﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("AreaGrabber")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("AUO")> 
<Assembly: AssemblyProduct("AreaGrabber")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft 2012")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("815959d1-2fc0-40ef-93bb-2c5f4a6f19f1")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 


<Assembly: AssemblyVersionAttribute("3.2020.05.01")> 
<Assembly: AssemblyFileVersionAttribute("3.2020.05.01")> 
