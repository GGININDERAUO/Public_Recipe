﻿Imports System.Windows.Forms
Imports System.IO
Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl
Imports System.Threading
Imports System.Globalization

Public Class Dialog_Align
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_TableProcess As ClsTableProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_Inverse As Boolean

    Private m_Left As Boolean
    Private m_Right As Boolean
    Private m_Top As Boolean
    Private m_Bottom As Boolean

    Private m_FuncBoundary As ClsParameterBoundary
    Private m_MuraBoundary As ClsParameterBoundary


    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_AxMDisplay As MIL_ID

    Private m_ModelChanged As Boolean
    Private m_PatternChanged As Boolean

    '--- 連線參數 ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- 多連線參數 ---
    Private m_ConnectedIP As ArrayList
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private WithEvents m_ZoomContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents m_ZoomInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_OriginToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

    '---SideViewAlign---
    Private m_Position As Integer

    '--- Grid Calibration ---
    Private m_Grid_Point As Point
    Private m_Grid_Angle As Double

    '---PatternAlign Display---
    Private m_AxMDisplay_PatternAlign As MIL_ID         '顯示 PatternAlign
    Private m_Img_8U_PatternAlign As MIL_ID = M_NULL
    Private res As System.Resources.ResourceManager '資源檔管理員

#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_Align", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo("zh-CN")
        Thread.CurrentThread.CurrentUICulture = New CultureInfo("zh-CN")
        Me.changeLanguage("zh-CN")
        '------------

        Try
            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess
            Me.m_FuncProcess = form.MainProcess.FuncProcess
            Me.m_MuraProcess = form.MainProcess.MuraProcess
            Me.m_TableProcess = form.MainProcess.TableProcess

            Me.m_ModelChanged = False
            Me.m_PatternChanged = False

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            Else
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            End If

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
            Me.m_AxMDisplay = Me.m_Form.AxMDisplay
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)
            Me.m_Pen = New Pen(Color.White)
            Me.m_Form.PaintStop = True

            image = Me.m_FuncProcess.Img_Original_NonPage
            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If

            '--- UI ---
            Me.m_VScrollBar = Me.m_Form.VScrollBar
            Me.m_HScrollBar = Me.m_Form.HScrollBar

            Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
            Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
            Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
            Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
            Me.m_ZoomContextMenuStrip = Me.m_Form.ZoomContextMenuStrip
            Me.m_ZoomInToolStripMenuItem = Me.m_Form.ZoomInToolStripMenuItem
            Me.m_ZoomOutToolStripMenuItem = Me.m_Form.ZoomOutToolStripMenuItem
            Me.m_OriginToolStripMenuItem = Me.m_Form.OriginToolStripMenuItem
            Me.m_ZoomAllToolStripMenuItem = Me.m_Form.ZoomAllToolStripMenuItem
            Me.ComboBox_MultiAngle.SelectedIndex = 0

            '---建立顯示 PatternAlign 元件 & Load Image---
            If Me.m_AxMDisplay_PatternAlign <> M_NULL Then
                MdispFree(Me.m_AxMDisplay_PatternAlign)
                Me.m_AxMDisplay_PatternAlign = M_NULL
            End If
            MdispAlloc(Me.m_MainProcess.System_Host, M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay_PatternAlign)

            '--- UI ---
            Me.UpdateData_Func()
            Me.UpdateData_Mura()
            Me.UpdateUserLevel()
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncSettingBase.SetMainForm]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Dialog Event ---"

    Private Sub Dialog_Dialog_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim PatternName As String = ""
        Dim Path As String = ""
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Text = "Model参数调整 [ " & Me.m_Form.GetProductNameInfo & " ]"

        Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
        RepairPath_2(Path)
        Me.m_FuncProcess.FuncModelRecipe = MILOperationLib.ClsFuncModelRecipe.ReadXML(Path)
        Label_Standard.Text = "MT参考座标：(" & Me.m_TableProcess.MappingTableRecipe.Standard_X.Value & "，" & Me.m_TableProcess.MappingTableRecipe.Standard_Y.Value & ") ;偏移角度：" & Format(Me.m_TableProcess.MappingTableRecipe.Standard_Theta.Value, "0.000")

        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 200000 '200 secs

                '--- PatternName ---
                PatternName = Me.m_Form.ComboBox_Pattern_MainFrm.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]Set Pattern Index Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

        Me.m_Form.ImageUpdate()
        Me.Update()
    End Sub

    Private Sub Dialog_Align_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing

        If Me.m_AxMDisplay_PatternAlign <> M_NULL Then
            MdispFree(Me.m_AxMDisplay_PatternAlign)
            Me.m_AxMDisplay_PatternAlign = M_NULL
        End If

        If Me.m_Img_8U_PatternAlign <> M_NULL Then
            MbufFree(Me.m_Img_8U_PatternAlign)
            Me.m_Img_8U_PatternAlign = M_NULL
        End If

        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.m_Form.PaintStop = True
        Me.m_Form.Focus()
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub

#End Region

#Region "--- 方法函式 ---"

#Region "--- UpdateUserLevel ---"

    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.TabControl_AlignSetting.Enabled = False
                Me.Button_LoadImage.Enabled = False
                Me.Button_Save.Enabled = False
            Case 1 'PM
                Me.TabControl_AlignSetting.Enabled = True

                Me.GroupBox_PanelRotate.Enabled = False
                Me.GroupBox_Boundary.Enabled = True
                Me.Button_Save.Enabled = True
                Me.Button_Close.Enabled = True
                Me.Button_LoadImage.Enabled = True
                Me.GroupBox_MT.Enabled = True
                Me.GroupBox_TableModify.Enabled = True
            Case 2 'ENG
                Me.TabControl_AlignSetting.Enabled = True

                Me.GroupBox_PanelRotate.Enabled = True
                Me.GroupBox_Boundary.Enabled = True
                Me.Button_Save.Enabled = True
                Me.Button_Close.Enabled = True
                Me.Button_LoadImage.Enabled = True
                Me.GroupBox_MT.Enabled = True
                Me.GroupBox_TableModify.Enabled = True
            Case 3 'ALL
                Me.TabControl_AlignSetting.Enabled = True

                Me.GroupBox_PanelRotate.Enabled = True
                Me.GroupBox_Boundary.Enabled = True
                Me.Button_Save.Enabled = True
                Me.Button_Close.Enabled = True
                Me.Button_LoadImage.Enabled = True
                Me.GroupBox_MT.Enabled = True
                Me.GroupBox_TableModify.Enabled = True
        End Select
    End Sub

#End Region

#Region "--- UpdateData ---"

#Region "--- UpdateData_Func ---"
    Private Sub UpdateData_Func()
        Dim fmr As ClsFuncModelRecipe

        Try
            fmr = Me.m_FuncProcess.FuncModelRecipe
            Me.m_FuncBoundary = fmr.Boundary

            If Me.m_IPBootConfig.MuraUI.Value Then
                Me.m_FuncBoundary = Me.m_MuraProcess.BoundaryOriginal
                If Me.m_FuncBoundary.TopY = 0 And Me.m_FuncBoundary.BottomY = 0 And Me.m_FuncBoundary.LeftX = 0 And Me.m_FuncBoundary.RightX = 0 Then
                    fmr.Boundary = Me.m_FuncProcess.FuncModelRecipe.Boundary
                    Me.m_FuncBoundary = fmr.Boundary
                End If
            End If

            '--- 第一頁 ---
            '--- [1] ROI ---
            Me.m_FuncBoundary = fmr.Boundary
            If Me.m_FuncBoundary.LeftX >= 0 And Me.m_FuncBoundary.RightX >= 0 And Me.m_FuncBoundary.TopY >= 0 And Me.m_FuncBoundary.BottomY Then
                Me.NumericUpDown_BoundaryTop.Maximum = Me.m_FuncBoundary.BottomY - 1
                Me.NumericUpDown_BoundaryBottom.Maximum = Me.m_IPBootConfig.ImageSizeY.Value - 1
                Me.NumericUpDown_BoundaryBottom.Minimum = Me.m_FuncBoundary.TopY + 1
                Me.NumericUpDown_BoundaryLeft.Maximum = Me.m_FuncBoundary.RightX - 1
                Me.NumericUpDown_BoundaryRight.Maximum = Me.m_IPBootConfig.ImageSizeX.Value - 1
                Me.NumericUpDown_BoundaryRight.Minimum = Me.m_FuncBoundary.LeftX + 1

                If Me.m_FuncBoundary.TopY >= Me.NumericUpDown_BoundaryTop.Maximum Then Me.m_FuncBoundary.TopY = Me.NumericUpDown_BoundaryTop.Maximum
                If Me.m_FuncBoundary.BottomY >= Me.NumericUpDown_BoundaryBottom.Maximum Then Me.m_FuncBoundary.BottomY = Me.NumericUpDown_BoundaryBottom.Maximum
                If Me.m_FuncBoundary.LeftX >= Me.NumericUpDown_BoundaryLeft.Maximum Then Me.m_FuncBoundary.LeftX = Me.NumericUpDown_BoundaryLeft.Maximum
                If Me.m_FuncBoundary.RightX >= Me.NumericUpDown_BoundaryRight.Maximum Then Me.m_FuncBoundary.RightX = Me.NumericUpDown_BoundaryRight.Maximum

                Me.NumericUpDown_BoundaryTop.Value = Me.m_FuncBoundary.TopY
                Me.NumericUpDown_BoundaryBottom.Value = Me.m_FuncBoundary.BottomY
                Me.NumericUpDown_BoundaryLeft.Value = Me.m_FuncBoundary.LeftX
                Me.NumericUpDown_BoundaryRight.Value = Me.m_FuncBoundary.RightX
            End If

            '--- [2] SideViewAlign ---
            Me.CheckBox_SideViewAlign.Checked = fmr.SideViewAlign.Value
            If Me.ComboBox_MultiAngle.Text = "LEFT" Then
                Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Left.LeftX & " , " & fmr.LeftUpRightDown_Left.TopY & ")"
                Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Left.RightX & " , " & fmr.LeftDownRightUp_Left.TopY & ")"
                Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Left.RightX & " , " & fmr.LeftUpRightDown_Left.BottomY & ")"
                Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Left.LeftX & " , " & fmr.LeftDownRightUp_Left.BottomY & ")"
            ElseIf Me.ComboBox_MultiAngle.Text = "RIGHT" Then
                Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Right.LeftX & " , " & fmr.LeftUpRightDown_Right.TopY & ")"
                Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Right.RightX & " , " & fmr.LeftDownRightUp_Right.TopY & ")"
                Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Right.RightX & " , " & fmr.LeftUpRightDown_Right.BottomY & ")"
                Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Right.LeftX & " , " & fmr.LeftDownRightUp_Right.BottomY & ")"
            ElseIf Me.ComboBox_MultiAngle.Text = "TOP" Then
                Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Top.LeftX & " , " & fmr.LeftUpRightDown_Top.TopY & ")"
                Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Top.RightX & " , " & fmr.LeftDownRightUp_Top.TopY & ")"
                Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Top.RightX & " , " & fmr.LeftUpRightDown_Top.BottomY & ")"
                Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Top.LeftX & " , " & fmr.LeftDownRightUp_Top.BottomY & ")"
            ElseIf Me.ComboBox_MultiAngle.Text = "BOTTOM" Then
                Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Bottom.LeftX & " , " & fmr.LeftUpRightDown_Bottom.TopY & ")"
                Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Bottom.RightX & " , " & fmr.LeftDownRightUp_Bottom.TopY & ")"
                Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Bottom.RightX & " , " & fmr.LeftUpRightDown_Bottom.BottomY & ")"
                Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Bottom.LeftX & " , " & fmr.LeftDownRightUp_Bottom.BottomY & ")"
            Else
                Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown.LeftX & " , " & fmr.LeftUpRightDown.TopY & ")"
                Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp.RightX & " , " & fmr.LeftDownRightUp.TopY & ")"
                Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown.RightX & " , " & fmr.LeftUpRightDown.BottomY & ")"
                Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp.LeftX & " , " & fmr.LeftDownRightUp.BottomY & ")"
            End If

            Me.RadioButton_BoundaryFinish.Checked = True

            '--- 第二頁 ---
            '--- [1] Align Type --
            If fmr.AlignType.Value = AlignType.Rectangle Then
                Me.RadioButton_AlignType_Rectangle.Checked = True
            ElseIf fmr.AlignType.Value = AlignType.Circle Then
                Me.RadioButton_AlignType_Circle.Checked = True
            ElseIf fmr.AlignType.Value = AlignType.Dot Then
                Me.RadioButton_AlignType_Dot.Checked = True
            End If

            '--- [2] Alignment Direction and Shift Offset ---
            Me.CheckBox_Func_TopAnalysis.Checked = fmr.TopAnalysis.Value
            Me.CheckBox_Func_BottomAnalysis.Checked = fmr.BottomAnalysis.Value
            Me.CheckBox_Func_LeftAnalysis.Checked = fmr.LeftAnalysis.Value
            Me.CheckBox_Func_RightAnalysis.Checked = fmr.RightAnalysis.Value

            Me.NumericUpDown_ShiftOffset_Top.Value = fmr.AlignmentShift_Offset.TopY
            Me.NumericUpDown_ShiftOffset_Bottom.Value = fmr.AlignmentShift_Offset.BottomY
            Me.NumericUpDown_ShiftOffset_Left.Value = fmr.AlignmentShift_Offset.LeftX
            Me.NumericUpDown_ShiftOffset_Right.Value = fmr.AlignmentShift_Offset.RightX

            '--- [3] Align ---
            Me.NumericUpDown_AlignmentShift.Value = fmr.Alignment_Shift.Value
            Me.NumericUpDown_AlignTolerance.Value = fmr.AlignTolerance.Value
            Me.CheckBox_EnhanceEdge.Checked = fmr.EnhanceEdge.Value
            Me.CheckBox_RotateCal.Checked = fmr.RotateCal.Value
            If fmr.RotateTheta.Value = "" Then
                If Me.CheckBox_Func_TopAnalysis.Checked Then
                    fmr.RotateTheta.Value = "TOP"
                ElseIf Me.CheckBox_Func_BottomAnalysis.Checked Then
                    fmr.RotateTheta.Value = "BOTTOM"
                ElseIf Me.CheckBox_Func_LeftAnalysis.Checked Then
                    fmr.RotateTheta.Value = "LEFT"
                ElseIf Me.CheckBox_Func_RightAnalysis.Checked Then
                    fmr.RotateTheta.Value = "RIGHT"
                End If
            Else
                Me.ComboBox_RotateTheta.Text = fmr.RotateTheta.Value
            End If

            '--- [4] Panel Rotate ---
            Me.CheckBox_PanelRotate.Checked = fmr.PanelRotate.Value
            Me.CheckBox_PanelMirror.Checked = fmr.PanelMirror.Value

            '--- 第三頁 ---
            '--- [1] Calibration Grid Setting ---
            Me.NumericUpDown_CalibrationGrid_Column_Num.Value = fmr.CalibrationGrid_Column_Num.Value
            Me.NumericUpDown_CalibrationGrid_Row_Num.Value = fmr.CalibrationGrid_Row_Num.Value
            Me.NumericUpDown_CalibrationGrid_X_Tolerance.Value = fmr.CalibrationGrid_X_Tolerance.Value
            Me.NumericUpDown_CalibrationGrid_Y_Tolerance.Value = fmr.CalibrationGrid_Y_Tolerance.Value

            Me.GroupBox_Calibration_Grid_Setting.Enabled = Me.m_IPBootConfig.Grid_Calibration_Enable.Value


            Label_Standard.Text = "MT參考座標：(" & Me.m_MainProcess.TableProcess.MappingTableRecipe.Standard_X.Value & "，" & Me.m_MainProcess.TableProcess.MappingTableRecipe.Standard_Y.Value & ") ;偏移角度：" & Format(Me.m_MainProcess.TableProcess.MappingTableRecipe.Standard_Theta.Value, "0.000")

        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.UpdateData_Func]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.UpdateData_Func]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- UpdateData_Mura ---"
    Public Sub UpdateData_Mura()
        Dim TransferBoundary As ClsParameterBoundary
        Dim mmr As ClsMuraModelRecipe
        Dim IPBootConfig As ClsIPBootConfig
        Try
            mmr = Me.m_MuraProcess.MuraModelRecipe
            IPBootConfig = Me.m_MainProcess.IPBootConfig

            '--- 計算JND值轉換設定 ---
            If IPBootConfig.Digitizer_Datadepth.Value >= 8 Then
                mmr.Divid.Value = 2 ^ (IPBootConfig.Digitizer_Datadepth.Value - 8)
            Else
                MessageBox.Show("[Dialog_MuraSettingBase.UpdateData] Digitizer's DataDepth 數值設定小於8，請重新確認 IPBootConfig中<Digitizer_Datadepth>參數", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            If IPBootConfig.Panel_TransferMode.Value = "MAPPINGTABLE" Then Me.Rdb_ScabType_MT.Checked = True
            If IPBootConfig.Panel_TransferMode.Value = "LINEAR" Then
                Me.Rdb_ScabType_Linear.Checked = True
                Me.GroupBox_TableModify.Enabled = True
            Else
                Me.GroupBox_TableModify.Enabled = False
            End If

            Me.m_MuraBoundary = mmr.Table

            If Me.m_MuraBoundary.TopY = Me.m_MuraBoundary.BottomY Or Me.m_MuraBoundary.LeftX = Me.m_MuraBoundary.RightX Then
                If Me.m_MuraBoundary.TopY = Me.m_MuraBoundary.BottomY Then
                    Me.m_MuraBoundary.BottomY = Me.m_MuraBoundary.BottomY + 1
                End If
                If Me.m_MuraBoundary.LeftX = Me.m_MuraBoundary.RightX Then
                    Me.m_MuraBoundary.RightX = Me.m_MuraBoundary.RightX + 1
                End If
            End If

            Me.NumericUpDown_TableTop.Maximum = Me.m_MuraBoundary.BottomY - 1
            Me.NumericUpDown_TableBottom.Maximum = IPBootConfig.ImageSizeY.Value - 1
            Me.NumericUpDown_TableBottom.Minimum = Me.m_MuraBoundary.TopY + 1
            Me.NumericUpDown_TableLeft.Maximum = Me.m_MuraBoundary.RightX - 1
            If Me.NumericUpDown_TableLeft.Maximum < 0 Then Me.NumericUpDown_TableLeft.Maximum = 0
            Me.NumericUpDown_TableRight.Minimum = Me.m_MuraBoundary.LeftX + 1

            '2009/06/08 Rick modify
            If Me.m_MuraBoundary.TopY > Me.NumericUpDown_TableTop.Maximum Then
                Me.m_MuraBoundary.TopY = Me.NumericUpDown_TableTop.Maximum
            Else
                Me.NumericUpDown_TableTop.Value = Me.m_MuraBoundary.TopY
            End If
            If Me.m_MuraBoundary.BottomY > Me.NumericUpDown_TableBottom.Maximum Then
                Me.m_MuraBoundary.BottomY = Me.NumericUpDown_TableBottom.Maximum
            Else
                Me.NumericUpDown_TableBottom.Value = Me.m_MuraBoundary.BottomY
            End If
            If Me.m_MuraBoundary.LeftX > Me.NumericUpDown_TableLeft.Maximum Then
                Me.m_MuraBoundary.LeftX = Me.NumericUpDown_TableLeft.Maximum
            Else
                Me.NumericUpDown_TableLeft.Value = Me.m_MuraBoundary.LeftX
            End If
            If Me.m_MuraBoundary.RightX > Me.NumericUpDown_TableRight.Maximum Then
                Me.m_MuraBoundary.RightX = Me.NumericUpDown_TableRight.Maximum
            Else
                Me.NumericUpDown_TableRight.Value = Me.m_MuraBoundary.RightX
            End If

            TransferBoundary = mmr.DataGate
            Me.NumericUpDown_LocalTop.Value = TransferBoundary.TopY
            Me.NumericUpDown_LocalBottom.Value = TransferBoundary.BottomY
            Me.NumericUpDown_LocalLeft.Value = TransferBoundary.LeftX
            Me.NumericUpDown_LocalRight.Value = TransferBoundary.RightX

            Me.RadioButton_TableFinish.Checked = True

        Catch ex As Exception
            Throw New Exception("[Dialog_MuraSettingBase.UpdateData]UpdateData Error! (" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim fmr As ClsFuncModelRecipe
        Dim ibc As ClsIPBootConfig
        Dim mmr As ClsMuraModelRecipe

        fmr = Me.m_FuncProcess.FuncModelRecipe
        ibc = Me.m_MainProcess.IPBootConfig
        mmr = Me.m_MuraProcess.MuraModelRecipe

        Try
            Me.m_FuncBoundary = fmr.Boundary

            '--- 第一頁 ---
            '--- [1] ROI ---
            Me.m_FuncBoundary.TopY = Me.NumericUpDown_BoundaryTop.Value
            Me.m_FuncBoundary.BottomY = Me.NumericUpDown_BoundaryBottom.Value
            Me.m_FuncBoundary.LeftX = Me.NumericUpDown_BoundaryLeft.Value
            Me.m_FuncBoundary.RightX = Me.NumericUpDown_BoundaryRight.Value

            '--- [2] SideView Position ---
            If Me.ComboBox_MultiAngle.Text = "LEFT" Then
                fmr.LeftUpRightDown_Left.LeftX = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Left.TopY = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftUpRightDown_Left.RightX = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Left.BottomY = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Left.LeftX = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Left.BottomY = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Left.RightX = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Left.TopY = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(1)
            ElseIf Me.ComboBox_MultiAngle.Text = "RIGHT" Then
                fmr.LeftUpRightDown_Right.LeftX = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Right.TopY = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftUpRightDown_Right.RightX = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Right.BottomY = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Right.LeftX = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Right.BottomY = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Right.RightX = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Right.TopY = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(1)
            ElseIf Me.ComboBox_MultiAngle.Text = "TOP" Then
                fmr.LeftUpRightDown_Top.LeftX = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Top.TopY = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftUpRightDown_Top.RightX = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Top.BottomY = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Top.LeftX = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Top.BottomY = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Top.RightX = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Top.TopY = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(1)
            ElseIf Me.ComboBox_MultiAngle.Text = "BOTTOM" Then
                fmr.LeftUpRightDown_Bottom.LeftX = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Bottom.TopY = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftUpRightDown_Bottom.RightX = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown_Bottom.BottomY = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Bottom.LeftX = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Bottom.BottomY = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp_Bottom.RightX = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp_Bottom.TopY = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(1)
            Else
                fmr.LeftUpRightDown.LeftX = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown.TopY = Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftUpRightDown.RightX = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftUpRightDown.BottomY = Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp.LeftX = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp.BottomY = Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(1)
                fmr.LeftDownRightUp.RightX = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(0)
                fmr.LeftDownRightUp.TopY = Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(1)
            End If

            fmr.SideViewAlign.Value = Me.CheckBox_SideViewAlign.Checked

            '--- 第二頁 ---
            '--- [1] Align Type ---
            If Me.RadioButton_AlignType_Rectangle.Checked Then
                fmr.AlignType.Value = AlignType.Rectangle
            ElseIf Me.RadioButton_AlignType_Circle.Checked Then
                fmr.AlignType.Value = AlignType.Circle
            ElseIf Me.RadioButton_AlignType_Dot.Checked Then
                fmr.AlignType.Value = AlignType.Dot
            End If

            '--- [2] Alignment Direction and Shift Offset ---
            fmr.AlignmentShift_Offset.TopY = Me.NumericUpDown_ShiftOffset_Top.Value
            fmr.AlignmentShift_Offset.BottomY = Me.NumericUpDown_ShiftOffset_Bottom.Value
            fmr.AlignmentShift_Offset.LeftX = Me.NumericUpDown_ShiftOffset_Left.Value
            fmr.AlignmentShift_Offset.RightX = Me.NumericUpDown_ShiftOffset_Right.Value

            fmr.TopAnalysis.Value = Me.CheckBox_Func_TopAnalysis.Checked
            fmr.BottomAnalysis.Value = Me.CheckBox_Func_BottomAnalysis.Checked
            fmr.LeftAnalysis.Value = Me.CheckBox_Func_LeftAnalysis.Checked
            fmr.RightAnalysis.Value = Me.CheckBox_Func_RightAnalysis.Checked

            '--- [3] Align ---
            fmr.Alignment_Shift.Value = Me.NumericUpDown_AlignmentShift.Value
            fmr.AlignTolerance.Value = Me.NumericUpDown_AlignTolerance.Value
            fmr.EnhanceEdge.Value = Me.CheckBox_EnhanceEdge.Checked
            fmr.RotateCal.Value = Me.CheckBox_RotateCal.Checked
            fmr.RotateTheta.Value = Me.ComboBox_RotateTheta.Text

            '--- [4] Panel Rotate ---
            fmr.PanelRotate.Value = Me.CheckBox_PanelRotate.Checked
            fmr.PanelMirror.Value = Me.CheckBox_PanelMirror.Checked

            '--- 第三頁 ---
            '--- [1] Calibration Grid Setting ---
            fmr.CalibrationGrid_Column_Num.Value = Me.NumericUpDown_CalibrationGrid_Column_Num.Value
            fmr.CalibrationGrid_Row_Num.Value = Me.NumericUpDown_CalibrationGrid_Row_Num.Value
            fmr.CalibrationGrid_X_Tolerance.Value = Me.NumericUpDown_CalibrationGrid_X_Tolerance.Value
            fmr.CalibrationGrid_Y_Tolerance.Value = Me.NumericUpDown_CalibrationGrid_Y_Tolerance.Value

            '--- 第四頁 ---
            '--- [1] Data\Gate 轉換方式 ---
            If Me.Rdb_ScabType_MT.Checked Then
                ibc.Panel_TransferMode.Value = "MAPPINGTABLE"
            ElseIf Me.Rdb_ScabType_Linear.Checked Then
                ibc.Panel_TransferMode.Value = "LINEAR"
            End If

            mmr.Table.TopY = Me.NumericUpDown_TableTop.Value
            mmr.Table.BottomY = Me.NumericUpDown_TableBottom.Value
            mmr.Table.LeftX = Me.NumericUpDown_TableLeft.Value
            mmr.Table.RightX = Me.NumericUpDown_TableRight.Value

            mmr.DataGate.TopY = Me.NumericUpDown_LocalTop.Value
            mmr.DataGate.BottomY = Me.NumericUpDown_LocalBottom.Value
            mmr.DataGate.LeftX = Me.NumericUpDown_LocalLeft.Value
            mmr.DataGate.RightX = Me.NumericUpDown_LocalRight.Value

        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Setting]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.Setting]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- ConnectToMultiIP ---"
    Public Function ConnectToMultiIP() As Boolean
        Dim ipnwc As ClsIPNetWorkConfig
        Dim i As Integer
        Dim ErrMsg = ""

        Me.m_ConnectedIP = New ArrayList
        ipnwc = Me.m_MainProcess.IPNetworkConfig

        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then
                ip = New ClsIPInfo
                ip.CCDNo = i
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
                System.Threading.Thread.Sleep(200)

                If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                    ErrMsg = ErrMsg + "IP - " & i & " 連線失敗 !( " & Me.m_IPConnectMsg & " )" & " ; "
                    Me.m_MainProcess.IsIPConnected = False
                Else
                    Me.m_ConnectedIP.Add(ip.CCDNo)
                End If

            End If

        Next

        If ErrMsg <> "" Then
            MsgBox(ErrMsg, MsgBoxStyle.Critical, "[AreaGrabber]")
            Return False
        Else
            Me.m_MainProcess.IsIPConnected = True
            Return True
        End If

    End Function
#End Region

#Region "--- Compare ---"

    Private Sub Compare(ByVal fmrOld As ClsFuncModelRecipe, ByVal fmrNew As ClsFuncModelRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim boundaryOld As ClsParameterBoundary
        Dim boundaryNew As ClsParameterBoundary
        '--- 第一頁 ---
        boundaryOld = fmrOld.Boundary
        boundaryNew = fmrNew.Boundary
        dlm.WriteLog("********************[FuncModelRecipe]************************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("[ClsFuncModelRecipe]Boundary.TopY: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
            boundaryOld.TopY = boundaryNew.TopY
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("[ClsFuncModelRecipe]Boundary.BottomY: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
            boundaryOld.BottomY = boundaryNew.BottomY
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("[ClsFuncModelRecipe]Boundary.LeftX: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
            boundaryOld.LeftX = boundaryNew.LeftX
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("[ClsFuncModelRecipe]Boundary.RightX: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
            boundaryOld.RightX = boundaryNew.RightX
        End If

        If fmrOld.FalseCount.Value <> fmrNew.FalseCount.Value Then
            dlm.WriteLog("[ClsFuncModelRecipe]Func FalseCount: " & fmrOld.FalseCount.Value & " --> " & fmrNew.FalseCount.Value)
            fmrOld.FalseCount.Value = fmrNew.FalseCount.Value
        End If
        If fmrOld.PatternCount.Value <> fmrNew.PatternCount.Value Then
            dlm.WriteLog("[ClsFuncModelRecipe]Func PatternCount: " & fmrOld.PatternCount.Value & " --> " & fmrNew.PatternCount.Value)
            fmrOld.PatternCount.Value = fmrNew.PatternCount.Value
        End If
        If fmrOld.Distance.Value <> fmrNew.Distance.Value Then
            dlm.WriteLog("[ClsFuncModelRecipe]Distance: " & fmrOld.Distance.Value & " --> " & fmrNew.Distance.Value)
            fmrOld.Distance.Value = fmrNew.Distance.Value
        End If

        '--- 第四頁 ---
        If fmrOld.PanelRotate.Value <> fmrNew.PanelRotate.Value Then
            dlm.WriteLog("[ClsFuncModelRecipe]PanelRotate: " & fmrOld.PanelRotate.Value & " --> " & fmrNew.PanelRotate.Value)
            fmrOld.PanelRotate.Value = fmrNew.PanelRotate.Value
        End If
        If fmrOld.Alignment_Shift.Value <> fmrNew.Alignment_Shift.Value Then
            dlm.WriteLog("[ClsFuncModelRecipe]Alignment_Shift: " & fmrOld.Alignment_Shift.Value & " --> " & fmrNew.Alignment_Shift.Value)
            fmrOld.Alignment_Shift.Value = fmrNew.Alignment_Shift.Value
        End If

    End Sub

    Private Sub Compare(ByVal fprOld As ClsFuncPatternRecipe, ByVal fprNew As ClsFuncPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[FuncPatternRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)
        If fprOld.PatternName.Value <> fprNew.PatternName.Value Then
            dlm.WriteLog("< PatternName >: " & fprNew.PatternName.Value & " --> " & fprNew.PatternName.Value)
        End If
        If fprOld.ExposureTime.Value <> fprNew.ExposureTime.Value Then
            dlm.WriteLog("< ExposureTime >: " & fprNew.ExposureTime.Value & " --> " & fprNew.ExposureTime.Value)
        End If
        If fprOld.DisplayMeanEnable.Value <> fprNew.DisplayMeanEnable.Value Then
            dlm.WriteLog("< MeanEnable >: " & fprNew.DisplayMeanEnable.Value & " --> " & fprNew.DisplayMeanEnable.Value)
        End If
        If fprOld.PointEnable.Value <> fprNew.PointEnable.Value Then
            dlm.WriteLog("< PointEnable >: " & fprNew.PointEnable.Value & " --> " & fprNew.PointEnable.Value)
        End If
        If fprOld.AnalysisBP.Value <> fprNew.AnalysisBP.Value Then
            dlm.WriteLog("< AnalysisBP >: " & fprNew.AnalysisBP.Value & " --> " & fprNew.AnalysisBP.Value)
        End If
        If fprOld.AnalysisDP.Value <> fprNew.AnalysisDP.Value Then
            dlm.WriteLog("< AnalysisDP >: " & fprNew.AnalysisDP.Value & " --> " & fprNew.AnalysisDP.Value)
        End If
        If fprOld.LineEnable.Value <> fprNew.LineEnable.Value Then
            dlm.WriteLog("< LineEnable >: " & fprNew.LineEnable.Value & " --> " & fprNew.LineEnable.Value)
        End If

        '--- LineFinderrecipe ---

        If fprOld.LineFinderRecipe.ByPassUpH.Value <> fprNew.LineFinderRecipe.ByPassUpH.Value Then
            dlm.WriteLog("< ByPassUpH >: " & fprOld.LineFinderRecipe.ByPassUpH.Value & " --> " & fprNew.LineFinderRecipe.ByPassUpH.Value)
        End If
        If fprOld.LineFinderRecipe.ByPassDownH.Value <> fprNew.LineFinderRecipe.ByPassDownH.Value Then
            dlm.WriteLog("< ByPassDownH >: " & fprOld.LineFinderRecipe.ByPassDownH.Value & " --> " & fprNew.LineFinderRecipe.ByPassDownH.Value)
        End If
        If fprOld.LineFinderRecipe.ByPassLeftV.Value <> fprNew.LineFinderRecipe.ByPassLeftV.Value Then
            dlm.WriteLog("< ByPassLeftV >: " & fprOld.LineFinderRecipe.ByPassLeftV.Value & " --> " & fprNew.LineFinderRecipe.ByPassLeftV.Value)
        End If
        If fprOld.LineFinderRecipe.ByPassRightV.Value <> fprNew.LineFinderRecipe.ByPassRightV.Value Then
            dlm.WriteLog("< ByPassRightV >: " & fprOld.LineFinderRecipe.ByPassRightV.Value & " --> " & fprNew.LineFinderRecipe.ByPassRightV.Value)
        End If
        If fprOld.LineFinderRecipe.Line_Cut.Value <> fprNew.LineFinderRecipe.Line_Cut.Value Then
            dlm.WriteLog("< Line_Cut >: " & fprOld.LineFinderRecipe.Line_Cut.Value & " --> " & fprNew.LineFinderRecipe.Line_Cut.Value)
        End If
        If fprOld.LineFinderRecipe.Line_Short_Cut.Value <> fprNew.LineFinderRecipe.Line_Short_Cut.Value Then
            dlm.WriteLog("< Line_Short_Cut >: " & fprOld.LineFinderRecipe.Line_Short_Cut.Value & " --> " & fprNew.LineFinderRecipe.Line_Short_Cut.Value)
        End If
        If fprOld.LineFinderRecipe.LineOverNum.Value <> fprNew.LineFinderRecipe.LineOverNum.Value Then
            dlm.WriteLog("< LineOverNum >: " & fprOld.LineFinderRecipe.LineOverNum.Value & " --> " & fprNew.LineFinderRecipe.LineOverNum.Value)
        End If
        If fprOld.LineFinderRecipe.BlockOverNum.Value <> fprNew.LineFinderRecipe.BlockOverNum.Value Then
            dlm.WriteLog("< BlockOverNum >: " & fprOld.LineFinderRecipe.BlockOverNum.Value & " --> " & fprNew.LineFinderRecipe.BlockOverNum.Value)
        End If
        If fprOld.LineFinderRecipe.Mean_Difference.Value <> fprNew.LineFinderRecipe.Mean_Difference.Value Then
            dlm.WriteLog("< Mean_Difference >: " & fprOld.LineFinderRecipe.Mean_Difference.Value & " --> " & fprNew.LineFinderRecipe.Mean_Difference.Value)
        End If
        If fprOld.LineEnable.Value <> fprNew.LineEnable.Value Then
            dlm.WriteLog("< LineEnable >: " & fprOld.LineEnable.Value & " --> " & fprNew.LineEnable.Value)
        End If
        If fprOld.HLine_NotAddToOutput.Value <> fprNew.HLine_NotAddToOutput.Value Then
            dlm.WriteLog("< HLine_NotAddToOutput >: " & fprOld.HLine_NotAddToOutput.Value & " --> " & fprNew.HLine_NotAddToOutput.Value)
        End If
        If fprOld.VLine_NotAddToOutput.Value <> fprNew.VLine_NotAddToOutput.Value Then
            dlm.WriteLog("< VLine_NotAddToOutput >: " & fprOld.VLine_NotAddToOutput.Value & " --> " & fprNew.VLine_NotAddToOutput.Value)
        End If
        If fprOld.HalfScreenEnable.Value <> fprNew.HalfScreenEnable.Value Then
            dlm.WriteLog("< HalfScreenEnable >: " & fprOld.HalfScreenEnable.Value & " --> " & fprNew.HalfScreenEnable.Value)
        End If

        '--- BDPointRecipe ---

        If fprOld.BDPointRecipe.Threshold_BP.Value <> fprNew.BDPointRecipe.Threshold_BP.Value Then
            dlm.WriteLog("< Threshold_BP >: " & fprOld.BDPointRecipe.Threshold_BP.Value & " --> " & fprNew.BDPointRecipe.Threshold_BP.Value)
        End If
        If fprOld.BDPointRecipe.Threshold_DP.Value <> fprNew.BDPointRecipe.Threshold_DP.Value Then
            dlm.WriteLog("< Threshold_DP >: " & fprOld.BDPointRecipe.Threshold_DP.Value & " --> " & fprNew.BDPointRecipe.Threshold_DP.Value)
        End If
        If fprOld.BDPointRecipe.ThresholdRim_BP.Value <> fprNew.BDPointRecipe.ThresholdRim_BP.Value Then
            dlm.WriteLog("< ThresholdRim_BP >: " & fprOld.BDPointRecipe.ThresholdRim_BP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_BP.Value)
        End If
        If fprOld.BDPointRecipe.ThresholdRim_DP.Value <> fprNew.BDPointRecipe.ThresholdRim_DP.Value Then
            dlm.WriteLog("< ThresholdRim_DP >: " & fprOld.BDPointRecipe.ThresholdRim_DP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_DP.Value)
        End If

        If fprOld.BDPointRecipe.AreaMax_BP.Value <> fprNew.BDPointRecipe.AreaMax_BP.Value Then
            dlm.WriteLog("< AreaMax_BP >: " & fprOld.BDPointRecipe.AreaMax_BP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_BP.Value)
        End If
        If fprOld.BDPointRecipe.AreaMin_BP.Value <> fprNew.BDPointRecipe.AreaMin_BP.Value Then
            dlm.WriteLog("< AreaMin_BP >: " & fprOld.BDPointRecipe.AreaMin_BP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_BP.Value)
        End If
        If fprOld.BDPointRecipe.AreaMax_DP.Value <> fprNew.BDPointRecipe.AreaMax_DP.Value Then
            dlm.WriteLog("< AreaMax_DP >: " & fprOld.BDPointRecipe.AreaMax_DP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_DP.Value)
        End If
        If fprOld.BDPointRecipe.AreaMin_DP.Value <> fprNew.BDPointRecipe.AreaMin_DP.Value Then
            dlm.WriteLog("< AreaMin_DP >: " & fprOld.BDPointRecipe.AreaMin_DP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_DP.Value)
        End If

        If fprOld.BDPointRecipe.BypassX.Value <> fprNew.BDPointRecipe.BypassX.Value Then
            dlm.WriteLog("< BypassX >: " & fprOld.BDPointRecipe.BypassX.Value & " --> " & fprNew.BDPointRecipe.BypassX.Value)
        End If
        If fprOld.BDPointRecipe.BypassY.Value <> fprNew.BDPointRecipe.BypassY.Value Then
            dlm.WriteLog("< BypassY >: " & fprOld.BDPointRecipe.BypassY.Value & " --> " & fprNew.BDPointRecipe.BypassY.Value)
        End If
        If fprOld.BDPointRecipe.OverNum.Value <> fprNew.BDPointRecipe.OverNum.Value Then
            dlm.WriteLog("< OverNum >: " & fprOld.BDPointRecipe.OverNum.Value & " --> " & fprNew.BDPointRecipe.OverNum.Value)
        End If
        If fprOld.PointEnable.Value <> fprNew.PointEnable.Value Then
            dlm.WriteLog("< PointEnable >: " & fprOld.PointEnable.Value & " --> " & fprNew.PointEnable.Value)
        End If

    End Sub

    Private Sub Compare(ByVal fpraOldOrder As ClsFuncPatternRecipeArray, ByVal fpraOld As ClsFuncPatternRecipeArray, ByVal fpraNew As ClsFuncPatternRecipeArray, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim i As Integer
        Dim j As Integer
        Dim fpp As ClsFuncPatternRecipe
        Dim fppOldOrder As ClsFuncPatternRecipe
        Dim fppOld As ClsFuncPatternRecipe
        Dim fppNew As ClsFuncPatternRecipe
        Dim bool As Boolean
        Dim bools(fpraNew.Count - 1) As Boolean
        For j = 0 To fpraNew.Count - 1
            bools(j) = True
        Next
        dlm.WriteLog("***********************[FuncPattern]*************************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)
        For i = 0 To fpraOldOrder.Count - 1
            fppOldOrder = fpraOldOrder.Item(i)
            fppOld = fpraOld.Item(i)
            bool = True

            For j = 0 To fpraNew.Count - 1
                fppNew = fpraNew.Item(j)
                If fppOldOrder Is fppNew Then
                    If i <> j Then
                        dlm.WriteLog("[Func] PatternReorder: " & i + 1 & " --> " & j + 1)
                    Else
                        dlm.WriteLog("[Func] Pattern: " & i + 1)
                    End If
                    Me.Compare(fppOld, fppNew, dlm)
                    bool = False
                    bools(j) = False
                    Exit For
                End If
            Next
            If bool Then
                dlm.WriteLog("[Func] PatternRemove: " & i + 1)
            End If
        Next

        For j = 0 To fpraNew.Count - 1
            If bools(j) Then
                dlm.WriteLog("[Func] PatternAdd: " & j + 1)
            End If
        Next
        fpraOldOrder.Clear()
        fpraOld.Clear()

        For i = 0 To fpraNew.Count - 1
            fpp = fpraNew.Item(i)
            fpraOldOrder.Add(fpp)
            fpraOld.Add(New ClsFuncPatternRecipe(fpp))
        Next
    End Sub

    Private Sub Compare(ByVal mmrOld As ClsMuraModelRecipe, ByVal mmrNew As ClsMuraModelRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim boundaryOld As ClsParameterBoundary
        Dim boundaryNew As ClsParameterBoundary

        dlm.WriteLog("********************[MuraModelRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)
        '--- 第一頁 ---
        boundaryOld = mmrOld.Boundary
        boundaryNew = mmrNew.Boundary
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("[MuraModelRecipe]Boundary.TopY: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
            boundaryOld.TopY = boundaryNew.TopY
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("[MuraModelRecipe]Boundary.BottomY: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
            boundaryOld.BottomY = boundaryNew.BottomY
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("[MuraModelRecipe]Boundary.LeftX: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
            boundaryOld.LeftX = boundaryNew.LeftX
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("[MuraModelRecipe]Boundary.RightX: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
            boundaryOld.RightX = boundaryNew.RightX
        End If

        boundaryOld = mmrOld.Table
        boundaryNew = mmrNew.Table
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("[MuraModelRecipe]Table.TopY: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
            boundaryOld.TopY = boundaryNew.TopY
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("[MuraModelRecipe]Table.BottomY: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
            boundaryOld.BottomY = boundaryNew.BottomY
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("[MuraModelRecipe]Table.LeftX: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
            boundaryOld.LeftX = boundaryNew.LeftX
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("[MuraModelRecipe]Table.RightX: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
            boundaryOld.RightX = boundaryNew.RightX
        End If

        boundaryOld = mmrOld.DataGate
        boundaryNew = mmrNew.DataGate
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("[MuraModelRecipe]DataGate.TopY: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
            boundaryOld.TopY = boundaryNew.TopY
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("[MuraModelRecipe]DataGate.BottomY: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
            boundaryOld.BottomY = boundaryNew.BottomY
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("[MuraModelRecipe]DataGate.LeftX: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
            boundaryOld.LeftX = boundaryNew.LeftX
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("[MuraModelRecipe]DataGate.RightX: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
            boundaryOld.RightX = boundaryNew.RightX
        End If

        '--- 第二頁 ---
        If mmrOld.AutoAddFalse.Value <> mmrNew.AutoAddFalse.Value Then
            dlm.WriteLog("[MuraModelRecipe]AutoAddFalse: " & mmrOld.AutoAddFalse.Value & " --> " & mmrNew.AutoAddFalse.Value)
            mmrOld.AutoAddFalse.Value = mmrNew.AutoAddFalse.Value
        End If
        If mmrOld.FalseCount.Value <> mmrNew.FalseCount.Value Then
            dlm.WriteLog("[MuraModelRecipe]FalseCount: " & mmrOld.FalseCount.Value & " --> " & mmrNew.FalseCount.Value)
            mmrOld.FalseCount.Value = mmrNew.FalseCount.Value
        End If
        If mmrOld.Distance.Value <> mmrNew.Distance.Value Then
            dlm.WriteLog("[MuraModelRecipe]Distance: " & mmrOld.Distance.Value & " --> " & mmrNew.Distance.Value)
            mmrOld.Distance.Value = mmrNew.Distance.Value
        End If
        If mmrOld.AreaMisalliance.Value <> mmrNew.AreaMisalliance.Value Then
            dlm.WriteLog("[MuraModelRecipe]AreaMisalliance: " & mmrOld.AreaMisalliance.Value & " --> " & mmrNew.AreaMisalliance.Value)
            mmrOld.AreaMisalliance.Value = mmrNew.AreaMisalliance.Value
        End If
        If mmrOld.FB_Distance.Value <> mmrNew.FB_Distance.Value Then
            dlm.WriteLog("[MuraModelRecipe]FB_Distance: " & mmrOld.FB_Distance.Value & " --> " & mmrNew.FB_Distance.Value)
            mmrOld.FB_Distance.Value = mmrNew.FB_Distance.Value
        End If

        If mmrOld.UseAutoFFC.Value <> mmrNew.UseAutoFFC.Value Then
            dlm.WriteLog("[MuraModelRecipe]UseAutoFFC: " & mmrOld.UseAutoFFC.Value & " --> " & mmrNew.UseAutoFFC.Value)
            mmrOld.UseAutoFFC.Value = mmrNew.UseAutoFFC.Value
        End If
        If mmrOld.CountToChangeFFC.Value <> mmrNew.CountToChangeFFC.Value Then
            dlm.WriteLog("[MuraModelRecipe]CountToChangeFFC: " & mmrOld.CountToChangeFFC.Value & " --> " & mmrNew.CountToChangeFFC.Value)
            mmrOld.CountToChangeFFC.Value = mmrNew.CountToChangeFFC.Value
        End If

        '--- Other ---
        If mmrOld.GoldenResizeCount.Value <> mmrNew.GoldenResizeCount.Value Then
            dlm.WriteLog("[MuraModelRecipe]GoldenResizeCount: " & mmrOld.GoldenResizeCount.Value & " --> " & mmrNew.GoldenResizeCount.Value)
            mmrOld.GoldenResizeCount.Value = mmrNew.GoldenResizeCount.Value
        End If
        If mmrOld.PitchX.Value <> mmrNew.PitchX.Value Then
            dlm.WriteLog("[MuraModelRecipe]PitchX: " & mmrOld.PitchX.Value & " --> " & mmrNew.PitchX.Value)
            mmrOld.PitchX.Value = mmrNew.PitchX.Value
        End If
        If mmrOld.PitchY.Value <> mmrNew.PitchY.Value Then
            dlm.WriteLog("[MuraModelRecipe]PitchY: " & mmrOld.PitchY.Value & " --> " & mmrNew.PitchY.Value)
            mmrOld.PitchX.Value = mmrNew.PitchY.Value
        End If

        boundaryOld = mmrOld.Band
        boundaryNew = mmrNew.Band
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("< Band >: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("< Band.BottomY >: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("< Band.LeftX >: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("< Band.RightX >: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
        End If

    End Sub

    Private Sub Compare(ByVal mprOld As ClsMuraPatternRecipe, ByVal mprNew As ClsMuraPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim boundaryOld As ClsParameterBoundary
        Dim boundaryNew As ClsParameterBoundary

        dlm.WriteLog("********************[MuraPatternRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        boundaryOld = mprOld.Rim
        boundaryNew = mprNew.Rim
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("< Rim.TopY >: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("< Rim.BottomY >: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("< Rim.LeftX >: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("< Rim.RightX >: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
        End If

        If mprOld.UseFFC.Value <> mprNew.UseFFC.Value Then
            dlm.WriteLog("< UseFFC >: " & mprOld.UseFFC.Value & " --> " & mprNew.UseFFC.Value)
        End If
        If mprOld.AlignValue.Value <> mprNew.AlignValue.Value Then
            dlm.WriteLog("< AlignValue >: " & mprOld.AlignValue.Value & " --> " & mprNew.AlignValue.Value)
        End If
        If mprOld.AlignPercentage.Value <> mprNew.AlignPercentage.Value Then
            dlm.WriteLog("AlignPercentage >: " & mprOld.AlignPercentage.Value & " --> " & mprNew.AlignPercentage.Value)
        End If

        If mprOld.BlobMura_GlobleSmooth.Value <> mprNew.BlobMura_GlobleSmooth.Value Then
            dlm.WriteLog("< BlobMura_GlobleSmooth >: " & mprOld.BlobMura_GlobleSmooth.Value & " --> " & mprNew.BlobMura_GlobleSmooth.Value)
        End If
        If mprOld.SmoothCount.Value <> mprNew.SmoothCount.Value Then
            dlm.WriteLog("< SmoothCount >: " & mprOld.SmoothCount.Value & " --> " & mprNew.SmoothCount.Value)
        End If

        If mprOld.WhiteBlobMura_BinarizeHeight.Value <> mprNew.WhiteBlobMura_BinarizeHeight.Value Then
            dlm.WriteLog("< WhiteBlobMura_BinarizeHeight >: " & mprOld.WhiteBlobMura_BinarizeHeight.Value & " --> " & mprNew.WhiteBlobMura_BinarizeHeight.Value)
        End If
        If mprOld.WhiteMacroMura_Threshold.Value <> mprNew.WhiteMacroMura_Threshold.Value Then
            dlm.WriteLog("< WhiteMacroMura_Threshold >: " & mprOld.WhiteMacroMura_Threshold.Value & " --> " & mprNew.WhiteMacroMura_Threshold.Value)
        End If
        If mprOld.BlackBlobMura_BinarizeHeight.Value <> mprNew.BlackBlobMura_BinarizeHeight.Value Then
            dlm.WriteLog("< BlackBlobMura_BinarizeHeight >: " & mprOld.BlackBlobMura_BinarizeHeight.Value & " --> " & mprNew.BlackBlobMura_BinarizeHeight.Value)
        End If
        If mprOld.BlackMacroMura_Threshold.Value <> mprNew.BlackMacroMura_Threshold.Value Then
            dlm.WriteLog("< BlackMacroMura_Threshold >: " & mprOld.BlackMacroMura_Threshold.Value & " --> " & mprNew.BlackMacroMura_Threshold.Value)
        End If


        If mprOld.UseRound.Value <> mprNew.UseRound.Value Then
            dlm.WriteLog("< UseRound >: " & mprOld.UseRound.Value & " --> " & mprNew.UseRound.Value)
        End If
        If mprOld.WhiteMura_ThresholdHeight.Value <> mprNew.WhiteMura_ThresholdHeight.Value Then
            dlm.WriteLog("< WhiteMura_ThresholdHeight >: " & mprOld.WhiteMura_ThresholdHeight.Value & " --> " & mprNew.WhiteMura_ThresholdHeight.Value)
        End If
        If mprOld.WhiteMura_ThresholdLow.Value <> mprNew.WhiteMura_ThresholdLow.Value Then
            dlm.WriteLog("< WhiteMura_ThresholdLow >: " & mprOld.WhiteMura_ThresholdLow.Value & " --> " & mprNew.WhiteMura_ThresholdLow.Value)
        End If
        If mprOld.BlackMura_ThresholdHeight.Value <> mprNew.BlackMura_ThresholdHeight.Value Then
            dlm.WriteLog("< BlackMura_ThresholdHeight >: " & mprOld.BlackMura_ThresholdHeight.Value & " --> " & mprNew.BlackMura_ThresholdHeight.Value)
        End If
        If mprOld.BlackMura_ThresholdLow.Value <> mprNew.BlackMura_ThresholdLow.Value Then
            dlm.WriteLog("< BlackMura_ThresholdLow >: " & mprOld.BlackMura_ThresholdLow.Value & " --> " & mprNew.BlackMura_ThresholdLow.Value)
        End If

        If mprOld.UseBand.Value <> mprNew.UseBand.Value Then
            dlm.WriteLog("UseBand >: " & mprOld.UseBand.Value & " --> " & mprNew.UseBand.Value)
        End If
        If mprOld.BandMura_ResizeCount.Value <> mprNew.BandMura_ResizeCount.Value Then
            dlm.WriteLog("< BandMura_ResizeCount >: " & mprOld.BandMura_ResizeCount.Value & " --> " & mprNew.BandMura_ResizeCount.Value)
        End If
        If mprOld.BandMura_SmoothCount.Value <> mprNew.BandMura_SmoothCount.Value Then
            dlm.WriteLog("< BandMura_SmoothCount >: " & mprOld.BandMura_SmoothCount.Value & " --> " & mprNew.BandMura_SmoothCount.Value)
        End If
        If mprOld.WhiteHBand_Threshold.Value <> mprNew.WhiteHBand_Threshold.Value Then
            dlm.WriteLog("< WhiteHBand_Threshold >: " & mprOld.WhiteHBand_Threshold.Value & " --> " & mprNew.WhiteHBand_Threshold.Value)
        End If
        If mprOld.BlackHBand_Threshold.Value <> mprNew.BlackHBand_Threshold.Value Then
            dlm.WriteLog("< BlackHBand_Threshold >: " & mprOld.BlackHBand_Threshold.Value & " --> " & mprNew.BlackHBand_Threshold.Value)
        End If
        If mprOld.WhiteVBand_Threshold.Value <> mprNew.WhiteVBand_Threshold.Value Then
            dlm.WriteLog("< WhiteVBand_Threshold >: " & mprOld.WhiteVBand_Threshold.Value & " --> " & mprNew.WhiteVBand_Threshold.Value)
        End If
        If mprOld.BlackVBand_Threshold.Value <> mprNew.BlackVBand_Threshold.Value Then
            dlm.WriteLog("< BlackVBand_Threshold >: " & mprOld.BlackVBand_Threshold.Value & " --> " & mprNew.BlackVBand_Threshold.Value)
        End If

        '--- WhiteBlobMura ---
        If mprOld.WhiteBlobMura_AreaMin.Value <> mprNew.WhiteBlobMura_AreaMin.Value Then
            dlm.WriteLog("< WhiteBlobMura_AreaMin >: " & mprOld.WhiteBlobMura_AreaMin.Value & " --> " & mprNew.WhiteBlobMura_AreaMin.Value)
        End If
        If mprOld.WhiteBlobMura_AreaMax.Value <> mprNew.WhiteBlobMura_AreaMax.Value Then
            dlm.WriteLog("< WhiteBlobMura_AreaMax >: " & mprOld.WhiteBlobMura_AreaMax.Value & " --> " & mprNew.WhiteBlobMura_AreaMax.Value)
        End If
        If mprOld.WhiteBlobMura_JNDMin.Value <> mprNew.WhiteBlobMura_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteBlobMura_JNDMin >: " & mprOld.WhiteBlobMura_JNDMin.Value & " --> " & mprNew.WhiteBlobMura_JNDMin.Value)
        End If
        If mprOld.WhiteBlobMura_JNDMax.Value <> mprNew.WhiteBlobMura_JNDMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteBlobMura_JNDMax >: " & mprOld.WhiteBlobMura_JNDMax.Value & " --> " & mprNew.WhiteBlobMura_JNDMax.Value)
        End If
        If mprOld.WhiteBlobMura_ElongationMin.Value <> mprNew.WhiteBlobMura_ElongationMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteBlobMura_ElongationMin >: " & mprOld.WhiteBlobMura_ElongationMin.Value & " --> " & mprNew.WhiteBlobMura_ElongationMin.Value)
        End If
        If mprOld.WhiteBlobMura_ElongationMax.Value <> mprNew.WhiteBlobMura_ElongationMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteBlobMura_ElongationMax >: " & mprOld.WhiteBlobMura_ElongationMax.Value & " --> " & mprNew.WhiteBlobMura_ElongationMax.Value)
        End If

        '--- WhiteAGM ---
        If mprOld.WhiteAGM_AreaMin.Value <> mprNew.WhiteAGM_AreaMin.Value Then
            dlm.WriteLog("< WhiteAGM_AreaMin >: " & mprOld.WhiteAGM_AreaMin.Value & " --> " & mprNew.WhiteAGM_AreaMin.Value)
        End If
        If mprOld.WhiteAGM_AreaMax.Value <> mprNew.WhiteAGM_AreaMax.Value Then
            dlm.WriteLog("< WhiteAGM_AreaMax >: " & mprOld.WhiteAGM_AreaMax.Value & " --> " & mprNew.WhiteAGM_AreaMax.Value)
        End If
        If mprOld.WhiteAGM_JNDMin.Value <> mprNew.WhiteAGM_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteAGM_JNDMin >: " & mprOld.WhiteAGM_JNDMin.Value & " --> " & mprNew.WhiteAGM_JNDMin.Value)
        End If
        If mprOld.WhiteAGM_JNDMax.Value <> mprNew.WhiteAGM_JNDMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteAGM_JNDMax >: " & mprOld.WhiteAGM_JNDMax.Value & " --> " & mprNew.WhiteAGM_JNDMax.Value)
        End If
        If mprOld.WhiteAGM_ElongationMin.Value <> mprNew.WhiteAGM_ElongationMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteAGM_ElongationMin >: " & mprOld.WhiteAGM_ElongationMin.Value & " --> " & mprNew.WhiteAGM_ElongationMin.Value)
        End If
        If mprOld.WhiteAGM_ElongationMax.Value <> mprNew.WhiteAGM_ElongationMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteAGM_ElongationMax >: " & mprOld.WhiteAGM_ElongationMax.Value & " --> " & mprNew.WhiteAGM_ElongationMax.Value)
        End If

        '--- WhiteMacroMura ---
        If mprOld.WhiteMacroMura_AreaMin.Value <> mprNew.WhiteMacroMura_AreaMin.Value Then
            dlm.WriteLog("< WhiteMacroMura_AreaMin >: " & mprOld.WhiteMacroMura_AreaMin.Value & " --> " & mprNew.WhiteMacroMura_AreaMin.Value)
        End If
        If mprOld.WhiteMacroMura_AreaMax.Value <> mprNew.WhiteMacroMura_AreaMax.Value Then
            dlm.WriteLog("< WhiteMacroMura_AreaMax >: " & mprOld.WhiteMacroMura_AreaMax.Value & " --> " & mprNew.WhiteMacroMura_AreaMax.Value)
        End If
        If mprOld.WhiteMacroMura_JND.Value <> mprNew.WhiteMacroMura_JND.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteMacroMura_JND >: " & mprOld.WhiteMacroMura_JND.Value & " --> " & mprNew.WhiteMacroMura_JND.Value)
        End If

        '--- WhiteBandMura ---
        If mprOld.WhiteBandMura_WidthMin.Value <> mprNew.WhiteBandMura_WidthMin.Value Then   '2009/05/14 Rick add
            dlm.WriteLog("< WhiteBandMura_WidthMin >: " & mprOld.WhiteBandMura_WidthMin.Value & " --> " & mprNew.WhiteBandMura_WidthMin.Value)
        End If
        If mprOld.WhiteBandMura_JND.Value <> mprNew.WhiteBandMura_JND.Value Then
            dlm.WriteLog("< WhiteBandMura_JND >: " & mprOld.WhiteBandMura_JND.Value & " --> " & mprNew.WhiteBandMura_JND.Value)
        End If
        If mprOld.WhiteBandMura_SJND.Value <> mprNew.WhiteBandMura_SJND.Value Then
            dlm.WriteLog("< WhiteBandMura_SJND >: " & mprOld.WhiteBandMura_SJND.Value & " --> " & mprNew.WhiteBandMura_SJND.Value)
        End If

        '--- BlackBlobMura ---
        If mprOld.BlackBlobMura_AreaMin.Value <> mprNew.BlackBlobMura_AreaMin.Value Then
            dlm.WriteLog("< BlackBlobMura_AreaMin >: " & mprOld.BlackBlobMura_AreaMin.Value & " --> " & mprNew.BlackBlobMura_AreaMin.Value)
        End If
        If mprOld.BlackBlobMura_AreaMax.Value <> mprNew.BlackBlobMura_AreaMax.Value Then
            dlm.WriteLog("< BlackBlobMura_AreaMax >: " & mprOld.BlackBlobMura_AreaMax.Value & " --> " & mprNew.BlackBlobMura_AreaMax.Value)
        End If
        If mprOld.BlackBlobMura_JNDMin.Value <> mprNew.BlackBlobMura_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackBlobMura_JNDMin >: " & mprOld.BlackBlobMura_JNDMin.Value & " --> " & mprNew.BlackBlobMura_JNDMin.Value)
        End If
        If mprOld.BlackBlobMura_JNDMax.Value <> mprNew.BlackBlobMura_JNDMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackBlobMura_JNDMax >: " & mprOld.BlackBlobMura_JNDMax.Value & " --> " & mprNew.BlackBlobMura_JNDMax.Value)
        End If
        If mprOld.BlackBlobMura_ElongationMin.Value <> mprNew.BlackBlobMura_ElongationMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackBlobMura_ElongationMin >: " & mprOld.BlackBlobMura_ElongationMin.Value & " --> " & mprNew.BlackBlobMura_ElongationMin.Value)
        End If
        If mprOld.BlackBlobMura_ElongationMax.Value <> mprNew.BlackBlobMura_ElongationMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackBlobMura_ElongationMax >: " & mprOld.BlackBlobMura_ElongationMax.Value & " --> " & mprNew.BlackBlobMura_ElongationMax.Value)
        End If

        '--- BlackAGM ---
        If mprOld.BlackAGM_AreaMin.Value <> mprNew.BlackAGM_AreaMin.Value Then
            dlm.WriteLog("< BlackAGM_AreaMin >: " & mprOld.BlackAGM_AreaMin.Value & " --> " & mprNew.BlackAGM_AreaMin.Value)
        End If
        If mprOld.BlackAGM_AreaMax.Value <> mprNew.BlackAGM_AreaMax.Value Then
            dlm.WriteLog("< BlackAGM_AreaMax >: " & mprOld.BlackAGM_AreaMax.Value & " --> " & mprNew.BlackAGM_AreaMax.Value)
        End If
        If mprOld.BlackAGM_JNDMin.Value <> mprNew.BlackAGM_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackAGM_JNDMin >: " & mprOld.BlackAGM_JNDMin.Value & " --> " & mprNew.BlackAGM_JNDMin.Value)
        End If
        If mprOld.BlackAGM_JNDMax.Value <> mprNew.BlackAGM_JNDMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackAGM_JNDMax >: " & mprOld.BlackAGM_JNDMax.Value & " --> " & mprNew.BlackAGM_JNDMax.Value)
        End If
        If mprOld.BlackAGM_ElongationMin.Value <> mprNew.BlackAGM_ElongationMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackAGM_ElongationMin >: " & mprOld.BlackAGM_ElongationMin.Value & " --> " & mprNew.BlackAGM_ElongationMin.Value)
        End If
        If mprOld.BlackAGM_ElongationMax.Value <> mprNew.BlackAGM_ElongationMax.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackAGM_ElongationMax >: " & mprOld.BlackAGM_ElongationMax.Value & " --> " & mprNew.BlackAGM_ElongationMax.Value)
        End If

        '--- BlackMacroMura ---
        If mprOld.BlackMacroMura_AreaMin.Value <> mprNew.BlackMacroMura_AreaMin.Value Then
            dlm.WriteLog("< BlackMacroMura_AreaMin >: " & mprOld.BlackMacroMura_AreaMin.Value & " --> " & mprNew.BlackMacroMura_AreaMin.Value)
        End If
        If mprOld.BlackMacroMura_AreaMax.Value <> mprNew.BlackMacroMura_AreaMax.Value Then
            dlm.WriteLog("< BlackMacroMura_AreaMax >: " & mprOld.BlackMacroMura_AreaMax.Value & " --> " & mprNew.BlackMacroMura_AreaMax.Value)
        End If
        If mprOld.BlackMacroMura_JND.Value <> mprNew.BlackMacroMura_JND.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackMacroMura_JND >: " & mprOld.BlackMacroMura_JND.Value & " --> " & mprNew.BlackMacroMura_JND.Value)
        End If

        '--- BlackBandMura ---
        If mprOld.BlackBandMura_WidthMin.Value <> mprNew.BlackBandMura_WidthMin.Value Then   '2009/05/14 Rick add
            dlm.WriteLog("< BlackBandMura_WidthMin >: " & mprOld.BlackBandMura_WidthMin.Value & " --> " & mprNew.BlackBandMura_WidthMin.Value)
        End If
        If mprOld.BlackBandMura_JND.Value <> mprNew.BlackBandMura_JND.Value Then
            dlm.WriteLog("< BlackBandMura_JND >: " & mprOld.BlackBandMura_JND.Value & " --> " & mprNew.BlackBandMura_JND.Value)
        End If
        If mprOld.BlackBandMura_SJND.Value <> mprNew.BlackBandMura_SJND.Value Then
            dlm.WriteLog("< BlackBandMura_SJND >: " & mprOld.BlackBandMura_SJND.Value & " --> " & mprNew.BlackBandMura_SJND.Value)
        End If

        If mprOld.SaveOriginal.Value <> mprNew.SaveOriginal.Value Then
            dlm.WriteLog("< SaveOriginal >: " & mprOld.SaveOriginal.Value & " --> " & mprNew.SaveOriginal.Value)
        End If
        If mprOld.SaveSmooth.Value <> mprNew.SaveSmooth.Value Then
            dlm.WriteLog("< SaveSmooth >: " & mprOld.SaveSmooth.Value & " --> " & mprNew.SaveSmooth.Value)
        End If

        If mprOld.SaveBlackBlob.Value <> mprNew.SaveBlackBlob.Value Then
            dlm.WriteLog("< SaveBlackBlob >: " & mprOld.SaveBlackBlob.Value & " --> " & mprNew.SaveBlackBlob.Value)
        End If
        If mprOld.SaveBlackThreshold.Value <> mprNew.SaveBlackThreshold.Value Then
            dlm.WriteLog("< SaveBlackThreshold >: " & mprOld.SaveBlackThreshold.Value & " --> " & mprNew.SaveBlackThreshold.Value)
        End If
        If mprOld.SaveBlackReconstructArea.Value <> mprNew.SaveBlackReconstructArea.Value Then
            dlm.WriteLog("< SaveBlackReconstructArea >: " & mprOld.SaveBlackReconstructArea.Value & " --> " & mprNew.SaveBlackReconstructArea.Value)
        End If
        If mprOld.SaveBlackReconstructRim.Value <> mprNew.SaveBlackReconstructRim.Value Then
            dlm.WriteLog("< SaveBlackReconstructRim >: " & mprOld.SaveBlackReconstructRim.Value & " --> " & mprNew.SaveBlackReconstructRim.Value)
        End If

        If mprOld.SaveWhiteBlob.Value <> mprNew.SaveWhiteBlob.Value Then
            dlm.WriteLog("< SaveWhiteBlob >: " & mprOld.SaveWhiteBlob.Value & " --> " & mprNew.SaveWhiteBlob.Value)
        End If
        If mprOld.SaveWhiteThreshold.Value <> mprNew.SaveWhiteThreshold.Value Then
            dlm.WriteLog("< SaveWhiteThreshold >: " & mprOld.SaveWhiteThreshold.Value & " --> " & mprNew.SaveWhiteThreshold.Value)
        End If
        If mprOld.SaveWhiteReconstructArea.Value <> mprNew.SaveWhiteReconstructArea.Value Then
            dlm.WriteLog("< SaveWhiteReconstructArea >: " & mprOld.SaveWhiteReconstructArea.Value & " --> " & mprNew.SaveWhiteReconstructArea.Value)
        End If
        If mprOld.SaveWhiteReconstructRim.Value <> mprNew.SaveWhiteReconstructRim.Value Then
            dlm.WriteLog("< SaveWhiteReconstructRim >: " & mprOld.SaveWhiteReconstructRim.Value & " --> " & mprNew.SaveWhiteReconstructRim.Value)
        End If

        If mprOld.SaveVProject.Value <> mprNew.SaveVProject.Value Then
            dlm.WriteLog("< SaveVProject >: " & mprOld.SaveVProject.Value & " --> " & mprNew.SaveVProject.Value)
        End If
        If mprOld.SaveHProject.Value <> mprNew.SaveHProject.Value Then
            dlm.WriteLog("< SaveHProject >: " & mprOld.SaveHProject.Value & " --> " & mprNew.SaveHProject.Value)
        End If

        If mprOld.SaveVBand.Value <> mprNew.SaveVBand.Value Then
            dlm.WriteLog("< SaveVBand >: " & mprOld.SaveVBand.Value & " --> " & mprNew.SaveVBand.Value)
        End If
        If mprOld.SaveHBand.Value <> mprNew.SaveHBand.Value Then
            dlm.WriteLog("< SaveHBand >: " & mprOld.SaveHBand.Value & " --> " & mprNew.SaveHBand.Value)
        End If

        If mprOld.PatternName.Value <> mprNew.PatternName.Value Then
            dlm.WriteLog("< PatternName >: " & mprOld.PatternName.Value & " --> " & mprNew.PatternName.Value)
        End If
        If mprOld.ExposureTime.Value <> mprNew.ExposureTime.Value Then
            dlm.WriteLog("< ExposureTime >: " & mprOld.ExposureTime.Value & " --> " & mprNew.ExposureTime.Value)
        End If

    End Sub

    Private Sub Compare(ByVal mpraOldOrder As ClsMuraPatternRecipeArray, ByVal mpraOld As ClsMuraPatternRecipeArray, ByVal mpraNew As ClsMuraPatternRecipeArray, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim i As Integer
        Dim j As Integer
        Dim mpp As ClsMuraPatternRecipe
        Dim mppOldOrder As ClsMuraPatternRecipe
        Dim mppOld As ClsMuraPatternRecipe
        Dim mppNew As ClsMuraPatternRecipe
        Dim bool As Boolean
        Dim bools(mpraNew.Count - 1) As Boolean
        For j = 0 To mpraNew.Count - 1
            bools(j) = True
        Next
        dlm.WriteLog("**********************[MuraPattern]**************************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)
        For i = 0 To mpraOldOrder.Count - 1
            mppOldOrder = mpraOldOrder.Item(i)
            mppOld = mpraOld.Item(i)
            bool = True

            For j = 0 To mpraNew.Count - 1
                mppNew = mpraNew.Item(j)
                If mppOldOrder Is mppNew Then
                    If i <> j Then
                        dlm.WriteLog("[Mura]PatternReorder: " & i + 1 & " --> " & j + 1)
                    Else
                        dlm.WriteLog("[Mura]Pattern: " & i + 1)
                    End If
                    Me.Compare(mppOld, mppNew, dlm)
                    bool = False
                    bools(j) = False
                    Exit For
                End If
            Next
            If bool Then
                dlm.WriteLog("[Mura]PatternRemove: " & i + 1)
            End If
        Next

        For j = 0 To mpraNew.Count - 1
            If bools(j) Then
                dlm.WriteLog("[Mura]PatternAdd: " & j + 1)
            End If
        Next
        mpraOldOrder.Clear()
        mpraOld.Clear()
        For i = 0 To mpraNew.Count - 1
            mpp = mpraNew.Item(i)
            mpraOldOrder.Add(mpp)
            mpraOld.Add(New ClsMuraPatternRecipe(mpp))
        Next
    End Sub

#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Save.Enabled = En
        Button_Close.Enabled = En
        Button_LoadImage.Enabled = En
        If Me.m_IPBootConfig.Grid_Calibration_Enable.Value Then
            Button_Calculate_Grid_Calibration.Enabled = En
            Button_Correct_Distortion.Enabled = En
        End If
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Me.SavePath ---"
    Private Function SavePath(ByRef strPath As String)

        strPath = Replace(strPath, "\", "\\")
        If (strPath.Contains("\\\\")) Then
            strPath = Replace(strPath, "\\\\", "\\")
        End If
        Return strPath
    End Function
#End Region

#Region "--- Repair_PatternName ---"
    Private Sub Repair_PatternName(ByRef strPatternName As String)
        Dim strFirst As String
        Dim strSecond As String
        strFirst = Mid(strPatternName, 1, 1)
        strSecond = Mid(strPatternName, 2, 1)

        If strFirst <> "F" And strSecond <> "_" Then
            If strFirst <> "_" Then strPatternName = "_" & strPatternName
            If Mid(strPatternName, 1, 1) <> "F" Then strPatternName = "F" & strPatternName
            Exit Sub
        Else
            Exit Sub
        End If

    End Sub
#End Region

#Region "--- Load RotateCalImg ---"
    Private Sub Load_RotateCalImg()
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FileName As String = ""
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---   
            FileName = Me.m_IPBootConfig.RamDiskPath.Value & "\Img_AfterRotate.tif"
            Me.RepairPath_2(FileName)
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            image = Me.m_FuncProcess.Img_Original_NonPage

            '[AreaGrabber] Load Image --- (For Display)
            '[1] image ---
            MbufDiskInquire(FileName, M_SIZE_X, SizeX)
            MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
            MbufDiskInquire(FileName, M_TYPE, Type)
            If image <> M_NULL Then
                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(image)
                    image = M_NULL
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.m_FuncProcess.Img_Original_NonPage)

            '[2] Img_16U_Grab ---
            If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                    Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

            Me.m_Form.StatusBarStatus(Path.GetFileName(FileName))
            'If Me.m_Form.ComboBox_CCD.Text <> "" Then
            '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
            '    If Not (iCheckLoadImage > 0) Then
            '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
            '    End If
            'End If

            '----------------------------------------------------------------------------------------------
            ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_IMAGE"
                TimeOut = 100000 '100 secs

                FilePath = FileName
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                    If SubSystemResult.Responses(0).Param1 = "1" Then
                        Me.m_Form.CheckBox_IsAligned.Checked = True
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                        strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                        RepairPath_2(strPath)
                        MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                    Else
                        Me.m_Form.CheckBox_IsAligned.Checked = False
                    End If
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Button_Enable(True)
                    Exit Sub
                End If

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    If image <> M_NULL Then
                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)

                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                            MbufFree(imageBuffer)
                            imageBuffer = M_NULL
                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufCopy(image, imageBuffer)

                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                        Me.m_Form.ResetScrollBar()
                    End If
                Else
                    Me.m_Form.CurrentIndex0 = 2
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 2
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If (Me.m_IPBootConfig.MuraUI.Value) Then
                image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image2 ---
                MbufDiskInquire(FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(FileName, M_TYPE, Type)
                If image2 <> M_NULL Then
                    If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image2)
                        image2 = M_NULL
                        image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                '[2] Img_16U_Grab ---
                If image2 <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

                If Not Response_OK Then
                    Button_Enable(True)
                    Exit Sub
                End If

                '--- Resize Original image ---
                If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 100000 '100 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) AndAlso FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                                Else
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                                End If

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            Me.m_Form.ImageUpdate()
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If
            End If

            Me.CheckBox_ShowBoundary.Enabled = True
            Me.GroupBox_BoundaryModify.Enabled = True


            If FileName <> "" Then
                If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                        Me.m_FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
                Me.CheckBox_ShowBoundary.Enabled = True
                Me.GroupBox_BoundaryModify.Enabled = True
            End If
            Call Me.m_Form.ImageZoomAll()
            System.IO.File.Delete(FileName)
            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Load_GridCalImg ---"
    Private Sub Load_GridCalImg()
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FileName As String = ""
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---   
            FileName = Me.m_IPBootConfig.RamDiskPath.Value & "\Img_Func_Calibrated_NonPage.tif"
            Me.RepairPath_2(FileName)
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            image = Me.m_FuncProcess.Img_Original_NonPage

            '[AreaGrabber] Load Image --- (For Display)
            '[1] image ---
            MbufDiskInquire(FileName, M_SIZE_X, SizeX)
            MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
            MbufDiskInquire(FileName, M_TYPE, Type)
            If image <> M_NULL Then
                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(image)
                    image = M_NULL
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.m_FuncProcess.Img_Original_NonPage)

            '[2] Img_16U_Grab ---
            If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                    Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

            Me.m_Form.StatusBarStatus(Path.GetFileName(FileName))
            'If Me.m_Form.ComboBox_CCD.Text <> "" Then
            '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
            '    If Not (iCheckLoadImage > 0) Then
            '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
            '    End If
            'End If

            '----------------------------------------------------------------------------------------------
            ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_IMAGE"
                TimeOut = 100000 '100 secs

                FilePath = FileName
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                    If SubSystemResult.Responses(0).Param1 = "1" Then
                        Me.m_Form.CheckBox_IsAligned.Checked = True
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                        strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                        RepairPath_2(strPath)
                        MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                    Else
                        Me.m_Form.CheckBox_IsAligned.Checked = False
                    End If
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Button_Enable(True)
                    Exit Sub
                End If

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    If image <> M_NULL Then
                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)

                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                            MbufFree(imageBuffer)
                            imageBuffer = M_NULL
                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufCopy(image, imageBuffer)

                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                        Me.m_Form.ResetScrollBar()
                    End If
                Else
                    Me.m_Form.CurrentIndex0 = 2
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 2
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If (Me.m_IPBootConfig.MuraUI.Value) Then
                image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image2 ---
                MbufDiskInquire(FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(FileName, M_TYPE, Type)
                If image2 <> M_NULL Then
                    If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image2)
                        image2 = M_NULL
                        image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                '[2] Img_16U_Grab ---
                If image2 <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

                If Not Response_OK Then
                    Button_Enable(True)
                    Exit Sub
                End If

                '--- Resize Original image ---
                If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 100000 '100 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) AndAlso FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                                Else
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                                End If

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            Me.m_Form.ImageUpdate()
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If
            End If

            Me.CheckBox_ShowBoundary.Enabled = True
            Me.GroupBox_BoundaryModify.Enabled = True


            If FileName <> "" Then
                If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                        Me.m_FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
                Me.CheckBox_ShowBoundary.Enabled = True
                Me.GroupBox_BoundaryModify.Enabled = True
            End If
            Call Me.m_Form.ImageZoomAll()
            System.IO.File.Delete(FileName)
            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "---SaveTempBoundary---"
    Private Sub SaveTempBoundary(ByVal fileName As String, ByVal pb As ClsParameterBoundary)
        Dim sw As StreamWriter
        sw = File.CreateText(fileName)

        Try
            sw.WriteLine("Top" & vbTab & "Buttom" & vbTab & "Left" & vbTab & "Right")
            sw.WriteLine(pb.TopY & "," & pb.BottomY & "," & pb.LeftX & "," & pb.RightX)

        Catch ex As Exception
            Throw New Exception("[Dialig_Align.SaveTempBoundary]SaveTempBoundary Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        Finally
            sw.Close()
        End Try

    End Sub
#End Region

#Region "--- Change Language ---"

    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_Alignment.Text = res.GetString("Button_Alignment.Text")
                CheckBox_PanelMirror.Text = res.GetString("CheckBox_PanelMirror.Text")
                CheckBox_PanelRotate.Text = res.GetString("CheckBox_PanelRotate.Text")
                CheckBox_ShowBoundary.Text = res.GetString("CheckBox_ShowBoundary.Text")
                CheckBox_ShowTable.Text = res.GetString("CheckBox_ShowTable.Text")
                GroupBox_Boundary.Text = res.GetString("GroupBox_Boundary.Text")
                GroupBox_BoundaryModify.Text = res.GetString("GroupBox_BoundaryModify.Text")
                GroupBox_Local.Text = res.GetString("GroupBox_Local.Text")
                GroupBox_MT.Text = res.GetString("GroupBox_MT.Text")
                GroupBox_TableModify.Text = res.GetString("GroupBox_TableModify.Text")
                Label_BoundaryBottom.Text = res.GetString("Label_BoundaryBottom.Text")
                Label_BoundaryLeft.Text = res.GetString("Label_BoundaryLeft.Text")
                Label_BoundaryRight.Text = res.GetString("Label_BoundaryRight.Text")
                Label_BoundaryTop.Text = res.GetString("Label_BoundaryTop.Text")
                Label_LocalBottom.Text = res.GetString("Label_LocalBottom.Text")
                Label_LocalLeft.Text = res.GetString("Label_LocalLeft.Text")
                Label_LocalRight.Text = res.GetString("Label_LocalRight.Text")
                Label_LocalTop.Text = res.GetString("Label_LocalTop.Text")
                Label_TableBottom.Text = res.GetString("Label_TableBottom.Text")
                Label_TableLeft.Text = res.GetString("Label_TableLeft.Text")
                Label_TableRight.Text = res.GetString("Label_TableRight.Text")
                Label_TableTop.Text = res.GetString("Label_TableTop.Text")
                RadioButton_BoundaryFinish.Text = res.GetString("RadioButton_BoundaryFinish.Text")
                RadioButton_BoundaryManual.Text = res.GetString("RadioButton_BoundaryManual.Text")
                RadioButton_TableFinish.Text = res.GetString("RadioButton_TableFinish.Text")
                RadioButton_TableManual.Text = res.GetString("RadioButton_TableManual.Text")

        End Select
    End Sub
#End Region


#End Region

#Region "--- Button Event ---"

#Region "--- Button_Cancel_Click ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Save_Click ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim i As Integer
        Dim strs() As String = {""}
        Dim Parameter_Lists As String = ""
        Dim Selected_IP_Index As Integer
        Dim Path As String
        Dim fmr As ClsFuncModelRecipe = Me.m_FuncProcess.FuncModelRecipe
        Dim pb As ClsParameterBoundary

        Try
            '--- Button Control ---   
            Button_Enable(False)
            Me.m_Form.PaintStop = True
            Me.RadioButton_BoundaryFinish.Checked = True

            Me.m_Form.PaintStop = True
            Me.Setting()

            'If Me.m_IPBootConfig.PanelRotate90.Value Then
            '    If Me.CheckBox_PanelMirror.Checked Then
            '        If Me.NumericUpDown_LocalRight.Value > Me.NumericUpDown_LocalLeft.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--左邊界應比右邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '        If Me.NumericUpDown_LocalBottom.Value > Me.NumericUpDown_LocalTop.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--上邊界應比下邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '    ElseIf Me.CheckBox_PanelRotate.Checked Then
            '        If Me.NumericUpDown_LocalLeft.Value > Me.NumericUpDown_LocalRight.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--右邊界應比左邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '        If Me.NumericUpDown_LocalBottom.Value > Me.NumericUpDown_LocalTop.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--上邊界應比下邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '    Else
            '        If Me.NumericUpDown_LocalRight.Value > Me.NumericUpDown_LocalLeft.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--左邊界應比右邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '        If Me.NumericUpDown_LocalBottom.Value > Me.NumericUpDown_LocalTop.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--上邊界應比下邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '    End If
            'Else
            '    If Me.CheckBox_PanelMirror.Checked Then
            '        If Me.NumericUpDown_LocalRight.Value > Me.NumericUpDown_LocalLeft.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--左邊界應比右邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '    ElseIf Me.CheckBox_PanelRotate.Checked Then
            '        If Me.NumericUpDown_LocalRight.Value > Me.NumericUpDown_LocalLeft.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--左邊界應比右邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '        If Me.NumericUpDown_LocalBottom.Value > Me.NumericUpDown_LocalTop.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--上邊界應比下邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '    Else
            '        If Me.NumericUpDown_LocalLeft.Value > Me.NumericUpDown_LocalRight.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--右邊界應比左邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '        If Me.NumericUpDown_LocalTop.Value > Me.NumericUpDown_LocalBottom.Value Then
            '            MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--下邊界應比上邊界大!--" & " << Recipe未儲存!! >>", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Exit Sub
            '        End If
            '    End If
            'End If



            If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("**************************[FuncSave]******************************")
                Me.Compare(Me.m_MainProcess.FuncModelRecipeTemp, Me.m_FuncProcess.FuncModelRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                Me.Compare(Me.m_MainProcess.FuncPatternRecipeArrayOrder, Me.m_MainProcess.FuncPatternRecipeArrayTemp, Me.m_FuncProcess.FuncPatternRecipeArray, Me.m_MainProcess.RecipeDailyLogManager)
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern 存檔]: " & Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\*_" & Me.m_MainProcess.GrabNo)
            End If

            If Me.m_IPBootConfig.MuraUI.Value Then  'Mura邊界同步
                Path = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.TextBox_Product.Text & "\Mura\MuraModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                RepairPath_2(Path)
                MILOperationLib.ClsMuraModelRecipe.WriteXML(Me.m_MuraProcess.MuraModelRecipe, Path)
            End If

            If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("**************************[MuraSave]******************************")
                Me.Compare(Me.m_MainProcess.MuraModelRecipeTemp, Me.m_MuraProcess.MuraModelRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                Me.Compare(Me.m_MainProcess.MuraPatternRecipeArrayOrder, Me.m_MainProcess.MuraPatternRecipeArrayTemp, Me.m_MuraProcess.MuraPatternRecipeArray, Me.m_MainProcess.RecipeDailyLogManager)
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern存檔]: " & Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.TextBox_Product.Text & "\Mura\*_" & Me.m_MainProcess.GrabNo)
            End If
            Me.m_MuraProcess.SaveAllMuraRecipe(Me.m_MainProcess.RECIPE_PATH, Me.m_Form.TextBox_Product.Text, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
            Me.m_MuraProcess.SaveAllFFCImages(Me.m_MainProcess.RECIPE_PATH, Me.m_Form.TextBox_Product.Text, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

            Me.m_FuncProcess.SaveAllFuncRecipe(Me.m_IPBootConfig, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
            Me.m_MainProcess.SaveBoot()

            '========== 單支 IP ====================
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If
            Selected_IP_Index = Me.m_Form.ComboBox_CCD.SelectedIndex

            '----------------------------------------------------------------------------------------------
            ' Dialog_FuncSettingBase Setting   ==> Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING"
                TimeOut = 10000 '10 secs

                'UI Recipe Setting -----------------------------------

                '--- 第一頁 ---
                Parameter_Lists = "BoundaryTop," & Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY & ";" & "BoundaryBottom," & Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY & ";" & "BoundaryLeft," & Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX & ";" & "BoundaryRight," & Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX & ";" & _
                                                    "LeftUpRightDown_Top," & Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(1) & ";" & "LeftUpRightDown_Bottom," & Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(1) & ";" & "LeftUpRightDown_Left," & Me.Label_LeftUp.Text.Trim("(").Trim(")").Split(",")(0) & ";" & "LeftUpRightDown_Right," & Me.Label_RightDown.Text.Trim("(").Trim(")").Split(",")(0) & ";" & _
                                                    "LeftDownRightUp_Top," & Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(1) & ";" & "LeftDownRightUp_Bottom," & Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(1) & ";" & "LeftDownRightUp_Left," & Me.Label_LeftDown.Text.Trim("(").Trim(")").Split(",")(0) & ";" & "LeftDownRightUp_Right," & Me.Label_RightUp.Text.Trim("(").Trim(")").Split(",")(0) & ";" & "SideViewAlign," & Me.CheckBox_SideViewAlign.Checked & ";"
                '--- 第二頁 ---
                Parameter_Lists = Parameter_Lists & "TopAnalysis," & Me.CheckBox_Func_TopAnalysis.Checked & ";" & "BottomAnalysis," & Me.CheckBox_Func_BottomAnalysis.Checked & ";" & "LeftAnalysis," & Me.CheckBox_Func_LeftAnalysis.Checked & ";" & "RightAnalysis," & Me.CheckBox_Func_RightAnalysis.Checked & ";" & "EnhanceEdge," & Me.CheckBox_EnhanceEdge.Checked & ";" & "RotateCal," & Me.CheckBox_RotateCal.Checked & ";" & "RotateTheta," & Me.ComboBox_RotateTheta.Text & ";" & _
                                                    "ShiftOffset_Top," & Me.NumericUpDown_ShiftOffset_Top.Value & ";" & "ShiftOffset_Bottom," & Me.NumericUpDown_ShiftOffset_Bottom.Value & ";" & "ShiftOffset_Left," & Me.NumericUpDown_ShiftOffset_Left.Value & ";" & "ShiftOffset_Right," & Me.NumericUpDown_ShiftOffset_Right.Value & ";"

                '--- 第三頁 ---
                Parameter_Lists = Parameter_Lists & "CalibrationGrid_Column_Num," & Me.NumericUpDown_CalibrationGrid_Column_Num.Value & ";" & "CalibrationGrid_Row_Num," & Me.NumericUpDown_CalibrationGrid_Row_Num.Value & ";" & _
                                                    "CalibrationGrid_X_Tolerance," & Me.NumericUpDown_CalibrationGrid_X_Tolerance.Value & ";" & "CalibrationGrid_Y_Tolerance," & Me.NumericUpDown_CalibrationGrid_Y_Tolerance.Value & ";"

                '--- 第四頁 ---
                Parameter_Lists = Parameter_Lists & "AlignmentShift," & Me.NumericUpDown_AlignmentShift.Value & ";" & "AlignTolerance," & Me.NumericUpDown_AlignTolerance.Value & ";" & "PanelRotate," & Me.CheckBox_PanelRotate.Checked & ";" & "PanelMirror," & Me.CheckBox_PanelMirror.Checked & ";" & _
                                  "AlignType," & fmr.AlignType.Value & ";" & _
                                  "CCDMode," & Me.m_TableProcess.MappingTableRecipe.ctp.CCDMode.Value & ";" & "FilterNum," & Me.m_TableProcess.MappingTableRecipe.ctp.FilterNum.Value & ";" & _
                                  "OffsetTop," & Me.m_FuncProcess.FuncModelRecipe.AlignmentShift_Offset.TopY & ";" & "OffsetBottom," & Me.m_FuncProcess.FuncModelRecipe.AlignmentShift_Offset.BottomY & ";" & "OffsetLeft," & Me.m_FuncProcess.FuncModelRecipe.AlignmentShift_Offset.LeftX & ";" & "OffsetRight," & Me.m_FuncProcess.FuncModelRecipe.AlignmentShift_Offset.RightX

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, Me.ComboBox_MultiAngle.Text, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSettingBase Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraSettingBase Setting   ==> Request_Command = "DIALOG_MURASETTINGBASE_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURASETTINGBASE_SETTING"
                TimeOut = 200000 '200 secs

                'UI Recipe Setting -----------------------------------


                '--- 第一頁 ---
                Parameter_Lists = "TableTop," & CInt(Me.NumericUpDown_TableTop.Value) & ";" & "TableBottom," & CInt(Me.NumericUpDown_TableBottom.Value) & ";" & "TableLeft," & CInt(Me.NumericUpDown_TableLeft.Value) & ";" & "TableRight," & CInt(Me.NumericUpDown_TableRight.Value) & ";" & _
                                  "LocalTop," & Me.NumericUpDown_LocalTop.Value & ";" & "LocalBottom," & Me.NumericUpDown_LocalBottom.Value & ";" & "LocalLeft," & Me.NumericUpDown_LocalLeft.Value & ";" & "LocalRight," & Me.NumericUpDown_LocalRight.Value & ";"

                If Rdb_ScabType_MT.Checked Then
                    Parameter_Lists = Parameter_Lists & "Panel_TransferMode," & "MAPPINGTABLE" & ";"
                Else
                    Parameter_Lists = Parameter_Lists & "Panel_TransferMode," & "LINEAR"
                End If

                '--- 第二頁 ---
                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSettingBase Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Save]Dialog_MuraSettingBase Setting Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '----------------------------------------------------------------------------------------------
            ' Save Boot Config Recipe ==> Request_Command = "SAVE_BOOT" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_BOOT"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Boot Config Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Me.m_ModelChanged Or Me.m_PatternChanged Then

                '========== 多支 IP ====================

                '[SAVE_ALL_FUNC_RECIPE] \ SAVE_ALL_MURA_RECIPE ---
                For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                        '--- 斷線清除 ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = i
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                            MsgBox("IP - " & i & " 連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If

                        If Me.m_IPBootConfig.FuncUI.Value Then
                            '----------------------------------------------------------------------------------------------
                            ' Save All Func Pattern Recipes  ==> Request_Command = "SAVE_ALL_FUNC_RECIPE" (Dispatcher 1)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "SAVE_ALL_FUNC_RECIPE"
                                TimeOut = 100000 '100 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Func Pattern Recipes Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Me.Button_Save.Enabled = True
                                    Button_Enable(True)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                            End Try
                        End If

                        If Me.m_IPBootConfig.MuraUI.Value Then
                            '----------------------------------------------------------------------------------------------
                            ' Save All Mura Pattern Recipes  ==> Request_Command = "SAVE_ALL_MURA_RECIPE" (Dispatcher 1)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "SAVE_ALL_MURA_RECIPE"
                                TimeOut = 100000 '100 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Mura Pattern Recipes Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Me.Button_Save.Enabled = True
                                    Button_Enable(True)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                            End Try
                        End If

                    End If
                Next

                Me.m_Form.ComboBox_CCD.SelectedIndex = Selected_IP_Index
            Else

                If Me.m_IPBootConfig.FuncUI.Value Then
                    '----------------------------------------------------------------------------------------------
                    ' Save All Func Pattern Recipes  ==> Request_Command = "SAVE_ALL_FUNC_RECIPE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SAVE_ALL_FUNC_RECIPE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Func Pattern Recipes Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Save.Enabled = True
                            Button_Enable(True)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If

                If Me.m_IPBootConfig.MuraUI.Value Then
                    '----------------------------------------------------------------------------------------------
                    ' Save All Mura Pattern Recipes  ==> Request_Command = "SAVE_ALL_MURA_RECIPE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SAVE_ALL_MURA_RECIPE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Mura Pattern Recipes Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Save.Enabled = True
                            Button_Enable(True)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If
            End If

            'Update TempBoundary
            Path = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.TextBox_Product.Text & "\Func\TempBoundary.txt"
            RepairPath_2(Path)
            pb = New ClsParameterBoundary
            pb.TopY = Me.NumericUpDown_BoundaryTop.Value
            pb.BottomY = Me.NumericUpDown_BoundaryBottom.Value
            pb.LeftX = Me.NumericUpDown_BoundaryLeft.Value
            pb.RightX = Me.NumericUpDown_BoundaryRight.Value
            SaveTempBoundary(Path, pb)

            Try
                '--- Prepare Command ---
                Request_Command = "UPDATE_TEMPBOUNDARY"
                TimeOut = 100000 '100 secs

                Parameter_Lists = "TopY," & Me.NumericUpDown_BoundaryTop.Value & ";" & "BottomY," & Me.NumericUpDown_BoundaryBottom.Value & ";" & "LeftX," & Me.NumericUpDown_BoundaryLeft.Value & ";" & "RightX," & Me.NumericUpDown_BoundaryRight.Value

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "UPDATE_TEMPBOUNDARY Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_Align.UPDATE_TEMPBOUNDARY]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Save.Enabled = True
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Button Control ---   
            Button_Enable(True)



            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_Save_Click]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.Button_Save_Click]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_LoadImage_Click ---"
    Private Sub Button_LoadImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LoadImage.Click
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim ResizeRatio As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---   
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                image = Me.m_FuncProcess.Img_Original_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_FuncProcess.Img_Original_NonPage)

                '[2] Img_16U_Grab ---
                If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 100000 '100 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        If SubSystemResult.Responses(0).Param1 = "1" Then
                            Me.m_Form.CheckBox_IsAligned.Checked = True
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                            strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                            RepairPath_2(strPath)
                            MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                            ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.RightX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.BottomY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY / ResizeRatio)
                        Else
                            Me.m_Form.CheckBox_IsAligned.Checked = False
                        End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        Button_Enable(True)
                        Exit Sub
                    End If

                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        If image <> M_NULL Then
                            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                            Type = MbufInquire(image, M_TYPE, M_NULL)

                            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                MbufFree(imageBuffer)
                                imageBuffer = M_NULL
                                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                            MbufCopy(image, imageBuffer)

                            MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                            MbufControl(image, M_MODIFIED, M_DEFAULT)
                            MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                            Me.m_Form.ResetScrollBar()
                        End If
                    Else
                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                If (Me.m_IPBootConfig.MuraUI.Value) Then

                    '----------------------------------------------------------------------------------------------
                    ' Transfer Mura Boundary  ==> Request_Command = "Transfer_Mura_Boundary" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "Transfer_Mura_Boundary"
                        TimeOut = 10000 '10 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                    '[AreaGrabber] Load Image --- (For Display)
                    '[1] image2 ---
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                    If image2 <> M_NULL Then
                        If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image2)
                            image2 = M_NULL
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                    '[2] Img_16U_Grab ---
                    If image2 <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                            Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                            Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                    If Not Response_OK Then
                        Button_Enable(True)
                        Exit Sub
                    End If

                    '--- Resize Original image ---
                    If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                        '----------------------------------------------------------------------------------------------
                        ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "RESIZE_ORIGINAL"
                            TimeOut = 100000 '100 secs
                            SaveImage = True

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                Button_Enable(True)
                                Exit Sub
                            End If

                            If SaveImage AndAlso Response_OK Then
                                '[1] Update Processed Image ---
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                                Else
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                                End If

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) AndAlso FileLen(strPath) > 0 Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If image <> M_NULL Then
                                        If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(image)
                                            image = M_NULL
                                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, image)
                                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                        MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                                    Else
                                        MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                                    End If

                                    If System.IO.File.Exists(strPath) = True Then
                                        System.IO.File.Delete(strPath)
                                    End If
                                End If

                                Me.m_Form.ImageUpdate()
                            End If
                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try
                    End If
                End If

                Me.CheckBox_ShowBoundary.Enabled = True
                Me.GroupBox_BoundaryModify.Enabled = True
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                        Me.m_FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
                Me.CheckBox_ShowBoundary.Enabled = True
                Me.GroupBox_BoundaryModify.Enabled = True
            End If
            Call Me.m_Form.ImageZoomAll()

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Button_OK_Click ---"
    Private Sub Button_Alignment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Alignment.Click
        Dim Image As MIL_ID = M_NULL
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim strPath = ""
        Dim Func_Boundary As ClsParameterBoundary
        Dim SizeX, SizeY As Integer
        Dim Align_Type As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Image = MdispInquire(Me.m_Form.AxMDisplay, M_SELECTED, M_NULL)
            If Image = M_NULL Then
                MsgBox("請載入影像")
            Else

                '----------------------------------------------------------------------------------------------
                ' Dialog_FuncSettingBase Setting   ==> Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING"
                    TimeOut = 10000 '10 secs

                    'UI Recipe Setting -----------------------------------
                    If Me.RadioButton_AlignType_Rectangle.Checked Then
                        Align_Type = AlignType.Rectangle
                    ElseIf Me.RadioButton_AlignType_Circle.Checked Then
                        Align_Type = AlignType.Circle
                        Me.CheckBox_RotateCal.Checked = True
                        Me.ComboBox_RotateTheta.SelectedIndex = 4
                    ElseIf Me.RadioButton_AlignType_Dot.Checked Then
                        Align_Type = AlignType.Dot
                    End If
                    '--- 第四頁 ---
                    Parameter_Lists = Parameter_Lists & "AlignmentShift," & Me.NumericUpDown_AlignmentShift.Value & ";" & "PanelRotate," & Me.CheckBox_PanelRotate.Checked & ";" & _
                                       "AlignType," & Align_Type & ";" & _
                                       "CCDMode," & Me.m_TableProcess.MappingTableRecipe.ctp.CCDMode.Value & ";" & "FilterNum," & Me.m_TableProcess.MappingTableRecipe.ctp.FilterNum.Value & ";"
                    'End UI Recipe Setting -----------------------------------

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSettingBase Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------------------------------
                'Calculate Func Original Boundary (Func's ROI)  ==> Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY"
                    TimeOut = 3000000 '3000 secs
                    Parameter_Lists = "0"         '2010/07/26 grant add mappingtable find 3CCD mark (Not Make MappingTable, emblem=>false)
                    Parameter_Lists1 = "Defect"   '2010/07/28 grant add mappingtable to distinguish "Standard_Theta" or "Defect_Theta"
                    Func_Boundary = Me.m_FuncProcess.FuncModelRecipe.Boundary   '2011/03/03 Rick add

                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Parameter_Lists, Parameter_Lists1, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                        If SubSystemResult.Responses(0).Param3 = "False" Then
                            Me.m_Form.OutputInfo(SubSystemResult.Responses(0).Param4)
                            Me.m_Form.StatusBarIPStatus(SubSystemResult.Responses(0).Param4)
                        Else
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK, Align_OK = " & SubSystemResult.Responses(0).Param3 & ", " & SubSystemResult.Responses(0).Param4)
                            '--- 解析 ROI Boundary ----
                            OutputString = SubSystemResult.Responses(0).Param2
                            strs1 = OutputString.Split(";")

                            If (CInt(strs1(0)) = 0 And CInt(strs1(1)) = 0 And CInt(strs1(2)) = 0 And CInt(strs1(3)) = 0) Then
                                Me.m_FuncProcess.FuncModelRecipe.Boundary = Func_Boundary
                            Else
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(strs1(0))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(strs1(1))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(strs1(2))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(strs1(3))
                                Me.m_MainProcess.DOffsetX = CInt(strs1(4))
                                Me.m_MainProcess.DOffsetY = CInt(strs1(5))
                                Me.m_MainProcess.DTheta = (strs1(6))
                                Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointX.Value = CInt(strs1(4))
                                Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointY.Value = CInt(strs1(5))
                            End If

                            '--- Status Message ---
                            Me.m_Form.OutputInfo(SubSystemResult.Responses(0).Param4)

                            '---Load After RotateCal Image---
                            If Me.CheckBox_RotateCal.Checked Then
                                Me.Load_RotateCalImg()
                            End If

                        End If

                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Alignment Fail !(" & SubSystemResult.Responses(0).Param2 & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment_Click]" & SubSystemResult.Responses(0).Param2, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '--- Calculate ROI Image ---
                Try
                    If Me.m_Form.OpenFileDialog.FileName <> "" Then
                        If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                            Try
                                If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                            Catch ex As Exception
                                MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        Else
                            If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                                MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                                Me.m_FuncProcess.Img_OriginalROI = M_NULL
                            End If

                            SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                            Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                        End If
                    End If
                Catch ex As Exception
                    Throw New Exception("Calculate Func ROI Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
                End Try

                '--- 更新路徑 ---
                strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                RepairPath_2(strPath)
                Label_Alignment.Text = "轉角座標：(" & Format(Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointX.Value, "0.0") & "，" & Format(Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointY.Value, "0.0") & ") ;偏移角度：" & Format(Me.m_MainProcess.DTheta, "0.000")
                MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_FuncProcess.FuncModelRecipe, strPath)

                '----------------------------------------------------------------------------------------------
                ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_FUNC_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save MappingTable Recipe  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_MAPPINGTABLE_RECIPE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Transfer ROI to Mura Boundary & Save  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                If Me.m_IPBootConfig.MuraUI.Value Then
                    Try
                        '--- Prepare Command ---
                        Request_Command = "TRANSFER_MURA_BOUNDARY_SAVERECIPE"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True

                            '--- 解析 ROI Boundary ----
                            OutputString = SubSystemResult.Responses(0).Param2
                            strs1 = OutputString.Split(";")
                            If (strs1.Count > 3) Then
                                Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY = CInt(strs1(0))
                                Me.m_MuraProcess.MuraModelRecipe.Boundary.BottomY = CInt(strs1(1))
                                Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX = CInt(strs1(2))
                                Me.m_MuraProcess.MuraModelRecipe.Boundary.RightX = CInt(strs1(3))
                            End If
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                            MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If

            End If

            'Update MuraBoundary
            If Me.CheckBox_Func_TopAnalysis.Checked Then
                Me.NumericUpDown_TableTop.Maximum = Me.NumericUpDown_BoundaryTop.Maximum
                Me.NumericUpDown_TableTop.Value = Me.NumericUpDown_BoundaryTop.Value
            End If

            If Me.CheckBox_Func_BottomAnalysis.Checked Then
                Me.NumericUpDown_TableBottom.Maximum = Me.NumericUpDown_BoundaryBottom.Maximum
                Me.NumericUpDown_TableBottom.Value = Me.NumericUpDown_BoundaryBottom.Value
            End If

            If Me.CheckBox_Func_LeftAnalysis.Checked Then
                Me.NumericUpDown_TableLeft.Maximum = Me.NumericUpDown_BoundaryLeft.Maximum
                Me.NumericUpDown_TableLeft.Value = Me.NumericUpDown_BoundaryLeft.Value
            End If

            If Me.CheckBox_Func_RightAnalysis.Checked Then
                Me.NumericUpDown_TableRight.Maximum = Me.NumericUpDown_BoundaryRight.Maximum
                Me.NumericUpDown_TableRight.Value = Me.NumericUpDown_BoundaryRight.Value
            End If

            Me.TabControl_AlignSetting.SelectedIndex = 0
            Me.CheckBox_ShowBoundary.Checked = False
            Me.CheckBox_ShowBoundary.Checked = True

            '--- Button Control ---   
            Button_Enable(True)

        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Set_SideView_Position_Click ---"
    Private Sub Button_Set_SideView_Position_Click(sender As System.Object, e As System.EventArgs) Handles Button_Set_SideView_Position.Click
        MsgBox("Please Double-Click the Left-Up Corner Position to Left-Down Corner Position in Clockwise form the Image")
        Me.m_Position = 1
    End Sub
#End Region

#Region "--- Button_Calculate_Grid_Calibration_Click ---"
    Private Sub Button_Calculate_Grid_Calibration_Click(sender As System.Object, e As System.EventArgs) Handles Button_Calculate_Grid_Calibration.Click
        Dim Image As MIL_ID = M_NULL
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim MaskFilePath As String = ""

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Button Control ---   
        Button_Enable(False)

        Image = MdispInquire(Me.m_Form.AxMDisplay, M_SELECTED, M_NULL)
        If Image = M_NULL Then
            MsgBox("請載入影像")
        Else
            If Me.CheckBox_UseAlignPattern.Checked Then
                MsgBox("請載入全白影像")
                Me.m_Form.OpenFileDialog.FileName = ""
                Me.m_Form.OpenFileDialog.ShowDialog()
                If Me.m_Form.OpenFileDialog.FileName <> "" Then
                    MaskFilePath = Me.m_Form.OpenFileDialog.FileName
                    MaskFilePath = SavePath(MaskFilePath)
                Else
                    MsgBox("無影像")
                    Exit Sub
                End If
            End If

            '----------------------------------------------------------------------------------------------------------------------
            'Calculate Grid Calibration  ==> Request_Command = "CALCULATE_GRID_CALIBRATION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_GRID_CALIBRATION"
                TimeOut = 100000 '100 secs


                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, m_Grid_Angle, MaskFilePath, Me.ComboBox_MultiAngle.Text, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                    If SubSystemResult.Responses(0).Param1 <> "" Then
                        Me.m_Form.OutputInfo(SubSystemResult.Responses(0).Param1)
                        MessageBox.Show("[Dialog_Align.Button_Calculate_Grid_Calibration_Click]" & SubSystemResult.Responses(0).Param1, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Else
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        '--- Update Processed Image ---
                        Image = Me.m_FuncProcess.Img_Original_NonPage
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_Calibrated_NonPage.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_Calibrated_NonPage.tif"
                            RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Image <> M_NULL Then
                                If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image)
                                    Image = M_NULL
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Image)
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                MbufCopy(Image, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                            Else
                                MbufCopy(Image, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                            End If

                            Me.m_Form.ImageUpdate()

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If

                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Grid Calibration Fail !(" & SubSystemResult.Responses(0).Param2 & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Calculate_Grid_Calibration_Click]" & SubSystemResult.Responses(0).Param2, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                Button_Enable(True)
            Catch ex As Exception
                Button_Enable(True)
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

        End If
    End Sub
#End Region

#Region "--- Button_Calculate_Grid_Angle_Click ---"
    Private Sub Button_Calculate_Grid_Angle_Click(sender As System.Object, e As System.EventArgs) Handles Button_Calculate_Grid_Angle.Click
        MsgBox("[鏡頭影像變形校正]  請雙擊點選2個點，由左而右，先點選左邊第一個點 P1，再點選左邊第二個點 P2 !(請一定放大影像來點選，且選擇沒有變形之中心區域做點選動作)")
        Me.m_Position = 1
        Me.Label_Grid_Calibration_Info.Text = "Info: "
    End Sub
#End Region

#Region "--- Button_Correct_Distortion_Click ---"
    Private Sub Button_Correct_Distortion_Click(sender As System.Object, e As System.EventArgs) Handles Button_Correct_Distortion.Click
        Dim Image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Button Control ---   
        Button_Enable(False)

        Image = MdispInquire(Me.m_Form.AxMDisplay, M_SELECTED, M_NULL)
        If Image = M_NULL Then
            MsgBox("請載入影像")
        Else
            '----------------------------------------------------------------------------------------------------------------------
            'Calculate Correct Image Distortion  ==> Request_Command = "CALCULATE_CORRECT_IMAGE_DISTORTION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_CORRECT_IMAGE_DISTORTION"
                TimeOut = 100000 '100 secs


                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.CheckBox_MultiAngle.Checked, Me.ComboBox_MultiAngle.Text, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                    Me.Load_GridCalImg()

                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Correct Image Distortion Fail !(" & SubSystemResult.Responses(0).Param2 & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Correct_Distortion_Click]" & SubSystemResult.Responses(0).Param2, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                Button_Enable(True)
            Catch ex As Exception
                Button_Enable(True)
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

        End If
    End Sub
#End Region

#Region "--- Button_Quick_Edge_Click ---"
    Private Sub Button_Quick_Edge_Click(sender As System.Object, e As System.EventArgs) Handles Button_Quick_Edge.Click

        Dim Image As MIL_ID = M_NULL
        Dim Boundary As ClsParameterBoundary = New ClsParameterBoundary

        Try

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Image = MdispInquire(Me.m_Form.AxMDisplay, M_SELECTED, M_NULL)
            If Image = M_NULL Then
                MsgBox("請載入影像")
            Else

                '----------------------------------------------------------------------------------------------
                ' Dialog_FuncSettingBase Setting   ==> Request_Command = "QUICK_FIND_EDGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "QUICK_FIND_EDGE"
                    TimeOut = 10000 '10 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True

                        Boundary.TopY = CInt(SubSystemResult.Responses(0).Param1)
                        Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param2)
                        Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param3)
                        Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)

                        If Boundary.CheckBoundary Then
                            Me.NumericUpDown_BoundaryTop.Value = Boundary.TopY
                            Me.NumericUpDown_BoundaryBottom.Value = Boundary.BottomY
                            Me.NumericUpDown_BoundaryLeft.Value = Boundary.LeftX
                            Me.NumericUpDown_BoundaryRight.Value = Boundary.RightX
                        End If

                    Else
                        'Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSettingBase Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_QuickFindEdge]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_QuickFindEdge]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.Button_QuickFindEdge]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Me.CheckBox_ShowBoundary.Checked = False
        Me.CheckBox_ShowBoundary.Checked = True
        Button_Enable(True)

    End Sub
#End Region


#End Region

#Region "--- MouseDown ---"

#Region "--- MouseDownPageROI ---"
    Private Sub MouseDownPageROI(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.RadioButton_BoundaryManual.Checked And Me.CheckBox_ShowBoundary.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

            If ZoomX <= 0 Then ZoomX = 0.1 '2012/09/05 Rick add
            If ZoomY <= 0 Then ZoomY = 0.1 '2012/09/05 Rick add

            p = (Me.NumericUpDown_BoundaryLeft.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = (Me.NumericUpDown_BoundaryRight.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right = True
                End If
            End If
            p = (Me.NumericUpDown_BoundaryTop.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = (Me.NumericUpDown_BoundaryBottom.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Top = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Bottom = True
                End If
            End If
        End If
    End Sub
#End Region

#Region "--- MouseDownPageTransfer ---"
    Private Sub MouseDownPageTransfer(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.RadioButton_TableManual.Checked And Me.CheckBox_ShowTable.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

            If ZoomX <= 0 Then ZoomX = 0.1 '2012/09/05 Rick add
            If ZoomY <= 0 Then ZoomY = 0.1 '2012/09/05 Rick add

            p = (Me.NumericUpDown_TableLeft.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = (Me.NumericUpDown_TableRight.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right = True
                End If
            End If
            p = (Me.NumericUpDown_TableTop.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = (Me.NumericUpDown_TableBottom.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Top = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Bottom = True
                End If
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- MouseMove ---"

#Region "--- MouseMovePageROI ---"
    Private Sub MouseMovePageROI()
        If Me.RadioButton_BoundaryManual.Checked And Me.CheckBox_ShowBoundary.Checked Then
            If Me.m_Left Then
                If Me.m_Form.MouseX >= Me.NumericUpDown_BoundaryRight.Value Then
                    Me.NumericUpDown_BoundaryLeft.Value = Me.NumericUpDown_BoundaryRight.Value - 1
                Else
                    If Me.m_Form.MouseX <= Me.NumericUpDown_BoundaryLeft.Minimum Then
                        Me.NumericUpDown_BoundaryLeft.Value = Me.NumericUpDown_BoundaryLeft.Minimum
                    Else
                        Me.NumericUpDown_BoundaryLeft.Value = Me.m_Form.MouseX
                    End If
                End If
            End If

            If Me.m_Right Then
                If Me.m_Form.MouseX <= Me.NumericUpDown_BoundaryLeft.Value Then
                    Me.NumericUpDown_BoundaryRight.Value = Me.NumericUpDown_BoundaryLeft.Value + 1
                Else
                    If Me.m_Form.MouseX >= Me.NumericUpDown_BoundaryRight.Maximum Then
                        Me.NumericUpDown_BoundaryRight.Value = Me.NumericUpDown_BoundaryRight.Maximum - 1
                    Else
                        Me.NumericUpDown_BoundaryRight.Value = Me.m_Form.MouseX
                    End If
                End If
            End If

            If Me.m_Top Then
                If Me.m_Form.MouseY >= Me.NumericUpDown_BoundaryBottom.Value Then
                    Me.NumericUpDown_BoundaryTop.Value = Me.NumericUpDown_BoundaryBottom.Value - 1
                Else
                    If Me.m_Form.MouseY <= Me.NumericUpDown_BoundaryTop.Minimum Then
                        Me.NumericUpDown_BoundaryTop.Value = Me.NumericUpDown_BoundaryTop.Minimum
                    Else
                        Me.NumericUpDown_BoundaryTop.Value = Me.m_Form.MouseY
                    End If
                End If
            End If

            If Me.m_Bottom Then
                If Me.m_Form.MouseY <= Me.NumericUpDown_BoundaryTop.Value Then
                    Me.NumericUpDown_BoundaryBottom.Value = Me.NumericUpDown_BoundaryTop.Value + 1
                Else
                    If Me.m_Form.MouseY >= Me.NumericUpDown_BoundaryBottom.Maximum Then
                        Me.NumericUpDown_BoundaryBottom.Value = Me.NumericUpDown_BoundaryBottom.Maximum - 1
                    Else
                        Me.NumericUpDown_BoundaryBottom.Value = Me.m_Form.MouseY
                    End If
                End If
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If
    End Sub
#End Region

#Region "--- MouseMovePageTransfer ---"
    Private Sub MouseMovePageTransfer()
        If Me.RadioButton_TableManual.Checked And Me.CheckBox_ShowTable.Checked Then
            If Me.m_Left Then
                If Me.m_Form.MouseX >= Me.NumericUpDown_TableRight.Value Then
                    Me.NumericUpDown_TableLeft.Value = Me.NumericUpDown_TableRight.Value - 1
                Else
                    If Me.m_Form.MouseX <= Me.NumericUpDown_TableLeft.Minimum Then
                        Me.NumericUpDown_TableLeft.Value = Me.NumericUpDown_TableLeft.Minimum
                    Else
                        Me.NumericUpDown_TableLeft.Value = Me.m_Form.MouseX
                    End If
                End If
            End If

            If Me.m_Right Then
                If Me.m_Form.MouseX <= Me.NumericUpDown_TableLeft.Value Then
                    Me.NumericUpDown_TableRight.Value = Me.NumericUpDown_TableLeft.Value + 1
                Else
                    If Me.m_Form.MouseX >= Me.NumericUpDown_BoundaryRight.Maximum Then
                        Me.NumericUpDown_TableRight.Value = Me.NumericUpDown_TableRight.Maximum - 1
                    Else
                        Me.NumericUpDown_TableRight.Value = Me.m_Form.MouseX
                    End If
                End If
            End If

            If Me.m_Top Then
                If Me.m_Form.MouseY >= Me.NumericUpDown_TableBottom.Value Then
                    Me.NumericUpDown_TableTop.Value = Me.NumericUpDown_TableBottom.Value - 1
                Else
                    If Me.m_Form.MouseY <= Me.NumericUpDown_TableTop.Minimum Then
                        Me.NumericUpDown_TableTop.Value = Me.NumericUpDown_TableTop.Minimum
                    Else
                        Me.NumericUpDown_TableTop.Value = Me.m_Form.MouseY
                    End If
                End If
            End If

            If Me.m_Bottom Then
                If Me.m_Form.MouseY <= Me.NumericUpDown_TableTop.Value Then
                    Me.NumericUpDown_TableBottom.Value = Me.NumericUpDown_TableTop.Value + 1
                Else
                    If Me.m_Form.MouseY >= Me.NumericUpDown_TableBottom.Maximum Then
                        Me.NumericUpDown_TableBottom.Value = Me.NumericUpDown_TableBottom.Maximum - 1
                    Else
                        Me.NumericUpDown_TableBottom.Value = Me.m_Form.MouseY
                    End If
                End If
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_ShowBoundary_CheckedChanged ---"
    Private Sub CheckBox_ShowBoundary_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowBoundary.CheckedChanged
        If CheckBox_ShowBoundary.Checked Then
            Me.RadioButton_BoundaryManual.Checked = True
            Me.ReDrawROI()
        Else
            Me.RadioButton_BoundaryFinish.Checked = True
            Me.m_Form.Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
        End If
    End Sub
#End Region

#Region "--- CheckBox_ShowTable_CheckedChanged ---"
    Private Sub CheckBox_ShowTable_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_ShowTable.CheckedChanged
        If CheckBox_ShowTable.Checked Then
            Me.RadioButton_TableManual.Checked = True
            Me.ReDrawTransfer()
        Else
            Me.RadioButton_TableFinish.Checked = True
            Me.m_Form.Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
        End If
    End Sub
#End Region

#Region "--- CheckBox_PanelMirror_CheckedChanged ---"
    Private Sub CheckBox_PanelMirror_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_PanelMirror.CheckedChanged
        If Me.CheckBox_PanelMirror.Checked Then
            If Me.NumericUpDown_LocalRight.Value > Me.NumericUpDown_LocalLeft.Value Then
                MessageBox.Show("請確認" & "--Position Transfer頁面--" & "Linear對應位置" & "--左邊界應比右邊界大!--", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub
#End Region


#End Region

#Region "--- RadioButton_Boundary Event ---"

#Region "--- RadioButton_BoundaryManual_CheckedChanged ---"
    Private Sub RadioButton_BoundaryManual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BoundaryManual.CheckedChanged
        If Me.RadioButton_BoundaryManual.Checked Then
            Me.m_Form.PaintStop = False
            Me.GroupBox_Boundary.Enabled = True
        End If
    End Sub
#End Region

#Region "--- RadioButton_BoundaryFinish_CheckedChanged ---"
    Private Sub RadioButton_BoundaryFinish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BoundaryFinish.CheckedChanged
        Dim boundary As ClsParameterBoundary
        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex <= Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
        End If

        If Me.RadioButton_BoundaryFinish.Checked Then
            Me.GroupBox_Boundary.Enabled = False
            Me.m_Form.PaintStop = True
            boundary = Me.m_FuncProcess.FuncModelRecipe.Boundary
            boundary.TopY = Me.NumericUpDown_BoundaryTop.Value
            boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Value
            boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Value
            boundary.RightX = Me.NumericUpDown_BoundaryRight.Value
        End If
    End Sub
#End Region

#Region "--- RadioButton_TableManual_CheckedChanged ---"
    Private Sub RadioButton_TableManual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_TableManual.CheckedChanged
        If Me.RadioButton_TableManual.Checked Then
            Me.m_Form.PaintStop = False
            Me.GroupBox_Table.Enabled = True
        End If
    End Sub
#End Region

#Region "--- RadioButton_TableFinish_CheckedChanged ---"
    Private Sub RadioButton_TableFinish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_TableFinish.CheckedChanged
        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex <= Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
        End If

        If Me.RadioButton_TableFinish.Checked Then
            Me.GroupBox_Table.Enabled = False
            Me.m_Form.PaintStop = True
        End If
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown_Boundary Event ---"

#Region "--- Boundary ROI ---"
    Private Sub NumericUpDown_BoundaryTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryTop.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryBottom.Minimum = Me.NumericUpDown_BoundaryTop.Value + 1
    End Sub

    Private Sub NumericUpDown_BoundaryBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryBottom.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryTop.Maximum = Me.NumericUpDown_BoundaryBottom.Value - 1
    End Sub

    Private Sub NumericUpDown_BoundaryLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryLeft.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryRight.Minimum = Me.NumericUpDown_BoundaryLeft.Value + 1
    End Sub

    Private Sub NumericUpDown_BoundaryRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryRight.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryLeft.Maximum = Me.NumericUpDown_BoundaryRight.Value - 1
    End Sub
#End Region

#Region "--- Table ROI ---"
    Private Sub NumericUpDown_TableTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_TableTop.ValueChanged
        Me.ReDrawTransfer()
        Me.NumericUpDown_TableBottom.Minimum = Me.NumericUpDown_TableTop.Value + 1
    End Sub

    Private Sub NumericUpDown_TableBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_TableBottom.ValueChanged
        Me.ReDrawTransfer()
        Me.NumericUpDown_TableTop.Maximum = Me.NumericUpDown_TableBottom.Value - 1
    End Sub

    Private Sub NumericUpDown_TableLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_TableLeft.ValueChanged
        Me.ReDrawTransfer()
        Me.NumericUpDown_TableRight.Minimum = Me.NumericUpDown_TableLeft.Value + 1
    End Sub

    Private Sub NumericUpDown_TableRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_TableRight.ValueChanged
        Me.ReDrawTransfer()
        Me.NumericUpDown_TableLeft.Maximum = Me.NumericUpDown_TableRight.Value - 1
    End Sub
#End Region

#End Region

#Region "--- AxMDisplay Event ---"

    Private Sub m_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                If Me.CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
                If Me.CheckBox_ShowTable.Checked Then Me.ReDrawTransfer()
            End If

        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseDownEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then '滑鼠左鍵
            Select Case Me.TabControl_AlignSetting.SelectedIndex
                Case 0
                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                        If Me.RadioButton_BoundaryManual.Checked Then
                            Me.MouseDownPageROI(e)
                        End If
                    End If
                Case 3
                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                        If Me.RadioButton_TableManual.Checked Then
                            Me.MouseDownPageTransfer(e)
                        End If
                    End If
            End Select
        End If
    End Sub

    Private Sub m_AxMDisplay_MouseUpEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_Left = False
            Me.m_Right = False
            Me.m_Top = False
            Me.m_Bottom = False
        End If
    End Sub

    Private Sub m_AxMDisplay_MouseMoveEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        Select Case Me.TabControl_AlignSetting.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    If Me.RadioButton_BoundaryManual.Checked Then
                        Me.MouseMovePageROI()
                    End If
                End If
            Case 3
                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    If Me.RadioButton_TableManual.Checked Then
                        Me.MouseMovePageTransfer()
                    End If
                End If
        End Select
    End Sub

    Private Sub m_Panel_AxMDisplay_DoubleClick(sender As Object, e As System.EventArgs) Handles m_Panel_AxMDisplay.DoubleClick
        Select Case Me.TabControl_AlignSetting.SelectedIndex
            Case 0
                Select Case Me.m_Position
                    Case 1
                        Me.Label_LeftUp.Text = "(" & Me.m_Form.MouseX & " , " & Me.m_Form.MouseY & ")"
                        Me.m_Position = Me.m_Position + 1
                    Case 2
                        Me.Label_RightUp.Text = "(" & Me.m_Form.MouseX & " , " & Me.m_Form.MouseY & ")"
                        Me.m_Position = Me.m_Position + 1
                    Case 3
                        Me.Label_RightDown.Text = "(" & Me.m_Form.MouseX & " , " & Me.m_Form.MouseY & ")"
                        Me.m_Position = Me.m_Position + 1
                    Case 4
                        Me.Label_LeftDown.Text = "(" & Me.m_Form.MouseX & " , " & Me.m_Form.MouseY & ")"
                        Me.m_Position = Me.m_Position + 1
                End Select
            Case 2
                Select Case Me.m_Position
                    Case 1
                        Me.Label_Grid_Calibration_Info.Text += "P1 (" & Me.m_Form.MouseX & "," & Me.m_Form.MouseY & ")"
                        m_Grid_Point.X = Me.m_Form.MouseX
                        m_Grid_Point.Y = Me.m_Form.MouseY
                        Me.m_Position = Me.m_Position + 1
                    Case 2
                        Me.Label_Grid_Calibration_Info.Text += "; P2 (" & Me.m_Form.MouseX & "," & Me.m_Form.MouseY & ")" & vbCrLf
                        Me.m_Position = Me.m_Position + 1
                        Me.m_Grid_Angle = Math.Atan2((Me.m_Form.MouseY - m_Grid_Point.Y), (Me.m_Form.MouseX - m_Grid_Point.X)) * 180 / Math.PI
                        If (Me.m_Grid_Angle < 0) Then Me.m_Grid_Angle += 360
                        Me.Label_Grid_Calibration_Info.Text += "=>Angle:" & Me.m_Grid_Angle
                End Select

        End Select
    End Sub

#End Region

#Region "--- ReDraw ---"

#Region "--- ReDrawTransfer ---"
    Private Sub ReDrawTransfer()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image <> M_NULL Then
            Select Case Me.TabControl_AlignSetting.SelectedIndex
                Case 3
                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                        Me.ReDrawPage0Transfer(image)
                    End If
            End Select
        End If
    End Sub
#End Region

#Region "--- ReDrawROI ---"
    Private Sub ReDrawROI()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image <> M_NULL Then
            Select Case Me.TabControl_AlignSetting.SelectedIndex
                Case 0
                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                        Me.ReDrawPage0ROI(image)
                    End If
            End Select
        End If
    End Sub
#End Region

#Region "--- ReDrawPage0ROI ---"
    Private Sub ReDrawPage0ROI(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Try
            image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If Me.CheckBox_ShowBoundary.Checked And image <> M_NULL Then
                '--- Clear Screen ---
                Me.m_Form.PaintStop = True
                Me.m_Form.Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)

                '--- Initial ---
                rect = New Rectangle
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

                If ZoomX <= 0 Then ZoomX = 0.1 '2012/09/04 Rick add
                If ZoomY <= 0 Then ZoomY = 0.1 '2012/09/04 Rick add

                s = Math.Ceiling(ZoomX)

                SizeX = MIL.MbufInquire(image, MIL.M_SIZE_X, M_NULL)
                SizeY = MIL.MbufInquire(image, MIL.M_SIZE_Y, M_NULL)
                'MIL.MbufInquire(image, MIL.M_SIZE_Y, SizeY)
                'MIL.MbufInquire(image, MIL.M_SIZE_X, SizeX)

                Me.m_SolidBrush.Color = Color.Red
                '--- Initial ---

                v = (Me.NumericUpDown_BoundaryLeft.Value - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_BoundaryRight.Value - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_BoundaryTop.Value - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_BoundaryBottom.Value - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If

            End If

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_Boundary.ReDrawPage0]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- ReDrawPage0Transfer ---"
    Private Sub ReDrawPage0Transfer(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Try
            image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If Me.CheckBox_ShowTable.Checked And image <> M_NULL Then
                '--- Clear Screen ---
                Me.m_Form.PaintStop = True
                Me.m_Form.Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)

                '--- Initial ---
                rect = New Rectangle
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

                If ZoomX <= 0 Then ZoomX = 0.1 '2012/09/04 Rick add
                If ZoomY <= 0 Then ZoomY = 0.1 '2012/09/04 Rick add

                s = Math.Ceiling(ZoomX)

                SizeX = MIL.MbufInquire(image, MIL.M_SIZE_X, M_NULL)
                SizeY = MIL.MbufInquire(image, MIL.M_SIZE_Y, M_NULL)
                'MIL.MbufInquire(image, MIL.M_SIZE_Y, SizeY)
                'MIL.MbufInquire(image, MIL.M_SIZE_X, SizeX)

                Me.m_SolidBrush.Color = Color.Red
                '--- Initial ---

                v = (Me.NumericUpDown_TableLeft.Value - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_TableRight.Value - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_TableTop.Value - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_TableBottom.Value - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If

            End If

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_Boundary.ReDrawPage0]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- TabConTrol Event ---"

#Region "--- TabControl_Setting_SelectedIndexChanged ---"
    Private Sub TabControl_Setting_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl_AlignSetting.SelectedIndexChanged
        Dim Path As String

        Select Case Me.TabControl_AlignSetting.SelectedIndex
            Case 0
                Me.CheckBox_ShowTable.Checked = False
                Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                RepairPath_2(Path)
                Me.m_FuncProcess.FuncModelRecipe = MILOperationLib.ClsFuncModelRecipe.ReadXML(Path)
                Me.UpdateData_Func()
            Case 1
                Me.CheckBox_ShowBoundary.Checked = False
                Me.CheckBox_ShowTable.Checked = False
            Case 2
                Me.CheckBox_ShowTable.Checked = False
                Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                RepairPath_2(Path)
                Me.m_FuncProcess.FuncModelRecipe = MILOperationLib.ClsFuncModelRecipe.ReadXML(Path)
                Me.UpdateData_Func()
            Case 3
                Me.CheckBox_ShowBoundary.Checked = False
                Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                RepairPath_2(Path)
                Me.m_MuraProcess.MuraModelRecipe = MILOperationLib.ClsMuraModelRecipe.ReadXML(Path)
                Me.UpdateData_Mura()
        End Select

        If RadioButton_BoundaryManual.Checked And Me.CheckBox_ShowBoundary.Checked Then
            Me.ReDrawROI()
        ElseIf RadioButton_TableManual.Checked And Me.CheckBox_ShowTable.Checked Then
            Me.ReDrawTransfer()
        Else
            Me.m_Form.PaintStop = True
        End If

    End Sub
#End Region

#End Region

#Region "--- UI Event ---"

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If Me.CheckBox_ShowBoundary.Checked Then
            If CheckBox_ShowBoundary.Checked Then
                Me.ReDrawROI()
            ElseIf CheckBox_ShowTable.Checked Then
                Me.ReDrawTransfer()
            End If
        End If
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If Me.CheckBox_ShowBoundary.Checked Then
            If CheckBox_ShowBoundary.Checked Then
                Me.ReDrawROI()
            ElseIf CheckBox_ShowTable.Checked Then
                Me.ReDrawTransfer()
            End If
        End If
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
            If CheckBox_ShowTable.Checked Then Me.ReDrawTransfer()
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
            If CheckBox_ShowTable.Checked Then Me.ReDrawTransfer()
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
            If CheckBox_ShowTable.Checked Then Me.ReDrawTransfer()
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
            If CheckBox_ShowTable.Checked Then Me.ReDrawTransfer()
        End If
    End Sub
#End Region

#Region "--- ComboBox Event ---"

    Private Sub ComboBox_MultiAngle_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles ComboBox_MultiAngle.SelectedIndexChanged

        Dim fmr As ClsFuncModelRecipe
        fmr = Me.m_FuncProcess.FuncModelRecipe

        If Me.ComboBox_MultiAngle.Text = "LEFT" Then
            Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Left.LeftX & " , " & fmr.LeftUpRightDown_Left.TopY & ")"
            Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Left.RightX & " , " & fmr.LeftDownRightUp_Left.TopY & ")"
            Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Left.RightX & " , " & fmr.LeftUpRightDown_Left.BottomY & ")"
            Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Left.LeftX & " , " & fmr.LeftDownRightUp_Left.BottomY & ")"
        ElseIf Me.ComboBox_MultiAngle.Text = "RIGHT" Then
            Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Right.LeftX & " , " & fmr.LeftUpRightDown_Right.TopY & ")"
            Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Right.RightX & " , " & fmr.LeftDownRightUp_Right.TopY & ")"
            Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Right.RightX & " , " & fmr.LeftUpRightDown_Right.BottomY & ")"
            Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Right.LeftX & " , " & fmr.LeftDownRightUp_Right.BottomY & ")"
        ElseIf Me.ComboBox_MultiAngle.Text = "TOP" Then
            Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Top.LeftX & " , " & fmr.LeftUpRightDown_Top.TopY & ")"
            Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Top.RightX & " , " & fmr.LeftDownRightUp_Top.TopY & ")"
            Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Top.RightX & " , " & fmr.LeftUpRightDown_Top.BottomY & ")"
            Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Top.LeftX & " , " & fmr.LeftDownRightUp_Top.BottomY & ")"
        ElseIf Me.ComboBox_MultiAngle.Text = "BOTTOM" Then
            Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown_Bottom.LeftX & " , " & fmr.LeftUpRightDown_Bottom.TopY & ")"
            Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp_Bottom.RightX & " , " & fmr.LeftDownRightUp_Bottom.TopY & ")"
            Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown_Bottom.RightX & " , " & fmr.LeftUpRightDown_Bottom.BottomY & ")"
            Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp_Bottom.LeftX & " , " & fmr.LeftDownRightUp_Bottom.BottomY & ")"
        Else
            Me.Label_LeftUp.Text = "(" & fmr.LeftUpRightDown.LeftX & " , " & fmr.LeftUpRightDown.TopY & ")"
            Me.Label_RightUp.Text = "(" & fmr.LeftDownRightUp.RightX & " , " & fmr.LeftDownRightUp.TopY & ")"
            Me.Label_RightDown.Text = "(" & fmr.LeftUpRightDown.RightX & " , " & fmr.LeftUpRightDown.BottomY & ")"
            Me.Label_LeftDown.Text = "(" & fmr.LeftDownRightUp.LeftX & " , " & fmr.LeftDownRightUp.BottomY & ")"
        End If

    End Sub

#End Region

#End Region


End Class