﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main_Form
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim TreeNode1 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node0")
        Dim TreeNode2 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node1")
        Dim TreeNode3 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node2")
        Dim TreeNode4 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node3")
        Dim TreeNode5 As System.Windows.Forms.TreeNode = New System.Windows.Forms.TreeNode("Node4")
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main_Form))
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.TabControl_SystemParam = New System.Windows.Forms.TabControl()
        Me.TabPage_Model = New System.Windows.Forms.TabPage()
        Me.ListView_MuraPattern = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label_MuraPatternSetting = New System.Windows.Forms.Label()
        Me.Label_FuncPatternSetting = New System.Windows.Forms.Label()
        Me.Label_ProductSetting = New System.Windows.Forms.Label()
        Me.ListView_FuncPattern = New System.Windows.Forms.ListView()
        Me.ColumnHeader_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ListView_Model = New System.Windows.Forms.ListView()
        Me.ColumnHeader_Model = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_Exp = New System.Windows.Forms.TabPage()
        Me.GroupBox_ExpSetting = New System.Windows.Forms.GroupBox()
        Me.ComboBox_ColorBand = New System.Windows.Forms.ComboBox()
        Me.Label175 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CheckBox_MannualFocus = New System.Windows.Forms.CheckBox()
        Me.Button_MannualMean = New System.Windows.Forms.Button()
        Me.Label_FocusValue = New System.Windows.Forms.Label()
        Me.Label_ROI_Mean = New System.Windows.Forms.Label()
        Me.Button_StopGrab = New System.Windows.Forms.Button()
        Me.ComboBox_PatnList = New System.Windows.Forms.ComboBox()
        Me.Button_Continue = New System.Windows.Forms.Button()
        Me.RadioButton_Func = New System.Windows.Forms.RadioButton()
        Me.GroupBox_ExposureTime = New System.Windows.Forms.GroupBox()
        Me.Button_SaveExpTime = New System.Windows.Forms.Button()
        Me.Label_ExposureTime = New System.Windows.Forms.Label()
        Me.NumericUpDown_ExposureTime = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_ExposureTime = New System.Windows.Forms.TrackBar()
        Me.RadioButton_Mura = New System.Windows.Forms.RadioButton()
        Me.CheckBox_ExpShowBoundary = New System.Windows.Forms.CheckBox()
        Me.TabPage_Align = New System.Windows.Forms.TabPage()
        Me.Button_SaveAlignParam = New System.Windows.Forms.Button()
        Me.GroupBox_MT = New System.Windows.Forms.GroupBox()
        Me.Rdb_ScabType_MT = New System.Windows.Forms.RadioButton()
        Me.Rdb_ScabType_Linear = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Local = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_LocalRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_LocalLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_LocalTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_LocalBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalTop = New System.Windows.Forms.Label()
        Me.Button_Alignment = New System.Windows.Forms.Button()
        Me.GroupBox_PanelRotate = New System.Windows.Forms.GroupBox()
        Me.CheckBox_PanelMirror = New System.Windows.Forms.CheckBox()
        Me.CheckBox_PanelRotate = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Alignment = New System.Windows.Forms.GroupBox()
        Me.CheckBox_EnhanceEdge = New System.Windows.Forms.CheckBox()
        Me.ComboBox_RotateTheta = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AlignTolerance = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_RotateCal = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AlignmentShift = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_AlignDirectionAndOffSet = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_ShiftOffset_Top = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_ShiftOffset_Left = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Func_RightAnalysis = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Func_TopAnalysis = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Func_BottomAnalysis = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_ShiftOffset_Bottom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_ShiftOffset_Right = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Func_LeftAnalysis = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BoundaryModify = New System.Windows.Forms.GroupBox()
        Me.Button_Quick_Edge = New System.Windows.Forms.Button()
        Me.RadioButton_BoundaryManual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BoundaryFinish = New System.Windows.Forms.RadioButton()
        Me.CheckBox_AlignShowBoundary = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Boundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BoundaryRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryTop = New System.Windows.Forms.Label()
        Me.RadioButton_AlignType_Circle = New System.Windows.Forms.RadioButton()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.RadioButton_AlignType_Rectangle = New System.Windows.Forms.RadioButton()
        Me.TabPage_FuncParam = New System.Windows.Forms.TabPage()
        Me.Button_SaveFuncParam = New System.Windows.Forms.Button()
        Me.Panel_FuncParam = New System.Windows.Forms.Panel()
        Me.GroupBox_GrayAbnormal = New System.Windows.Forms.GroupBox()
        Me.Lbl_GrayAbnormal_NegLimit = New System.Windows.Forms.Label()
        Me.Lbl_GrayAbnormal_PosLimit = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormal_NegLimit = New System.Windows.Forms.NumericUpDown()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormalStandardGray = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GrayAbnormal_PosLimit = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_GrayAbnormal_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_DLine = New System.Windows.Forms.GroupBox()
        Me.RadioButton_DL_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DL_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.NumericUpDown_DL_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.Label_SplitLine = New System.Windows.Forms.Label()
        Me.Label_SplitPoint = New System.Windows.Forms.Label()
        Me.CheckBox_DLine_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_ImgProcBoundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Boundary_MulWidth_RX = New System.Windows.Forms.NumericUpDown()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Boundary_MulWidth_BY = New System.Windows.Forms.NumericUpDown()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Boundary_MulWidth_LX = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Boundary_MulWidth_TY = New System.Windows.Forms.NumericUpDown()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.GroupBox_LinePitchSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Line_PitchY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_PitchX = New System.Windows.Forms.NumericUpDown()
        Me.Label_LinePitchY = New System.Windows.Forms.Label()
        Me.Label_LinePitchX = New System.Windows.Forms.Label()
        Me.GroupBox_PointMode = New System.Windows.Forms.GroupBox()
        Me.RadioButton_BPDP = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP = New System.Windows.Forms.RadioButton()
        Me.CheckBox_BLine_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_LineAverageFilter = New System.Windows.Forms.GroupBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AverageFilter = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Point_Algorithm = New System.Windows.Forms.GroupBox()
        Me.RadioButton_PointAlgorithm_3 = New System.Windows.Forms.RadioButton()
        Me.GroupBox_BLine = New System.Windows.Forms.GroupBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BL_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BL_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BL_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_VLine_NotAddToOutput = New System.Windows.Forms.CheckBox()
        Me.GroupBox_PointPitchSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Point_PitchY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Point_PitchX = New System.Windows.Forms.NumericUpDown()
        Me.Label_PointPitchY = New System.Windows.Forms.Label()
        Me.Label_PointPitchX = New System.Windows.Forms.Label()
        Me.GroupBox_DP_Characteristics = New System.Windows.Forms.GroupBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.NumericUpDown_DP_MinGray_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_Compactness_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_StdDev_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_MinGray_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_GrayMean_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_MaxGray_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_Fullness_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_HLine_NotAddToOutput = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Point_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BP_Characteristics = New System.Windows.Forms.GroupBox()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BP_MaxGray_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BP_StdDev_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BP_Compactness_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BP_MaxGray_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_GrayMean_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_MaxGray_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_Fullness_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_LineCommonSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Line_Short_Cut_H = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ShortCut_H = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_Cut_H = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_Cut_H = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_ByPassRightV = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ByPassRightV = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_ByPassLeftV = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ByPassLeftV = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Block_OverNumber = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Block_OverNum = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Line_ByPassUpH = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_Short_Cut = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_ByPassUpH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_ByPassDownH = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ShortCut = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_Cut = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_OverNumber = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_OverNum = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Line_ByPassDownH = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Line_Cut = New System.Windows.Forms.RadioButton()
        Me.GroupBox_BPoint = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BP_RimThreshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_RimThreshold_Low = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_Threshold_Low = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_Threshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_RimThreshold = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_PointCommonSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_DP_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Point_OverNum = New System.Windows.Forms.NumericUpDown()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Point_ByPassY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Point_ByPassX = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Line_Enable = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Align_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_DPoint = New System.Windows.Forms.GroupBox()
        Me.RadioButton_DP_Threshold_Low = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_Threshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_RimThreshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_RimThreshold_Low = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_RimThreshold = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.TreeView_FuncParamPattern = New System.Windows.Forms.TreeView()
        Me.TabPage_MuraParam = New System.Windows.Forms.TabPage()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button_MuraPrePrcoessPage = New System.Windows.Forms.Button()
        Me.Button_MuraBandPage = New System.Windows.Forms.Button()
        Me.Button_MuraCenterPage = New System.Windows.Forms.Button()
        Me.Button_MuraAroundPage = New System.Windows.Forms.Button()
        Me.TabControl_MuraParam = New System.Windows.Forms.TabControl()
        Me.TabPage_MuraPreprocessParam = New System.Windows.Forms.TabPage()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.GroupBox_MuraRatio = New System.Windows.Forms.GroupBox()
        Me.GroupBox_BlobResize = New System.Windows.Forms.GroupBox()
        Me.Num_ResizeCount_Min = New System.Windows.Forms.NumericUpDown()
        Me.Num_ResizeCount_Mid = New System.Windows.Forms.NumericUpDown()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.GroupBox_MarcoResize = New System.Windows.Forms.GroupBox()
        Me.Num_ResizeCount_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Num_ResizeCount_Mid2 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_MacroPowerY = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_UseBaseLine = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_MacroPowerX = New System.Windows.Forms.NumericUpDown()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.NumericUpDown_DefocusCount = New System.Windows.Forms.NumericUpDown()
        Me.Button_MuraPreprocess = New System.Windows.Forms.Button()
        Me.Label_GlobleSmooth = New System.Windows.Forms.Label()
        Me.NumericUpDown_MacroMura_GlobleSmooth = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_RemoveHVBand = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_BlobMura_GlobleSmooth = New System.Windows.Forms.NumericUpDown()
        Me.TabPage_MuraBlobParam = New System.Windows.Forms.TabPage()
        Me.GroupBox_Modify = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowMuraCenterByPass = New System.Windows.Forms.CheckBox()
        Me.RadioButton_Manual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Finish = New System.Windows.Forms.RadioButton()
        Me.GroupBox_MuraCenterBlobByPass = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_MuraCenterBlobByPassRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_MuraCenterBlobByPassLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_MuraCenterBlobByPassTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_MuraCenterBlobByPassBotton = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaTop = New System.Windows.Forms.Label()
        Me.Button_AnalysisMuraBlob = New System.Windows.Forms.Button()
        Me.GroupBox_MuraCenterBlobThreshold = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.NUD_BlackBlobMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBlobMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.NUD_BlackMacroMura_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBlobMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteMacroMura_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Label_ReconstructLow = New System.Windows.Forms.Label()
        Me.Label_ReconstructHeight = New System.Windows.Forms.Label()
        Me.CheckBox_UseReconstructBW = New System.Windows.Forms.CheckBox()
        Me.TabPage_MuraAroundParam = New System.Windows.Forms.TabPage()
        Me.GroupBox_RimBlobValue = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BlackRimBlobValue = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteRimBlobValue = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_BlackRimBlobValue = New System.Windows.Forms.CheckBox()
        Me.CheckBox_WhiteRimBlobValue = New System.Windows.Forms.CheckBox()
        Me.Button_AnalysisMuraAround = New System.Windows.Forms.Button()
        Me.GroupBox_MuraAroundByPass = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowMuraAoundByPass = New System.Windows.Forms.CheckBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Round = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_RimRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_Right = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_Left = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_Bottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_Top = New System.Windows.Forms.Label()
        Me.GroupBox_MuraAroundThreshold = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlackMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlackMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WhiteMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.TabPage_MuraBandParam = New System.Windows.Forms.TabPage()
        Me.GroupBox_BandVOpenSearch = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BandVOpenEdgeStrength = New System.Windows.Forms.NumericUpDown()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.CheckBox_EnableBandVOpen = New System.Windows.Forms.CheckBox()
        Me.Button_AnalysisMuraBand = New System.Windows.Forms.Button()
        Me.GroupBox_BandBlockH = New System.Windows.Forms.GroupBox()
        Me.ListView_HBlock = New System.Windows.Forms.ListView()
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader13 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox_BandLeakPoint = New System.Windows.Forms.GroupBox()
        Me.CheckBox_EnableBandLeakPoint = New System.Windows.Forms.CheckBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BandLeakPointFilterRadius = New System.Windows.Forms.NumericUpDown()
        Me.ComboBox_MuraBandResult = New System.Windows.Forms.ComboBox()
        Me.CheckBox_BandUseRemoveHV = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BandResizeThreshold = New System.Windows.Forms.GroupBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlackVBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlackHBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BandMura_SmoothCount = New System.Windows.Forms.NumericUpDown()
        Me.Label_Band_SmoothCount = New System.Windows.Forms.Label()
        Me.NumericUpDown_BandMura_ResizeCount = New System.Windows.Forms.NumericUpDown()
        Me.Label_Band_ResizeCount = New System.Windows.Forms.Label()
        Me.NumericUpDown_WhiteHBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteVBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackBand_Thrshold = New System.Windows.Forms.Label()
        Me.Label_HBand_Thrshold = New System.Windows.Forms.Label()
        Me.CheckBox_MuraBandResult = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BandBlockV = New System.Windows.Forms.GroupBox()
        Me.ListView_VBlock = New System.Windows.Forms.ListView()
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox_BandByPass = New System.Windows.Forms.GroupBox()
        Me.ComboBox_ShowMuraBand = New System.Windows.Forms.ComboBox()
        Me.CheckBox_ShowMuraBandByPass = New System.Windows.Forms.CheckBox()
        Me.GroupBox_V = New System.Windows.Forms.GroupBox()
        Me.TextBox_VHCount = New System.Windows.Forms.TextBox()
        Me.Button_VLeftBase = New System.Windows.Forms.Button()
        Me.TextBox_VVCount = New System.Windows.Forms.TextBox()
        Me.Button_VRightBase = New System.Windows.Forms.Button()
        Me.Button_VTopBase = New System.Windows.Forms.Button()
        Me.NumericUpDown_VTop = New System.Windows.Forms.NumericUpDown()
        Me.Button_VBottomBase = New System.Windows.Forms.Button()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.NumericUpDown_VRight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_VBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.NumericUpDown_VLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.GroupBox_H = New System.Windows.Forms.GroupBox()
        Me.TextBox_HHCount = New System.Windows.Forms.TextBox()
        Me.TextBox_HVCount = New System.Windows.Forms.TextBox()
        Me.Button_HLeftBase = New System.Windows.Forms.Button()
        Me.Button_HTopBase = New System.Windows.Forms.Button()
        Me.Button_HRightBase = New System.Windows.Forms.Button()
        Me.Button_HBottomBase = New System.Windows.Forms.Button()
        Me.NumericUpDown_HRight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_HTop = New System.Windows.Forms.NumericUpDown()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.NumericUpDown_HLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.NumericUpDown_HBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.GroupBox_BandBlockSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_AutoWidth = New System.Windows.Forms.NumericUpDown()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.CheckBox_ShowMuraBlock = New System.Windows.Forms.CheckBox()
        Me.Button_AddBlockSetting = New System.Windows.Forms.Button()
        Me.ComboBox_SelectMuraBlock = New System.Windows.Forms.ComboBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlockBlackTH = New System.Windows.Forms.NumericUpDown()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlockWhiteTH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlockTop = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlockRight = New System.Windows.Forms.NumericUpDown()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlockButtom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlockLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TreeView_MuraParamPattern = New System.Windows.Forms.TreeView()
        Me.CheckBox_AnalysisCenterMuraEnable = New System.Windows.Forms.CheckBox()
        Me.CheckBox_AnalysisBandMuraEnable = New System.Windows.Forms.CheckBox()
        Me.CheckBox_AnalysisAroundMuraEnable = New System.Windows.Forms.CheckBox()
        Me.Button_MuraParamSave = New System.Windows.Forms.Button()
        Me.txtOutput = New System.Windows.Forms.RichTextBox()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.Button_MuraAutoTest = New System.Windows.Forms.Button()
        Me.Button_MuraManualTest = New System.Windows.Forms.Button()
        Me.Button_JND = New System.Windows.Forms.Button()
        Me.Button_SettingMura = New System.Windows.Forms.Button()
        Me.Button_MuraResult = New System.Windows.Forms.Button()
        Me.Button_MuraFalseDefect = New System.Windows.Forms.Button()
        Me.Button_FuncImgProcTest = New System.Windows.Forms.Button()
        Me.Button_Align = New System.Windows.Forms.Button()
        Me.Button_SettingFunc = New System.Windows.Forms.Button()
        Me.Button_FuncFalseDefect = New System.Windows.Forms.Button()
        Me.Button_ADJMean = New System.Windows.Forms.Button()
        Me.Button_CameraAlignment = New System.Windows.Forms.Button()
        Me.Button_ProductModelSetting = New System.Windows.Forms.Button()
        Me.Label_ImgGrayValue = New System.Windows.Forms.Label()
        Me.Label_imgAnchorPosY = New System.Windows.Forms.Label()
        Me.Label_imgAnchorPosX = New System.Windows.Forms.Label()
        Me.Button_ImgCal = New System.Windows.Forms.Button()
        Me.TextBox_Product = New System.Windows.Forms.TextBox()
        Me.Label_Type = New System.Windows.Forms.Label()
        Me.Label_Select = New System.Windows.Forms.Label()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.PictureBox_VBand_White = New System.Windows.Forms.PictureBox()
        Me.ComboBox_Type = New System.Windows.Forms.ComboBox()
        Me.PictureBox_VBand_Black = New System.Windows.Forms.PictureBox()
        Me.PictureBox_HBand_White = New System.Windows.Forms.PictureBox()
        Me.PictureBox_HBand_Black = New System.Windows.Forms.PictureBox()
        Me.ComboBox_Select = New System.Windows.Forms.ComboBox()
        Me.ComboBox_Pattern_MainFrm = New System.Windows.Forms.ComboBox()
        Me.PictureBox_PreInfo = New System.Windows.Forms.PictureBox()
        Me.Label_Product = New System.Windows.Forms.Label()
        Me.Button_QuickAlign = New System.Windows.Forms.Button()
        Me.VScrollBar = New System.Windows.Forms.VScrollBar()
        Me.Button_ZoomAll = New System.Windows.Forms.Button()
        Me.TextBox_PreInfo = New System.Windows.Forms.TextBox()
        Me.Button_LoadImage = New System.Windows.Forms.Button()
        Me.Button_ZoomO = New System.Windows.Forms.Button()
        Me.Button_ZoomIn = New System.Windows.Forms.Button()
        Me.Button_SaveImage = New System.Windows.Forms.Button()
        Me.Button_ZoomOut = New System.Windows.Forms.Button()
        Me.Panel_AxMDisplay = New System.Windows.Forms.Panel()
        Me.Label_DisplayMsg = New System.Windows.Forms.Label()
        Me.HScrollBar = New System.Windows.Forms.HScrollBar()
        Me.ContextMenuStrip_FuncPattern = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem_AddPattern = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_RemovePattern = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip_Model = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem_AddModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_RemoveModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_SetCurrentModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button_BarcodeSetting = New System.Windows.Forms.Button()
        Me.StatusBar_IP = New System.Windows.Forms.StatusBar()
        Me.StatusBarPanel_IPStatus = New System.Windows.Forms.StatusBarPanel()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.tsmEdit = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmRecipe = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmIPNetWorkConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.tsmIPBootConfig = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox_IPStatus = New System.Windows.Forms.GroupBox()
        Me.Button_InitialIP = New System.Windows.Forms.Button()
        Me.Button_KillIP = New System.Windows.Forms.Button()
        Me.ComboBox_GrabNo = New System.Windows.Forms.ComboBox()
        Me.ComboBox_CCDMode = New System.Windows.Forms.ComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox_IP = New System.Windows.Forms.GroupBox()
        Me.ComboBox_CCD = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button_FuncResult = New System.Windows.Forms.Button()
        Me.btnClearLog = New System.Windows.Forms.Button()
        Me.StatusBar = New System.Windows.Forms.StatusBar()
        Me.StatusBarPanel_XY = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Value = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Scale = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_UsedNonPage = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Status = New System.Windows.Forms.StatusBarPanel()
        Me.GroupBox_Image = New System.Windows.Forms.GroupBox()
        Me.CheckBox_SaveAI = New System.Windows.Forms.CheckBox()
        Me.TabControl_HightLevel = New System.Windows.Forms.TabControl()
        Me.TabPage_HighLevelOP = New System.Windows.Forms.TabPage()
        Me.GroupBox_Log = New System.Windows.Forms.GroupBox()
        Me.DateTimePicker_Log = New System.Windows.Forms.DateTimePicker()
        Me.Button_Log_Open = New System.Windows.Forms.Button()
        Me.ComboBox_Log_Type = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox_Log_IPNo = New System.Windows.Forms.ComboBox()
        Me.Button_SetMappingTable = New System.Windows.Forms.Button()
        Me.GroupBox_FuncSetting = New System.Windows.Forms.GroupBox()
        Me.Button_SettingBase = New System.Windows.Forms.Button()
        Me.Button_MuraCollect = New System.Windows.Forms.Button()
        Me.Button_AlignTest = New System.Windows.Forms.Button()
        Me.Button_FuncSettingBase = New System.Windows.Forms.Button()
        Me.TabPage_OMS = New System.Windows.Forms.TabPage()
        Me.Button_OMSSetting = New System.Windows.Forms.Button()
        Me.GroupBox_OMS_Enable_Setting = New System.Windows.Forms.GroupBox()
        Me.Button_OMS_Save = New System.Windows.Forms.Button()
        Me.ComboBox_OMS_Enable_IPNo = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TabPage_Tool = New System.Windows.Forms.TabPage()
        Me.Button_RMSSetting = New System.Windows.Forms.Button()
        Me.Button_MDC_Setting = New System.Windows.Forms.Button()
        Me.Button_LookUpPosition = New System.Windows.Forms.Button()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.ZoomContextMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ZoomInToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZoomOutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OriginToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ZoomAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BitToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotifyIcon_AreaGrabber = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.RadioButton_Licensed = New System.Windows.Forms.RadioButton()
        Me.CheckBox_IsAligned = New System.Windows.Forms.CheckBox()
        Me.ContextMenuStrip_MuraPattern = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.tmr = New System.Windows.Forms.Timer(Me.components)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.TabControl_SystemParam.SuspendLayout()
        Me.TabPage_Model.SuspendLayout()
        Me.TabPage_Exp.SuspendLayout()
        Me.GroupBox_ExpSetting.SuspendLayout()
        Me.GroupBox_ExposureTime.SuspendLayout()
        CType(Me.NumericUpDown_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Align.SuspendLayout()
        Me.GroupBox_MT.SuspendLayout()
        Me.GroupBox_Local.SuspendLayout()
        CType(Me.NumericUpDown_LocalRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LocalLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LocalTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LocalBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PanelRotate.SuspendLayout()
        Me.GroupBox_Alignment.SuspendLayout()
        CType(Me.NumericUpDown_AlignTolerance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AlignmentShift, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_AlignDirectionAndOffSet.SuspendLayout()
        CType(Me.NumericUpDown_ShiftOffset_Top, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ShiftOffset_Left, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ShiftOffset_Bottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ShiftOffset_Right, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BoundaryModify.SuspendLayout()
        Me.GroupBox_Boundary.SuspendLayout()
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_FuncParam.SuspendLayout()
        Me.Panel_FuncParam.SuspendLayout()
        Me.GroupBox_GrayAbnormal.SuspendLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_DLine.SuspendLayout()
        CType(Me.NumericUpDown_DL_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DL_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ImgProcBoundary.SuspendLayout()
        CType(Me.NumericUpDown_Boundary_MulWidth_RX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_BY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_LX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_TY, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_LinePitchSetting.SuspendLayout()
        CType(Me.NumericUpDown_Line_PitchY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_PitchX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PointMode.SuspendLayout()
        Me.GroupBox_LineAverageFilter.SuspendLayout()
        CType(Me.NumericUpDown_AverageFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Point_Algorithm.SuspendLayout()
        Me.GroupBox_BLine.SuspendLayout()
        CType(Me.NumericUpDown_BL_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BL_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PointPitchSetting.SuspendLayout()
        CType(Me.NumericUpDown_Point_PitchY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_PitchX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_DP_Characteristics.SuspendLayout()
        CType(Me.NumericUpDown_DP_MinGray_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Compactness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_StdDev_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_MinGray_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_GrayMean_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Fullness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BP_Characteristics.SuspendLayout()
        CType(Me.NumericUpDown_BP_MaxGray_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_StdDev_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Compactness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_MaxGray_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_GrayMean_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Fullness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_LineCommonSetting.SuspendLayout()
        CType(Me.NumericUpDown_Line_Short_Cut_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_Cut_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassRightV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassLeftV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Block_OverNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_Short_Cut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassUpH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassDownH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_Cut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_OverNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BPoint.SuspendLayout()
        CType(Me.NumericUpDown_BP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Threshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PointCommonSetting.SuspendLayout()
        CType(Me.NumericUpDown_DP_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_OverNum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_ByPassY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_ByPassX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_DPoint.SuspendLayout()
        CType(Me.NumericUpDown_DP_Threshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_MuraParam.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TabControl_MuraParam.SuspendLayout()
        Me.TabPage_MuraPreprocessParam.SuspendLayout()
        Me.GroupBox_MuraRatio.SuspendLayout()
        Me.GroupBox_BlobResize.SuspendLayout()
        CType(Me.Num_ResizeCount_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Mid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MarcoResize.SuspendLayout()
        CType(Me.Num_ResizeCount_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Mid2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MacroPowerY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MacroPowerX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DefocusCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MacroMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlobMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_MuraBlobParam.SuspendLayout()
        Me.GroupBox_Modify.SuspendLayout()
        Me.GroupBox_MuraCenterBlobByPass.SuspendLayout()
        CType(Me.NumericUpDown_MuraCenterBlobByPassRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MuraCenterBlobByPassLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MuraCenterBlobByPassTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MuraCenterBlobByPassBotton, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MuraCenterBlobThreshold.SuspendLayout()
        CType(Me.NUD_BlackBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackMacroMura_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteMacroMura_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_MuraAroundParam.SuspendLayout()
        Me.GroupBox_RimBlobValue.SuspendLayout()
        CType(Me.NumericUpDown_BlackRimBlobValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteRimBlobValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MuraAroundByPass.SuspendLayout()
        Me.GroupBox_Round.SuspendLayout()
        CType(Me.NumericUpDown_RimRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MuraAroundThreshold.SuspendLayout()
        CType(Me.NumericUpDown_BlackMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlackMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_MuraBandParam.SuspendLayout()
        Me.GroupBox_BandVOpenSearch.SuspendLayout()
        CType(Me.NumericUpDown_BandVOpenEdgeStrength, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BandBlockH.SuspendLayout()
        Me.GroupBox_BandLeakPoint.SuspendLayout()
        CType(Me.NumericUpDown_BandLeakPointFilterRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BandResizeThreshold.SuspendLayout()
        CType(Me.NumericUpDown_BlackVBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlackHBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BandMura_SmoothCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BandMura_ResizeCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteHBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteVBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BandBlockV.SuspendLayout()
        Me.GroupBox_BandByPass.SuspendLayout()
        Me.GroupBox_V.SuspendLayout()
        CType(Me.NumericUpDown_VTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_H.SuspendLayout()
        CType(Me.NumericUpDown_HRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BandBlockSetting.SuspendLayout()
        CType(Me.NumericUpDown_AutoWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockBlackTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockWhiteTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockButtom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.PictureBox_VBand_White, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_VBand_Black, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_HBand_White, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_HBand_Black, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox_PreInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel_AxMDisplay.SuspendLayout()
        Me.ContextMenuStrip_FuncPattern.SuspendLayout()
        Me.ContextMenuStrip_Model.SuspendLayout()
        CType(Me.StatusBarPanel_IPStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.mnuMain.SuspendLayout()
        Me.GroupBox_IPStatus.SuspendLayout()
        Me.GroupBox_IP.SuspendLayout()
        CType(Me.StatusBarPanel_XY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Value, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Scale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_UsedNonPage, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Status, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Image.SuspendLayout()
        Me.TabControl_HightLevel.SuspendLayout()
        Me.TabPage_HighLevelOP.SuspendLayout()
        Me.GroupBox_Log.SuspendLayout()
        Me.GroupBox_FuncSetting.SuspendLayout()
        Me.TabPage_OMS.SuspendLayout()
        Me.GroupBox_OMS_Enable_Setting.SuspendLayout()
        Me.TabPage_Tool.SuspendLayout()
        Me.ZoomContextMenuStrip.SuspendLayout()
        Me.ContextMenuStrip_MuraPattern.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Location = New System.Drawing.Point(575, 4)
        Me.SplitContainer2.Name = "SplitContainer2"
        Me.SplitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.AutoScroll = True
        Me.SplitContainer2.Panel1.Controls.Add(Me.TabControl_SystemParam)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.txtOutput)
        Me.SplitContainer2.Size = New System.Drawing.Size(537, 596)
        Me.SplitContainer2.SplitterDistance = 502
        Me.SplitContainer2.TabIndex = 10032
        '
        'TabControl_SystemParam
        '
        Me.TabControl_SystemParam.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl_SystemParam.Controls.Add(Me.TabPage_Model)
        Me.TabControl_SystemParam.Controls.Add(Me.TabPage_Exp)
        Me.TabControl_SystemParam.Controls.Add(Me.TabPage_Align)
        Me.TabControl_SystemParam.Controls.Add(Me.TabPage_FuncParam)
        Me.TabControl_SystemParam.Controls.Add(Me.TabPage_MuraParam)
        Me.TabControl_SystemParam.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl_SystemParam.ItemSize = New System.Drawing.Size(50, 10)
        Me.TabControl_SystemParam.Location = New System.Drawing.Point(0, 0)
        Me.TabControl_SystemParam.Multiline = True
        Me.TabControl_SystemParam.Name = "TabControl_SystemParam"
        Me.TabControl_SystemParam.SelectedIndex = 0
        Me.TabControl_SystemParam.Size = New System.Drawing.Size(537, 502)
        Me.TabControl_SystemParam.TabIndex = 0
        '
        'TabPage_Model
        '
        Me.TabPage_Model.BackColor = System.Drawing.Color.LightYellow
        Me.TabPage_Model.Controls.Add(Me.ListView_MuraPattern)
        Me.TabPage_Model.Controls.Add(Me.Label_MuraPatternSetting)
        Me.TabPage_Model.Controls.Add(Me.Label_FuncPatternSetting)
        Me.TabPage_Model.Controls.Add(Me.Label_ProductSetting)
        Me.TabPage_Model.Controls.Add(Me.ListView_FuncPattern)
        Me.TabPage_Model.Controls.Add(Me.ListView_Model)
        Me.TabPage_Model.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_Model.Name = "TabPage_Model"
        Me.TabPage_Model.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Model.Size = New System.Drawing.Size(529, 484)
        Me.TabPage_Model.TabIndex = 0
        Me.TabPage_Model.Tag = "Model"
        '
        'ListView_MuraPattern
        '
        Me.ListView_MuraPattern.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.ListView_MuraPattern.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ListView_MuraPattern.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.ListView_MuraPattern.FullRowSelect = True
        Me.ListView_MuraPattern.Location = New System.Drawing.Point(355, 36)
        Me.ListView_MuraPattern.MultiSelect = False
        Me.ListView_MuraPattern.Name = "ListView_MuraPattern"
        Me.ListView_MuraPattern.Size = New System.Drawing.Size(166, 442)
        Me.ListView_MuraPattern.TabIndex = 62
        Me.ListView_MuraPattern.UseCompatibleStateImageBehavior = False
        Me.ListView_MuraPattern.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Pattern List"
        Me.ColumnHeader1.Width = 162
        '
        'Label_MuraPatternSetting
        '
        Me.Label_MuraPatternSetting.BackColor = System.Drawing.Color.AliceBlue
        Me.Label_MuraPatternSetting.Font = New System.Drawing.Font("微軟正黑體", 11.25!)
        Me.Label_MuraPatternSetting.Location = New System.Drawing.Point(369, 6)
        Me.Label_MuraPatternSetting.Name = "Label_MuraPatternSetting"
        Me.Label_MuraPatternSetting.Size = New System.Drawing.Size(139, 27)
        Me.Label_MuraPatternSetting.TabIndex = 61
        Me.Label_MuraPatternSetting.Text = "Mura Pattern列表"
        Me.Label_MuraPatternSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_FuncPatternSetting
        '
        Me.Label_FuncPatternSetting.BackColor = System.Drawing.Color.Aquamarine
        Me.Label_FuncPatternSetting.Font = New System.Drawing.Font("微軟正黑體", 11.25!)
        Me.Label_FuncPatternSetting.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label_FuncPatternSetting.Location = New System.Drawing.Point(195, 6)
        Me.Label_FuncPatternSetting.Name = "Label_FuncPatternSetting"
        Me.Label_FuncPatternSetting.Size = New System.Drawing.Size(139, 27)
        Me.Label_FuncPatternSetting.TabIndex = 61
        Me.Label_FuncPatternSetting.Text = "FUNC Pattern列表"
        Me.Label_FuncPatternSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_ProductSetting
        '
        Me.Label_ProductSetting.BackColor = System.Drawing.Color.Gold
        Me.Label_ProductSetting.Font = New System.Drawing.Font("微軟正黑體", 11.25!)
        Me.Label_ProductSetting.Location = New System.Drawing.Point(21, 6)
        Me.Label_ProductSetting.Name = "Label_ProductSetting"
        Me.Label_ProductSetting.Size = New System.Drawing.Size(139, 27)
        Me.Label_ProductSetting.TabIndex = 61
        Me.Label_ProductSetting.Text = "產品型號列表"
        Me.Label_ProductSetting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ListView_FuncPattern
        '
        Me.ListView_FuncPattern.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.ListView_FuncPattern.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ListView_FuncPattern.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_Pattern})
        Me.ListView_FuncPattern.FullRowSelect = True
        Me.ListView_FuncPattern.Location = New System.Drawing.Point(181, 36)
        Me.ListView_FuncPattern.MultiSelect = False
        Me.ListView_FuncPattern.Name = "ListView_FuncPattern"
        Me.ListView_FuncPattern.Size = New System.Drawing.Size(166, 442)
        Me.ListView_FuncPattern.TabIndex = 60
        Me.ListView_FuncPattern.UseCompatibleStateImageBehavior = False
        Me.ListView_FuncPattern.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_Pattern
        '
        Me.ColumnHeader_Pattern.Text = "Pattern List"
        Me.ColumnHeader_Pattern.Width = 162
        '
        'ListView_Model
        '
        Me.ListView_Model.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.ListView_Model.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ListView_Model.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_Model})
        Me.ListView_Model.FullRowSelect = True
        Me.ListView_Model.Location = New System.Drawing.Point(7, 36)
        Me.ListView_Model.MultiSelect = False
        Me.ListView_Model.Name = "ListView_Model"
        Me.ListView_Model.Size = New System.Drawing.Size(166, 442)
        Me.ListView_Model.TabIndex = 58
        Me.ListView_Model.UseCompatibleStateImageBehavior = False
        Me.ListView_Model.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_Model
        '
        Me.ColumnHeader_Model.Text = "Model List"
        Me.ColumnHeader_Model.Width = 162
        '
        'TabPage_Exp
        '
        Me.TabPage_Exp.Controls.Add(Me.GroupBox_ExpSetting)
        Me.TabPage_Exp.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_Exp.Name = "TabPage_Exp"
        Me.TabPage_Exp.Size = New System.Drawing.Size(529, 484)
        Me.TabPage_Exp.TabIndex = 1
        Me.TabPage_Exp.Tag = "EXP"
        Me.TabPage_Exp.UseVisualStyleBackColor = True
        '
        'GroupBox_ExpSetting
        '
        Me.GroupBox_ExpSetting.BackColor = System.Drawing.Color.AliceBlue
        Me.GroupBox_ExpSetting.Controls.Add(Me.ComboBox_ColorBand)
        Me.GroupBox_ExpSetting.Controls.Add(Me.Label175)
        Me.GroupBox_ExpSetting.Controls.Add(Me.Label10)
        Me.GroupBox_ExpSetting.Controls.Add(Me.CheckBox_MannualFocus)
        Me.GroupBox_ExpSetting.Controls.Add(Me.Button_MannualMean)
        Me.GroupBox_ExpSetting.Controls.Add(Me.Label_FocusValue)
        Me.GroupBox_ExpSetting.Controls.Add(Me.Label_ROI_Mean)
        Me.GroupBox_ExpSetting.Controls.Add(Me.Button_StopGrab)
        Me.GroupBox_ExpSetting.Controls.Add(Me.ComboBox_PatnList)
        Me.GroupBox_ExpSetting.Controls.Add(Me.Button_Continue)
        Me.GroupBox_ExpSetting.Controls.Add(Me.RadioButton_Func)
        Me.GroupBox_ExpSetting.Controls.Add(Me.GroupBox_ExposureTime)
        Me.GroupBox_ExpSetting.Controls.Add(Me.RadioButton_Mura)
        Me.GroupBox_ExpSetting.Controls.Add(Me.CheckBox_ExpShowBoundary)
        Me.GroupBox_ExpSetting.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox_ExpSetting.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox_ExpSetting.Name = "GroupBox_ExpSetting"
        Me.GroupBox_ExpSetting.Size = New System.Drawing.Size(529, 484)
        Me.GroupBox_ExpSetting.TabIndex = 73
        Me.GroupBox_ExpSetting.TabStop = False
        '
        'ComboBox_ColorBand
        '
        Me.ComboBox_ColorBand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_ColorBand.ForeColor = System.Drawing.Color.Red
        Me.ComboBox_ColorBand.FormattingEnabled = True
        Me.ComboBox_ColorBand.Items.AddRange(New Object() {"NONE", "L", "R", "G", "B", "raw"})
        Me.ComboBox_ColorBand.Location = New System.Drawing.Point(96, 44)
        Me.ComboBox_ColorBand.Name = "ComboBox_ColorBand"
        Me.ComboBox_ColorBand.Size = New System.Drawing.Size(73, 20)
        Me.ComboBox_ColorBand.TabIndex = 74
        '
        'Label175
        '
        Me.Label175.AutoSize = True
        Me.Label175.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label175.Location = New System.Drawing.Point(6, 48)
        Me.Label175.Name = "Label175"
        Me.Label175.Size = New System.Drawing.Size(69, 12)
        Me.Label175.TabIndex = 73
        Me.Label175.Text = "Color Band : "
        '
        'Label10
        '
        Me.Label10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label10.Location = New System.Drawing.Point(6, 18)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(41, 15)
        Me.Label10.TabIndex = 59
        Me.Label10.Text = "Pattern"
        '
        'CheckBox_MannualFocus
        '
        Me.CheckBox_MannualFocus.AutoSize = True
        Me.CheckBox_MannualFocus.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_MannualFocus.Location = New System.Drawing.Point(9, 281)
        Me.CheckBox_MannualFocus.Name = "CheckBox_MannualFocus"
        Me.CheckBox_MannualFocus.Size = New System.Drawing.Size(75, 16)
        Me.CheckBox_MannualFocus.TabIndex = 71
        Me.CheckBox_MannualFocus.Text = "计算Focus"
        Me.CheckBox_MannualFocus.UseVisualStyleBackColor = True
        '
        'Button_MannualMean
        '
        Me.Button_MannualMean.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_MannualMean.Location = New System.Drawing.Point(9, 238)
        Me.Button_MannualMean.Name = "Button_MannualMean"
        Me.Button_MannualMean.Size = New System.Drawing.Size(135, 24)
        Me.Button_MannualMean.TabIndex = 1
        Me.Button_MannualMean.Text = "计算Mean"
        Me.Button_MannualMean.UseVisualStyleBackColor = True
        '
        'Label_FocusValue
        '
        Me.Label_FocusValue.AutoSize = True
        Me.Label_FocusValue.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_FocusValue.Location = New System.Drawing.Point(110, 283)
        Me.Label_FocusValue.Name = "Label_FocusValue"
        Me.Label_FocusValue.Size = New System.Drawing.Size(68, 12)
        Me.Label_FocusValue.TabIndex = 70
        Me.Label_FocusValue.Text = "Focus Value :"
        '
        'Label_ROI_Mean
        '
        Me.Label_ROI_Mean.AutoSize = True
        Me.Label_ROI_Mean.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_ROI_Mean.Location = New System.Drawing.Point(152, 243)
        Me.Label_ROI_Mean.Name = "Label_ROI_Mean"
        Me.Label_ROI_Mean.Size = New System.Drawing.Size(75, 12)
        Me.Label_ROI_Mean.TabIndex = 0
        Me.Label_ROI_Mean.Text = "ROI Mean 值 :"
        '
        'Button_StopGrab
        '
        Me.Button_StopGrab.Enabled = False
        Me.Button_StopGrab.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_StopGrab.Location = New System.Drawing.Point(113, 87)
        Me.Button_StopGrab.Name = "Button_StopGrab"
        Me.Button_StopGrab.Size = New System.Drawing.Size(98, 40)
        Me.Button_StopGrab.TabIndex = 72
        Me.Button_StopGrab.Text = "Stop Grab"
        '
        'ComboBox_PatnList
        '
        Me.ComboBox_PatnList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PatnList.FormattingEnabled = True
        Me.ComboBox_PatnList.Location = New System.Drawing.Point(63, 14)
        Me.ComboBox_PatnList.Name = "ComboBox_PatnList"
        Me.ComboBox_PatnList.Size = New System.Drawing.Size(106, 20)
        Me.ComboBox_PatnList.TabIndex = 58
        '
        'Button_Continue
        '
        Me.Button_Continue.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_Continue.Location = New System.Drawing.Point(9, 87)
        Me.Button_Continue.Name = "Button_Continue"
        Me.Button_Continue.Size = New System.Drawing.Size(98, 40)
        Me.Button_Continue.TabIndex = 43
        Me.Button_Continue.Text = "Continuous"
        '
        'RadioButton_Func
        '
        Me.RadioButton_Func.AutoSize = True
        Me.RadioButton_Func.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Func.Location = New System.Drawing.Point(260, 16)
        Me.RadioButton_Func.Name = "RadioButton_Func"
        Me.RadioButton_Func.Size = New System.Drawing.Size(46, 16)
        Me.RadioButton_Func.TabIndex = 60
        Me.RadioButton_Func.Text = "Func"
        Me.RadioButton_Func.UseVisualStyleBackColor = True
        '
        'GroupBox_ExposureTime
        '
        Me.GroupBox_ExposureTime.Controls.Add(Me.Button_SaveExpTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.Label_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.NumericUpDown_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.TrackBar_ExposureTime)
        Me.GroupBox_ExposureTime.Enabled = False
        Me.GroupBox_ExposureTime.Location = New System.Drawing.Point(9, 141)
        Me.GroupBox_ExposureTime.Name = "GroupBox_ExposureTime"
        Me.GroupBox_ExposureTime.Size = New System.Drawing.Size(421, 91)
        Me.GroupBox_ExposureTime.TabIndex = 64
        Me.GroupBox_ExposureTime.TabStop = False
        Me.GroupBox_ExposureTime.Text = "曝光時間"
        '
        'Button_SaveExpTime
        '
        Me.Button_SaveExpTime.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_SaveExpTime.Location = New System.Drawing.Point(222, 51)
        Me.Button_SaveExpTime.Name = "Button_SaveExpTime"
        Me.Button_SaveExpTime.Size = New System.Drawing.Size(87, 26)
        Me.Button_SaveExpTime.TabIndex = 46
        Me.Button_SaveExpTime.Text = "Save"
        Me.Button_SaveExpTime.UseVisualStyleBackColor = True
        '
        'Label_ExposureTime
        '
        Me.Label_ExposureTime.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_ExposureTime.Location = New System.Drawing.Point(143, 53)
        Me.Label_ExposureTime.Name = "Label_ExposureTime"
        Me.Label_ExposureTime.Size = New System.Drawing.Size(71, 22)
        Me.Label_ExposureTime.TabIndex = 45
        Me.Label_ExposureTime.Text = "微秒(us)"
        Me.Label_ExposureTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown_ExposureTime
        '
        Me.NumericUpDown_ExposureTime.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Location = New System.Drawing.Point(7, 52)
        Me.NumericUpDown_ExposureTime.Maximum = New Decimal(New Integer() {7000000, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Name = "NumericUpDown_ExposureTime"
        Me.NumericUpDown_ExposureTime.Size = New System.Drawing.Size(128, 22)
        Me.NumericUpDown_ExposureTime.TabIndex = 44
        Me.NumericUpDown_ExposureTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_ExposureTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'TrackBar_ExposureTime
        '
        Me.TrackBar_ExposureTime.AutoSize = False
        Me.TrackBar_ExposureTime.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TrackBar_ExposureTime.LargeChange = 10000
        Me.TrackBar_ExposureTime.Location = New System.Drawing.Point(4, 21)
        Me.TrackBar_ExposureTime.Maximum = 7000000
        Me.TrackBar_ExposureTime.Minimum = 1
        Me.TrackBar_ExposureTime.Name = "TrackBar_ExposureTime"
        Me.TrackBar_ExposureTime.Size = New System.Drawing.Size(411, 25)
        Me.TrackBar_ExposureTime.TabIndex = 44
        Me.TrackBar_ExposureTime.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_ExposureTime.Value = 1
        '
        'RadioButton_Mura
        '
        Me.RadioButton_Mura.AutoSize = True
        Me.RadioButton_Mura.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Mura.Location = New System.Drawing.Point(185, 16)
        Me.RadioButton_Mura.Name = "RadioButton_Mura"
        Me.RadioButton_Mura.Size = New System.Drawing.Size(48, 16)
        Me.RadioButton_Mura.TabIndex = 61
        Me.RadioButton_Mura.Text = "Mura"
        Me.RadioButton_Mura.UseVisualStyleBackColor = True
        '
        'CheckBox_ExpShowBoundary
        '
        Me.CheckBox_ExpShowBoundary.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_ExpShowBoundary.Location = New System.Drawing.Point(332, 14)
        Me.CheckBox_ExpShowBoundary.Name = "CheckBox_ExpShowBoundary"
        Me.CheckBox_ExpShowBoundary.Size = New System.Drawing.Size(98, 24)
        Me.CheckBox_ExpShowBoundary.TabIndex = 69
        Me.CheckBox_ExpShowBoundary.Text = "显示ROI"
        '
        'TabPage_Align
        '
        Me.TabPage_Align.AutoScroll = True
        Me.TabPage_Align.BackColor = System.Drawing.Color.Linen
        Me.TabPage_Align.Controls.Add(Me.Button_SaveAlignParam)
        Me.TabPage_Align.Controls.Add(Me.GroupBox_MT)
        Me.TabPage_Align.Controls.Add(Me.GroupBox_Local)
        Me.TabPage_Align.Controls.Add(Me.Button_Alignment)
        Me.TabPage_Align.Controls.Add(Me.GroupBox_PanelRotate)
        Me.TabPage_Align.Controls.Add(Me.GroupBox_Alignment)
        Me.TabPage_Align.Controls.Add(Me.GroupBox_AlignDirectionAndOffSet)
        Me.TabPage_Align.Controls.Add(Me.GroupBox_BoundaryModify)
        Me.TabPage_Align.Controls.Add(Me.RadioButton_AlignType_Circle)
        Me.TabPage_Align.Controls.Add(Me.Label11)
        Me.TabPage_Align.Controls.Add(Me.RadioButton_AlignType_Rectangle)
        Me.TabPage_Align.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_Align.Name = "TabPage_Align"
        Me.TabPage_Align.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Align.Size = New System.Drawing.Size(529, 484)
        Me.TabPage_Align.TabIndex = 2
        Me.TabPage_Align.Tag = "Align"
        '
        'Button_SaveAlignParam
        '
        Me.Button_SaveAlignParam.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_SaveAlignParam.Location = New System.Drawing.Point(143, 6)
        Me.Button_SaveAlignParam.Name = "Button_SaveAlignParam"
        Me.Button_SaveAlignParam.Size = New System.Drawing.Size(126, 31)
        Me.Button_SaveAlignParam.TabIndex = 82
        Me.Button_SaveAlignParam.Text = "Save"
        '
        'GroupBox_MT
        '
        Me.GroupBox_MT.Controls.Add(Me.Rdb_ScabType_MT)
        Me.GroupBox_MT.Controls.Add(Me.Rdb_ScabType_Linear)
        Me.GroupBox_MT.Location = New System.Drawing.Point(11, 546)
        Me.GroupBox_MT.Name = "GroupBox_MT"
        Me.GroupBox_MT.Size = New System.Drawing.Size(377, 48)
        Me.GroupBox_MT.TabIndex = 79
        Me.GroupBox_MT.TabStop = False
        Me.GroupBox_MT.Text = "Data\Gate 轉換方式"
        '
        'Rdb_ScabType_MT
        '
        Me.Rdb_ScabType_MT.AutoSize = True
        Me.Rdb_ScabType_MT.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Rdb_ScabType_MT.Location = New System.Drawing.Point(98, 21)
        Me.Rdb_ScabType_MT.Name = "Rdb_ScabType_MT"
        Me.Rdb_ScabType_MT.Size = New System.Drawing.Size(91, 16)
        Me.Rdb_ScabType_MT.TabIndex = 1
        Me.Rdb_ScabType_MT.Text = "MappingTable"
        Me.Rdb_ScabType_MT.UseVisualStyleBackColor = True
        '
        'Rdb_ScabType_Linear
        '
        Me.Rdb_ScabType_Linear.AutoSize = True
        Me.Rdb_ScabType_Linear.Checked = True
        Me.Rdb_ScabType_Linear.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Rdb_ScabType_Linear.Location = New System.Drawing.Point(8, 21)
        Me.Rdb_ScabType_Linear.Name = "Rdb_ScabType_Linear"
        Me.Rdb_ScabType_Linear.Size = New System.Drawing.Size(53, 16)
        Me.Rdb_ScabType_Linear.TabIndex = 0
        Me.Rdb_ScabType_Linear.TabStop = True
        Me.Rdb_ScabType_Linear.Text = "Linear"
        Me.Rdb_ScabType_Linear.UseVisualStyleBackColor = True
        '
        'GroupBox_Local
        '
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalRight)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalRight)
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalLeft)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalLeft)
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalTop)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalBottom)
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalBottom)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalTop)
        Me.GroupBox_Local.Location = New System.Drawing.Point(11, 600)
        Me.GroupBox_Local.Name = "GroupBox_Local"
        Me.GroupBox_Local.Size = New System.Drawing.Size(420, 87)
        Me.GroupBox_Local.TabIndex = 12
        Me.GroupBox_Local.TabStop = False
        Me.GroupBox_Local.Text = "對應位置"
        '
        'NumericUpDown_LocalRight
        '
        Me.NumericUpDown_LocalRight.Location = New System.Drawing.Point(305, 48)
        Me.NumericUpDown_LocalRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalRight.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalRight.Name = "NumericUpDown_LocalRight"
        Me.NumericUpDown_LocalRight.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_LocalRight.TabIndex = 8
        Me.NumericUpDown_LocalRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_LocalRight.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalRight
        '
        Me.Label_LocalRight.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_LocalRight.Location = New System.Drawing.Point(211, 48)
        Me.Label_LocalRight.Name = "Label_LocalRight"
        Me.Label_LocalRight.Size = New System.Drawing.Size(88, 23)
        Me.Label_LocalRight.TabIndex = 7
        Me.Label_LocalRight.Text = "右邊界 :"
        Me.Label_LocalRight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_LocalLeft
        '
        Me.NumericUpDown_LocalLeft.Location = New System.Drawing.Point(102, 47)
        Me.NumericUpDown_LocalLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalLeft.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalLeft.Name = "NumericUpDown_LocalLeft"
        Me.NumericUpDown_LocalLeft.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_LocalLeft.TabIndex = 6
        Me.NumericUpDown_LocalLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_LocalLeft.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalLeft
        '
        Me.Label_LocalLeft.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_LocalLeft.Location = New System.Drawing.Point(8, 48)
        Me.Label_LocalLeft.Name = "Label_LocalLeft"
        Me.Label_LocalLeft.Size = New System.Drawing.Size(88, 23)
        Me.Label_LocalLeft.TabIndex = 5
        Me.Label_LocalLeft.Text = "左邊界 :"
        Me.Label_LocalLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_LocalTop
        '
        Me.NumericUpDown_LocalTop.Location = New System.Drawing.Point(102, 22)
        Me.NumericUpDown_LocalTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalTop.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalTop.Name = "NumericUpDown_LocalTop"
        Me.NumericUpDown_LocalTop.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_LocalTop.TabIndex = 2
        Me.NumericUpDown_LocalTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_LocalTop.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalBottom
        '
        Me.Label_LocalBottom.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_LocalBottom.Location = New System.Drawing.Point(211, 23)
        Me.Label_LocalBottom.Name = "Label_LocalBottom"
        Me.Label_LocalBottom.Size = New System.Drawing.Size(88, 23)
        Me.Label_LocalBottom.TabIndex = 3
        Me.Label_LocalBottom.Text = "下邊界 :"
        Me.Label_LocalBottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_LocalBottom
        '
        Me.NumericUpDown_LocalBottom.Location = New System.Drawing.Point(305, 22)
        Me.NumericUpDown_LocalBottom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalBottom.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalBottom.Name = "NumericUpDown_LocalBottom"
        Me.NumericUpDown_LocalBottom.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_LocalBottom.TabIndex = 4
        Me.NumericUpDown_LocalBottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_LocalBottom.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalTop
        '
        Me.Label_LocalTop.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_LocalTop.Location = New System.Drawing.Point(8, 23)
        Me.Label_LocalTop.Name = "Label_LocalTop"
        Me.Label_LocalTop.Size = New System.Drawing.Size(88, 23)
        Me.Label_LocalTop.TabIndex = 1
        Me.Label_LocalTop.Text = "上邊界 :"
        Me.Label_LocalTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button_Alignment
        '
        Me.Button_Alignment.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_Alignment.Location = New System.Drawing.Point(11, 6)
        Me.Button_Alignment.Name = "Button_Alignment"
        Me.Button_Alignment.Size = New System.Drawing.Size(126, 31)
        Me.Button_Alignment.TabIndex = 61
        Me.Button_Alignment.Text = "Alignment"
        Me.Button_Alignment.UseVisualStyleBackColor = True
        '
        'GroupBox_PanelRotate
        '
        Me.GroupBox_PanelRotate.Controls.Add(Me.CheckBox_PanelMirror)
        Me.GroupBox_PanelRotate.Controls.Add(Me.CheckBox_PanelRotate)
        Me.GroupBox_PanelRotate.Location = New System.Drawing.Point(317, 7)
        Me.GroupBox_PanelRotate.Name = "GroupBox_PanelRotate"
        Me.GroupBox_PanelRotate.Size = New System.Drawing.Size(160, 72)
        Me.GroupBox_PanelRotate.TabIndex = 65
        Me.GroupBox_PanelRotate.TabStop = False
        Me.GroupBox_PanelRotate.Text = "Panel Rotating"
        '
        'CheckBox_PanelMirror
        '
        Me.CheckBox_PanelMirror.AutoSize = True
        Me.CheckBox_PanelMirror.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_PanelMirror.Location = New System.Drawing.Point(6, 48)
        Me.CheckBox_PanelMirror.Name = "CheckBox_PanelMirror"
        Me.CheckBox_PanelMirror.Size = New System.Drawing.Size(110, 16)
        Me.CheckBox_PanelMirror.TabIndex = 1
        Me.CheckBox_PanelMirror.Text = "Panel 座標 Mirror"
        Me.CheckBox_PanelMirror.UseVisualStyleBackColor = True
        '
        'CheckBox_PanelRotate
        '
        Me.CheckBox_PanelRotate.AutoSize = True
        Me.CheckBox_PanelRotate.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_PanelRotate.Location = New System.Drawing.Point(6, 21)
        Me.CheckBox_PanelRotate.Name = "CheckBox_PanelRotate"
        Me.CheckBox_PanelRotate.Size = New System.Drawing.Size(109, 16)
        Me.CheckBox_PanelRotate.TabIndex = 0
        Me.CheckBox_PanelRotate.Text = "Panel 旋轉 180度"
        Me.CheckBox_PanelRotate.UseVisualStyleBackColor = True
        '
        'GroupBox_Alignment
        '
        Me.GroupBox_Alignment.Controls.Add(Me.CheckBox_EnhanceEdge)
        Me.GroupBox_Alignment.Controls.Add(Me.ComboBox_RotateTheta)
        Me.GroupBox_Alignment.Controls.Add(Me.Label12)
        Me.GroupBox_Alignment.Controls.Add(Me.NumericUpDown_AlignTolerance)
        Me.GroupBox_Alignment.Controls.Add(Me.CheckBox_RotateCal)
        Me.GroupBox_Alignment.Controls.Add(Me.Label13)
        Me.GroupBox_Alignment.Controls.Add(Me.NumericUpDown_AlignmentShift)
        Me.GroupBox_Alignment.Location = New System.Drawing.Point(11, 435)
        Me.GroupBox_Alignment.Name = "GroupBox_Alignment"
        Me.GroupBox_Alignment.Size = New System.Drawing.Size(364, 105)
        Me.GroupBox_Alignment.TabIndex = 76
        Me.GroupBox_Alignment.TabStop = False
        Me.GroupBox_Alignment.Text = "Align"
        '
        'CheckBox_EnhanceEdge
        '
        Me.CheckBox_EnhanceEdge.AutoSize = True
        Me.CheckBox_EnhanceEdge.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_EnhanceEdge.Location = New System.Drawing.Point(11, 76)
        Me.CheckBox_EnhanceEdge.Name = "CheckBox_EnhanceEdge"
        Me.CheckBox_EnhanceEdge.Size = New System.Drawing.Size(88, 16)
        Me.CheckBox_EnhanceEdge.TabIndex = 4
        Me.CheckBox_EnhanceEdge.Text = "EnhanceEdge"
        Me.CheckBox_EnhanceEdge.UseVisualStyleBackColor = True
        '
        'ComboBox_RotateTheta
        '
        Me.ComboBox_RotateTheta.FormattingEnabled = True
        Me.ComboBox_RotateTheta.Items.AddRange(New Object() {"TOP", "BOTTOM", "LEFT", "RIGHT", "WARP"})
        Me.ComboBox_RotateTheta.Location = New System.Drawing.Point(221, 74)
        Me.ComboBox_RotateTheta.Name = "ComboBox_RotateTheta"
        Me.ComboBox_RotateTheta.Size = New System.Drawing.Size(135, 20)
        Me.ComboBox_RotateTheta.TabIndex = 79
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label12.Location = New System.Drawing.Point(8, 46)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(92, 12)
        Me.Label12.TabIndex = 76
        Me.Label12.Text = "Align Tolerance："
        '
        'NumericUpDown_AlignTolerance
        '
        Me.NumericUpDown_AlignTolerance.Location = New System.Drawing.Point(132, 43)
        Me.NumericUpDown_AlignTolerance.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_AlignTolerance.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_AlignTolerance.Name = "NumericUpDown_AlignTolerance"
        Me.NumericUpDown_AlignTolerance.Size = New System.Drawing.Size(92, 22)
        Me.NumericUpDown_AlignTolerance.TabIndex = 77
        Me.NumericUpDown_AlignTolerance.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_AlignTolerance.Value = New Decimal(New Integer() {40, 0, 0, 0})
        '
        'CheckBox_RotateCal
        '
        Me.CheckBox_RotateCal.AutoSize = True
        Me.CheckBox_RotateCal.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_RotateCal.Location = New System.Drawing.Point(132, 76)
        Me.CheckBox_RotateCal.Name = "CheckBox_RotateCal"
        Me.CheckBox_RotateCal.Size = New System.Drawing.Size(69, 16)
        Me.CheckBox_RotateCal.TabIndex = 78
        Me.CheckBox_RotateCal.Text = "ImageCal"
        Me.CheckBox_RotateCal.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label13.Location = New System.Drawing.Point(8, 18)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(97, 12)
        Me.Label13.TabIndex = 74
        Me.Label13.Text = "Alignnment Shift："
        '
        'NumericUpDown_AlignmentShift
        '
        Me.NumericUpDown_AlignmentShift.Location = New System.Drawing.Point(132, 16)
        Me.NumericUpDown_AlignmentShift.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_AlignmentShift.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_AlignmentShift.Name = "NumericUpDown_AlignmentShift"
        Me.NumericUpDown_AlignmentShift.Size = New System.Drawing.Size(92, 22)
        Me.NumericUpDown_AlignmentShift.TabIndex = 75
        Me.NumericUpDown_AlignmentShift.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_AlignDirectionAndOffSet
        '
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.NumericUpDown_ShiftOffset_Top)
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.NumericUpDown_ShiftOffset_Left)
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.CheckBox_Func_RightAnalysis)
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.CheckBox_Func_TopAnalysis)
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.CheckBox_Func_BottomAnalysis)
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.NumericUpDown_ShiftOffset_Bottom)
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.NumericUpDown_ShiftOffset_Right)
        Me.GroupBox_AlignDirectionAndOffSet.Controls.Add(Me.CheckBox_Func_LeftAnalysis)
        Me.GroupBox_AlignDirectionAndOffSet.Location = New System.Drawing.Point(11, 257)
        Me.GroupBox_AlignDirectionAndOffSet.Name = "GroupBox_AlignDirectionAndOffSet"
        Me.GroupBox_AlignDirectionAndOffSet.Size = New System.Drawing.Size(345, 172)
        Me.GroupBox_AlignDirectionAndOffSet.TabIndex = 81
        Me.GroupBox_AlignDirectionAndOffSet.TabStop = False
        Me.GroupBox_AlignDirectionAndOffSet.Text = "Align Direction and Offset"
        '
        'NumericUpDown_ShiftOffset_Top
        '
        Me.NumericUpDown_ShiftOffset_Top.Location = New System.Drawing.Point(132, 46)
        Me.NumericUpDown_ShiftOffset_Top.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Top.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Top.Name = "NumericUpDown_ShiftOffset_Top"
        Me.NumericUpDown_ShiftOffset_Top.Size = New System.Drawing.Size(92, 22)
        Me.NumericUpDown_ShiftOffset_Top.TabIndex = 83
        Me.NumericUpDown_ShiftOffset_Top.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_ShiftOffset_Left
        '
        Me.NumericUpDown_ShiftOffset_Left.Location = New System.Drawing.Point(20, 92)
        Me.NumericUpDown_ShiftOffset_Left.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Left.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Left.Name = "NumericUpDown_ShiftOffset_Left"
        Me.NumericUpDown_ShiftOffset_Left.Size = New System.Drawing.Size(92, 22)
        Me.NumericUpDown_ShiftOffset_Left.TabIndex = 82
        Me.NumericUpDown_ShiftOffset_Left.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CheckBox_Func_RightAnalysis
        '
        Me.CheckBox_Func_RightAnalysis.AutoSize = True
        Me.CheckBox_Func_RightAnalysis.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_Func_RightAnalysis.Location = New System.Drawing.Point(230, 67)
        Me.CheckBox_Func_RightAnalysis.Name = "CheckBox_Func_RightAnalysis"
        Me.CheckBox_Func_RightAnalysis.Size = New System.Drawing.Size(92, 16)
        Me.CheckBox_Func_RightAnalysis.TabIndex = 3
        Me.CheckBox_Func_RightAnalysis.Text = "Right Analysis"
        Me.CheckBox_Func_RightAnalysis.UseVisualStyleBackColor = True
        '
        'CheckBox_Func_TopAnalysis
        '
        Me.CheckBox_Func_TopAnalysis.AutoSize = True
        Me.CheckBox_Func_TopAnalysis.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_Func_TopAnalysis.Location = New System.Drawing.Point(126, 24)
        Me.CheckBox_Func_TopAnalysis.Name = "CheckBox_Func_TopAnalysis"
        Me.CheckBox_Func_TopAnalysis.Size = New System.Drawing.Size(85, 16)
        Me.CheckBox_Func_TopAnalysis.TabIndex = 0
        Me.CheckBox_Func_TopAnalysis.Text = "Top Analysis"
        Me.CheckBox_Func_TopAnalysis.UseVisualStyleBackColor = True
        '
        'CheckBox_Func_BottomAnalysis
        '
        Me.CheckBox_Func_BottomAnalysis.AutoSize = True
        Me.CheckBox_Func_BottomAnalysis.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_Func_BottomAnalysis.Location = New System.Drawing.Point(126, 117)
        Me.CheckBox_Func_BottomAnalysis.Name = "CheckBox_Func_BottomAnalysis"
        Me.CheckBox_Func_BottomAnalysis.Size = New System.Drawing.Size(101, 16)
        Me.CheckBox_Func_BottomAnalysis.TabIndex = 2
        Me.CheckBox_Func_BottomAnalysis.Text = "Bottom Analysis"
        Me.CheckBox_Func_BottomAnalysis.UseVisualStyleBackColor = True
        '
        'NumericUpDown_ShiftOffset_Bottom
        '
        Me.NumericUpDown_ShiftOffset_Bottom.Location = New System.Drawing.Point(132, 141)
        Me.NumericUpDown_ShiftOffset_Bottom.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Bottom.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Bottom.Name = "NumericUpDown_ShiftOffset_Bottom"
        Me.NumericUpDown_ShiftOffset_Bottom.Size = New System.Drawing.Size(92, 22)
        Me.NumericUpDown_ShiftOffset_Bottom.TabIndex = 81
        Me.NumericUpDown_ShiftOffset_Bottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_ShiftOffset_Right
        '
        Me.NumericUpDown_ShiftOffset_Right.Location = New System.Drawing.Point(240, 92)
        Me.NumericUpDown_ShiftOffset_Right.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Right.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Right.Name = "NumericUpDown_ShiftOffset_Right"
        Me.NumericUpDown_ShiftOffset_Right.Size = New System.Drawing.Size(92, 22)
        Me.NumericUpDown_ShiftOffset_Right.TabIndex = 80
        Me.NumericUpDown_ShiftOffset_Right.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CheckBox_Func_LeftAnalysis
        '
        Me.CheckBox_Func_LeftAnalysis.AutoSize = True
        Me.CheckBox_Func_LeftAnalysis.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_Func_LeftAnalysis.Location = New System.Drawing.Point(14, 67)
        Me.CheckBox_Func_LeftAnalysis.Name = "CheckBox_Func_LeftAnalysis"
        Me.CheckBox_Func_LeftAnalysis.Size = New System.Drawing.Size(85, 16)
        Me.CheckBox_Func_LeftAnalysis.TabIndex = 1
        Me.CheckBox_Func_LeftAnalysis.Text = "Left Analysis"
        Me.CheckBox_Func_LeftAnalysis.UseVisualStyleBackColor = True
        '
        'GroupBox_BoundaryModify
        '
        Me.GroupBox_BoundaryModify.Controls.Add(Me.Button_Quick_Edge)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryManual)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryFinish)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.CheckBox_AlignShowBoundary)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.GroupBox_Boundary)
        Me.GroupBox_BoundaryModify.Location = New System.Drawing.Point(11, 82)
        Me.GroupBox_BoundaryModify.Name = "GroupBox_BoundaryModify"
        Me.GroupBox_BoundaryModify.Size = New System.Drawing.Size(420, 169)
        Me.GroupBox_BoundaryModify.TabIndex = 0
        Me.GroupBox_BoundaryModify.TabStop = False
        Me.GroupBox_BoundaryModify.Text = "可視區分析參數調整"
        '
        'Button_Quick_Edge
        '
        Me.Button_Quick_Edge.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_Quick_Edge.Location = New System.Drawing.Point(244, 142)
        Me.Button_Quick_Edge.Name = "Button_Quick_Edge"
        Me.Button_Quick_Edge.Size = New System.Drawing.Size(165, 23)
        Me.Button_Quick_Edge.TabIndex = 58
        Me.Button_Quick_Edge.Text = "Quick Edge"
        Me.Button_Quick_Edge.UseVisualStyleBackColor = True
        Me.Button_Quick_Edge.Visible = False
        '
        'RadioButton_BoundaryManual
        '
        Me.RadioButton_BoundaryManual.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BoundaryManual.Location = New System.Drawing.Point(163, 18)
        Me.RadioButton_BoundaryManual.Name = "RadioButton_BoundaryManual"
        Me.RadioButton_BoundaryManual.Size = New System.Drawing.Size(143, 36)
        Me.RadioButton_BoundaryManual.TabIndex = 14
        Me.RadioButton_BoundaryManual.Text = "手動設定 (Adjust)"
        '
        'RadioButton_BoundaryFinish
        '
        Me.RadioButton_BoundaryFinish.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BoundaryFinish.Location = New System.Drawing.Point(12, 18)
        Me.RadioButton_BoundaryFinish.Name = "RadioButton_BoundaryFinish"
        Me.RadioButton_BoundaryFinish.Size = New System.Drawing.Size(145, 36)
        Me.RadioButton_BoundaryFinish.TabIndex = 12
        Me.RadioButton_BoundaryFinish.Text = "完成設定 (Finsh)"
        '
        'CheckBox_AlignShowBoundary
        '
        Me.CheckBox_AlignShowBoundary.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_AlignShowBoundary.Location = New System.Drawing.Point(312, 24)
        Me.CheckBox_AlignShowBoundary.Name = "CheckBox_AlignShowBoundary"
        Me.CheckBox_AlignShowBoundary.Size = New System.Drawing.Size(108, 24)
        Me.CheckBox_AlignShowBoundary.TabIndex = 15
        Me.CheckBox_AlignShowBoundary.Text = "顯示(Show)"
        '
        'GroupBox_Boundary
        '
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryTop)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryTop)
        Me.GroupBox_Boundary.Enabled = False
        Me.GroupBox_Boundary.Location = New System.Drawing.Point(8, 60)
        Me.GroupBox_Boundary.Name = "GroupBox_Boundary"
        Me.GroupBox_Boundary.Size = New System.Drawing.Size(401, 80)
        Me.GroupBox_Boundary.TabIndex = 13
        Me.GroupBox_Boundary.TabStop = False
        Me.GroupBox_Boundary.Text = "分析參數"
        '
        'NumericUpDown_BoundaryRight
        '
        Me.NumericUpDown_BoundaryRight.Location = New System.Drawing.Point(292, 51)
        Me.NumericUpDown_BoundaryRight.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryRight.Name = "NumericUpDown_BoundaryRight"
        Me.NumericUpDown_BoundaryRight.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_BoundaryRight.TabIndex = 8
        Me.NumericUpDown_BoundaryRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryRight
        '
        Me.Label_BoundaryRight.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_BoundaryRight.Location = New System.Drawing.Point(203, 52)
        Me.Label_BoundaryRight.Name = "Label_BoundaryRight"
        Me.Label_BoundaryRight.Size = New System.Drawing.Size(80, 23)
        Me.Label_BoundaryRight.TabIndex = 7
        Me.Label_BoundaryRight.Text = "右邊界 :"
        Me.Label_BoundaryRight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BoundaryLeft
        '
        Me.NumericUpDown_BoundaryLeft.Location = New System.Drawing.Point(94, 51)
        Me.NumericUpDown_BoundaryLeft.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BoundaryLeft.Name = "NumericUpDown_BoundaryLeft"
        Me.NumericUpDown_BoundaryLeft.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_BoundaryLeft.TabIndex = 6
        Me.NumericUpDown_BoundaryLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryLeft
        '
        Me.Label_BoundaryLeft.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_BoundaryLeft.Location = New System.Drawing.Point(8, 54)
        Me.Label_BoundaryLeft.Name = "Label_BoundaryLeft"
        Me.Label_BoundaryLeft.Size = New System.Drawing.Size(80, 23)
        Me.Label_BoundaryLeft.TabIndex = 5
        Me.Label_BoundaryLeft.Text = "左邊界 :"
        Me.Label_BoundaryLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BoundaryTop
        '
        Me.NumericUpDown_BoundaryTop.Location = New System.Drawing.Point(94, 26)
        Me.NumericUpDown_BoundaryTop.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BoundaryTop.Name = "NumericUpDown_BoundaryTop"
        Me.NumericUpDown_BoundaryTop.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_BoundaryTop.TabIndex = 2
        Me.NumericUpDown_BoundaryTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryBottom
        '
        Me.Label_BoundaryBottom.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_BoundaryBottom.Location = New System.Drawing.Point(203, 27)
        Me.Label_BoundaryBottom.Name = "Label_BoundaryBottom"
        Me.Label_BoundaryBottom.Size = New System.Drawing.Size(80, 23)
        Me.Label_BoundaryBottom.TabIndex = 3
        Me.Label_BoundaryBottom.Text = "下邊界 :"
        Me.Label_BoundaryBottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BoundaryBottom
        '
        Me.NumericUpDown_BoundaryBottom.Location = New System.Drawing.Point(292, 26)
        Me.NumericUpDown_BoundaryBottom.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown_BoundaryBottom.Name = "NumericUpDown_BoundaryBottom"
        Me.NumericUpDown_BoundaryBottom.Size = New System.Drawing.Size(103, 22)
        Me.NumericUpDown_BoundaryBottom.TabIndex = 4
        Me.NumericUpDown_BoundaryBottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryTop
        '
        Me.Label_BoundaryTop.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_BoundaryTop.Location = New System.Drawing.Point(8, 27)
        Me.Label_BoundaryTop.Name = "Label_BoundaryTop"
        Me.Label_BoundaryTop.Size = New System.Drawing.Size(80, 23)
        Me.Label_BoundaryTop.TabIndex = 1
        Me.Label_BoundaryTop.Text = "上邊界 :"
        Me.Label_BoundaryTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RadioButton_AlignType_Circle
        '
        Me.RadioButton_AlignType_Circle.AutoSize = True
        Me.RadioButton_AlignType_Circle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_AlignType_Circle.Location = New System.Drawing.Point(249, 54)
        Me.RadioButton_AlignType_Circle.Name = "RadioButton_AlignType_Circle"
        Me.RadioButton_AlignType_Circle.Size = New System.Drawing.Size(51, 16)
        Me.RadioButton_AlignType_Circle.TabIndex = 53
        Me.RadioButton_AlignType_Circle.Text = "Circle"
        Me.RadioButton_AlignType_Circle.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label11.Location = New System.Drawing.Point(9, 56)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(99, 12)
        Me.Label11.TabIndex = 80
        Me.Label11.Text = "Alignnment Type："
        '
        'RadioButton_AlignType_Rectangle
        '
        Me.RadioButton_AlignType_Rectangle.AutoSize = True
        Me.RadioButton_AlignType_Rectangle.Checked = True
        Me.RadioButton_AlignType_Rectangle.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_AlignType_Rectangle.Location = New System.Drawing.Point(143, 54)
        Me.RadioButton_AlignType_Rectangle.Name = "RadioButton_AlignType_Rectangle"
        Me.RadioButton_AlignType_Rectangle.Size = New System.Drawing.Size(69, 16)
        Me.RadioButton_AlignType_Rectangle.TabIndex = 53
        Me.RadioButton_AlignType_Rectangle.TabStop = True
        Me.RadioButton_AlignType_Rectangle.Text = "Rectangle"
        Me.RadioButton_AlignType_Rectangle.UseVisualStyleBackColor = True
        '
        'TabPage_FuncParam
        '
        Me.TabPage_FuncParam.AutoScroll = True
        Me.TabPage_FuncParam.BackColor = System.Drawing.Color.Bisque
        Me.TabPage_FuncParam.Controls.Add(Me.Button_SaveFuncParam)
        Me.TabPage_FuncParam.Controls.Add(Me.Panel_FuncParam)
        Me.TabPage_FuncParam.Controls.Add(Me.TreeView_FuncParamPattern)
        Me.TabPage_FuncParam.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_FuncParam.Name = "TabPage_FuncParam"
        Me.TabPage_FuncParam.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_FuncParam.Size = New System.Drawing.Size(529, 484)
        Me.TabPage_FuncParam.TabIndex = 3
        Me.TabPage_FuncParam.Tag = "FuncParam"
        '
        'Button_SaveFuncParam
        '
        Me.Button_SaveFuncParam.BackColor = System.Drawing.Color.Beige
        Me.Button_SaveFuncParam.Font = New System.Drawing.Font("新細明體", 12.0!)
        Me.Button_SaveFuncParam.Location = New System.Drawing.Point(6, 4)
        Me.Button_SaveFuncParam.Name = "Button_SaveFuncParam"
        Me.Button_SaveFuncParam.Size = New System.Drawing.Size(125, 39)
        Me.Button_SaveFuncParam.TabIndex = 59
        Me.Button_SaveFuncParam.Text = "儲存"
        Me.Button_SaveFuncParam.UseVisualStyleBackColor = False
        '
        'Panel_FuncParam
        '
        Me.Panel_FuncParam.AutoScroll = True
        Me.Panel_FuncParam.BackColor = System.Drawing.Color.Bisque
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_GrayAbnormal)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_GrayAbnormal_Enable)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_DLine)
        Me.Panel_FuncParam.Controls.Add(Me.Label_SplitLine)
        Me.Panel_FuncParam.Controls.Add(Me.Label_SplitPoint)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_DLine_Enable)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_ImgProcBoundary)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_LinePitchSetting)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_PointMode)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_BLine_Enable)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_LineAverageFilter)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_Point_Algorithm)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_BLine)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_VLine_NotAddToOutput)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_PointPitchSetting)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_DP_Characteristics)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_HLine_NotAddToOutput)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_Point_Enable)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_BP_Characteristics)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_LineCommonSetting)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_BPoint)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_PointCommonSetting)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_Line_Enable)
        Me.Panel_FuncParam.Controls.Add(Me.CheckBox_Align_Enable)
        Me.Panel_FuncParam.Controls.Add(Me.GroupBox_DPoint)
        Me.Panel_FuncParam.Font = New System.Drawing.Font("微軟正黑體", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Panel_FuncParam.Location = New System.Drawing.Point(137, 3)
        Me.Panel_FuncParam.Name = "Panel_FuncParam"
        Me.Panel_FuncParam.Size = New System.Drawing.Size(384, 475)
        Me.Panel_FuncParam.TabIndex = 2
        '
        'GroupBox_GrayAbnormal
        '
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Lbl_GrayAbnormal_NegLimit)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Lbl_GrayAbnormal_PosLimit)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.NumericUpDown_GrayAbnormal_NegLimit)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label22)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label23)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label17)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label19)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label20)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.NumericUpDown_GrayAbnormalStandardGray)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.NumericUpDown_GrayAbnormal_PosLimit)
        Me.GroupBox_GrayAbnormal.Enabled = False
        Me.GroupBox_GrayAbnormal.Location = New System.Drawing.Point(7, 469)
        Me.GroupBox_GrayAbnormal.Name = "GroupBox_GrayAbnormal"
        Me.GroupBox_GrayAbnormal.Size = New System.Drawing.Size(350, 112)
        Me.GroupBox_GrayAbnormal.TabIndex = 58
        Me.GroupBox_GrayAbnormal.TabStop = False
        Me.GroupBox_GrayAbnormal.Text = "Gray Abnormal"
        '
        'Lbl_GrayAbnormal_NegLimit
        '
        Me.Lbl_GrayAbnormal_NegLimit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_NegLimit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Lbl_GrayAbnormal_NegLimit.Location = New System.Drawing.Point(216, 59)
        Me.Lbl_GrayAbnormal_NegLimit.Name = "Lbl_GrayAbnormal_NegLimit"
        Me.Lbl_GrayAbnormal_NegLimit.Size = New System.Drawing.Size(43, 15)
        Me.Lbl_GrayAbnormal_NegLimit.TabIndex = 20
        Me.Lbl_GrayAbnormal_NegLimit.Text = "0"
        Me.Lbl_GrayAbnormal_NegLimit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Lbl_GrayAbnormal_PosLimit
        '
        Me.Lbl_GrayAbnormal_PosLimit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_PosLimit.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Lbl_GrayAbnormal_PosLimit.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Lbl_GrayAbnormal_PosLimit.Location = New System.Drawing.Point(216, 32)
        Me.Lbl_GrayAbnormal_PosLimit.Name = "Lbl_GrayAbnormal_PosLimit"
        Me.Lbl_GrayAbnormal_PosLimit.Size = New System.Drawing.Size(43, 15)
        Me.Lbl_GrayAbnormal_PosLimit.TabIndex = 19
        Me.Lbl_GrayAbnormal_PosLimit.Text = "0"
        Me.Lbl_GrayAbnormal_PosLimit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_GrayAbnormal_NegLimit
        '
        Me.NumericUpDown_GrayAbnormal_NegLimit.Location = New System.Drawing.Point(123, 53)
        Me.NumericUpDown_GrayAbnormal_NegLimit.Name = "NumericUpDown_GrayAbnormal_NegLimit"
        Me.NumericUpDown_GrayAbnormal_NegLimit.Size = New System.Drawing.Size(50, 23)
        Me.NumericUpDown_GrayAbnormal_NegLimit.TabIndex = 18
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label22.Location = New System.Drawing.Point(7, 57)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(90, 16)
        Me.Label22.TabIndex = 16
        Me.Label22.Text = "Negative Limit"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("新細明體", 11.25!)
        Me.Label23.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label23.Location = New System.Drawing.Point(176, 59)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(35, 15)
        Me.Label23.TabIndex = 17
        Me.Label23.Text = "% = "
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label17.Location = New System.Drawing.Point(7, 84)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(86, 16)
        Me.Label17.TabIndex = 12
        Me.Label17.Text = "StandardGray"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label19.Location = New System.Drawing.Point(7, 30)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(81, 16)
        Me.Label19.TabIndex = 12
        Me.Label19.Text = "Positive Limit"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("新細明體", 11.25!)
        Me.Label20.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label20.Location = New System.Drawing.Point(176, 32)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(35, 15)
        Me.Label20.TabIndex = 13
        Me.Label20.Text = "% = "
        '
        'NumericUpDown_GrayAbnormalStandardGray
        '
        Me.NumericUpDown_GrayAbnormalStandardGray.Location = New System.Drawing.Point(123, 80)
        Me.NumericUpDown_GrayAbnormalStandardGray.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GrayAbnormalStandardGray.Name = "NumericUpDown_GrayAbnormalStandardGray"
        Me.NumericUpDown_GrayAbnormalStandardGray.Size = New System.Drawing.Size(50, 23)
        Me.NumericUpDown_GrayAbnormalStandardGray.TabIndex = 12
        '
        'NumericUpDown_GrayAbnormal_PosLimit
        '
        Me.NumericUpDown_GrayAbnormal_PosLimit.Location = New System.Drawing.Point(123, 26)
        Me.NumericUpDown_GrayAbnormal_PosLimit.Name = "NumericUpDown_GrayAbnormal_PosLimit"
        Me.NumericUpDown_GrayAbnormal_PosLimit.Size = New System.Drawing.Size(50, 23)
        Me.NumericUpDown_GrayAbnormal_PosLimit.TabIndex = 12
        '
        'CheckBox_GrayAbnormal_Enable
        '
        Me.CheckBox_GrayAbnormal_Enable.AutoSize = True
        Me.CheckBox_GrayAbnormal_Enable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_GrayAbnormal_Enable.Location = New System.Drawing.Point(162, 67)
        Me.CheckBox_GrayAbnormal_Enable.Name = "CheckBox_GrayAbnormal_Enable"
        Me.CheckBox_GrayAbnormal_Enable.Size = New System.Drawing.Size(136, 20)
        Me.CheckBox_GrayAbnormal_Enable.TabIndex = 57
        Me.CheckBox_GrayAbnormal_Enable.Text = "檢查Gray Abnormal"
        Me.CheckBox_GrayAbnormal_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_DLine
        '
        Me.GroupBox_DLine.Controls.Add(Me.RadioButton_DL_Threshold)
        Me.GroupBox_DLine.Controls.Add(Me.NumericUpDown_DL_Threshold)
        Me.GroupBox_DLine.Controls.Add(Me.Label18)
        Me.GroupBox_DLine.Controls.Add(Me.NumericUpDown_DL_RimThreshold)
        Me.GroupBox_DLine.Location = New System.Drawing.Point(8, 1817)
        Me.GroupBox_DLine.Name = "GroupBox_DLine"
        Me.GroupBox_DLine.Size = New System.Drawing.Size(349, 78)
        Me.GroupBox_DLine.TabIndex = 54
        Me.GroupBox_DLine.TabStop = False
        Me.GroupBox_DLine.Text = "DLine"
        '
        'RadioButton_DL_Threshold
        '
        Me.RadioButton_DL_Threshold.AutoSize = True
        Me.RadioButton_DL_Threshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_DL_Threshold.Location = New System.Drawing.Point(11, 18)
        Me.RadioButton_DL_Threshold.Name = "RadioButton_DL_Threshold"
        Me.RadioButton_DL_Threshold.Size = New System.Drawing.Size(102, 20)
        Me.RadioButton_DL_Threshold.TabIndex = 14
        Me.RadioButton_DL_Threshold.Text = "DL_Threshold"
        Me.RadioButton_DL_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DL_Threshold
        '
        Me.NumericUpDown_DL_Threshold.Enabled = False
        Me.NumericUpDown_DL_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DL_Threshold.Location = New System.Drawing.Point(157, 16)
        Me.NumericUpDown_DL_Threshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_DL_Threshold.Name = "NumericUpDown_DL_Threshold"
        Me.NumericUpDown_DL_Threshold.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_DL_Threshold.TabIndex = 3
        Me.NumericUpDown_DL_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label18.Location = New System.Drawing.Point(8, 47)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(107, 16)
        Me.Label18.TabIndex = 27
        Me.Label18.Text = "DL Rim Threshold"
        '
        'NumericUpDown_DL_RimThreshold
        '
        Me.NumericUpDown_DL_RimThreshold.Enabled = False
        Me.NumericUpDown_DL_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DL_RimThreshold.Location = New System.Drawing.Point(157, 43)
        Me.NumericUpDown_DL_RimThreshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_DL_RimThreshold.Name = "NumericUpDown_DL_RimThreshold"
        Me.NumericUpDown_DL_RimThreshold.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_DL_RimThreshold.TabIndex = 25
        Me.NumericUpDown_DL_RimThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_SplitLine
        '
        Me.Label_SplitLine.AutoSize = True
        Me.Label_SplitLine.Font = New System.Drawing.Font("細明體", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label_SplitLine.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_SplitLine.Location = New System.Drawing.Point(28, 1678)
        Me.Label_SplitLine.Name = "Label_SplitLine"
        Me.Label_SplitLine.Size = New System.Drawing.Size(233, 12)
        Me.Label_SplitLine.TabIndex = 48
        Me.Label_SplitLine.Text = "---------------- Line ----------------"
        '
        'Label_SplitPoint
        '
        Me.Label_SplitPoint.AutoSize = True
        Me.Label_SplitPoint.Font = New System.Drawing.Font("細明體", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label_SplitPoint.Location = New System.Drawing.Point(20, 655)
        Me.Label_SplitPoint.Name = "Label_SplitPoint"
        Me.Label_SplitPoint.Size = New System.Drawing.Size(239, 12)
        Me.Label_SplitPoint.TabIndex = 47
        Me.Label_SplitPoint.Text = "---------------- Point ----------------"
        '
        'CheckBox_DLine_Enable
        '
        Me.CheckBox_DLine_Enable.AutoSize = True
        Me.CheckBox_DLine_Enable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_DLine_Enable.Location = New System.Drawing.Point(162, 36)
        Me.CheckBox_DLine_Enable.Name = "CheckBox_DLine_Enable"
        Me.CheckBox_DLine_Enable.Size = New System.Drawing.Size(105, 20)
        Me.CheckBox_DLine_Enable.TabIndex = 56
        Me.CheckBox_DLine_Enable.Text = "暗線檢 Enable"
        Me.CheckBox_DLine_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_ImgProcBoundary
        '
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_RX)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label29)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label30)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label27)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_BY)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label28)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_LX)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label25)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label15)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_TY)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label24)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label26)
        Me.GroupBox_ImgProcBoundary.Location = New System.Drawing.Point(7, 338)
        Me.GroupBox_ImgProcBoundary.Name = "GroupBox_ImgProcBoundary"
        Me.GroupBox_ImgProcBoundary.Size = New System.Drawing.Size(350, 125)
        Me.GroupBox_ImgProcBoundary.TabIndex = 46
        Me.GroupBox_ImgProcBoundary.TabStop = False
        Me.GroupBox_ImgProcBoundary.Text = "ImgProc Boundary"
        '
        'NumericUpDown_Boundary_MulWidth_RX
        '
        Me.NumericUpDown_Boundary_MulWidth_RX.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.NumericUpDown_Boundary_MulWidth_RX.Location = New System.Drawing.Point(192, 45)
        Me.NumericUpDown_Boundary_MulWidth_RX.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_RX.Name = "NumericUpDown_Boundary_MulWidth_RX"
        Me.NumericUpDown_Boundary_MulWidth_RX.Size = New System.Drawing.Size(59, 23)
        Me.NumericUpDown_Boundary_MulWidth_RX.TabIndex = 30
        Me.NumericUpDown_Boundary_MulWidth_RX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label29.Location = New System.Drawing.Point(7, 51)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(133, 16)
        Me.Label29.TabIndex = 29
        Me.Label29.Text = "Boundary Width RX = "
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label30.Location = New System.Drawing.Point(274, 51)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(54, 16)
        Me.Label30.TabIndex = 31
        Me.Label30.Text = "* PitchX "
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label27.Location = New System.Drawing.Point(274, 101)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(53, 16)
        Me.Label27.TabIndex = 28
        Me.Label27.Text = "* PitchY "
        '
        'NumericUpDown_Boundary_MulWidth_BY
        '
        Me.NumericUpDown_Boundary_MulWidth_BY.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.NumericUpDown_Boundary_MulWidth_BY.Location = New System.Drawing.Point(192, 95)
        Me.NumericUpDown_Boundary_MulWidth_BY.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_BY.Name = "NumericUpDown_Boundary_MulWidth_BY"
        Me.NumericUpDown_Boundary_MulWidth_BY.Size = New System.Drawing.Size(59, 23)
        Me.NumericUpDown_Boundary_MulWidth_BY.TabIndex = 27
        Me.NumericUpDown_Boundary_MulWidth_BY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label28.Location = New System.Drawing.Point(7, 101)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(131, 16)
        Me.Label28.TabIndex = 26
        Me.Label28.Text = "Boundary Width BY = "
        '
        'NumericUpDown_Boundary_MulWidth_LX
        '
        Me.NumericUpDown_Boundary_MulWidth_LX.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.NumericUpDown_Boundary_MulWidth_LX.Location = New System.Drawing.Point(192, 20)
        Me.NumericUpDown_Boundary_MulWidth_LX.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_LX.Name = "NumericUpDown_Boundary_MulWidth_LX"
        Me.NumericUpDown_Boundary_MulWidth_LX.Size = New System.Drawing.Size(59, 23)
        Me.NumericUpDown_Boundary_MulWidth_LX.TabIndex = 21
        Me.NumericUpDown_Boundary_MulWidth_LX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label25.Location = New System.Drawing.Point(274, 76)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(53, 16)
        Me.Label25.TabIndex = 25
        Me.Label25.Text = "* PitchY "
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("細明體", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label15.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label15.Location = New System.Drawing.Point(7, 26)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(125, 12)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "Boundary Width LX = "
        '
        'NumericUpDown_Boundary_MulWidth_TY
        '
        Me.NumericUpDown_Boundary_MulWidth_TY.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.NumericUpDown_Boundary_MulWidth_TY.Location = New System.Drawing.Point(192, 70)
        Me.NumericUpDown_Boundary_MulWidth_TY.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_TY.Name = "NumericUpDown_Boundary_MulWidth_TY"
        Me.NumericUpDown_Boundary_MulWidth_TY.Size = New System.Drawing.Size(59, 23)
        Me.NumericUpDown_Boundary_MulWidth_TY.TabIndex = 24
        Me.NumericUpDown_Boundary_MulWidth_TY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label24.Location = New System.Drawing.Point(274, 26)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(54, 16)
        Me.Label24.TabIndex = 22
        Me.Label24.Text = "* PitchX "
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label26.Location = New System.Drawing.Point(7, 76)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(131, 16)
        Me.Label26.TabIndex = 23
        Me.Label26.Text = "Boundary Width TY = "
        '
        'GroupBox_LinePitchSetting
        '
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.NumericUpDown_Line_PitchY)
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.NumericUpDown_Line_PitchX)
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.Label_LinePitchY)
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.Label_LinePitchX)
        Me.GroupBox_LinePitchSetting.Location = New System.Drawing.Point(7, 157)
        Me.GroupBox_LinePitchSetting.Name = "GroupBox_LinePitchSetting"
        Me.GroupBox_LinePitchSetting.Size = New System.Drawing.Size(246, 55)
        Me.GroupBox_LinePitchSetting.TabIndex = 45
        Me.GroupBox_LinePitchSetting.TabStop = False
        Me.GroupBox_LinePitchSetting.Text = "Line Pitch Setting"
        '
        'NumericUpDown_Line_PitchY
        '
        Me.NumericUpDown_Line_PitchY.Location = New System.Drawing.Point(186, 20)
        Me.NumericUpDown_Line_PitchY.Name = "NumericUpDown_Line_PitchY"
        Me.NumericUpDown_Line_PitchY.Size = New System.Drawing.Size(52, 23)
        Me.NumericUpDown_Line_PitchY.TabIndex = 3
        Me.NumericUpDown_Line_PitchY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_Line_PitchX
        '
        Me.NumericUpDown_Line_PitchX.Location = New System.Drawing.Point(68, 20)
        Me.NumericUpDown_Line_PitchX.Name = "NumericUpDown_Line_PitchX"
        Me.NumericUpDown_Line_PitchX.Size = New System.Drawing.Size(52, 23)
        Me.NumericUpDown_Line_PitchX.TabIndex = 2
        Me.NumericUpDown_Line_PitchX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_LinePitchY
        '
        Me.Label_LinePitchY.AutoSize = True
        Me.Label_LinePitchY.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_LinePitchY.Location = New System.Drawing.Point(126, 24)
        Me.Label_LinePitchY.Name = "Label_LinePitchY"
        Me.Label_LinePitchY.Size = New System.Drawing.Size(42, 16)
        Me.Label_LinePitchY.TabIndex = 1
        Me.Label_LinePitchY.Text = "PitchY"
        '
        'Label_LinePitchX
        '
        Me.Label_LinePitchX.AutoSize = True
        Me.Label_LinePitchX.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_LinePitchX.Location = New System.Drawing.Point(9, 24)
        Me.Label_LinePitchX.Name = "Label_LinePitchX"
        Me.Label_LinePitchX.Size = New System.Drawing.Size(43, 16)
        Me.Label_LinePitchX.TabIndex = 0
        Me.Label_LinePitchX.Text = "PitchX"
        '
        'GroupBox_PointMode
        '
        Me.GroupBox_PointMode.Controls.Add(Me.RadioButton_BPDP)
        Me.GroupBox_PointMode.Controls.Add(Me.RadioButton_DP)
        Me.GroupBox_PointMode.Controls.Add(Me.RadioButton_BP)
        Me.GroupBox_PointMode.Location = New System.Drawing.Point(7, 587)
        Me.GroupBox_PointMode.Name = "GroupBox_PointMode"
        Me.GroupBox_PointMode.Size = New System.Drawing.Size(350, 59)
        Me.GroupBox_PointMode.TabIndex = 13
        Me.GroupBox_PointMode.TabStop = False
        Me.GroupBox_PointMode.Text = "Point Mode"
        '
        'RadioButton_BPDP
        '
        Me.RadioButton_BPDP.AutoSize = True
        Me.RadioButton_BPDP.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BPDP.Location = New System.Drawing.Point(176, 24)
        Me.RadioButton_BPDP.Name = "RadioButton_BPDP"
        Me.RadioButton_BPDP.Size = New System.Drawing.Size(89, 20)
        Me.RadioButton_BPDP.TabIndex = 2
        Me.RadioButton_BPDP.TabStop = True
        Me.RadioButton_BPDP.Text = "檢查BP+DP"
        Me.RadioButton_BPDP.UseVisualStyleBackColor = True
        '
        'RadioButton_DP
        '
        Me.RadioButton_DP.AutoSize = True
        Me.RadioButton_DP.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_DP.Location = New System.Drawing.Point(90, 24)
        Me.RadioButton_DP.Name = "RadioButton_DP"
        Me.RadioButton_DP.Size = New System.Drawing.Size(66, 20)
        Me.RadioButton_DP.TabIndex = 1
        Me.RadioButton_DP.TabStop = True
        Me.RadioButton_DP.Text = "檢查DP"
        Me.RadioButton_DP.UseVisualStyleBackColor = True
        '
        'RadioButton_BP
        '
        Me.RadioButton_BP.AutoSize = True
        Me.RadioButton_BP.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BP.Location = New System.Drawing.Point(6, 24)
        Me.RadioButton_BP.Name = "RadioButton_BP"
        Me.RadioButton_BP.Size = New System.Drawing.Size(64, 20)
        Me.RadioButton_BP.TabIndex = 0
        Me.RadioButton_BP.TabStop = True
        Me.RadioButton_BP.Text = "檢查BP"
        Me.RadioButton_BP.UseVisualStyleBackColor = True
        '
        'CheckBox_BLine_Enable
        '
        Me.CheckBox_BLine_Enable.AutoSize = True
        Me.CheckBox_BLine_Enable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_BLine_Enable.Location = New System.Drawing.Point(6, 36)
        Me.CheckBox_BLine_Enable.Name = "CheckBox_BLine_Enable"
        Me.CheckBox_BLine_Enable.Size = New System.Drawing.Size(105, 20)
        Me.CheckBox_BLine_Enable.TabIndex = 55
        Me.CheckBox_BLine_Enable.Text = "亮線檢 Enable"
        Me.CheckBox_BLine_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_LineAverageFilter
        '
        Me.GroupBox_LineAverageFilter.Controls.Add(Me.Label44)
        Me.GroupBox_LineAverageFilter.Controls.Add(Me.NumericUpDown_AverageFilter)
        Me.GroupBox_LineAverageFilter.Location = New System.Drawing.Point(7, 218)
        Me.GroupBox_LineAverageFilter.Name = "GroupBox_LineAverageFilter"
        Me.GroupBox_LineAverageFilter.Size = New System.Drawing.Size(167, 55)
        Me.GroupBox_LineAverageFilter.TabIndex = 44
        Me.GroupBox_LineAverageFilter.TabStop = False
        Me.GroupBox_LineAverageFilter.Text = "Average Filter"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label44.Location = New System.Drawing.Point(7, 23)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(62, 16)
        Me.Label44.TabIndex = 4
        Me.Label44.Text = "Ave. Pitch"
        '
        'NumericUpDown_AverageFilter
        '
        Me.NumericUpDown_AverageFilter.Location = New System.Drawing.Point(99, 19)
        Me.NumericUpDown_AverageFilter.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDown_AverageFilter.Name = "NumericUpDown_AverageFilter"
        Me.NumericUpDown_AverageFilter.Size = New System.Drawing.Size(54, 23)
        Me.NumericUpDown_AverageFilter.TabIndex = 27
        Me.NumericUpDown_AverageFilter.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_Point_Algorithm
        '
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_3)
        Me.GroupBox_Point_Algorithm.Location = New System.Drawing.Point(7, 277)
        Me.GroupBox_Point_Algorithm.Name = "GroupBox_Point_Algorithm"
        Me.GroupBox_Point_Algorithm.Size = New System.Drawing.Size(205, 55)
        Me.GroupBox_Point_Algorithm.TabIndex = 43
        Me.GroupBox_Point_Algorithm.TabStop = False
        Me.GroupBox_Point_Algorithm.Text = "Point Algorithm"
        '
        'RadioButton_PointAlgorithm_3
        '
        Me.RadioButton_PointAlgorithm_3.AutoSize = True
        Me.RadioButton_PointAlgorithm_3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_PointAlgorithm_3.Location = New System.Drawing.Point(8, 26)
        Me.RadioButton_PointAlgorithm_3.Name = "RadioButton_PointAlgorithm_3"
        Me.RadioButton_PointAlgorithm_3.Size = New System.Drawing.Size(157, 20)
        Me.RadioButton_PointAlgorithm_3.TabIndex = 14
        Me.RadioButton_PointAlgorithm_3.Text = "5x5 Gray Ratio Method"
        Me.RadioButton_PointAlgorithm_3.UseVisualStyleBackColor = True
        '
        'GroupBox_BLine
        '
        Me.GroupBox_BLine.Controls.Add(Me.Label16)
        Me.GroupBox_BLine.Controls.Add(Me.NumericUpDown_BL_RimThreshold)
        Me.GroupBox_BLine.Controls.Add(Me.RadioButton_BL_Threshold)
        Me.GroupBox_BLine.Controls.Add(Me.NumericUpDown_BL_Threshold)
        Me.GroupBox_BLine.Enabled = False
        Me.GroupBox_BLine.Location = New System.Drawing.Point(8, 1737)
        Me.GroupBox_BLine.Name = "GroupBox_BLine"
        Me.GroupBox_BLine.Size = New System.Drawing.Size(349, 74)
        Me.GroupBox_BLine.TabIndex = 53
        Me.GroupBox_BLine.TabStop = False
        Me.GroupBox_BLine.Text = "BLine"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label16.Location = New System.Drawing.Point(8, 46)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(105, 16)
        Me.Label16.TabIndex = 30
        Me.Label16.Text = "BL Rim Threshold"
        '
        'NumericUpDown_BL_RimThreshold
        '
        Me.NumericUpDown_BL_RimThreshold.Enabled = False
        Me.NumericUpDown_BL_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BL_RimThreshold.Location = New System.Drawing.Point(157, 42)
        Me.NumericUpDown_BL_RimThreshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_BL_RimThreshold.Name = "NumericUpDown_BL_RimThreshold"
        Me.NumericUpDown_BL_RimThreshold.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_BL_RimThreshold.TabIndex = 28
        Me.NumericUpDown_BL_RimThreshold.Tag = ""
        Me.NumericUpDown_BL_RimThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_BL_Threshold
        '
        Me.RadioButton_BL_Threshold.AutoSize = True
        Me.RadioButton_BL_Threshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BL_Threshold.Location = New System.Drawing.Point(11, 15)
        Me.RadioButton_BL_Threshold.Name = "RadioButton_BL_Threshold"
        Me.RadioButton_BL_Threshold.Size = New System.Drawing.Size(100, 20)
        Me.RadioButton_BL_Threshold.TabIndex = 20
        Me.RadioButton_BL_Threshold.Text = "BL_Threshold"
        Me.RadioButton_BL_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BL_Threshold
        '
        Me.NumericUpDown_BL_Threshold.Enabled = False
        Me.NumericUpDown_BL_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BL_Threshold.Location = New System.Drawing.Point(157, 15)
        Me.NumericUpDown_BL_Threshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_BL_Threshold.Name = "NumericUpDown_BL_Threshold"
        Me.NumericUpDown_BL_Threshold.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_BL_Threshold.TabIndex = 19
        Me.NumericUpDown_BL_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CheckBox_VLine_NotAddToOutput
        '
        Me.CheckBox_VLine_NotAddToOutput.AutoSize = True
        Me.CheckBox_VLine_NotAddToOutput.Enabled = False
        Me.CheckBox_VLine_NotAddToOutput.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_VLine_NotAddToOutput.Location = New System.Drawing.Point(197, 1708)
        Me.CheckBox_VLine_NotAddToOutput.Name = "CheckBox_VLine_NotAddToOutput"
        Me.CheckBox_VLine_NotAddToOutput.Size = New System.Drawing.Size(126, 20)
        Me.CheckBox_VLine_NotAddToOutput.TabIndex = 52
        Me.CheckBox_VLine_NotAddToOutput.Text = "V-Line 不加入輸出"
        Me.CheckBox_VLine_NotAddToOutput.UseVisualStyleBackColor = True
        '
        'GroupBox_PointPitchSetting
        '
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.NumericUpDown_Point_PitchY)
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.NumericUpDown_Point_PitchX)
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.Label_PointPitchY)
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.Label_PointPitchX)
        Me.GroupBox_PointPitchSetting.Location = New System.Drawing.Point(6, 96)
        Me.GroupBox_PointPitchSetting.Name = "GroupBox_PointPitchSetting"
        Me.GroupBox_PointPitchSetting.Size = New System.Drawing.Size(246, 55)
        Me.GroupBox_PointPitchSetting.TabIndex = 42
        Me.GroupBox_PointPitchSetting.TabStop = False
        Me.GroupBox_PointPitchSetting.Text = "Point Pitch Setting"
        '
        'NumericUpDown_Point_PitchY
        '
        Me.NumericUpDown_Point_PitchY.Location = New System.Drawing.Point(186, 22)
        Me.NumericUpDown_Point_PitchY.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.NumericUpDown_Point_PitchY.Name = "NumericUpDown_Point_PitchY"
        Me.NumericUpDown_Point_PitchY.Size = New System.Drawing.Size(50, 23)
        Me.NumericUpDown_Point_PitchY.TabIndex = 3
        Me.NumericUpDown_Point_PitchY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_Point_PitchX
        '
        Me.NumericUpDown_Point_PitchX.Location = New System.Drawing.Point(68, 22)
        Me.NumericUpDown_Point_PitchX.Name = "NumericUpDown_Point_PitchX"
        Me.NumericUpDown_Point_PitchX.Size = New System.Drawing.Size(50, 23)
        Me.NumericUpDown_Point_PitchX.TabIndex = 2
        Me.NumericUpDown_Point_PitchX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label_PointPitchY
        '
        Me.Label_PointPitchY.AutoSize = True
        Me.Label_PointPitchY.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_PointPitchY.Location = New System.Drawing.Point(127, 26)
        Me.Label_PointPitchY.Name = "Label_PointPitchY"
        Me.Label_PointPitchY.Size = New System.Drawing.Size(42, 16)
        Me.Label_PointPitchY.TabIndex = 1
        Me.Label_PointPitchY.Text = "PitchY"
        '
        'Label_PointPitchX
        '
        Me.Label_PointPitchX.AutoSize = True
        Me.Label_PointPitchX.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_PointPitchX.Location = New System.Drawing.Point(9, 26)
        Me.Label_PointPitchX.Name = "Label_PointPitchX"
        Me.Label_PointPitchX.Size = New System.Drawing.Size(43, 16)
        Me.Label_PointPitchX.TabIndex = 0
        Me.Label_PointPitchX.Text = "PitchX"
        '
        'GroupBox_DP_Characteristics
        '
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label69)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label68)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label67)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label66)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label65)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label64)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label21)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label71)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label70)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label50)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_MinGray_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Compactness_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_StdDev_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_MinGray_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_GrayMean_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_MaxGray_Fullness_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Fullness_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Fullness_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Elongation_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Elongation_Min)
        Me.GroupBox_DP_Characteristics.Location = New System.Drawing.Point(8, 1378)
        Me.GroupBox_DP_Characteristics.Name = "GroupBox_DP_Characteristics"
        Me.GroupBox_DP_Characteristics.Size = New System.Drawing.Size(349, 292)
        Me.GroupBox_DP_Characteristics.TabIndex = 41
        Me.GroupBox_DP_Characteristics.TabStop = False
        Me.GroupBox_DP_Characteristics.Text = "DP Characteristics"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label69.Location = New System.Drawing.Point(7, 178)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(86, 16)
        Me.Label69.TabIndex = 57
        Me.Label69.Text = "MinGray_Max"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label68.Location = New System.Drawing.Point(7, 151)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(95, 16)
        Me.Label68.TabIndex = 57
        Me.Label68.Text = "GrayMean Max"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label67.Location = New System.Drawing.Point(7, 124)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(130, 16)
        Me.Label67.TabIndex = 57
        Me.Label67.Text = "MaxGray Fullness Min"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label66.Location = New System.Drawing.Point(7, 98)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(81, 16)
        Me.Label66.TabIndex = 57
        Me.Label66.Text = "Fullness_Max"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label65.Location = New System.Drawing.Point(7, 73)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(78, 16)
        Me.Label65.TabIndex = 57
        Me.Label65.Text = "Fullness_Min"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label64.Location = New System.Drawing.Point(7, 48)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(100, 16)
        Me.Label64.TabIndex = 57
        Me.Label64.Text = "Elongation_Max"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(7, 23)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(97, 16)
        Me.Label21.TabIndex = 57
        Me.Label21.Text = "Elongation_Min"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label71.Location = New System.Drawing.Point(7, 259)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(77, 16)
        Me.Label71.TabIndex = 42
        Me.Label71.Text = "StdDev Max"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label70.Location = New System.Drawing.Point(7, 232)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(112, 16)
        Me.Label70.TabIndex = 42
        Me.Label70.Text = "Compactness Max"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label50.Location = New System.Drawing.Point(7, 205)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(83, 16)
        Me.Label50.TabIndex = 42
        Me.Label50.Text = "MinGray_Min"
        '
        'NumericUpDown_DP_MinGray_Min
        '
        Me.NumericUpDown_DP_MinGray_Min.Location = New System.Drawing.Point(185, 201)
        Me.NumericUpDown_DP_MinGray_Min.Maximum = New Decimal(New Integer() {200000000, 0, 0, 0})
        Me.NumericUpDown_DP_MinGray_Min.Name = "NumericUpDown_DP_MinGray_Min"
        Me.NumericUpDown_DP_MinGray_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_MinGray_Min.TabIndex = 41
        Me.NumericUpDown_DP_MinGray_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_Compactness_Max
        '
        Me.NumericUpDown_DP_Compactness_Max.DecimalPlaces = 1
        Me.NumericUpDown_DP_Compactness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Compactness_Max.Location = New System.Drawing.Point(185, 228)
        Me.NumericUpDown_DP_Compactness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_Compactness_Max.Name = "NumericUpDown_DP_Compactness_Max"
        Me.NumericUpDown_DP_Compactness_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_Compactness_Max.TabIndex = 55
        Me.NumericUpDown_DP_Compactness_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_StdDev_Max
        '
        Me.NumericUpDown_DP_StdDev_Max.DecimalPlaces = 1
        Me.NumericUpDown_DP_StdDev_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_StdDev_Max.Location = New System.Drawing.Point(185, 255)
        Me.NumericUpDown_DP_StdDev_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_StdDev_Max.Name = "NumericUpDown_DP_StdDev_Max"
        Me.NumericUpDown_DP_StdDev_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_StdDev_Max.TabIndex = 49
        Me.NumericUpDown_DP_StdDev_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_MinGray_Max
        '
        Me.NumericUpDown_DP_MinGray_Max.DecimalPlaces = 1
        Me.NumericUpDown_DP_MinGray_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_MinGray_Max.Location = New System.Drawing.Point(185, 174)
        Me.NumericUpDown_DP_MinGray_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_MinGray_Max.Name = "NumericUpDown_DP_MinGray_Max"
        Me.NumericUpDown_DP_MinGray_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_MinGray_Max.TabIndex = 47
        Me.NumericUpDown_DP_MinGray_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_GrayMean_Max
        '
        Me.NumericUpDown_DP_GrayMean_Max.DecimalPlaces = 1
        Me.NumericUpDown_DP_GrayMean_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_GrayMean_Max.Location = New System.Drawing.Point(185, 147)
        Me.NumericUpDown_DP_GrayMean_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_GrayMean_Max.Name = "NumericUpDown_DP_GrayMean_Max"
        Me.NumericUpDown_DP_GrayMean_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_GrayMean_Max.TabIndex = 40
        Me.NumericUpDown_DP_GrayMean_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_MaxGray_Fullness_Min
        '
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.DecimalPlaces = 1
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Location = New System.Drawing.Point(185, 120)
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Name = "NumericUpDown_DP_MaxGray_Fullness_Min"
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.TabIndex = 37
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_Fullness_Max
        '
        Me.NumericUpDown_DP_Fullness_Max.DecimalPlaces = 1
        Me.NumericUpDown_DP_Fullness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Fullness_Max.Location = New System.Drawing.Point(185, 93)
        Me.NumericUpDown_DP_Fullness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_Fullness_Max.Name = "NumericUpDown_DP_Fullness_Max"
        Me.NumericUpDown_DP_Fullness_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_Fullness_Max.TabIndex = 34
        Me.NumericUpDown_DP_Fullness_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_Fullness_Min
        '
        Me.NumericUpDown_DP_Fullness_Min.DecimalPlaces = 1
        Me.NumericUpDown_DP_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Fullness_Min.Location = New System.Drawing.Point(185, 68)
        Me.NumericUpDown_DP_Fullness_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_Fullness_Min.Name = "NumericUpDown_DP_Fullness_Min"
        Me.NumericUpDown_DP_Fullness_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_Fullness_Min.TabIndex = 33
        Me.NumericUpDown_DP_Fullness_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_Elongation_Max
        '
        Me.NumericUpDown_DP_Elongation_Max.DecimalPlaces = 1
        Me.NumericUpDown_DP_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Elongation_Max.Location = New System.Drawing.Point(185, 43)
        Me.NumericUpDown_DP_Elongation_Max.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_DP_Elongation_Max.Name = "NumericUpDown_DP_Elongation_Max"
        Me.NumericUpDown_DP_Elongation_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_Elongation_Max.TabIndex = 30
        Me.NumericUpDown_DP_Elongation_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_Elongation_Min
        '
        Me.NumericUpDown_DP_Elongation_Min.DecimalPlaces = 1
        Me.NumericUpDown_DP_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Elongation_Min.Location = New System.Drawing.Point(185, 18)
        Me.NumericUpDown_DP_Elongation_Min.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_DP_Elongation_Min.Name = "NumericUpDown_DP_Elongation_Min"
        Me.NumericUpDown_DP_Elongation_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_Elongation_Min.TabIndex = 29
        Me.NumericUpDown_DP_Elongation_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'CheckBox_HLine_NotAddToOutput
        '
        Me.CheckBox_HLine_NotAddToOutput.AutoSize = True
        Me.CheckBox_HLine_NotAddToOutput.Enabled = False
        Me.CheckBox_HLine_NotAddToOutput.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_HLine_NotAddToOutput.Location = New System.Drawing.Point(8, 1707)
        Me.CheckBox_HLine_NotAddToOutput.Name = "CheckBox_HLine_NotAddToOutput"
        Me.CheckBox_HLine_NotAddToOutput.Size = New System.Drawing.Size(127, 20)
        Me.CheckBox_HLine_NotAddToOutput.TabIndex = 51
        Me.CheckBox_HLine_NotAddToOutput.Text = "H-Line 不加入輸出"
        Me.CheckBox_HLine_NotAddToOutput.UseVisualStyleBackColor = True
        '
        'CheckBox_Point_Enable
        '
        Me.CheckBox_Point_Enable.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar
        Me.CheckBox_Point_Enable.AutoSize = True
        Me.CheckBox_Point_Enable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_Point_Enable.Location = New System.Drawing.Point(6, 5)
        Me.CheckBox_Point_Enable.Name = "CheckBox_Point_Enable"
        Me.CheckBox_Point_Enable.Size = New System.Drawing.Size(119, 20)
        Me.CheckBox_Point_Enable.TabIndex = 14
        Me.CheckBox_Point_Enable.Text = "Point檢查Enable"
        Me.CheckBox_Point_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_BP_Characteristics
        '
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label80)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label79)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label49)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_MaxGray_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label78)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label77)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label76)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_StdDev_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label75)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label74)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label73)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Compactness_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label72)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_MaxGray_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_GrayMean_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_MaxGray_Fullness_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Fullness_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Fullness_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Elongation_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Elongation_Min)
        Me.GroupBox_BP_Characteristics.Location = New System.Drawing.Point(7, 1085)
        Me.GroupBox_BP_Characteristics.Name = "GroupBox_BP_Characteristics"
        Me.GroupBox_BP_Characteristics.Size = New System.Drawing.Size(350, 287)
        Me.GroupBox_BP_Characteristics.TabIndex = 40
        Me.GroupBox_BP_Characteristics.TabStop = False
        Me.GroupBox_BP_Characteristics.Text = "BP Characteristics"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label80.Location = New System.Drawing.Point(9, 259)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(79, 16)
        Me.Label80.TabIndex = 56
        Me.Label80.Text = "StdDev_Max"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label79.Location = New System.Drawing.Point(9, 232)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(114, 16)
        Me.Label79.TabIndex = 56
        Me.Label79.Text = "Compactness_Max"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label49.Location = New System.Drawing.Point(9, 205)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(89, 16)
        Me.Label49.TabIndex = 56
        Me.Label49.Text = "MaxGray_Max"
        '
        'NumericUpDown_BP_MaxGray_Max
        '
        Me.NumericUpDown_BP_MaxGray_Max.Location = New System.Drawing.Point(186, 201)
        Me.NumericUpDown_BP_MaxGray_Max.Maximum = New Decimal(New Integer() {200000000, 0, 0, 0})
        Me.NumericUpDown_BP_MaxGray_Max.Name = "NumericUpDown_BP_MaxGray_Max"
        Me.NumericUpDown_BP_MaxGray_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_MaxGray_Max.TabIndex = 55
        Me.NumericUpDown_BP_MaxGray_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label78.Location = New System.Drawing.Point(9, 178)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(86, 16)
        Me.Label78.TabIndex = 57
        Me.Label78.Text = "MaxGray_Min"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label77.Location = New System.Drawing.Point(9, 151)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(94, 16)
        Me.Label77.TabIndex = 57
        Me.Label77.Text = "GrayMean_Min"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label76.Location = New System.Drawing.Point(9, 123)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(130, 16)
        Me.Label76.TabIndex = 57
        Me.Label76.Text = "MaxGray Fullness Min"
        '
        'NumericUpDown_BP_StdDev_Max
        '
        Me.NumericUpDown_BP_StdDev_Max.DecimalPlaces = 1
        Me.NumericUpDown_BP_StdDev_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_StdDev_Max.Location = New System.Drawing.Point(186, 255)
        Me.NumericUpDown_BP_StdDev_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_StdDev_Max.Name = "NumericUpDown_BP_StdDev_Max"
        Me.NumericUpDown_BP_StdDev_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_StdDev_Max.TabIndex = 54
        Me.NumericUpDown_BP_StdDev_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label75.Location = New System.Drawing.Point(9, 98)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(81, 16)
        Me.Label75.TabIndex = 57
        Me.Label75.Text = "Fullness_Max"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label74.Location = New System.Drawing.Point(9, 73)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(78, 16)
        Me.Label74.TabIndex = 57
        Me.Label74.Text = "Fullness_Min"
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label73.Location = New System.Drawing.Point(9, 48)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(100, 16)
        Me.Label73.TabIndex = 57
        Me.Label73.Text = "Elongation_Max"
        '
        'NumericUpDown_BP_Compactness_Max
        '
        Me.NumericUpDown_BP_Compactness_Max.DecimalPlaces = 1
        Me.NumericUpDown_BP_Compactness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Compactness_Max.Location = New System.Drawing.Point(186, 228)
        Me.NumericUpDown_BP_Compactness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_Compactness_Max.Name = "NumericUpDown_BP_Compactness_Max"
        Me.NumericUpDown_BP_Compactness_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_Compactness_Max.TabIndex = 51
        Me.NumericUpDown_BP_Compactness_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label72.Location = New System.Drawing.Point(9, 23)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(97, 16)
        Me.Label72.TabIndex = 57
        Me.Label72.Text = "Elongation_Min"
        '
        'NumericUpDown_BP_MaxGray_Min
        '
        Me.NumericUpDown_BP_MaxGray_Min.DecimalPlaces = 1
        Me.NumericUpDown_BP_MaxGray_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_MaxGray_Min.Location = New System.Drawing.Point(186, 174)
        Me.NumericUpDown_BP_MaxGray_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_MaxGray_Min.Name = "NumericUpDown_BP_MaxGray_Min"
        Me.NumericUpDown_BP_MaxGray_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_MaxGray_Min.TabIndex = 45
        Me.NumericUpDown_BP_MaxGray_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_GrayMean_Min
        '
        Me.NumericUpDown_BP_GrayMean_Min.DecimalPlaces = 1
        Me.NumericUpDown_BP_GrayMean_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_GrayMean_Min.Location = New System.Drawing.Point(186, 147)
        Me.NumericUpDown_BP_GrayMean_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_GrayMean_Min.Name = "NumericUpDown_BP_GrayMean_Min"
        Me.NumericUpDown_BP_GrayMean_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_GrayMean_Min.TabIndex = 43
        Me.NumericUpDown_BP_GrayMean_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_MaxGray_Fullness_Min
        '
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.DecimalPlaces = 1
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Location = New System.Drawing.Point(186, 120)
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Name = "NumericUpDown_BP_MaxGray_Fullness_Min"
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.TabIndex = 37
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_Fullness_Max
        '
        Me.NumericUpDown_BP_Fullness_Max.DecimalPlaces = 1
        Me.NumericUpDown_BP_Fullness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Fullness_Max.Location = New System.Drawing.Point(186, 93)
        Me.NumericUpDown_BP_Fullness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_Fullness_Max.Name = "NumericUpDown_BP_Fullness_Max"
        Me.NumericUpDown_BP_Fullness_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_Fullness_Max.TabIndex = 34
        Me.NumericUpDown_BP_Fullness_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_Fullness_Min
        '
        Me.NumericUpDown_BP_Fullness_Min.DecimalPlaces = 1
        Me.NumericUpDown_BP_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Fullness_Min.Location = New System.Drawing.Point(186, 68)
        Me.NumericUpDown_BP_Fullness_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_Fullness_Min.Name = "NumericUpDown_BP_Fullness_Min"
        Me.NumericUpDown_BP_Fullness_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_Fullness_Min.TabIndex = 33
        Me.NumericUpDown_BP_Fullness_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_Elongation_Max
        '
        Me.NumericUpDown_BP_Elongation_Max.DecimalPlaces = 1
        Me.NumericUpDown_BP_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Elongation_Max.Location = New System.Drawing.Point(186, 43)
        Me.NumericUpDown_BP_Elongation_Max.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_BP_Elongation_Max.Name = "NumericUpDown_BP_Elongation_Max"
        Me.NumericUpDown_BP_Elongation_Max.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_Elongation_Max.TabIndex = 30
        Me.NumericUpDown_BP_Elongation_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_Elongation_Min
        '
        Me.NumericUpDown_BP_Elongation_Min.DecimalPlaces = 1
        Me.NumericUpDown_BP_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Elongation_Min.Location = New System.Drawing.Point(186, 18)
        Me.NumericUpDown_BP_Elongation_Min.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_BP_Elongation_Min.Name = "NumericUpDown_BP_Elongation_Min"
        Me.NumericUpDown_BP_Elongation_Min.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_Elongation_Min.TabIndex = 29
        Me.NumericUpDown_BP_Elongation_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_LineCommonSetting
        '
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Short_Cut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ShortCut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Cut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_Cut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassRightV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassRightV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassLeftV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassLeftV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Block_OverNumber)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Block_OverNum)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassUpH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Short_Cut)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassUpH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassDownH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ShortCut)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Cut)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_OverNumber)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_OverNum)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassDownH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_Cut)
        Me.GroupBox_LineCommonSetting.Location = New System.Drawing.Point(8, 1901)
        Me.GroupBox_LineCommonSetting.Name = "GroupBox_LineCommonSetting"
        Me.GroupBox_LineCommonSetting.Size = New System.Drawing.Size(349, 307)
        Me.GroupBox_LineCommonSetting.TabIndex = 50
        Me.GroupBox_LineCommonSetting.TabStop = False
        Me.GroupBox_LineCommonSetting.Text = "Line Common Setting"
        '
        'NumericUpDown_Line_Short_Cut_H
        '
        Me.NumericUpDown_Line_Short_Cut_H.Enabled = False
        Me.NumericUpDown_Line_Short_Cut_H.Location = New System.Drawing.Point(160, 211)
        Me.NumericUpDown_Line_Short_Cut_H.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_Line_Short_Cut_H.Name = "NumericUpDown_Line_Short_Cut_H"
        Me.NumericUpDown_Line_Short_Cut_H.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_Short_Cut_H.TabIndex = 40
        Me.NumericUpDown_Line_Short_Cut_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_Line_ShortCut_H
        '
        Me.RadioButton_Line_ShortCut_H.AutoSize = True
        Me.RadioButton_Line_ShortCut_H.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_ShortCut_H.Location = New System.Drawing.Point(10, 213)
        Me.RadioButton_Line_ShortCut_H.Name = "RadioButton_Line_ShortCut_H"
        Me.RadioButton_Line_ShortCut_H.Size = New System.Drawing.Size(116, 20)
        Me.RadioButton_Line_ShortCut_H.TabIndex = 39
        Me.RadioButton_Line_ShortCut_H.TabStop = True
        Me.RadioButton_Line_ShortCut_H.Text = "Line Short Cut H"
        Me.RadioButton_Line_ShortCut_H.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_Cut_H
        '
        Me.NumericUpDown_Line_Cut_H.Enabled = False
        Me.NumericUpDown_Line_Cut_H.Location = New System.Drawing.Point(160, 184)
        Me.NumericUpDown_Line_Cut_H.Maximum = New Decimal(New Integer() {30000, 0, 0, 0})
        Me.NumericUpDown_Line_Cut_H.Name = "NumericUpDown_Line_Cut_H"
        Me.NumericUpDown_Line_Cut_H.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_Cut_H.TabIndex = 37
        Me.NumericUpDown_Line_Cut_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_Line_Cut_H
        '
        Me.RadioButton_Line_Cut_H.AutoSize = True
        Me.RadioButton_Line_Cut_H.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_Cut_H.Location = New System.Drawing.Point(10, 186)
        Me.RadioButton_Line_Cut_H.Name = "RadioButton_Line_Cut_H"
        Me.RadioButton_Line_Cut_H.Size = New System.Drawing.Size(83, 20)
        Me.RadioButton_Line_Cut_H.TabIndex = 38
        Me.RadioButton_Line_Cut_H.Text = "Line Cut H"
        Me.RadioButton_Line_Cut_H.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_ByPassRightV
        '
        Me.NumericUpDown_Line_ByPassRightV.Enabled = False
        Me.NumericUpDown_Line_ByPassRightV.Location = New System.Drawing.Point(160, 103)
        Me.NumericUpDown_Line_ByPassRightV.Name = "NumericUpDown_Line_ByPassRightV"
        Me.NumericUpDown_Line_ByPassRightV.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_ByPassRightV.TabIndex = 35
        Me.NumericUpDown_Line_ByPassRightV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_Line_ByPassRightV
        '
        Me.RadioButton_Line_ByPassRightV.AutoSize = True
        Me.RadioButton_Line_ByPassRightV.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_ByPassRightV.Location = New System.Drawing.Point(12, 105)
        Me.RadioButton_Line_ByPassRightV.Name = "RadioButton_Line_ByPassRightV"
        Me.RadioButton_Line_ByPassRightV.Size = New System.Drawing.Size(107, 20)
        Me.RadioButton_Line_ByPassRightV.TabIndex = 36
        Me.RadioButton_Line_ByPassRightV.Text = "ByPass Right V"
        Me.RadioButton_Line_ByPassRightV.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_ByPassLeftV
        '
        Me.NumericUpDown_Line_ByPassLeftV.Enabled = False
        Me.NumericUpDown_Line_ByPassLeftV.Location = New System.Drawing.Point(160, 76)
        Me.NumericUpDown_Line_ByPassLeftV.Name = "NumericUpDown_Line_ByPassLeftV"
        Me.NumericUpDown_Line_ByPassLeftV.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_ByPassLeftV.TabIndex = 33
        Me.NumericUpDown_Line_ByPassLeftV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_Line_ByPassLeftV
        '
        Me.RadioButton_Line_ByPassLeftV.AutoSize = True
        Me.RadioButton_Line_ByPassLeftV.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_ByPassLeftV.Location = New System.Drawing.Point(12, 78)
        Me.RadioButton_Line_ByPassLeftV.Name = "RadioButton_Line_ByPassLeftV"
        Me.RadioButton_Line_ByPassLeftV.Size = New System.Drawing.Size(98, 20)
        Me.RadioButton_Line_ByPassLeftV.TabIndex = 34
        Me.RadioButton_Line_ByPassLeftV.Text = "ByPass Left V"
        Me.RadioButton_Line_ByPassLeftV.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Block_OverNumber
        '
        Me.NumericUpDown_Block_OverNumber.Location = New System.Drawing.Point(160, 265)
        Me.NumericUpDown_Block_OverNumber.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Block_OverNumber.Name = "NumericUpDown_Block_OverNumber"
        Me.NumericUpDown_Block_OverNumber.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Block_OverNumber.TabIndex = 32
        Me.NumericUpDown_Block_OverNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_Block_OverNum
        '
        Me.RadioButton_Block_OverNum.AutoSize = True
        Me.RadioButton_Block_OverNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Block_OverNum.Location = New System.Drawing.Point(10, 267)
        Me.RadioButton_Block_OverNum.Name = "RadioButton_Block_OverNum"
        Me.RadioButton_Block_OverNum.Size = New System.Drawing.Size(114, 20)
        Me.RadioButton_Block_OverNum.TabIndex = 31
        Me.RadioButton_Block_OverNum.TabStop = True
        Me.RadioButton_Block_OverNum.Text = "Block OverNum"
        Me.RadioButton_Block_OverNum.UseVisualStyleBackColor = True
        '
        'RadioButton_Line_ByPassUpH
        '
        Me.RadioButton_Line_ByPassUpH.AutoSize = True
        Me.RadioButton_Line_ByPassUpH.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_ByPassUpH.Location = New System.Drawing.Point(12, 24)
        Me.RadioButton_Line_ByPassUpH.Name = "RadioButton_Line_ByPassUpH"
        Me.RadioButton_Line_ByPassUpH.Size = New System.Drawing.Size(95, 20)
        Me.RadioButton_Line_ByPassUpH.TabIndex = 15
        Me.RadioButton_Line_ByPassUpH.Text = "ByPass Up H"
        Me.RadioButton_Line_ByPassUpH.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_Short_Cut
        '
        Me.NumericUpDown_Line_Short_Cut.Enabled = False
        Me.NumericUpDown_Line_Short_Cut.Location = New System.Drawing.Point(160, 157)
        Me.NumericUpDown_Line_Short_Cut.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_Line_Short_Cut.Name = "NumericUpDown_Line_Short_Cut"
        Me.NumericUpDown_Line_Short_Cut.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_Short_Cut.TabIndex = 27
        Me.NumericUpDown_Line_Short_Cut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_Line_ByPassUpH
        '
        Me.NumericUpDown_Line_ByPassUpH.Enabled = False
        Me.NumericUpDown_Line_ByPassUpH.Location = New System.Drawing.Point(160, 22)
        Me.NumericUpDown_Line_ByPassUpH.Name = "NumericUpDown_Line_ByPassUpH"
        Me.NumericUpDown_Line_ByPassUpH.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_ByPassUpH.TabIndex = 5
        Me.NumericUpDown_Line_ByPassUpH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_Line_ByPassDownH
        '
        Me.NumericUpDown_Line_ByPassDownH.Enabled = False
        Me.NumericUpDown_Line_ByPassDownH.Location = New System.Drawing.Point(160, 49)
        Me.NumericUpDown_Line_ByPassDownH.Name = "NumericUpDown_Line_ByPassDownH"
        Me.NumericUpDown_Line_ByPassDownH.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_ByPassDownH.TabIndex = 7
        Me.NumericUpDown_Line_ByPassDownH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_Line_ShortCut
        '
        Me.RadioButton_Line_ShortCut.AutoSize = True
        Me.RadioButton_Line_ShortCut.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_ShortCut.Location = New System.Drawing.Point(10, 159)
        Me.RadioButton_Line_ShortCut.Name = "RadioButton_Line_ShortCut"
        Me.RadioButton_Line_ShortCut.Size = New System.Drawing.Size(115, 20)
        Me.RadioButton_Line_ShortCut.TabIndex = 25
        Me.RadioButton_Line_ShortCut.TabStop = True
        Me.RadioButton_Line_ShortCut.Text = "Line Short Cut V"
        Me.RadioButton_Line_ShortCut.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_Cut
        '
        Me.NumericUpDown_Line_Cut.Enabled = False
        Me.NumericUpDown_Line_Cut.Location = New System.Drawing.Point(160, 130)
        Me.NumericUpDown_Line_Cut.Maximum = New Decimal(New Integer() {30000, 0, 0, 0})
        Me.NumericUpDown_Line_Cut.Name = "NumericUpDown_Line_Cut"
        Me.NumericUpDown_Line_Cut.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_Cut.TabIndex = 9
        Me.NumericUpDown_Line_Cut.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_Line_OverNumber
        '
        Me.NumericUpDown_Line_OverNumber.Enabled = False
        Me.NumericUpDown_Line_OverNumber.Location = New System.Drawing.Point(160, 238)
        Me.NumericUpDown_Line_OverNumber.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_Line_OverNumber.Name = "NumericUpDown_Line_OverNumber"
        Me.NumericUpDown_Line_OverNumber.Size = New System.Drawing.Size(64, 23)
        Me.NumericUpDown_Line_OverNumber.TabIndex = 24
        Me.NumericUpDown_Line_OverNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_Line_OverNum
        '
        Me.RadioButton_Line_OverNum.AutoSize = True
        Me.RadioButton_Line_OverNum.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_OverNum.Location = New System.Drawing.Point(10, 240)
        Me.RadioButton_Line_OverNum.Name = "RadioButton_Line_OverNum"
        Me.RadioButton_Line_OverNum.Size = New System.Drawing.Size(104, 20)
        Me.RadioButton_Line_OverNum.TabIndex = 13
        Me.RadioButton_Line_OverNum.TabStop = True
        Me.RadioButton_Line_OverNum.Text = "LineOverNum"
        Me.RadioButton_Line_OverNum.UseVisualStyleBackColor = True
        '
        'RadioButton_Line_ByPassDownH
        '
        Me.RadioButton_Line_ByPassDownH.AutoSize = True
        Me.RadioButton_Line_ByPassDownH.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_ByPassDownH.Location = New System.Drawing.Point(12, 51)
        Me.RadioButton_Line_ByPassDownH.Name = "RadioButton_Line_ByPassDownH"
        Me.RadioButton_Line_ByPassDownH.Size = New System.Drawing.Size(111, 20)
        Me.RadioButton_Line_ByPassDownH.TabIndex = 16
        Me.RadioButton_Line_ByPassDownH.Text = "ByPass Down H"
        Me.RadioButton_Line_ByPassDownH.UseVisualStyleBackColor = True
        '
        'RadioButton_Line_Cut
        '
        Me.RadioButton_Line_Cut.AutoSize = True
        Me.RadioButton_Line_Cut.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Line_Cut.Location = New System.Drawing.Point(10, 132)
        Me.RadioButton_Line_Cut.Name = "RadioButton_Line_Cut"
        Me.RadioButton_Line_Cut.Size = New System.Drawing.Size(82, 20)
        Me.RadioButton_Line_Cut.TabIndex = 17
        Me.RadioButton_Line_Cut.Text = "Line Cut V"
        Me.RadioButton_Line_Cut.UseVisualStyleBackColor = True
        '
        'GroupBox_BPoint
        '
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_RimThreshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_RimThreshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_Threshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_Threshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_RimThreshold)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_RimThreshold)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_Threshold)
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_Threshold)
        Me.GroupBox_BPoint.Enabled = False
        Me.GroupBox_BPoint.Location = New System.Drawing.Point(7, 677)
        Me.GroupBox_BPoint.Name = "GroupBox_BPoint"
        Me.GroupBox_BPoint.Size = New System.Drawing.Size(350, 130)
        Me.GroupBox_BPoint.TabIndex = 16
        Me.GroupBox_BPoint.TabStop = False
        Me.GroupBox_BPoint.Text = "BPoint"
        '
        'NumericUpDown_BP_RimThreshold_Low
        '
        Me.NumericUpDown_BP_RimThreshold_Low.Enabled = False
        Me.NumericUpDown_BP_RimThreshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold_Low.Location = New System.Drawing.Point(166, 97)
        Me.NumericUpDown_BP_RimThreshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold_Low.Name = "NumericUpDown_BP_RimThreshold_Low"
        Me.NumericUpDown_BP_RimThreshold_Low.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_BP_RimThreshold_Low.TabIndex = 36
        Me.NumericUpDown_BP_RimThreshold_Low.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_BP_RimThreshold_Low
        '
        Me.RadioButton_BP_RimThreshold_Low.AutoSize = True
        Me.RadioButton_BP_RimThreshold_Low.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BP_RimThreshold_Low.Location = New System.Drawing.Point(6, 99)
        Me.RadioButton_BP_RimThreshold_Low.Name = "RadioButton_BP_RimThreshold_Low"
        Me.RadioButton_BP_RimThreshold_Low.Size = New System.Drawing.Size(123, 20)
        Me.RadioButton_BP_RimThreshold_Low.TabIndex = 35
        Me.RadioButton_BP_RimThreshold_Low.TabStop = True
        Me.RadioButton_BP_RimThreshold_Low.Text = "Boundary Th Low"
        Me.RadioButton_BP_RimThreshold_Low.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_Threshold_Low
        '
        Me.RadioButton_BP_Threshold_Low.AutoSize = True
        Me.RadioButton_BP_Threshold_Low.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BP_Threshold_Low.Location = New System.Drawing.Point(7, 45)
        Me.RadioButton_BP_Threshold_Low.Name = "RadioButton_BP_Threshold_Low"
        Me.RadioButton_BP_Threshold_Low.Size = New System.Drawing.Size(108, 20)
        Me.RadioButton_BP_Threshold_Low.TabIndex = 34
        Me.RadioButton_BP_Threshold_Low.Text = "Threshold Low"
        Me.RadioButton_BP_Threshold_Low.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_Threshold_Low
        '
        Me.NumericUpDown_BP_Threshold_Low.Enabled = False
        Me.NumericUpDown_BP_Threshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold_Low.Location = New System.Drawing.Point(166, 43)
        Me.NumericUpDown_BP_Threshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold_Low.Name = "NumericUpDown_BP_Threshold_Low"
        Me.NumericUpDown_BP_Threshold_Low.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_BP_Threshold_Low.TabIndex = 33
        Me.NumericUpDown_BP_Threshold_Low.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_RimThreshold
        '
        Me.NumericUpDown_BP_RimThreshold.Enabled = False
        Me.NumericUpDown_BP_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold.Location = New System.Drawing.Point(166, 70)
        Me.NumericUpDown_BP_RimThreshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold.Name = "NumericUpDown_BP_RimThreshold"
        Me.NumericUpDown_BP_RimThreshold.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_BP_RimThreshold.TabIndex = 27
        Me.NumericUpDown_BP_RimThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_BP_RimThreshold
        '
        Me.RadioButton_BP_RimThreshold.AutoSize = True
        Me.RadioButton_BP_RimThreshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BP_RimThreshold.Location = New System.Drawing.Point(6, 72)
        Me.RadioButton_BP_RimThreshold.Name = "RadioButton_BP_RimThreshold"
        Me.RadioButton_BP_RimThreshold.Size = New System.Drawing.Size(127, 20)
        Me.RadioButton_BP_RimThreshold.TabIndex = 26
        Me.RadioButton_BP_RimThreshold.TabStop = True
        Me.RadioButton_BP_RimThreshold.Text = "Boundary Th High"
        Me.RadioButton_BP_RimThreshold.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_Threshold
        '
        Me.RadioButton_BP_Threshold.AutoSize = True
        Me.RadioButton_BP_Threshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_BP_Threshold.Location = New System.Drawing.Point(7, 18)
        Me.RadioButton_BP_Threshold.Name = "RadioButton_BP_Threshold"
        Me.RadioButton_BP_Threshold.Size = New System.Drawing.Size(112, 20)
        Me.RadioButton_BP_Threshold.TabIndex = 14
        Me.RadioButton_BP_Threshold.Text = "Threshold High"
        Me.RadioButton_BP_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_Threshold
        '
        Me.NumericUpDown_BP_Threshold.Enabled = False
        Me.NumericUpDown_BP_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold.Location = New System.Drawing.Point(166, 16)
        Me.NumericUpDown_BP_Threshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold.Name = "NumericUpDown_BP_Threshold"
        Me.NumericUpDown_BP_Threshold.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_BP_Threshold.TabIndex = 3
        Me.NumericUpDown_BP_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_PointCommonSetting
        '
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_DP_AreaMin)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_DP_AreaMax)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_Point_OverNum)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.Label83)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.Label82)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.Label87)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.Label86)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.Label85)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.Label84)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.Label81)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_Point_ByPassY)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_Point_ByPassX)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_BP_AreaMin)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_BP_AreaMax)
        Me.GroupBox_PointCommonSetting.Location = New System.Drawing.Point(7, 949)
        Me.GroupBox_PointCommonSetting.Name = "GroupBox_PointCommonSetting"
        Me.GroupBox_PointCommonSetting.Size = New System.Drawing.Size(350, 130)
        Me.GroupBox_PointCommonSetting.TabIndex = 18
        Me.GroupBox_PointCommonSetting.TabStop = False
        Me.GroupBox_PointCommonSetting.Text = "Point Common Setting"
        '
        'NumericUpDown_DP_AreaMin
        '
        Me.NumericUpDown_DP_AreaMin.Location = New System.Drawing.Point(117, 95)
        Me.NumericUpDown_DP_AreaMin.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_DP_AreaMin.Name = "NumericUpDown_DP_AreaMin"
        Me.NumericUpDown_DP_AreaMin.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_AreaMin.TabIndex = 32
        Me.NumericUpDown_DP_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_AreaMax
        '
        Me.NumericUpDown_DP_AreaMax.Location = New System.Drawing.Point(117, 69)
        Me.NumericUpDown_DP_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_DP_AreaMax.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_AreaMax.Name = "NumericUpDown_DP_AreaMax"
        Me.NumericUpDown_DP_AreaMax.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_DP_AreaMax.TabIndex = 31
        Me.NumericUpDown_DP_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_DP_AreaMax.Value = New Decimal(New Integer() {250, 0, 0, 0})
        '
        'NumericUpDown_Point_OverNum
        '
        Me.NumericUpDown_Point_OverNum.Location = New System.Drawing.Point(272, 67)
        Me.NumericUpDown_Point_OverNum.Maximum = New Decimal(New Integer() {200000000, 0, 0, 0})
        Me.NumericUpDown_Point_OverNum.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Point_OverNum.Name = "NumericUpDown_Point_OverNum"
        Me.NumericUpDown_Point_OverNum.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_Point_OverNum.TabIndex = 30
        Me.NumericUpDown_Point_OverNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_Point_OverNum.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label83.Location = New System.Drawing.Point(188, 19)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(56, 16)
        Me.Label83.TabIndex = 57
        Me.Label83.Text = "ByPass X"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label82.Location = New System.Drawing.Point(188, 44)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(55, 16)
        Me.Label82.TabIndex = 57
        Me.Label82.Text = "ByPass Y"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label87.Location = New System.Drawing.Point(12, 22)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(79, 16)
        Me.Label87.TabIndex = 57
        Me.Label87.Text = "BP Area Max"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label86.Location = New System.Drawing.Point(12, 48)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(76, 16)
        Me.Label86.TabIndex = 57
        Me.Label86.Text = "BP Area Min"
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label85.Location = New System.Drawing.Point(12, 74)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(81, 16)
        Me.Label85.TabIndex = 57
        Me.Label85.Text = "DP Area Max"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label84.Location = New System.Drawing.Point(12, 100)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(78, 16)
        Me.Label84.TabIndex = 57
        Me.Label84.Text = "DP Area Min"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label81.Location = New System.Drawing.Point(188, 69)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(63, 16)
        Me.Label81.TabIndex = 57
        Me.Label81.Text = "OverNum"
        '
        'NumericUpDown_Point_ByPassY
        '
        Me.NumericUpDown_Point_ByPassY.Location = New System.Drawing.Point(272, 42)
        Me.NumericUpDown_Point_ByPassY.Name = "NumericUpDown_Point_ByPassY"
        Me.NumericUpDown_Point_ByPassY.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_Point_ByPassY.TabIndex = 24
        Me.NumericUpDown_Point_ByPassY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_Point_ByPassX
        '
        Me.NumericUpDown_Point_ByPassX.Location = New System.Drawing.Point(272, 17)
        Me.NumericUpDown_Point_ByPassX.Name = "NumericUpDown_Point_ByPassX"
        Me.NumericUpDown_Point_ByPassX.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_Point_ByPassX.TabIndex = 23
        Me.NumericUpDown_Point_ByPassX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_AreaMin
        '
        Me.NumericUpDown_BP_AreaMin.Location = New System.Drawing.Point(117, 43)
        Me.NumericUpDown_BP_AreaMin.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BP_AreaMin.Name = "NumericUpDown_BP_AreaMin"
        Me.NumericUpDown_BP_AreaMin.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_AreaMin.TabIndex = 22
        Me.NumericUpDown_BP_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_BP_AreaMax
        '
        Me.NumericUpDown_BP_AreaMax.Location = New System.Drawing.Point(117, 17)
        Me.NumericUpDown_BP_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_BP_AreaMax.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_AreaMax.Name = "NumericUpDown_BP_AreaMax"
        Me.NumericUpDown_BP_AreaMax.Size = New System.Drawing.Size(60, 23)
        Me.NumericUpDown_BP_AreaMax.TabIndex = 21
        Me.NumericUpDown_BP_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown_BP_AreaMax.Value = New Decimal(New Integer() {250, 0, 0, 0})
        '
        'CheckBox_Line_Enable
        '
        Me.CheckBox_Line_Enable.AutoSize = True
        Me.CheckBox_Line_Enable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_Line_Enable.Location = New System.Drawing.Point(162, 5)
        Me.CheckBox_Line_Enable.Name = "CheckBox_Line_Enable"
        Me.CheckBox_Line_Enable.Size = New System.Drawing.Size(113, 20)
        Me.CheckBox_Line_Enable.TabIndex = 49
        Me.CheckBox_Line_Enable.Text = "Line檢查Enable"
        Me.CheckBox_Line_Enable.UseVisualStyleBackColor = True
        '
        'CheckBox_Align_Enable
        '
        Me.CheckBox_Align_Enable.AutoSize = True
        Me.CheckBox_Align_Enable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_Align_Enable.Location = New System.Drawing.Point(6, 67)
        Me.CheckBox_Align_Enable.Name = "CheckBox_Align_Enable"
        Me.CheckBox_Align_Enable.Size = New System.Drawing.Size(56, 20)
        Me.CheckBox_Align_Enable.TabIndex = 15
        Me.CheckBox_Align_Enable.Text = "Align"
        Me.CheckBox_Align_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_DPoint
        '
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_Threshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_Threshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_RimThreshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_RimThreshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_RimThreshold)
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_RimThreshold)
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_Threshold)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_Threshold)
        Me.GroupBox_DPoint.Enabled = False
        Me.GroupBox_DPoint.Location = New System.Drawing.Point(7, 813)
        Me.GroupBox_DPoint.Name = "GroupBox_DPoint"
        Me.GroupBox_DPoint.Size = New System.Drawing.Size(350, 130)
        Me.GroupBox_DPoint.TabIndex = 17
        Me.GroupBox_DPoint.TabStop = False
        Me.GroupBox_DPoint.Text = "DPoint"
        '
        'RadioButton_DP_Threshold_Low
        '
        Me.RadioButton_DP_Threshold_Low.AutoSize = True
        Me.RadioButton_DP_Threshold_Low.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_DP_Threshold_Low.Location = New System.Drawing.Point(7, 45)
        Me.RadioButton_DP_Threshold_Low.Name = "RadioButton_DP_Threshold_Low"
        Me.RadioButton_DP_Threshold_Low.Size = New System.Drawing.Size(108, 20)
        Me.RadioButton_DP_Threshold_Low.TabIndex = 32
        Me.RadioButton_DP_Threshold_Low.Text = "Threshold Low"
        Me.RadioButton_DP_Threshold_Low.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_Threshold_Low
        '
        Me.NumericUpDown_DP_Threshold_Low.Enabled = False
        Me.NumericUpDown_DP_Threshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold_Low.Location = New System.Drawing.Point(166, 43)
        Me.NumericUpDown_DP_Threshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold_Low.Name = "NumericUpDown_DP_Threshold_Low"
        Me.NumericUpDown_DP_Threshold_Low.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_DP_Threshold_Low.TabIndex = 31
        Me.NumericUpDown_DP_Threshold_Low.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'NumericUpDown_DP_RimThreshold_Low
        '
        Me.NumericUpDown_DP_RimThreshold_Low.Enabled = False
        Me.NumericUpDown_DP_RimThreshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold_Low.Location = New System.Drawing.Point(166, 97)
        Me.NumericUpDown_DP_RimThreshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold_Low.Name = "NumericUpDown_DP_RimThreshold_Low"
        Me.NumericUpDown_DP_RimThreshold_Low.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_DP_RimThreshold_Low.TabIndex = 30
        Me.NumericUpDown_DP_RimThreshold_Low.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_DP_RimThreshold_Low
        '
        Me.RadioButton_DP_RimThreshold_Low.AutoSize = True
        Me.RadioButton_DP_RimThreshold_Low.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_DP_RimThreshold_Low.Location = New System.Drawing.Point(6, 99)
        Me.RadioButton_DP_RimThreshold_Low.Name = "RadioButton_DP_RimThreshold_Low"
        Me.RadioButton_DP_RimThreshold_Low.Size = New System.Drawing.Size(123, 20)
        Me.RadioButton_DP_RimThreshold_Low.TabIndex = 29
        Me.RadioButton_DP_RimThreshold_Low.TabStop = True
        Me.RadioButton_DP_RimThreshold_Low.Text = "Boundary Th Low"
        Me.RadioButton_DP_RimThreshold_Low.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_RimThreshold
        '
        Me.NumericUpDown_DP_RimThreshold.Enabled = False
        Me.NumericUpDown_DP_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold.Location = New System.Drawing.Point(166, 70)
        Me.NumericUpDown_DP_RimThreshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold.Name = "NumericUpDown_DP_RimThreshold"
        Me.NumericUpDown_DP_RimThreshold.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_DP_RimThreshold.TabIndex = 28
        Me.NumericUpDown_DP_RimThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'RadioButton_DP_RimThreshold
        '
        Me.RadioButton_DP_RimThreshold.AutoSize = True
        Me.RadioButton_DP_RimThreshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_DP_RimThreshold.Location = New System.Drawing.Point(6, 72)
        Me.RadioButton_DP_RimThreshold.Name = "RadioButton_DP_RimThreshold"
        Me.RadioButton_DP_RimThreshold.Size = New System.Drawing.Size(127, 20)
        Me.RadioButton_DP_RimThreshold.TabIndex = 27
        Me.RadioButton_DP_RimThreshold.TabStop = True
        Me.RadioButton_DP_RimThreshold.Text = "Boundary Th High"
        Me.RadioButton_DP_RimThreshold.UseVisualStyleBackColor = True
        '
        'RadioButton_DP_Threshold
        '
        Me.RadioButton_DP_Threshold.AutoSize = True
        Me.RadioButton_DP_Threshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_DP_Threshold.Location = New System.Drawing.Point(7, 18)
        Me.RadioButton_DP_Threshold.Name = "RadioButton_DP_Threshold"
        Me.RadioButton_DP_Threshold.Size = New System.Drawing.Size(112, 20)
        Me.RadioButton_DP_Threshold.TabIndex = 14
        Me.RadioButton_DP_Threshold.Text = "Threshold High"
        Me.RadioButton_DP_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_Threshold
        '
        Me.NumericUpDown_DP_Threshold.Enabled = False
        Me.NumericUpDown_DP_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold.Location = New System.Drawing.Point(166, 16)
        Me.NumericUpDown_DP_Threshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold.Name = "NumericUpDown_DP_Threshold"
        Me.NumericUpDown_DP_Threshold.Size = New System.Drawing.Size(56, 23)
        Me.NumericUpDown_DP_Threshold.TabIndex = 3
        Me.NumericUpDown_DP_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TreeView_FuncParamPattern
        '
        Me.TreeView_FuncParamPattern.Location = New System.Drawing.Point(6, 49)
        Me.TreeView_FuncParamPattern.Name = "TreeView_FuncParamPattern"
        Me.TreeView_FuncParamPattern.Size = New System.Drawing.Size(125, 429)
        Me.TreeView_FuncParamPattern.TabIndex = 0
        '
        'TabPage_MuraParam
        '
        Me.TabPage_MuraParam.AutoScroll = True
        Me.TabPage_MuraParam.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage_MuraParam.Controls.Add(Me.TableLayoutPanel1)
        Me.TabPage_MuraParam.Controls.Add(Me.TabControl_MuraParam)
        Me.TabPage_MuraParam.Controls.Add(Me.TreeView_MuraParamPattern)
        Me.TabPage_MuraParam.Controls.Add(Me.CheckBox_AnalysisCenterMuraEnable)
        Me.TabPage_MuraParam.Controls.Add(Me.CheckBox_AnalysisBandMuraEnable)
        Me.TabPage_MuraParam.Controls.Add(Me.CheckBox_AnalysisAroundMuraEnable)
        Me.TabPage_MuraParam.Controls.Add(Me.Button_MuraParamSave)
        Me.TabPage_MuraParam.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_MuraParam.Name = "TabPage_MuraParam"
        Me.TabPage_MuraParam.Size = New System.Drawing.Size(529, 484)
        Me.TabPage_MuraParam.TabIndex = 4
        Me.TabPage_MuraParam.Tag = "FuncFalseDefect"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Button_MuraPrePrcoessPage, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_MuraBandPage, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_MuraCenterPage, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_MuraAroundPage, 2, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(134, 24)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(384, 31)
        Me.TableLayoutPanel1.TabIndex = 109
        '
        'Button_MuraPrePrcoessPage
        '
        Me.Button_MuraPrePrcoessPage.BackColor = System.Drawing.Color.Snow
        Me.Button_MuraPrePrcoessPage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button_MuraPrePrcoessPage.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button_MuraPrePrcoessPage.ForeColor = System.Drawing.Color.Black
        Me.Button_MuraPrePrcoessPage.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_MuraPrePrcoessPage.Location = New System.Drawing.Point(3, 3)
        Me.Button_MuraPrePrcoessPage.Name = "Button_MuraPrePrcoessPage"
        Me.Button_MuraPrePrcoessPage.Size = New System.Drawing.Size(90, 25)
        Me.Button_MuraPrePrcoessPage.TabIndex = 108
        Me.Button_MuraPrePrcoessPage.Text = "前處理"
        Me.Button_MuraPrePrcoessPage.UseVisualStyleBackColor = False
        '
        'Button_MuraBandPage
        '
        Me.Button_MuraBandPage.BackColor = System.Drawing.Color.Snow
        Me.Button_MuraBandPage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button_MuraBandPage.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button_MuraBandPage.ForeColor = System.Drawing.Color.Black
        Me.Button_MuraBandPage.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_MuraBandPage.Location = New System.Drawing.Point(291, 3)
        Me.Button_MuraBandPage.Name = "Button_MuraBandPage"
        Me.Button_MuraBandPage.Size = New System.Drawing.Size(90, 25)
        Me.Button_MuraBandPage.TabIndex = 108
        Me.Button_MuraBandPage.Text = "帶狀MURA"
        Me.Button_MuraBandPage.UseVisualStyleBackColor = False
        '
        'Button_MuraCenterPage
        '
        Me.Button_MuraCenterPage.BackColor = System.Drawing.Color.Snow
        Me.Button_MuraCenterPage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button_MuraCenterPage.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button_MuraCenterPage.ForeColor = System.Drawing.Color.Black
        Me.Button_MuraCenterPage.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_MuraCenterPage.Location = New System.Drawing.Point(99, 3)
        Me.Button_MuraCenterPage.Name = "Button_MuraCenterPage"
        Me.Button_MuraCenterPage.Size = New System.Drawing.Size(90, 25)
        Me.Button_MuraCenterPage.TabIndex = 108
        Me.Button_MuraCenterPage.Text = "中心MURA"
        Me.Button_MuraCenterPage.UseVisualStyleBackColor = False
        '
        'Button_MuraAroundPage
        '
        Me.Button_MuraAroundPage.BackColor = System.Drawing.Color.Snow
        Me.Button_MuraAroundPage.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button_MuraAroundPage.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button_MuraAroundPage.ForeColor = System.Drawing.Color.Black
        Me.Button_MuraAroundPage.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_MuraAroundPage.Location = New System.Drawing.Point(195, 3)
        Me.Button_MuraAroundPage.Name = "Button_MuraAroundPage"
        Me.Button_MuraAroundPage.Size = New System.Drawing.Size(90, 25)
        Me.Button_MuraAroundPage.TabIndex = 108
        Me.Button_MuraAroundPage.Text = "邊框MURA"
        Me.Button_MuraAroundPage.UseVisualStyleBackColor = False
        '
        'TabControl_MuraParam
        '
        Me.TabControl_MuraParam.Appearance = System.Windows.Forms.TabAppearance.Buttons
        Me.TabControl_MuraParam.Controls.Add(Me.TabPage_MuraPreprocessParam)
        Me.TabControl_MuraParam.Controls.Add(Me.TabPage_MuraBlobParam)
        Me.TabControl_MuraParam.Controls.Add(Me.TabPage_MuraAroundParam)
        Me.TabControl_MuraParam.Controls.Add(Me.TabPage_MuraBandParam)
        Me.TabControl_MuraParam.ItemSize = New System.Drawing.Size(50, 10)
        Me.TabControl_MuraParam.Location = New System.Drawing.Point(134, 64)
        Me.TabControl_MuraParam.Multiline = True
        Me.TabControl_MuraParam.Name = "TabControl_MuraParam"
        Me.TabControl_MuraParam.SelectedIndex = 0
        Me.TabControl_MuraParam.Size = New System.Drawing.Size(384, 420)
        Me.TabControl_MuraParam.TabIndex = 107
        '
        'TabPage_MuraPreprocessParam
        '
        Me.TabPage_MuraPreprocessParam.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage_MuraPreprocessParam.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.TabPage_MuraPreprocessParam.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.Label33)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.Label31)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.Label34)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.GroupBox_MuraRatio)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.NumericUpDown_MacroPowerY)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.CheckBox_UseBaseLine)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.NumericUpDown_MacroPowerX)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.Label36)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.NumericUpDown_DefocusCount)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.Button_MuraPreprocess)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.Label_GlobleSmooth)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.NumericUpDown_MacroMura_GlobleSmooth)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.CheckBox_RemoveHVBand)
        Me.TabPage_MuraPreprocessParam.Controls.Add(Me.NumericUpDown_BlobMura_GlobleSmooth)
        Me.TabPage_MuraPreprocessParam.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_MuraPreprocessParam.Name = "TabPage_MuraPreprocessParam"
        Me.TabPage_MuraPreprocessParam.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_MuraPreprocessParam.Size = New System.Drawing.Size(376, 402)
        Me.TabPage_MuraPreprocessParam.TabIndex = 3
        '
        'Label33
        '
        Me.Label33.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label33.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label33.Location = New System.Drawing.Point(266, 110)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(54, 23)
        Me.Label33.TabIndex = 79
        Me.Label33.Text = "Power Y :"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label33.Visible = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label31.Location = New System.Drawing.Point(6, 50)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(59, 12)
        Me.Label31.TabIndex = 60
        Me.Label31.Text = "糊焦次数 :"
        '
        'Label34
        '
        Me.Label34.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label34.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label34.Location = New System.Drawing.Point(266, 85)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(54, 23)
        Me.Label34.TabIndex = 79
        Me.Label34.Text = "Power X :"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.Label34.Visible = False
        '
        'GroupBox_MuraRatio
        '
        Me.GroupBox_MuraRatio.Controls.Add(Me.GroupBox_BlobResize)
        Me.GroupBox_MuraRatio.Controls.Add(Me.GroupBox_MarcoResize)
        Me.GroupBox_MuraRatio.Location = New System.Drawing.Point(8, 78)
        Me.GroupBox_MuraRatio.Name = "GroupBox_MuraRatio"
        Me.GroupBox_MuraRatio.Size = New System.Drawing.Size(248, 81)
        Me.GroupBox_MuraRatio.TabIndex = 73
        Me.GroupBox_MuraRatio.TabStop = False
        Me.GroupBox_MuraRatio.Text = "Mura 比例参数"
        '
        'GroupBox_BlobResize
        '
        Me.GroupBox_BlobResize.Controls.Add(Me.Num_ResizeCount_Min)
        Me.GroupBox_BlobResize.Controls.Add(Me.Num_ResizeCount_Mid)
        Me.GroupBox_BlobResize.Controls.Add(Me.Label32)
        Me.GroupBox_BlobResize.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox_BlobResize.Location = New System.Drawing.Point(6, 17)
        Me.GroupBox_BlobResize.Name = "GroupBox_BlobResize"
        Me.GroupBox_BlobResize.Size = New System.Drawing.Size(110, 53)
        Me.GroupBox_BlobResize.TabIndex = 0
        Me.GroupBox_BlobResize.TabStop = False
        Me.GroupBox_BlobResize.Text = "Blob"
        '
        'Num_ResizeCount_Min
        '
        Me.Num_ResizeCount_Min.Location = New System.Drawing.Point(5, 21)
        Me.Num_ResizeCount_Min.Maximum = New Decimal(New Integer() {8, 0, 0, 0})
        Me.Num_ResizeCount_Min.Name = "Num_ResizeCount_Min"
        Me.Num_ResizeCount_Min.Size = New System.Drawing.Size(40, 22)
        Me.Num_ResizeCount_Min.TabIndex = 72
        Me.Num_ResizeCount_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Num_ResizeCount_Mid
        '
        Me.Num_ResizeCount_Mid.Location = New System.Drawing.Point(64, 21)
        Me.Num_ResizeCount_Mid.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.Num_ResizeCount_Mid.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Num_ResizeCount_Mid.Name = "Num_ResizeCount_Mid"
        Me.Num_ResizeCount_Mid.Size = New System.Drawing.Size(40, 22)
        Me.Num_ResizeCount_Mid.TabIndex = 66
        Me.Num_ResizeCount_Mid.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Num_ResizeCount_Mid.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label32.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label32.Location = New System.Drawing.Point(51, 23)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(9, 12)
        Me.Label32.TabIndex = 71
        Me.Label32.Text = "-"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_MarcoResize
        '
        Me.GroupBox_MarcoResize.Controls.Add(Me.Num_ResizeCount_Max)
        Me.GroupBox_MarcoResize.Controls.Add(Me.Label35)
        Me.GroupBox_MarcoResize.Controls.Add(Me.Num_ResizeCount_Mid2)
        Me.GroupBox_MarcoResize.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox_MarcoResize.Location = New System.Drawing.Point(123, 17)
        Me.GroupBox_MarcoResize.Name = "GroupBox_MarcoResize"
        Me.GroupBox_MarcoResize.Size = New System.Drawing.Size(119, 53)
        Me.GroupBox_MarcoResize.TabIndex = 1
        Me.GroupBox_MarcoResize.TabStop = False
        Me.GroupBox_MarcoResize.Text = "Macro"
        '
        'Num_ResizeCount_Max
        '
        Me.Num_ResizeCount_Max.Location = New System.Drawing.Point(67, 21)
        Me.Num_ResizeCount_Max.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.Num_ResizeCount_Max.Minimum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.Num_ResizeCount_Max.Name = "Num_ResizeCount_Max"
        Me.Num_ResizeCount_Max.Size = New System.Drawing.Size(40, 22)
        Me.Num_ResizeCount_Max.TabIndex = 73
        Me.Num_ResizeCount_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Num_ResizeCount_Max.Value = New Decimal(New Integer() {2, 0, 0, 0})
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label35.Location = New System.Drawing.Point(52, 23)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(9, 12)
        Me.Label35.TabIndex = 74
        Me.Label35.Text = "-"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Num_ResizeCount_Mid2
        '
        Me.Num_ResizeCount_Mid2.Location = New System.Drawing.Point(6, 21)
        Me.Num_ResizeCount_Mid2.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.Num_ResizeCount_Mid2.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Num_ResizeCount_Mid2.Name = "Num_ResizeCount_Mid2"
        Me.Num_ResizeCount_Mid2.Size = New System.Drawing.Size(40, 22)
        Me.Num_ResizeCount_Mid2.TabIndex = 75
        Me.Num_ResizeCount_Mid2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Num_ResizeCount_Mid2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_MacroPowerY
        '
        Me.NumericUpDown_MacroPowerY.Enabled = False
        Me.NumericUpDown_MacroPowerY.Location = New System.Drawing.Point(326, 113)
        Me.NumericUpDown_MacroPowerY.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerY.Name = "NumericUpDown_MacroPowerY"
        Me.NumericUpDown_MacroPowerY.Size = New System.Drawing.Size(40, 22)
        Me.NumericUpDown_MacroPowerY.TabIndex = 78
        Me.NumericUpDown_MacroPowerY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_MacroPowerY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerY.Visible = False
        '
        'CheckBox_UseBaseLine
        '
        Me.CheckBox_UseBaseLine.AutoSize = True
        Me.CheckBox_UseBaseLine.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_UseBaseLine.Location = New System.Drawing.Point(268, 15)
        Me.CheckBox_UseBaseLine.Name = "CheckBox_UseBaseLine"
        Me.CheckBox_UseBaseLine.Size = New System.Drawing.Size(98, 16)
        Me.CheckBox_UseBaseLine.TabIndex = 66
        Me.CheckBox_UseBaseLine.Text = "Macro Use LSQ"
        Me.CheckBox_UseBaseLine.UseVisualStyleBackColor = True
        Me.CheckBox_UseBaseLine.Visible = False
        '
        'NumericUpDown_MacroPowerX
        '
        Me.NumericUpDown_MacroPowerX.Enabled = False
        Me.NumericUpDown_MacroPowerX.Location = New System.Drawing.Point(326, 85)
        Me.NumericUpDown_MacroPowerX.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerX.Name = "NumericUpDown_MacroPowerX"
        Me.NumericUpDown_MacroPowerX.Size = New System.Drawing.Size(40, 22)
        Me.NumericUpDown_MacroPowerX.TabIndex = 78
        Me.NumericUpDown_MacroPowerX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_MacroPowerX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerX.Visible = False
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label36.Location = New System.Drawing.Point(6, 194)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(92, 12)
        Me.Label36.TabIndex = 70
        Me.Label36.Text = "Macro 平滑次数 :"
        '
        'NumericUpDown_DefocusCount
        '
        Me.NumericUpDown_DefocusCount.Location = New System.Drawing.Point(91, 45)
        Me.NumericUpDown_DefocusCount.Name = "NumericUpDown_DefocusCount"
        Me.NumericUpDown_DefocusCount.Size = New System.Drawing.Size(144, 22)
        Me.NumericUpDown_DefocusCount.TabIndex = 61
        Me.NumericUpDown_DefocusCount.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Button_MuraPreprocess
        '
        Me.Button_MuraPreprocess.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_MuraPreprocess.Location = New System.Drawing.Point(6, 5)
        Me.Button_MuraPreprocess.Name = "Button_MuraPreprocess"
        Me.Button_MuraPreprocess.Size = New System.Drawing.Size(114, 36)
        Me.Button_MuraPreprocess.TabIndex = 66
        Me.Button_MuraPreprocess.Text = "分析檢測影像"
        '
        'Label_GlobleSmooth
        '
        Me.Label_GlobleSmooth.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_GlobleSmooth.Location = New System.Drawing.Point(6, 162)
        Me.Label_GlobleSmooth.Name = "Label_GlobleSmooth"
        Me.Label_GlobleSmooth.Size = New System.Drawing.Size(125, 23)
        Me.Label_GlobleSmooth.TabIndex = 68
        Me.Label_GlobleSmooth.Text = "Blob 平滑次数 :"
        Me.Label_GlobleSmooth.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_MacroMura_GlobleSmooth
        '
        Me.NumericUpDown_MacroMura_GlobleSmooth.Location = New System.Drawing.Point(137, 189)
        Me.NumericUpDown_MacroMura_GlobleSmooth.Name = "NumericUpDown_MacroMura_GlobleSmooth"
        Me.NumericUpDown_MacroMura_GlobleSmooth.Size = New System.Drawing.Size(112, 22)
        Me.NumericUpDown_MacroMura_GlobleSmooth.TabIndex = 71
        Me.NumericUpDown_MacroMura_GlobleSmooth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'CheckBox_RemoveHVBand
        '
        Me.CheckBox_RemoveHVBand.AutoSize = True
        Me.CheckBox_RemoveHVBand.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_RemoveHVBand.Location = New System.Drawing.Point(139, 15)
        Me.CheckBox_RemoveHVBand.Name = "CheckBox_RemoveHVBand"
        Me.CheckBox_RemoveHVBand.Size = New System.Drawing.Size(110, 16)
        Me.CheckBox_RemoveHVBand.TabIndex = 74
        Me.CheckBox_RemoveHVBand.Text = "Remove HV Band"
        Me.CheckBox_RemoveHVBand.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BlobMura_GlobleSmooth
        '
        Me.NumericUpDown_BlobMura_GlobleSmooth.Location = New System.Drawing.Point(137, 162)
        Me.NumericUpDown_BlobMura_GlobleSmooth.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BlobMura_GlobleSmooth.Name = "NumericUpDown_BlobMura_GlobleSmooth"
        Me.NumericUpDown_BlobMura_GlobleSmooth.Size = New System.Drawing.Size(112, 22)
        Me.NumericUpDown_BlobMura_GlobleSmooth.TabIndex = 69
        Me.NumericUpDown_BlobMura_GlobleSmooth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TabPage_MuraBlobParam
        '
        Me.TabPage_MuraBlobParam.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage_MuraBlobParam.Controls.Add(Me.GroupBox_Modify)
        Me.TabPage_MuraBlobParam.Controls.Add(Me.Button_AnalysisMuraBlob)
        Me.TabPage_MuraBlobParam.Controls.Add(Me.GroupBox_MuraCenterBlobThreshold)
        Me.TabPage_MuraBlobParam.Controls.Add(Me.CheckBox_UseReconstructBW)
        Me.TabPage_MuraBlobParam.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_MuraBlobParam.Name = "TabPage_MuraBlobParam"
        Me.TabPage_MuraBlobParam.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_MuraBlobParam.Size = New System.Drawing.Size(376, 402)
        Me.TabPage_MuraBlobParam.TabIndex = 0
        '
        'GroupBox_Modify
        '
        Me.GroupBox_Modify.Controls.Add(Me.CheckBox_ShowMuraCenterByPass)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Manual)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Finish)
        Me.GroupBox_Modify.Controls.Add(Me.GroupBox_MuraCenterBlobByPass)
        Me.GroupBox_Modify.Location = New System.Drawing.Point(8, 59)
        Me.GroupBox_Modify.Name = "GroupBox_Modify"
        Me.GroupBox_Modify.Size = New System.Drawing.Size(362, 140)
        Me.GroupBox_Modify.TabIndex = 70
        Me.GroupBox_Modify.TabStop = False
        Me.GroupBox_Modify.Text = "Blob Mura ByPass 参数调整"
        '
        'CheckBox_ShowMuraCenterByPass
        '
        Me.CheckBox_ShowMuraCenterByPass.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_ShowMuraCenterByPass.Location = New System.Drawing.Point(262, 21)
        Me.CheckBox_ShowMuraCenterByPass.Name = "CheckBox_ShowMuraCenterByPass"
        Me.CheckBox_ShowMuraCenterByPass.Size = New System.Drawing.Size(95, 24)
        Me.CheckBox_ShowMuraCenterByPass.TabIndex = 12
        Me.CheckBox_ShowMuraCenterByPass.Text = "显示"
        '
        'RadioButton_Manual
        '
        Me.RadioButton_Manual.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Manual.Location = New System.Drawing.Point(129, 21)
        Me.RadioButton_Manual.Name = "RadioButton_Manual"
        Me.RadioButton_Manual.Size = New System.Drawing.Size(104, 24)
        Me.RadioButton_Manual.TabIndex = 10
        Me.RadioButton_Manual.Text = "手动设定"
        '
        'RadioButton_Finish
        '
        Me.RadioButton_Finish.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton_Finish.Location = New System.Drawing.Point(9, 21)
        Me.RadioButton_Finish.Name = "RadioButton_Finish"
        Me.RadioButton_Finish.Size = New System.Drawing.Size(112, 24)
        Me.RadioButton_Finish.TabIndex = 0
        Me.RadioButton_Finish.Text = "完成设定"
        '
        'GroupBox_MuraCenterBlobByPass
        '
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.NumericUpDown_MuraCenterBlobByPassRight)
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.Label_AreaRight)
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.NumericUpDown_MuraCenterBlobByPassLeft)
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.Label_AreaLeft)
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.NumericUpDown_MuraCenterBlobByPassTop)
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.Label_AreaBottom)
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.NumericUpDown_MuraCenterBlobByPassBotton)
        Me.GroupBox_MuraCenterBlobByPass.Controls.Add(Me.Label_AreaTop)
        Me.GroupBox_MuraCenterBlobByPass.Location = New System.Drawing.Point(8, 49)
        Me.GroupBox_MuraCenterBlobByPass.Name = "GroupBox_MuraCenterBlobByPass"
        Me.GroupBox_MuraCenterBlobByPass.Size = New System.Drawing.Size(348, 85)
        Me.GroupBox_MuraCenterBlobByPass.TabIndex = 9
        Me.GroupBox_MuraCenterBlobByPass.TabStop = False
        Me.GroupBox_MuraCenterBlobByPass.Text = "中心ByPass参数"
        '
        'NumericUpDown_MuraCenterBlobByPassRight
        '
        Me.NumericUpDown_MuraCenterBlobByPassRight.Location = New System.Drawing.Point(262, 52)
        Me.NumericUpDown_MuraCenterBlobByPassRight.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_MuraCenterBlobByPassRight.Name = "NumericUpDown_MuraCenterBlobByPassRight"
        Me.NumericUpDown_MuraCenterBlobByPassRight.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_MuraCenterBlobByPassRight.TabIndex = 8
        Me.NumericUpDown_MuraCenterBlobByPassRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_AreaRight
        '
        Me.Label_AreaRight.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_AreaRight.Location = New System.Drawing.Point(175, 53)
        Me.Label_AreaRight.Name = "Label_AreaRight"
        Me.Label_AreaRight.Size = New System.Drawing.Size(81, 23)
        Me.Label_AreaRight.TabIndex = 7
        Me.Label_AreaRight.Text = "右边界 :"
        Me.Label_AreaRight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_MuraCenterBlobByPassLeft
        '
        Me.NumericUpDown_MuraCenterBlobByPassLeft.Location = New System.Drawing.Point(101, 52)
        Me.NumericUpDown_MuraCenterBlobByPassLeft.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_MuraCenterBlobByPassLeft.Name = "NumericUpDown_MuraCenterBlobByPassLeft"
        Me.NumericUpDown_MuraCenterBlobByPassLeft.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_MuraCenterBlobByPassLeft.TabIndex = 6
        Me.NumericUpDown_MuraCenterBlobByPassLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_AreaLeft
        '
        Me.Label_AreaLeft.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_AreaLeft.Location = New System.Drawing.Point(8, 53)
        Me.Label_AreaLeft.Name = "Label_AreaLeft"
        Me.Label_AreaLeft.Size = New System.Drawing.Size(81, 23)
        Me.Label_AreaLeft.TabIndex = 5
        Me.Label_AreaLeft.Text = "左边界 :"
        Me.Label_AreaLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_MuraCenterBlobByPassTop
        '
        Me.NumericUpDown_MuraCenterBlobByPassTop.Location = New System.Drawing.Point(101, 22)
        Me.NumericUpDown_MuraCenterBlobByPassTop.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_MuraCenterBlobByPassTop.Name = "NumericUpDown_MuraCenterBlobByPassTop"
        Me.NumericUpDown_MuraCenterBlobByPassTop.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_MuraCenterBlobByPassTop.TabIndex = 2
        Me.NumericUpDown_MuraCenterBlobByPassTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_AreaBottom
        '
        Me.Label_AreaBottom.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_AreaBottom.Location = New System.Drawing.Point(175, 23)
        Me.Label_AreaBottom.Name = "Label_AreaBottom"
        Me.Label_AreaBottom.Size = New System.Drawing.Size(81, 23)
        Me.Label_AreaBottom.TabIndex = 3
        Me.Label_AreaBottom.Text = "下边界 :"
        Me.Label_AreaBottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_MuraCenterBlobByPassBotton
        '
        Me.NumericUpDown_MuraCenterBlobByPassBotton.Location = New System.Drawing.Point(262, 22)
        Me.NumericUpDown_MuraCenterBlobByPassBotton.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_MuraCenterBlobByPassBotton.Name = "NumericUpDown_MuraCenterBlobByPassBotton"
        Me.NumericUpDown_MuraCenterBlobByPassBotton.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_MuraCenterBlobByPassBotton.TabIndex = 4
        Me.NumericUpDown_MuraCenterBlobByPassBotton.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_AreaTop
        '
        Me.Label_AreaTop.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_AreaTop.Location = New System.Drawing.Point(8, 23)
        Me.Label_AreaTop.Name = "Label_AreaTop"
        Me.Label_AreaTop.Size = New System.Drawing.Size(81, 23)
        Me.Label_AreaTop.TabIndex = 1
        Me.Label_AreaTop.Text = "上边界 :"
        Me.Label_AreaTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button_AnalysisMuraBlob
        '
        Me.Button_AnalysisMuraBlob.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_AnalysisMuraBlob.Location = New System.Drawing.Point(6, 9)
        Me.Button_AnalysisMuraBlob.Name = "Button_AnalysisMuraBlob"
        Me.Button_AnalysisMuraBlob.Size = New System.Drawing.Size(137, 36)
        Me.Button_AnalysisMuraBlob.TabIndex = 71
        Me.Button_AnalysisMuraBlob.Text = "分析點狀MURA"
        '
        'GroupBox_MuraCenterBlobThreshold
        '
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.Label7)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.Label8)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.NUD_BlackBlobMura_ReconstructLow)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.NUD_WhiteBlobMura_ReconstructLow)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.Label37)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.NUD_BlackMacroMura_Threshold)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.NUD_BlackBlobMura_ReconstructHeight)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.NUD_WhiteBlobMura_ReconstructHeight)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.NUD_WhiteMacroMura_Threshold)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.Label_ReconstructLow)
        Me.GroupBox_MuraCenterBlobThreshold.Controls.Add(Me.Label_ReconstructHeight)
        Me.GroupBox_MuraCenterBlobThreshold.Location = New System.Drawing.Point(6, 208)
        Me.GroupBox_MuraCenterBlobThreshold.Name = "GroupBox_MuraCenterBlobThreshold"
        Me.GroupBox_MuraCenterBlobThreshold.Size = New System.Drawing.Size(362, 141)
        Me.GroupBox_MuraCenterBlobThreshold.TabIndex = 74
        Me.GroupBox_MuraCenterBlobThreshold.TabStop = False
        Me.GroupBox_MuraCenterBlobThreshold.Text = "影像处理参数"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label7.Location = New System.Drawing.Point(300, 21)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 12)
        Me.Label7.TabIndex = 44
        Me.Label7.Text = "Black"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label8.Location = New System.Drawing.Point(218, 21)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(33, 12)
        Me.Label8.TabIndex = 43
        Me.Label8.Text = "White"
        '
        'NUD_BlackBlobMura_ReconstructLow
        '
        Me.NUD_BlackBlobMura_ReconstructLow.Location = New System.Drawing.Point(283, 75)
        Me.NUD_BlackBlobMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBlobMura_ReconstructLow.Name = "NUD_BlackBlobMura_ReconstructLow"
        Me.NUD_BlackBlobMura_ReconstructLow.Size = New System.Drawing.Size(73, 22)
        Me.NUD_BlackBlobMura_ReconstructLow.TabIndex = 42
        Me.NUD_BlackBlobMura_ReconstructLow.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteBlobMura_ReconstructLow
        '
        Me.NUD_WhiteBlobMura_ReconstructLow.Location = New System.Drawing.Point(202, 75)
        Me.NUD_WhiteBlobMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_ReconstructLow.Name = "NUD_WhiteBlobMura_ReconstructLow"
        Me.NUD_WhiteBlobMura_ReconstructLow.Size = New System.Drawing.Size(73, 22)
        Me.NUD_WhiteBlobMura_ReconstructLow.TabIndex = 41
        Me.NUD_WhiteBlobMura_ReconstructLow.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label37
        '
        Me.Label37.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label37.Location = New System.Drawing.Point(4, 76)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(179, 23)
        Me.Label37.TabIndex = 40
        Me.Label37.Text = "Blob Reconstruct Low :"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_BlackMacroMura_Threshold
        '
        Me.NUD_BlackMacroMura_Threshold.Location = New System.Drawing.Point(283, 108)
        Me.NUD_BlackMacroMura_Threshold.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackMacroMura_Threshold.Name = "NUD_BlackMacroMura_Threshold"
        Me.NUD_BlackMacroMura_Threshold.Size = New System.Drawing.Size(73, 22)
        Me.NUD_BlackMacroMura_Threshold.TabIndex = 35
        Me.NUD_BlackMacroMura_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackBlobMura_ReconstructHeight
        '
        Me.NUD_BlackBlobMura_ReconstructHeight.Location = New System.Drawing.Point(283, 42)
        Me.NUD_BlackBlobMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBlobMura_ReconstructHeight.Name = "NUD_BlackBlobMura_ReconstructHeight"
        Me.NUD_BlackBlobMura_ReconstructHeight.Size = New System.Drawing.Size(73, 22)
        Me.NUD_BlackBlobMura_ReconstructHeight.TabIndex = 34
        Me.NUD_BlackBlobMura_ReconstructHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteBlobMura_ReconstructHeight
        '
        Me.NUD_WhiteBlobMura_ReconstructHeight.Location = New System.Drawing.Point(202, 42)
        Me.NUD_WhiteBlobMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_ReconstructHeight.Name = "NUD_WhiteBlobMura_ReconstructHeight"
        Me.NUD_WhiteBlobMura_ReconstructHeight.Size = New System.Drawing.Size(73, 22)
        Me.NUD_WhiteBlobMura_ReconstructHeight.TabIndex = 31
        Me.NUD_WhiteBlobMura_ReconstructHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteMacroMura_Threshold
        '
        Me.NUD_WhiteMacroMura_Threshold.Location = New System.Drawing.Point(202, 108)
        Me.NUD_WhiteMacroMura_Threshold.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteMacroMura_Threshold.Name = "NUD_WhiteMacroMura_Threshold"
        Me.NUD_WhiteMacroMura_Threshold.Size = New System.Drawing.Size(73, 22)
        Me.NUD_WhiteMacroMura_Threshold.TabIndex = 33
        Me.NUD_WhiteMacroMura_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_ReconstructLow
        '
        Me.Label_ReconstructLow.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_ReconstructLow.Location = New System.Drawing.Point(4, 109)
        Me.Label_ReconstructLow.Name = "Label_ReconstructLow"
        Me.Label_ReconstructLow.Size = New System.Drawing.Size(179, 23)
        Me.Label_ReconstructLow.TabIndex = 32
        Me.Label_ReconstructLow.Text = "Macro Mura Threshold :"
        Me.Label_ReconstructLow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_ReconstructHeight
        '
        Me.Label_ReconstructHeight.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_ReconstructHeight.Location = New System.Drawing.Point(4, 43)
        Me.Label_ReconstructHeight.Name = "Label_ReconstructHeight"
        Me.Label_ReconstructHeight.Size = New System.Drawing.Size(179, 23)
        Me.Label_ReconstructHeight.TabIndex = 30
        Me.Label_ReconstructHeight.Text = "Blob Reconstruct Height :"
        Me.Label_ReconstructHeight.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CheckBox_UseReconstructBW
        '
        Me.CheckBox_UseReconstructBW.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_UseReconstructBW.Location = New System.Drawing.Point(164, 16)
        Me.CheckBox_UseReconstructBW.Name = "CheckBox_UseReconstructBW"
        Me.CheckBox_UseReconstructBW.Size = New System.Drawing.Size(183, 24)
        Me.CheckBox_UseReconstructBW.TabIndex = 77
        Me.CheckBox_UseReconstructBW.Text = "UseReconstructBW"
        Me.CheckBox_UseReconstructBW.Visible = False
        '
        'TabPage_MuraAroundParam
        '
        Me.TabPage_MuraAroundParam.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage_MuraAroundParam.Controls.Add(Me.GroupBox_RimBlobValue)
        Me.TabPage_MuraAroundParam.Controls.Add(Me.Button_AnalysisMuraAround)
        Me.TabPage_MuraAroundParam.Controls.Add(Me.GroupBox_MuraAroundByPass)
        Me.TabPage_MuraAroundParam.Controls.Add(Me.GroupBox_MuraAroundThreshold)
        Me.TabPage_MuraAroundParam.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_MuraAroundParam.Name = "TabPage_MuraAroundParam"
        Me.TabPage_MuraAroundParam.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_MuraAroundParam.Size = New System.Drawing.Size(376, 402)
        Me.TabPage_MuraAroundParam.TabIndex = 1
        '
        'GroupBox_RimBlobValue
        '
        Me.GroupBox_RimBlobValue.Controls.Add(Me.NumericUpDown_BlackRimBlobValue)
        Me.GroupBox_RimBlobValue.Controls.Add(Me.NumericUpDown_WhiteRimBlobValue)
        Me.GroupBox_RimBlobValue.Controls.Add(Me.CheckBox_BlackRimBlobValue)
        Me.GroupBox_RimBlobValue.Controls.Add(Me.CheckBox_WhiteRimBlobValue)
        Me.GroupBox_RimBlobValue.Location = New System.Drawing.Point(8, 307)
        Me.GroupBox_RimBlobValue.Name = "GroupBox_RimBlobValue"
        Me.GroupBox_RimBlobValue.Size = New System.Drawing.Size(362, 89)
        Me.GroupBox_RimBlobValue.TabIndex = 93
        Me.GroupBox_RimBlobValue.TabStop = False
        Me.GroupBox_RimBlobValue.Text = "Rim Blob Value"
        Me.GroupBox_RimBlobValue.Visible = False
        '
        'NumericUpDown_BlackRimBlobValue
        '
        Me.NumericUpDown_BlackRimBlobValue.Location = New System.Drawing.Point(279, 54)
        Me.NumericUpDown_BlackRimBlobValue.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_BlackRimBlobValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BlackRimBlobValue.Name = "NumericUpDown_BlackRimBlobValue"
        Me.NumericUpDown_BlackRimBlobValue.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_BlackRimBlobValue.TabIndex = 84
        Me.NumericUpDown_BlackRimBlobValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_BlackRimBlobValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_WhiteRimBlobValue
        '
        Me.NumericUpDown_WhiteRimBlobValue.Location = New System.Drawing.Point(279, 21)
        Me.NumericUpDown_WhiteRimBlobValue.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_WhiteRimBlobValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_WhiteRimBlobValue.Name = "NumericUpDown_WhiteRimBlobValue"
        Me.NumericUpDown_WhiteRimBlobValue.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_WhiteRimBlobValue.TabIndex = 9
        Me.NumericUpDown_WhiteRimBlobValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_WhiteRimBlobValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CheckBox_BlackRimBlobValue
        '
        Me.CheckBox_BlackRimBlobValue.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_BlackRimBlobValue.Location = New System.Drawing.Point(12, 54)
        Me.CheckBox_BlackRimBlobValue.Name = "CheckBox_BlackRimBlobValue"
        Me.CheckBox_BlackRimBlobValue.Size = New System.Drawing.Size(234, 24)
        Me.CheckBox_BlackRimBlobValue.TabIndex = 83
        Me.CheckBox_BlackRimBlobValue.Text = "Black Rim Blob Value Enable"
        '
        'CheckBox_WhiteRimBlobValue
        '
        Me.CheckBox_WhiteRimBlobValue.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_WhiteRimBlobValue.Location = New System.Drawing.Point(12, 21)
        Me.CheckBox_WhiteRimBlobValue.Name = "CheckBox_WhiteRimBlobValue"
        Me.CheckBox_WhiteRimBlobValue.Size = New System.Drawing.Size(234, 24)
        Me.CheckBox_WhiteRimBlobValue.TabIndex = 82
        Me.CheckBox_WhiteRimBlobValue.Text = "White Rim Blob Value Enable"
        '
        'Button_AnalysisMuraAround
        '
        Me.Button_AnalysisMuraAround.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_AnalysisMuraAround.Location = New System.Drawing.Point(6, 8)
        Me.Button_AnalysisMuraAround.Name = "Button_AnalysisMuraAround"
        Me.Button_AnalysisMuraAround.Size = New System.Drawing.Size(161, 36)
        Me.Button_AnalysisMuraAround.TabIndex = 86
        Me.Button_AnalysisMuraAround.Text = "分析边框MURA"
        '
        'GroupBox_MuraAroundByPass
        '
        Me.GroupBox_MuraAroundByPass.Controls.Add(Me.CheckBox_ShowMuraAoundByPass)
        Me.GroupBox_MuraAroundByPass.Controls.Add(Me.RadioButton1)
        Me.GroupBox_MuraAroundByPass.Controls.Add(Me.RadioButton2)
        Me.GroupBox_MuraAroundByPass.Controls.Add(Me.GroupBox_Round)
        Me.GroupBox_MuraAroundByPass.Location = New System.Drawing.Point(8, 56)
        Me.GroupBox_MuraAroundByPass.Name = "GroupBox_MuraAroundByPass"
        Me.GroupBox_MuraAroundByPass.Size = New System.Drawing.Size(362, 133)
        Me.GroupBox_MuraAroundByPass.TabIndex = 85
        Me.GroupBox_MuraAroundByPass.TabStop = False
        Me.GroupBox_MuraAroundByPass.Text = "ByPass参数调整"
        '
        'CheckBox_ShowMuraAoundByPass
        '
        Me.CheckBox_ShowMuraAoundByPass.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_ShowMuraAoundByPass.Location = New System.Drawing.Point(190, 17)
        Me.CheckBox_ShowMuraAoundByPass.Name = "CheckBox_ShowMuraAoundByPass"
        Me.CheckBox_ShowMuraAoundByPass.Size = New System.Drawing.Size(66, 24)
        Me.CheckBox_ShowMuraAoundByPass.TabIndex = 12
        Me.CheckBox_ShowMuraAoundByPass.Text = "显示"
        '
        'RadioButton1
        '
        Me.RadioButton1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton1.Location = New System.Drawing.Point(112, 16)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(72, 24)
        Me.RadioButton1.TabIndex = 10
        Me.RadioButton1.Text = "手动设定"
        '
        'RadioButton2
        '
        Me.RadioButton2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton2.Location = New System.Drawing.Point(8, 16)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(72, 24)
        Me.RadioButton2.TabIndex = 0
        Me.RadioButton2.Text = "完成设定"
        '
        'GroupBox_Round
        '
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimRight)
        Me.GroupBox_Round.Controls.Add(Me.Label_Right)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimLeft)
        Me.GroupBox_Round.Controls.Add(Me.Label_Left)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimTop)
        Me.GroupBox_Round.Controls.Add(Me.Label_Bottom)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimBottom)
        Me.GroupBox_Round.Controls.Add(Me.Label_Top)
        Me.GroupBox_Round.Location = New System.Drawing.Point(8, 40)
        Me.GroupBox_Round.Name = "GroupBox_Round"
        Me.GroupBox_Round.Size = New System.Drawing.Size(348, 89)
        Me.GroupBox_Round.TabIndex = 9
        Me.GroupBox_Round.TabStop = False
        Me.GroupBox_Round.Text = "ByPass参数"
        '
        'NumericUpDown_RimRight
        '
        Me.NumericUpDown_RimRight.Location = New System.Drawing.Point(257, 48)
        Me.NumericUpDown_RimRight.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_RimRight.Name = "NumericUpDown_RimRight"
        Me.NumericUpDown_RimRight.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_RimRight.TabIndex = 8
        Me.NumericUpDown_RimRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_RimRight.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Right
        '
        Me.Label_Right.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_Right.Location = New System.Drawing.Point(172, 49)
        Me.Label_Right.Name = "Label_Right"
        Me.Label_Right.Size = New System.Drawing.Size(79, 23)
        Me.Label_Right.TabIndex = 7
        Me.Label_Right.Text = "右边界 :"
        Me.Label_Right.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_RimLeft
        '
        Me.NumericUpDown_RimLeft.Location = New System.Drawing.Point(93, 48)
        Me.NumericUpDown_RimLeft.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_RimLeft.Name = "NumericUpDown_RimLeft"
        Me.NumericUpDown_RimLeft.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_RimLeft.TabIndex = 6
        Me.NumericUpDown_RimLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_RimLeft.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Left
        '
        Me.Label_Left.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_Left.Location = New System.Drawing.Point(8, 49)
        Me.Label_Left.Name = "Label_Left"
        Me.Label_Left.Size = New System.Drawing.Size(79, 23)
        Me.Label_Left.TabIndex = 5
        Me.Label_Left.Text = "左边界 :"
        Me.Label_Left.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_RimTop
        '
        Me.NumericUpDown_RimTop.Location = New System.Drawing.Point(93, 17)
        Me.NumericUpDown_RimTop.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_RimTop.Name = "NumericUpDown_RimTop"
        Me.NumericUpDown_RimTop.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_RimTop.TabIndex = 2
        Me.NumericUpDown_RimTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_RimTop.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Bottom
        '
        Me.Label_Bottom.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_Bottom.Location = New System.Drawing.Point(172, 18)
        Me.Label_Bottom.Name = "Label_Bottom"
        Me.Label_Bottom.Size = New System.Drawing.Size(79, 23)
        Me.Label_Bottom.TabIndex = 3
        Me.Label_Bottom.Text = "下边界 :"
        Me.Label_Bottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_RimBottom
        '
        Me.NumericUpDown_RimBottom.Location = New System.Drawing.Point(257, 17)
        Me.NumericUpDown_RimBottom.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_RimBottom.Name = "NumericUpDown_RimBottom"
        Me.NumericUpDown_RimBottom.Size = New System.Drawing.Size(72, 22)
        Me.NumericUpDown_RimBottom.TabIndex = 4
        Me.NumericUpDown_RimBottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_RimBottom.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Top
        '
        Me.Label_Top.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_Top.Location = New System.Drawing.Point(8, 18)
        Me.Label_Top.Name = "Label_Top"
        Me.Label_Top.Size = New System.Drawing.Size(79, 23)
        Me.Label_Top.TabIndex = 1
        Me.Label_Top.Text = "上边界 :"
        Me.Label_Top.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_MuraAroundThreshold
        '
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.Label9)
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.Label14)
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.NumericUpDown_BlackMura_ReconstructLow)
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.NumericUpDown_BlackMura_ReconstructHeight)
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.NumericUpDown_WhiteMura_ReconstructLow)
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.Label40)
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.Label41)
        Me.GroupBox_MuraAroundThreshold.Controls.Add(Me.NumericUpDown_WhiteMura_ReconstructHeight)
        Me.GroupBox_MuraAroundThreshold.Location = New System.Drawing.Point(8, 195)
        Me.GroupBox_MuraAroundThreshold.Name = "GroupBox_MuraAroundThreshold"
        Me.GroupBox_MuraAroundThreshold.Size = New System.Drawing.Size(362, 106)
        Me.GroupBox_MuraAroundThreshold.TabIndex = 89
        Me.GroupBox_MuraAroundThreshold.TabStop = False
        Me.GroupBox_MuraAroundThreshold.Text = "影像处理参数"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label9.Location = New System.Drawing.Point(296, 18)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 12)
        Me.Label9.TabIndex = 51
        Me.Label9.Text = "Black"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label14.Location = New System.Drawing.Point(216, 18)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 12)
        Me.Label14.TabIndex = 50
        Me.Label14.Text = "White"
        '
        'NumericUpDown_BlackMura_ReconstructLow
        '
        Me.NumericUpDown_BlackMura_ReconstructLow.Location = New System.Drawing.Point(279, 69)
        Me.NumericUpDown_BlackMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_ReconstructLow.Name = "NumericUpDown_BlackMura_ReconstructLow"
        Me.NumericUpDown_BlackMura_ReconstructLow.Size = New System.Drawing.Size(73, 22)
        Me.NumericUpDown_BlackMura_ReconstructLow.TabIndex = 49
        Me.NumericUpDown_BlackMura_ReconstructLow.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_BlackMura_ReconstructHeight
        '
        Me.NumericUpDown_BlackMura_ReconstructHeight.Location = New System.Drawing.Point(279, 39)
        Me.NumericUpDown_BlackMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_ReconstructHeight.Name = "NumericUpDown_BlackMura_ReconstructHeight"
        Me.NumericUpDown_BlackMura_ReconstructHeight.Size = New System.Drawing.Size(73, 22)
        Me.NumericUpDown_BlackMura_ReconstructHeight.TabIndex = 48
        Me.NumericUpDown_BlackMura_ReconstructHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_WhiteMura_ReconstructLow
        '
        Me.NumericUpDown_WhiteMura_ReconstructLow.Location = New System.Drawing.Point(200, 69)
        Me.NumericUpDown_WhiteMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_ReconstructLow.Name = "NumericUpDown_WhiteMura_ReconstructLow"
        Me.NumericUpDown_WhiteMura_ReconstructLow.Size = New System.Drawing.Size(73, 22)
        Me.NumericUpDown_WhiteMura_ReconstructLow.TabIndex = 47
        Me.NumericUpDown_WhiteMura_ReconstructLow.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label40
        '
        Me.Label40.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label40.Location = New System.Drawing.Point(8, 70)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(169, 23)
        Me.Label40.TabIndex = 43
        Me.Label40.Text = "边框 Reconstruct Low :"
        Me.Label40.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label41
        '
        Me.Label41.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label41.Location = New System.Drawing.Point(8, 40)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(169, 23)
        Me.Label41.TabIndex = 42
        Me.Label41.Text = "边框 Reconstruct Height :"
        Me.Label41.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown_WhiteMura_ReconstructHeight
        '
        Me.NumericUpDown_WhiteMura_ReconstructHeight.Location = New System.Drawing.Point(200, 39)
        Me.NumericUpDown_WhiteMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_ReconstructHeight.Name = "NumericUpDown_WhiteMura_ReconstructHeight"
        Me.NumericUpDown_WhiteMura_ReconstructHeight.Size = New System.Drawing.Size(73, 22)
        Me.NumericUpDown_WhiteMura_ReconstructHeight.TabIndex = 46
        Me.NumericUpDown_WhiteMura_ReconstructHeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TabPage_MuraBandParam
        '
        Me.TabPage_MuraBandParam.AutoScroll = True
        Me.TabPage_MuraBandParam.BackColor = System.Drawing.Color.FloralWhite
        Me.TabPage_MuraBandParam.Controls.Add(Me.GroupBox_BandVOpenSearch)
        Me.TabPage_MuraBandParam.Controls.Add(Me.Button_AnalysisMuraBand)
        Me.TabPage_MuraBandParam.Controls.Add(Me.GroupBox_BandBlockH)
        Me.TabPage_MuraBandParam.Controls.Add(Me.GroupBox_BandLeakPoint)
        Me.TabPage_MuraBandParam.Controls.Add(Me.ComboBox_MuraBandResult)
        Me.TabPage_MuraBandParam.Controls.Add(Me.CheckBox_BandUseRemoveHV)
        Me.TabPage_MuraBandParam.Controls.Add(Me.GroupBox_BandResizeThreshold)
        Me.TabPage_MuraBandParam.Controls.Add(Me.CheckBox_MuraBandResult)
        Me.TabPage_MuraBandParam.Controls.Add(Me.GroupBox_BandBlockV)
        Me.TabPage_MuraBandParam.Controls.Add(Me.GroupBox_BandByPass)
        Me.TabPage_MuraBandParam.Controls.Add(Me.GroupBox_BandBlockSetting)
        Me.TabPage_MuraBandParam.Location = New System.Drawing.Point(4, 14)
        Me.TabPage_MuraBandParam.Name = "TabPage_MuraBandParam"
        Me.TabPage_MuraBandParam.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_MuraBandParam.Size = New System.Drawing.Size(376, 402)
        Me.TabPage_MuraBandParam.TabIndex = 2
        '
        'GroupBox_BandVOpenSearch
        '
        Me.GroupBox_BandVOpenSearch.Controls.Add(Me.NumericUpDown_BandVOpenEdgeStrength)
        Me.GroupBox_BandVOpenSearch.Controls.Add(Me.Label42)
        Me.GroupBox_BandVOpenSearch.Controls.Add(Me.CheckBox_EnableBandVOpen)
        Me.GroupBox_BandVOpenSearch.Location = New System.Drawing.Point(8, 1148)
        Me.GroupBox_BandVOpenSearch.Name = "GroupBox_BandVOpenSearch"
        Me.GroupBox_BandVOpenSearch.Size = New System.Drawing.Size(273, 101)
        Me.GroupBox_BandVOpenSearch.TabIndex = 106
        Me.GroupBox_BandVOpenSearch.TabStop = False
        Me.GroupBox_BandVOpenSearch.Text = "V Open Search"
        '
        'NumericUpDown_BandVOpenEdgeStrength
        '
        Me.NumericUpDown_BandVOpenEdgeStrength.Location = New System.Drawing.Point(140, 56)
        Me.NumericUpDown_BandVOpenEdgeStrength.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.NumericUpDown_BandVOpenEdgeStrength.Name = "NumericUpDown_BandVOpenEdgeStrength"
        Me.NumericUpDown_BandVOpenEdgeStrength.Size = New System.Drawing.Size(77, 22)
        Me.NumericUpDown_BandVOpenEdgeStrength.TabIndex = 6
        Me.NumericUpDown_BandVOpenEdgeStrength.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_BandVOpenEdgeStrength.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Label42
        '
        Me.Label42.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label42.Location = New System.Drawing.Point(6, 57)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(126, 23)
        Me.Label42.TabIndex = 5
        Me.Label42.Text = "Edge Strngth :"
        Me.Label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CheckBox_EnableBandVOpen
        '
        Me.CheckBox_EnableBandVOpen.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_EnableBandVOpen.Location = New System.Drawing.Point(6, 24)
        Me.CheckBox_EnableBandVOpen.Name = "CheckBox_EnableBandVOpen"
        Me.CheckBox_EnableBandVOpen.Size = New System.Drawing.Size(182, 24)
        Me.CheckBox_EnableBandVOpen.TabIndex = 85
        Me.CheckBox_EnableBandVOpen.Text = "Enable Vopen"
        '
        'Button_AnalysisMuraBand
        '
        Me.Button_AnalysisMuraBand.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_AnalysisMuraBand.Location = New System.Drawing.Point(3, 6)
        Me.Button_AnalysisMuraBand.Name = "Button_AnalysisMuraBand"
        Me.Button_AnalysisMuraBand.Size = New System.Drawing.Size(161, 36)
        Me.Button_AnalysisMuraBand.TabIndex = 96
        Me.Button_AnalysisMuraBand.Text = "分析帶狀MURA"
        '
        'GroupBox_BandBlockH
        '
        Me.GroupBox_BandBlockH.Controls.Add(Me.ListView_HBlock)
        Me.GroupBox_BandBlockH.Location = New System.Drawing.Point(8, 589)
        Me.GroupBox_BandBlockH.Name = "GroupBox_BandBlockH"
        Me.GroupBox_BandBlockH.Size = New System.Drawing.Size(390, 149)
        Me.GroupBox_BandBlockH.TabIndex = 102
        Me.GroupBox_BandBlockH.TabStop = False
        Me.GroupBox_BandBlockH.Text = "H-Block TH Setting"
        '
        'ListView_HBlock
        '
        Me.ListView_HBlock.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader13})
        Me.ListView_HBlock.FullRowSelect = True
        Me.ListView_HBlock.GridLines = True
        Me.ListView_HBlock.Location = New System.Drawing.Point(13, 16)
        Me.ListView_HBlock.Name = "ListView_HBlock"
        Me.ListView_HBlock.Size = New System.Drawing.Size(364, 117)
        Me.ListView_HBlock.TabIndex = 53
        Me.ListView_HBlock.UseCompatibleStateImageBehavior = False
        Me.ListView_HBlock.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "左边界"
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "上边界"
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "右边界"
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "下边界"
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "White TH"
        Me.ColumnHeader6.Width = 65
        '
        'ColumnHeader13
        '
        Me.ColumnHeader13.Text = "Black TH"
        '
        'GroupBox_BandLeakPoint
        '
        Me.GroupBox_BandLeakPoint.Controls.Add(Me.CheckBox_EnableBandLeakPoint)
        Me.GroupBox_BandLeakPoint.Controls.Add(Me.Label43)
        Me.GroupBox_BandLeakPoint.Controls.Add(Me.NumericUpDown_BandLeakPointFilterRadius)
        Me.GroupBox_BandLeakPoint.Location = New System.Drawing.Point(8, 1061)
        Me.GroupBox_BandLeakPoint.Name = "GroupBox_BandLeakPoint"
        Me.GroupBox_BandLeakPoint.Size = New System.Drawing.Size(273, 81)
        Me.GroupBox_BandLeakPoint.TabIndex = 105
        Me.GroupBox_BandLeakPoint.TabStop = False
        Me.GroupBox_BandLeakPoint.Text = "Leak Point ( Need RemoveHV for Blob)"
        '
        'CheckBox_EnableBandLeakPoint
        '
        Me.CheckBox_EnableBandLeakPoint.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_EnableBandLeakPoint.Location = New System.Drawing.Point(6, 24)
        Me.CheckBox_EnableBandLeakPoint.Name = "CheckBox_EnableBandLeakPoint"
        Me.CheckBox_EnableBandLeakPoint.Size = New System.Drawing.Size(182, 24)
        Me.CheckBox_EnableBandLeakPoint.TabIndex = 85
        Me.CheckBox_EnableBandLeakPoint.Text = "Enable LeakPoint Serach"
        '
        'Label43
        '
        Me.Label43.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label43.Location = New System.Drawing.Point(6, 55)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(106, 23)
        Me.Label43.TabIndex = 5
        Me.Label43.Text = "Filter Radius :"
        Me.Label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BandLeakPointFilterRadius
        '
        Me.NumericUpDown_BandLeakPointFilterRadius.Location = New System.Drawing.Point(120, 54)
        Me.NumericUpDown_BandLeakPointFilterRadius.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BandLeakPointFilterRadius.Name = "NumericUpDown_BandLeakPointFilterRadius"
        Me.NumericUpDown_BandLeakPointFilterRadius.Size = New System.Drawing.Size(77, 22)
        Me.NumericUpDown_BandLeakPointFilterRadius.TabIndex = 6
        Me.NumericUpDown_BandLeakPointFilterRadius.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'ComboBox_MuraBandResult
        '
        Me.ComboBox_MuraBandResult.FormattingEnabled = True
        Me.ComboBox_MuraBandResult.Items.AddRange(New Object() {"Black", "White"})
        Me.ComboBox_MuraBandResult.Location = New System.Drawing.Point(76, 56)
        Me.ComboBox_MuraBandResult.Name = "ComboBox_MuraBandResult"
        Me.ComboBox_MuraBandResult.Size = New System.Drawing.Size(90, 20)
        Me.ComboBox_MuraBandResult.TabIndex = 94
        '
        'CheckBox_BandUseRemoveHV
        '
        Me.CheckBox_BandUseRemoveHV.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_BandUseRemoveHV.Location = New System.Drawing.Point(172, 55)
        Me.CheckBox_BandUseRemoveHV.Name = "CheckBox_BandUseRemoveHV"
        Me.CheckBox_BandUseRemoveHV.Size = New System.Drawing.Size(107, 24)
        Me.CheckBox_BandUseRemoveHV.TabIndex = 104
        Me.CheckBox_BandUseRemoveHV.Text = "Band RemoveHV"
        '
        'GroupBox_BandResizeThreshold
        '
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.Label54)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.Label55)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.NumericUpDown_BlackVBand_Threshold)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.NumericUpDown_BlackHBand_Threshold)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.NumericUpDown_BandMura_SmoothCount)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.Label_Band_SmoothCount)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.NumericUpDown_BandMura_ResizeCount)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.Label_Band_ResizeCount)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.NumericUpDown_WhiteHBand_Threshold)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.NumericUpDown_WhiteVBand_Threshold)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.Label_BlackBand_Thrshold)
        Me.GroupBox_BandResizeThreshold.Controls.Add(Me.Label_HBand_Thrshold)
        Me.GroupBox_BandResizeThreshold.Location = New System.Drawing.Point(6, 92)
        Me.GroupBox_BandResizeThreshold.Name = "GroupBox_BandResizeThreshold"
        Me.GroupBox_BandResizeThreshold.Size = New System.Drawing.Size(338, 153)
        Me.GroupBox_BandResizeThreshold.TabIndex = 99
        Me.GroupBox_BandResizeThreshold.TabStop = False
        Me.GroupBox_BandResizeThreshold.Text = "影像处理参数"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label54.Location = New System.Drawing.Point(265, 75)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(32, 12)
        Me.Label54.TabIndex = 41
        Me.Label54.Text = "Black"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label55.Location = New System.Drawing.Point(171, 75)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(33, 12)
        Me.Label55.TabIndex = 40
        Me.Label55.Text = "White"
        '
        'NumericUpDown_BlackVBand_Threshold
        '
        Me.NumericUpDown_BlackVBand_Threshold.Location = New System.Drawing.Point(245, 118)
        Me.NumericUpDown_BlackVBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlackVBand_Threshold.Name = "NumericUpDown_BlackVBand_Threshold"
        Me.NumericUpDown_BlackVBand_Threshold.Size = New System.Drawing.Size(84, 22)
        Me.NumericUpDown_BlackVBand_Threshold.TabIndex = 39
        Me.NumericUpDown_BlackVBand_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_BlackVBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_BlackHBand_Threshold
        '
        Me.NumericUpDown_BlackHBand_Threshold.Location = New System.Drawing.Point(245, 93)
        Me.NumericUpDown_BlackHBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlackHBand_Threshold.Name = "NumericUpDown_BlackHBand_Threshold"
        Me.NumericUpDown_BlackHBand_Threshold.Size = New System.Drawing.Size(84, 22)
        Me.NumericUpDown_BlackHBand_Threshold.TabIndex = 38
        Me.NumericUpDown_BlackHBand_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_BlackHBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_BandMura_SmoothCount
        '
        Me.NumericUpDown_BandMura_SmoothCount.Location = New System.Drawing.Point(134, 44)
        Me.NumericUpDown_BandMura_SmoothCount.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BandMura_SmoothCount.Name = "NumericUpDown_BandMura_SmoothCount"
        Me.NumericUpDown_BandMura_SmoothCount.Size = New System.Drawing.Size(112, 22)
        Me.NumericUpDown_BandMura_SmoothCount.TabIndex = 37
        Me.NumericUpDown_BandMura_SmoothCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_Band_SmoothCount
        '
        Me.Label_Band_SmoothCount.AutoSize = True
        Me.Label_Band_SmoothCount.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_Band_SmoothCount.Location = New System.Drawing.Point(8, 49)
        Me.Label_Band_SmoothCount.Name = "Label_Band_SmoothCount"
        Me.Label_Band_SmoothCount.Size = New System.Drawing.Size(93, 12)
        Me.Label_Band_SmoothCount.TabIndex = 36
        Me.Label_Band_SmoothCount.Text = "Band 平滑次数："
        '
        'NumericUpDown_BandMura_ResizeCount
        '
        Me.NumericUpDown_BandMura_ResizeCount.Location = New System.Drawing.Point(134, 19)
        Me.NumericUpDown_BandMura_ResizeCount.Maximum = New Decimal(New Integer() {4, 0, 0, 0})
        Me.NumericUpDown_BandMura_ResizeCount.Name = "NumericUpDown_BandMura_ResizeCount"
        Me.NumericUpDown_BandMura_ResizeCount.Size = New System.Drawing.Size(112, 22)
        Me.NumericUpDown_BandMura_ResizeCount.TabIndex = 35
        Me.NumericUpDown_BandMura_ResizeCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_Band_ResizeCount
        '
        Me.Label_Band_ResizeCount.AutoSize = True
        Me.Label_Band_ResizeCount.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_Band_ResizeCount.Location = New System.Drawing.Point(8, 24)
        Me.Label_Band_ResizeCount.Name = "Label_Band_ResizeCount"
        Me.Label_Band_ResizeCount.Size = New System.Drawing.Size(93, 12)
        Me.Label_Band_ResizeCount.TabIndex = 34
        Me.Label_Band_ResizeCount.Text = "Band 缩放次数："
        '
        'NumericUpDown_WhiteHBand_Threshold
        '
        Me.NumericUpDown_WhiteHBand_Threshold.Location = New System.Drawing.Point(153, 93)
        Me.NumericUpDown_WhiteHBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_WhiteHBand_Threshold.Name = "NumericUpDown_WhiteHBand_Threshold"
        Me.NumericUpDown_WhiteHBand_Threshold.Size = New System.Drawing.Size(84, 22)
        Me.NumericUpDown_WhiteHBand_Threshold.TabIndex = 31
        Me.NumericUpDown_WhiteHBand_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_WhiteHBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_WhiteVBand_Threshold
        '
        Me.NumericUpDown_WhiteVBand_Threshold.Location = New System.Drawing.Point(153, 118)
        Me.NumericUpDown_WhiteVBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_WhiteVBand_Threshold.Name = "NumericUpDown_WhiteVBand_Threshold"
        Me.NumericUpDown_WhiteVBand_Threshold.Size = New System.Drawing.Size(84, 22)
        Me.NumericUpDown_WhiteVBand_Threshold.TabIndex = 33
        Me.NumericUpDown_WhiteVBand_Threshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_WhiteVBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_BlackBand_Thrshold
        '
        Me.Label_BlackBand_Thrshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_BlackBand_Thrshold.Location = New System.Drawing.Point(10, 119)
        Me.Label_BlackBand_Thrshold.Name = "Label_BlackBand_Thrshold"
        Me.Label_BlackBand_Thrshold.Size = New System.Drawing.Size(139, 23)
        Me.Label_BlackBand_Thrshold.TabIndex = 32
        Me.Label_BlackBand_Thrshold.Text = "V-Band Threshold："
        Me.Label_BlackBand_Thrshold.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_HBand_Thrshold
        '
        Me.Label_HBand_Thrshold.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_HBand_Thrshold.Location = New System.Drawing.Point(10, 94)
        Me.Label_HBand_Thrshold.Name = "Label_HBand_Thrshold"
        Me.Label_HBand_Thrshold.Size = New System.Drawing.Size(139, 23)
        Me.Label_HBand_Thrshold.TabIndex = 30
        Me.Label_HBand_Thrshold.Text = "H-Band Threshold："
        Me.Label_HBand_Thrshold.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CheckBox_MuraBandResult
        '
        Me.CheckBox_MuraBandResult.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_MuraBandResult.Location = New System.Drawing.Point(6, 55)
        Me.CheckBox_MuraBandResult.Name = "CheckBox_MuraBandResult"
        Me.CheckBox_MuraBandResult.Size = New System.Drawing.Size(64, 24)
        Me.CheckBox_MuraBandResult.TabIndex = 93
        Me.CheckBox_MuraBandResult.Text = "Result"
        '
        'GroupBox_BandBlockV
        '
        Me.GroupBox_BandBlockV.Controls.Add(Me.ListView_VBlock)
        Me.GroupBox_BandBlockV.Location = New System.Drawing.Point(8, 749)
        Me.GroupBox_BandBlockV.Name = "GroupBox_BandBlockV"
        Me.GroupBox_BandBlockV.Size = New System.Drawing.Size(387, 148)
        Me.GroupBox_BandBlockV.TabIndex = 103
        Me.GroupBox_BandBlockV.TabStop = False
        Me.GroupBox_BandBlockV.Text = "V-Block TH Setting"
        '
        'ListView_VBlock
        '
        Me.ListView_VBlock.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10, Me.ColumnHeader11, Me.ColumnHeader12})
        Me.ListView_VBlock.FullRowSelect = True
        Me.ListView_VBlock.GridLines = True
        Me.ListView_VBlock.Location = New System.Drawing.Point(11, 18)
        Me.ListView_VBlock.Name = "ListView_VBlock"
        Me.ListView_VBlock.Size = New System.Drawing.Size(364, 117)
        Me.ListView_VBlock.TabIndex = 54
        Me.ListView_VBlock.UseCompatibleStateImageBehavior = False
        Me.ListView_VBlock.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "左边界"
        '
        'ColumnHeader8
        '
        Me.ColumnHeader8.Text = "上边界"
        '
        'ColumnHeader9
        '
        Me.ColumnHeader9.Text = "右边界"
        '
        'ColumnHeader10
        '
        Me.ColumnHeader10.Text = "下边界"
        '
        'ColumnHeader11
        '
        Me.ColumnHeader11.Text = "White TH"
        Me.ColumnHeader11.Width = 65
        '
        'ColumnHeader12
        '
        Me.ColumnHeader12.Text = "Black TH"
        '
        'GroupBox_BandByPass
        '
        Me.GroupBox_BandByPass.Controls.Add(Me.ComboBox_ShowMuraBand)
        Me.GroupBox_BandByPass.Controls.Add(Me.CheckBox_ShowMuraBandByPass)
        Me.GroupBox_BandByPass.Controls.Add(Me.GroupBox_V)
        Me.GroupBox_BandByPass.Controls.Add(Me.RadioButton3)
        Me.GroupBox_BandByPass.Controls.Add(Me.RadioButton4)
        Me.GroupBox_BandByPass.Controls.Add(Me.GroupBox_H)
        Me.GroupBox_BandByPass.Location = New System.Drawing.Point(6, 251)
        Me.GroupBox_BandByPass.Name = "GroupBox_BandByPass"
        Me.GroupBox_BandByPass.Size = New System.Drawing.Size(338, 330)
        Me.GroupBox_BandByPass.TabIndex = 95
        Me.GroupBox_BandByPass.TabStop = False
        Me.GroupBox_BandByPass.Text = "ByPass参数调整"
        '
        'ComboBox_ShowMuraBand
        '
        Me.ComboBox_ShowMuraBand.FormattingEnabled = True
        Me.ComboBox_ShowMuraBand.Items.AddRange(New Object() {"V", "H"})
        Me.ComboBox_ShowMuraBand.Location = New System.Drawing.Point(262, 21)
        Me.ComboBox_ShowMuraBand.Name = "ComboBox_ShowMuraBand"
        Me.ComboBox_ShowMuraBand.Size = New System.Drawing.Size(70, 20)
        Me.ComboBox_ShowMuraBand.TabIndex = 13
        '
        'CheckBox_ShowMuraBandByPass
        '
        Me.CheckBox_ShowMuraBandByPass.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_ShowMuraBandByPass.Location = New System.Drawing.Point(196, 20)
        Me.CheckBox_ShowMuraBandByPass.Name = "CheckBox_ShowMuraBandByPass"
        Me.CheckBox_ShowMuraBandByPass.Size = New System.Drawing.Size(63, 24)
        Me.CheckBox_ShowMuraBandByPass.TabIndex = 12
        Me.CheckBox_ShowMuraBandByPass.Text = "显示"
        '
        'GroupBox_V
        '
        Me.GroupBox_V.Controls.Add(Me.TextBox_VHCount)
        Me.GroupBox_V.Controls.Add(Me.Button_VLeftBase)
        Me.GroupBox_V.Controls.Add(Me.TextBox_VVCount)
        Me.GroupBox_V.Controls.Add(Me.Button_VRightBase)
        Me.GroupBox_V.Controls.Add(Me.Button_VTopBase)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VTop)
        Me.GroupBox_V.Controls.Add(Me.Button_VBottomBase)
        Me.GroupBox_V.Controls.Add(Me.Label56)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VRight)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VBottom)
        Me.GroupBox_V.Controls.Add(Me.Label57)
        Me.GroupBox_V.Controls.Add(Me.Label58)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VLeft)
        Me.GroupBox_V.Controls.Add(Me.Label59)
        Me.GroupBox_V.Location = New System.Drawing.Point(6, 194)
        Me.GroupBox_V.Name = "GroupBox_V"
        Me.GroupBox_V.Size = New System.Drawing.Size(326, 132)
        Me.GroupBox_V.TabIndex = 11
        Me.GroupBox_V.TabStop = False
        Me.GroupBox_V.Text = "垂直参数"
        '
        'TextBox_VHCount
        '
        Me.TextBox_VHCount.Location = New System.Drawing.Point(139, 102)
        Me.TextBox_VHCount.Name = "TextBox_VHCount"
        Me.TextBox_VHCount.Size = New System.Drawing.Size(47, 22)
        Me.TextBox_VHCount.TabIndex = 20
        '
        'Button_VLeftBase
        '
        Me.Button_VLeftBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_VLeftBase.Location = New System.Drawing.Point(298, 72)
        Me.Button_VLeftBase.Name = "Button_VLeftBase"
        Me.Button_VLeftBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_VLeftBase.TabIndex = 20
        Me.Button_VLeftBase.Text = "+"
        Me.Button_VLeftBase.UseVisualStyleBackColor = True
        '
        'TextBox_VVCount
        '
        Me.TextBox_VVCount.Location = New System.Drawing.Point(139, 10)
        Me.TextBox_VVCount.Name = "TextBox_VVCount"
        Me.TextBox_VVCount.Size = New System.Drawing.Size(47, 22)
        Me.TextBox_VVCount.TabIndex = 19
        '
        'Button_VRightBase
        '
        Me.Button_VRightBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_VRightBase.Location = New System.Drawing.Point(5, 72)
        Me.Button_VRightBase.Name = "Button_VRightBase"
        Me.Button_VRightBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_VRightBase.TabIndex = 20
        Me.Button_VRightBase.Text = "+"
        Me.Button_VRightBase.UseVisualStyleBackColor = True
        '
        'Button_VTopBase
        '
        Me.Button_VTopBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_VTopBase.Location = New System.Drawing.Point(298, 44)
        Me.Button_VTopBase.Name = "Button_VTopBase"
        Me.Button_VTopBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_VTopBase.TabIndex = 19
        Me.Button_VTopBase.Text = "+"
        Me.Button_VTopBase.UseVisualStyleBackColor = True
        '
        'NumericUpDown_VTop
        '
        Me.NumericUpDown_VTop.Location = New System.Drawing.Point(102, 43)
        Me.NumericUpDown_VTop.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VTop.Name = "NumericUpDown_VTop"
        Me.NumericUpDown_VTop.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_VTop.TabIndex = 14
        Me.NumericUpDown_VTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button_VBottomBase
        '
        Me.Button_VBottomBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_VBottomBase.Location = New System.Drawing.Point(5, 44)
        Me.Button_VBottomBase.Name = "Button_VBottomBase"
        Me.Button_VBottomBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_VBottomBase.TabIndex = 19
        Me.Button_VBottomBase.Text = "+"
        Me.Button_VBottomBase.UseVisualStyleBackColor = True
        '
        'Label56
        '
        Me.Label56.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label56.Location = New System.Drawing.Point(166, 44)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(60, 23)
        Me.Label56.TabIndex = 15
        Me.Label56.Text = "下边界 :"
        Me.Label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_VRight
        '
        Me.NumericUpDown_VRight.Location = New System.Drawing.Point(234, 71)
        Me.NumericUpDown_VRight.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VRight.Name = "NumericUpDown_VRight"
        Me.NumericUpDown_VRight.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_VRight.TabIndex = 8
        Me.NumericUpDown_VRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_VBottom
        '
        Me.NumericUpDown_VBottom.Location = New System.Drawing.Point(234, 43)
        Me.NumericUpDown_VBottom.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VBottom.Name = "NumericUpDown_VBottom"
        Me.NumericUpDown_VBottom.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_VBottom.TabIndex = 16
        Me.NumericUpDown_VBottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label57
        '
        Me.Label57.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label57.Location = New System.Drawing.Point(166, 72)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(60, 23)
        Me.Label57.TabIndex = 7
        Me.Label57.Text = "右边界 :"
        Me.Label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label58
        '
        Me.Label58.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label58.Location = New System.Drawing.Point(34, 44)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(60, 23)
        Me.Label58.TabIndex = 13
        Me.Label58.Text = "上边界 :"
        Me.Label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_VLeft
        '
        Me.NumericUpDown_VLeft.Location = New System.Drawing.Point(102, 71)
        Me.NumericUpDown_VLeft.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VLeft.Name = "NumericUpDown_VLeft"
        Me.NumericUpDown_VLeft.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_VLeft.TabIndex = 6
        Me.NumericUpDown_VLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label59
        '
        Me.Label59.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label59.Location = New System.Drawing.Point(34, 72)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(60, 23)
        Me.Label59.TabIndex = 5
        Me.Label59.Text = "左边界 :"
        Me.Label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'RadioButton3
        '
        Me.RadioButton3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton3.Location = New System.Drawing.Point(101, 20)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(89, 24)
        Me.RadioButton3.TabIndex = 10
        Me.RadioButton3.Text = "手动设定"
        '
        'RadioButton4
        '
        Me.RadioButton4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RadioButton4.Location = New System.Drawing.Point(6, 20)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(89, 24)
        Me.RadioButton4.TabIndex = 0
        Me.RadioButton4.Text = "完成设定"
        '
        'GroupBox_H
        '
        Me.GroupBox_H.Controls.Add(Me.TextBox_HHCount)
        Me.GroupBox_H.Controls.Add(Me.TextBox_HVCount)
        Me.GroupBox_H.Controls.Add(Me.Button_HLeftBase)
        Me.GroupBox_H.Controls.Add(Me.Button_HTopBase)
        Me.GroupBox_H.Controls.Add(Me.Button_HRightBase)
        Me.GroupBox_H.Controls.Add(Me.Button_HBottomBase)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HRight)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HTop)
        Me.GroupBox_H.Controls.Add(Me.Label60)
        Me.GroupBox_H.Controls.Add(Me.Label61)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HLeft)
        Me.GroupBox_H.Controls.Add(Me.Label62)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HBottom)
        Me.GroupBox_H.Controls.Add(Me.Label63)
        Me.GroupBox_H.Location = New System.Drawing.Point(6, 50)
        Me.GroupBox_H.Name = "GroupBox_H"
        Me.GroupBox_H.Size = New System.Drawing.Size(326, 138)
        Me.GroupBox_H.TabIndex = 9
        Me.GroupBox_H.TabStop = False
        Me.GroupBox_H.Text = "水平参数"
        '
        'TextBox_HHCount
        '
        Me.TextBox_HHCount.Location = New System.Drawing.Point(139, 108)
        Me.TextBox_HHCount.Name = "TextBox_HHCount"
        Me.TextBox_HHCount.Size = New System.Drawing.Size(47, 22)
        Me.TextBox_HHCount.TabIndex = 18
        '
        'TextBox_HVCount
        '
        Me.TextBox_HVCount.Location = New System.Drawing.Point(139, 14)
        Me.TextBox_HVCount.Name = "TextBox_HVCount"
        Me.TextBox_HVCount.Size = New System.Drawing.Size(47, 22)
        Me.TextBox_HVCount.TabIndex = 17
        '
        'Button_HLeftBase
        '
        Me.Button_HLeftBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_HLeftBase.Location = New System.Drawing.Point(298, 76)
        Me.Button_HLeftBase.Name = "Button_HLeftBase"
        Me.Button_HLeftBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_HLeftBase.TabIndex = 16
        Me.Button_HLeftBase.Text = "+"
        Me.Button_HLeftBase.UseVisualStyleBackColor = True
        '
        'Button_HTopBase
        '
        Me.Button_HTopBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_HTopBase.Location = New System.Drawing.Point(298, 47)
        Me.Button_HTopBase.Name = "Button_HTopBase"
        Me.Button_HTopBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_HTopBase.TabIndex = 15
        Me.Button_HTopBase.Text = "+"
        Me.Button_HTopBase.UseVisualStyleBackColor = True
        '
        'Button_HRightBase
        '
        Me.Button_HRightBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_HRightBase.Location = New System.Drawing.Point(5, 76)
        Me.Button_HRightBase.Name = "Button_HRightBase"
        Me.Button_HRightBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_HRightBase.TabIndex = 14
        Me.Button_HRightBase.Text = "+"
        Me.Button_HRightBase.UseVisualStyleBackColor = True
        '
        'Button_HBottomBase
        '
        Me.Button_HBottomBase.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_HBottomBase.Location = New System.Drawing.Point(5, 47)
        Me.Button_HBottomBase.Name = "Button_HBottomBase"
        Me.Button_HBottomBase.Size = New System.Drawing.Size(21, 23)
        Me.Button_HBottomBase.TabIndex = 13
        Me.Button_HBottomBase.Text = "+"
        Me.Button_HBottomBase.UseVisualStyleBackColor = True
        '
        'NumericUpDown_HRight
        '
        Me.NumericUpDown_HRight.Location = New System.Drawing.Point(234, 75)
        Me.NumericUpDown_HRight.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HRight.Name = "NumericUpDown_HRight"
        Me.NumericUpDown_HRight.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_HRight.TabIndex = 12
        Me.NumericUpDown_HRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_HTop
        '
        Me.NumericUpDown_HTop.Location = New System.Drawing.Point(102, 46)
        Me.NumericUpDown_HTop.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HTop.Name = "NumericUpDown_HTop"
        Me.NumericUpDown_HTop.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_HTop.TabIndex = 2
        Me.NumericUpDown_HTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label60
        '
        Me.Label60.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label60.Location = New System.Drawing.Point(166, 76)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(60, 23)
        Me.Label60.TabIndex = 11
        Me.Label60.Text = "右边界 :"
        Me.Label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label61
        '
        Me.Label61.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label61.Location = New System.Drawing.Point(166, 47)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(60, 23)
        Me.Label61.TabIndex = 3
        Me.Label61.Text = "下边界 :"
        Me.Label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_HLeft
        '
        Me.NumericUpDown_HLeft.Location = New System.Drawing.Point(102, 75)
        Me.NumericUpDown_HLeft.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HLeft.Name = "NumericUpDown_HLeft"
        Me.NumericUpDown_HLeft.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_HLeft.TabIndex = 10
        Me.NumericUpDown_HLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label62
        '
        Me.Label62.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label62.Location = New System.Drawing.Point(34, 76)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(60, 23)
        Me.Label62.TabIndex = 9
        Me.Label62.Text = "左边界 :"
        Me.Label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_HBottom
        '
        Me.NumericUpDown_HBottom.Location = New System.Drawing.Point(234, 46)
        Me.NumericUpDown_HBottom.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HBottom.Name = "NumericUpDown_HBottom"
        Me.NumericUpDown_HBottom.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_HBottom.TabIndex = 4
        Me.NumericUpDown_HBottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label63
        '
        Me.Label63.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label63.Location = New System.Drawing.Point(34, 47)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(60, 23)
        Me.Label63.TabIndex = 1
        Me.Label63.Text = "上边界 :"
        Me.Label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_BandBlockSetting
        '
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.NumericUpDown_AutoWidth)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Label45)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.CheckBox_ShowMuraBlock)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Button_AddBlockSetting)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.ComboBox_SelectMuraBlock)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Label46)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.NumericUpDown_BlockBlackTH)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Label47)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.NumericUpDown_BlockWhiteTH)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.NumericUpDown_BlockTop)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.NumericUpDown_BlockRight)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Label48)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Label51)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.NumericUpDown_BlockButtom)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.NumericUpDown_BlockLeft)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Label52)
        Me.GroupBox_BandBlockSetting.Controls.Add(Me.Label53)
        Me.GroupBox_BandBlockSetting.Location = New System.Drawing.Point(8, 903)
        Me.GroupBox_BandBlockSetting.Name = "GroupBox_BandBlockSetting"
        Me.GroupBox_BandBlockSetting.Size = New System.Drawing.Size(345, 152)
        Me.GroupBox_BandBlockSetting.TabIndex = 101
        Me.GroupBox_BandBlockSetting.TabStop = False
        Me.GroupBox_BandBlockSetting.Text = "Block参数设定"
        '
        'NumericUpDown_AutoWidth
        '
        Me.NumericUpDown_AutoWidth.Location = New System.Drawing.Point(71, 109)
        Me.NumericUpDown_AutoWidth.Maximum = New Decimal(New Integer() {6576, 0, 0, 0})
        Me.NumericUpDown_AutoWidth.Name = "NumericUpDown_AutoWidth"
        Me.NumericUpDown_AutoWidth.Size = New System.Drawing.Size(71, 22)
        Me.NumericUpDown_AutoWidth.TabIndex = 82
        Me.NumericUpDown_AutoWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_AutoWidth.Value = New Decimal(New Integer() {15, 0, 0, 0})
        '
        'Label45
        '
        Me.Label45.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label45.Location = New System.Drawing.Point(8, 110)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(57, 23)
        Me.Label45.TabIndex = 81
        Me.Label45.Text = "宽度 :"
        Me.Label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CheckBox_ShowMuraBlock
        '
        Me.CheckBox_ShowMuraBlock.AutoSize = True
        Me.CheckBox_ShowMuraBlock.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_ShowMuraBlock.Location = New System.Drawing.Point(151, 113)
        Me.CheckBox_ShowMuraBlock.Name = "CheckBox_ShowMuraBlock"
        Me.CheckBox_ShowMuraBlock.Size = New System.Drawing.Size(48, 16)
        Me.CheckBox_ShowMuraBlock.TabIndex = 80
        Me.CheckBox_ShowMuraBlock.Text = "显示"
        Me.CheckBox_ShowMuraBlock.UseVisualStyleBackColor = True
        '
        'Button_AddBlockSetting
        '
        Me.Button_AddBlockSetting.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_AddBlockSetting.Location = New System.Drawing.Point(286, 110)
        Me.Button_AddBlockSetting.Name = "Button_AddBlockSetting"
        Me.Button_AddBlockSetting.Size = New System.Drawing.Size(50, 23)
        Me.Button_AddBlockSetting.TabIndex = 55
        Me.Button_AddBlockSetting.Text = "Add"
        '
        'ComboBox_SelectMuraBlock
        '
        Me.ComboBox_SelectMuraBlock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_SelectMuraBlock.Items.AddRange(New Object() {"V", "H"})
        Me.ComboBox_SelectMuraBlock.Location = New System.Drawing.Point(211, 111)
        Me.ComboBox_SelectMuraBlock.Name = "ComboBox_SelectMuraBlock"
        Me.ComboBox_SelectMuraBlock.Size = New System.Drawing.Size(69, 20)
        Me.ComboBox_SelectMuraBlock.TabIndex = 54
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label46.Location = New System.Drawing.Point(171, 81)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(50, 12)
        Me.Label46.TabIndex = 43
        Me.Label46.Text = "Black TH"
        '
        'NumericUpDown_BlockBlackTH
        '
        Me.NumericUpDown_BlockBlackTH.Location = New System.Drawing.Point(250, 76)
        Me.NumericUpDown_BlockBlackTH.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockBlackTH.Name = "NumericUpDown_BlockBlackTH"
        Me.NumericUpDown_BlockBlackTH.Size = New System.Drawing.Size(71, 22)
        Me.NumericUpDown_BlockBlackTH.TabIndex = 42
        Me.NumericUpDown_BlockBlackTH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_BlockBlackTH.Value = New Decimal(New Integer() {65535, 0, 0, 0})
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label47.Location = New System.Drawing.Point(8, 81)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(51, 12)
        Me.Label47.TabIndex = 43
        Me.Label47.Text = "White TH"
        '
        'NumericUpDown_BlockWhiteTH
        '
        Me.NumericUpDown_BlockWhiteTH.Location = New System.Drawing.Point(91, 76)
        Me.NumericUpDown_BlockWhiteTH.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockWhiteTH.Name = "NumericUpDown_BlockWhiteTH"
        Me.NumericUpDown_BlockWhiteTH.Size = New System.Drawing.Size(71, 22)
        Me.NumericUpDown_BlockWhiteTH.TabIndex = 42
        Me.NumericUpDown_BlockWhiteTH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_BlockWhiteTH.Value = New Decimal(New Integer() {65535, 0, 0, 0})
        '
        'NumericUpDown_BlockTop
        '
        Me.NumericUpDown_BlockTop.Location = New System.Drawing.Point(250, 21)
        Me.NumericUpDown_BlockTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockTop.Name = "NumericUpDown_BlockTop"
        Me.NumericUpDown_BlockTop.Size = New System.Drawing.Size(71, 22)
        Me.NumericUpDown_BlockTop.TabIndex = 14
        Me.NumericUpDown_BlockTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_BlockRight
        '
        Me.NumericUpDown_BlockRight.Location = New System.Drawing.Point(91, 46)
        Me.NumericUpDown_BlockRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockRight.Name = "NumericUpDown_BlockRight"
        Me.NumericUpDown_BlockRight.Size = New System.Drawing.Size(71, 22)
        Me.NumericUpDown_BlockRight.TabIndex = 8
        Me.NumericUpDown_BlockRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label48
        '
        Me.Label48.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label48.Location = New System.Drawing.Point(171, 47)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(73, 23)
        Me.Label48.TabIndex = 15
        Me.Label48.Text = "下边界 :"
        Me.Label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label51
        '
        Me.Label51.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label51.Location = New System.Drawing.Point(8, 47)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(73, 23)
        Me.Label51.TabIndex = 7
        Me.Label51.Text = "右边界 :"
        Me.Label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BlockButtom
        '
        Me.NumericUpDown_BlockButtom.Location = New System.Drawing.Point(250, 46)
        Me.NumericUpDown_BlockButtom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockButtom.Name = "NumericUpDown_BlockButtom"
        Me.NumericUpDown_BlockButtom.Size = New System.Drawing.Size(71, 22)
        Me.NumericUpDown_BlockButtom.TabIndex = 16
        Me.NumericUpDown_BlockButtom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_BlockLeft
        '
        Me.NumericUpDown_BlockLeft.Location = New System.Drawing.Point(91, 21)
        Me.NumericUpDown_BlockLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockLeft.Name = "NumericUpDown_BlockLeft"
        Me.NumericUpDown_BlockLeft.Size = New System.Drawing.Size(71, 22)
        Me.NumericUpDown_BlockLeft.TabIndex = 6
        Me.NumericUpDown_BlockLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label52
        '
        Me.Label52.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label52.Location = New System.Drawing.Point(171, 22)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(73, 23)
        Me.Label52.TabIndex = 13
        Me.Label52.Text = "上边界 :"
        Me.Label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label53
        '
        Me.Label53.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label53.Location = New System.Drawing.Point(8, 22)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(73, 23)
        Me.Label53.TabIndex = 5
        Me.Label53.Text = "左边界 :"
        Me.Label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TreeView_MuraParamPattern
        '
        Me.TreeView_MuraParamPattern.Font = New System.Drawing.Font("新細明體", 9.0!)
        Me.TreeView_MuraParamPattern.Location = New System.Drawing.Point(3, 61)
        Me.TreeView_MuraParamPattern.Name = "TreeView_MuraParamPattern"
        TreeNode1.Name = "Node0"
        TreeNode1.Text = "Node0"
        TreeNode2.Name = "Node1"
        TreeNode2.Text = "Node1"
        TreeNode3.Name = "Node2"
        TreeNode3.Text = "Node2"
        TreeNode4.Name = "Node3"
        TreeNode4.Text = "Node3"
        TreeNode5.Name = "Node4"
        TreeNode5.Text = "Node4"
        Me.TreeView_MuraParamPattern.Nodes.AddRange(New System.Windows.Forms.TreeNode() {TreeNode1, TreeNode2, TreeNode3, TreeNode4, TreeNode5})
        Me.TreeView_MuraParamPattern.Size = New System.Drawing.Size(125, 420)
        Me.TreeView_MuraParamPattern.TabIndex = 60
        '
        'CheckBox_AnalysisCenterMuraEnable
        '
        Me.CheckBox_AnalysisCenterMuraEnable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_AnalysisCenterMuraEnable.Location = New System.Drawing.Point(146, 6)
        Me.CheckBox_AnalysisCenterMuraEnable.Name = "CheckBox_AnalysisCenterMuraEnable"
        Me.CheckBox_AnalysisCenterMuraEnable.Size = New System.Drawing.Size(123, 23)
        Me.CheckBox_AnalysisCenterMuraEnable.TabIndex = 76
        Me.CheckBox_AnalysisCenterMuraEnable.Text = "檢查點狀MURA"
        '
        'CheckBox_AnalysisBandMuraEnable
        '
        Me.CheckBox_AnalysisBandMuraEnable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_AnalysisBandMuraEnable.Location = New System.Drawing.Point(392, 6)
        Me.CheckBox_AnalysisBandMuraEnable.Name = "CheckBox_AnalysisBandMuraEnable"
        Me.CheckBox_AnalysisBandMuraEnable.Size = New System.Drawing.Size(123, 23)
        Me.CheckBox_AnalysisBandMuraEnable.TabIndex = 100
        Me.CheckBox_AnalysisBandMuraEnable.Text = "檢查BAND MURA"
        '
        'CheckBox_AnalysisAroundMuraEnable
        '
        Me.CheckBox_AnalysisAroundMuraEnable.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.CheckBox_AnalysisAroundMuraEnable.Location = New System.Drawing.Point(269, 6)
        Me.CheckBox_AnalysisAroundMuraEnable.Name = "CheckBox_AnalysisAroundMuraEnable"
        Me.CheckBox_AnalysisAroundMuraEnable.Size = New System.Drawing.Size(123, 23)
        Me.CheckBox_AnalysisAroundMuraEnable.TabIndex = 91
        Me.CheckBox_AnalysisAroundMuraEnable.Text = "檢查邊框MURA"
        '
        'Button_MuraParamSave
        '
        Me.Button_MuraParamSave.Location = New System.Drawing.Point(3, 6)
        Me.Button_MuraParamSave.Name = "Button_MuraParamSave"
        Me.Button_MuraParamSave.Size = New System.Drawing.Size(125, 50)
        Me.Button_MuraParamSave.TabIndex = 57
        Me.Button_MuraParamSave.Text = "儲存"
        '
        'txtOutput
        '
        Me.txtOutput.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtOutput.Location = New System.Drawing.Point(0, 0)
        Me.txtOutput.MaxLength = 100
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.Size = New System.Drawing.Size(537, 90)
        Me.txtOutput.TabIndex = 10024
        Me.txtOutput.Text = ""
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 27)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.Color.LavenderBlush
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_MuraAutoTest)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_MuraManualTest)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_JND)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_SettingMura)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_MuraResult)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_MuraFalseDefect)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_FuncImgProcTest)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_Align)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_SettingFunc)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_FuncFalseDefect)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_ADJMean)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_CameraAlignment)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_ProductModelSetting)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.BackColor = System.Drawing.Color.Azure
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label_ImgGrayValue)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label_imgAnchorPosY)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label_imgAnchorPosX)
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_ImgCal)
        Me.SplitContainer1.Panel2.Controls.Add(Me.TextBox_Product)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label_Type)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label_Select)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label_Pattern)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox_VBand_White)
        Me.SplitContainer1.Panel2.Controls.Add(Me.ComboBox_Type)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox_VBand_Black)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox_HBand_White)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox_HBand_Black)
        Me.SplitContainer1.Panel2.Controls.Add(Me.ComboBox_Select)
        Me.SplitContainer1.Panel2.Controls.Add(Me.ComboBox_Pattern_MainFrm)
        Me.SplitContainer1.Panel2.Controls.Add(Me.PictureBox_PreInfo)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Label_Product)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_QuickAlign)
        Me.SplitContainer1.Panel2.Controls.Add(Me.VScrollBar)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_ZoomAll)
        Me.SplitContainer1.Panel2.Controls.Add(Me.TextBox_PreInfo)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_LoadImage)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_ZoomO)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_ZoomIn)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_SaveImage)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_ZoomOut)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel_AxMDisplay)
        Me.SplitContainer1.Panel2.Controls.Add(Me.HScrollBar)
        Me.SplitContainer1.Size = New System.Drawing.Size(1296, 603)
        Me.SplitContainer1.SplitterDistance = 174
        Me.SplitContainer1.TabIndex = 10036
        '
        'Button_MuraAutoTest
        '
        Me.Button_MuraAutoTest.BackColor = System.Drawing.Color.Orange
        Me.Button_MuraAutoTest.Location = New System.Drawing.Point(12, 452)
        Me.Button_MuraAutoTest.Name = "Button_MuraAutoTest"
        Me.Button_MuraAutoTest.Size = New System.Drawing.Size(150, 40)
        Me.Button_MuraAutoTest.TabIndex = 0
        Me.Button_MuraAutoTest.Text = "Mura Auto Test"
        Me.Button_MuraAutoTest.UseVisualStyleBackColor = False
        '
        'Button_MuraManualTest
        '
        Me.Button_MuraManualTest.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_MuraManualTest.Location = New System.Drawing.Point(12, 292)
        Me.Button_MuraManualTest.Name = "Button_MuraManualTest"
        Me.Button_MuraManualTest.Size = New System.Drawing.Size(150, 40)
        Me.Button_MuraManualTest.TabIndex = 3
        Me.Button_MuraManualTest.Text = "Mura Manual Test"
        Me.Button_MuraManualTest.UseVisualStyleBackColor = False
        '
        'Button_JND
        '
        Me.Button_JND.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_JND.Location = New System.Drawing.Point(12, 372)
        Me.Button_JND.Name = "Button_JND"
        Me.Button_JND.Size = New System.Drawing.Size(150, 40)
        Me.Button_JND.TabIndex = 1
        Me.Button_JND.Text = "計算 JND"
        Me.Button_JND.UseVisualStyleBackColor = False
        '
        'Button_SettingMura
        '
        Me.Button_SettingMura.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_SettingMura.Location = New System.Drawing.Point(12, 332)
        Me.Button_SettingMura.Name = "Button_SettingMura"
        Me.Button_SettingMura.Size = New System.Drawing.Size(150, 40)
        Me.Button_SettingMura.TabIndex = 1
        Me.Button_SettingMura.Text = "Mura 參數設定"
        Me.Button_SettingMura.UseVisualStyleBackColor = False
        '
        'Button_MuraResult
        '
        Me.Button_MuraResult.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_MuraResult.Location = New System.Drawing.Point(12, 492)
        Me.Button_MuraResult.Name = "Button_MuraResult"
        Me.Button_MuraResult.Size = New System.Drawing.Size(150, 40)
        Me.Button_MuraResult.TabIndex = 10027
        Me.Button_MuraResult.Text = "Mura判片結果"
        Me.Button_MuraResult.UseVisualStyleBackColor = False
        '
        'Button_MuraFalseDefect
        '
        Me.Button_MuraFalseDefect.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_MuraFalseDefect.Location = New System.Drawing.Point(12, 412)
        Me.Button_MuraFalseDefect.Name = "Button_MuraFalseDefect"
        Me.Button_MuraFalseDefect.Size = New System.Drawing.Size(150, 40)
        Me.Button_MuraFalseDefect.TabIndex = 4
        Me.Button_MuraFalseDefect.Text = "Mura False Defect"
        Me.Button_MuraFalseDefect.UseVisualStyleBackColor = False
        '
        'Button_FuncImgProcTest
        '
        Me.Button_FuncImgProcTest.BackColor = System.Drawing.Color.Orange
        Me.Button_FuncImgProcTest.Location = New System.Drawing.Point(12, 252)
        Me.Button_FuncImgProcTest.Name = "Button_FuncImgProcTest"
        Me.Button_FuncImgProcTest.Size = New System.Drawing.Size(150, 40)
        Me.Button_FuncImgProcTest.TabIndex = 42
        Me.Button_FuncImgProcTest.Text = "Func ImgProc Test"
        Me.Button_FuncImgProcTest.UseVisualStyleBackColor = False
        '
        'Button_Align
        '
        Me.Button_Align.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_Align.Location = New System.Drawing.Point(12, 92)
        Me.Button_Align.Name = "Button_Align"
        Me.Button_Align.Size = New System.Drawing.Size(150, 40)
        Me.Button_Align.TabIndex = 5
        Me.Button_Align.Text = "Alignment Setting"
        Me.Button_Align.UseVisualStyleBackColor = False
        '
        'Button_SettingFunc
        '
        Me.Button_SettingFunc.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_SettingFunc.Location = New System.Drawing.Point(12, 172)
        Me.Button_SettingFunc.Name = "Button_SettingFunc"
        Me.Button_SettingFunc.Size = New System.Drawing.Size(150, 40)
        Me.Button_SettingFunc.TabIndex = 3
        Me.Button_SettingFunc.Text = "Func參數設定"
        Me.Button_SettingFunc.UseVisualStyleBackColor = False
        '
        'Button_FuncFalseDefect
        '
        Me.Button_FuncFalseDefect.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_FuncFalseDefect.Location = New System.Drawing.Point(12, 212)
        Me.Button_FuncFalseDefect.Name = "Button_FuncFalseDefect"
        Me.Button_FuncFalseDefect.Size = New System.Drawing.Size(150, 40)
        Me.Button_FuncFalseDefect.TabIndex = 40
        Me.Button_FuncFalseDefect.Text = "Func False Defect"
        Me.Button_FuncFalseDefect.UseVisualStyleBackColor = False
        '
        'Button_ADJMean
        '
        Me.Button_ADJMean.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_ADJMean.Location = New System.Drawing.Point(12, 52)
        Me.Button_ADJMean.Name = "Button_ADJMean"
        Me.Button_ADJMean.Size = New System.Drawing.Size(150, 40)
        Me.Button_ADJMean.TabIndex = 25
        Me.Button_ADJMean.Text = "Mean Adjustment"
        Me.Button_ADJMean.UseVisualStyleBackColor = False
        '
        'Button_CameraAlignment
        '
        Me.Button_CameraAlignment.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button_CameraAlignment.Location = New System.Drawing.Point(12, 132)
        Me.Button_CameraAlignment.Name = "Button_CameraAlignment"
        Me.Button_CameraAlignment.Size = New System.Drawing.Size(150, 40)
        Me.Button_CameraAlignment.TabIndex = 31
        Me.Button_CameraAlignment.Text = "Camera Alignment"
        Me.Button_CameraAlignment.UseVisualStyleBackColor = False
        '
        'Button_ProductModelSetting
        '
        Me.Button_ProductModelSetting.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button_ProductModelSetting.Location = New System.Drawing.Point(12, 12)
        Me.Button_ProductModelSetting.Name = "Button_ProductModelSetting"
        Me.Button_ProductModelSetting.Size = New System.Drawing.Size(150, 40)
        Me.Button_ProductModelSetting.TabIndex = 0
        Me.Button_ProductModelSetting.Text = "產品信息設定"
        Me.Button_ProductModelSetting.UseVisualStyleBackColor = False
        '
        'Label_ImgGrayValue
        '
        Me.Label_ImgGrayValue.Font = New System.Drawing.Font("微軟正黑體", 9.75!)
        Me.Label_ImgGrayValue.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_ImgGrayValue.Location = New System.Drawing.Point(171, 522)
        Me.Label_ImgGrayValue.Name = "Label_ImgGrayValue"
        Me.Label_ImgGrayValue.Size = New System.Drawing.Size(183, 23)
        Me.Label_ImgGrayValue.TabIndex = 10033
        Me.Label_ImgGrayValue.Text = "亮度: 4095"
        Me.Label_ImgGrayValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_imgAnchorPosY
        '
        Me.Label_imgAnchorPosY.Font = New System.Drawing.Font("微軟正黑體", 9.75!)
        Me.Label_imgAnchorPosY.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_imgAnchorPosY.Location = New System.Drawing.Point(94, 522)
        Me.Label_imgAnchorPosY.Name = "Label_imgAnchorPosY"
        Me.Label_imgAnchorPosY.Size = New System.Drawing.Size(76, 23)
        Me.Label_imgAnchorPosY.TabIndex = 10033
        Me.Label_imgAnchorPosY.Text = "Y: 10640"
        Me.Label_imgAnchorPosY.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_imgAnchorPosX
        '
        Me.Label_imgAnchorPosX.Font = New System.Drawing.Font("微軟正黑體", 9.75!)
        Me.Label_imgAnchorPosX.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label_imgAnchorPosX.Location = New System.Drawing.Point(17, 522)
        Me.Label_imgAnchorPosX.Name = "Label_imgAnchorPosX"
        Me.Label_imgAnchorPosX.Size = New System.Drawing.Size(76, 23)
        Me.Label_imgAnchorPosX.TabIndex = 10033
        Me.Label_imgAnchorPosX.Text = "X: 14192"
        Me.Label_imgAnchorPosX.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Button_ImgCal
        '
        Me.Button_ImgCal.BackColor = System.Drawing.Color.Azure
        Me.Button_ImgCal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_ImgCal.Location = New System.Drawing.Point(414, 107)
        Me.Button_ImgCal.Name = "Button_ImgCal"
        Me.Button_ImgCal.Size = New System.Drawing.Size(77, 25)
        Me.Button_ImgCal.TabIndex = 33
        Me.Button_ImgCal.Text = "Cal."
        Me.Button_ImgCal.UseVisualStyleBackColor = False
        '
        'TextBox_Product
        '
        Me.TextBox_Product.Enabled = False
        Me.TextBox_Product.Location = New System.Drawing.Point(293, 14)
        Me.TextBox_Product.Name = "TextBox_Product"
        Me.TextBox_Product.Size = New System.Drawing.Size(145, 22)
        Me.TextBox_Product.TabIndex = 27
        '
        'Label_Type
        '
        Me.Label_Type.Location = New System.Drawing.Point(10, 14)
        Me.Label_Type.Name = "Label_Type"
        Me.Label_Type.Size = New System.Drawing.Size(64, 23)
        Me.Label_Type.TabIndex = 22
        Me.Label_Type.Text = "影像類型 :"
        Me.Label_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Select
        '
        Me.Label_Select.Location = New System.Drawing.Point(10, 38)
        Me.Label_Select.Name = "Label_Select"
        Me.Label_Select.Size = New System.Drawing.Size(64, 23)
        Me.Label_Select.TabIndex = 21
        Me.Label_Select.Text = "顯示影像 :"
        Me.Label_Select.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Pattern
        '
        Me.Label_Pattern.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Label_Pattern.Location = New System.Drawing.Point(247, 38)
        Me.Label_Pattern.Name = "Label_Pattern"
        Me.Label_Pattern.Size = New System.Drawing.Size(46, 23)
        Me.Label_Pattern.TabIndex = 25
        Me.Label_Pattern.Text = "Pattern :"
        Me.Label_Pattern.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox_VBand_White
        '
        Me.PictureBox_VBand_White.Location = New System.Drawing.Point(15, 551)
        Me.PictureBox_VBand_White.Name = "PictureBox_VBand_White"
        Me.PictureBox_VBand_White.Size = New System.Drawing.Size(478, 48)
        Me.PictureBox_VBand_White.TabIndex = 10031
        Me.PictureBox_VBand_White.TabStop = False
        Me.PictureBox_VBand_White.Visible = False
        '
        'ComboBox_Type
        '
        Me.ComboBox_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Type.Items.AddRange(New Object() {"全影像", "可視區", "Band", "亮校正相關"})
        Me.ComboBox_Type.Location = New System.Drawing.Point(74, 14)
        Me.ComboBox_Type.Name = "ComboBox_Type"
        Me.ComboBox_Type.Size = New System.Drawing.Size(168, 20)
        Me.ComboBox_Type.TabIndex = 16
        '
        'PictureBox_VBand_Black
        '
        Me.PictureBox_VBand_Black.Location = New System.Drawing.Point(15, 551)
        Me.PictureBox_VBand_Black.Name = "PictureBox_VBand_Black"
        Me.PictureBox_VBand_Black.Size = New System.Drawing.Size(477, 48)
        Me.PictureBox_VBand_Black.TabIndex = 10029
        Me.PictureBox_VBand_Black.TabStop = False
        Me.PictureBox_VBand_Black.Visible = False
        '
        'PictureBox_HBand_White
        '
        Me.PictureBox_HBand_White.Location = New System.Drawing.Point(516, 172)
        Me.PictureBox_HBand_White.Name = "PictureBox_HBand_White"
        Me.PictureBox_HBand_White.Size = New System.Drawing.Size(55, 321)
        Me.PictureBox_HBand_White.TabIndex = 10030
        Me.PictureBox_HBand_White.TabStop = False
        Me.PictureBox_HBand_White.Visible = False
        '
        'PictureBox_HBand_Black
        '
        Me.PictureBox_HBand_Black.Location = New System.Drawing.Point(516, 172)
        Me.PictureBox_HBand_Black.Name = "PictureBox_HBand_Black"
        Me.PictureBox_HBand_Black.Size = New System.Drawing.Size(55, 321)
        Me.PictureBox_HBand_Black.TabIndex = 10028
        Me.PictureBox_HBand_Black.TabStop = False
        Me.PictureBox_HBand_Black.Visible = False
        '
        'ComboBox_Select
        '
        Me.ComboBox_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Select.Location = New System.Drawing.Point(74, 38)
        Me.ComboBox_Select.Name = "ComboBox_Select"
        Me.ComboBox_Select.Size = New System.Drawing.Size(168, 20)
        Me.ComboBox_Select.TabIndex = 17
        '
        'ComboBox_Pattern_MainFrm
        '
        Me.ComboBox_Pattern_MainFrm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Pattern_MainFrm.Location = New System.Drawing.Point(293, 41)
        Me.ComboBox_Pattern_MainFrm.Name = "ComboBox_Pattern_MainFrm"
        Me.ComboBox_Pattern_MainFrm.Size = New System.Drawing.Size(145, 20)
        Me.ComboBox_Pattern_MainFrm.TabIndex = 24
        '
        'PictureBox_PreInfo
        '
        Me.PictureBox_PreInfo.Image = CType(resources.GetObject("PictureBox_PreInfo.Image"), System.Drawing.Image)
        Me.PictureBox_PreInfo.Location = New System.Drawing.Point(13, 141)
        Me.PictureBox_PreInfo.Name = "PictureBox_PreInfo"
        Me.PictureBox_PreInfo.Size = New System.Drawing.Size(27, 27)
        Me.PictureBox_PreInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox_PreInfo.TabIndex = 10026
        Me.PictureBox_PreInfo.TabStop = False
        '
        'Label_Product
        '
        Me.Label_Product.Location = New System.Drawing.Point(248, 12)
        Me.Label_Product.Name = "Label_Product"
        Me.Label_Product.Size = New System.Drawing.Size(35, 23)
        Me.Label_Product.TabIndex = 28
        Me.Label_Product.Text = "產品 :"
        Me.Label_Product.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button_QuickAlign
        '
        Me.Button_QuickAlign.BackColor = System.Drawing.Color.Azure
        Me.Button_QuickAlign.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_QuickAlign.Location = New System.Drawing.Point(414, 82)
        Me.Button_QuickAlign.Name = "Button_QuickAlign"
        Me.Button_QuickAlign.Size = New System.Drawing.Size(77, 25)
        Me.Button_QuickAlign.TabIndex = 32
        Me.Button_QuickAlign.Text = "Align"
        Me.Button_QuickAlign.UseVisualStyleBackColor = False
        '
        'VScrollBar
        '
        Me.VScrollBar.LargeChange = 1
        Me.VScrollBar.Location = New System.Drawing.Point(494, 152)
        Me.VScrollBar.Name = "VScrollBar"
        Me.VScrollBar.Size = New System.Drawing.Size(19, 341)
        Me.VScrollBar.TabIndex = 10008
        '
        'Button_ZoomAll
        '
        Me.Button_ZoomAll.BackColor = System.Drawing.Color.Azure
        Me.Button_ZoomAll.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_ZoomAll.Location = New System.Drawing.Point(244, 82)
        Me.Button_ZoomAll.Name = "Button_ZoomAll"
        Me.Button_ZoomAll.Size = New System.Drawing.Size(77, 52)
        Me.Button_ZoomAll.TabIndex = 10014
        Me.Button_ZoomAll.Text = "全顯 (All)"
        Me.Button_ZoomAll.UseVisualStyleBackColor = False
        '
        'TextBox_PreInfo
        '
        Me.TextBox_PreInfo.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TextBox_PreInfo.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.TextBox_PreInfo.Location = New System.Drawing.Point(45, 144)
        Me.TextBox_PreInfo.Name = "TextBox_PreInfo"
        Me.TextBox_PreInfo.ReadOnly = True
        Me.TextBox_PreInfo.Size = New System.Drawing.Size(446, 22)
        Me.TextBox_PreInfo.TabIndex = 10021
        '
        'Button_LoadImage
        '
        Me.Button_LoadImage.BackColor = System.Drawing.Color.Azure
        Me.Button_LoadImage.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_LoadImage.Location = New System.Drawing.Point(337, 82)
        Me.Button_LoadImage.Name = "Button_LoadImage"
        Me.Button_LoadImage.Size = New System.Drawing.Size(77, 25)
        Me.Button_LoadImage.TabIndex = 29
        Me.Button_LoadImage.Text = "Load Image"
        Me.Button_LoadImage.UseVisualStyleBackColor = False
        '
        'Button_ZoomO
        '
        Me.Button_ZoomO.BackColor = System.Drawing.Color.Azure
        Me.Button_ZoomO.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_ZoomO.Location = New System.Drawing.Point(167, 82)
        Me.Button_ZoomO.Name = "Button_ZoomO"
        Me.Button_ZoomO.Size = New System.Drawing.Size(77, 52)
        Me.Button_ZoomO.TabIndex = 10011
        Me.Button_ZoomO.Text = "還原 (Original)"
        Me.Button_ZoomO.UseVisualStyleBackColor = False
        '
        'Button_ZoomIn
        '
        Me.Button_ZoomIn.BackColor = System.Drawing.Color.Azure
        Me.Button_ZoomIn.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_ZoomIn.Location = New System.Drawing.Point(13, 82)
        Me.Button_ZoomIn.Name = "Button_ZoomIn"
        Me.Button_ZoomIn.Size = New System.Drawing.Size(77, 52)
        Me.Button_ZoomIn.TabIndex = 10009
        Me.Button_ZoomIn.Text = "放大 (In)"
        Me.Button_ZoomIn.UseVisualStyleBackColor = False
        '
        'Button_SaveImage
        '
        Me.Button_SaveImage.BackColor = System.Drawing.Color.Azure
        Me.Button_SaveImage.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_SaveImage.Location = New System.Drawing.Point(337, 107)
        Me.Button_SaveImage.Name = "Button_SaveImage"
        Me.Button_SaveImage.Size = New System.Drawing.Size(77, 25)
        Me.Button_SaveImage.TabIndex = 23
        Me.Button_SaveImage.Text = "Save Image"
        Me.Button_SaveImage.UseVisualStyleBackColor = False
        '
        'Button_ZoomOut
        '
        Me.Button_ZoomOut.BackColor = System.Drawing.Color.Azure
        Me.Button_ZoomOut.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Button_ZoomOut.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button_ZoomOut.Location = New System.Drawing.Point(90, 82)
        Me.Button_ZoomOut.Name = "Button_ZoomOut"
        Me.Button_ZoomOut.Size = New System.Drawing.Size(77, 52)
        Me.Button_ZoomOut.TabIndex = 10010
        Me.Button_ZoomOut.Text = "縮小 (Out)"
        Me.Button_ZoomOut.UseVisualStyleBackColor = False
        '
        'Panel_AxMDisplay
        '
        Me.Panel_AxMDisplay.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel_AxMDisplay.Controls.Add(Me.Label_DisplayMsg)
        Me.Panel_AxMDisplay.Location = New System.Drawing.Point(13, 172)
        Me.Panel_AxMDisplay.Name = "Panel_AxMDisplay"
        Me.Panel_AxMDisplay.Size = New System.Drawing.Size(478, 321)
        Me.Panel_AxMDisplay.TabIndex = 10025
        '
        'Label_DisplayMsg
        '
        Me.Label_DisplayMsg.AutoSize = True
        Me.Label_DisplayMsg.BackColor = System.Drawing.Color.Green
        Me.Label_DisplayMsg.ForeColor = System.Drawing.Color.Yellow
        Me.Label_DisplayMsg.Location = New System.Drawing.Point(454, 1)
        Me.Label_DisplayMsg.Name = "Label_DisplayMsg"
        Me.Label_DisplayMsg.Size = New System.Drawing.Size(32, 12)
        Me.Label_DisplayMsg.TabIndex = 0
        Me.Label_DisplayMsg.Text = "(X,Y)"
        Me.Label_DisplayMsg.Visible = False
        '
        'HScrollBar
        '
        Me.HScrollBar.LargeChange = 1
        Me.HScrollBar.Location = New System.Drawing.Point(11, 496)
        Me.HScrollBar.Name = "HScrollBar"
        Me.HScrollBar.Size = New System.Drawing.Size(480, 19)
        Me.HScrollBar.TabIndex = 10007
        '
        'ContextMenuStrip_FuncPattern
        '
        Me.ContextMenuStrip_FuncPattern.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem_AddPattern, Me.ToolStripMenuItem_RemovePattern})
        Me.ContextMenuStrip_FuncPattern.Name = "ContextMenuStrip"
        Me.ContextMenuStrip_FuncPattern.Size = New System.Drawing.Size(124, 48)
        '
        'ToolStripMenuItem_AddPattern
        '
        Me.ToolStripMenuItem_AddPattern.Name = "ToolStripMenuItem_AddPattern"
        Me.ToolStripMenuItem_AddPattern.Size = New System.Drawing.Size(123, 22)
        Me.ToolStripMenuItem_AddPattern.Tag = "ADD"
        Me.ToolStripMenuItem_AddPattern.Text = "Add"
        '
        'ToolStripMenuItem_RemovePattern
        '
        Me.ToolStripMenuItem_RemovePattern.Name = "ToolStripMenuItem_RemovePattern"
        Me.ToolStripMenuItem_RemovePattern.Size = New System.Drawing.Size(123, 22)
        Me.ToolStripMenuItem_RemovePattern.Tag = "REMOVE"
        Me.ToolStripMenuItem_RemovePattern.Text = "Remove"
        '
        'ContextMenuStrip_Model
        '
        Me.ContextMenuStrip_Model.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem_AddModel, Me.ToolStripMenuItem_RemoveModel, Me.ToolStripMenuItem_SetCurrentModel})
        Me.ContextMenuStrip_Model.Name = "ContextMenuStrip_Model"
        Me.ContextMenuStrip_Model.Size = New System.Drawing.Size(139, 70)
        '
        'ToolStripMenuItem_AddModel
        '
        Me.ToolStripMenuItem_AddModel.Name = "ToolStripMenuItem_AddModel"
        Me.ToolStripMenuItem_AddModel.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem_AddModel.Tag = "ADD"
        Me.ToolStripMenuItem_AddModel.Text = "Add"
        '
        'ToolStripMenuItem_RemoveModel
        '
        Me.ToolStripMenuItem_RemoveModel.Name = "ToolStripMenuItem_RemoveModel"
        Me.ToolStripMenuItem_RemoveModel.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem_RemoveModel.Tag = "REMOVE"
        Me.ToolStripMenuItem_RemoveModel.Text = "Remove"
        '
        'ToolStripMenuItem_SetCurrentModel
        '
        Me.ToolStripMenuItem_SetCurrentModel.Name = "ToolStripMenuItem_SetCurrentModel"
        Me.ToolStripMenuItem_SetCurrentModel.Size = New System.Drawing.Size(138, 22)
        Me.ToolStripMenuItem_SetCurrentModel.Tag = "SET_CURRENT"
        Me.ToolStripMenuItem_SetCurrentModel.Text = "Set Current"
        '
        'Button_BarcodeSetting
        '
        Me.Button_BarcodeSetting.Location = New System.Drawing.Point(12, 127)
        Me.Button_BarcodeSetting.Name = "Button_BarcodeSetting"
        Me.Button_BarcodeSetting.Size = New System.Drawing.Size(125, 23)
        Me.Button_BarcodeSetting.TabIndex = 26
        Me.Button_BarcodeSetting.Text = "Barcode Setting"
        Me.Button_BarcodeSetting.UseVisualStyleBackColor = True
        '
        'StatusBar_IP
        '
        Me.StatusBar_IP.Location = New System.Drawing.Point(0, 636)
        Me.StatusBar_IP.Name = "StatusBar_IP"
        Me.StatusBar_IP.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel_IPStatus})
        Me.StatusBar_IP.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StatusBar_IP.ShowPanels = True
        Me.StatusBar_IP.Size = New System.Drawing.Size(1376, 24)
        Me.StatusBar_IP.TabIndex = 10022
        '
        'StatusBarPanel_IPStatus
        '
        Me.StatusBarPanel_IPStatus.Name = "StatusBarPanel_IPStatus"
        Me.StatusBarPanel_IPStatus.Text = "IP Status："
        Me.StatusBarPanel_IPStatus.Width = 750
        '
        'mnuMain
        '
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmEdit})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Size = New System.Drawing.Size(1376, 24)
        Me.mnuMain.TabIndex = 10019
        Me.mnuMain.Text = "MenuStrip1"
        '
        'tsmEdit
        '
        Me.tsmEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmRecipe})
        Me.tsmEdit.Name = "tsmEdit"
        Me.tsmEdit.Size = New System.Drawing.Size(74, 20)
        Me.tsmEdit.Text = "編輯(Edit)"
        '
        'tsmRecipe
        '
        Me.tsmRecipe.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.tsmIPNetWorkConfig, Me.tsmIPBootConfig})
        Me.tsmRecipe.Name = "tsmRecipe"
        Me.tsmRecipe.Size = New System.Drawing.Size(115, 22)
        Me.tsmRecipe.Text = "Recipe"
        '
        'tsmIPNetWorkConfig
        '
        Me.tsmIPNetWorkConfig.Name = "tsmIPNetWorkConfig"
        Me.tsmIPNetWorkConfig.Size = New System.Drawing.Size(265, 22)
        Me.tsmIPNetWorkConfig.Text = "IP 網路編輯(IPNetWorkConfig)"
        '
        'tsmIPBootConfig
        '
        Me.tsmIPBootConfig.Name = "tsmIPBootConfig"
        Me.tsmIPBootConfig.Size = New System.Drawing.Size(265, 22)
        Me.tsmIPBootConfig.Text = "IP Boot Recipe編輯(IPBootConfig)"
        '
        'GroupBox_IPStatus
        '
        Me.GroupBox_IPStatus.Controls.Add(Me.Button_InitialIP)
        Me.GroupBox_IPStatus.Controls.Add(Me.Button_KillIP)
        Me.GroupBox_IPStatus.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox_IPStatus.Name = "GroupBox_IPStatus"
        Me.GroupBox_IPStatus.Size = New System.Drawing.Size(73, 84)
        Me.GroupBox_IPStatus.TabIndex = 10023
        Me.GroupBox_IPStatus.TabStop = False
        Me.GroupBox_IPStatus.Text = "IP Status"
        '
        'Button_InitialIP
        '
        Me.Button_InitialIP.Location = New System.Drawing.Point(6, 21)
        Me.Button_InitialIP.Name = "Button_InitialIP"
        Me.Button_InitialIP.Size = New System.Drawing.Size(56, 32)
        Me.Button_InitialIP.TabIndex = 96
        Me.Button_InitialIP.Text = "Initial IP"
        Me.Button_InitialIP.UseVisualStyleBackColor = True
        '
        'Button_KillIP
        '
        Me.Button_KillIP.Location = New System.Drawing.Point(6, 59)
        Me.Button_KillIP.Name = "Button_KillIP"
        Me.Button_KillIP.Size = New System.Drawing.Size(56, 20)
        Me.Button_KillIP.TabIndex = 97
        Me.Button_KillIP.Text = "Kill IP"
        Me.Button_KillIP.UseVisualStyleBackColor = True
        '
        'ComboBox_GrabNo
        '
        Me.ComboBox_GrabNo.Enabled = False
        Me.ComboBox_GrabNo.FormattingEnabled = True
        Me.ComboBox_GrabNo.Location = New System.Drawing.Point(83, 120)
        Me.ComboBox_GrabNo.Name = "ComboBox_GrabNo"
        Me.ComboBox_GrabNo.Size = New System.Drawing.Size(56, 20)
        Me.ComboBox_GrabNo.TabIndex = 10005
        '
        'ComboBox_CCDMode
        '
        Me.ComboBox_CCDMode.Enabled = False
        Me.ComboBox_CCDMode.FormattingEnabled = True
        Me.ComboBox_CCDMode.Items.AddRange(New Object() {"2", "3", "9"})
        Me.ComboBox_CCDMode.Location = New System.Drawing.Point(83, 94)
        Me.ComboBox_CCDMode.Name = "ComboBox_CCDMode"
        Me.ComboBox_CCDMode.Size = New System.Drawing.Size(56, 20)
        Me.ComboBox_CCDMode.TabIndex = 10004
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(25, 124)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 12)
        Me.Label4.TabIndex = 10003
        Me.Label4.Text = "Grab No："
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 98)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 12)
        Me.Label3.TabIndex = 10002
        Me.Label3.Text = "CCD Mode："
        '
        'GroupBox_IP
        '
        Me.GroupBox_IP.Controls.Add(Me.ComboBox_CCD)
        Me.GroupBox_IP.Controls.Add(Me.Label1)
        Me.GroupBox_IP.Location = New System.Drawing.Point(6, 146)
        Me.GroupBox_IP.Name = "GroupBox_IP"
        Me.GroupBox_IP.Size = New System.Drawing.Size(163, 45)
        Me.GroupBox_IP.TabIndex = 10018
        Me.GroupBox_IP.TabStop = False
        Me.GroupBox_IP.Text = "IP Selection"
        '
        'ComboBox_CCD
        '
        Me.ComboBox_CCD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_CCD.FormattingEnabled = True
        Me.ComboBox_CCD.Location = New System.Drawing.Point(62, 18)
        Me.ComboBox_CCD.Name = "ComboBox_CCD"
        Me.ComboBox_CCD.Size = New System.Drawing.Size(85, 20)
        Me.ComboBox_CCD.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "IP："
        '
        'Button_FuncResult
        '
        Me.Button_FuncResult.Location = New System.Drawing.Point(87, 35)
        Me.Button_FuncResult.Name = "Button_FuncResult"
        Me.Button_FuncResult.Size = New System.Drawing.Size(85, 23)
        Me.Button_FuncResult.TabIndex = 10017
        Me.Button_FuncResult.Text = "Func判片結果"
        '
        'btnClearLog
        '
        Me.btnClearLog.Location = New System.Drawing.Point(92, 6)
        Me.btnClearLog.Name = "btnClearLog"
        Me.btnClearLog.Size = New System.Drawing.Size(74, 23)
        Me.btnClearLog.TabIndex = 10016
        Me.btnClearLog.Text = "Clear Log"
        Me.btnClearLog.UseVisualStyleBackColor = True
        '
        'StatusBar
        '
        Me.StatusBar.Location = New System.Drawing.Point(0, 660)
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel_XY, Me.StatusBarPanel_Value, Me.StatusBarPanel_Scale, Me.StatusBarPanel_UsedNonPage, Me.StatusBarPanel_Status})
        Me.StatusBar.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StatusBar.ShowPanels = True
        Me.StatusBar.Size = New System.Drawing.Size(1376, 22)
        Me.StatusBar.TabIndex = 10013
        '
        'StatusBarPanel_XY
        '
        Me.StatusBarPanel_XY.Name = "StatusBarPanel_XY"
        Me.StatusBarPanel_XY.Text = "(X,Y) = NULL"
        '
        'StatusBarPanel_Value
        '
        Me.StatusBarPanel_Value.Name = "StatusBarPanel_Value"
        Me.StatusBarPanel_Value.Text = "亮度 = NULL"
        Me.StatusBarPanel_Value.Width = 80
        '
        'StatusBarPanel_Scale
        '
        Me.StatusBarPanel_Scale.Name = "StatusBarPanel_Scale"
        Me.StatusBarPanel_Scale.Text = "縮放 = 1.0"
        Me.StatusBarPanel_Scale.Width = 70
        '
        'StatusBarPanel_UsedNonPage
        '
        Me.StatusBarPanel_UsedNonPage.Name = "StatusBarPanel_UsedNonPage"
        Me.StatusBarPanel_UsedNonPage.Text = "UsedNonPage = NULL"
        Me.StatusBarPanel_UsedNonPage.Width = 130
        '
        'StatusBarPanel_Status
        '
        Me.StatusBarPanel_Status.Name = "StatusBarPanel_Status"
        Me.StatusBarPanel_Status.Text = "Status："
        Me.StatusBarPanel_Status.Width = 330
        '
        'GroupBox_Image
        '
        Me.GroupBox_Image.Controls.Add(Me.CheckBox_SaveAI)
        Me.GroupBox_Image.Location = New System.Drawing.Point(182, 6)
        Me.GroupBox_Image.Name = "GroupBox_Image"
        Me.GroupBox_Image.Size = New System.Drawing.Size(64, 53)
        Me.GroupBox_Image.TabIndex = 10015
        Me.GroupBox_Image.TabStop = False
        Me.GroupBox_Image.Text = "影像"
        '
        'CheckBox_SaveAI
        '
        Me.CheckBox_SaveAI.AutoSize = True
        Me.CheckBox_SaveAI.Location = New System.Drawing.Point(13, 21)
        Me.CheckBox_SaveAI.Name = "CheckBox_SaveAI"
        Me.CheckBox_SaveAI.Size = New System.Drawing.Size(36, 16)
        Me.CheckBox_SaveAI.TabIndex = 34
        Me.CheckBox_SaveAI.Text = "AI"
        Me.CheckBox_SaveAI.UseVisualStyleBackColor = True
        '
        'TabControl_HightLevel
        '
        Me.TabControl_HightLevel.Controls.Add(Me.TabPage_HighLevelOP)
        Me.TabControl_HightLevel.Controls.Add(Me.TabPage_OMS)
        Me.TabControl_HightLevel.Controls.Add(Me.TabPage_Tool)
        Me.TabControl_HightLevel.Location = New System.Drawing.Point(1311, 27)
        Me.TabControl_HightLevel.Multiline = True
        Me.TabControl_HightLevel.Name = "TabControl_HightLevel"
        Me.TabControl_HightLevel.SelectedIndex = 0
        Me.TabControl_HightLevel.Size = New System.Drawing.Size(257, 599)
        Me.TabControl_HightLevel.TabIndex = 10012
        '
        'TabPage_HighLevelOP
        '
        Me.TabPage_HighLevelOP.Controls.Add(Me.GroupBox_Log)
        Me.TabPage_HighLevelOP.Controls.Add(Me.Button_SetMappingTable)
        Me.TabPage_HighLevelOP.Controls.Add(Me.GroupBox_Image)
        Me.TabPage_HighLevelOP.Controls.Add(Me.GroupBox_FuncSetting)
        Me.TabPage_HighLevelOP.Controls.Add(Me.GroupBox_IPStatus)
        Me.TabPage_HighLevelOP.Controls.Add(Me.btnClearLog)
        Me.TabPage_HighLevelOP.Controls.Add(Me.ComboBox_CCDMode)
        Me.TabPage_HighLevelOP.Controls.Add(Me.Label3)
        Me.TabPage_HighLevelOP.Controls.Add(Me.Label4)
        Me.TabPage_HighLevelOP.Controls.Add(Me.ComboBox_GrabNo)
        Me.TabPage_HighLevelOP.Controls.Add(Me.GroupBox_IP)
        Me.TabPage_HighLevelOP.Controls.Add(Me.Button_FuncResult)
        Me.TabPage_HighLevelOP.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_HighLevelOP.Name = "TabPage_HighLevelOP"
        Me.TabPage_HighLevelOP.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_HighLevelOP.Size = New System.Drawing.Size(249, 573)
        Me.TabPage_HighLevelOP.TabIndex = 17
        Me.TabPage_HighLevelOP.Text = "高階操作"
        Me.TabPage_HighLevelOP.UseVisualStyleBackColor = True
        '
        'GroupBox_Log
        '
        Me.GroupBox_Log.Controls.Add(Me.DateTimePicker_Log)
        Me.GroupBox_Log.Controls.Add(Me.Button_Log_Open)
        Me.GroupBox_Log.Controls.Add(Me.ComboBox_Log_Type)
        Me.GroupBox_Log.Controls.Add(Me.Label5)
        Me.GroupBox_Log.Controls.Add(Me.Label2)
        Me.GroupBox_Log.Controls.Add(Me.ComboBox_Log_IPNo)
        Me.GroupBox_Log.Location = New System.Drawing.Point(6, 423)
        Me.GroupBox_Log.Name = "GroupBox_Log"
        Me.GroupBox_Log.Size = New System.Drawing.Size(251, 94)
        Me.GroupBox_Log.TabIndex = 103
        Me.GroupBox_Log.TabStop = False
        Me.GroupBox_Log.Text = "Log"
        '
        'DateTimePicker_Log
        '
        Me.DateTimePicker_Log.Location = New System.Drawing.Point(120, 12)
        Me.DateTimePicker_Log.Name = "DateTimePicker_Log"
        Me.DateTimePicker_Log.Size = New System.Drawing.Size(107, 22)
        Me.DateTimePicker_Log.TabIndex = 5
        Me.DateTimePicker_Log.Value = New Date(2011, 1, 6, 0, 0, 0, 0)
        '
        'Button_Log_Open
        '
        Me.Button_Log_Open.Location = New System.Drawing.Point(168, 65)
        Me.Button_Log_Open.Name = "Button_Log_Open"
        Me.Button_Log_Open.Size = New System.Drawing.Size(59, 23)
        Me.Button_Log_Open.TabIndex = 4
        Me.Button_Log_Open.Text = "Open"
        Me.Button_Log_Open.UseVisualStyleBackColor = True
        '
        'ComboBox_Log_Type
        '
        Me.ComboBox_Log_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Log_Type.FormattingEnabled = True
        Me.ComboBox_Log_Type.Location = New System.Drawing.Point(67, 38)
        Me.ComboBox_Log_Type.Name = "ComboBox_Log_Type"
        Me.ComboBox_Log_Type.Size = New System.Drawing.Size(160, 20)
        Me.ComboBox_Log_Type.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(4, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(60, 12)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Log 種類 : "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(40, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "IP : "
        '
        'ComboBox_Log_IPNo
        '
        Me.ComboBox_Log_IPNo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Log_IPNo.FormattingEnabled = True
        Me.ComboBox_Log_IPNo.Location = New System.Drawing.Point(67, 13)
        Me.ComboBox_Log_IPNo.Name = "ComboBox_Log_IPNo"
        Me.ComboBox_Log_IPNo.Size = New System.Drawing.Size(47, 20)
        Me.ComboBox_Log_IPNo.TabIndex = 0
        '
        'Button_SetMappingTable
        '
        Me.Button_SetMappingTable.Location = New System.Drawing.Point(87, 61)
        Me.Button_SetMappingTable.Name = "Button_SetMappingTable"
        Me.Button_SetMappingTable.Size = New System.Drawing.Size(84, 27)
        Me.Button_SetMappingTable.TabIndex = 65
        Me.Button_SetMappingTable.Text = "MappingTable"
        '
        'GroupBox_FuncSetting
        '
        Me.GroupBox_FuncSetting.Controls.Add(Me.Button_SettingBase)
        Me.GroupBox_FuncSetting.Controls.Add(Me.Button_MuraCollect)
        Me.GroupBox_FuncSetting.Controls.Add(Me.Button_AlignTest)
        Me.GroupBox_FuncSetting.Controls.Add(Me.Button_FuncSettingBase)
        Me.GroupBox_FuncSetting.Location = New System.Drawing.Point(6, 197)
        Me.GroupBox_FuncSetting.Name = "GroupBox_FuncSetting"
        Me.GroupBox_FuncSetting.Size = New System.Drawing.Size(236, 164)
        Me.GroupBox_FuncSetting.TabIndex = 41
        Me.GroupBox_FuncSetting.TabStop = False
        Me.GroupBox_FuncSetting.Text = "參數設定"
        '
        'Button_SettingBase
        '
        Me.Button_SettingBase.Location = New System.Drawing.Point(6, 79)
        Me.Button_SettingBase.Name = "Button_SettingBase"
        Me.Button_SettingBase.Size = New System.Drawing.Size(90, 23)
        Me.Button_SettingBase.TabIndex = 0
        Me.Button_SettingBase.Text = "Mura 基本設定"
        Me.Button_SettingBase.UseVisualStyleBackColor = True
        '
        'Button_MuraCollect
        '
        Me.Button_MuraCollect.Location = New System.Drawing.Point(136, 79)
        Me.Button_MuraCollect.Name = "Button_MuraCollect"
        Me.Button_MuraCollect.Size = New System.Drawing.Size(94, 22)
        Me.Button_MuraCollect.TabIndex = 6
        Me.Button_MuraCollect.Text = "Mura Collect"
        Me.Button_MuraCollect.UseVisualStyleBackColor = True
        '
        'Button_AlignTest
        '
        Me.Button_AlignTest.Location = New System.Drawing.Point(6, 18)
        Me.Button_AlignTest.Name = "Button_AlignTest"
        Me.Button_AlignTest.Size = New System.Drawing.Size(102, 27)
        Me.Button_AlignTest.TabIndex = 6
        Me.Button_AlignTest.Text = "Alignment Setting"
        Me.Button_AlignTest.UseVisualStyleBackColor = True
        '
        'Button_FuncSettingBase
        '
        Me.Button_FuncSettingBase.Location = New System.Drawing.Point(6, 50)
        Me.Button_FuncSettingBase.Name = "Button_FuncSettingBase"
        Me.Button_FuncSettingBase.Size = New System.Drawing.Size(102, 23)
        Me.Button_FuncSettingBase.TabIndex = 4
        Me.Button_FuncSettingBase.Text = "Func 基本設定"
        Me.Button_FuncSettingBase.UseVisualStyleBackColor = True
        '
        'TabPage_OMS
        '
        Me.TabPage_OMS.Controls.Add(Me.Button_OMSSetting)
        Me.TabPage_OMS.Controls.Add(Me.GroupBox_OMS_Enable_Setting)
        Me.TabPage_OMS.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_OMS.Name = "TabPage_OMS"
        Me.TabPage_OMS.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_OMS.Size = New System.Drawing.Size(249, 573)
        Me.TabPage_OMS.TabIndex = 16
        Me.TabPage_OMS.Text = "OMS"
        Me.TabPage_OMS.UseVisualStyleBackColor = True
        '
        'Button_OMSSetting
        '
        Me.Button_OMSSetting.Location = New System.Drawing.Point(143, 90)
        Me.Button_OMSSetting.Name = "Button_OMSSetting"
        Me.Button_OMSSetting.Size = New System.Drawing.Size(70, 24)
        Me.Button_OMSSetting.TabIndex = 1
        Me.Button_OMSSetting.Text = "OMS"
        Me.Button_OMSSetting.UseVisualStyleBackColor = True
        '
        'GroupBox_OMS_Enable_Setting
        '
        Me.GroupBox_OMS_Enable_Setting.Controls.Add(Me.Button_OMS_Save)
        Me.GroupBox_OMS_Enable_Setting.Controls.Add(Me.ComboBox_OMS_Enable_IPNo)
        Me.GroupBox_OMS_Enable_Setting.Controls.Add(Me.Label6)
        Me.GroupBox_OMS_Enable_Setting.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox_OMS_Enable_Setting.Location = New System.Drawing.Point(4, 7)
        Me.GroupBox_OMS_Enable_Setting.Name = "GroupBox_OMS_Enable_Setting"
        Me.GroupBox_OMS_Enable_Setting.Size = New System.Drawing.Size(209, 73)
        Me.GroupBox_OMS_Enable_Setting.TabIndex = 0
        Me.GroupBox_OMS_Enable_Setting.TabStop = False
        Me.GroupBox_OMS_Enable_Setting.Text = "OMS Enable Setting"
        '
        'Button_OMS_Save
        '
        Me.Button_OMS_Save.ForeColor = System.Drawing.Color.Black
        Me.Button_OMS_Save.Location = New System.Drawing.Point(12, 43)
        Me.Button_OMS_Save.Name = "Button_OMS_Save"
        Me.Button_OMS_Save.Size = New System.Drawing.Size(60, 24)
        Me.Button_OMS_Save.TabIndex = 2
        Me.Button_OMS_Save.Text = "Save"
        Me.Button_OMS_Save.UseVisualStyleBackColor = True
        '
        'ComboBox_OMS_Enable_IPNo
        '
        Me.ComboBox_OMS_Enable_IPNo.FormattingEnabled = True
        Me.ComboBox_OMS_Enable_IPNo.Location = New System.Drawing.Point(115, 20)
        Me.ComboBox_OMS_Enable_IPNo.Name = "ComboBox_OMS_Enable_IPNo"
        Me.ComboBox_OMS_Enable_IPNo.Size = New System.Drawing.Size(58, 20)
        Me.ComboBox_OMS_Enable_IPNo.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(10, 24)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(97, 12)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "OMS Enable IP No:"
        '
        'TabPage_Tool
        '
        Me.TabPage_Tool.Controls.Add(Me.Button_BarcodeSetting)
        Me.TabPage_Tool.Controls.Add(Me.Button_RMSSetting)
        Me.TabPage_Tool.Controls.Add(Me.Button_MDC_Setting)
        Me.TabPage_Tool.Controls.Add(Me.Button_LookUpPosition)
        Me.TabPage_Tool.Location = New System.Drawing.Point(4, 22)
        Me.TabPage_Tool.Name = "TabPage_Tool"
        Me.TabPage_Tool.Size = New System.Drawing.Size(249, 573)
        Me.TabPage_Tool.TabIndex = 14
        Me.TabPage_Tool.Text = "Tool"
        Me.TabPage_Tool.UseVisualStyleBackColor = True
        '
        'Button_RMSSetting
        '
        Me.Button_RMSSetting.Location = New System.Drawing.Point(12, 98)
        Me.Button_RMSSetting.Name = "Button_RMSSetting"
        Me.Button_RMSSetting.Size = New System.Drawing.Size(125, 23)
        Me.Button_RMSSetting.TabIndex = 33
        Me.Button_RMSSetting.Text = "RMS Setting"
        Me.Button_RMSSetting.UseVisualStyleBackColor = True
        '
        'Button_MDC_Setting
        '
        Me.Button_MDC_Setting.Location = New System.Drawing.Point(12, 40)
        Me.Button_MDC_Setting.Name = "Button_MDC_Setting"
        Me.Button_MDC_Setting.Size = New System.Drawing.Size(125, 23)
        Me.Button_MDC_Setting.TabIndex = 30
        Me.Button_MDC_Setting.Text = "MDC Setting"
        Me.Button_MDC_Setting.UseVisualStyleBackColor = True
        '
        'Button_LookUpPosition
        '
        Me.Button_LookUpPosition.Location = New System.Drawing.Point(12, 9)
        Me.Button_LookUpPosition.Name = "Button_LookUpPosition"
        Me.Button_LookUpPosition.Size = New System.Drawing.Size(125, 23)
        Me.Button_LookUpPosition.TabIndex = 0
        Me.Button_LookUpPosition.Text = "Look up Position"
        Me.Button_LookUpPosition.UseVisualStyleBackColor = True
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.Filter = "圖檔 (*.tif)|*.tif"
        '
        'SaveFileDialog
        '
        Me.SaveFileDialog.Filter = "TIFF(*.tif;*.tiff)|*.tif;*.tiff"
        '
        'ZoomContextMenuStrip
        '
        Me.ZoomContextMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ZoomInToolStripMenuItem, Me.ZoomOutToolStripMenuItem, Me.OriginToolStripMenuItem, Me.ZoomAllToolStripMenuItem, Me.BitToolStripMenuItem, Me.BitToolStripMenuItem1, Me.BitToolStripMenuItem2})
        Me.ZoomContextMenuStrip.Name = "ContextMenuStrip"
        Me.ZoomContextMenuStrip.Size = New System.Drawing.Size(132, 158)
        '
        'ZoomInToolStripMenuItem
        '
        Me.ZoomInToolStripMenuItem.Name = "ZoomInToolStripMenuItem"
        Me.ZoomInToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.ZoomInToolStripMenuItem.Text = "ZoomIn"
        '
        'ZoomOutToolStripMenuItem
        '
        Me.ZoomOutToolStripMenuItem.Name = "ZoomOutToolStripMenuItem"
        Me.ZoomOutToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.ZoomOutToolStripMenuItem.Text = "ZoomOut"
        '
        'OriginToolStripMenuItem
        '
        Me.OriginToolStripMenuItem.Name = "OriginToolStripMenuItem"
        Me.OriginToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.OriginToolStripMenuItem.Text = "Origin"
        '
        'ZoomAllToolStripMenuItem
        '
        Me.ZoomAllToolStripMenuItem.Name = "ZoomAllToolStripMenuItem"
        Me.ZoomAllToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.ZoomAllToolStripMenuItem.Text = "ZoomAll"
        '
        'BitToolStripMenuItem
        '
        Me.BitToolStripMenuItem.Name = "BitToolStripMenuItem"
        Me.BitToolStripMenuItem.Size = New System.Drawing.Size(131, 22)
        Me.BitToolStripMenuItem.Text = "10 bit"
        '
        'BitToolStripMenuItem1
        '
        Me.BitToolStripMenuItem1.Name = "BitToolStripMenuItem1"
        Me.BitToolStripMenuItem1.Size = New System.Drawing.Size(131, 22)
        Me.BitToolStripMenuItem1.Text = "8 bit"
        '
        'BitToolStripMenuItem2
        '
        Me.BitToolStripMenuItem2.Name = "BitToolStripMenuItem2"
        Me.BitToolStripMenuItem2.Size = New System.Drawing.Size(131, 22)
        Me.BitToolStripMenuItem2.Text = "12 bit"
        '
        'NotifyIcon_AreaGrabber
        '
        Me.NotifyIcon_AreaGrabber.BalloonTipText = "AreaGrabber"
        Me.NotifyIcon_AreaGrabber.Icon = CType(resources.GetObject("NotifyIcon_AreaGrabber.Icon"), System.Drawing.Icon)
        Me.NotifyIcon_AreaGrabber.Text = "AreaGrabber"
        '
        'RadioButton_Licensed
        '
        Me.RadioButton_Licensed.AutoSize = True
        Me.RadioButton_Licensed.Checked = True
        Me.RadioButton_Licensed.Enabled = False
        Me.RadioButton_Licensed.Location = New System.Drawing.Point(735, 664)
        Me.RadioButton_Licensed.Name = "RadioButton_Licensed"
        Me.RadioButton_Licensed.Size = New System.Drawing.Size(64, 16)
        Me.RadioButton_Licensed.TabIndex = 10032
        Me.RadioButton_Licensed.TabStop = True
        Me.RadioButton_Licensed.Text = "Licensed"
        Me.RadioButton_Licensed.UseVisualStyleBackColor = True
        '
        'CheckBox_IsAligned
        '
        Me.CheckBox_IsAligned.AutoSize = True
        Me.CheckBox_IsAligned.Enabled = False
        Me.CheckBox_IsAligned.Location = New System.Drawing.Point(758, 641)
        Me.CheckBox_IsAligned.Name = "CheckBox_IsAligned"
        Me.CheckBox_IsAligned.Size = New System.Drawing.Size(50, 16)
        Me.CheckBox_IsAligned.TabIndex = 10035
        Me.CheckBox_IsAligned.Text = "Align"
        Me.CheckBox_IsAligned.UseVisualStyleBackColor = True
        '
        'ContextMenuStrip_MuraPattern
        '
        Me.ContextMenuStrip_MuraPattern.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ToolStripMenuItem2})
        Me.ContextMenuStrip_MuraPattern.Name = "ContextMenuStrip"
        Me.ContextMenuStrip_MuraPattern.Size = New System.Drawing.Size(124, 48)
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(123, 22)
        Me.ToolStripMenuItem1.Text = "Add"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(123, 22)
        Me.ToolStripMenuItem2.Text = "Remove"
        '
        'tmr
        '
        Me.tmr.Interval = 500
        '
        'Main_Form
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1376, 682)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.CheckBox_IsAligned)
        Me.Controls.Add(Me.RadioButton_Licensed)
        Me.Controls.Add(Me.StatusBar_IP)
        Me.Controls.Add(Me.mnuMain)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.TabControl_HightLevel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Main_Form"
        Me.Text = "AreaGrabber"
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.TabControl_SystemParam.ResumeLayout(False)
        Me.TabPage_Model.ResumeLayout(False)
        Me.TabPage_Exp.ResumeLayout(False)
        Me.GroupBox_ExpSetting.ResumeLayout(False)
        Me.GroupBox_ExpSetting.PerformLayout()
        Me.GroupBox_ExposureTime.ResumeLayout(False)
        CType(Me.NumericUpDown_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Align.ResumeLayout(False)
        Me.TabPage_Align.PerformLayout()
        Me.GroupBox_MT.ResumeLayout(False)
        Me.GroupBox_MT.PerformLayout()
        Me.GroupBox_Local.ResumeLayout(False)
        CType(Me.NumericUpDown_LocalRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LocalLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LocalTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LocalBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PanelRotate.ResumeLayout(False)
        Me.GroupBox_PanelRotate.PerformLayout()
        Me.GroupBox_Alignment.ResumeLayout(False)
        Me.GroupBox_Alignment.PerformLayout()
        CType(Me.NumericUpDown_AlignTolerance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AlignmentShift, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_AlignDirectionAndOffSet.ResumeLayout(False)
        Me.GroupBox_AlignDirectionAndOffSet.PerformLayout()
        CType(Me.NumericUpDown_ShiftOffset_Top, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ShiftOffset_Left, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ShiftOffset_Bottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ShiftOffset_Right, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BoundaryModify.ResumeLayout(False)
        Me.GroupBox_Boundary.ResumeLayout(False)
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_FuncParam.ResumeLayout(False)
        Me.Panel_FuncParam.ResumeLayout(False)
        Me.Panel_FuncParam.PerformLayout()
        Me.GroupBox_GrayAbnormal.ResumeLayout(False)
        Me.GroupBox_GrayAbnormal.PerformLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_DLine.ResumeLayout(False)
        Me.GroupBox_DLine.PerformLayout()
        CType(Me.NumericUpDown_DL_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DL_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_ImgProcBoundary.ResumeLayout(False)
        Me.GroupBox_ImgProcBoundary.PerformLayout()
        CType(Me.NumericUpDown_Boundary_MulWidth_RX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_BY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_LX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_TY, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_LinePitchSetting.ResumeLayout(False)
        Me.GroupBox_LinePitchSetting.PerformLayout()
        CType(Me.NumericUpDown_Line_PitchY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_PitchX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PointMode.ResumeLayout(False)
        Me.GroupBox_PointMode.PerformLayout()
        Me.GroupBox_LineAverageFilter.ResumeLayout(False)
        Me.GroupBox_LineAverageFilter.PerformLayout()
        CType(Me.NumericUpDown_AverageFilter, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Point_Algorithm.ResumeLayout(False)
        Me.GroupBox_Point_Algorithm.PerformLayout()
        Me.GroupBox_BLine.ResumeLayout(False)
        Me.GroupBox_BLine.PerformLayout()
        CType(Me.NumericUpDown_BL_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BL_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PointPitchSetting.ResumeLayout(False)
        Me.GroupBox_PointPitchSetting.PerformLayout()
        CType(Me.NumericUpDown_Point_PitchY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_PitchX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_DP_Characteristics.ResumeLayout(False)
        Me.GroupBox_DP_Characteristics.PerformLayout()
        CType(Me.NumericUpDown_DP_MinGray_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Compactness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_StdDev_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_MinGray_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_GrayMean_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Fullness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BP_Characteristics.ResumeLayout(False)
        Me.GroupBox_BP_Characteristics.PerformLayout()
        CType(Me.NumericUpDown_BP_MaxGray_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_StdDev_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Compactness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_MaxGray_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_GrayMean_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Fullness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_LineCommonSetting.ResumeLayout(False)
        Me.GroupBox_LineCommonSetting.PerformLayout()
        CType(Me.NumericUpDown_Line_Short_Cut_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_Cut_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassRightV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassLeftV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Block_OverNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_Short_Cut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassUpH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassDownH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_Cut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_OverNumber, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BPoint.ResumeLayout(False)
        Me.GroupBox_BPoint.PerformLayout()
        CType(Me.NumericUpDown_BP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Threshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PointCommonSetting.ResumeLayout(False)
        Me.GroupBox_PointCommonSetting.PerformLayout()
        CType(Me.NumericUpDown_DP_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_OverNum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_ByPassY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_ByPassX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_DPoint.ResumeLayout(False)
        Me.GroupBox_DPoint.PerformLayout()
        CType(Me.NumericUpDown_DP_Threshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_MuraParam.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TabControl_MuraParam.ResumeLayout(False)
        Me.TabPage_MuraPreprocessParam.ResumeLayout(False)
        Me.TabPage_MuraPreprocessParam.PerformLayout()
        Me.GroupBox_MuraRatio.ResumeLayout(False)
        Me.GroupBox_BlobResize.ResumeLayout(False)
        Me.GroupBox_BlobResize.PerformLayout()
        CType(Me.Num_ResizeCount_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Mid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MarcoResize.ResumeLayout(False)
        Me.GroupBox_MarcoResize.PerformLayout()
        CType(Me.Num_ResizeCount_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Mid2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MacroPowerY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MacroPowerX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DefocusCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MacroMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlobMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_MuraBlobParam.ResumeLayout(False)
        Me.GroupBox_Modify.ResumeLayout(False)
        Me.GroupBox_MuraCenterBlobByPass.ResumeLayout(False)
        CType(Me.NumericUpDown_MuraCenterBlobByPassRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MuraCenterBlobByPassLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MuraCenterBlobByPassTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MuraCenterBlobByPassBotton, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MuraCenterBlobThreshold.ResumeLayout(False)
        Me.GroupBox_MuraCenterBlobThreshold.PerformLayout()
        CType(Me.NUD_BlackBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackMacroMura_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteMacroMura_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_MuraAroundParam.ResumeLayout(False)
        Me.GroupBox_RimBlobValue.ResumeLayout(False)
        CType(Me.NumericUpDown_BlackRimBlobValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteRimBlobValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MuraAroundByPass.ResumeLayout(False)
        Me.GroupBox_Round.ResumeLayout(False)
        CType(Me.NumericUpDown_RimRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MuraAroundThreshold.ResumeLayout(False)
        Me.GroupBox_MuraAroundThreshold.PerformLayout()
        CType(Me.NumericUpDown_BlackMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlackMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_MuraBandParam.ResumeLayout(False)
        Me.GroupBox_BandVOpenSearch.ResumeLayout(False)
        CType(Me.NumericUpDown_BandVOpenEdgeStrength, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BandBlockH.ResumeLayout(False)
        Me.GroupBox_BandLeakPoint.ResumeLayout(False)
        CType(Me.NumericUpDown_BandLeakPointFilterRadius, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BandResizeThreshold.ResumeLayout(False)
        Me.GroupBox_BandResizeThreshold.PerformLayout()
        CType(Me.NumericUpDown_BlackVBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlackHBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BandMura_SmoothCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BandMura_ResizeCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteHBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteVBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BandBlockV.ResumeLayout(False)
        Me.GroupBox_BandByPass.ResumeLayout(False)
        Me.GroupBox_V.ResumeLayout(False)
        Me.GroupBox_V.PerformLayout()
        CType(Me.NumericUpDown_VTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VBottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VLeft, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_H.ResumeLayout(False)
        Me.GroupBox_H.PerformLayout()
        CType(Me.NumericUpDown_HRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BandBlockSetting.ResumeLayout(False)
        Me.GroupBox_BandBlockSetting.PerformLayout()
        CType(Me.NumericUpDown_AutoWidth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockBlackTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockWhiteTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockButtom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockLeft, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.Panel2.PerformLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        CType(Me.PictureBox_VBand_White, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_VBand_Black, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_HBand_White, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_HBand_Black, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox_PreInfo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel_AxMDisplay.ResumeLayout(False)
        Me.Panel_AxMDisplay.PerformLayout()
        Me.ContextMenuStrip_FuncPattern.ResumeLayout(False)
        Me.ContextMenuStrip_Model.ResumeLayout(False)
        CType(Me.StatusBarPanel_IPStatus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.GroupBox_IPStatus.ResumeLayout(False)
        Me.GroupBox_IP.ResumeLayout(False)
        Me.GroupBox_IP.PerformLayout()
        CType(Me.StatusBarPanel_XY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Value, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Scale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_UsedNonPage, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Status, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Image.ResumeLayout(False)
        Me.GroupBox_Image.PerformLayout()
        Me.TabControl_HightLevel.ResumeLayout(False)
        Me.TabPage_HighLevelOP.ResumeLayout(False)
        Me.TabPage_HighLevelOP.PerformLayout()
        Me.GroupBox_Log.ResumeLayout(False)
        Me.GroupBox_Log.PerformLayout()
        Me.GroupBox_FuncSetting.ResumeLayout(False)
        Me.TabPage_OMS.ResumeLayout(False)
        Me.GroupBox_OMS_Enable_Setting.ResumeLayout(False)
        Me.GroupBox_OMS_Enable_Setting.PerformLayout()
        Me.TabPage_Tool.ResumeLayout(False)
        Me.ZoomContextMenuStrip.ResumeLayout(False)
        Me.ContextMenuStrip_MuraPattern.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel_AxMDisplay As System.Windows.Forms.Panel
    Friend WithEvents StatusBar_IP As System.Windows.Forms.StatusBar
    Friend WithEvents StatusBarPanel_IPStatus As System.Windows.Forms.StatusBarPanel
    Friend WithEvents txtOutput As System.Windows.Forms.RichTextBox
    Friend WithEvents TextBox_PreInfo As System.Windows.Forms.TextBox
    Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
    Friend WithEvents tsmEdit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmRecipe As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmIPNetWorkConfig As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents tsmIPBootConfig As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VScrollBar As System.Windows.Forms.VScrollBar
    Friend WithEvents GroupBox_IPStatus As System.Windows.Forms.GroupBox
    Friend WithEvents Button_InitialIP As System.Windows.Forms.Button
    Friend WithEvents Button_KillIP As System.Windows.Forms.Button
    Friend WithEvents ComboBox_GrabNo As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_CCDMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox_PreInfo As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox_IP As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_CCD As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button_FuncResult As System.Windows.Forms.Button
    Friend WithEvents btnClearLog As System.Windows.Forms.Button
    Friend WithEvents Button_ZoomAll As System.Windows.Forms.Button
    Friend WithEvents StatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents StatusBarPanel_XY As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_Value As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_Scale As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_UsedNonPage As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_Status As System.Windows.Forms.StatusBarPanel
    Friend WithEvents GroupBox_Image As System.Windows.Forms.GroupBox
    Friend WithEvents Button_LoadImage As System.Windows.Forms.Button
    Friend WithEvents TextBox_Product As System.Windows.Forms.TextBox
    Friend WithEvents Label_Product As System.Windows.Forms.Label
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Pattern_MainFrm As System.Windows.Forms.ComboBox
    Friend WithEvents Button_SaveImage As System.Windows.Forms.Button
    Friend WithEvents Label_Type As System.Windows.Forms.Label
    Friend WithEvents Label_Select As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Select As System.Windows.Forms.ComboBox
    Friend WithEvents Button_ZoomOut As System.Windows.Forms.Button
    Friend WithEvents Button_ZoomIn As System.Windows.Forms.Button
    Friend WithEvents Button_ZoomO As System.Windows.Forms.Button
    Friend WithEvents TabControl_HightLevel As System.Windows.Forms.TabControl
    Friend WithEvents Button_ADJMean As System.Windows.Forms.Button
    Friend WithEvents Button_FuncImgProcTest As System.Windows.Forms.Button
    Friend WithEvents GroupBox_FuncSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Button_SettingFunc As System.Windows.Forms.Button
    Friend WithEvents Button_FuncSettingBase As System.Windows.Forms.Button
    Friend WithEvents Button_FuncFalseDefect As System.Windows.Forms.Button
    Friend WithEvents Button_SetMappingTable As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Log As System.Windows.Forms.GroupBox
    Friend WithEvents DateTimePicker_Log As System.Windows.Forms.DateTimePicker
    Friend WithEvents Button_Log_Open As System.Windows.Forms.Button
    Friend WithEvents ComboBox_Log_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Log_IPNo As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage_Tool As System.Windows.Forms.TabPage
    Friend WithEvents Button_MDC_Setting As System.Windows.Forms.Button
    Friend WithEvents Button_LookUpPosition As System.Windows.Forms.Button
    Friend WithEvents HScrollBar As System.Windows.Forms.HScrollBar
    Friend WithEvents TabPage_OMS As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_OMS_Enable_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Button_OMS_Save As System.Windows.Forms.Button
    Friend WithEvents ComboBox_OMS_Enable_IPNo As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Button_OMSSetting As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents Button_SettingBase As System.Windows.Forms.Button
    Friend WithEvents Button_SettingMura As System.Windows.Forms.Button
    Friend WithEvents Button_MuraManualTest As System.Windows.Forms.Button
    Friend WithEvents Button_MuraAutoTest As System.Windows.Forms.Button
    Friend WithEvents Button_JND As System.Windows.Forms.Button
    Friend WithEvents Button_MuraFalseDefect As System.Windows.Forms.Button
    Friend WithEvents Button_MuraResult As System.Windows.Forms.Button
    Friend WithEvents Label_DisplayMsg As System.Windows.Forms.Label
    Friend WithEvents Button_CameraAlignment As System.Windows.Forms.Button
    Friend WithEvents ZoomContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ZoomInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ZoomOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OriginToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ZoomAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox_HBand_Black As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_VBand_Black As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_HBand_White As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox_VBand_White As System.Windows.Forms.PictureBox
    Friend WithEvents Button_Align As System.Windows.Forms.Button
    Friend WithEvents Button_ImgCal As System.Windows.Forms.Button
    Friend WithEvents Button_QuickAlign As System.Windows.Forms.Button
    Friend WithEvents Button_MuraCollect As System.Windows.Forms.Button
    Friend WithEvents Button_RMSSetting As System.Windows.Forms.Button
    Friend WithEvents NotifyIcon_AreaGrabber As System.Windows.Forms.NotifyIcon
    Friend WithEvents Button_BarcodeSetting As System.Windows.Forms.Button
    Friend WithEvents RadioButton_Licensed As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_IsAligned As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox_Type As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_SaveAI As System.Windows.Forms.CheckBox
    Friend WithEvents BitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BitToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BitToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents Button_ProductModelSetting As System.Windows.Forms.Button
    Friend WithEvents SplitContainer2 As System.Windows.Forms.SplitContainer
    Friend WithEvents TabControl_SystemParam As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Model As System.Windows.Forms.TabPage
    Friend WithEvents ListView_Model As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Model As System.Windows.Forms.ColumnHeader
    Friend WithEvents ContextMenuStrip_Model As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem_AddModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_RemoveModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_SetCurrentModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListView_FuncPattern As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label_FuncPatternSetting As System.Windows.Forms.Label
    Friend WithEvents Label_ProductSetting As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip_FuncPattern As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem_AddPattern As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_RemovePattern As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListView_MuraPattern As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label_MuraPatternSetting As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip_MuraPattern As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label_ImgGrayValue As System.Windows.Forms.Label
    Friend WithEvents Label_imgAnchorPosY As System.Windows.Forms.Label
    Friend WithEvents Label_imgAnchorPosX As System.Windows.Forms.Label
    Friend WithEvents TabPage_Exp As System.Windows.Forms.TabPage
    Friend WithEvents RadioButton_Mura As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Func As System.Windows.Forms.RadioButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_PatnList As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Continue As System.Windows.Forms.Button
    Friend WithEvents GroupBox_ExposureTime As System.Windows.Forms.GroupBox
    Friend WithEvents Button_SaveExpTime As System.Windows.Forms.Button
    Friend WithEvents Label_ExposureTime As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ExposureTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents TrackBar_ExposureTime As System.Windows.Forms.TrackBar
    Friend WithEvents CheckBox_ExpShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents Label_ROI_Mean As System.Windows.Forms.Label
    Friend WithEvents Button_MannualMean As System.Windows.Forms.Button
    Friend WithEvents TabPage_Align As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_MT As System.Windows.Forms.GroupBox
    Friend WithEvents Rdb_ScabType_MT As System.Windows.Forms.RadioButton
    Friend WithEvents Rdb_ScabType_Linear As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_Local As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_LocalRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LocalLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LocalTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LocalBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalTop As System.Windows.Forms.Label
    Friend WithEvents GroupBox_PanelRotate As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_PanelMirror As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_PanelRotate As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Alignment As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_EnhanceEdge As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox_RotateTheta As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Button_Alignment As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_AlignTolerance As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_RotateCal As System.Windows.Forms.CheckBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AlignmentShift As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_AlignDirectionAndOffSet As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_ShiftOffset_Top As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_ShiftOffset_Left As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Func_RightAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_TopAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_BottomAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_ShiftOffset_Bottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_ShiftOffset_Right As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Func_LeftAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_BoundaryModify As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Quick_Edge As System.Windows.Forms.Button
    Friend WithEvents RadioButton_BoundaryManual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BoundaryFinish As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_AlignShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Boundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BoundaryRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryTop As System.Windows.Forms.Label
    Friend WithEvents RadioButton_AlignType_Circle As System.Windows.Forms.RadioButton
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents RadioButton_AlignType_Rectangle As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage_FuncParam As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_MuraParam As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox_MannualFocus As System.Windows.Forms.CheckBox
    Friend WithEvents Label_FocusValue As System.Windows.Forms.Label
    Friend WithEvents Button_StopGrab As System.Windows.Forms.Button
    Friend WithEvents GroupBox_ExpSetting As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_ColorBand As System.Windows.Forms.ComboBox
    Friend WithEvents Label175 As System.Windows.Forms.Label
    Friend WithEvents TabPage_HighLevelOP As System.Windows.Forms.TabPage
    Friend WithEvents tmr As System.Windows.Forms.Timer
    Friend WithEvents Button_SaveAlignParam As System.Windows.Forms.Button
    Friend WithEvents Button_AlignTest As System.Windows.Forms.Button
    Friend WithEvents TreeView_FuncParamPattern As System.Windows.Forms.TreeView
    Friend WithEvents CheckBox_Align_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Point_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_PointCommonSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_DP_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Point_OverNum As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Point_ByPassY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Point_ByPassX As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_DPoint As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_DP_Threshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_Threshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_RimThreshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_RimThreshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_RimThreshold As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Panel_FuncParam As System.Windows.Forms.Panel
    Friend WithEvents GroupBox_DP_Characteristics As System.Windows.Forms.GroupBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_DP_MinGray_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_Compactness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_StdDev_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_MinGray_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_GrayMean_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_MaxGray_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_Fullness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_BP_Characteristics As System.Windows.Forms.GroupBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BP_MaxGray_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_StdDev_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_Compactness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_MaxGray_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_GrayMean_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_MaxGray_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_Fullness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_LinePitchSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Line_PitchY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_PitchX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LinePitchY As System.Windows.Forms.Label
    Friend WithEvents Label_LinePitchX As System.Windows.Forms.Label
    Friend WithEvents GroupBox_LineAverageFilter As System.Windows.Forms.GroupBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AverageFilter As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_Point_Algorithm As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_PointAlgorithm_3 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_PointPitchSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Point_PitchY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Point_PitchX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_PointPitchY As System.Windows.Forms.Label
    Friend WithEvents Label_PointPitchX As System.Windows.Forms.Label
    Friend WithEvents GroupBox_ImgProcBoundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Boundary_MulWidth_RX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Boundary_MulWidth_BY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Boundary_MulWidth_LX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Boundary_MulWidth_TY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label_SplitLine As System.Windows.Forms.Label
    Friend WithEvents Label_SplitPoint As System.Windows.Forms.Label
    Friend WithEvents GroupBox_DLine As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_DL_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DL_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_DL_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_DLine_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_BLine_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_BLine As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BL_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BL_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BL_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_VLine_NotAddToOutput As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_HLine_NotAddToOutput As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_LineCommonSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Line_Short_Cut_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_ShortCut_H As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_Cut_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_Cut_H As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_ByPassRightV As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_ByPassRightV As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_ByPassLeftV As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_ByPassLeftV As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Block_OverNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Block_OverNum As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Line_ByPassUpH As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_Short_Cut As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_ByPassUpH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_ByPassDownH As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_ShortCut As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_Cut As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_OverNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_OverNum As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Line_ByPassDownH As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Line_Cut As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_Line_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_GrayAbnormal_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents Button_SaveFuncParam As System.Windows.Forms.Button
    Friend WithEvents TreeView_MuraParamPattern As System.Windows.Forms.TreeView
    Friend WithEvents Button_MuraParamSave As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_DefocusCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_RemoveHVBand As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_MuraRatio As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_BlobResize As System.Windows.Forms.GroupBox
    Friend WithEvents Num_ResizeCount_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Num_ResizeCount_Mid As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_MarcoResize As System.Windows.Forms.GroupBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MacroPowerY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_MacroPowerX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Num_ResizeCount_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Num_ResizeCount_Mid2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_UseBaseLine As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_MacroMura_GlobleSmooth As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label_GlobleSmooth As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlobMura_GlobleSmooth As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_MuraPreprocess As System.Windows.Forms.Button
    Friend WithEvents CheckBox_UseReconstructBW As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_AnalysisCenterMuraEnable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_MuraCenterBlobThreshold As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_BlackBlobMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBlobMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackMacroMura_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBlobMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteMacroMura_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_ReconstructLow As System.Windows.Forms.Label
    Friend WithEvents Label_ReconstructHeight As System.Windows.Forms.Label
    Friend WithEvents Button_AnalysisMuraBlob As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Modify As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowMuraCenterByPass As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_Manual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Finish As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_MuraCenterBlobByPass As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_MuraCenterBlobByPassRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MuraCenterBlobByPassLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MuraCenterBlobByPassTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MuraCenterBlobByPassBotton As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaTop As System.Windows.Forms.Label
    Friend WithEvents CheckBox_AnalysisAroundMuraEnable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_MuraAroundThreshold As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BlackMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WhiteMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_AnalysisMuraAround As System.Windows.Forms.Button
    Friend WithEvents GroupBox_MuraAroundByPass As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowMuraAoundByPass As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_Round As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_RimRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Right As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Left As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Bottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Top As System.Windows.Forms.Label
    Friend WithEvents GroupBox_BandVOpenSearch As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BandVOpenEdgeStrength As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_EnableBandVOpen As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_BandLeakPoint As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_EnableBandLeakPoint As System.Windows.Forms.CheckBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BandLeakPointFilterRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_BandUseRemoveHV As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_BandBlockV As System.Windows.Forms.GroupBox
    Friend WithEvents ListView_VBlock As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox_BandBlockH As System.Windows.Forms.GroupBox
    Friend WithEvents ListView_HBlock As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader13 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ComboBox_MuraBandResult As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_BandBlockSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_AutoWidth As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_ShowMuraBlock As System.Windows.Forms.CheckBox
    Friend WithEvents Button_AddBlockSetting As System.Windows.Forms.Button
    Friend WithEvents ComboBox_SelectMuraBlock As System.Windows.Forms.ComboBox
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlockBlackTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlockWhiteTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlockTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlockRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlockButtom As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlockLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_AnalysisBandMuraEnable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_MuraBandResult As System.Windows.Forms.CheckBox
    Friend WithEvents Button_AnalysisMuraBand As System.Windows.Forms.Button
    Friend WithEvents GroupBox_BandResizeThreshold As System.Windows.Forms.GroupBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlackVBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackHBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BandMura_SmoothCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Band_SmoothCount As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BandMura_ResizeCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Band_ResizeCount As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WhiteHBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteVBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackBand_Thrshold As System.Windows.Forms.Label
    Friend WithEvents Label_HBand_Thrshold As System.Windows.Forms.Label
    Friend WithEvents GroupBox_BandByPass As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_ShowMuraBand As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_ShowMuraBandByPass As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_V As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_VHCount As System.Windows.Forms.TextBox
    Friend WithEvents Button_VLeftBase As System.Windows.Forms.Button
    Friend WithEvents TextBox_VVCount As System.Windows.Forms.TextBox
    Friend WithEvents Button_VRightBase As System.Windows.Forms.Button
    Friend WithEvents Button_VTopBase As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_VTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_VBottomBase As System.Windows.Forms.Button
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_VBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_H As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_HHCount As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_HVCount As System.Windows.Forms.TextBox
    Friend WithEvents Button_HLeftBase As System.Windows.Forms.Button
    Friend WithEvents Button_HTopBase As System.Windows.Forms.Button
    Friend WithEvents Button_HRightBase As System.Windows.Forms.Button
    Friend WithEvents Button_HBottomBase As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_HRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_HTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents TabPage_MuraBlobParam As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_MuraAroundParam As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_MuraBandParam As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_MuraPreprocessParam As System.Windows.Forms.TabPage
    Friend WithEvents Button_MuraBandPage As System.Windows.Forms.Button
    Friend WithEvents Button_MuraPrePrcoessPage As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button_MuraCenterPage As System.Windows.Forms.Button
    Friend WithEvents Button_MuraAroundPage As System.Windows.Forms.Button
    Friend WithEvents TabControl_MuraParam As System.Windows.Forms.TabControl
    Friend WithEvents GroupBox_RimBlobValue As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BlackRimBlobValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteRimBlobValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_BlackRimBlobValue As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_WhiteRimBlobValue As System.Windows.Forms.CheckBox
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_GrayAbnormal As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_GrayAbnormal_NegLimit As System.Windows.Forms.Label
    Friend WithEvents Lbl_GrayAbnormal_PosLimit As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormal_NegLimit As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormalStandardGray As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_GrayAbnormal_PosLimit As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_PointMode As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BPDP As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_BPoint As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BP_RimThreshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_RimThreshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_Threshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_Threshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_RimThreshold As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label

End Class
