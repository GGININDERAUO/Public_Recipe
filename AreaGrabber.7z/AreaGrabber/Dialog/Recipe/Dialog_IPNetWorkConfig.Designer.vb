﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_IPNetWorkConfig
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.GroupBox_IPNetWork_Setting = New System.Windows.Forms.GroupBox()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.DataGridView_IPNetWorkConfig = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.IP_Address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IP_Port1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.IP_Port2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MAC_Address = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NUD_Total_IP = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox_IPStart_Port = New System.Windows.Forms.TextBox()
        Me.GroupBox_DefectUpdate = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button_FtpRootPath = New System.Windows.Forms.Button()
        Me.TextBox_FtpRootPath = New System.Windows.Forms.TextBox()
        Me.CheckBox_DefectUpdateToFtp = New System.Windows.Forms.CheckBox()
        Me.FolderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition = New System.Windows.Forms.CheckBox()
        Me.CheckBox_All_In_One = New System.Windows.Forms.CheckBox()
        Me.CheckBox_9in3 = New System.Windows.Forms.CheckBox()
        Me.GroupBox_IPNetWork_Setting.SuspendLayout()
        CType(Me.DataGridView_IPNetWorkConfig, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_Total_IP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_DefectUpdate.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button_Save
        '
        Me.Button_Save.Location = New System.Drawing.Point(14, 28)
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.Size = New System.Drawing.Size(83, 29)
        Me.Button_Save.TabIndex = 32
        Me.Button_Save.Text = "Save"
        Me.Button_Save.UseVisualStyleBackColor = True
        '
        'GroupBox_IPNetWork_Setting
        '
        Me.GroupBox_IPNetWork_Setting.Controls.Add(Me.Button_Cancel)
        Me.GroupBox_IPNetWork_Setting.Controls.Add(Me.Button_Save)
        Me.GroupBox_IPNetWork_Setting.Location = New System.Drawing.Point(355, 308)
        Me.GroupBox_IPNetWork_Setting.Name = "GroupBox_IPNetWork_Setting"
        Me.GroupBox_IPNetWork_Setting.Size = New System.Drawing.Size(210, 71)
        Me.GroupBox_IPNetWork_Setting.TabIndex = 34
        Me.GroupBox_IPNetWork_Setting.TabStop = False
        Me.GroupBox_IPNetWork_Setting.Text = "Setting"
        '
        'Button_Cancel
        '
        Me.Button_Cancel.Location = New System.Drawing.Point(113, 28)
        Me.Button_Cancel.Name = "Button_Cancel"
        Me.Button_Cancel.Size = New System.Drawing.Size(83, 29)
        Me.Button_Cancel.TabIndex = 34
        Me.Button_Cancel.Text = "Close"
        Me.Button_Cancel.UseVisualStyleBackColor = True
        '
        'DataGridView_IPNetWorkConfig
        '
        Me.DataGridView_IPNetWorkConfig.AccessibleDescription = ""
        Me.DataGridView_IPNetWorkConfig.AccessibleName = ""
        Me.DataGridView_IPNetWorkConfig.AllowUserToAddRows = False
        Me.DataGridView_IPNetWorkConfig.AllowUserToDeleteRows = False
        Me.DataGridView_IPNetWorkConfig.AllowUserToResizeColumns = False
        Me.DataGridView_IPNetWorkConfig.AllowUserToResizeRows = False
        Me.DataGridView_IPNetWorkConfig.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_IPNetWorkConfig.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.IP_Address, Me.IP_Port1, Me.IP_Port2, Me.MAC_Address})
        Me.DataGridView_IPNetWorkConfig.Location = New System.Drawing.Point(12, 42)
        Me.DataGridView_IPNetWorkConfig.Name = "DataGridView_IPNetWorkConfig"
        Me.DataGridView_IPNetWorkConfig.RowHeadersWidth = 120
        Me.DataGridView_IPNetWorkConfig.RowTemplate.Height = 24
        Me.DataGridView_IPNetWorkConfig.Size = New System.Drawing.Size(553, 260)
        Me.DataGridView_IPNetWorkConfig.TabIndex = 36
        '
        'Column1
        '
        Me.Column1.HeaderText = "Enabled"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 50
        '
        'IP_Address
        '
        Me.IP_Address.HeaderText = "IP Address"
        Me.IP_Address.Name = "IP_Address"
        '
        'IP_Port1
        '
        Me.IP_Port1.HeaderText = "Port1"
        Me.IP_Port1.Name = "IP_Port1"
        Me.IP_Port1.Width = 50
        '
        'IP_Port2
        '
        Me.IP_Port2.HeaderText = "Port2"
        Me.IP_Port2.Name = "IP_Port2"
        Me.IP_Port2.Width = 50
        '
        'MAC_Address
        '
        Me.MAC_Address.HeaderText = "MAC Address"
        Me.MAC_Address.Name = "MAC_Address"
        Me.MAC_Address.Width = 180
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 12)
        Me.Label1.TabIndex = 37
        Me.Label1.Text = "Total IP : "
        '
        'NUD_Total_IP
        '
        Me.NUD_Total_IP.Location = New System.Drawing.Point(69, 12)
        Me.NUD_Total_IP.Name = "NUD_Total_IP"
        Me.NUD_Total_IP.Size = New System.Drawing.Size(71, 22)
        Me.NUD_Total_IP.TabIndex = 38
        Me.NUD_Total_IP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(306, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 12)
        Me.Label2.TabIndex = 39
        Me.Label2.Text = "IP Starter Port : "
        '
        'TextBox_IPStart_Port
        '
        Me.TextBox_IPStart_Port.Location = New System.Drawing.Point(382, 11)
        Me.TextBox_IPStart_Port.Name = "TextBox_IPStart_Port"
        Me.TextBox_IPStart_Port.Size = New System.Drawing.Size(64, 22)
        Me.TextBox_IPStart_Port.TabIndex = 40
        Me.TextBox_IPStart_Port.Text = "0"
        Me.TextBox_IPStart_Port.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_DefectUpdate
        '
        Me.GroupBox_DefectUpdate.Controls.Add(Me.Label3)
        Me.GroupBox_DefectUpdate.Controls.Add(Me.Button_FtpRootPath)
        Me.GroupBox_DefectUpdate.Controls.Add(Me.TextBox_FtpRootPath)
        Me.GroupBox_DefectUpdate.Controls.Add(Me.CheckBox_DefectUpdateToFtp)
        Me.GroupBox_DefectUpdate.Location = New System.Drawing.Point(12, 308)
        Me.GroupBox_DefectUpdate.Name = "GroupBox_DefectUpdate"
        Me.GroupBox_DefectUpdate.Size = New System.Drawing.Size(324, 71)
        Me.GroupBox_DefectUpdate.TabIndex = 41
        Me.GroupBox_DefectUpdate.TabStop = False
        Me.GroupBox_DefectUpdate.Text = "Defect Update"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(8, 46)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 12)
        Me.Label3.TabIndex = 86
        Me.Label3.Text = "Ftp Root Path : "
        '
        'Button_FtpRootPath
        '
        Me.Button_FtpRootPath.Location = New System.Drawing.Point(287, 38)
        Me.Button_FtpRootPath.Name = "Button_FtpRootPath"
        Me.Button_FtpRootPath.Size = New System.Drawing.Size(28, 23)
        Me.Button_FtpRootPath.TabIndex = 85
        Me.Button_FtpRootPath.Text = "..."
        '
        'TextBox_FtpRootPath
        '
        Me.TextBox_FtpRootPath.Enabled = False
        Me.TextBox_FtpRootPath.Location = New System.Drawing.Point(91, 40)
        Me.TextBox_FtpRootPath.Name = "TextBox_FtpRootPath"
        Me.TextBox_FtpRootPath.Size = New System.Drawing.Size(190, 22)
        Me.TextBox_FtpRootPath.TabIndex = 84
        '
        'CheckBox_DefectUpdateToFtp
        '
        Me.CheckBox_DefectUpdateToFtp.AutoSize = True
        Me.CheckBox_DefectUpdateToFtp.Location = New System.Drawing.Point(10, 18)
        Me.CheckBox_DefectUpdateToFtp.Name = "CheckBox_DefectUpdateToFtp"
        Me.CheckBox_DefectUpdateToFtp.Size = New System.Drawing.Size(128, 16)
        Me.CheckBox_DefectUpdateToFtp.TabIndex = 29
        Me.CheckBox_DefectUpdateToFtp.Text = "Defects Update To Ftp"
        Me.CheckBox_DefectUpdateToFtp.UseVisualStyleBackColor = True
        '
        'CheckBox_Export_Grabber_Output_with_OTHER_Condition
        '
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.AutoSize = True
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.Location = New System.Drawing.Point(22, 385)
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.Name = "CheckBox_Export_Grabber_Output_with_OTHER_Condition"
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.Size = New System.Drawing.Size(241, 16)
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.TabIndex = 42
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.Text = "Export Grabber output with OTHER condition"
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.UseVisualStyleBackColor = True
        '
        'CheckBox_All_In_One
        '
        Me.CheckBox_All_In_One.AutoSize = True
        Me.CheckBox_All_In_One.Location = New System.Drawing.Point(287, 385)
        Me.CheckBox_All_In_One.Name = "CheckBox_All_In_One"
        Me.CheckBox_All_In_One.Size = New System.Drawing.Size(195, 16)
        Me.CheckBox_All_In_One.TabIndex = 43
        Me.CheckBox_All_In_One.Text = "All IP In One PC(TaskManger Used)"
        Me.CheckBox_All_In_One.UseVisualStyleBackColor = True
        '
        'CheckBox_9in3
        '
        Me.CheckBox_9in3.AutoSize = True
        Me.CheckBox_9in3.Location = New System.Drawing.Point(502, 385)
        Me.CheckBox_9in3.Name = "CheckBox_9in3"
        Me.CheckBox_9in3.Size = New System.Drawing.Size(51, 16)
        Me.CheckBox_9in3.TabIndex = 44
        Me.CheckBox_9in3.Text = "9 in 3"
        Me.CheckBox_9in3.UseVisualStyleBackColor = True
        '
        'Dialog_IPNetWorkConfig
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(572, 412)
        Me.Controls.Add(Me.CheckBox_9in3)
        Me.Controls.Add(Me.CheckBox_All_In_One)
        Me.Controls.Add(Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition)
        Me.Controls.Add(Me.GroupBox_DefectUpdate)
        Me.Controls.Add(Me.TextBox_IPStart_Port)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NUD_Total_IP)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DataGridView_IPNetWorkConfig)
        Me.Controls.Add(Me.GroupBox_IPNetWork_Setting)
        Me.Name = "Dialog_IPNetWorkConfig"
        Me.Text = "IPNetWorkConfig"
        Me.GroupBox_IPNetWork_Setting.ResumeLayout(False)
        CType(Me.DataGridView_IPNetWorkConfig, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_Total_IP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_DefectUpdate.ResumeLayout(False)
        Me.GroupBox_DefectUpdate.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents GroupBox_IPNetWork_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents DataGridView_IPNetWorkConfig As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NUD_Total_IP As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox_IPStart_Port As System.Windows.Forms.TextBox
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents IP_Address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IP_Port1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents IP_Port2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents MAC_Address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GroupBox_DefectUpdate As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_DefectUpdateToFtp As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Button_FtpRootPath As System.Windows.Forms.Button
    Friend WithEvents TextBox_FtpRootPath As System.Windows.Forms.TextBox
    Friend WithEvents FolderBrowserDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents CheckBox_Export_Grabber_Output_with_OTHER_Condition As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_All_In_One As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_9in3 As System.Windows.Forms.CheckBox
End Class
