Imports ClassLibrary
Imports AUO.SubSystemControl
Imports System.Windows.Forms
Imports MILOperationLib
Imports System.IO
Imports System.Globalization
Imports System.Threading

Public Class Dialog_IPBootConfig
    Private m_MainProcess As ClsMainProcess
    Private m_Form As Main_Form

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    Private res As System.Resources.ResourceManager '�YԴ�n����T

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Try
            '--- Change Language ---
            res = New Resources.ResourceManager("AreaGrabber.Dialog_IPBootConfig", Me.GetType().Assembly)
            Thread.CurrentThread.CurrentCulture = New CultureInfo("zh-CN")
            Thread.CurrentThread.CurrentUICulture = New CultureInfo("zh-CN")
            Me.changeLanguage("zh-CN")
            '------------

            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess

            Me.UpdateData()
            Me.Update()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_IPBootConfig.SetMainForm]" & ex.Message)
        End Try
    End Sub

    Private Sub Dialog_IPBootConfig_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.m_Form.Focus()
        Me.Finalize()
    End Sub

#Region "--- ��k�禡 ---"

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- UpdateData ---"
    Private Sub UpdateData()
        Dim abc As ClsAreaBootConfig
        Dim ipbc As ClsIPBootConfig
        Dim ipnc As ClsIPNetWorkConfig

        Try
            abc = Me.m_MainProcess.AreaBootConfig
            ipbc = Me.m_MainProcess.IPBootConfig
            ipnc = Me.m_MainProcess.IPNetworkConfig

            '--- Card Setting ---
            Me.TextBox_CardSystem.Text = ipbc.CardSystem.Value
            Me.TextBox_CardSystemDeviceNumber.Text = ipbc.CardSystemDeviceNumber.Value
            Me.TextBox_GPUDeviceNumber.Text = ipbc.GPUDeviceNumber.Value

            '--- Digitizer Setting ---
            Me.TextBox_DigitizerFormat.Text = ipbc.DigitizerFormat.Value
            Me.TextBox_DigitizerFormatForTrigger.Text = ipbc.DigitizerFormatForTrigger.Value
            Me.TextBox_DigitizerDeviceNumber.Text = ipbc.DigitizerDeviceNumber.Value
            Me.TextBox_Digitizer_Datadepth.Text = ipbc.Digitizer_Datadepth.Value
            Me.TextBox_ImageSizeX.Text = ipbc.ImageSizeX.Value
            Me.TextBox_ImageSizeY.Text = ipbc.ImageSizeY.Value

            '--- Digitizer Type ---
            If ipbc.Digitizer_Type.Value = DigitizerType.Mono Then
                Me.RadioButton_DigitizerType_Mono.Checked = True
            ElseIf ipbc.Digitizer_Type.Value = DigitizerType.Color Then
                Me.RadioButton_DigitizerType_Color.Checked = True
                Me.CheckBox_EnablePCA.Checked = ipbc.EnablePCA.Value
            End If

            If ipbc.IsPacked.Value Then
                Me.CheckBox_IsPacked.Checked = True
            End If

            '--- Bayer Pattern ---
            If ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Blue_Green Then
                Me.RadioButton_BayerPattern_Blue_Green.Checked = True
            ElseIf ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Green_Blue Then
                Me.RadioButton_BayerPattern_Green_Blue.Checked = True
            ElseIf ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Green_Red Then
                Me.RadioButton_BayerPattern_Green_Red.Checked = True
            ElseIf ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Red_Green Then
                Me.RadioButton_BayerPattern_Red_Green.Checked = True
            End If

            '---IP Setting ---
            Me.TextBox_CCDNo.Text = ipbc.CCD.Value
            Me.TextBox_GrabNo.Text = ipbc.GrabNo.Value
            Me.ComboBox_Authority.Text = ipbc.AUTH.Value
            Me.CheckBox_ShowOGDImg.Checked = ipbc.ShowOGDImg.Value
            Me.NumericUpDown_InitialDelayTime.Value = ipbc.InitialDelayTime.Value

            '---RecipePath Setting ---
            Me.TextBox_RecipePath.Text = ipbc.RecipePath.Value
            Me.TextBox_DataRootPath.Text = ipbc.DataRootPath.Value
            Me.TextBox_RamDiskPath.Text = ipbc.RamDiskPath.Value
            Me.TextBox_CharacteristicPath.Text = ipbc.CharacteristicPath.Value

            '---Function Enable Setting ---
            '---Log ---
            Me.CheckBox_SubSystem_Log.Checked = ipbc.SubSystem_Log_Enable.Value
            Me.CheckBox_WriteToLog1.Checked = ipbc.WriteToLog1_Enable.Value
            Me.CheckBox_WriteToLog2.Checked = ipbc.WriteToLog2_Enable.Value
            Me.CheckBox_TimeLog.Checked = ipbc.TimeLog_Enable.Value
            Me.CheckBox_HVValueLog.Checked = ipbc.HVValueLog_Enable.Value

            '---Func Selection ---
            Me.CheckBox_FuncUI.Checked = ipbc.FuncUI.Value
            Me.CheckBox_MuraUI.Checked = ipbc.MuraUI.Value
            Me.CheckBox_PLMarkUI.Checked = ipbc.PLMarkUI.Value
            Me.CheckBox_MaskMarkUI.Checked = ipbc.MaskMarkUI.Value
            Me.CheckBox_TPMarkUI.Checked = ipbc.TPMarkUI.Value
            Me.CheckBox_BarcodeUI.Checked = ipbc.BarcodeUI.Value

            '---MappingTable Setting ---
            Me.ComboBox_PanelTransfer.Text = ipbc.Panel_TransferMode.Value

            '---Panel Rotate 90 degree---   
            Me.CheckBox_PanelRotate90.Checked = ipbc.PanelRotate90.Value

            '---Set RAMRush per Count ---   
            Me.NumericUpDown_SetRAMRush_PerCount.Value = ipbc.SetRAMRush_PerCount.Value
            Me.CheckBox_SaveToRam.Checked = ipbc.SaveToRam.Value
            Me.CheckBox_LocalGrab.Checked = ipbc.LocalGrab.Value

            '---Max Defect Setting ---
            Me.TextBox_FuncDefects_Max.Text = ipbc.FuncDefects_Max.Value
            Me.TextBox_MuraDefects_Max.Text = ipbc.MuraDefects_Max.Value

            '---Image Path Setting ---
            Me.TextBox_DefectPath.Text = ipbc.DefectPath.Value
            Me.TextBox_ImagePath.Text = ipbc.ImagePath.Value
            Me.TextBox_ImagePath2.Text = ipbc.ImagePath2.Value
            Me.TextBox_ResizeBMPPath.Text = ipbc.ResizeBMPPath.Value
            Me.NumericUpDown_ResizeBMPCount.Value = ipbc.ResizeBMPCount.Value

            '---Auto Delete File ---
            Me.CheckBox_AutoDeleteFile.Checked = ipbc.AutoDeleteFile.Value

            '---Save Defect Image ---
            Me.CheckBox_Save_Func_DefectImage.Checked = ipbc.Save_Func_DefectImage.Value
            Me.CheckBox_Save_Mura_DefectImage.Checked = ipbc.Save_Mura_DefectImage.Value

            '--- BlobAnalysis Method ---
            If ipbc.BlobAnalysis_Method.Value = "MIL" Then
                Me.RadioButton_BlobAnalysis_MIL.Checked = True
            Else
                Me.RadioButton_BlobAnalysis_CUDA.Checked = True
            End If

            '--- ExposureTime ---
            Me.TextBox_Max_ExposureTime.Text = ipbc.Max_ExposureTime.Value

            '---Defect Enhance---
            Me.NumericUpDown_Enlarge.Value = ipbc.Enlarge.Value
            Me.NumericUpDown_Enhance.Value = ipbc.Enhance.Value

            '---DetailOutput---
            Me.CheckBox_DetailOutput.Checked = ipbc.DetailOutput.Value

            '--- Master\Slave Mode ---
            Me.CheckBox_MasterSlaveMode_Enable.Checked = ipbc.MasterSlaveMode_Enable.Value

            If ipbc.MasterSlaveMode_Enable.Value = True Then
                If ipbc.MasterSlaveMode.Value = MasterSlaveMode.Master Then
                    Me.RadioButton_MasterMode.Checked = True
                ElseIf ipbc.MasterSlaveMode.Value = MasterSlaveMode.Slave Then
                    Me.RadioButton_SlaveMode.Checked = True
                End If
            Else
                Me.RadioButton_MasterMode.Enabled = False
                Me.RadioButton_SlaveMode.Enabled = False
            End If

            '--- CCD Link Type ---
            If ipbc.CCD_Link_Type.Value = CCD_LinkType.CameraLink Then
                Me.RadioButton_CCD_Link_CameraLink.Checked = True
            ElseIf ipbc.CCD_Link_Type.Value = CCD_LinkType.GigE Then
                Me.RadioButton_CCD_Link_GigE.Checked = True
            ElseIf ipbc.CCD_Link_Type.Value = CCD_LinkType.CXP Then
                Me.RadioButton_CCD_Link_CXP.Checked = True
            End If

            Me.TextBox_GigE_SerialNum.Text = ipbc.GigE_SerialNum.Value

            '--- Grid Calibration ---
            Me.CheckBox_Grid_Calibration_Enable.Checked = ipbc.Grid_Calibration_Enable.Value

            '--- UI- Hide To Icon ---
            Me.CheckBox_AreaGrabber_Hide_To_Icon.Checked = abc.UI_AreaGrabber_HideToIcon_Enable.Value
            Me.CheckBox_IP_Hide_To_Icon.Checked = ipbc.UI_IP_HideToIcon_Enable.Value

            '---PixelShiftCCD Setting---
            Me.CheckBox_ShiftCCD_IsShiftCCD.Checked = ipbc.IsPixelShiftCCD.Value
            Me.ComboBox_ShiftCCD_Stage.SelectedIndex = CInt(ipbc.PixelShiftStage.Value)
            Me.TextBox_ShiftCCD_ComPort.Text = ipbc.PixelShiftComPort.Value.Substring(3)

            '---Trigger Setting---
            If ipbc.IsTrigger.Value Then
                Me.ComboBox_TriggerMode.SelectedIndex = 1
            Else
                Me.ComboBox_TriggerMode.SelectedIndex = 0
            End If
            Me.CheckBox_WaitGrabEnd.Checked = ipbc.WaitGrabEnd.Value

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_IPBootConfig.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_IPBootConfig.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim abc As ClsAreaBootConfig
        Dim ipbc As ClsIPBootConfig
        Dim ipnc As ClsIPNetWorkConfig
        Dim CCDNo As Integer = 0
        Dim GrabNo As String = ""

        Try
            abc = Me.m_MainProcess.AreaBootConfig
            ipbc = Me.m_MainProcess.IPBootConfig
            ipnc = Me.m_MainProcess.IPNetworkConfig

            '---Card Setting ---
            ipbc.CardSystem.Value = Me.TextBox_CardSystem.Text
            ipbc.CardSystemDeviceNumber.Value = Me.TextBox_CardSystemDeviceNumber.Text
            ipbc.GPUDeviceNumber.Value = CInt(Me.TextBox_GPUDeviceNumber.Text)

            '---Digitizer Setting ---
            ipbc.DigitizerFormat.Value = Me.TextBox_DigitizerFormat.Text
            ipbc.DigitizerFormatForTrigger.Value = Me.TextBox_DigitizerFormatForTrigger.Text
            ipbc.DigitizerDeviceNumber.Value = CInt(Me.TextBox_DigitizerDeviceNumber.Text)
            ipbc.Digitizer_Datadepth.Value = CInt(Me.TextBox_Digitizer_Datadepth.Text)
            ipbc.ImageSizeX.Value = CInt(Me.TextBox_ImageSizeX.Text)
            ipbc.ImageSizeY.Value = CInt(Me.TextBox_ImageSizeY.Text)

            '--- Digitizer Type ---
            If Me.RadioButton_DigitizerType_Mono.Checked Then
                ipbc.Digitizer_Type.Value = DigitizerType.Mono
            ElseIf Me.RadioButton_DigitizerType_Color.Checked Then
                ipbc.Digitizer_Type.Value = DigitizerType.Color
                ipbc.EnablePCA.Value = Me.CheckBox_EnablePCA.Checked
            End If

            If Me.CheckBox_IsPacked.Checked Then
                ipbc.IsPacked.Value = True
            Else
                ipbc.IsPacked.Value = False
            End If

            '--- Bayer Pattern ---
            If Me.RadioButton_BayerPattern_Blue_Green.Checked Then
                ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Blue_Green
            ElseIf Me.RadioButton_BayerPattern_Green_Blue.Checked Then
                ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Green_Blue
            ElseIf Me.RadioButton_BayerPattern_Green_Red.Checked Then
                ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Green_Red
            ElseIf Me.RadioButton_BayerPattern_Red_Green.Checked Then
                ipbc.ColorDigitizer_BayerPattern.Value = BayerPattern.Red_Green
            End If

            '---IP Setting ---
            ipbc.CCD.Value = CInt(Me.TextBox_CCDNo.Text)
            ipbc.GrabNo.Value = Me.TextBox_GrabNo.Text
            ipbc.AUTH.Value = CInt(Me.ComboBox_Authority.Text)
            ipbc.ShowOGDImg.Value = CheckBox_ShowOGDImg.Checked
            ipbc.InitialDelayTime.Value = NumericUpDown_InitialDelayTime.Value

            '---RecipePath Setting ---
            ipbc.RecipePath.Value = Me.TextBox_RecipePath.Text
            ipbc.DataRootPath.Value = Me.TextBox_DataRootPath.Text
            ipbc.RamDiskPath.Value = Me.TextBox_RamDiskPath.Text
            ipbc.CharacteristicPath.Value = Me.TextBox_CharacteristicPath.Text

            '---Function Enable Setting ---
            '---Log ---
            ipbc.SubSystem_Log_Enable.Value = Me.CheckBox_SubSystem_Log.Checked
            ipbc.WriteToLog1_Enable.Value = Me.CheckBox_WriteToLog1.Checked
            ipbc.WriteToLog2_Enable.Value = Me.CheckBox_WriteToLog2.Checked
            ipbc.TimeLog_Enable.Value = Me.CheckBox_TimeLog.Checked
            ipbc.HVValueLog_Enable.Value = Me.CheckBox_HVValueLog.Checked

            '---Func Selection ---
            ipbc.FuncUI.Value = Me.CheckBox_FuncUI.Checked
            ipbc.MuraUI.Value = Me.CheckBox_MuraUI.Checked
            ipbc.PLMarkUI.Value = Me.CheckBox_PLMarkUI.Checked
            ipbc.MaskMarkUI.Value = Me.CheckBox_MaskMarkUI.Checked
            ipbc.TPMarkUI.Value = Me.CheckBox_TPMarkUI.Checked
            ipbc.BarcodeUI.Value = Me.CheckBox_BarcodeUI.Checked

            '---MappingTable Setting ---
            ipbc.Panel_TransferMode.Value = Me.ComboBox_PanelTransfer.Text

            '---Panel Rotate 90 degree---  
            ipbc.PanelRotate90.Value = Me.CheckBox_PanelRotate90.Checked

            '---Set RAMRush per Count ---   
            ipbc.SetRAMRush_PerCount.Value = Me.NumericUpDown_SetRAMRush_PerCount.Value
            ipbc.SaveToRam.Value = Me.CheckBox_SaveToRam.Checked
            ipbc.LocalGrab.Value = Me.CheckBox_LocalGrab.Checked

            '---Max Defect Setting ---   
            ipbc.FuncDefects_Max.Value = CInt(Me.TextBox_FuncDefects_Max.Text)
            ipbc.MuraDefects_Max.Value = CInt(Me.TextBox_MuraDefects_Max.Text)

            '---Image Path Setting ---
            ipbc.DefectPath.Value = Me.TextBox_DefectPath.Text
            ipbc.ImagePath.Value = Me.TextBox_ImagePath.Text
            ipbc.ImagePath2.Value = Me.TextBox_ImagePath2.Text
            ipbc.ResizeBMPPath.Value = Me.TextBox_ResizeBMPPath.Text
            ipbc.ResizeBMPCount.Value = Me.NumericUpDown_ResizeBMPCount.Value

            '---Auto Delete File ---
            ipbc.AutoDeleteFile.Value = Me.CheckBox_AutoDeleteFile.Checked

            '---Save Defect Image ---
            ipbc.Save_Func_DefectImage.Value = Me.CheckBox_Save_Func_DefectImage.Checked
            ipbc.Save_Mura_DefectImage.Value = Me.CheckBox_Save_Mura_DefectImage.Checked

            '--- BlobAnalysis Method ---
            If Me.RadioButton_BlobAnalysis_MIL.Checked = True Then
                ipbc.BlobAnalysis_Method.Value = "MIL"
            Else
                ipbc.BlobAnalysis_Method.Value = "CUDA"
            End If

            '--- ExposureTime ---
            ipbc.Max_ExposureTime.Value = Me.TextBox_Max_ExposureTime.Text

            '---Defect Enhance---
            ipbc.Enlarge.Value = Me.NumericUpDown_Enlarge.Value
            ipbc.Enhance.Value = Me.NumericUpDown_Enhance.Value

            '---DetailOutput---
            ipbc.DetailOutput.Value = Me.CheckBox_DetailOutput.Checked

            '--- Master\Slave Mode ---
            ipbc.MasterSlaveMode_Enable.Value = Me.CheckBox_MasterSlaveMode_Enable.Checked

            If Me.RadioButton_MasterMode.Checked Then
                ipbc.MasterSlaveMode.Value = MasterSlaveMode.Master
            ElseIf Me.RadioButton_SlaveMode.Checked Then
                ipbc.MasterSlaveMode.Value = MasterSlaveMode.Slave
            End If

            '--- CCD Link Type ---
            If Me.RadioButton_CCD_Link_CameraLink.Checked Then
                ipbc.CCD_Link_Type.Value = CCD_LinkType.CameraLink
            ElseIf Me.RadioButton_CCD_Link_GigE.Checked Then
                ipbc.CCD_Link_Type.Value = CCD_LinkType.GigE
            ElseIf Me.RadioButton_CCD_Link_CXP.Checked Then
                ipbc.CCD_Link_Type.Value = CCD_LinkType.CXP
            End If

            ipbc.GigE_SerialNum.Value = Me.TextBox_GigE_SerialNum.Text

            '--- Grid Calibration ---
            ipbc.Grid_Calibration_Enable.Value = Me.CheckBox_Grid_Calibration_Enable.Checked

            '--- UI- Hide To Icon ---
            abc.UI_AreaGrabber_HideToIcon_Enable.Value = Me.CheckBox_AreaGrabber_Hide_To_Icon.Checked
            ipbc.UI_IP_HideToIcon_Enable.Value = Me.CheckBox_IP_Hide_To_Icon.Checked

            '---PixelShift CCD Setting---
            ipbc.IsPixelShiftCCD.Value = Me.CheckBox_ShiftCCD_IsShiftCCD.Checked
            ipbc.PixelShiftStage.Value = Me.ComboBox_ShiftCCD_Stage.SelectedIndex
            ipbc.PixelShiftComPort.Value = "COM" & Me.TextBox_ShiftCCD_ComPort.Text

            '---Trigger Setting---
            If Me.ComboBox_TriggerMode.SelectedIndex = 0 Then
                ipbc.IsTrigger.Value = "false"
            Else
                ipbc.IsTrigger.Value = "true"
            End If
            ipbc.WaitGrabEnd.Value = Me.CheckBox_WaitGrabEnd.Checked

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_IPBootConfig.Setting]" & ex.Message)
            MessageBox.Show("[Dialog_IPBootConfig.Setting]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_Save.Enabled = En
        Me.Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                GroupBox_CardSetting.Enabled = False
                GroupBox_DigitizerSetting.Enabled = False
                GroupBox_FunctionEnable.Enabled = False
                GroupBox_IPSetting.Enabled = False
                GroupBox_RecipePath_Setting.Enabled = False
                GroupBox_PanelTransferSetting.Enabled = False
            Case 1 'PM
                GroupBox_CardSetting.Enabled = True
                GroupBox_DigitizerSetting.Enabled = True
                GroupBox_FunctionEnable.Enabled = True
                GroupBox_IPSetting.Enabled = True
                GroupBox_RecipePath_Setting.Enabled = True
                GroupBox_PanelTransferSetting.Enabled = True
            Case 2 'ENG
                GroupBox_CardSetting.Enabled = True
                GroupBox_DigitizerSetting.Enabled = True
                GroupBox_FunctionEnable.Enabled = True
                GroupBox_IPSetting.Enabled = True
                GroupBox_RecipePath_Setting.Enabled = True
                GroupBox_PanelTransferSetting.Enabled = True
            Case 3 'ALL
                GroupBox_CardSetting.Enabled = True
                GroupBox_DigitizerSetting.Enabled = True
                GroupBox_FunctionEnable.Enabled = True
                GroupBox_IPSetting.Enabled = True
                GroupBox_RecipePath_Setting.Enabled = True
                GroupBox_PanelTransferSetting.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Me.SavePath ---"
    Private Function SavePath(ByRef strPath As String)

        strPath = Replace(strPath, "\", "\\")
        If (strPath.Contains("\\\\")) Then
            strPath = Replace(strPath, "\\\\", "\\")
        End If
        Return strPath
    End Function
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim Parameter_Lists As String = ""
        Dim ipbc As ClsIPBootConfig
        Dim ipnc As ClsIPNetWorkConfig
        Dim MasterSlaveMode As Integer = 0

        Try
            '---Button Control ---   
            Button_Enable(False)

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_Form.PaintStop = True

            If MsgBox("�O�_�x�sRecipe�ѼơH", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                ipbc = Me.m_MainProcess.IPBootConfig
                ipnc = Me.m_MainProcess.IPNetworkConfig
                Me.Setting()
                Me.m_MainProcess.SaveBoot()
                Me.m_MainProcess.SaveAreaBoot()

                '----------------------------------------------------------------------------------------------
                ' Dialog_IPBootConfig Setting   ==> Request_Command = "DIALOG_IPBOOTCONFIG_SETTING" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "DIALOG_IPBOOTCONFIG_SETTING"
                    TimeOut = 10000 '10 secs

                    'UI Recipe Setting -----------------------------------

                    '--- �Ĥ@�� ---
                    '---Card Setting ---
                    Parameter_Lists = "CardSystem," & ipbc.CardSystem.Value & ";" & "CardSystemDeviceNumber," & ipbc.CardSystemDeviceNumber.Value & ";" & "GPUDeviceNumber," & ipbc.GPUDeviceNumber.Value & ";"
                    '---Digitizer Setting ---
                    Parameter_Lists = Parameter_Lists & "DigitizerFormat," & ipbc.DigitizerFormat.Value & ";" & "DigitizerFormatForTrigger," & ipbc.DigitizerFormatForTrigger.Value & ";" & "DigitizerDeviceNumber," & ipbc.DigitizerDeviceNumber.Value & ";" & _
                                                        "Digitizer_Datadepth," & ipbc.Digitizer_Datadepth.Value & ";" & "ImageSizeX," & ipbc.ImageSizeX.Value & ";" & "ImageSizeY," & ipbc.ImageSizeY.Value & ";"
                    '---CCD Link Type ---
                    Parameter_Lists = Parameter_Lists & "Digitizer_Type," & ipbc.Digitizer_Type.Value & ";"
                    '---ColorDigitizer Bayer Pattern ---
                    Parameter_Lists = Parameter_Lists & "ColorDigitizer_BayerPattern," & ipbc.ColorDigitizer_BayerPattern.Value & ";" & "IsPacked," & ipbc.IsPacked.Value & ";" & "EnablePCA," & ipbc.EnablePCA.Value & ";"
                    '---IP Setting ---
                    Parameter_Lists = Parameter_Lists & "CCD," & ipbc.CCD.Value & ";" & "GrabNo," & ipbc.GrabNo.Value & ";" & "AUTH," & ipbc.AUTH.Value & ";" & "ShowOGDImg," & ipbc.ShowOGDImg.Value & ";" & "InitialDelayTime," & ipbc.InitialDelayTime.Value & ";"
                    '---RecipePath Setting ---
                    Parameter_Lists = Parameter_Lists & "RecipePath," & ipbc.RecipePath.Value & ";" & "DataRootPath," & ipbc.DataRootPath.Value & ";" & "RamDiskPath," & ipbc.RamDiskPath.Value & ";" & "CharacteristicPath," & ipbc.CharacteristicPath.Value & ";"
                    '---Function Enable Setting ---
                    Parameter_Lists = Parameter_Lists & "SubSystem_Log_Enable," & ipbc.SubSystem_Log_Enable.Value & ";" & "WriteToLog1_Enable," & Me.CheckBox_WriteToLog1.Checked & ";" & "WriteToLog2_Enable," & Me.CheckBox_WriteToLog1.Checked & ";" & "TimeLog_Enable," & ipbc.TimeLog_Enable.Value & ";" & "HVValueLog_Enable," & ipbc.HVValueLog_Enable.Value & ";"
                    '---Func Selection ---
                    Parameter_Lists = Parameter_Lists & "FuncUI," & ipbc.FuncUI.Value & ";" & "MuraUI," & ipbc.MuraUI.Value & ";" & "PLMarkUI," & ipbc.PLMarkUI.Value & ";" & "MaskMarkUI," & ipbc.MaskMarkUI.Value & ";" & "TPMarkUI," & ipbc.TPMarkUI.Value & ";" & "BarcodeUI," & ipbc.BarcodeUI.Value & ";"
                    '---MappingTable Setting ---
                    Parameter_Lists = Parameter_Lists & "Panel_TransferMode," & ipbc.Panel_TransferMode.Value & ";"
                    '---Panel Rotate 90 Setting ---
                    Parameter_Lists = Parameter_Lists & "PanelRotate90," & Me.CheckBox_PanelRotate90.Checked & ";"
                    '---Set RAMRush PerCount Setting & Save To RamDisk---
                    Parameter_Lists = Parameter_Lists & "SetRAMRush_PerCount," & Me.NumericUpDown_SetRAMRush_PerCount.Value & ";" & "SaveToRam," & Me.CheckBox_SaveToRam.Checked & ";" & "LocalGrab," & Me.CheckBox_LocalGrab.Checked & ";"
                    '---DefectNum Setting ---
                    Parameter_Lists = Parameter_Lists & "FuncDefects_Max," & Me.TextBox_FuncDefects_Max.Text & ";" & "MuraDefects_Max," & Me.TextBox_MuraDefects_Max.Text & ";"
                    '---Image Path Setting ---
                    Parameter_Lists = Parameter_Lists & "DefectPath," & Me.TextBox_DefectPath.Text & ";" & "ImagePath," & Me.TextBox_ImagePath.Text & ";" & "ImagePath2," & Me.TextBox_ImagePath2.Text & ";" & "ResizeBMPPath," & Me.TextBox_ResizeBMPPath.Text & ";" & "ResizeBMPCount," & Me.NumericUpDown_ResizeBMPCount.Value & ";"
                    '---Auto Delete File ---
                    Parameter_Lists = Parameter_Lists & "AutoDeleteFile," & Me.CheckBox_AutoDeleteFile.Checked & ";"
                    '---Save Defect Image ---
                    Parameter_Lists = Parameter_Lists & "Save_Func_DefectImage," & Me.CheckBox_Save_Func_DefectImage.Checked & ";" & "Save_Mura_DefectImage," & Me.CheckBox_Save_Mura_DefectImage.Checked & ";"
                    '---BlobAnalysis Method ---
                    Parameter_Lists = Parameter_Lists & "BlobAnalysis_Method," & Me.m_MainProcess.IPBootConfig.BlobAnalysis_Method.Value & ";"
                    '---ExposureTime Setting ---
                    Parameter_Lists = Parameter_Lists & "Max_ExposureTime," & Me.m_MainProcess.IPBootConfig.Max_ExposureTime.Value & ";"
                    '---DefectEnhance ---
                    Parameter_Lists = Parameter_Lists & "Enlarge," & Me.NumericUpDown_Enlarge.Value & ";" & "Enhance," & Me.NumericUpDown_Enhance.Value & ";"
                    '---DetailOutput---
                    Parameter_Lists = Parameter_Lists & "DetailOutput," & Me.CheckBox_DetailOutput.Checked & ";"
                    '---Master\Slave Mode ---
                    Parameter_Lists = Parameter_Lists & "MasterSlaveMode," & ipbc.MasterSlaveMode.Value & ";" & "MasterSlaveMode_Enable," & Me.CheckBox_MasterSlaveMode_Enable.Checked & ";"
                    '---CCD Link Type ---
                    Parameter_Lists = Parameter_Lists & "CCD_Link_Type," & ipbc.CCD_Link_Type.Value & ";" & "GigE_SerialNum," & Me.TextBox_GigE_SerialNum.Text & ";"
                    '---Grid Calibration Setting ---
                    Parameter_Lists = Parameter_Lists & "Grid_Calibration_Enable," & ipbc.Grid_Calibration_Enable.Value & ";"
                    '--- Icon Setting ---
                    Parameter_Lists = Parameter_Lists & "UI_IP_HideToIcon_Enable," & ipbc.UI_IP_HideToIcon_Enable.Value & ";"
                    '---PixelShiftCCD Setting---
                    Parameter_Lists = Parameter_Lists & "IsPixelShiftCCD," & ipbc.IsPixelShiftCCD.Value & ";" & "PixelShiftStage," & ipbc.PixelShiftStage.Value & ";" & "PixelShiftComPort," & ipbc.PixelShiftComPort.Value & ";"
                    '---Trigger Setting---
                    Parameter_Lists = Parameter_Lists & "IsTrigger," & ipbc.IsTrigger.Value & ";" & "WaitGrabEnd," & ipbc.WaitGrabEnd.Value & ";"

                    'End UI Recipe Setting -----------------------------------

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_IPBootConfig Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_IPBootConfig.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save Boot Config Recipe ==> Request_Command = "SAVE_BOOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_BOOT"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Boot Config Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_IPBootConfig.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If
            '---Button Control ---   
            Button_Enable(True)

            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_IPBootConfig.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_IPBootConfig.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- Button_Close ---"
    Private Sub Button_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.Close()
    End Sub
#End Region

#Region "--- Button_RecipePath ---"
    Private Sub Button_RecipePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_RecipePath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_RecipePath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_RecipePath.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region

#Region "--- Button_DataRootPath ---"
    Private Sub Button_DataRootPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DataRootPath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_DataRootPath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_DataRootPath.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region

#Region "--- Button_RamDiskPath ---"
    Private Sub Button_RamDiskPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_RamDiskPath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_RamDiskPath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_RamDiskPath.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region

#Region "--- Button_DefectPath ---"
    Private Sub Button_DefectPath_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DefectPath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_DefectPath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_DefectPath.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region

#Region "--- Button_ImagePath ---"
    Private Sub Button_ImagePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ImagePath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_ImagePath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_ImagePath.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region

#Region "--- Button_ImagePath2 ---"
    Private Sub Button_ImagePath2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ImagePath2.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_ImagePath2.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_ImagePath2.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region

#Region "---Button_ResizeBMPPath_Click---"
    Private Sub Button_ResizeBMPPath_Click(sender As System.Object, e As System.EventArgs) Handles Button_ResizeBMPPath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_ResizeBMPPath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_ResizeBMPPath.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region


#Region "---Button_CharacteristicPath---"
    Private Sub Button_CharacteristicPath_Click(sender As System.Object, e As System.EventArgs) Handles Button_CharacteristicPath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_CharacteristicPath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_CharacteristicPath.Text = Me.SavePath(Me.FolderBrowserDialog.SelectedPath)
        End If
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_MasterSlaveMode_Enable_CheckedChanged ---"
    Private Sub CheckBox_MasterSlaveMode_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_MasterSlaveMode_Enable.CheckedChanged
        Me.RadioButton_MasterMode.Enabled = Me.CheckBox_MasterSlaveMode_Enable.Checked
        Me.RadioButton_SlaveMode.Enabled = Me.CheckBox_MasterSlaveMode_Enable.Checked
    End Sub
#End Region

#End Region

#Region "--- RadioButton ---"

#Region "--- RadioButton_DigitizerType_Mono_CheckedChanged ---"
    Private Sub RadioButton_DigitizerType_Mono_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DigitizerType_Mono.CheckedChanged
        Me.GroupBox_BayerPattern.Enabled = False
    End Sub
#End Region

#Region "--- RadioButton_DigitizerType_Color_CheckedChanged ---"
    Private Sub RadioButton_DigitizerType_Color_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DigitizerType_Color.CheckedChanged
        Me.GroupBox_BayerPattern.Enabled = True
    End Sub
#End Region

#End Region

#Region "--- Change Language ---"

    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                CheckBox_PanelRotate90.Text = res.GetString("CheckBox_PanelRotate90.Text")
                Label12.Text = res.GetString("Label12.Text")
                Label13.Text = res.GetString("Label13.Text")
                Label14.Text = res.GetString("Label14.Text")
                Label30.Text = res.GetString("Label30.Text")
        End Select
    End Sub
#End Region

End Class