<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_IPBootConfig
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_IPBootConfig))
        Me.GroupBox_CardSetting = New System.Windows.Forms.GroupBox()
        Me.TextBox_GPUDeviceNumber = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox_CardSystemDeviceNumber = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox_CardSystem = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox_DigitizerSetting = New System.Windows.Forms.GroupBox()
        Me.TextBox_ImageSizeY = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox_ImageSizeX = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox_Digitizer_Datadepth = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox_DigitizerDeviceNumber = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox_DigitizerFormatForTrigger = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox_DigitizerFormat = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox_IPSetting = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowOGDImg = New System.Windows.Forms.CheckBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.NumericUpDown_InitialDelayTime = New System.Windows.Forms.NumericUpDown()
        Me.ComboBox_Authority = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.CheckBox_AutoDeleteFile = New System.Windows.Forms.CheckBox()
        Me.TextBox_GrabNo = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TextBox_CCDNo = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox_RecipePath_Setting = New System.Windows.Forms.GroupBox()
        Me.CheckBox_SaveToRam = New System.Windows.Forms.CheckBox()
        Me.CheckBox_LocalGrab = New System.Windows.Forms.CheckBox()
        Me.Button_CharacteristicPath = New System.Windows.Forms.Button()
        Me.TextBox_CharacteristicPath = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Button_RamDiskPath = New System.Windows.Forms.Button()
        Me.TextBox_RamDiskPath = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button_DataRootPath = New System.Windows.Forms.Button()
        Me.TextBox_DataRootPath = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Button_RecipePath = New System.Windows.Forms.Button()
        Me.TextBox_RecipePath = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.GroupBox_FunctionEnable = New System.Windows.Forms.GroupBox()
        Me.GroupBox_FuncSelection = New System.Windows.Forms.GroupBox()
        Me.CheckBox_BarcodeUI = New System.Windows.Forms.CheckBox()
        Me.CheckBox_TPMarkUI = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MaskMarkUI = New System.Windows.Forms.CheckBox()
        Me.CheckBox_PLMarkUI = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MuraUI = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FuncUI = New System.Windows.Forms.CheckBox()
        Me.GroupBox_LogSetting = New System.Windows.Forms.GroupBox()
        Me.CheckBox_HVValueLog = New System.Windows.Forms.CheckBox()
        Me.CheckBox_TimeLog = New System.Windows.Forms.CheckBox()
        Me.CheckBox_WriteToLog2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_WriteToLog1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SubSystem_Log = New System.Windows.Forms.CheckBox()
        Me.GroupBox_PanelTransferSetting = New System.Windows.Forms.GroupBox()
        Me.ComboBox_PanelTransfer = New System.Windows.Forms.ComboBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox_PanelRotation = New System.Windows.Forms.GroupBox()
        Me.CheckBox_PanelRotate90 = New System.Windows.Forms.CheckBox()
        Me.GroupBox_DefectNumSetting = New System.Windows.Forms.GroupBox()
        Me.TextBox_MuraDefects_Max = New System.Windows.Forms.TextBox()
        Me.TextBox_FuncDefects_Max = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox_ImagePath_Setting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_ResizeBMPCount = New System.Windows.Forms.NumericUpDown()
        Me.Button_ResizeBMPPath = New System.Windows.Forms.Button()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TextBox_ResizeBMPPath = New System.Windows.Forms.TextBox()
        Me.CheckBox_Save_Mura_DefectImage = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Save_Func_DefectImage = New System.Windows.Forms.CheckBox()
        Me.Button_ImagePath2 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox_ImagePath2 = New System.Windows.Forms.TextBox()
        Me.Button_ImagePath = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox_ImagePath = New System.Windows.Forms.TextBox()
        Me.Button_DefectPath = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox_DefectPath = New System.Windows.Forms.TextBox()
        Me.GroupBox_SetRAMRush_PerCount = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_SetRAMRush_PerCount = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.GroupBox_BlobAnalysis_Setting = New System.Windows.Forms.GroupBox()
        Me.CheckBox_DetailOutput = New System.Windows.Forms.CheckBox()
        Me.RadioButton_BlobAnalysis_MIL = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BlobAnalysis_CUDA = New System.Windows.Forms.RadioButton()
        Me.GroupBox_ExposureTime_Setting = New System.Windows.Forms.GroupBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TextBox_Max_ExposureTime = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Enhance = New System.Windows.Forms.NumericUpDown()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Enlarge = New System.Windows.Forms.NumericUpDown()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.GroupBox_MasterSlaveMode = New System.Windows.Forms.GroupBox()
        Me.CheckBox_MasterSlaveMode_Enable = New System.Windows.Forms.CheckBox()
        Me.RadioButton_SlaveMode = New System.Windows.Forms.RadioButton()
        Me.RadioButton_MasterMode = New System.Windows.Forms.RadioButton()
        Me.GroupBox_CCD_Link_Type = New System.Windows.Forms.GroupBox()
        Me.RadioButton_CCD_Link_CXP = New System.Windows.Forms.RadioButton()
        Me.TextBox_GigE_SerialNum = New System.Windows.Forms.TextBox()
        Me.RadioButton_CCD_Link_GigE = New System.Windows.Forms.RadioButton()
        Me.RadioButton_CCD_Link_CameraLink = New System.Windows.Forms.RadioButton()
        Me.GroupBox_DigitizerType = New System.Windows.Forms.GroupBox()
        Me.CheckBox_IsPacked = New System.Windows.Forms.CheckBox()
        Me.CheckBox_EnablePCA = New System.Windows.Forms.CheckBox()
        Me.RadioButton_DigitizerType_Color = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DigitizerType_Mono = New System.Windows.Forms.RadioButton()
        Me.GroupBox_BayerPattern = New System.Windows.Forms.GroupBox()
        Me.RadioButton_BayerPattern_Red_Green = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BayerPattern_Green_Red = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BayerPattern_Green_Blue = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BayerPattern_Blue_Green = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Grid_Calibration_Setting = New System.Windows.Forms.GroupBox()
        Me.CheckBox_Grid_Calibration_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Icon_Setting = New System.Windows.Forms.GroupBox()
        Me.CheckBox_IP_Hide_To_Icon = New System.Windows.Forms.CheckBox()
        Me.CheckBox_AreaGrabber_Hide_To_Icon = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TextBox_ShiftCCD_ComPort = New System.Windows.Forms.TextBox()
        Me.ComboBox_ShiftCCD_Stage = New System.Windows.Forms.ComboBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.CheckBox_ShiftCCD_IsShiftCCD = New System.Windows.Forms.CheckBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ComboBox_TriggerMode = New System.Windows.Forms.ComboBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.CheckBox_WaitGrabEnd = New System.Windows.Forms.CheckBox()
        Me.FolderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.GroupBox_CardSetting.SuspendLayout()
        Me.GroupBox_DigitizerSetting.SuspendLayout()
        Me.GroupBox_IPSetting.SuspendLayout()
        CType(Me.NumericUpDown_InitialDelayTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_RecipePath_Setting.SuspendLayout()
        Me.GroupBox_FunctionEnable.SuspendLayout()
        Me.GroupBox_FuncSelection.SuspendLayout()
        Me.GroupBox_LogSetting.SuspendLayout()
        Me.GroupBox_PanelTransferSetting.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox_PanelRotation.SuspendLayout()
        Me.GroupBox_DefectNumSetting.SuspendLayout()
        Me.GroupBox_ImagePath_Setting.SuspendLayout()
        CType(Me.NumericUpDown_ResizeBMPCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_SetRAMRush_PerCount.SuspendLayout()
        CType(Me.NumericUpDown_SetRAMRush_PerCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BlobAnalysis_Setting.SuspendLayout()
        Me.GroupBox_ExposureTime_Setting.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NumericUpDown_Enhance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Enlarge, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MasterSlaveMode.SuspendLayout()
        Me.GroupBox_CCD_Link_Type.SuspendLayout()
        Me.GroupBox_DigitizerType.SuspendLayout()
        Me.GroupBox_BayerPattern.SuspendLayout()
        Me.GroupBox_Grid_Calibration_Setting.SuspendLayout()
        Me.GroupBox_Icon_Setting.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox_CardSetting
        '
        resources.ApplyResources(Me.GroupBox_CardSetting, "GroupBox_CardSetting")
        Me.GroupBox_CardSetting.Controls.Add(Me.TextBox_GPUDeviceNumber)
        Me.GroupBox_CardSetting.Controls.Add(Me.Label3)
        Me.GroupBox_CardSetting.Controls.Add(Me.TextBox_CardSystemDeviceNumber)
        Me.GroupBox_CardSetting.Controls.Add(Me.Label2)
        Me.GroupBox_CardSetting.Controls.Add(Me.TextBox_CardSystem)
        Me.GroupBox_CardSetting.Controls.Add(Me.Label1)
        Me.GroupBox_CardSetting.Name = "GroupBox_CardSetting"
        Me.GroupBox_CardSetting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_CardSetting, resources.GetString("GroupBox_CardSetting.ToolTip"))
        '
        'TextBox_GPUDeviceNumber
        '
        resources.ApplyResources(Me.TextBox_GPUDeviceNumber, "TextBox_GPUDeviceNumber")
        Me.TextBox_GPUDeviceNumber.Name = "TextBox_GPUDeviceNumber"
        Me.ToolTip1.SetToolTip(Me.TextBox_GPUDeviceNumber, resources.GetString("TextBox_GPUDeviceNumber.ToolTip"))
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        Me.ToolTip1.SetToolTip(Me.Label3, resources.GetString("Label3.ToolTip"))
        '
        'TextBox_CardSystemDeviceNumber
        '
        resources.ApplyResources(Me.TextBox_CardSystemDeviceNumber, "TextBox_CardSystemDeviceNumber")
        Me.TextBox_CardSystemDeviceNumber.Name = "TextBox_CardSystemDeviceNumber"
        Me.ToolTip1.SetToolTip(Me.TextBox_CardSystemDeviceNumber, resources.GetString("TextBox_CardSystemDeviceNumber.ToolTip"))
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        Me.ToolTip1.SetToolTip(Me.Label2, resources.GetString("Label2.ToolTip"))
        '
        'TextBox_CardSystem
        '
        resources.ApplyResources(Me.TextBox_CardSystem, "TextBox_CardSystem")
        Me.TextBox_CardSystem.Name = "TextBox_CardSystem"
        Me.ToolTip1.SetToolTip(Me.TextBox_CardSystem, resources.GetString("TextBox_CardSystem.ToolTip"))
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        Me.ToolTip1.SetToolTip(Me.Label1, resources.GetString("Label1.ToolTip"))
        '
        'GroupBox_DigitizerSetting
        '
        resources.ApplyResources(Me.GroupBox_DigitizerSetting, "GroupBox_DigitizerSetting")
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.TextBox_ImageSizeY)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.Label9)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.TextBox_ImageSizeX)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.Label8)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.TextBox_Digitizer_Datadepth)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.Label7)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.TextBox_DigitizerDeviceNumber)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.Label6)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.TextBox_DigitizerFormatForTrigger)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.Label5)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.TextBox_DigitizerFormat)
        Me.GroupBox_DigitizerSetting.Controls.Add(Me.Label4)
        Me.GroupBox_DigitizerSetting.Name = "GroupBox_DigitizerSetting"
        Me.GroupBox_DigitizerSetting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_DigitizerSetting, resources.GetString("GroupBox_DigitizerSetting.ToolTip"))
        '
        'TextBox_ImageSizeY
        '
        resources.ApplyResources(Me.TextBox_ImageSizeY, "TextBox_ImageSizeY")
        Me.TextBox_ImageSizeY.Name = "TextBox_ImageSizeY"
        Me.ToolTip1.SetToolTip(Me.TextBox_ImageSizeY, resources.GetString("TextBox_ImageSizeY.ToolTip"))
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        Me.ToolTip1.SetToolTip(Me.Label9, resources.GetString("Label9.ToolTip"))
        '
        'TextBox_ImageSizeX
        '
        resources.ApplyResources(Me.TextBox_ImageSizeX, "TextBox_ImageSizeX")
        Me.TextBox_ImageSizeX.Name = "TextBox_ImageSizeX"
        Me.ToolTip1.SetToolTip(Me.TextBox_ImageSizeX, resources.GetString("TextBox_ImageSizeX.ToolTip"))
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        Me.ToolTip1.SetToolTip(Me.Label8, resources.GetString("Label8.ToolTip"))
        '
        'TextBox_Digitizer_Datadepth
        '
        resources.ApplyResources(Me.TextBox_Digitizer_Datadepth, "TextBox_Digitizer_Datadepth")
        Me.TextBox_Digitizer_Datadepth.Name = "TextBox_Digitizer_Datadepth"
        Me.ToolTip1.SetToolTip(Me.TextBox_Digitizer_Datadepth, resources.GetString("TextBox_Digitizer_Datadepth.ToolTip"))
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        Me.ToolTip1.SetToolTip(Me.Label7, resources.GetString("Label7.ToolTip"))
        '
        'TextBox_DigitizerDeviceNumber
        '
        resources.ApplyResources(Me.TextBox_DigitizerDeviceNumber, "TextBox_DigitizerDeviceNumber")
        Me.TextBox_DigitizerDeviceNumber.Name = "TextBox_DigitizerDeviceNumber"
        Me.ToolTip1.SetToolTip(Me.TextBox_DigitizerDeviceNumber, resources.GetString("TextBox_DigitizerDeviceNumber.ToolTip"))
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        Me.ToolTip1.SetToolTip(Me.Label6, resources.GetString("Label6.ToolTip"))
        '
        'TextBox_DigitizerFormatForTrigger
        '
        resources.ApplyResources(Me.TextBox_DigitizerFormatForTrigger, "TextBox_DigitizerFormatForTrigger")
        Me.TextBox_DigitizerFormatForTrigger.Name = "TextBox_DigitizerFormatForTrigger"
        Me.ToolTip1.SetToolTip(Me.TextBox_DigitizerFormatForTrigger, resources.GetString("TextBox_DigitizerFormatForTrigger.ToolTip"))
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        Me.ToolTip1.SetToolTip(Me.Label5, resources.GetString("Label5.ToolTip"))
        '
        'TextBox_DigitizerFormat
        '
        resources.ApplyResources(Me.TextBox_DigitizerFormat, "TextBox_DigitizerFormat")
        Me.TextBox_DigitizerFormat.Name = "TextBox_DigitizerFormat"
        Me.ToolTip1.SetToolTip(Me.TextBox_DigitizerFormat, resources.GetString("TextBox_DigitizerFormat.ToolTip"))
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        Me.ToolTip1.SetToolTip(Me.Label4, resources.GetString("Label4.ToolTip"))
        '
        'GroupBox_IPSetting
        '
        resources.ApplyResources(Me.GroupBox_IPSetting, "GroupBox_IPSetting")
        Me.GroupBox_IPSetting.Controls.Add(Me.CheckBox_ShowOGDImg)
        Me.GroupBox_IPSetting.Controls.Add(Me.Label32)
        Me.GroupBox_IPSetting.Controls.Add(Me.NumericUpDown_InitialDelayTime)
        Me.GroupBox_IPSetting.Controls.Add(Me.ComboBox_Authority)
        Me.GroupBox_IPSetting.Controls.Add(Me.Label22)
        Me.GroupBox_IPSetting.Controls.Add(Me.CheckBox_AutoDeleteFile)
        Me.GroupBox_IPSetting.Controls.Add(Me.TextBox_GrabNo)
        Me.GroupBox_IPSetting.Controls.Add(Me.Label17)
        Me.GroupBox_IPSetting.Controls.Add(Me.TextBox_CCDNo)
        Me.GroupBox_IPSetting.Controls.Add(Me.Label16)
        Me.GroupBox_IPSetting.Name = "GroupBox_IPSetting"
        Me.GroupBox_IPSetting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_IPSetting, resources.GetString("GroupBox_IPSetting.ToolTip"))
        '
        'CheckBox_ShowOGDImg
        '
        resources.ApplyResources(Me.CheckBox_ShowOGDImg, "CheckBox_ShowOGDImg")
        Me.CheckBox_ShowOGDImg.Name = "CheckBox_ShowOGDImg"
        Me.ToolTip1.SetToolTip(Me.CheckBox_ShowOGDImg, resources.GetString("CheckBox_ShowOGDImg.ToolTip"))
        Me.CheckBox_ShowOGDImg.UseVisualStyleBackColor = True
        '
        'Label32
        '
        resources.ApplyResources(Me.Label32, "Label32")
        Me.Label32.Name = "Label32"
        Me.ToolTip1.SetToolTip(Me.Label32, resources.GetString("Label32.ToolTip"))
        '
        'NumericUpDown_InitialDelayTime
        '
        resources.ApplyResources(Me.NumericUpDown_InitialDelayTime, "NumericUpDown_InitialDelayTime")
        Me.NumericUpDown_InitialDelayTime.Increment = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_InitialDelayTime.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_InitialDelayTime.Minimum = New Decimal(New Integer() {3000, 0, 0, 0})
        Me.NumericUpDown_InitialDelayTime.Name = "NumericUpDown_InitialDelayTime"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_InitialDelayTime, resources.GetString("NumericUpDown_InitialDelayTime.ToolTip"))
        Me.NumericUpDown_InitialDelayTime.Value = New Decimal(New Integer() {6000, 0, 0, 0})
        '
        'ComboBox_Authority
        '
        resources.ApplyResources(Me.ComboBox_Authority, "ComboBox_Authority")
        Me.ComboBox_Authority.FormattingEnabled = True
        Me.ComboBox_Authority.Items.AddRange(New Object() {resources.GetString("ComboBox_Authority.Items"), resources.GetString("ComboBox_Authority.Items1"), resources.GetString("ComboBox_Authority.Items2"), resources.GetString("ComboBox_Authority.Items3"), resources.GetString("ComboBox_Authority.Items4")})
        Me.ComboBox_Authority.Name = "ComboBox_Authority"
        Me.ToolTip1.SetToolTip(Me.ComboBox_Authority, resources.GetString("ComboBox_Authority.ToolTip"))
        '
        'Label22
        '
        resources.ApplyResources(Me.Label22, "Label22")
        Me.Label22.Name = "Label22"
        Me.ToolTip1.SetToolTip(Me.Label22, resources.GetString("Label22.ToolTip"))
        '
        'CheckBox_AutoDeleteFile
        '
        resources.ApplyResources(Me.CheckBox_AutoDeleteFile, "CheckBox_AutoDeleteFile")
        Me.CheckBox_AutoDeleteFile.Name = "CheckBox_AutoDeleteFile"
        Me.ToolTip1.SetToolTip(Me.CheckBox_AutoDeleteFile, resources.GetString("CheckBox_AutoDeleteFile.ToolTip"))
        Me.CheckBox_AutoDeleteFile.UseVisualStyleBackColor = True
        '
        'TextBox_GrabNo
        '
        resources.ApplyResources(Me.TextBox_GrabNo, "TextBox_GrabNo")
        Me.TextBox_GrabNo.Name = "TextBox_GrabNo"
        Me.ToolTip1.SetToolTip(Me.TextBox_GrabNo, resources.GetString("TextBox_GrabNo.ToolTip"))
        '
        'Label17
        '
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        Me.ToolTip1.SetToolTip(Me.Label17, resources.GetString("Label17.ToolTip"))
        '
        'TextBox_CCDNo
        '
        resources.ApplyResources(Me.TextBox_CCDNo, "TextBox_CCDNo")
        Me.TextBox_CCDNo.Name = "TextBox_CCDNo"
        Me.ToolTip1.SetToolTip(Me.TextBox_CCDNo, resources.GetString("TextBox_CCDNo.ToolTip"))
        '
        'Label16
        '
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        Me.ToolTip1.SetToolTip(Me.Label16, resources.GetString("Label16.ToolTip"))
        '
        'GroupBox_RecipePath_Setting
        '
        resources.ApplyResources(Me.GroupBox_RecipePath_Setting, "GroupBox_RecipePath_Setting")
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.CheckBox_SaveToRam)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.CheckBox_LocalGrab)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Button_CharacteristicPath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.TextBox_CharacteristicPath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Label27)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Button_RamDiskPath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.TextBox_RamDiskPath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Label21)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Button_DataRootPath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.TextBox_DataRootPath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Label20)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Button_RecipePath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.TextBox_RecipePath)
        Me.GroupBox_RecipePath_Setting.Controls.Add(Me.Label19)
        Me.GroupBox_RecipePath_Setting.Name = "GroupBox_RecipePath_Setting"
        Me.GroupBox_RecipePath_Setting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_RecipePath_Setting, resources.GetString("GroupBox_RecipePath_Setting.ToolTip"))
        '
        'CheckBox_SaveToRam
        '
        resources.ApplyResources(Me.CheckBox_SaveToRam, "CheckBox_SaveToRam")
        Me.CheckBox_SaveToRam.Name = "CheckBox_SaveToRam"
        Me.ToolTip1.SetToolTip(Me.CheckBox_SaveToRam, resources.GetString("CheckBox_SaveToRam.ToolTip"))
        Me.CheckBox_SaveToRam.UseVisualStyleBackColor = True
        '
        'CheckBox_LocalGrab
        '
        resources.ApplyResources(Me.CheckBox_LocalGrab, "CheckBox_LocalGrab")
        Me.CheckBox_LocalGrab.Name = "CheckBox_LocalGrab"
        Me.ToolTip1.SetToolTip(Me.CheckBox_LocalGrab, resources.GetString("CheckBox_LocalGrab.ToolTip"))
        Me.CheckBox_LocalGrab.UseVisualStyleBackColor = True
        '
        'Button_CharacteristicPath
        '
        resources.ApplyResources(Me.Button_CharacteristicPath, "Button_CharacteristicPath")
        Me.Button_CharacteristicPath.Name = "Button_CharacteristicPath"
        Me.ToolTip1.SetToolTip(Me.Button_CharacteristicPath, resources.GetString("Button_CharacteristicPath.ToolTip"))
        Me.Button_CharacteristicPath.UseVisualStyleBackColor = True
        '
        'TextBox_CharacteristicPath
        '
        resources.ApplyResources(Me.TextBox_CharacteristicPath, "TextBox_CharacteristicPath")
        Me.TextBox_CharacteristicPath.Name = "TextBox_CharacteristicPath"
        Me.ToolTip1.SetToolTip(Me.TextBox_CharacteristicPath, resources.GetString("TextBox_CharacteristicPath.ToolTip"))
        '
        'Label27
        '
        resources.ApplyResources(Me.Label27, "Label27")
        Me.Label27.Name = "Label27"
        Me.ToolTip1.SetToolTip(Me.Label27, resources.GetString("Label27.ToolTip"))
        '
        'Button_RamDiskPath
        '
        resources.ApplyResources(Me.Button_RamDiskPath, "Button_RamDiskPath")
        Me.Button_RamDiskPath.Name = "Button_RamDiskPath"
        Me.ToolTip1.SetToolTip(Me.Button_RamDiskPath, resources.GetString("Button_RamDiskPath.ToolTip"))
        Me.Button_RamDiskPath.UseVisualStyleBackColor = True
        '
        'TextBox_RamDiskPath
        '
        resources.ApplyResources(Me.TextBox_RamDiskPath, "TextBox_RamDiskPath")
        Me.TextBox_RamDiskPath.Name = "TextBox_RamDiskPath"
        Me.ToolTip1.SetToolTip(Me.TextBox_RamDiskPath, resources.GetString("TextBox_RamDiskPath.ToolTip"))
        '
        'Label21
        '
        resources.ApplyResources(Me.Label21, "Label21")
        Me.Label21.Name = "Label21"
        Me.ToolTip1.SetToolTip(Me.Label21, resources.GetString("Label21.ToolTip"))
        '
        'Button_DataRootPath
        '
        resources.ApplyResources(Me.Button_DataRootPath, "Button_DataRootPath")
        Me.Button_DataRootPath.Name = "Button_DataRootPath"
        Me.ToolTip1.SetToolTip(Me.Button_DataRootPath, resources.GetString("Button_DataRootPath.ToolTip"))
        Me.Button_DataRootPath.UseVisualStyleBackColor = True
        '
        'TextBox_DataRootPath
        '
        resources.ApplyResources(Me.TextBox_DataRootPath, "TextBox_DataRootPath")
        Me.TextBox_DataRootPath.Name = "TextBox_DataRootPath"
        Me.ToolTip1.SetToolTip(Me.TextBox_DataRootPath, resources.GetString("TextBox_DataRootPath.ToolTip"))
        '
        'Label20
        '
        resources.ApplyResources(Me.Label20, "Label20")
        Me.Label20.Name = "Label20"
        Me.ToolTip1.SetToolTip(Me.Label20, resources.GetString("Label20.ToolTip"))
        '
        'Button_RecipePath
        '
        resources.ApplyResources(Me.Button_RecipePath, "Button_RecipePath")
        Me.Button_RecipePath.Name = "Button_RecipePath"
        Me.ToolTip1.SetToolTip(Me.Button_RecipePath, resources.GetString("Button_RecipePath.ToolTip"))
        Me.Button_RecipePath.UseVisualStyleBackColor = True
        '
        'TextBox_RecipePath
        '
        resources.ApplyResources(Me.TextBox_RecipePath, "TextBox_RecipePath")
        Me.TextBox_RecipePath.Name = "TextBox_RecipePath"
        Me.ToolTip1.SetToolTip(Me.TextBox_RecipePath, resources.GetString("TextBox_RecipePath.ToolTip"))
        '
        'Label19
        '
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.Name = "Label19"
        Me.ToolTip1.SetToolTip(Me.Label19, resources.GetString("Label19.ToolTip"))
        '
        'GroupBox_FunctionEnable
        '
        resources.ApplyResources(Me.GroupBox_FunctionEnable, "GroupBox_FunctionEnable")
        Me.GroupBox_FunctionEnable.Controls.Add(Me.GroupBox_FuncSelection)
        Me.GroupBox_FunctionEnable.Controls.Add(Me.GroupBox_LogSetting)
        Me.GroupBox_FunctionEnable.Name = "GroupBox_FunctionEnable"
        Me.GroupBox_FunctionEnable.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_FunctionEnable, resources.GetString("GroupBox_FunctionEnable.ToolTip"))
        '
        'GroupBox_FuncSelection
        '
        resources.ApplyResources(Me.GroupBox_FuncSelection, "GroupBox_FuncSelection")
        Me.GroupBox_FuncSelection.Controls.Add(Me.CheckBox_BarcodeUI)
        Me.GroupBox_FuncSelection.Controls.Add(Me.CheckBox_TPMarkUI)
        Me.GroupBox_FuncSelection.Controls.Add(Me.CheckBox_MaskMarkUI)
        Me.GroupBox_FuncSelection.Controls.Add(Me.CheckBox_PLMarkUI)
        Me.GroupBox_FuncSelection.Controls.Add(Me.CheckBox_MuraUI)
        Me.GroupBox_FuncSelection.Controls.Add(Me.CheckBox_FuncUI)
        Me.GroupBox_FuncSelection.Name = "GroupBox_FuncSelection"
        Me.GroupBox_FuncSelection.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_FuncSelection, resources.GetString("GroupBox_FuncSelection.ToolTip"))
        '
        'CheckBox_BarcodeUI
        '
        resources.ApplyResources(Me.CheckBox_BarcodeUI, "CheckBox_BarcodeUI")
        Me.CheckBox_BarcodeUI.Name = "CheckBox_BarcodeUI"
        Me.ToolTip1.SetToolTip(Me.CheckBox_BarcodeUI, resources.GetString("CheckBox_BarcodeUI.ToolTip"))
        Me.CheckBox_BarcodeUI.UseVisualStyleBackColor = True
        '
        'CheckBox_TPMarkUI
        '
        resources.ApplyResources(Me.CheckBox_TPMarkUI, "CheckBox_TPMarkUI")
        Me.CheckBox_TPMarkUI.Name = "CheckBox_TPMarkUI"
        Me.ToolTip1.SetToolTip(Me.CheckBox_TPMarkUI, resources.GetString("CheckBox_TPMarkUI.ToolTip"))
        Me.CheckBox_TPMarkUI.UseVisualStyleBackColor = True
        '
        'CheckBox_MaskMarkUI
        '
        resources.ApplyResources(Me.CheckBox_MaskMarkUI, "CheckBox_MaskMarkUI")
        Me.CheckBox_MaskMarkUI.Name = "CheckBox_MaskMarkUI"
        Me.ToolTip1.SetToolTip(Me.CheckBox_MaskMarkUI, resources.GetString("CheckBox_MaskMarkUI.ToolTip"))
        Me.CheckBox_MaskMarkUI.UseVisualStyleBackColor = True
        '
        'CheckBox_PLMarkUI
        '
        resources.ApplyResources(Me.CheckBox_PLMarkUI, "CheckBox_PLMarkUI")
        Me.CheckBox_PLMarkUI.Name = "CheckBox_PLMarkUI"
        Me.ToolTip1.SetToolTip(Me.CheckBox_PLMarkUI, resources.GetString("CheckBox_PLMarkUI.ToolTip"))
        Me.CheckBox_PLMarkUI.UseVisualStyleBackColor = True
        '
        'CheckBox_MuraUI
        '
        resources.ApplyResources(Me.CheckBox_MuraUI, "CheckBox_MuraUI")
        Me.CheckBox_MuraUI.Name = "CheckBox_MuraUI"
        Me.ToolTip1.SetToolTip(Me.CheckBox_MuraUI, resources.GetString("CheckBox_MuraUI.ToolTip"))
        Me.CheckBox_MuraUI.UseVisualStyleBackColor = True
        '
        'CheckBox_FuncUI
        '
        resources.ApplyResources(Me.CheckBox_FuncUI, "CheckBox_FuncUI")
        Me.CheckBox_FuncUI.Name = "CheckBox_FuncUI"
        Me.ToolTip1.SetToolTip(Me.CheckBox_FuncUI, resources.GetString("CheckBox_FuncUI.ToolTip"))
        Me.CheckBox_FuncUI.UseVisualStyleBackColor = True
        '
        'GroupBox_LogSetting
        '
        resources.ApplyResources(Me.GroupBox_LogSetting, "GroupBox_LogSetting")
        Me.GroupBox_LogSetting.Controls.Add(Me.CheckBox_HVValueLog)
        Me.GroupBox_LogSetting.Controls.Add(Me.CheckBox_TimeLog)
        Me.GroupBox_LogSetting.Controls.Add(Me.CheckBox_WriteToLog2)
        Me.GroupBox_LogSetting.Controls.Add(Me.CheckBox_WriteToLog1)
        Me.GroupBox_LogSetting.Controls.Add(Me.CheckBox_SubSystem_Log)
        Me.GroupBox_LogSetting.Name = "GroupBox_LogSetting"
        Me.GroupBox_LogSetting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_LogSetting, resources.GetString("GroupBox_LogSetting.ToolTip"))
        '
        'CheckBox_HVValueLog
        '
        resources.ApplyResources(Me.CheckBox_HVValueLog, "CheckBox_HVValueLog")
        Me.CheckBox_HVValueLog.Name = "CheckBox_HVValueLog"
        Me.ToolTip1.SetToolTip(Me.CheckBox_HVValueLog, resources.GetString("CheckBox_HVValueLog.ToolTip"))
        Me.CheckBox_HVValueLog.UseVisualStyleBackColor = True
        '
        'CheckBox_TimeLog
        '
        resources.ApplyResources(Me.CheckBox_TimeLog, "CheckBox_TimeLog")
        Me.CheckBox_TimeLog.Name = "CheckBox_TimeLog"
        Me.ToolTip1.SetToolTip(Me.CheckBox_TimeLog, resources.GetString("CheckBox_TimeLog.ToolTip"))
        Me.CheckBox_TimeLog.UseVisualStyleBackColor = True
        '
        'CheckBox_WriteToLog2
        '
        resources.ApplyResources(Me.CheckBox_WriteToLog2, "CheckBox_WriteToLog2")
        Me.CheckBox_WriteToLog2.Name = "CheckBox_WriteToLog2"
        Me.ToolTip1.SetToolTip(Me.CheckBox_WriteToLog2, resources.GetString("CheckBox_WriteToLog2.ToolTip"))
        Me.CheckBox_WriteToLog2.UseVisualStyleBackColor = True
        '
        'CheckBox_WriteToLog1
        '
        resources.ApplyResources(Me.CheckBox_WriteToLog1, "CheckBox_WriteToLog1")
        Me.CheckBox_WriteToLog1.Name = "CheckBox_WriteToLog1"
        Me.ToolTip1.SetToolTip(Me.CheckBox_WriteToLog1, resources.GetString("CheckBox_WriteToLog1.ToolTip"))
        Me.CheckBox_WriteToLog1.UseVisualStyleBackColor = True
        '
        'CheckBox_SubSystem_Log
        '
        resources.ApplyResources(Me.CheckBox_SubSystem_Log, "CheckBox_SubSystem_Log")
        Me.CheckBox_SubSystem_Log.Name = "CheckBox_SubSystem_Log"
        Me.ToolTip1.SetToolTip(Me.CheckBox_SubSystem_Log, resources.GetString("CheckBox_SubSystem_Log.ToolTip"))
        Me.CheckBox_SubSystem_Log.UseVisualStyleBackColor = True
        '
        'GroupBox_PanelTransferSetting
        '
        resources.ApplyResources(Me.GroupBox_PanelTransferSetting, "GroupBox_PanelTransferSetting")
        Me.GroupBox_PanelTransferSetting.Controls.Add(Me.ComboBox_PanelTransfer)
        Me.GroupBox_PanelTransferSetting.Name = "GroupBox_PanelTransferSetting"
        Me.GroupBox_PanelTransferSetting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_PanelTransferSetting, resources.GetString("GroupBox_PanelTransferSetting.ToolTip"))
        '
        'ComboBox_PanelTransfer
        '
        resources.ApplyResources(Me.ComboBox_PanelTransfer, "ComboBox_PanelTransfer")
        Me.ComboBox_PanelTransfer.FormattingEnabled = True
        Me.ComboBox_PanelTransfer.Items.AddRange(New Object() {resources.GetString("ComboBox_PanelTransfer.Items"), resources.GetString("ComboBox_PanelTransfer.Items1"), resources.GetString("ComboBox_PanelTransfer.Items2")})
        Me.ComboBox_PanelTransfer.Name = "ComboBox_PanelTransfer"
        Me.ToolTip1.SetToolTip(Me.ComboBox_PanelTransfer, resources.GetString("ComboBox_PanelTransfer.ToolTip"))
        '
        'TableLayoutPanel1
        '
        resources.ApplyResources(Me.TableLayoutPanel1, "TableLayoutPanel1")
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Save, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Close, 1, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.ToolTip1.SetToolTip(Me.TableLayoutPanel1, resources.GetString("TableLayoutPanel1.ToolTip"))
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        Me.ToolTip1.SetToolTip(Me.Button_Save, resources.GetString("Button_Save.ToolTip"))
        '
        'Button_Close
        '
        resources.ApplyResources(Me.Button_Close, "Button_Close")
        Me.Button_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_Close.Name = "Button_Close"
        Me.ToolTip1.SetToolTip(Me.Button_Close, resources.GetString("Button_Close.ToolTip"))
        '
        'GroupBox_PanelRotation
        '
        resources.ApplyResources(Me.GroupBox_PanelRotation, "GroupBox_PanelRotation")
        Me.GroupBox_PanelRotation.Controls.Add(Me.CheckBox_PanelRotate90)
        Me.GroupBox_PanelRotation.Name = "GroupBox_PanelRotation"
        Me.GroupBox_PanelRotation.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_PanelRotation, resources.GetString("GroupBox_PanelRotation.ToolTip"))
        '
        'CheckBox_PanelRotate90
        '
        resources.ApplyResources(Me.CheckBox_PanelRotate90, "CheckBox_PanelRotate90")
        Me.CheckBox_PanelRotate90.Name = "CheckBox_PanelRotate90"
        Me.ToolTip1.SetToolTip(Me.CheckBox_PanelRotate90, resources.GetString("CheckBox_PanelRotate90.ToolTip"))
        Me.CheckBox_PanelRotate90.UseVisualStyleBackColor = True
        '
        'GroupBox_DefectNumSetting
        '
        resources.ApplyResources(Me.GroupBox_DefectNumSetting, "GroupBox_DefectNumSetting")
        Me.GroupBox_DefectNumSetting.Controls.Add(Me.TextBox_MuraDefects_Max)
        Me.GroupBox_DefectNumSetting.Controls.Add(Me.TextBox_FuncDefects_Max)
        Me.GroupBox_DefectNumSetting.Controls.Add(Me.Label11)
        Me.GroupBox_DefectNumSetting.Controls.Add(Me.Label10)
        Me.GroupBox_DefectNumSetting.Name = "GroupBox_DefectNumSetting"
        Me.GroupBox_DefectNumSetting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_DefectNumSetting, resources.GetString("GroupBox_DefectNumSetting.ToolTip"))
        '
        'TextBox_MuraDefects_Max
        '
        resources.ApplyResources(Me.TextBox_MuraDefects_Max, "TextBox_MuraDefects_Max")
        Me.TextBox_MuraDefects_Max.Name = "TextBox_MuraDefects_Max"
        Me.ToolTip1.SetToolTip(Me.TextBox_MuraDefects_Max, resources.GetString("TextBox_MuraDefects_Max.ToolTip"))
        '
        'TextBox_FuncDefects_Max
        '
        resources.ApplyResources(Me.TextBox_FuncDefects_Max, "TextBox_FuncDefects_Max")
        Me.TextBox_FuncDefects_Max.Name = "TextBox_FuncDefects_Max"
        Me.ToolTip1.SetToolTip(Me.TextBox_FuncDefects_Max, resources.GetString("TextBox_FuncDefects_Max.ToolTip"))
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        Me.ToolTip1.SetToolTip(Me.Label11, resources.GetString("Label11.ToolTip"))
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        Me.ToolTip1.SetToolTip(Me.Label10, resources.GetString("Label10.ToolTip"))
        '
        'GroupBox_ImagePath_Setting
        '
        resources.ApplyResources(Me.GroupBox_ImagePath_Setting, "GroupBox_ImagePath_Setting")
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.NumericUpDown_ResizeBMPCount)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Button_ResizeBMPPath)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Label31)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Label30)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.TextBox_ResizeBMPPath)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.CheckBox_Save_Mura_DefectImage)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.CheckBox_Save_Func_DefectImage)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Button_ImagePath2)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Label14)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.TextBox_ImagePath2)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Button_ImagePath)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Label13)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.TextBox_ImagePath)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Button_DefectPath)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.Label12)
        Me.GroupBox_ImagePath_Setting.Controls.Add(Me.TextBox_DefectPath)
        Me.GroupBox_ImagePath_Setting.Name = "GroupBox_ImagePath_Setting"
        Me.GroupBox_ImagePath_Setting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_ImagePath_Setting, resources.GetString("GroupBox_ImagePath_Setting.ToolTip"))
        '
        'NumericUpDown_ResizeBMPCount
        '
        resources.ApplyResources(Me.NumericUpDown_ResizeBMPCount, "NumericUpDown_ResizeBMPCount")
        Me.NumericUpDown_ResizeBMPCount.Name = "NumericUpDown_ResizeBMPCount"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_ResizeBMPCount, resources.GetString("NumericUpDown_ResizeBMPCount.ToolTip"))
        '
        'Button_ResizeBMPPath
        '
        resources.ApplyResources(Me.Button_ResizeBMPPath, "Button_ResizeBMPPath")
        Me.Button_ResizeBMPPath.Name = "Button_ResizeBMPPath"
        Me.ToolTip1.SetToolTip(Me.Button_ResizeBMPPath, resources.GetString("Button_ResizeBMPPath.ToolTip"))
        '
        'Label31
        '
        resources.ApplyResources(Me.Label31, "Label31")
        Me.Label31.Name = "Label31"
        Me.ToolTip1.SetToolTip(Me.Label31, resources.GetString("Label31.ToolTip"))
        '
        'Label30
        '
        resources.ApplyResources(Me.Label30, "Label30")
        Me.Label30.Name = "Label30"
        Me.ToolTip1.SetToolTip(Me.Label30, resources.GetString("Label30.ToolTip"))
        '
        'TextBox_ResizeBMPPath
        '
        resources.ApplyResources(Me.TextBox_ResizeBMPPath, "TextBox_ResizeBMPPath")
        Me.TextBox_ResizeBMPPath.Name = "TextBox_ResizeBMPPath"
        Me.ToolTip1.SetToolTip(Me.TextBox_ResizeBMPPath, resources.GetString("TextBox_ResizeBMPPath.ToolTip"))
        '
        'CheckBox_Save_Mura_DefectImage
        '
        resources.ApplyResources(Me.CheckBox_Save_Mura_DefectImage, "CheckBox_Save_Mura_DefectImage")
        Me.CheckBox_Save_Mura_DefectImage.Name = "CheckBox_Save_Mura_DefectImage"
        Me.ToolTip1.SetToolTip(Me.CheckBox_Save_Mura_DefectImage, resources.GetString("CheckBox_Save_Mura_DefectImage.ToolTip"))
        Me.CheckBox_Save_Mura_DefectImage.UseVisualStyleBackColor = True
        '
        'CheckBox_Save_Func_DefectImage
        '
        resources.ApplyResources(Me.CheckBox_Save_Func_DefectImage, "CheckBox_Save_Func_DefectImage")
        Me.CheckBox_Save_Func_DefectImage.Name = "CheckBox_Save_Func_DefectImage"
        Me.ToolTip1.SetToolTip(Me.CheckBox_Save_Func_DefectImage, resources.GetString("CheckBox_Save_Func_DefectImage.ToolTip"))
        Me.CheckBox_Save_Func_DefectImage.UseVisualStyleBackColor = True
        '
        'Button_ImagePath2
        '
        resources.ApplyResources(Me.Button_ImagePath2, "Button_ImagePath2")
        Me.Button_ImagePath2.Name = "Button_ImagePath2"
        Me.ToolTip1.SetToolTip(Me.Button_ImagePath2, resources.GetString("Button_ImagePath2.ToolTip"))
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        Me.ToolTip1.SetToolTip(Me.Label14, resources.GetString("Label14.ToolTip"))
        '
        'TextBox_ImagePath2
        '
        resources.ApplyResources(Me.TextBox_ImagePath2, "TextBox_ImagePath2")
        Me.TextBox_ImagePath2.Name = "TextBox_ImagePath2"
        Me.ToolTip1.SetToolTip(Me.TextBox_ImagePath2, resources.GetString("TextBox_ImagePath2.ToolTip"))
        '
        'Button_ImagePath
        '
        resources.ApplyResources(Me.Button_ImagePath, "Button_ImagePath")
        Me.Button_ImagePath.Name = "Button_ImagePath"
        Me.ToolTip1.SetToolTip(Me.Button_ImagePath, resources.GetString("Button_ImagePath.ToolTip"))
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        Me.ToolTip1.SetToolTip(Me.Label13, resources.GetString("Label13.ToolTip"))
        '
        'TextBox_ImagePath
        '
        resources.ApplyResources(Me.TextBox_ImagePath, "TextBox_ImagePath")
        Me.TextBox_ImagePath.Name = "TextBox_ImagePath"
        Me.ToolTip1.SetToolTip(Me.TextBox_ImagePath, resources.GetString("TextBox_ImagePath.ToolTip"))
        '
        'Button_DefectPath
        '
        resources.ApplyResources(Me.Button_DefectPath, "Button_DefectPath")
        Me.Button_DefectPath.Name = "Button_DefectPath"
        Me.ToolTip1.SetToolTip(Me.Button_DefectPath, resources.GetString("Button_DefectPath.ToolTip"))
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        Me.ToolTip1.SetToolTip(Me.Label12, resources.GetString("Label12.ToolTip"))
        '
        'TextBox_DefectPath
        '
        resources.ApplyResources(Me.TextBox_DefectPath, "TextBox_DefectPath")
        Me.TextBox_DefectPath.Name = "TextBox_DefectPath"
        Me.ToolTip1.SetToolTip(Me.TextBox_DefectPath, resources.GetString("TextBox_DefectPath.ToolTip"))
        '
        'GroupBox_SetRAMRush_PerCount
        '
        resources.ApplyResources(Me.GroupBox_SetRAMRush_PerCount, "GroupBox_SetRAMRush_PerCount")
        Me.GroupBox_SetRAMRush_PerCount.Controls.Add(Me.NumericUpDown_SetRAMRush_PerCount)
        Me.GroupBox_SetRAMRush_PerCount.Controls.Add(Me.Label15)
        Me.GroupBox_SetRAMRush_PerCount.Name = "GroupBox_SetRAMRush_PerCount"
        Me.GroupBox_SetRAMRush_PerCount.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_SetRAMRush_PerCount, resources.GetString("GroupBox_SetRAMRush_PerCount.ToolTip"))
        '
        'NumericUpDown_SetRAMRush_PerCount
        '
        resources.ApplyResources(Me.NumericUpDown_SetRAMRush_PerCount, "NumericUpDown_SetRAMRush_PerCount")
        Me.NumericUpDown_SetRAMRush_PerCount.Name = "NumericUpDown_SetRAMRush_PerCount"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_SetRAMRush_PerCount, resources.GetString("NumericUpDown_SetRAMRush_PerCount.ToolTip"))
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        Me.ToolTip1.SetToolTip(Me.Label15, resources.GetString("Label15.ToolTip"))
        '
        'GroupBox_BlobAnalysis_Setting
        '
        resources.ApplyResources(Me.GroupBox_BlobAnalysis_Setting, "GroupBox_BlobAnalysis_Setting")
        Me.GroupBox_BlobAnalysis_Setting.Controls.Add(Me.CheckBox_DetailOutput)
        Me.GroupBox_BlobAnalysis_Setting.Controls.Add(Me.RadioButton_BlobAnalysis_MIL)
        Me.GroupBox_BlobAnalysis_Setting.Controls.Add(Me.RadioButton_BlobAnalysis_CUDA)
        Me.GroupBox_BlobAnalysis_Setting.Name = "GroupBox_BlobAnalysis_Setting"
        Me.GroupBox_BlobAnalysis_Setting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_BlobAnalysis_Setting, resources.GetString("GroupBox_BlobAnalysis_Setting.ToolTip"))
        '
        'CheckBox_DetailOutput
        '
        resources.ApplyResources(Me.CheckBox_DetailOutput, "CheckBox_DetailOutput")
        Me.CheckBox_DetailOutput.Name = "CheckBox_DetailOutput"
        Me.ToolTip1.SetToolTip(Me.CheckBox_DetailOutput, resources.GetString("CheckBox_DetailOutput.ToolTip"))
        Me.CheckBox_DetailOutput.UseVisualStyleBackColor = True
        '
        'RadioButton_BlobAnalysis_MIL
        '
        resources.ApplyResources(Me.RadioButton_BlobAnalysis_MIL, "RadioButton_BlobAnalysis_MIL")
        Me.RadioButton_BlobAnalysis_MIL.Name = "RadioButton_BlobAnalysis_MIL"
        Me.RadioButton_BlobAnalysis_MIL.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_BlobAnalysis_MIL, resources.GetString("RadioButton_BlobAnalysis_MIL.ToolTip"))
        Me.RadioButton_BlobAnalysis_MIL.UseVisualStyleBackColor = True
        '
        'RadioButton_BlobAnalysis_CUDA
        '
        resources.ApplyResources(Me.RadioButton_BlobAnalysis_CUDA, "RadioButton_BlobAnalysis_CUDA")
        Me.RadioButton_BlobAnalysis_CUDA.Name = "RadioButton_BlobAnalysis_CUDA"
        Me.RadioButton_BlobAnalysis_CUDA.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_BlobAnalysis_CUDA, resources.GetString("RadioButton_BlobAnalysis_CUDA.ToolTip"))
        Me.RadioButton_BlobAnalysis_CUDA.UseVisualStyleBackColor = True
        '
        'GroupBox_ExposureTime_Setting
        '
        resources.ApplyResources(Me.GroupBox_ExposureTime_Setting, "GroupBox_ExposureTime_Setting")
        Me.GroupBox_ExposureTime_Setting.Controls.Add(Me.Label25)
        Me.GroupBox_ExposureTime_Setting.Controls.Add(Me.TextBox_Max_ExposureTime)
        Me.GroupBox_ExposureTime_Setting.Controls.Add(Me.Label24)
        Me.GroupBox_ExposureTime_Setting.Name = "GroupBox_ExposureTime_Setting"
        Me.GroupBox_ExposureTime_Setting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_ExposureTime_Setting, resources.GetString("GroupBox_ExposureTime_Setting.ToolTip"))
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        Me.ToolTip1.SetToolTip(Me.Label25, resources.GetString("Label25.ToolTip"))
        '
        'TextBox_Max_ExposureTime
        '
        resources.ApplyResources(Me.TextBox_Max_ExposureTime, "TextBox_Max_ExposureTime")
        Me.TextBox_Max_ExposureTime.Name = "TextBox_Max_ExposureTime"
        Me.ToolTip1.SetToolTip(Me.TextBox_Max_ExposureTime, resources.GetString("TextBox_Max_ExposureTime.ToolTip"))
        '
        'Label24
        '
        resources.ApplyResources(Me.Label24, "Label24")
        Me.Label24.Name = "Label24"
        Me.ToolTip1.SetToolTip(Me.Label24, resources.GetString("Label24.ToolTip"))
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_Enhance)
        Me.GroupBox1.Controls.Add(Me.Label26)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_Enlarge)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox1, resources.GetString("GroupBox1.ToolTip"))
        '
        'NumericUpDown_Enhance
        '
        resources.ApplyResources(Me.NumericUpDown_Enhance, "NumericUpDown_Enhance")
        Me.NumericUpDown_Enhance.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_Enhance.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_Enhance.Name = "NumericUpDown_Enhance"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_Enhance, resources.GetString("NumericUpDown_Enhance.ToolTip"))
        Me.NumericUpDown_Enhance.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label26
        '
        resources.ApplyResources(Me.Label26, "Label26")
        Me.Label26.Name = "Label26"
        Me.ToolTip1.SetToolTip(Me.Label26, resources.GetString("Label26.ToolTip"))
        '
        'NumericUpDown_Enlarge
        '
        resources.ApplyResources(Me.NumericUpDown_Enlarge, "NumericUpDown_Enlarge")
        Me.NumericUpDown_Enlarge.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_Enlarge.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Enlarge.Name = "NumericUpDown_Enlarge"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_Enlarge, resources.GetString("NumericUpDown_Enlarge.ToolTip"))
        Me.NumericUpDown_Enlarge.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label23
        '
        resources.ApplyResources(Me.Label23, "Label23")
        Me.Label23.Name = "Label23"
        Me.ToolTip1.SetToolTip(Me.Label23, resources.GetString("Label23.ToolTip"))
        '
        'GroupBox_MasterSlaveMode
        '
        resources.ApplyResources(Me.GroupBox_MasterSlaveMode, "GroupBox_MasterSlaveMode")
        Me.GroupBox_MasterSlaveMode.Controls.Add(Me.CheckBox_MasterSlaveMode_Enable)
        Me.GroupBox_MasterSlaveMode.Controls.Add(Me.RadioButton_SlaveMode)
        Me.GroupBox_MasterSlaveMode.Controls.Add(Me.RadioButton_MasterMode)
        Me.GroupBox_MasterSlaveMode.Name = "GroupBox_MasterSlaveMode"
        Me.GroupBox_MasterSlaveMode.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_MasterSlaveMode, resources.GetString("GroupBox_MasterSlaveMode.ToolTip"))
        '
        'CheckBox_MasterSlaveMode_Enable
        '
        resources.ApplyResources(Me.CheckBox_MasterSlaveMode_Enable, "CheckBox_MasterSlaveMode_Enable")
        Me.CheckBox_MasterSlaveMode_Enable.Name = "CheckBox_MasterSlaveMode_Enable"
        Me.ToolTip1.SetToolTip(Me.CheckBox_MasterSlaveMode_Enable, resources.GetString("CheckBox_MasterSlaveMode_Enable.ToolTip"))
        Me.CheckBox_MasterSlaveMode_Enable.UseVisualStyleBackColor = True
        '
        'RadioButton_SlaveMode
        '
        resources.ApplyResources(Me.RadioButton_SlaveMode, "RadioButton_SlaveMode")
        Me.RadioButton_SlaveMode.Name = "RadioButton_SlaveMode"
        Me.RadioButton_SlaveMode.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_SlaveMode, resources.GetString("RadioButton_SlaveMode.ToolTip"))
        Me.RadioButton_SlaveMode.UseVisualStyleBackColor = True
        '
        'RadioButton_MasterMode
        '
        resources.ApplyResources(Me.RadioButton_MasterMode, "RadioButton_MasterMode")
        Me.RadioButton_MasterMode.Checked = True
        Me.RadioButton_MasterMode.Name = "RadioButton_MasterMode"
        Me.RadioButton_MasterMode.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_MasterMode, resources.GetString("RadioButton_MasterMode.ToolTip"))
        Me.RadioButton_MasterMode.UseVisualStyleBackColor = True
        '
        'GroupBox_CCD_Link_Type
        '
        resources.ApplyResources(Me.GroupBox_CCD_Link_Type, "GroupBox_CCD_Link_Type")
        Me.GroupBox_CCD_Link_Type.Controls.Add(Me.RadioButton_CCD_Link_CXP)
        Me.GroupBox_CCD_Link_Type.Controls.Add(Me.TextBox_GigE_SerialNum)
        Me.GroupBox_CCD_Link_Type.Controls.Add(Me.RadioButton_CCD_Link_GigE)
        Me.GroupBox_CCD_Link_Type.Controls.Add(Me.RadioButton_CCD_Link_CameraLink)
        Me.GroupBox_CCD_Link_Type.Name = "GroupBox_CCD_Link_Type"
        Me.GroupBox_CCD_Link_Type.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_CCD_Link_Type, resources.GetString("GroupBox_CCD_Link_Type.ToolTip"))
        '
        'RadioButton_CCD_Link_CXP
        '
        resources.ApplyResources(Me.RadioButton_CCD_Link_CXP, "RadioButton_CCD_Link_CXP")
        Me.RadioButton_CCD_Link_CXP.Name = "RadioButton_CCD_Link_CXP"
        Me.ToolTip1.SetToolTip(Me.RadioButton_CCD_Link_CXP, resources.GetString("RadioButton_CCD_Link_CXP.ToolTip"))
        Me.RadioButton_CCD_Link_CXP.UseVisualStyleBackColor = True
        '
        'TextBox_GigE_SerialNum
        '
        resources.ApplyResources(Me.TextBox_GigE_SerialNum, "TextBox_GigE_SerialNum")
        Me.TextBox_GigE_SerialNum.Name = "TextBox_GigE_SerialNum"
        Me.ToolTip1.SetToolTip(Me.TextBox_GigE_SerialNum, resources.GetString("TextBox_GigE_SerialNum.ToolTip"))
        '
        'RadioButton_CCD_Link_GigE
        '
        resources.ApplyResources(Me.RadioButton_CCD_Link_GigE, "RadioButton_CCD_Link_GigE")
        Me.RadioButton_CCD_Link_GigE.Name = "RadioButton_CCD_Link_GigE"
        Me.ToolTip1.SetToolTip(Me.RadioButton_CCD_Link_GigE, resources.GetString("RadioButton_CCD_Link_GigE.ToolTip"))
        Me.RadioButton_CCD_Link_GigE.UseVisualStyleBackColor = True
        '
        'RadioButton_CCD_Link_CameraLink
        '
        resources.ApplyResources(Me.RadioButton_CCD_Link_CameraLink, "RadioButton_CCD_Link_CameraLink")
        Me.RadioButton_CCD_Link_CameraLink.Checked = True
        Me.RadioButton_CCD_Link_CameraLink.Name = "RadioButton_CCD_Link_CameraLink"
        Me.RadioButton_CCD_Link_CameraLink.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_CCD_Link_CameraLink, resources.GetString("RadioButton_CCD_Link_CameraLink.ToolTip"))
        Me.RadioButton_CCD_Link_CameraLink.UseVisualStyleBackColor = True
        '
        'GroupBox_DigitizerType
        '
        resources.ApplyResources(Me.GroupBox_DigitizerType, "GroupBox_DigitizerType")
        Me.GroupBox_DigitizerType.Controls.Add(Me.CheckBox_IsPacked)
        Me.GroupBox_DigitizerType.Controls.Add(Me.CheckBox_EnablePCA)
        Me.GroupBox_DigitizerType.Controls.Add(Me.RadioButton_DigitizerType_Color)
        Me.GroupBox_DigitizerType.Controls.Add(Me.RadioButton_DigitizerType_Mono)
        Me.GroupBox_DigitizerType.Name = "GroupBox_DigitizerType"
        Me.GroupBox_DigitizerType.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_DigitizerType, resources.GetString("GroupBox_DigitizerType.ToolTip"))
        '
        'CheckBox_IsPacked
        '
        resources.ApplyResources(Me.CheckBox_IsPacked, "CheckBox_IsPacked")
        Me.CheckBox_IsPacked.Name = "CheckBox_IsPacked"
        Me.ToolTip1.SetToolTip(Me.CheckBox_IsPacked, resources.GetString("CheckBox_IsPacked.ToolTip"))
        Me.CheckBox_IsPacked.UseVisualStyleBackColor = True
        '
        'CheckBox_EnablePCA
        '
        resources.ApplyResources(Me.CheckBox_EnablePCA, "CheckBox_EnablePCA")
        Me.CheckBox_EnablePCA.Name = "CheckBox_EnablePCA"
        Me.ToolTip1.SetToolTip(Me.CheckBox_EnablePCA, resources.GetString("CheckBox_EnablePCA.ToolTip"))
        Me.CheckBox_EnablePCA.UseVisualStyleBackColor = True
        '
        'RadioButton_DigitizerType_Color
        '
        resources.ApplyResources(Me.RadioButton_DigitizerType_Color, "RadioButton_DigitizerType_Color")
        Me.RadioButton_DigitizerType_Color.Name = "RadioButton_DigitizerType_Color"
        Me.RadioButton_DigitizerType_Color.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_DigitizerType_Color, resources.GetString("RadioButton_DigitizerType_Color.ToolTip"))
        Me.RadioButton_DigitizerType_Color.UseVisualStyleBackColor = True
        '
        'RadioButton_DigitizerType_Mono
        '
        resources.ApplyResources(Me.RadioButton_DigitizerType_Mono, "RadioButton_DigitizerType_Mono")
        Me.RadioButton_DigitizerType_Mono.Checked = True
        Me.RadioButton_DigitizerType_Mono.Name = "RadioButton_DigitizerType_Mono"
        Me.RadioButton_DigitizerType_Mono.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_DigitizerType_Mono, resources.GetString("RadioButton_DigitizerType_Mono.ToolTip"))
        Me.RadioButton_DigitizerType_Mono.UseVisualStyleBackColor = True
        '
        'GroupBox_BayerPattern
        '
        resources.ApplyResources(Me.GroupBox_BayerPattern, "GroupBox_BayerPattern")
        Me.GroupBox_BayerPattern.Controls.Add(Me.RadioButton_BayerPattern_Red_Green)
        Me.GroupBox_BayerPattern.Controls.Add(Me.RadioButton_BayerPattern_Green_Red)
        Me.GroupBox_BayerPattern.Controls.Add(Me.RadioButton_BayerPattern_Green_Blue)
        Me.GroupBox_BayerPattern.Controls.Add(Me.RadioButton_BayerPattern_Blue_Green)
        Me.GroupBox_BayerPattern.Name = "GroupBox_BayerPattern"
        Me.GroupBox_BayerPattern.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_BayerPattern, resources.GetString("GroupBox_BayerPattern.ToolTip"))
        '
        'RadioButton_BayerPattern_Red_Green
        '
        resources.ApplyResources(Me.RadioButton_BayerPattern_Red_Green, "RadioButton_BayerPattern_Red_Green")
        Me.RadioButton_BayerPattern_Red_Green.Name = "RadioButton_BayerPattern_Red_Green"
        Me.RadioButton_BayerPattern_Red_Green.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_BayerPattern_Red_Green, resources.GetString("RadioButton_BayerPattern_Red_Green.ToolTip"))
        Me.RadioButton_BayerPattern_Red_Green.UseVisualStyleBackColor = True
        '
        'RadioButton_BayerPattern_Green_Red
        '
        resources.ApplyResources(Me.RadioButton_BayerPattern_Green_Red, "RadioButton_BayerPattern_Green_Red")
        Me.RadioButton_BayerPattern_Green_Red.Name = "RadioButton_BayerPattern_Green_Red"
        Me.RadioButton_BayerPattern_Green_Red.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_BayerPattern_Green_Red, resources.GetString("RadioButton_BayerPattern_Green_Red.ToolTip"))
        Me.RadioButton_BayerPattern_Green_Red.UseVisualStyleBackColor = True
        '
        'RadioButton_BayerPattern_Green_Blue
        '
        resources.ApplyResources(Me.RadioButton_BayerPattern_Green_Blue, "RadioButton_BayerPattern_Green_Blue")
        Me.RadioButton_BayerPattern_Green_Blue.Name = "RadioButton_BayerPattern_Green_Blue"
        Me.RadioButton_BayerPattern_Green_Blue.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_BayerPattern_Green_Blue, resources.GetString("RadioButton_BayerPattern_Green_Blue.ToolTip"))
        Me.RadioButton_BayerPattern_Green_Blue.UseVisualStyleBackColor = True
        '
        'RadioButton_BayerPattern_Blue_Green
        '
        resources.ApplyResources(Me.RadioButton_BayerPattern_Blue_Green, "RadioButton_BayerPattern_Blue_Green")
        Me.RadioButton_BayerPattern_Blue_Green.Name = "RadioButton_BayerPattern_Blue_Green"
        Me.RadioButton_BayerPattern_Blue_Green.TabStop = True
        Me.ToolTip1.SetToolTip(Me.RadioButton_BayerPattern_Blue_Green, resources.GetString("RadioButton_BayerPattern_Blue_Green.ToolTip"))
        Me.RadioButton_BayerPattern_Blue_Green.UseVisualStyleBackColor = True
        '
        'GroupBox_Grid_Calibration_Setting
        '
        resources.ApplyResources(Me.GroupBox_Grid_Calibration_Setting, "GroupBox_Grid_Calibration_Setting")
        Me.GroupBox_Grid_Calibration_Setting.Controls.Add(Me.CheckBox_Grid_Calibration_Enable)
        Me.GroupBox_Grid_Calibration_Setting.Name = "GroupBox_Grid_Calibration_Setting"
        Me.GroupBox_Grid_Calibration_Setting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_Grid_Calibration_Setting, resources.GetString("GroupBox_Grid_Calibration_Setting.ToolTip"))
        '
        'CheckBox_Grid_Calibration_Enable
        '
        resources.ApplyResources(Me.CheckBox_Grid_Calibration_Enable, "CheckBox_Grid_Calibration_Enable")
        Me.CheckBox_Grid_Calibration_Enable.Name = "CheckBox_Grid_Calibration_Enable"
        Me.ToolTip1.SetToolTip(Me.CheckBox_Grid_Calibration_Enable, resources.GetString("CheckBox_Grid_Calibration_Enable.ToolTip"))
        Me.CheckBox_Grid_Calibration_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_Icon_Setting
        '
        resources.ApplyResources(Me.GroupBox_Icon_Setting, "GroupBox_Icon_Setting")
        Me.GroupBox_Icon_Setting.Controls.Add(Me.CheckBox_IP_Hide_To_Icon)
        Me.GroupBox_Icon_Setting.Controls.Add(Me.CheckBox_AreaGrabber_Hide_To_Icon)
        Me.GroupBox_Icon_Setting.Name = "GroupBox_Icon_Setting"
        Me.GroupBox_Icon_Setting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_Icon_Setting, resources.GetString("GroupBox_Icon_Setting.ToolTip"))
        '
        'CheckBox_IP_Hide_To_Icon
        '
        resources.ApplyResources(Me.CheckBox_IP_Hide_To_Icon, "CheckBox_IP_Hide_To_Icon")
        Me.CheckBox_IP_Hide_To_Icon.Name = "CheckBox_IP_Hide_To_Icon"
        Me.ToolTip1.SetToolTip(Me.CheckBox_IP_Hide_To_Icon, resources.GetString("CheckBox_IP_Hide_To_Icon.ToolTip"))
        Me.CheckBox_IP_Hide_To_Icon.UseVisualStyleBackColor = True
        '
        'CheckBox_AreaGrabber_Hide_To_Icon
        '
        resources.ApplyResources(Me.CheckBox_AreaGrabber_Hide_To_Icon, "CheckBox_AreaGrabber_Hide_To_Icon")
        Me.CheckBox_AreaGrabber_Hide_To_Icon.Name = "CheckBox_AreaGrabber_Hide_To_Icon"
        Me.ToolTip1.SetToolTip(Me.CheckBox_AreaGrabber_Hide_To_Icon, resources.GetString("CheckBox_AreaGrabber_Hide_To_Icon.ToolTip"))
        Me.CheckBox_AreaGrabber_Hide_To_Icon.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.TextBox_ShiftCCD_ComPort)
        Me.GroupBox2.Controls.Add(Me.ComboBox_ShiftCCD_Stage)
        Me.GroupBox2.Controls.Add(Me.Label28)
        Me.GroupBox2.Controls.Add(Me.CheckBox_ShiftCCD_IsShiftCCD)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox2, resources.GetString("GroupBox2.ToolTip"))
        '
        'TextBox_ShiftCCD_ComPort
        '
        resources.ApplyResources(Me.TextBox_ShiftCCD_ComPort, "TextBox_ShiftCCD_ComPort")
        Me.TextBox_ShiftCCD_ComPort.Name = "TextBox_ShiftCCD_ComPort"
        Me.ToolTip1.SetToolTip(Me.TextBox_ShiftCCD_ComPort, resources.GetString("TextBox_ShiftCCD_ComPort.ToolTip"))
        '
        'ComboBox_ShiftCCD_Stage
        '
        resources.ApplyResources(Me.ComboBox_ShiftCCD_Stage, "ComboBox_ShiftCCD_Stage")
        Me.ComboBox_ShiftCCD_Stage.FormattingEnabled = True
        Me.ComboBox_ShiftCCD_Stage.Items.AddRange(New Object() {resources.GetString("ComboBox_ShiftCCD_Stage.Items"), resources.GetString("ComboBox_ShiftCCD_Stage.Items1"), resources.GetString("ComboBox_ShiftCCD_Stage.Items2")})
        Me.ComboBox_ShiftCCD_Stage.Name = "ComboBox_ShiftCCD_Stage"
        Me.ToolTip1.SetToolTip(Me.ComboBox_ShiftCCD_Stage, resources.GetString("ComboBox_ShiftCCD_Stage.ToolTip"))
        '
        'Label28
        '
        resources.ApplyResources(Me.Label28, "Label28")
        Me.Label28.Name = "Label28"
        Me.ToolTip1.SetToolTip(Me.Label28, resources.GetString("Label28.ToolTip"))
        '
        'CheckBox_ShiftCCD_IsShiftCCD
        '
        resources.ApplyResources(Me.CheckBox_ShiftCCD_IsShiftCCD, "CheckBox_ShiftCCD_IsShiftCCD")
        Me.CheckBox_ShiftCCD_IsShiftCCD.Name = "CheckBox_ShiftCCD_IsShiftCCD"
        Me.ToolTip1.SetToolTip(Me.CheckBox_ShiftCCD_IsShiftCCD, resources.GetString("CheckBox_ShiftCCD_IsShiftCCD.ToolTip"))
        Me.CheckBox_ShiftCCD_IsShiftCCD.UseVisualStyleBackColor = True
        '
        'Label18
        '
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        Me.ToolTip1.SetToolTip(Me.Label18, resources.GetString("Label18.ToolTip"))
        '
        'GroupBox3
        '
        resources.ApplyResources(Me.GroupBox3, "GroupBox3")
        Me.GroupBox3.Controls.Add(Me.ComboBox_TriggerMode)
        Me.GroupBox3.Controls.Add(Me.Label29)
        Me.GroupBox3.Controls.Add(Me.CheckBox_WaitGrabEnd)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox3, resources.GetString("GroupBox3.ToolTip"))
        '
        'ComboBox_TriggerMode
        '
        resources.ApplyResources(Me.ComboBox_TriggerMode, "ComboBox_TriggerMode")
        Me.ComboBox_TriggerMode.FormattingEnabled = True
        Me.ComboBox_TriggerMode.Items.AddRange(New Object() {resources.GetString("ComboBox_TriggerMode.Items"), resources.GetString("ComboBox_TriggerMode.Items1")})
        Me.ComboBox_TriggerMode.Name = "ComboBox_TriggerMode"
        Me.ToolTip1.SetToolTip(Me.ComboBox_TriggerMode, resources.GetString("ComboBox_TriggerMode.ToolTip"))
        '
        'Label29
        '
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Name = "Label29"
        Me.ToolTip1.SetToolTip(Me.Label29, resources.GetString("Label29.ToolTip"))
        '
        'CheckBox_WaitGrabEnd
        '
        resources.ApplyResources(Me.CheckBox_WaitGrabEnd, "CheckBox_WaitGrabEnd")
        Me.CheckBox_WaitGrabEnd.Name = "CheckBox_WaitGrabEnd"
        Me.ToolTip1.SetToolTip(Me.CheckBox_WaitGrabEnd, resources.GetString("CheckBox_WaitGrabEnd.ToolTip"))
        Me.CheckBox_WaitGrabEnd.UseVisualStyleBackColor = True
        '
        'FolderBrowserDialog
        '
        resources.ApplyResources(Me.FolderBrowserDialog, "FolderBrowserDialog")
        '
        'Dialog_IPBootConfig
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox_Icon_Setting)
        Me.Controls.Add(Me.GroupBox_Grid_Calibration_Setting)
        Me.Controls.Add(Me.GroupBox_BayerPattern)
        Me.Controls.Add(Me.GroupBox_DigitizerType)
        Me.Controls.Add(Me.GroupBox_CCD_Link_Type)
        Me.Controls.Add(Me.GroupBox_MasterSlaveMode)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox_ExposureTime_Setting)
        Me.Controls.Add(Me.GroupBox_BlobAnalysis_Setting)
        Me.Controls.Add(Me.GroupBox_SetRAMRush_PerCount)
        Me.Controls.Add(Me.GroupBox_ImagePath_Setting)
        Me.Controls.Add(Me.GroupBox_DefectNumSetting)
        Me.Controls.Add(Me.GroupBox_PanelRotation)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.GroupBox_PanelTransferSetting)
        Me.Controls.Add(Me.GroupBox_FunctionEnable)
        Me.Controls.Add(Me.GroupBox_RecipePath_Setting)
        Me.Controls.Add(Me.GroupBox_IPSetting)
        Me.Controls.Add(Me.GroupBox_DigitizerSetting)
        Me.Controls.Add(Me.GroupBox_CardSetting)
        Me.Name = "Dialog_IPBootConfig"
        Me.ToolTip1.SetToolTip(Me, resources.GetString("$this.ToolTip"))
        Me.GroupBox_CardSetting.ResumeLayout(False)
        Me.GroupBox_CardSetting.PerformLayout()
        Me.GroupBox_DigitizerSetting.ResumeLayout(False)
        Me.GroupBox_DigitizerSetting.PerformLayout()
        Me.GroupBox_IPSetting.ResumeLayout(False)
        Me.GroupBox_IPSetting.PerformLayout()
        CType(Me.NumericUpDown_InitialDelayTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_RecipePath_Setting.ResumeLayout(False)
        Me.GroupBox_RecipePath_Setting.PerformLayout()
        Me.GroupBox_FunctionEnable.ResumeLayout(False)
        Me.GroupBox_FuncSelection.ResumeLayout(False)
        Me.GroupBox_FuncSelection.PerformLayout()
        Me.GroupBox_LogSetting.ResumeLayout(False)
        Me.GroupBox_LogSetting.PerformLayout()
        Me.GroupBox_PanelTransferSetting.ResumeLayout(False)
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox_PanelRotation.ResumeLayout(False)
        Me.GroupBox_PanelRotation.PerformLayout()
        Me.GroupBox_DefectNumSetting.ResumeLayout(False)
        Me.GroupBox_DefectNumSetting.PerformLayout()
        Me.GroupBox_ImagePath_Setting.ResumeLayout(False)
        Me.GroupBox_ImagePath_Setting.PerformLayout()
        CType(Me.NumericUpDown_ResizeBMPCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_SetRAMRush_PerCount.ResumeLayout(False)
        Me.GroupBox_SetRAMRush_PerCount.PerformLayout()
        CType(Me.NumericUpDown_SetRAMRush_PerCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BlobAnalysis_Setting.ResumeLayout(False)
        Me.GroupBox_BlobAnalysis_Setting.PerformLayout()
        Me.GroupBox_ExposureTime_Setting.ResumeLayout(False)
        Me.GroupBox_ExposureTime_Setting.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.NumericUpDown_Enhance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Enlarge, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MasterSlaveMode.ResumeLayout(False)
        Me.GroupBox_MasterSlaveMode.PerformLayout()
        Me.GroupBox_CCD_Link_Type.ResumeLayout(False)
        Me.GroupBox_CCD_Link_Type.PerformLayout()
        Me.GroupBox_DigitizerType.ResumeLayout(False)
        Me.GroupBox_DigitizerType.PerformLayout()
        Me.GroupBox_BayerPattern.ResumeLayout(False)
        Me.GroupBox_BayerPattern.PerformLayout()
        Me.GroupBox_Grid_Calibration_Setting.ResumeLayout(False)
        Me.GroupBox_Grid_Calibration_Setting.PerformLayout()
        Me.GroupBox_Icon_Setting.ResumeLayout(False)
        Me.GroupBox_Icon_Setting.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox_CardSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CardSystem As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CardSystemDeviceNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox_GPUDeviceNumber As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_DigitizerSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox_DigitizerFormat As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox_DigitizerFormatForTrigger As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox_DigitizerDeviceNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Digitizer_Datadepth As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox_ImageSizeX As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox_ImageSizeY As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_IPSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CCDNo As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TextBox_GrabNo As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_RecipePath_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox_RecipePath As System.Windows.Forms.TextBox
    Friend WithEvents Button_RecipePath As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Button_DataRootPath As System.Windows.Forms.Button
    Friend WithEvents TextBox_DataRootPath As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Button_RamDiskPath As System.Windows.Forms.Button
    Friend WithEvents TextBox_RamDiskPath As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_FunctionEnable As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_LogSetting As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_SubSystem_Log As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_WriteToLog1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_WriteToLog2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_TimeLog As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_FuncSelection As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_MuraUI As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FuncUI As System.Windows.Forms.CheckBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Authority As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_PanelTransferSetting As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_PanelTransfer As System.Windows.Forms.ComboBox
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents GroupBox_PanelRotation As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_PanelRotate90 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_DefectNumSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MuraDefects_Max As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_FuncDefects_Max As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_ImagePath_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Button_DefectPath As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox_DefectPath As System.Windows.Forms.TextBox
    Friend WithEvents Button_ImagePath As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox_ImagePath As System.Windows.Forms.TextBox
    Friend WithEvents FolderBrowserDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents Button_ImagePath2 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBox_ImagePath2 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_SetRAMRush_PerCount As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_SetRAMRush_PerCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_AutoDeleteFile As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Save_Mura_DefectImage As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Save_Func_DefectImage As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_PLMarkUI As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_BlobAnalysis_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BlobAnalysis_MIL As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BlobAnalysis_CUDA As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_ExposureTime_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Max_ExposureTime As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Enhance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Enlarge As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_DetailOutput As System.Windows.Forms.CheckBox
    Friend WithEvents Button_CharacteristicPath As System.Windows.Forms.Button
    Friend WithEvents TextBox_CharacteristicPath As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_MasterSlaveMode As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_SlaveMode As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_MasterMode As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_MasterSlaveMode_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_CCD_Link_Type As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_GigE_SerialNum As System.Windows.Forms.TextBox
    Friend WithEvents RadioButton_CCD_Link_GigE As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_CCD_Link_CameraLink As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_DigitizerType As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_DigitizerType_Color As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DigitizerType_Mono As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_BayerPattern As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BayerPattern_Blue_Green As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BayerPattern_Red_Green As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BayerPattern_Green_Red As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BayerPattern_Green_Blue As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_MaskMarkUI As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_TPMarkUI As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Grid_Calibration_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_Grid_Calibration_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Icon_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_AreaGrabber_Hide_To_Icon As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_IP_Hide_To_Icon As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_ShiftCCD_ComPort As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox_ShiftCCD_Stage As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_ShiftCCD_IsShiftCCD As System.Windows.Forms.CheckBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_TriggerMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_WaitGrabEnd As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_BarcodeUI As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_ResizeBMPCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_ResizeBMPPath As System.Windows.Forms.Button
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox_ResizeBMPPath As System.Windows.Forms.TextBox
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_InitialDelayTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_EnablePCA As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_HVValueLog As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_ShowOGDImg As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveToRam As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_IsPacked As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_LocalGrab As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_CCD_Link_CXP As System.Windows.Forms.RadioButton
End Class
