Imports ClassLibrary
Imports AUO.SubSystemControl
Imports System.Windows.Forms
Imports MILOperationLib
Imports System.IO

Public Class Dialog_IPNetWorkConfig
    Private m_MainProcess As ClsMainProcess
    Private m_Form As Main_Form
    Private m_ConnectedIP As ArrayList

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    Public Sub SetMainForm(ByVal form As Main_Form)
        Try
            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess

            Me.UpdateData()
            Me.UpdateUserLevel()
            Me.Update()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_IPNetWorkConfig.SetMainForm]" & ex.Message)
        End Try
    End Sub

#Region "--- Form Event ---"
    Private Sub Dialog_IPNetWorkConfig_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.m_Form.Focus()
        Me.Finalize()
    End Sub
#End Region

#Region "--- ��k�禡 ---"

#Region "--- ConnectToMultiIP ---"
    Public Function ConnectToMultiIP()
        Dim ipnwc As ClsIPNetWorkConfig
        Dim i As Integer

        Me.m_ConnectedIP = New ArrayList
        ipnwc = Me.m_MainProcess.IPNetworkConfig

        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        For i = 1 To Me.NUD_Total_IP.Value

            If DataGridView_IPNetWorkConfig.Rows(i).Cells(0).Value = True Then
                ip = New ClsIPInfo
                ip.CCDNo = i
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
                If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                    'MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.m_MainProcess.IsIPConnected = False
                Else
                    Me.m_ConnectedIP.Add(ip.CCDNo)
                End If

            End If

        Next

        If Me.m_ConnectedIP.Count >= Me.NUD_Total_IP.Value Then   '2013/06/28 Rick modufy
            'If Me.m_ConnectedIP.Count >= 1 Then
            Me.m_MainProcess.IsIPConnected = True
            Return True
        Else
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Save.Enabled = En
        Button_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                GroupBox_IPNetWork_Setting.Enabled = False
                DataGridView_IPNetWorkConfig.Enabled = False
            Case 1 'PM
                GroupBox_IPNetWork_Setting.Enabled = True
                DataGridView_IPNetWorkConfig.Enabled = True
            Case 2 'ENG
                GroupBox_IPNetWork_Setting.Enabled = True
                DataGridView_IPNetWorkConfig.Enabled = True
            Case 3 'ALL
                GroupBox_IPNetWork_Setting.Enabled = True
                DataGridView_IPNetWorkConfig.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- UpdateData ---"
    Private Sub UpdateData()
        Dim ipnwc As ClsIPNetWorkConfig
        Dim stemp(4) As String

        ipnwc = Me.m_MainProcess.IPNetworkConfig

        '--- Grabber output with OTHER condition ---
        Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.Checked = ipnwc.Grabber_Output_with_OTHER_Condition

        If DataGridView_IPNetWorkConfig.Rows.Count > 0 Then DataGridView_IPNetWorkConfig.Rows.Clear()

        '--- Total IP ---
        Me.NUD_Total_IP.Value = ipnwc.Total_IP                                 'Total IP

        '--- PatGen Port ---
        Me.TextBox_IPStart_Port.Text = ipnwc.IPStarter_Port

        '---Defect Update To Ftp ---
        Me.CheckBox_DefectUpdateToFtp.Checked = ipnwc.Defect_UpdateTo_Ftp
        Me.TextBox_FtpRootPath.Text = ipnwc.FtpRootPath

        '--- AreaGrabber ---
        stemp(1) = ipnwc.Server_IPAddress                                      'IPAddress
        stemp(2) = ipnwc.Server_Port1                                          'Port1
        stemp(3) = ipnwc.Server_Port2                                          'Port2
        stemp(4) = ipnwc.Server_MacAddress                                     'MacAddress
        DataGridView_IPNetWorkConfig.Rows.Add(stemp)
        DataGridView_IPNetWorkConfig.Rows(0).HeaderCell.Value = "AreaGrabber"  'Name
        DataGridView_IPNetWorkConfig.Rows(0).Cells(0).Value = True             'Enable

        '---All_In_One---
        Me.CheckBox_All_In_One.Checked = ipnwc.All_In_One
        Me.CheckBox_9in3.Checked = ipnwc.C9in3
        '--- IP ---
        Me.Update_IP_Info()

    End Sub

#End Region

#Region "--- Update_IP_Info ---"

    Private Sub Update_IP_Info()
        Dim i As Integer
        Dim ipnwc As ClsIPNetWorkConfig
        Dim stemp(4) As String

        ipnwc = Me.m_MainProcess.IPNetworkConfig

        '--- IP ---
        If ipnwc.NetWorkList.Count <= 0 Then
            For i = 0 To Me.NUD_Total_IP.Value - 1
                Dim ipClient As New ClsClient
                ipnwc.Add(ipClient)
                stemp(1) = "127.0.0.1"                                      'IPAddress
                stemp(2) = 9001                                             'Port1
                stemp(3) = 9002                                             'Port2
                stemp(4) = "00-00-00-00-00-00-00"                           'MacAddress
                DataGridView_IPNetWorkConfig.Rows.Add(stemp)
                DataGridView_IPNetWorkConfig.Rows(i + 1).HeaderCell.Value = "IP" & (i + 1)
            Next
        Else
            For i = 0 To ipnwc.Total_IP - 1
                stemp(1) = ipnwc.NetWorkList.Item(i).IP_IPAddress
                stemp(2) = ipnwc.NetWorkList.Item(i).IP_Port1
                stemp(3) = ipnwc.NetWorkList.Item(i).IP_Port2
                stemp(4) = ipnwc.NetWorkList.Item(i).IP_MacAddress
                DataGridView_IPNetWorkConfig.Rows.Add(stemp)
                DataGridView_IPNetWorkConfig.Rows(i + 1).HeaderCell.Value = "IP" & (i + 1)
                DataGridView_IPNetWorkConfig.Rows(i + 1).Cells(0).Value = ipnwc.NetWorkList.Item(i).IP_Enable
            Next

            For i = ipnwc.Total_IP To Me.NUD_Total_IP.Value - 1
                Dim ipClient As New ClsClient
                ipnwc.Add(ipClient)
                stemp(1) = "127.0.0.1"                                      'IPAddress
                stemp(2) = 9001                                             'Port1
                stemp(3) = 9002                                             'Port2
                stemp(4) = "00-00-00-00-00-00-00"                           'MacAddress
                DataGridView_IPNetWorkConfig.Rows.Add(stemp)
                DataGridView_IPNetWorkConfig.Rows(i + 1).HeaderCell.Value = "IP" & (i + 1)
            Next

        End If
    End Sub

#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim ipnwc As ClsIPNetWorkConfig
        Dim i As Integer
        ipnwc = Me.m_MainProcess.IPNetworkConfig

        Try
            '--- Grabber output with OTHER condition ---
            ipnwc.Grabber_Output_with_OTHER_Condition = Me.CheckBox_Export_Grabber_Output_with_OTHER_Condition.Checked

            '--- Total_IP ---
            If Me.NUD_Total_IP.Value <= 0 Then
                MsgBox("Total IP ����p��ε���0 !", MsgBoxStyle.Critical, "[AreaGrabber]")
                Exit Sub
            End If

            If ipnwc.Total_IP <> Me.NUD_Total_IP.Value Then
                '---IP No.---
                For i = Me.m_Form.ComboBox_CCD.Items.Count - 1 To 0 Step -1
                    Me.m_Form.ComboBox_CCD.Items.RemoveAt(i)
                Next
                For i = 0 To Me.m_MainProcess.IPNetworkConfig.NetWorkList.Count - 1
                    Me.m_Form.ComboBox_CCD.Items.Insert(i, i + 1)
                Next
            End If

            '--- Total IP ---
            ipnwc.Total_IP = Me.NUD_Total_IP.Value

            '--- IPStarter_Port ---
            ipnwc.IPStarter_Port = Me.TextBox_IPStart_Port.Text
            ipnwc.FtpRootPath = Me.TextBox_FtpRootPath.Text
            If Not Directory.Exists(ipnwc.FtpRootPath) Then Directory.CreateDirectory(ipnwc.FtpRootPath)

            '--- Defect Update To Ftp ---
            ipnwc.Defect_UpdateTo_Ftp = Me.CheckBox_DefectUpdateToFtp.Checked


            '--- AreaGrabber ---
            DataGridView_IPNetWorkConfig.Rows(0).Cells(0).Value = True
            ipnwc.Server_IPAddress = DataGridView_IPNetWorkConfig.Rows(0).Cells(1).Value
            ipnwc.Server_Port1 = DataGridView_IPNetWorkConfig.Rows(0).Cells(2).Value
            ipnwc.Server_Port2 = DataGridView_IPNetWorkConfig.Rows(0).Cells(3).Value
            ipnwc.Server_MacAddress = DataGridView_IPNetWorkConfig.Rows(0).Cells(4).Value

            '--- IP Group ---
            For i = 1 To Me.NUD_Total_IP.Value
                ipnwc.NetWorkList.Item(i - 1).IP_Enable = DataGridView_IPNetWorkConfig.Rows(i).Cells(0).Value
                ipnwc.NetWorkList.Item(i - 1).IP_IPAddress = DataGridView_IPNetWorkConfig.Rows(i).Cells(1).Value
                ipnwc.NetWorkList.Item(i - 1).IP_Port1 = DataGridView_IPNetWorkConfig.Rows(i).Cells(2).Value
                ipnwc.NetWorkList.Item(i - 1).IP_Port2 = DataGridView_IPNetWorkConfig.Rows(i).Cells(3).Value
                ipnwc.NetWorkList.Item(i - 1).IP_MacAddress = DataGridView_IPNetWorkConfig.Rows(i).Cells(4).Value
            Next

            '---All In One---
            ipnwc.All_In_One = Me.CheckBox_All_In_One.Checked
            ipnwc.C9in3 = Me.CheckBox_9in3.Checked

            ClsIPNetWorkConfig.WriteXML(Me.m_MainProcess.IPNetworkConfig, Me.m_MainProcess.BootRecipePath & "\IPNetWorkConfig.xml")
        Catch ex As Exception
            Throw New Exception("[Dialog_IPNetWorkConfig.Setting]Save IPNetWorkConfig file (IP - " & i & ") Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- SaveAllBootConfig ---"
    Private Sub SaveAllBootConfig()
        Dim CCDNo As Integer = 0
        Dim GrabNo As String = ""
        Dim BootRecipeFilename As String         '��m�ҰʰѼ��ɦW
        Dim IPBootConfig As New ClsIPBootConfig
        Dim ipnwc As ClsIPNetWorkConfig
        ipnwc = Me.m_MainProcess.IPNetworkConfig

        Try

            For CCDNo = 1 To Me.NUD_Total_IP.Value

                GrabNo = Trim(Str(Me.m_MainProcess.IPNetworkConfig.Total_IP)) & "_" & Trim(Str(CCDNo))

                '--- Ū��IPBootConfig ---
                BootRecipeFilename = Me.m_MainProcess.BootRecipePath & "\IPBootConfig_IP" & CCDNo & "_C" & GrabNo & ".xml"
                If System.IO.File.Exists(BootRecipeFilename) Then     ' �ˬdRecipe�����|�O�_�s�b
                    IPBootConfig = MILOperationLib.ClsIPBootConfig.ReadXML(BootRecipeFilename)
                Else
                    If GrabNo <> "" Then
                        IPBootConfig.GrabNo.Value = GrabNo
                    End If
                End If

                '--- UpdateData ---
                '--- AreaGrabber (Server) ---
                IPBootConfig.AreaGrabber_IpAddress.Value = ipnwc.Server_IPAddress
                IPBootConfig.AreaGrabber_Port1.Value = ipnwc.Server_Port1
                IPBootConfig.AreaGrabber_Port2.Value = ipnwc.Server_Port2

                '--- IP (Client) ---
                IPBootConfig.IpAddress.Value = ipnwc.NetWorkList.Item(CCDNo - 1).IP_IPAddress()
                IPBootConfig.IP_Port1.Value = ipnwc.NetWorkList.Item(CCDNo - 1).IP_Port1()
                IPBootConfig.IP_Port2.Value = ipnwc.NetWorkList.Item(CCDNo - 1).IP_Port2()

                MILOperationLib.ClsIPBootConfig.WriteXML(IPBootConfig, BootRecipeFilename)
            Next
        Catch ex As Exception
            Throw New Exception("[Dialog_IPNetWorkConfig.SaveAllBootConfig] Save All IPBootConfig Files (IP - " & CCDNo & ") Error�I(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim str As String
        Dim strs() As String
        Dim ipnwc As ClsIPNetWorkConfig
        Dim i As Integer
        Dim Parameter_Lists As String = ""
        Dim ConnectedIPNo As Integer

        Try
            '--- Button Control ---   
            Me.Button_Enable(False)

            '--- Total IP ---
            Me.m_MainProcess.IPNetworkConfig.Total_IP = Me.NUD_Total_IP.Value
            ClsIPNetWorkConfig.WriteXML(Me.m_MainProcess.IPNetworkConfig, Me.m_MainProcess.BootRecipePath & "\IPNetWorkConfig.xml")

            '--- �إ߳s�u ---
            If Not Me.ConnectToMultiIP Then
                Me.Button_Enable(True)
                Exit Sub
            End If

            Me.Setting()

            If Me.m_MainProcess.IsIPConnected Then
                '----------------------------------------------------------------------------------------------
                ' Dialog_IPNetWorkConfig Setting   ==> Request_Command = "DIALOG_IPNETWORKCONFIG_SETTING" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "DIALOG_IPNETWORKCONFIG_SETTING"
                    TimeOut = 500000 '500 secs

                    ipnwc = Me.m_MainProcess.IPNetworkConfig

                    Parameter_Lists = "AreaGrabber_IPAddress," & ipnwc.Server_IPAddress & ";" & "AreaGrabber_Port1," & ipnwc.Server_Port1 & ";" & "AreaGrabber_Port2," & ipnwc.Server_Port2 & ";" & "AreaGrabber_MacAddress," & ipnwc.Server_MacAddress
                    For i = 1 To Me.NUD_Total_IP.Value
                        If DataGridView_IPNetWorkConfig.Rows(i).Cells(0).Value = True Then
                            Parameter_Lists = Parameter_Lists & ";" & i & "," & i & ";" & "IP_IPAddress," & ipnwc.NetWorkList.Item(i - 1).IP_IPAddress & ";" & "IP_Port1," & ipnwc.NetWorkList.Item(i - 1).IP_Port1 & ";" & "IP_Port2," & ipnwc.NetWorkList.Item(i - 1).IP_Port2
                        End If
                    Next

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")

                        For i = 0 To Me.m_ConnectedIP.Count - 1
                            ConnectedIPNo = Me.m_ConnectedIP.Item(i)

                            If DataGridView_IPNetWorkConfig.Rows(ConnectedIPNo).Cells(0).Value = True Then
                                If Me.m_MainProcess.IP_Dispatcher1.IP_IsConnect(ConnectedIPNo - 1) Then
                                    str = SubSystemResult.Responses(i).Param1()
                                    strs = str.Split(",")
                                    If strs(0) = Me.m_ConnectedIP.Item(i) Then
                                        Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(ConnectedIPNo - 1).IP_MacAddress = strs(1)
                                    End If
                                End If
                            End If
                        Next

                        Response_OK = True
                    Else
                        Me.Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_IPNetWorkConfig Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_IPNetWorkConfig.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save Boot Config Recipe ==> Request_Command = "SAVE_BOOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_BOOT"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    Me.SaveAllBootConfig()

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Boot Config Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_IPNetWorkConfig.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                MessageBox.Show("1. �p���ܧ� IP Address��IP Port �]�w,�Э��s�Ұ� IP�P�۰ʭ��ҵ{�� " & Environment.NewLine & "(�ݤ�ʧ�s TaskManager.xml �ɮפ� GrabberPort),�_�h�L�k�s�u !" & Environment.NewLine & _
                                "2. �p���ܧ� IP Starter Port �]�w , �Э��s�Ұ�-�۰ʭ��ҵ{�� (C:\AOI_S\AutoTaskManagers.bat)", "����", MessageBoxButtons.OK, MessageBoxIcon.Information)

            End If

            '--- Button Control ---   
            Button_Enable(True)

            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_IPNetWorkConfig.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_IPNetWorkConfig.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region

#Region "--- Button_FtpRootPath ---"
    Private Sub Button_FtpRootPath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FtpRootPath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_FtpRootPath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_FtpRootPath.Text = Me.FolderBrowserDialog.SelectedPath
        End If
    End Sub
#End Region

#End Region

#Region "--- NumericUoDown Event ---"

#Region "--- NUD_Total_IP_ValueChanged ---"
    Private Sub NUD_Total_IP_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_Total_IP.ValueChanged
        Dim ipnwc As ClsIPNetWorkConfig
        Dim stemp(4) As String
        Dim i As Integer

        Try

            ipnwc = Me.m_MainProcess.IPNetworkConfig
            If Me.NUD_Total_IP.Value = Me.m_MainProcess.IPNetworkConfig.Total_IP + 1 Then

                Dim ipClient As New ClsClient
                ipnwc.Add(ipClient)
                stemp(1) = "127.0.0.1"                                      'IPAddress
                stemp(2) = 9001                                             'Port1
                stemp(3) = 9002                                             'Port2
                stemp(4) = "00-00-00-00-00-00-00"                           'MacAddress
                DataGridView_IPNetWorkConfig.Rows.Add(stemp)
                DataGridView_IPNetWorkConfig.Rows(Me.m_MainProcess.IPNetworkConfig.Total_IP + 1).HeaderCell.Value = "IP" & (Me.m_MainProcess.IPNetworkConfig.Total_IP + 1)
                ipnwc.Total_IP = ipnwc.Total_IP + 1
            ElseIf Me.NUD_Total_IP.Value = Me.m_MainProcess.IPNetworkConfig.Total_IP - 1 Then
                ipnwc.RemoveAt(Me.m_MainProcess.IPNetworkConfig.Total_IP - 1)
                DataGridView_IPNetWorkConfig.Rows.RemoveAt(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                ipnwc.Total_IP = ipnwc.Total_IP - 1
            ElseIf Me.NUD_Total_IP.Value > ipnwc.Total_IP + 1 Then

                If DataGridView_IPNetWorkConfig.Rows.Count > 0 Then DataGridView_IPNetWorkConfig.Rows.Clear()

                '--- AreaGrabber ---
                stemp(1) = ipnwc.Server_IPAddress                                      'IPAddress
                stemp(2) = ipnwc.Server_Port1                                          'Port1
                stemp(3) = ipnwc.Server_Port2                                          'Port2
                stemp(4) = ipnwc.Server_MacAddress                                     'MacAddress
                DataGridView_IPNetWorkConfig.Rows.Add(stemp)
                DataGridView_IPNetWorkConfig.Rows(0).HeaderCell.Value = "AreaGrabber"  'Name
                DataGridView_IPNetWorkConfig.Rows(0).Cells(0).Value = True             'Enable

                '--- IP 
                Me.Update_IP_Info()

            ElseIf Me.NUD_Total_IP.Value < ipnwc.Total_IP - 1 Then

                For i = ipnwc.Total_IP - 1 To Me.NUD_Total_IP.Value
                    ipnwc.RemoveAt(i)
                Next

                If DataGridView_IPNetWorkConfig.Rows.Count > 0 Then DataGridView_IPNetWorkConfig.Rows.Clear()

                '--- AreaGrabber ---
                stemp(1) = ipnwc.Server_IPAddress                                      'IPAddress
                stemp(2) = ipnwc.Server_Port1                                          'Port1
                stemp(3) = ipnwc.Server_Port2                                          'Port2
                stemp(4) = ipnwc.Server_MacAddress                                     'MacAddress
                DataGridView_IPNetWorkConfig.Rows.Add(stemp)
                DataGridView_IPNetWorkConfig.Rows(0).HeaderCell.Value = "AreaGrabber"  'Name
                DataGridView_IPNetWorkConfig.Rows(0).Cells(0).Value = True             'Enable

                For i = 0 To ipnwc.Total_IP - 1
                    stemp(1) = ipnwc.NetWorkList.Item(i).IP_IPAddress
                    stemp(2) = ipnwc.NetWorkList.Item(i).IP_Port1
                    stemp(3) = ipnwc.NetWorkList.Item(i).IP_Port2
                    stemp(4) = ipnwc.NetWorkList.Item(i).IP_MacAddress
                    DataGridView_IPNetWorkConfig.Rows.Add(stemp)
                    DataGridView_IPNetWorkConfig.Rows(i + 1).HeaderCell.Value = "IP" & (i + 1)
                    DataGridView_IPNetWorkConfig.Rows(i + 1).Cells(0).Value = ipnwc.NetWorkList.Item(i).IP_Enable
                Next

            End If

            '--- Total IP ---
            ipnwc.Total_IP = Me.NUD_Total_IP.Value                              'Total IP

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_IPNetWorkConfig.NUD_Total_IP_ValueChanged]" & ex.Message)
            MessageBox.Show("[Dialog_IPNetWorkConfig.NUD_Total_IP_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

    Private Sub CheckBox_9in3_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_9in3.CheckedChanged
        If CheckBox_9in3.Checked = True Then
            CheckBox_All_In_One.Checked = False
        End If
    End Sub

    Private Sub CheckBox_All_In_One_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_All_In_One.CheckedChanged
        If Me.CheckBox_All_In_One.Checked = True Then
            Me.CheckBox_9in3.Checked = False
        End If
    End Sub

#End Region

    

End Class