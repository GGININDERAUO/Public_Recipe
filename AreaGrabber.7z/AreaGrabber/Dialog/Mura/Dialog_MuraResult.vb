Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraResult
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_Size As Integer
    Private m_Rotate90 As Boolean
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim Image As MIL_ID = M_NULL
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraResult", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------
        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess

        If Me.m_MainProcess.IPBootConfig.PanelRotate90.Value = "true" Then
            Me.m_Rotate90 = True
        Else
            Me.m_Rotate90 = False
        End If

        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_Pen = New Pen(Color.Red)
        Me.m_SolidBrush = New SolidBrush(Color.Red)
        Me.m_Size = 15

        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
            Image = Me.m_MuraProcess.Img_16U_FFCResult_NonPage
            If Image <> M_NULL Then
                Me.m_Form.CurrentIndex1 = 1
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 0
            End If
        Else
            Image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
            If Image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If
        End If

        '--- UI ---
        Me.m_VScrollBar = Me.m_Form.VScrollBar
        Me.m_HScrollBar = Me.m_Form.HScrollBar

        Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
        Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
        Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
        Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
        '--- UI ---

        Me.m_Form.ImageUpdate()
        Me.m_Form.ImageZoomAll()
        Me.Update()
    End Sub

    Private Sub Dialog_MuraResult_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub


#Region "---��k��� ---"

#Region "--- ShowResult ---"
    Public Sub ShowResult()
        Try
            Me.ShowMuraColor()
            Me.ShowBlob()
            Me.ShowBand()
        Catch ex As Exception
            Throw New Exception("[Dialog_MuraResult.ShowResult]Show Result Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- ShowMuraColor ---"
    Private Sub ShowMuraColor()
        '--- White Blob Mura ---
        Me.LblColor_WhiteBlobMuraArrayArea.BackColor = Color.Red
        Me.LblColor_WhiteMacroMuraArrayArea.BackColor = Color.Green
        Me.LblColor_WhiteBlobMuraArrayRim.BackColor = Color.Blue

        Me.LblCount_WhiteBlobMuraArrayArea.Text = CInt(Me.m_MuraProcess.MuraGroup_All.WhiteBlobMuraArrayArea.Count)
        Me.LblCount_WhiteMacroMuraArrayArea.Text = CInt(Me.m_MuraProcess.MuraGroup_All.WhiteMacroMuraArrayArea.Count)
        Me.LblCount_WhiteBlobMuraArrayRim.Text = CInt(Me.m_MuraProcess.MuraGroup_All.WhiteBlobMuraArrayRim.Count)

        '--- Black Blob Mura ---
        Me.LblColor_BlackBlobMuraArrayArea.BackColor = Color.Cyan
        Me.LblColor_BlackMacroMuraArrayArea.BackColor = Color.Magenta
        Me.LblColor_BlackBlobMuraArrayRim.BackColor = Color.Yellow

        Me.LblCount_BlackBlobMuraArrayArea.Text = CInt(Me.m_MuraProcess.MuraGroup_All.BlackBlobMuraArrayArea.Count)
        Me.LblCount_BlackMacroMuraArrayArea.Text = CInt(Me.m_MuraProcess.MuraGroup_All.BlackMacroMuraArrayArea.Count)
        Me.LblCount_BlackBlobMuraArrayRim.Text = CInt(Me.m_MuraProcess.MuraGroup_All.BlackBlobMuraArrayRim.Count)

        '--- Band Mura ---
        Me.LblColor_WhiteVBand.BackColor = Color.Gold
        Me.LblColor_BlackVBand.BackColor = Color.Brown
        Me.LblColor_WhiteHBand.BackColor = Color.DarkTurquoise
        Me.LblColor_BlackHBand.BackColor = Color.DarkOrange

        Me.LblCount_WhiteVBand.Text = CInt(Me.m_MuraProcess.MuraGroup_All.WhiteVBand.Count)
        Me.LblCount_BlackVBand.Text = CInt(Me.m_MuraProcess.MuraGroup_All.BlackVBand.Count)
        Me.LblCount_WhiteHBand.Text = CInt(Me.m_MuraProcess.MuraGroup_All.WhiteHBand.Count)
        Me.LblCount_BlackHBand.Text = CInt(Me.m_MuraProcess.MuraGroup_All.BlackHBand.Count)

    End Sub
#End Region

#Region "--- DrawMark ---"
    Private Sub DrawMark()
        Dim image As MIL_ID = M_NULL
        Dim offX As Integer
        Dim offY As Integer
        Dim SizeX, SizeY As Integer
        Dim mmr As ClsMuraModelRecipe = Me.m_MuraProcess.MuraModelRecipe

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        offX = Me.m_MuraProcess.BoundaryOriginal.LeftX
        offY = Me.m_MuraProcess.BoundaryOriginal.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    If Me.CheckBox_ShowBlob.Checked Then
                        Me.DrawWhiteBlobArea(0, 0)
                        Me.DrawWhiteMacroArea(0, 0)
                        Me.DrawWhiteRim(0, 0)
                        Me.DrawBlackBlobArea(0, 0)
                        Me.DrawBlackMacroArea(0, 0)
                        Me.DrawBlackRim(0, 0)
                    End If
                    If Me.CheckBox_ShowBand.Checked Then

                        Me.DrawHBand(0, 0, SizeX, SizeY, Me.m_Rotate90)
                        Me.DrawVBand(0, 0, SizeX, SizeY, Me.m_Rotate90)
                    End If
                    Me.DrawSelect(0, 0)
                End If
            Case 1
                If Me.CheckBox_ShowBand.Checked Then
                    Me.DrawHBand(-offY, 0, SizeX, SizeY, Me.m_Rotate90)
                    Me.DrawVBand(-offX, 0, SizeX, SizeY, Me.m_Rotate90)
                End If
                If Me.CheckBox_ShowBlob.Checked Then
                    Select Case Me.m_Form.ComboBox_Select.SelectedIndex
                        Case 0
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 1
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 2
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 3
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 4
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                        Case 5
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 6
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                        Case 7
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                        Case 8
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 9
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 11
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 17   '2015/06/10 Rick add
                            Me.DrawWhiteRim(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                        Case 19
                            Me.DrawWhiteBlobArea(-offX, -offY)
                            Me.DrawWhiteMacroArea(-offX, -offY)
                            Me.DrawWhiteRim(-offX, -offY)
                            Me.DrawBlackBlobArea(-offX, -offY)
                            Me.DrawBlackMacroArea(-offX, -offY)
                            Me.DrawBlackRim(-offX, -offY)
                    End Select
                End If
                Me.DrawSelect(-offX, -offY)

            Case 2
                If Me.CheckBox_ShowBand.Checked Then
                    image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
                    Select Case Me.m_Form.ComboBox_Select.SelectedIndex
                        Case 0
                            Me.DrawHBand(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY - offY, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 1
                            Me.DrawHBand(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY - offY, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 2
                            Me.DrawHBand(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY - offY, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 3
                            Me.DrawHBand(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY - offY, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 4
                            Me.DrawHBand(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY - offY, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 5
                            Me.DrawHBand(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY - offY, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 6
                            Me.DrawHBand(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY - offY, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 7
                            Me.DrawVBand(-Me.m_MuraProcess.MuraModelRecipe.Band.LeftX - offX, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 8
                            Me.DrawVBand(-Me.m_MuraProcess.MuraModelRecipe.Band.LeftX - offX, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 9
                            Me.DrawVBand(-Me.m_MuraProcess.MuraModelRecipe.Band.LeftX - offX, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 10
                            Me.DrawVBand(-Me.m_MuraProcess.MuraModelRecipe.Band.LeftX - offX, 0, SizeX, SizeY, Me.m_Rotate90)
                        Case 11
                            Me.DrawVBand(-Me.m_MuraProcess.MuraModelRecipe.Band.LeftX - offX, 0, SizeX, SizeY, Me.m_Rotate90)
                    End Select
                End If
        End Select
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = False
    End Sub
#End Region

#Region "--- DrawSelect ---"
    Private Sub DrawSelect(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim maxX As Integer
        Dim maxY As Integer
        Dim minX As Integer
        Dim minY As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim BlobX As Integer
        Dim BlobY As Integer
        Dim s As Double
        Dim r As Integer
        Dim lvi As ListViewItem
        Dim rect As Rectangle

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        If s < 1 Then
            r = 1
        Else
            r = s
        End If
        rect = New Rectangle
        Me.m_SolidBrush.Color = Color.Red
        For i = 0 To Me.ListView_Blob.SelectedItems.Count - 1
            lvi = Me.ListView_Blob.SelectedItems.Item(i)
            BlobX = lvi.SubItems(6).Text
            BlobY = lvi.SubItems(7).Text

            minX = (BlobX - 0.5 * Me.m_Size - ox) * s    '2013/02/25 Rick modify
            minY = (BlobY - 0.5 * Me.m_Size - oy) * s    '2013/02/25 Rick modify
            maxX = (BlobX + 0.5 * Me.m_Size - ox) * s    '2013/02/25 Rick modify
            maxY = (BlobY + 0.5 * Me.m_Size - oy) * s    '2013/02/25 Rick modify

            If minX < bx And minX >= 0 Then
                rect.X = minX
                rect.Y = minY
                rect.Width = r
                rect.Height = maxY - minY + 1
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            If minY < by And minY >= 0 Then
                rect.X = minX
                rect.Y = minY
                rect.Width = maxX - minX + 1
                rect.Height = r
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            If maxX < bx And maxX >= 0 Then
                rect.X = maxX
                rect.Y = minY
                rect.Width = r
                rect.Height = maxY - minY + 1
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            If maxY < by And maxY >= 0 Then
                rect.X = minX
                rect.Y = maxY
                rect.Width = maxX - minX + 1
                rect.Height = r
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        Next
    End Sub
#End Region

#Region "--- ShowBlob ---"
    Private Sub ShowBlob()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim lvsic As ListViewItem.ListViewSubItemCollection
        Dim mpa As ClsMuraPositionArray
        Dim mp As ClsMuraPosition
        Me.ListView_Blob.Items.Clear()
        Try
            mpa = Me.m_MuraProcess.MuraGroup_All.WhiteBlobMuraArrayArea
            For i = 0 To mpa.Count - 1
                mp = mpa.GetMuraPosition(i)
                If mp.CPD = "C" Then
                    lvi = Me.ListView_Blob.Items.Add("Cell Particle Diffusion(����)")
                ElseIf mp.CPD = "W" Then
                    lvi = Me.ListView_Blob.Items.Add("White GAP SPOT(����)")
                Else
                    lvi = Me.ListView_Blob.Items.Add("White Blob Mura(����)")
                End If

                lvsic = lvi.SubItems
                Me.Blob_AddToListView(mp, lvsic)
            Next

            mpa = Me.m_MuraProcess.MuraGroup_All.WhiteMacroMuraArrayArea
            For i = 0 To mpa.Count - 1
                mp = mpa.GetMuraPosition(i)
                lvi = Me.ListView_Blob.Items.Add("White Macro Mura(����)")
                lvsic = lvi.SubItems
                Me.Blob_AddToListView(mp, lvsic)
            Next

            mpa = Me.m_MuraProcess.MuraGroup_All.WhiteBlobMuraArrayRim
            For i = 0 To mpa.Count - 1
                mp = mpa.GetMuraPosition(i)
                lvi = Me.ListView_Blob.Items.Add("White Blob Mura(��t)")
                lvsic = lvi.SubItems
                Me.Blob_AddToListView(mp, lvsic)
            Next

            mpa = Me.m_MuraProcess.MuraGroup_All.BlackBlobMuraArrayArea
            For i = 0 To mpa.Count - 1
                mp = mpa.GetMuraPosition(i)
                If mp.CPD = "W" Then
                    lvi = Me.ListView_Blob.Items.Add("Black GAP SPOT(����)")
                Else
                    lvi = Me.ListView_Blob.Items.Add("Black Blob Mura(����)")
                End If
                lvsic = lvi.SubItems
                Me.Blob_AddToListView(mp, lvsic)
            Next

            mpa = Me.m_MuraProcess.MuraGroup_All.BlackMacroMuraArrayArea
            For i = 0 To mpa.Count - 1
                mp = mpa.GetMuraPosition(i)
                lvi = Me.ListView_Blob.Items.Add("Black Macro Mura(����)")
                lvsic = lvi.SubItems
                Me.Blob_AddToListView(mp, lvsic)
            Next

            mpa = Me.m_MuraProcess.MuraGroup_All.BlackBlobMuraArrayRim
            For i = 0 To mpa.Count - 1
                mp = mpa.GetMuraPosition(i)
                lvi = Me.ListView_Blob.Items.Add("Black Blob Mura(��t)")
                lvsic = lvi.SubItems
                Me.Blob_AddToListView(mp, lvsic)
            Next

        Catch ex As Exception
            Throw New Exception("[Dialog_MuraResult.ShowBlob]Show Blob Error")
        End Try
    End Sub
#End Region

#Region "--- Blob_AddToListView ---"""
    Private Sub Blob_AddToListView(ByVal mp As ClsMuraPosition, ByVal lvsic As ListViewItem.ListViewSubItemCollection)
        lvsic.Add(mp.Data)
        lvsic.Add(mp.Gate)
        lvsic.Add(mp.Area)
        lvsic.Add(mp.JND.ToString("0.00"))
        lvsic.Add(mp.Rank)
        lvsic.Add(mp.CenterX.ToString("0.00"))
        lvsic.Add(mp.CenterY.ToString("0.00"))
        lvsic.Add(mp.MinData)
        lvsic.Add(mp.MinGate)
        lvsic.Add(mp.MaxData)
        lvsic.Add(mp.MaxGate)
        lvsic.Add(mp.Score.ToString("0.00"))
        lvsic.Add(mp.Elongation.ToString("0.00"))
        lvsic.Add(mp.Pattern)
        lvsic.Add(mp.GrayMin.ToString("0.00"))
        lvsic.Add(mp.GrayMax.ToString("0.00"))
        lvsic.Add(mp.Fullness.ToString("0.00"))
        lvsic.Add(mp.Compactness.ToString("0.00"))
        lvsic.Add(mp.MinFeretAngle.ToString("0.00"))
        lvsic.Add(mp.MaxGray_Fullness.ToString("0.00"))
        lvsic.Add(mp.StdDev.ToString("0.00"))
        lvsic.Add(mp.Fatness.ToString("0.00"))
        lvsic.Add(mp.Breadth.ToString("0.00"))
        lvsic.Add(mp.CPD)
    End Sub
#End Region

#Region "--- ShowBand ---"
    Private Sub ShowBand()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mpa As ClsMuraPositionArray
        Dim mp As ClsMuraPosition
        Me.ListView_Band.Items.Clear()
        mpa = Me.m_MuraProcess.MuraGroup_All.WhiteVBand
        For i = 0 To mpa.Count - 1
            mp = mpa.GetMuraPosition(i)
            lvi = Me.ListView_Band.Items.Add("White V-Band Mura")
            lvi.SubItems.Add(mp.Data)
            lvi.SubItems.Add(mp.Gate)
            lvi.SubItems.Add(mp.Area)
            lvi.SubItems.Add(mp.JND.ToString("0.00"))
            lvi.SubItems.Add(mp.Rank)
            lvi.SubItems.Add(mp.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mp.CenterY.ToString("0.00"))
            lvi.SubItems.Add(mp.MinData)
            lvi.SubItems.Add(mp.MinGate)
            lvi.SubItems.Add(mp.MaxData)
            lvi.SubItems.Add(mp.MaxGate)
            lvi.SubItems.Add(mp.Score.ToString("0.00"))
            lvi.SubItems.Add(mp.BandWidth.ToString("0.00"))
            lvi.SubItems.Add(mp.Breadth.ToString("0.00"))
        Next

        mpa = Me.m_MuraProcess.MuraGroup_All.BlackVBand
        For i = 0 To mpa.Count - 1
            mp = mpa.GetMuraPosition(i)
            lvi = Me.ListView_Band.Items.Add("Black V-Band Mura")
            lvi.SubItems.Add(mp.Data)
            lvi.SubItems.Add(mp.Gate)
            lvi.SubItems.Add(mp.Area)
            lvi.SubItems.Add(mp.JND.ToString("0.00"))
            lvi.SubItems.Add(mp.Rank)
            lvi.SubItems.Add(mp.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mp.CenterY.ToString("0.00"))
            lvi.SubItems.Add(mp.MinData)
            lvi.SubItems.Add(mp.MinGate)
            lvi.SubItems.Add(mp.MaxData)
            lvi.SubItems.Add(mp.MaxGate)
            lvi.SubItems.Add(mp.Score.ToString("0.00"))
            lvi.SubItems.Add(mp.BandWidth.ToString("0.00"))
            lvi.SubItems.Add(mp.Breadth.ToString("0.00"))
        Next

        mpa = Me.m_MuraProcess.MuraGroup_All.WhiteHBand
        For i = 0 To mpa.Count - 1
            mp = mpa.GetMuraPosition(i)
            lvi = Me.ListView_Band.Items.Add("White H-Band Mura")
            lvi.SubItems.Add(mp.Data)
            lvi.SubItems.Add(mp.Gate)
            lvi.SubItems.Add(mp.Area)
            lvi.SubItems.Add(mp.JND.ToString("0.00"))
            lvi.SubItems.Add(mp.Rank)
            lvi.SubItems.Add(mp.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mp.CenterY.ToString("0.00"))
            lvi.SubItems.Add(mp.MinData)
            lvi.SubItems.Add(mp.MinGate)
            lvi.SubItems.Add(mp.MaxData)
            lvi.SubItems.Add(mp.MaxGate)
            lvi.SubItems.Add(mp.Score.ToString("0.00"))
            lvi.SubItems.Add(mp.BandWidth.ToString("0.00"))
            lvi.SubItems.Add(mp.Breadth.ToString("0.00"))
        Next

        mpa = Me.m_MuraProcess.MuraGroup_All.BlackHBand
        For i = 0 To mpa.Count - 1
            mp = mpa.GetMuraPosition(i)
            lvi = Me.ListView_Band.Items.Add("Black H-Band Mura")
            lvi.SubItems.Add(mp.Data)
            lvi.SubItems.Add(mp.Gate)
            lvi.SubItems.Add(mp.Area)
            lvi.SubItems.Add(mp.JND.ToString("0.00"))
            lvi.SubItems.Add(mp.Rank)
            lvi.SubItems.Add(mp.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mp.CenterY.ToString("0.00"))
            lvi.SubItems.Add(mp.MinData)
            lvi.SubItems.Add(mp.MinGate)
            lvi.SubItems.Add(mp.MaxData)
            lvi.SubItems.Add(mp.MaxGate)
            lvi.SubItems.Add(mp.Score.ToString("0.00"))
            lvi.SubItems.Add(mp.BandWidth.ToString("0.00"))
            lvi.SubItems.Add(mp.Breadth.ToString("0.00"))
        Next
    End Sub
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_Ok.Text = res.GetString("Button_Ok.Text")
                CheckBox_ShowBand.Text = res.GetString("CheckBox_ShowBand.Text")
                CheckBox_ShowBlob.Text = res.GetString("CheckBox_ShowBlob.Text")
                GroupBox_MuraResult.Text = res.GetString("GroupBox_MuraResult.Text")
                Label3.Text = res.GetString("Label3.Text")
                Label6.Text = res.GetString("Label6.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- Draw Event ---"
    Private Sub m_Panel_AxMDisplay_PaintEvent(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark()
        End If
    End Sub

    Private Sub DrawWhiteBlobArea(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim muraPositionArray As ClsMuraPositionArray
        Dim muraPosition As ClsMuraPosition

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red
        muraPositionArray = Me.m_MuraProcess.MuraGroup_All.WhiteBlobMuraArrayArea
        For i = 0 To muraPositionArray.Count - 1
            muraPosition = muraPositionArray.GetMuraPosition(i)
            x = (muraPosition.CenterX - ox + 0.5) * s - hr
            y = (muraPosition.CenterY - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub
    Private Sub DrawWhiteMacroArea(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim muraPositionArray As ClsMuraPositionArray
        Dim muraPosition As ClsMuraPosition

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Green
        muraPositionArray = Me.m_MuraProcess.MuraGroup_All.WhiteMacroMuraArrayArea
        For i = 0 To muraPositionArray.Count - 1
            muraPosition = muraPositionArray.GetMuraPosition(i)
            x = (muraPosition.CenterX - ox + 0.5) * s - hr
            y = (muraPosition.CenterY - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub

    Private Sub DrawWhiteRim(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim muraPositionArray As ClsMuraPositionArray
        Dim muraPosition As ClsMuraPosition

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Blue
        muraPositionArray = Me.m_MuraProcess.MuraGroup_All.WhiteBlobMuraArrayRim
        For i = 0 To muraPositionArray.Count - 1
            muraPosition = muraPositionArray.GetMuraPosition(i)
            x = (muraPosition.CenterX - ox + 0.5) * s - hr
            y = (muraPosition.CenterY - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub

    Private Sub DrawBlackBlobArea(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim muraPositionArray As ClsMuraPositionArray
        Dim muraPosition As ClsMuraPosition

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Cyan
        muraPositionArray = Me.m_MuraProcess.MuraGroup_All.BlackBlobMuraArrayArea
        For i = 0 To muraPositionArray.Count - 1
            muraPosition = muraPositionArray.GetMuraPosition(i)
            x = (muraPosition.CenterX - ox + 0.5) * s - hr
            y = (muraPosition.CenterY - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub
    Private Sub DrawBlackMacroArea(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim muraPositionArray As ClsMuraPositionArray
        Dim muraPosition As ClsMuraPosition

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Magenta
        muraPositionArray = Me.m_MuraProcess.MuraGroup_All.BlackMacroMuraArrayArea
        For i = 0 To muraPositionArray.Count - 1
            muraPosition = muraPositionArray.GetMuraPosition(i)
            x = (muraPosition.CenterX - ox + 0.5) * s - hr
            y = (muraPosition.CenterY - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub

    Private Sub DrawBlackRim(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim muraPositionArray As ClsMuraPositionArray
        Dim muraPosition As ClsMuraPosition

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Yellow
        muraPositionArray = Me.m_MuraProcess.MuraGroup_All.BlackBlobMuraArrayRim
        For i = 0 To muraPositionArray.Count - 1
            muraPosition = muraPositionArray.GetMuraPosition(i)
            x = (muraPosition.CenterX - ox + 0.5) * s - hr
            y = (muraPosition.CenterY - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub

    Private Sub DrawHBand(ByVal offset As Integer, ByVal s As Integer, ByVal e_SizeX As Integer, ByVal e_SizeY As Integer, ByVal InverseDataGate As Boolean)
        Dim i As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim ZoomX As Double
        Dim ZoomY As Double
        Dim rect As Rectangle
        Dim muraBandArray As ClsMuraPositionArray
        Dim muraBand As ClsMuraPosition

        rect = New Rectangle
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

        muraBandArray = Me.m_MuraProcess.MuraGroup_All.WhiteHBand
        Me.m_Pen.Color = Color.DarkTurquoise
        Me.m_SolidBrush.Color = Color.DarkTurquoise
        For i = 0 To muraBandArray.Count - 1
            muraBand = muraBandArray.GetMuraPosition(i)

            If Not InverseDataGate Then
                '--- H-Band ---
                ox = Me.m_Form.HScrollBar.Value
                oy = muraBand.CenterY - Me.m_Form.VScrollBar.Value + offset
                rect.X = (muraBand.CenterX - ox - 0.5 * muraBand.BandWidth) * ZoomX
                rect.Y = oy * ZoomY

                rect.Width = (e_SizeX - s + 1) * ZoomX
                rect.Height = Math.Ceiling(muraBand.BandWidth * ZoomY)
            Else
                '--- V-Band ---
                ox = muraBand.CenterX - Me.m_Form.HScrollBar.Value + offset
                oy = Me.m_Form.VScrollBar.Value
                rect.X = ox * ZoomY
                rect.Y = (muraBand.CenterY - oy - 0.5 * muraBand.BandWidth) * ZoomX

                rect.Height = (e_SizeY - s + 1) * ZoomY
                rect.Width = Math.Ceiling(muraBand.BandWidth * ZoomX)
            End If

            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next

        muraBandArray = Me.m_MuraProcess.MuraGroup_All.BlackHBand
        Me.m_Pen.Color = Color.DarkOrange
        Me.m_SolidBrush.Color = Color.DarkOrange
        For i = 0 To muraBandArray.Count - 1
            muraBand = muraBandArray.GetMuraPosition(i)

            If Not InverseDataGate Then
                '--- H-Band ---
                ox = Me.m_Form.HScrollBar.Value
                oy = muraBand.CenterY - Me.m_Form.VScrollBar.Value + offset
                rect.X = (muraBand.CenterX - ox - 0.5 * muraBand.BandWidth) * ZoomX
                rect.Y = oy * ZoomY

                rect.Width = (e_SizeX - s + 1) * ZoomX
                rect.Height = Math.Ceiling(muraBand.BandWidth * ZoomY)
            Else
                '--- V-Band ---
                ox = muraBand.CenterX - Me.m_Form.HScrollBar.Value + offset
                oy = Me.m_Form.VScrollBar.Value
                rect.X = ox * ZoomY
                rect.Y = (muraBand.CenterY - oy - 0.5 * muraBand.BandWidth) * ZoomX

                rect.Height = (e_SizeX - s + 1) * ZoomX
                rect.Width = Math.Ceiling(muraBand.BandWidth * ZoomY)
            End If

            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next
    End Sub
    Private Sub DrawVBand(ByVal offset As Integer, ByVal s As Integer, ByVal e_SizeX As Integer, ByVal e_SizeY As Integer, ByVal InverseDataGate As Boolean)
        Dim i As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim ZoomX As Double
        Dim rect As Rectangle
        Dim muraBandArray As ClsMuraPositionArray
        Dim muraBand As ClsMuraPosition

        rect = New Rectangle
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

        muraBandArray = Me.m_MuraProcess.MuraGroup_All.WhiteVBand
        Me.m_Pen.Color = Color.Gold
        Me.m_SolidBrush.Color = Color.Gold
        For i = 0 To muraBandArray.Count - 1
            muraBand = muraBandArray.GetMuraPosition(i)

            If Not InverseDataGate Then
                '--- V Band ---
                ox = Me.m_Form.HScrollBar.Value - offset
                oy = muraBand.CenterY - Me.m_Form.VScrollBar.Value
                rect.X = (muraBand.CenterX - ox - 0.5 * muraBand.BandWidth) * ZoomX
                rect.Y = oy * ZoomX

                rect.Width = Math.Ceiling(muraBand.BandWidth * ZoomX)
                rect.Height = (e_SizeY - s + 1) * ZoomX
            Else
                '--- H Band ---
                ox = muraBand.CenterX - Me.m_Form.HScrollBar.Value
                oy = Me.m_Form.VScrollBar.Value - offset
                rect.X = ox * ZoomX
                rect.Y = (muraBand.CenterY - oy - 0.5 * muraBand.BandWidth) * ZoomX

                rect.Height = Math.Ceiling(muraBand.BandWidth * ZoomX)
                rect.Width = (e_SizeX - s + 1) * ZoomX
            End If

            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next

        muraBandArray = Me.m_MuraProcess.MuraGroup_All.BlackVBand
        Me.m_Pen.Color = Color.Brown
        Me.m_SolidBrush.Color = Color.Brown
        For i = 0 To muraBandArray.Count - 1
            muraBand = muraBandArray.GetMuraPosition(i)

            If Not InverseDataGate Then
                '--- V Band ---
                ox = Me.m_Form.HScrollBar.Value - offset
                oy = muraBand.CenterY - Me.m_Form.VScrollBar.Value
                rect.X = (muraBand.CenterX - ox - 0.5 * muraBand.BandWidth) * ZoomX
                rect.Y = oy * ZoomX

                rect.Width = Math.Ceiling(muraBand.BandWidth * ZoomX)
                rect.Height = (e_SizeY - s + 1) * ZoomX
            Else
                '--- H Band ---
                ox = muraBand.CenterX - Me.m_Form.HScrollBar.Value
                oy = Me.m_Form.VScrollBar.Value - offset
                rect.X = ox * ZoomX
                rect.Y = (muraBand.CenterY - oy - 0.5 * muraBand.BandWidth) * ZoomX

                rect.Height = Math.Ceiling(muraBand.BandWidth * ZoomX)
                rect.Width = (e_SizeX - s + 1) * ZoomX
            End If

            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next

    End Sub
#End Region

#Region "--- CheckBox Event ---"
    Private Sub CheckBox_ShowBlob_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowBlob.CheckedChanged
        Me.DrawMark()
    End Sub
    Private Sub CheckBox_ShowBand_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowBand.CheckedChanged
        Me.DrawMark()
    End Sub
#End Region

#Region "--- Button Event ---"

    Private Sub Button_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Ok.Click
        Me.Close()
    End Sub

    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub

#End Region

#Region "--- Sub ListView ---"

#Region "--- ListView_Blob_DoubleClick ---"
    Private Sub ListView_Blob_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Blob.DoubleClick
        Dim i As Integer
        Dim picsize As Integer
        Dim offset_X, offset_Y As Integer
        Dim p As New Position
        Dim ZoomX As Double
        Dim DisplayWidth As Integer = Me.m_Form.Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.m_Form.Panel_AxMDisplay.Size.Height
        Dim Image As MIL_ID = M_NULL
        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim CenterHScroll As Double
        Dim OffsetHScroll As Double
        Dim CenterVScroll As Double
        Dim OffsetVScroll As Double

        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
        Me.m_Form.SetStatusBarPanel_Scale("�Y�� = " & ZoomX)
        Me.m_Form.SetButton_ZoomIn(True)
        Me.m_Form.SetButton_ZoomOut(True)
        Me.m_Form.ResetScrollBar()

        i = ListView_Blob.SelectedIndices(0)
        p.BlobX = ListView_Blob.Items(i).SubItems(6).Text
        p.BlobY = ListView_Blob.Items(i).SubItems(7).Text
        p.BlobArea = ListView_Blob.Items(i).SubItems(3).Text

        picsize = Math.Max(CInt(((p.BlobArea) ^ 0.5) * 2), 50)
        offset_X = Math.Max(CInt(p.BlobX) - CInt(picsize / 2), 0)
        offset_Y = Math.Max(CInt(p.BlobY) - CInt(picsize / 2), 0)

        'offset_X = Math.Min(offset_X, Me.m_Form.HScrollBar.Maximum)
        'offset_Y = Math.Min(offset_Y, Me.m_Form.VScrollBar.Maximum)
        'Me.m_Form.HScrollBar.Value = offset_X
        'Me.m_Form.VScrollBar.Value = offset_Y
        Me.m_Form.ResetScrollBar()

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

        If Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
            offset_X = offset_X - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.LeftX
            offset_Y = offset_Y - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.TopY
        End If

        CenterHScroll = ((offset_X + CInt(picsize / 2)) * Me.m_Form.HScrollBar.Maximum) / (SizeX - DisplayWidth / ZoomX)
        OffsetHScroll = ((DisplayWidth / ZoomX) / 2) * (Me.m_Form.HScrollBar.Maximum / (SizeX - DisplayWidth / ZoomX))
        CenterVScroll = ((offset_Y + CInt(picsize / 2)) * Me.m_Form.VScrollBar.Maximum) / (SizeY - DisplayHeight / ZoomX)
        OffsetVScroll = ((DisplayHeight / ZoomX) / 2) * (Me.m_Form.VScrollBar.Maximum / (SizeY - DisplayHeight / ZoomX))

        CenterHScroll = CenterHScroll - OffsetHScroll
        CenterVScroll = CenterVScroll - OffsetVScroll

        If CenterHScroll < 0 Then
            Me.m_Form.HScrollBar.Value = 0
        ElseIf CenterHScroll > Me.m_Form.HScrollBar.Maximum Then
            Me.m_Form.HScrollBar.Value = Me.m_Form.HScrollBar.Maximum
        Else
            If CenterHScroll > 0 Then Me.m_Form.HScrollBar.Value = CenterHScroll
        End If

        If CenterVScroll < 0 Then
            Me.m_Form.VScrollBar.Value = 0
        ElseIf CenterVScroll > Me.m_Form.VScrollBar.Maximum Then
            Me.m_Form.VScrollBar.Value = Me.m_Form.VScrollBar.Maximum
        Else
            If CenterVScroll > 0 Then Me.m_Form.VScrollBar.Value = CenterVScroll
        End If


        Me.DrawMark()
    End Sub
#End Region

#Region "--- ListView_Band_DoubleClick ---"
    Private Sub ListView_Band_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Band.DoubleClick
        Dim indexes As ListView.SelectedIndexCollection = Me.ListView_Band.SelectedIndices
        Dim index As Integer
        Dim offset_X, offset_Y As Integer
        Dim p As New ClsMuraPosition
        Dim ZoomX As Double
        Dim DisplayWidth As Integer = Me.m_Form.Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.m_Form.Panel_AxMDisplay.Size.Height
        Dim Image As MIL_ID = M_NULL
        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim CenterHScroll As Double
        Dim OffsetHScroll As Double
        Dim CenterVScroll As Double
        Dim OffsetVScroll As Double

        'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
        Me.m_Form.SetStatusBarPanel_Scale("�Y�� = " & ZoomX)
        Me.m_Form.SetButton_ZoomIn(True)
        Me.m_Form.SetButton_ZoomOut(True)
        Me.m_Form.ResetScrollBar()

        For Each index In indexes
            p.CenterX = ListView_Band.Items(index).SubItems(6).Text
            p.CenterY = ListView_Band.Items(index).SubItems(7).Text
            p.Area = ListView_Band.Items(index).SubItems(3).Text
            If p.CenterX = -1 Then
                offset_X = 0
                'offset_Y = Math.Max(CInt(p.CenterY) - 50, 0)
                offset_Y = CInt(p.CenterY)
            End If
            If p.CenterY = -1 Then
                'offset_X = Math.Max(CInt(p.CenterX) - 50, 0)
                offset_X = CInt(p.CenterX)
                offset_Y = 0
            End If
            'offset_X = Math.Min(offset_X, Me.m_Form.HScrollBar.Maximum)
            'offset_Y = Math.Min(offset_Y, Me.m_Form.VScrollBar.Maximum)
            'Me.m_Form.HScrollBar.Value = offset_X
            'Me.m_Form.VScrollBar.Value = offset_Y
            Me.m_Form.ResetScrollBar()

            Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

            If Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                offset_X = offset_X - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.LeftX
                offset_Y = offset_Y - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.TopY
            End If

            OffsetHScroll = ((DisplayWidth / ZoomX) / 2) * (Me.m_Form.HScrollBar.Maximum / (SizeX - DisplayWidth / ZoomX))
            OffsetVScroll = ((DisplayHeight / ZoomX) / 2) * (Me.m_Form.VScrollBar.Maximum / (SizeY - DisplayHeight / ZoomX))

            If p.CenterX = -1 Then
                CenterHScroll = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.LeftX
                CenterVScroll = (offset_Y * Me.m_Form.VScrollBar.Maximum) / (SizeY - DisplayHeight / ZoomX)
                CenterVScroll = CenterVScroll - OffsetVScroll
            ElseIf p.CenterY = -1 Then
                CenterHScroll = (offset_X * Me.m_Form.HScrollBar.Maximum) / (SizeX - DisplayWidth / ZoomX)
                CenterVScroll = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.TopY
                CenterHScroll = CenterHScroll - OffsetHScroll
            End If

            If CenterHScroll < 0 Then
                Me.m_Form.HScrollBar.Value = 0
            ElseIf CenterHScroll > Me.m_Form.HScrollBar.Maximum Then
                Me.m_Form.HScrollBar.Value = Me.m_Form.HScrollBar.Maximum
            Else
                If CenterHScroll > 0 Then Me.m_Form.HScrollBar.Value = CenterHScroll
            End If

            If CenterVScroll < 0 Then
                Me.m_Form.VScrollBar.Value = 0
            ElseIf CenterVScroll > Me.m_Form.VScrollBar.Maximum Then
                Me.m_Form.VScrollBar.Value = Me.m_Form.VScrollBar.Maximum
            Else
                If CenterVScroll > 0 Then Me.m_Form.VScrollBar.Value = CenterVScroll
            End If

            Me.DrawMark()
        Next
    End Sub
#End Region

#End Region

#Region "--- UI Event ---"

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If CheckBox_ShowBlob.Checked Or CheckBox_ShowBand.Checked Then
            Me.DrawMark()
        End If
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If CheckBox_ShowBlob.Checked Or CheckBox_ShowBand.Checked Then
            Me.DrawMark()
        End If
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_ShowBlob.Checked Or CheckBox_ShowBand.Checked Then Me.DrawMark()
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_ShowBlob.Checked Or CheckBox_ShowBand.Checked Then Me.DrawMark()
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_ShowBlob.Checked Or CheckBox_ShowBand.Checked Then Me.DrawMark()
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_ShowBlob.Checked Or CheckBox_ShowBand.Checked Then Me.DrawMark()
        End If
    End Sub
#End Region

#End Region

End Class