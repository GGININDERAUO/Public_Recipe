Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL

Imports System.IO
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraSetting

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_AxMDisplay As MIL_ID
    Friend WithEvents m_DialogBoundary As Dialog_MuraBoundary

    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_PaintStop As Boolean
    Private m_CurrentTab As Integer
    Private m_Boundary As ClsParameterBoundary

    Private m_Left1 As Boolean
    Private m_Right1 As Boolean
    Private m_Top1 As Boolean
    Private m_Bottom1 As Boolean

    Private m_Left2 As Boolean
    Private m_Right2 As Boolean
    Private m_Top2 As Boolean
    Private m_Bottom2 As Boolean

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form,ByVal language as String)

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraSetting", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------
        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess

        '-- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.UpdateUserLevel()

        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_SolidBrush = New SolidBrush(Color.White)

        If Me.m_MuraProcess.Img_CurrentOriginal_NonPage <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        Button_Save.Enabled = False
        Me.GroupBox_SettingFFC.Enabled = False

        'Me.UpdateData()

    End Sub

#Region "--- Dialog Event ---"
    Private Sub Dialog_MuraSetting_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer

        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
            Me.ComboBox_PatternList.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
        Next

        If Me.m_Form.ComboBox_Pattern_MainFrm.Text = "" Or Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex > Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
            Me.ComboBox_PatternList.SelectedIndex = 0
        End If

        If Me.m_Form.GetPatternIndexInfo <> -1 Then
            Me.m_MainProcess.SetRecipe(Me.m_Form.ComboBox_Pattern_MainFrm.Text, Me.m_MainProcess.ErrorCode)
            Me.ComboBox_PatternList.SelectedIndex = Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex
        End If

        Me.m_Form.ComboBox_Pattern_MainFrm.Enabled = False

        Me.Update()
    End Sub

    Private Sub Dialog_MuraSetting_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_Form.ComboBox_Pattern_MainFrm.Enabled = True
        Me.Finalize()
    End Sub

    Private Sub m_DialogBoundary_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogBoundary.Closing
        Me.m_DialogBoundary = Nothing
        Me.m_Form.Focus()
        Me.m_Form.GroupBox_Image.Enabled = True
        Me.Show()
        If Me.m_MuraProcess.Img_ChildSample <> M_NULL Then
            Me.NumericUpDown_AlignValue.Enabled = True
            Me.Button_FFCImage.Enabled = True
            Me.Button_SaveFFCImages.Enabled = True
            Me.Button_Calculate_Max.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.TabControl_Setting.Enabled = False
                Me.Button_Save.Enabled = False
                Me.CheckBox_GrayAbnormal_Enable.Enabled = False
            Case 1 'PM
                Me.TabControl_Setting.Enabled = True

                Me.GroupBox_FFCOperation.Enabled = False
                Me.Button_SaveFFCImages.Enabled = False
                Me.GroupBox_GlobleSmooth.Enabled = False
                Me.GroupBox_Defocus.Enabled = False
                Me.GroupBox_MuraRatio.Enabled = False
                Me.GroupBox_Parameter.Enabled = False
                Me.CheckBox_Rim.Enabled = False
                Me.GroupBox_RimParameter.Enabled = False
                Me.CheckBox_Band.Enabled = False
                Me.GroupBox_BandParameter.Enabled = False
                Me.GroupBox_JND_1.Enabled = False
                Me.GroupBox_Save.Enabled = True

                Me.Button_Save.Enabled = True
                Me.CheckBox_GrayAbnormal_Enable.Enabled = True
            Case 2 'ENG
                Me.TabControl_Setting.Enabled = True

                Me.GroupBox_FFCOperation.Enabled = True
                Me.Button_SaveFFCImages.Enabled = True
                Me.GroupBox_GlobleSmooth.Enabled = True
                Me.GroupBox_Defocus.Enabled = True
                Me.GroupBox_MuraRatio.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
                Me.CheckBox_Rim.Enabled = True
                Me.GroupBox_RimParameter.Enabled = True
                Me.CheckBox_Band.Enabled = True
                Me.GroupBox_BandParameter.Enabled = True
                Me.GroupBox_JND_1.Enabled = True
                Me.GroupBox_Save.Enabled = True

                Me.Button_Save.Enabled = True
                Me.CheckBox_GrayAbnormal_Enable.Enabled = True
            Case 3 'ALL
                Me.TabControl_Setting.Enabled = True

                Me.GroupBox_FFCOperation.Enabled = True
                Me.Button_SaveFFCImages.Enabled = True
                Me.GroupBox_GlobleSmooth.Enabled = True
                Me.GroupBox_Defocus.Enabled = True
                Me.GroupBox_MuraRatio.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
                Me.CheckBox_Rim.Enabled = True
                Me.GroupBox_RimParameter.Enabled = True
                Me.CheckBox_Band.Enabled = True
                Me.GroupBox_BandParameter.Enabled = True
                Me.GroupBox_JND_1.Enabled = True
                Me.GroupBox_Save.Enabled = True

                Me.Button_Save.Enabled = True
                Me.CheckBox_GrayAbnormal_Enable.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim s As Integer
        Dim boundary As ClsParameterBoundary
        Dim HBoundary As ClsParameterBoundary
        Dim VBoundary As ClsParameterBoundary
        Dim mpr As ClsMuraPatternRecipe
        Dim mmr As ClsMuraModelRecipe
        Dim GrayLevel_Maximum As Double
        Dim MuraUpdateDataLog As String

        Try
            MuraUpdateDataLog = ""

            mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
            mmr = Me.m_MuraProcess.MuraModelRecipe
            GrayLevel_Maximum = 2 ^ Me.m_MainProcess.IPBootConfig.Digitizer_Datadepth.Value - 1

            If mpr.UseFFC.Value Then
                Me.m_Boundary = Me.m_MuraProcess.BoundarySample
            Else
                Me.m_Boundary = Me.m_MuraProcess.BoundaryOriginal
            End If

            If Me.m_Boundary.TopY = 0 And Me.m_Boundary.BottomY = 0 And Me.m_Boundary.LeftX = 0 And Me.m_Boundary.RightX = 0 Then
                Me.m_Boundary = Me.m_MuraProcess.MuraModelRecipe.Boundary
            End If

            Me.Text = "[Mura] �v���B�z�Ѽƽվ� [ Pattern�G" & Me.m_Form.ComboBox_Pattern_MainFrm.Text & " ]"

            '--- Page 1 --- (FFC)
            If Me.NumericUpDown_DefocusCount.Maximum >= mpr.DefocusCount.Value Then Me.NumericUpDown_DefocusCount.Value = mpr.DefocusCount.Value Else MuraUpdateDataLog &= "[FFC & Golden] DefocusCount �]�w�W�X�d�� (Max =" & Me.NumericUpDown_DefocusCount.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_PitchX.Maximum >= mmr.PitchX.Value Then Me.NumericUpDown_PitchX.Value = mmr.PitchX.Value Else MuraUpdateDataLog &= "[FFC & Golden] PitchX �]�w�W�X�d�� (Max =" & Me.NumericUpDown_PitchX.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_PitchY.Maximum >= mmr.PitchY.Value Then Me.NumericUpDown_PitchY.Value = mmr.PitchY.Value Else MuraUpdateDataLog &= "[FFC & Golden] PitchY �]�w�W�X�d�� (Max =" & Me.NumericUpDown_PitchY.Maximum & ")" & vbCrLf

            If Me.NumericUpDown_BlobMura_GlobleSmooth.Maximum >= mpr.BlobMura_GlobleSmooth.Value Then Me.NumericUpDown_BlobMura_GlobleSmooth.Value = mpr.BlobMura_GlobleSmooth.Value Else MuraUpdateDataLog &= "[FFC & Golden] BlobMura_GlobleSmooth �]�w�W�X�d�� (Max =" & Me.NumericUpDown_BlobMura_GlobleSmooth.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_MacroMura_GlobleSmooth.Maximum >= mpr.MacroMura_GlobleSmooth.Value Then Me.NumericUpDown_MacroMura_GlobleSmooth.Value = mpr.MacroMura_GlobleSmooth.Value Else MuraUpdateDataLog &= "[FFC & Golden] MacroMura_GlobleSmooth �]�w�W�X�d�� (Max =" & Me.NumericUpDown_MacroMura_GlobleSmooth.Maximum & ")" & vbCrLf

            Me.NumericUpDown_AlignValue.Maximum = GrayLevel_Maximum
            Me.CheckBox_UseFFC.Checked = mpr.UseFFC.Value
            Me.CheckBox_UseBLFFC.Checked = mmr.UseBLFFC.Value

            If mpr.AlignValue.Value > GrayLevel_Maximum Then
                mpr.AlignValue.Value = GrayLevel_Maximum / 2
                Me.NumericUpDown_AlignValue.Value = mpr.AlignValue.Value
            Else
                Me.NumericUpDown_AlignValue.Value = mpr.AlignValue.Value
            End If
            If Me.NumericUpDown_AlignPercentage.Maximum >= mpr.AlignPercentage.Value Then Me.NumericUpDown_AlignPercentage.Value = mpr.AlignPercentage.Value Else MuraUpdateDataLog &= "[FFC & Golden] Align Percentage �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AlignPercentage.Maximum & ")" & vbCrLf

            If Not mpr.UseFFC.Value Then
                Me.NumericUpDown_AlignValue.Enabled = False
                Me.Button_FFCImage.Enabled = False
                Me.Button_Calculate_Max.Enabled = False
                Me.GroupBox_SettingFFC.Enabled = False
                Me.NumericUpDown_AlignPercentage.Enabled = False
                Me.Button_SaveFFCImages.Enabled = False
                Me.Button_Calculate_Max.Enabled = False
            Else
                Me.NumericUpDown_AlignValue.Enabled = True
                Me.Button_FFCImage.Enabled = True
                Me.Button_Calculate_Max.Enabled = True
                Me.GroupBox_SettingFFC.Enabled = True
                Me.NumericUpDown_AlignPercentage.Enabled = True
                Me.Button_SaveFFCImages.Enabled = True
                Me.Button_Calculate_Max.Enabled = True
            End If

            Me.CheckBox_RemoveHVBand.Checked = mpr.RemoveHVBand.Value

            Me.CheckBox_UseFFT.Checked = mpr.UseFFT.Value
            Me.NumericUpDown_FFTFilterRadius.Value = mpr.FFTFilterRadius.Value

            '--- Page 2 --- (Center)
            Me.CheckBox_Center.Checked = mpr.UseCenter.Value
            Me.NumericUpDown_AreaBottom.Maximum = Me.m_Boundary.BottomY - Me.NumericUpDown_AreaTop.Value
            Me.NumericUpDown_AreaTop.Maximum = Me.m_Boundary.BottomY - Me.NumericUpDown_AreaBottom.Value
            Me.NumericUpDown_AreaRight.Maximum = Me.m_Boundary.RightX - Me.NumericUpDown_AreaLeft.Value
            Me.NumericUpDown_AreaLeft.Maximum = Me.m_Boundary.RightX - Me.NumericUpDown_AreaRight.Value
            Me.NUD_WhiteBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
            Me.NUD_WhiteBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
            Me.NUD_BlackBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
            Me.NUD_BlackBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
            Me.NUD_WhiteMacroMura_Threshold.Maximum = GrayLevel_Maximum
            Me.NUD_BlackMacroMura_Threshold.Maximum = GrayLevel_Maximum

            boundary = mmr.BoundaryRound
            If Me.NumericUpDown_AreaTop.Maximum >= boundary.TopY Then Me.NumericUpDown_AreaTop.Value = boundary.TopY Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] BoundaryRound[Area Top] �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AreaTop.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_AreaBottom.Maximum >= boundary.BottomY Then Me.NumericUpDown_AreaBottom.Value = boundary.BottomY Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] BoundaryRound[Area Bottom] �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AreaBottom.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_AreaLeft.Maximum >= boundary.LeftX Then Me.NumericUpDown_AreaLeft.Value = boundary.LeftX Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] BoundaryRound[Area Left] �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AreaLeft.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_AreaRight.Maximum >= boundary.RightX Then Me.NumericUpDown_AreaRight.Value = boundary.RightX Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] BoundaryRound[Area Right] �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AreaRight.Maximum & ")" & vbCrLf

            If Me.NUD_WhiteBlobMura_ReconstructHeight.Maximum >= mpr.WhiteBlobMura_BinarizeHeight.Value Then Me.NUD_WhiteBlobMura_ReconstructHeight.Value = mpr.WhiteBlobMura_BinarizeHeight.Value Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] WhiteBlobMura_ReconstructHeight �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBlobMura_ReconstructHeight.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteBlobMura_ReconstructLow.Maximum >= mpr.WhiteBlobMura_BinarizeLow.Value Then Me.NUD_WhiteBlobMura_ReconstructLow.Value = mpr.WhiteBlobMura_BinarizeLow.Value Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] WhiteBlobMura_ReconstructLow �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBlobMura_ReconstructLow.Maximum & ")" & vbCrLf
            If Me.NUD_BlackBlobMura_ReconstructHeight.Maximum >= mpr.BlackBlobMura_BinarizeHeight.Value Then Me.NUD_BlackBlobMura_ReconstructHeight.Value = mpr.BlackBlobMura_BinarizeHeight.Value Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] BlackBlobMura_ReconstructHeight �]�w�W�X�d�� (Max =" & Me.NUD_BlackBlobMura_ReconstructHeight.Maximum & ")" & vbCrLf
            If Me.NUD_BlackBlobMura_ReconstructLow.Maximum >= mpr.BlackBlobMura_BinarizeLow.Value Then Me.NUD_BlackBlobMura_ReconstructLow.Value = mpr.BlackBlobMura_BinarizeLow.Value Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] BlackBlobMura_ReconstructLow �]�w�W�X�d�� (Max =" & Me.NUD_BlackBlobMura_ReconstructLow.Maximum & ")" & vbCrLf

            If Me.NUD_WhiteMacroMura_Threshold.Maximum >= mpr.WhiteMacroMura_Threshold.Value Then Me.NUD_WhiteMacroMura_Threshold.Value = mpr.WhiteMacroMura_Threshold.Value Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] WhiteMacroMura_Threshold �]�w�W�X�d�� (Max =" & Me.NUD_WhiteMacroMura_Threshold.Maximum & ")" & vbCrLf
            If Me.NUD_BlackMacroMura_Threshold.Maximum >= mpr.BlackMacroMura_Threshold.Value Then Me.NUD_BlackMacroMura_Threshold.Value = mpr.BlackMacroMura_Threshold.Value Else MuraUpdateDataLog &= "[����ByPass�Ѽ�] BlackMacroMura_Threshold �]�w�W�X�d�� (Max =" & Me.NUD_BlackMacroMura_Threshold.Maximum & ")" & vbCrLf

            Me.RadioButton_Finish.Checked = True

            Me.Num_ResizeCount_Min.Value = mpr.ResizeCount_min.Value
            Me.Num_ResizeCount_Mid.Value = mpr.ResizeCount_mid.Value
            Me.Num_ResizeCount_Mid2.Value = mpr.ResizeCount_mid.Value
            Me.Num_ResizeCount_Max.Value = mpr.ResizeCount_max.Value

            Me.CheckBox_UseBaseLine.Checked = mpr.UseBaseLine.Value
            Me.NumericUpDown_MacroPowerX.Value = mpr.MacroPowerX.Value
            Me.NumericUpDown_MacroPowerY.Value = mpr.MacroPowerY.Value

            Me.CheckBox_UseReconstructBW.Checked = mpr.UseReconstructBW.Value

            If mmr.L7AXPMode.Value Then
                Me.NumericUpDown_BlobMulRatio.Enabled = True
                Me.NumericUpDown_BlobMulRatio.Value = mpr.BlobMulRatio.Value
            Else
                Me.NumericUpDown_BlobMulRatio.Enabled = False
            End If


            '--- Page 3 --- (CPD)
            '(WithCore)
            Me.CheckBox_WithCoreCPD_Enable.Checked = mpr.CPDRecipe.WithCoreCPD_Enable
            If Me.CheckBox_WithCoreCPD_Enable.Checked Then Me.GroupBox_WithCoreCPDRecipe.Enabled = True
            Me.NumericUpDown_WithCoreWhiteCPD_ThHigh.Value = mpr.CPDRecipe.WithCoreWhiteCPD_ThHigh
            Me.NumericUpDown_WithCoreWhiteCPD_ThLow.Value = mpr.CPDRecipe.WithCoreWhiteCPD_ThLow
            Me.NumericUpDown_WithCoreBlackCPD_ThHigh.Value = mpr.CPDRecipe.WithCoreBlackCPD_ThHigh
            Me.NumericUpDown_WithCoreBlackCPD_ThLow.Value = mpr.CPDRecipe.WithCoreBlackCPD_ThLow
            Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low.Value = mpr.CPDRecipe.WithCoreWhiteCPDCompactness_Low
            Me.NumericUpDown_WithCoreWhiteCPDCompactness_High.Value = mpr.CPDRecipe.WithCoreWhiteCPDCompactness_High
            Me.NumericUpDown_WithCoreBlackCPDCompactness_Low.Value = mpr.CPDRecipe.WithCoreBlackCPDCompactness_Low
            Me.NumericUpDown_WithCoreBlackCPDCompactness_High.Value = mpr.CPDRecipe.WithCoreBlackCPDCompactness_High
            Me.NumericUpDown_WithCoreWhiteCPDElongation_Low.Value = mpr.CPDRecipe.WithCoreWhiteCPDElongation_Low
            Me.NumericUpDown_WithCoreWhiteCPDElongation_High.Value = mpr.CPDRecipe.WithCoreWhiteCPDElongation_High
            Me.NumericUpDown_WithCoreBlackCPDElongation_Low.Value = mpr.CPDRecipe.WithCoreBlackCPDElongation_Low
            Me.NumericUpDown_WithCoreBlackCPDElongation_High.Value = mpr.CPDRecipe.WithCoreBlackCPDElongation_High
            Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low.Value = mpr.CPDRecipe.WithCoreWhiteCPDBreadth_Low
            Me.NumericUpDown_WithCoreWhiteCPDBreadth_High.Value = mpr.CPDRecipe.WithCoreWhiteCPDBreadth_High
            Me.NumericUpDown_WithCoreBlackCPDBreadth_Low.Value = mpr.CPDRecipe.WithCoreBlackCPDBreadth_Low
            Me.NumericUpDown_WithCoreBlackCPDBreadth_High.Value = mpr.CPDRecipe.WithCoreBlackCPDBreadth_High
            '(WithoutCore)
            Me.CheckBox_WithoutCoreCPD_Enable.Checked = mpr.CPDRecipe.WithoutCoreCPD_Enable
            If Me.CheckBox_WithoutCoreCPD_Enable.Checked Then Me.GroupBox_WithoutCoreCPDRecipe.Enabled = True
            Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh.Value = mpr.CPDRecipe.WithoutCoreWhiteCPD_ThHigh
            Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow.Value = mpr.CPDRecipe.WithoutCoreWhiteCPD_ThLow
            Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh.Value = mpr.CPDRecipe.WithoutCoreBlackCPD_ThHigh
            Me.NumericUpDown_WithoutCoreBlackCPD_ThLow.Value = mpr.CPDRecipe.WithoutCoreBlackCPD_ThLow
            Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low.Value = mpr.CPDRecipe.WithoutCoreWhiteCPDCompactness_Low
            Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High.Value = mpr.CPDRecipe.WithoutCoreWhiteCPDCompactness_High
            Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low.Value = mpr.CPDRecipe.WithoutCoreBlackCPDCompactness_Low
            Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High.Value = mpr.CPDRecipe.WithoutCoreBlackCPDCompactness_High
            Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low.Value = mpr.CPDRecipe.WithoutCoreWhiteCPDElongation_Low
            Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High.Value = mpr.CPDRecipe.WithoutCoreWhiteCPDElongation_High
            Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low.Value = mpr.CPDRecipe.WithoutCoreBlackCPDElongation_Low
            Me.NumericUpDown_WithoutCoreBlackCPDElongation_High.Value = mpr.CPDRecipe.WithoutCoreBlackCPDElongation_High
            Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low.Value = mpr.CPDRecipe.WithoutCoreWhiteCPDBreadth_Low
            Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High.Value = mpr.CPDRecipe.WithoutCoreWhiteCPDBreadth_High
            Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low.Value = mpr.CPDRecipe.WithoutCoreBlackCPDBreadth_Low
            Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High.Value = mpr.CPDRecipe.WithoutCoreBlackCPDBreadth_High

            '--- Page 4 --- (Round)
            Me.CheckBox_Rim.Checked = mpr.UseRound.Value

            Me.NumericUpDown_RimTop.Minimum = 1
            Me.NumericUpDown_RimBottom.Minimum = 1
            Me.NumericUpDown_RimLeft.Minimum = 1
            Me.NumericUpDown_RimRight.Minimum = 1

            boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound

            If boundary.TopY <> 0 AndAlso boundary.BottomY <> 0 AndAlso boundary.LeftX <> 0 AndAlso boundary.RightX <> 0 Then
                Me.NumericUpDown_RimTop.Maximum = boundary.TopY - 1
                Me.NumericUpDown_RimBottom.Maximum = boundary.BottomY - 1
                Me.NumericUpDown_RimLeft.Maximum = boundary.LeftX - 1
                Me.NumericUpDown_RimRight.Maximum = boundary.RightX - 1
            End If
            Me.SetRimBoundary(Me.m_MuraProcess.CurrentMuraPatternRecipe.Rim)

            If Me.NumericUpDown_WhiteMura_RimHeight.Maximum >= mpr.WhiteMura_ThresholdHeight.Value Then Me.NumericUpDown_WhiteMura_RimHeight.Value = mpr.WhiteMura_ThresholdHeight.Value Else MuraUpdateDataLog &= "[��tByPass�Ѽ�] WhiteMura_RimHeight �]�w�W�X�d�� (Max =" & Me.NumericUpDown_WhiteMura_RimHeight.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_WhiteMura_RimLow.Maximum >= mpr.WhiteMura_ThresholdLow.Value Then Me.NumericUpDown_WhiteMura_RimLow.Value = mpr.WhiteMura_ThresholdLow.Value Else MuraUpdateDataLog &= "[��tByPass�Ѽ�] WhiteMura_RimLow �]�w�W�X�d�� (Max =" & Me.NumericUpDown_WhiteMura_RimLow.Maximum & ")" & vbCrLf

            If Me.NumericUpDown_BlackMura_RimHeight.Maximum >= mpr.BlackMura_ThresholdHeight.Value Then Me.NumericUpDown_BlackMura_RimHeight.Value = mpr.BlackMura_ThresholdHeight.Value Else MuraUpdateDataLog &= "[��tByPass�Ѽ�] BlackMura_RimHeight �]�w�W�X�d�� (Max =" & Me.NumericUpDown_BlackMura_RimHeight.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_BlackMura_RimLow.Maximum >= mpr.BlackMura_ThresholdLow.Value Then Me.NumericUpDown_BlackMura_RimLow.Value = mpr.BlackMura_ThresholdLow.Value Else MuraUpdateDataLog &= "[��tByPass�Ѽ�] BlackMura_RimLow �]�w�W�X�d�� (Max =" & Me.NumericUpDown_BlackMura_RimLow.Maximum & ")" & vbCrLf

            If Me.NumericUpDown_Resize.Maximum >= mmr.GoldenResizeCount.Value Then Me.NumericUpDown_Resize.Value = mmr.GoldenResizeCount.Value Else MuraUpdateDataLog &= "[��tByPass�Ѽ�] Resize �]�w�W�X�d�� (Max =" & Me.NumericUpDown_Resize.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_Smooth.Maximum >= mpr.SmoothCount.Value Then Me.NumericUpDown_Smooth.Value = mpr.SmoothCount.Value Else MuraUpdateDataLog &= "[��tByPass�Ѽ�] Smooth �]�w�W�X�d�� (Max =" & Me.NumericUpDown_Smooth.Maximum & ")" & vbCrLf

            Me.RadioButton_RoundFinish.Checked = True

            '--- Page 5 --- (Band)
            Me.CheckBox_Band.Checked = mpr.UseBand.Value
            HBoundary = mpr.HBand
            VBoundary = mpr.VBand
            Me.NumericUpDown_HTop.Value = HBoundary.TopY
            Me.NumericUpDown_HBottom.Value = HBoundary.BottomY
            Me.NumericUpDown_HLeft.Value = HBoundary.LeftX
            Me.NumericUpDown_HRight.Value = HBoundary.RightX
            Me.NumericUpDown_VTop.Value = VBoundary.TopY
            Me.NumericUpDown_VBottom.Value = VBoundary.BottomY
            Me.NumericUpDown_VLeft.Value = VBoundary.LeftX
            Me.NumericUpDown_VRight.Value = VBoundary.RightX
            Me.NumericUpDown_HBottom.Minimum = 0
            Me.NumericUpDown_HTop.Minimum = 0
            Me.NumericUpDown_VRight.Minimum = 0
            Me.NumericUpDown_VLeft.Minimum = 0

            s = Me.m_Boundary.BottomY - Me.m_Boundary.TopY + 1
            If Me.NumericUpDown_HTop.Value + Me.NumericUpDown_HBottom.Value >= s Then
                Me.NumericUpDown_HTop.Value = 0
                Me.NumericUpDown_HBottom.Value = 0
                MuraUpdateDataLog &= "[H band�]�w] �����Ѽ�Top + Bottom�]�w�W�X�d�� (Max =" & s & ")" & vbCrLf
            End If

            s = Me.m_Boundary.RightX - Me.m_Boundary.LeftX + 1
            If Me.NumericUpDown_HRight.Value + Me.NumericUpDown_HLeft.Value >= s Then
                Me.NumericUpDown_HRight.Value = 0
                Me.NumericUpDown_HLeft.Value = 0
                MuraUpdateDataLog &= "[H band�]�w] �����Ѽ�Left + Right�]�w�W�X�d�� (Max =" & s & ")" & vbCrLf
            End If

            s = Me.m_Boundary.BottomY - Me.m_Boundary.TopY + 1
            If Me.NumericUpDown_VTop.Value + Me.NumericUpDown_VBottom.Value >= s Then
                Me.NumericUpDown_VTop.Value = 0
                Me.NumericUpDown_VBottom.Value = 0
                MuraUpdateDataLog &= "[V band�]�w] �����Ѽ�Top + Bottom�]�w�W�X�d�� (Max =" & s & ")" & vbCrLf
            End If

            s = Me.m_Boundary.RightX - Me.m_Boundary.LeftX + 1
            If Me.NumericUpDown_VRight.Value + Me.NumericUpDown_VLeft.Value >= s Then
                Me.NumericUpDown_VRight.Value = 0
                Me.NumericUpDown_VLeft.Value = 0
                MuraUpdateDataLog &= "[V band�]�w] �����Ѽ�Left + Right�]�w�W�X�d�� (Max =" & s & ")" & vbCrLf
            End If

            Me.NumericUpDown_WhiteHBand_Threshold.Value = mpr.WhiteHBand_Threshold.Value
            Me.NumericUpDown_BlackHBand_Threshold.Value = mpr.BlackHBand_Threshold.Value
            Me.NumericUpDown_WhiteVBand_Threshold.Value = mpr.WhiteVBand_Threshold.Value
            Me.NumericUpDown_BlackVBand_Threshold.Value = mpr.BlackVBand_Threshold.Value

            'Me.NumericUpDown_WhiteHBand_Threshold.Maximum = GrayLevel_Maximum
            'Me.NumericUpDown_BlackHBand_Threshold.Maximum = GrayLevel_Maximum
            'Me.NumericUpDown_WhiteVBand_Threshold.Maximum = GrayLevel_Maximum
            'Me.NumericUpDown_BlackVBand_Threshold.Maximum = GrayLevel_Maximum

            If Me.NumericUpDown_BandMura_ResizeCount.Maximum >= mpr.BandMura_ResizeCount.Value Then Me.NumericUpDown_BandMura_ResizeCount.Value = mpr.BandMura_ResizeCount.Value Else MuraUpdateDataLog &= "[V\H Band�Ѽ�] BandMura_ResizeCount �]�w�W�X�d�� (Max =" & Me.NumericUpDown_BandMura_ResizeCount.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_BandMura_SmoothCount.Maximum >= mpr.BandMura_SmoothCount.Value Then Me.NumericUpDown_BandMura_SmoothCount.Value = mpr.BandMura_SmoothCount.Value Else MuraUpdateDataLog &= "[V\H Band�Ѽ�] BandMura_SmoothCount �]�w�W�X�d�� (Max =" & Me.NumericUpDown_BandMura_SmoothCount.Maximum & ")" & vbCrLf

            Me.CheckBox_UseHValue.Checked = mpr.HVValueRecipe.UseHValue
            Me.Label_HSlope.Text = mpr.HVValueRecipe.HSlope
            Me.Label_HConst.Text = mpr.HVValueRecipe.HConst
            Me.CheckBox_HValue_UseHBand.Checked = mpr.HVValueRecipe.UseHBand
            Me.NumericUpDown_HValue_WhiteHBandTH.Value = mpr.HVValueRecipe.WhiteHBandTH
            Me.NumericUpDown_HValue_BlackHBandTH.Value = mpr.HVValueRecipe.BlackHBandTH
            Me.CheckBox_UseVValue.Checked = mpr.HVValueRecipe.UseVValue
            Me.Label_VSlope.Text = mpr.HVValueRecipe.VSlope
            Me.Label_VConst.Text = mpr.HVValueRecipe.VConst
            Me.CheckBox_VValue_UseVBand.Checked = mpr.HVValueRecipe.UseVBand
            Me.NumericUpDown_VValue_WhiteVBandTH.Value = mpr.HVValueRecipe.WhiteVBandTH
            Me.NumericUpDown_VValue_BlackVBandTH.Value = mpr.HVValueRecipe.BlackVBandTH

            '--- Page 6 --- (JND)
            '--- White ---
            If Me.NUD_WhiteBlobMura_AreaMin.Maximum >= mpr.WhiteBlobMura_AreaMin.Value Then Me.NUD_WhiteBlobMura_AreaMin.Value = mpr.WhiteBlobMura_AreaMin.Value Else MuraUpdateDataLog &= "[JND�]�w] White Blob_AreaMin �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBlobMura_AreaMin.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteBlobMura_AreaMax.Maximum >= mpr.WhiteBlobMura_AreaMax.Value Then Me.NUD_WhiteBlobMura_AreaMax.Value = mpr.WhiteBlobMura_AreaMax.Value Else MuraUpdateDataLog &= "[JND�]�w] White Blob_AreaMax �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBlobMura_AreaMax.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteBlobMura_JND_Min.Maximum >= mpr.WhiteBlobMura_JNDMin.Value Then Me.NUD_WhiteBlobMura_JND_Min.Value = mpr.WhiteBlobMura_JNDMin.Value Else MuraUpdateDataLog &= "[JND�]�w] White BlobMura_JND �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBlobMura_JND_Min.Maximum & ")" & vbCrLf
            Me.NUD_WhiteBlobMura_JND_Max.Value = mpr.WhiteBlobMura_JNDMax.Value
            Me.NUD_WhiteBlobMura_Elongation_Min.Value = mpr.WhiteBlobMura_ElongationMin.Value
            Me.NUD_WhiteBlobMura_Elongation_Max.Value = mpr.WhiteBlobMura_ElongationMax.Value

            If Me.NUD_WhiteAGM_AreaMin.Maximum >= mpr.WhiteAGM_AreaMin.Value Then Me.NUD_WhiteAGM_AreaMin.Value = mpr.WhiteAGM_AreaMin.Value Else MuraUpdateDataLog &= "[JND�]�w] White AGM_AreaMin �]�w�W�X�d�� (Max =" & Me.NUD_WhiteAGM_AreaMin.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteAGM_AreaMax.Maximum >= mpr.WhiteAGM_AreaMax.Value Then Me.NUD_WhiteAGM_AreaMax.Value = mpr.WhiteAGM_AreaMax.Value Else MuraUpdateDataLog &= "[JND�]�w] White AGM_AreaMax �]�w�W�X�d�� (Max =" & Me.NUD_WhiteAGM_AreaMax.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteAGM_JND_Min.Maximum >= mpr.WhiteAGM_JNDMin.Value Then Me.NUD_WhiteAGM_JND_Min.Value = mpr.WhiteAGM_JNDMin.Value Else MuraUpdateDataLog &= "[JND�]�w] White AGM_JND �]�w�W�X�d�� (Max =" & Me.NUD_WhiteAGM_JND_Min.Maximum & ")" & vbCrLf
            Me.NUD_WhiteAGM_JND_Max.Value = mpr.WhiteAGM_JNDMax.Value
            Me.NUD_WhiteAGM_Elongation_Min.Value = mpr.WhiteAGM_ElongationMin.Value
            Me.NUD_WhiteAGM_Elongation_Max.Value = mpr.WhiteAGM_ElongationMax.Value

            If Me.NUD_WhiteMacroMura_AreaMin.Maximum >= mpr.WhiteMacroMura_AreaMin.Value Then Me.NUD_WhiteMacroMura_AreaMin.Value = mpr.WhiteMacroMura_AreaMin.Value Else MuraUpdateDataLog &= "[JND�]�w] White Macro_AreaMin �]�w�W�X�d�� (Max =" & Me.NUD_WhiteMacroMura_AreaMin.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteMacroMura_AreaMax.Maximum >= mpr.WhiteMacroMura_AreaMax.Value Then Me.NUD_WhiteMacroMura_AreaMax.Value = mpr.WhiteMacroMura_AreaMax.Value Else MuraUpdateDataLog &= "[JND�]�w] White Macro_AreaMax �]�w�W�X�d�� (Max =" & Me.NUD_WhiteMacroMura_AreaMax.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteMacroMura_JND.Maximum >= mpr.WhiteMacroMura_JND.Value Then Me.NUD_WhiteMacroMura_JND.Value = mpr.WhiteMacroMura_JND.Value Else MuraUpdateDataLog &= "[JND�]�w] White MacroMura_JND �]�w�W�X�d�� (Max =" & Me.NUD_WhiteMacroMura_JND.Maximum & ")" & vbCrLf

            If Me.NUD_WhiteBandMura_WidthMin.Maximum >= mpr.WhiteBandMura_WidthMin.Value Then Me.NUD_WhiteBandMura_WidthMin.Value = mpr.WhiteBandMura_WidthMin.Value Else MuraUpdateDataLog &= "[JND�]�w] White BandMura_WidthMin �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBandMura_WidthMin.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteBandMura_JND.Maximum >= mpr.WhiteBandMura_JND.Value Then Me.NUD_WhiteBandMura_JND.Value = mpr.WhiteBandMura_JND.Value Else MuraUpdateDataLog &= "[JND�]�w] White BandMura_JND �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBandMura_JND.Maximum & ")" & vbCrLf
            If Me.NUD_WhiteBandMura_SJND.Maximum >= mpr.WhiteBandMura_SJND.Value Then Me.NUD_WhiteBandMura_SJND.Value = mpr.WhiteBandMura_SJND.Value Else MuraUpdateDataLog &= "[JND�]�w] White BandMura_SJND �]�w�W�X�d�� (Max =" & Me.NUD_WhiteBandMura_SJND.Maximum & ")" & vbCrLf

            '--- Black ---
            If Me.NUD_BlackBlobMura_AreaMin.Maximum >= mpr.BlackBlobMura_AreaMin.Value Then Me.NUD_BlackBlobMura_AreaMin.Value = mpr.BlackBlobMura_AreaMin.Value Else MuraUpdateDataLog &= "[JND�]�w] Black Blob_AreaMin �]�w�W�X�d�� (Max =" & Me.NUD_BlackBlobMura_AreaMin.Maximum & ")" & vbCrLf
            If Me.NUD_BlackBlobMura_AreaMax.Maximum >= mpr.BlackBlobMura_AreaMax.Value Then Me.NUD_BlackBlobMura_AreaMax.Value = mpr.BlackBlobMura_AreaMax.Value Else MuraUpdateDataLog &= "[JND�]�w] Black Blob_AreaMax �]�w�W�X�d�� (Max =" & Me.NUD_BlackBlobMura_AreaMax.Maximum & ")" & vbCrLf
            If Me.NUD_BlackBlobMura_JND_Min.Maximum >= mpr.BlackBlobMura_JNDMin.Value Then Me.NUD_BlackBlobMura_JND_Min.Value = mpr.BlackBlobMura_JNDMin.Value Else MuraUpdateDataLog &= "[JND�]�w] Black BlobMura_JND �]�w�W�X�d�� (Max =" & Me.NUD_BlackBlobMura_JND_Min.Maximum & ")" & vbCrLf
            Me.NUD_BlackBlobMura_JND_Max.Value = mpr.BlackBlobMura_JNDMax.Value
            Me.NUD_BlackBlobMura_Elongation_Min.Value = mpr.BlackBlobMura_ElongationMin.Value
            Me.NUD_BlackBlobMura_Elongation_Max.Value = mpr.BlackBlobMura_ElongationMax.Value

            If Me.NUD_BlackAGM_AreaMin.Maximum >= mpr.BlackAGM_AreaMin.Value Then Me.NUD_BlackAGM_AreaMin.Value = mpr.BlackAGM_AreaMin.Value Else MuraUpdateDataLog &= "[JND�]�w] Black AGM_AreaMin �]�w�W�X�d�� (Max =" & Me.NUD_BlackAGM_AreaMin.Maximum & ")" & vbCrLf
            If Me.NUD_BlackAGM_AreaMax.Maximum >= mpr.BlackAGM_AreaMax.Value Then Me.NUD_BlackAGM_AreaMax.Value = mpr.BlackAGM_AreaMax.Value Else MuraUpdateDataLog &= "[JND�]�w] Black AGM_AreaMax �]�w�W�X�d�� (Max =" & Me.NUD_BlackAGM_AreaMax.Maximum & ")" & vbCrLf
            If Me.NUD_BlackAGM_JND_Min.Maximum >= mpr.BlackAGM_JNDMin.Value Then Me.NUD_BlackAGM_JND_Min.Value = mpr.BlackAGM_JNDMin.Value Else MuraUpdateDataLog &= "[JND�]�w] Black AGM_JND �]�w�W�X�d�� (Max =" & Me.NUD_BlackAGM_JND_Min.Maximum & ")" & vbCrLf
            Me.NUD_BlackAGM_JND_Max.Value = mpr.BlackAGM_JNDMax.Value
            Me.NUD_BlackAGM_Elongation_Min.Value = mpr.BlackAGM_ElongationMin.Value
            Me.NUD_BlackAGM_Elongation_Max.Value = mpr.BlackAGM_ElongationMax.Value

            If Me.NUD_BlackMacroMura_AreaMin.Maximum >= mpr.BlackMacroMura_AreaMin.Value Then Me.NUD_BlackMacroMura_AreaMin.Value = mpr.BlackMacroMura_AreaMin.Value Else MuraUpdateDataLog &= "[JND�]�w] Black Macro_AreaMin �]�w�W�X�d�� (Max =" & Me.NUD_BlackMacroMura_AreaMin.Maximum & ")" & vbCrLf
            If Me.NUD_BlackMacroMura_AreaMax.Maximum >= mpr.BlackMacroMura_AreaMax.Value Then Me.NUD_BlackMacroMura_AreaMax.Value = mpr.BlackMacroMura_AreaMax.Value Else MuraUpdateDataLog &= "[JND�]�w] Black Macro_AreaMax �]�w�W�X�d�� (Max =" & Me.NUD_BlackMacroMura_AreaMax.Maximum & ")" & vbCrLf
            If Me.NUD_BlackMacroMura_JND.Maximum >= mpr.BlackMacroMura_JND.Value Then Me.NUD_BlackMacroMura_JND.Value = mpr.BlackMacroMura_JND.Value Else MuraUpdateDataLog &= "[JND�]�w] Black MacroMura_JND �]�w�W�X�d�� (Max =" & Me.NUD_BlackMacroMura_JND.Maximum & ")" & vbCrLf

            If Me.NUD_BlackBandMura_WidthMin.Maximum >= mpr.BlackBandMura_WidthMin.Value Then Me.NUD_BlackBandMura_WidthMin.Value = mpr.BlackBandMura_WidthMin.Value Else MuraUpdateDataLog &= "[JND�]�w] Black BandMura_WidthMin �]�w�W�X�d�� (Max =" & Me.NUD_BlackBandMura_WidthMin.Maximum & ")" & vbCrLf
            If Me.NUD_BlackBandMura_JND.Maximum >= mpr.BlackBandMura_JND.Value Then Me.NUD_BlackBandMura_JND.Value = mpr.BlackBandMura_JND.Value Else MuraUpdateDataLog &= "[JND�]�w] Black BandMura_JND �]�w�W�X�d�� (Max =" & Me.NUD_BlackBandMura_JND.Maximum & ")" & vbCrLf
            If Me.NUD_BlackBandMura_SJND.Maximum >= mpr.BlackBandMura_SJND.Value Then Me.NUD_BlackBandMura_SJND.Value = mpr.BlackBandMura_SJND.Value Else MuraUpdateDataLog &= "[JND�]�w] Black BandMura_SJND �]�w�W�X�d�� (Max =" & Me.NUD_BlackBandMura_SJND.Maximum & ")" & vbCrLf

            '--- Page 7 --- (SAVE)
            Me.CheckBox_SaveOriginal.Checked = mpr.SaveOriginal.Value
            Me.CheckBox_SaveDefocus.Checked = mpr.SaveDefocus.Value
            Me.CheckBox_SaveSmooth.Checked = mpr.SaveSmooth.Value
            Me.CheckBox_SaveResizeBMP.Checked = mpr.SaveResizeBMP.Value
            Me.CheckBox_SaveWhiteThreshold.Checked = mpr.SaveWhiteThreshold.Value
            Me.CheckBox_SaveWhiteReconstructArea.Checked = mpr.SaveWhiteReconstructArea.Value
            Me.CheckBox_SaveWhiteReconstructRim.Checked = mpr.SaveWhiteReconstructRim.Value
            Me.CheckBox_SaveBlackThreshold.Checked = mpr.SaveBlackThreshold.Value
            Me.CheckBox_SaveBlackReconstructArea.Checked = mpr.SaveBlackReconstructArea.Value
            Me.CheckBox_SaveBlackReconstructRim.Checked = mpr.SaveBlackReconstructRim.Value
            Me.CheckBox_SaveVBand.Checked = mpr.SaveVBand.Value
            Me.CheckBox_SaveHBand.Checked = mpr.SaveHBand.Value
            Me.CheckBox_SaveFFCAlignResult.Checked = mpr.SaveFFCAlignResult.Value
            Me.CheckBox_SaveFFTResult.Checked = mpr.SaveFFTResult.Value

            '--- Page 8 --- (AUTO)
            Me.NumericUpDown_AutoExposure_TargetMean.Maximum = GrayLevel_Maximum
            If Me.NumericUpDown_AutoExposure_Kp.Maximum >= mpr.AutoExposure_Kp.Value Then Me.NumericUpDown_AutoExposure_Kp.Value = mpr.AutoExposure_Kp.Value Else MuraUpdateDataLog &= "[Auto] AutoExposure_Kp �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AutoExposure_Kp.Maximum & ")" & vbCrLf
            If mpr.AutoExposure_TargetMean.Value >= GrayLevel_Maximum Then
                mpr.AutoExposure_TargetMean.Value = GrayLevel_Maximum
                Me.NumericUpDown_AutoExposure_TargetMean.Value = mpr.AutoExposure_TargetMean.Value
            Else
                Me.NumericUpDown_AutoExposure_TargetMean.Value = mpr.AutoExposure_TargetMean.Value
            End If

            If Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum >= mpr.AutoExposure_LargeErrorRange_UL.Value Then Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value = mpr.AutoExposure_LargeErrorRange_UL.Value Else MuraUpdateDataLog &= "[Auto] AutoExposure_LargeErrorRange_UL �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum >= mpr.AutoExposure_LargeErrorRange_DL.Value Then Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value = mpr.AutoExposure_LargeErrorRange_DL.Value Else MuraUpdateDataLog &= "[Auto] AutoExposure_LargeErrorRange_DL �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_AutoExposure_SmallErrorRange.Maximum >= mpr.AutoExposure_SmallErrorRange.Value Then Me.NumericUpDown_AutoExposure_SmallErrorRange.Value = mpr.AutoExposure_SmallErrorRange.Value Else MuraUpdateDataLog &= "[Auto] AutoExposure_SmallErrorRange �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AutoExposure_SmallErrorRange.Maximum & ")" & vbCrLf
            If Me.NumericUpDown_AutoExposure_GrabDelayTime.Maximum >= mpr.AutoExposure_GrabDelayTime.Value Then Me.NumericUpDown_AutoExposure_GrabDelayTime.Value = mpr.AutoExposure_GrabDelayTime.Value Else MuraUpdateDataLog &= "[Auto] AutoExposure_GrabDelayTime �]�w�W�X�d�� (Max =" & Me.NumericUpDown_AutoExposure_GrabDelayTime.Maximum & ")" & vbCrLf

            '--- Page 9 --- (Abnormal)
            Me.CheckBox_GrayAbnormal_Enable.Checked = mpr.GrayAbnormalEnable.Value
            Me.CheckBox_MultiRegion.Checked = mpr.MultiRegion.Value
            Me.NumericUpDown_GrayAbnormal_PosLimit_1.Value = mpr.DisplayMeanOffsetRecipe1.PosLimit.Value
            Me.NumericUpDown_GrayAbnormal_NegLimit_1.Value = mpr.DisplayMeanOffsetRecipe1.NegLimit.Value
            Me.NumericUpDown_GrayAbnormalStandardGray_1.Value = mpr.DisplayMeanOffsetRecipe1.StandardGray.Value
            Me.Lbl_GrayAbnormal_PosLimit_1.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_1.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit_1.Value) / 100), "#"))   '2009/10/23 Rick add
            Me.Lbl_GrayAbnormal_NegLimit_1.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_1.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit_1.Value) / 100), "#"))   '2009/10/23 Rick add
            Me.NumericUpDown_GrayAbnormal_PosLimit_2.Value = mpr.DisplayMeanOffsetRecipe2.PosLimit.Value
            Me.NumericUpDown_GrayAbnormal_NegLimit_2.Value = mpr.DisplayMeanOffsetRecipe2.NegLimit.Value
            Me.NumericUpDown_GrayAbnormalStandardGray_2.Value = mpr.DisplayMeanOffsetRecipe2.StandardGray.Value
            Me.Lbl_GrayAbnormal_PosLimit_2.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_2.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit_2.Value) / 100), "#"))   '2009/10/23 Rick add
            Me.Lbl_GrayAbnormal_NegLimit_2.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_2.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit_2.Value) / 100), "#"))   '2009/10/23 Rick add
            Me.NumericUpDown_GrayAbnormal_PosLimit_3.Value = mpr.DisplayMeanOffsetRecipe3.PosLimit.Value
            Me.NumericUpDown_GrayAbnormal_NegLimit_3.Value = mpr.DisplayMeanOffsetRecipe3.NegLimit.Value
            Me.NumericUpDown_GrayAbnormalStandardGray_3.Value = mpr.DisplayMeanOffsetRecipe3.StandardGray.Value
            Me.Lbl_GrayAbnormal_PosLimit_3.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_3.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit_3.Value) / 100), "#"))   '2009/10/23 Rick add
            Me.Lbl_GrayAbnormal_NegLimit_3.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_3.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit_3.Value) / 100), "#"))   '2009/10/23 Rick add


            If MuraUpdateDataLog.Length > 0 Then Throw New Exception(MuraUpdateDataLog)
        Catch ex As Exception
            Button_Enable(True)
            MsgBox("[Dialog_MuraSetting] �ѼƸ��JForm�X���G" & vbCrLf & ex.Message & "�A�нT�{�C", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try
    End Sub
#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim mpr As ClsMuraPatternRecipe
        Dim mmr As ClsMuraModelRecipe
        Dim boundary As ClsParameterBoundary

        Try
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MainProcess.MuraPatternRecipeArrayOrder.Count Then
                mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
            Else
                mpr = Me.m_MuraProcess.MuraPatternRecipeArray.Item(0)
            End If
            mmr = Me.m_MuraProcess.MuraModelRecipe

            '--- Page 1 ---
            mpr.DefocusCount.Value = Me.NumericUpDown_DefocusCount.Value
            mmr.PitchX.Value = Me.NumericUpDown_PitchX.Value
            mmr.PitchY.Value = Me.NumericUpDown_PitchY.Value

            mpr.BlobMura_GlobleSmooth.Value = Me.NumericUpDown_BlobMura_GlobleSmooth.Value
            mpr.MacroMura_GlobleSmooth.Value = Me.NumericUpDown_MacroMura_GlobleSmooth.Value

            mpr.UseFFC.Value = Me.CheckBox_UseFFC.Checked
            mmr.UseBLFFC.Value = Me.CheckBox_UseBLFFC.Checked
            mpr.AlignValue.Value = Me.NumericUpDown_AlignValue.Value
            mpr.AlignPercentage.Value = Me.NumericUpDown_AlignPercentage.Value

            mpr.RemoveHVBand.Value = Me.CheckBox_RemoveHVBand.Checked

            mpr.UseFFT.Value = Me.CheckBox_UseFFT.Checked
            mpr.FFTFilterRadius.Value = Me.NumericUpDown_FFTFilterRadius.Value

            '--- Page 2 ---
            mpr.UseCenter.Value = Me.CheckBox_Center.Checked
            mpr.WhiteBlobMura_BinarizeHeight.Value = Me.NUD_WhiteBlobMura_ReconstructHeight.Value
            mpr.WhiteBlobMura_BinarizeLow.Value = Me.NUD_WhiteBlobMura_ReconstructLow.Value
            mpr.BlackBlobMura_BinarizeHeight.Value = Me.NUD_BlackBlobMura_ReconstructHeight.Value
            mpr.BlackBlobMura_BinarizeLow.Value = Me.NUD_BlackBlobMura_ReconstructLow.Value

            mpr.WhiteMacroMura_Threshold.Value = Me.NUD_WhiteMacroMura_Threshold.Value
            mpr.BlackMacroMura_Threshold.Value = Me.NUD_BlackMacroMura_Threshold.Value

            mpr.ResizeCount_min.Value = Me.Num_ResizeCount_Min.Value
            mpr.ResizeCount_mid.Value = Me.Num_ResizeCount_Mid.Value
            mpr.ResizeCount_max.Value = Me.Num_ResizeCount_Max.Value

            mpr.UseBaseLine.Value = Me.CheckBox_UseBaseLine.Checked
            mpr.MacroPowerX.Value = Me.NumericUpDown_MacroPowerX.Value
            mpr.MacroPowerY.Value = Me.NumericUpDown_MacroPowerY.Value

            boundary = mmr.BoundaryRound
            boundary.TopY = Me.NumericUpDown_AreaTop.Value
            boundary.BottomY = Me.NumericUpDown_AreaBottom.Value
            boundary.LeftX = Me.NumericUpDown_AreaLeft.Value
            boundary.RightX = Me.NumericUpDown_AreaRight.Value

            mpr.UseReconstructBW.Value = Me.CheckBox_UseReconstructBW.Checked

            mpr.BlobMulRatio.Value = Me.NumericUpDown_BlobMulRatio.Value

            '--- Page 3---
            '(WithCore)
            mpr.CPDRecipe.WithCoreCPD_Enable = Me.CheckBox_WithCoreCPD_Enable.Checked
            mpr.CPDRecipe.WithCoreWhiteCPD_ThHigh = Me.NumericUpDown_WithCoreWhiteCPD_ThHigh.Value
            mpr.CPDRecipe.WithCoreWhiteCPD_ThLow = Me.NumericUpDown_WithCoreWhiteCPD_ThLow.Value
            mpr.CPDRecipe.WithCoreBlackCPD_ThHigh = Me.NumericUpDown_WithCoreBlackCPD_ThHigh.Value
            mpr.CPDRecipe.WithCoreBlackCPD_ThLow = Me.NumericUpDown_WithCoreBlackCPD_ThLow.Value
            mpr.CPDRecipe.WithCoreWhiteCPDCompactness_Low = Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low.Value
            mpr.CPDRecipe.WithCoreWhiteCPDCompactness_High = Me.NumericUpDown_WithCoreWhiteCPDCompactness_High.Value
            mpr.CPDRecipe.WithCoreBlackCPDCompactness_Low = Me.NumericUpDown_WithCoreBlackCPDCompactness_Low.Value
            mpr.CPDRecipe.WithCoreBlackCPDCompactness_High = Me.NumericUpDown_WithCoreBlackCPDCompactness_High.Value
            mpr.CPDRecipe.WithCoreWhiteCPDElongation_Low = Me.NumericUpDown_WithCoreWhiteCPDElongation_Low.Value
            mpr.CPDRecipe.WithCoreWhiteCPDElongation_High = Me.NumericUpDown_WithCoreWhiteCPDElongation_High.Value
            mpr.CPDRecipe.WithCoreBlackCPDElongation_Low = Me.NumericUpDown_WithCoreBlackCPDElongation_Low.Value
            mpr.CPDRecipe.WithCoreBlackCPDElongation_High = Me.NumericUpDown_WithCoreBlackCPDElongation_High.Value
            mpr.CPDRecipe.WithCoreWhiteCPDBreadth_Low = Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low.Value
            mpr.CPDRecipe.WithCoreWhiteCPDBreadth_High = Me.NumericUpDown_WithCoreWhiteCPDBreadth_High.Value
            mpr.CPDRecipe.WithCoreBlackCPDBreadth_Low = Me.NumericUpDown_WithCoreBlackCPDBreadth_Low.Value
            mpr.CPDRecipe.WithCoreBlackCPDBreadth_High = Me.NumericUpDown_WithCoreBlackCPDBreadth_High.Value
            '(WithoutCore)
            mpr.CPDRecipe.WithoutCoreCPD_Enable = Me.CheckBox_WithoutCoreCPD_Enable.Checked
            mpr.CPDRecipe.WithoutCoreWhiteCPD_ThHigh = Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh.Value
            mpr.CPDRecipe.WithoutCoreWhiteCPD_ThLow = Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow.Value
            mpr.CPDRecipe.WithoutCoreBlackCPD_ThHigh = Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh.Value
            mpr.CPDRecipe.WithoutCoreBlackCPD_ThLow = Me.NumericUpDown_WithoutCoreBlackCPD_ThLow.Value
            mpr.CPDRecipe.WithoutCoreWhiteCPDCompactness_Low = Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low.Value
            mpr.CPDRecipe.WithoutCoreWhiteCPDCompactness_High = Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High.Value
            mpr.CPDRecipe.WithoutCoreBlackCPDCompactness_Low = Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low.Value
            mpr.CPDRecipe.WithoutCoreBlackCPDCompactness_High = Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High.Value
            mpr.CPDRecipe.WithoutCoreWhiteCPDElongation_Low = Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low.Value
            mpr.CPDRecipe.WithoutCoreWhiteCPDElongation_High = Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High.Value
            mpr.CPDRecipe.WithoutCoreBlackCPDElongation_Low = Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low.Value
            mpr.CPDRecipe.WithoutCoreBlackCPDElongation_High = Me.NumericUpDown_WithoutCoreBlackCPDElongation_High.Value
            mpr.CPDRecipe.WithoutCoreWhiteCPDBreadth_Low = Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low.Value
            mpr.CPDRecipe.WithoutCoreWhiteCPDBreadth_High = Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High.Value
            mpr.CPDRecipe.WithoutCoreBlackCPDBreadth_Low = Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low.Value
            mpr.CPDRecipe.WithoutCoreBlackCPDBreadth_High = Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High.Value

            '--- Page 4 ---
            mpr.UseRound.Value = Me.CheckBox_Rim.Checked
            mpr.WhiteMura_ThresholdHeight.Value = Me.NumericUpDown_WhiteMura_RimHeight.Value
            mpr.WhiteMura_ThresholdLow.Value = Me.NumericUpDown_WhiteMura_RimLow.Value

            mpr.BlackMura_ThresholdHeight.Value = Me.NumericUpDown_BlackMura_RimHeight.Value
            mpr.BlackMura_ThresholdLow.Value = Me.NumericUpDown_BlackMura_RimLow.Value

            mmr.GoldenResizeCount.Value = Me.NumericUpDown_Resize.Text
            mpr.SmoothCount.Value = Me.NumericUpDown_Smooth.Text

            boundary = mpr.Rim
            boundary.TopY = Me.NumericUpDown_RimTop.Value
            boundary.BottomY = Me.NumericUpDown_RimBottom.Value
            boundary.LeftX = Me.NumericUpDown_RimLeft.Value
            boundary.RightX = Me.NumericUpDown_RimRight.Value

            '--- Page 5 ---
            mpr.UseBand.Value = Me.CheckBox_Band.Checked
            mpr.BandMura_ResizeCount.Value = Me.NumericUpDown_BandMura_ResizeCount.Value
            mpr.BandMura_SmoothCount.Value = Me.NumericUpDown_BandMura_SmoothCount.Value
            mpr.WhiteHBand_Threshold.Value = Me.NumericUpDown_WhiteHBand_Threshold.Value
            mpr.BlackHBand_Threshold.Value = Me.NumericUpDown_BlackHBand_Threshold.Value
            mpr.WhiteVBand_Threshold.Value = Me.NumericUpDown_WhiteVBand_Threshold.Value
            mpr.BlackVBand_Threshold.Value = Me.NumericUpDown_BlackVBand_Threshold.Value

            mpr.HBand.TopY = Me.NumericUpDown_HTop.Value
            mpr.HBand.BottomY = Me.NumericUpDown_HBottom.Value
            mpr.HBand.LeftX = Me.NumericUpDown_HLeft.Value
            mpr.HBand.RightX = Me.NumericUpDown_HRight.Value
            mpr.VBand.TopY = Me.NumericUpDown_VTop.Value
            mpr.VBand.BottomY = Me.NumericUpDown_VBottom.Value
            mpr.VBand.LeftX = Me.NumericUpDown_VLeft.Value
            mpr.VBand.RightX = Me.NumericUpDown_VRight.Value


            '--- Page 6 ---
            '(White)
            mpr.WhiteBlobMura_AreaMin.Value = Me.NUD_WhiteBlobMura_AreaMin.Value
            mpr.WhiteBlobMura_AreaMax.Value = Me.NUD_WhiteBlobMura_AreaMax.Value
            mpr.WhiteBlobMura_JNDMin.Value = Me.NUD_WhiteBlobMura_JND_Min.Value
            mpr.WhiteBlobMura_JNDMax.Value = Me.NUD_WhiteBlobMura_JND_Max.Value
            mpr.WhiteBlobMura_ElongationMin.Value = Me.NUD_WhiteBlobMura_Elongation_Min.Value
            mpr.WhiteBlobMura_ElongationMax.Value = Me.NUD_WhiteBlobMura_Elongation_Max.Value

            mpr.WhiteAGM_AreaMin.Value = Me.NUD_WhiteAGM_AreaMin.Value
            mpr.WhiteAGM_AreaMax.Value = Me.NUD_WhiteAGM_AreaMax.Value
            mpr.WhiteAGM_JNDMin.Value = Me.NUD_WhiteAGM_JND_Min.Value
            mpr.WhiteAGM_JNDMax.Value = Me.NUD_WhiteAGM_JND_Max.Value
            mpr.WhiteAGM_ElongationMin.Value = Me.NUD_WhiteAGM_Elongation_Min.Value
            mpr.WhiteAGM_ElongationMax.Value = Me.NUD_WhiteAGM_Elongation_Max.Value

            mpr.WhiteMacroMura_AreaMin.Value = Me.NUD_WhiteMacroMura_AreaMin.Value
            mpr.WhiteMacroMura_AreaMax.Value = Me.NUD_WhiteMacroMura_AreaMax.Value
            mpr.WhiteMacroMura_JND.Value = Me.NUD_WhiteMacroMura_JND.Value

            mpr.WhiteBandMura_WidthMin.Value = Me.NUD_WhiteBandMura_WidthMin.Value
            mpr.WhiteBandMura_JND.Value = Me.NUD_WhiteBandMura_JND.Value
            mpr.WhiteBandMura_SJND.Value = Me.NUD_WhiteBandMura_SJND.Value

            '(Black)
            mpr.BlackBlobMura_AreaMin.Value = Me.NUD_BlackBlobMura_AreaMin.Value
            mpr.BlackBlobMura_AreaMax.Value = Me.NUD_BlackBlobMura_AreaMax.Value
            mpr.BlackBlobMura_JNDMin.Value = Me.NUD_BlackBlobMura_JND_Min.Value
            mpr.BlackBlobMura_JNDMax.Value = Me.NUD_BlackBlobMura_JND_Max.Value
            mpr.BlackBlobMura_ElongationMin.Value = Me.NUD_BlackBlobMura_Elongation_Min.Value
            mpr.BlackBlobMura_ElongationMax.Value = Me.NUD_BlackBlobMura_Elongation_Max.Value

            mpr.BlackAGM_AreaMin.Value = Me.NUD_BlackAGM_AreaMin.Value
            mpr.BlackAGM_AreaMax.Value = Me.NUD_BlackAGM_AreaMax.Value
            mpr.BlackAGM_JNDMin.Value = Me.NUD_BlackAGM_JND_Min.Value
            mpr.BlackAGM_JNDMax.Value = Me.NUD_BlackAGM_JND_Max.Value
            mpr.BlackAGM_ElongationMin.Value = Me.NUD_BlackAGM_Elongation_Min.Value
            mpr.BlackAGM_ElongationMax.Value = Me.NUD_BlackAGM_Elongation_Max.Value

            mpr.BlackMacroMura_AreaMin.Value = Me.NUD_BlackMacroMura_AreaMin.Value
            mpr.BlackMacroMura_AreaMax.Value = Me.NUD_BlackMacroMura_AreaMax.Value
            mpr.BlackMacroMura_JND.Value = Me.NUD_BlackMacroMura_JND.Value

            mpr.BlackBandMura_WidthMin.Value = Me.NUD_BlackBandMura_WidthMin.Value
            mpr.BlackBandMura_JND.Value = Me.NUD_BlackBandMura_JND.Value
            mpr.BlackBandMura_SJND.Value = Me.NUD_BlackBandMura_SJND.Value

            mpr.HVValueRecipe.UseHValue = Me.CheckBox_UseHValue.Checked
            mpr.HVValueRecipe.HSlope = Me.Label_HSlope.Text
            mpr.HVValueRecipe.HConst = Me.Label_HConst.Text
            mpr.HVValueRecipe.UseHBand = Me.CheckBox_HValue_UseHBand.Checked
            mpr.HVValueRecipe.WhiteHBandTH = Me.NumericUpDown_HValue_WhiteHBandTH.Value
            mpr.HVValueRecipe.BlackHBandTH = Me.NumericUpDown_HValue_BlackHBandTH.Value
            mpr.HVValueRecipe.UseVValue = Me.CheckBox_UseVValue.Checked
            mpr.HVValueRecipe.VSlope = Me.Label_VSlope.Text
            mpr.HVValueRecipe.VConst = Me.Label_VConst.Text
            mpr.HVValueRecipe.UseVBand = Me.CheckBox_VValue_UseVBand.Checked
            mpr.HVValueRecipe.WhiteVBandTH = Me.NumericUpDown_VValue_WhiteVBandTH.Value
            mpr.HVValueRecipe.BlackVBandTH = Me.NumericUpDown_VValue_BlackVBandTH.Value

            '--- Page 7 ---
            mpr.SaveOriginal.Value = Me.CheckBox_SaveOriginal.Checked
            mpr.SaveDefocus.Value = Me.CheckBox_SaveDefocus.Checked
            mpr.SaveSmooth.Value = Me.CheckBox_SaveSmooth.Checked
            mpr.SaveResizeBMP.Value = Me.CheckBox_SaveResizeBMP.Checked
            mpr.SaveWhiteThreshold.Value = Me.CheckBox_SaveWhiteThreshold.Checked
            mpr.SaveWhiteReconstructArea.Value = Me.CheckBox_SaveWhiteReconstructArea.Checked
            mpr.SaveWhiteReconstructRim.Value = Me.CheckBox_SaveWhiteReconstructRim.Checked

            mpr.SaveBlackThreshold.Value = Me.CheckBox_SaveBlackThreshold.Checked
            mpr.SaveBlackReconstructArea.Value = Me.CheckBox_SaveBlackReconstructArea.Checked
            mpr.SaveBlackReconstructRim.Value = Me.CheckBox_SaveBlackReconstructRim.Checked

            mpr.SaveVBand.Value = Me.CheckBox_SaveVBand.Checked
            mpr.SaveHBand.Value = Me.CheckBox_SaveHBand.Checked
            mpr.SaveFFCAlignResult.Value = Me.CheckBox_SaveFFCAlignResult.Checked
            mpr.SaveFFTResult.Value = Me.CheckBox_SaveFFTResult.Checked

            '--- Page 8 ---
            mpr.AutoExposure_Kp.Value = Me.NumericUpDown_AutoExposure_Kp.Value
            mpr.AutoExposure_TargetMean.Value = Me.NumericUpDown_AutoExposure_TargetMean.Value
            mpr.AutoExposure_LargeErrorRange_UL.Value = Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value
            mpr.AutoExposure_LargeErrorRange_DL.Value = Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value
            mpr.AutoExposure_SmallErrorRange.Value = Me.NumericUpDown_AutoExposure_SmallErrorRange.Value
            mpr.AutoExposure_GrabDelayTime.Value = Me.NumericUpDown_AutoExposure_GrabDelayTime.Value

            '--- Page 9 ---
            mpr.DisplayMeanOffsetRecipe1.PosLimit.Value = Me.NumericUpDown_GrayAbnormal_PosLimit_1.Value
            mpr.DisplayMeanOffsetRecipe1.NegLimit.Value = Me.NumericUpDown_GrayAbnormal_NegLimit_1.Value
            mpr.DisplayMeanOffsetRecipe1.StandardGray.Value = Me.NumericUpDown_GrayAbnormalStandardGray_1.Value
            mpr.DisplayMeanOffsetRecipe2.PosLimit.Value = Me.NumericUpDown_GrayAbnormal_PosLimit_2.Value
            mpr.DisplayMeanOffsetRecipe2.NegLimit.Value = Me.NumericUpDown_GrayAbnormal_NegLimit_2.Value
            mpr.DisplayMeanOffsetRecipe2.StandardGray.Value = Me.NumericUpDown_GrayAbnormalStandardGray_2.Value
            mpr.DisplayMeanOffsetRecipe3.PosLimit.Value = Me.NumericUpDown_GrayAbnormal_PosLimit_3.Value
            mpr.DisplayMeanOffsetRecipe3.NegLimit.Value = Me.NumericUpDown_GrayAbnormal_NegLimit_3.Value
            mpr.DisplayMeanOffsetRecipe3.StandardGray.Value = Me.NumericUpDown_GrayAbnormalStandardGray_3.Value
            mpr.GrayAbnormalEnable.Value = Me.CheckBox_GrayAbnormal_Enable.Checked
            mpr.MultiRegion.Value = Me.CheckBox_MultiRegion.Checked

        Catch ex As Exception
            Throw New Exception("[Dialog_MuraSetting.Setting]Setting Error! (" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Compare ---"
    Private Sub Compare(ByVal mprOld As ClsMuraPatternRecipe, ByVal mprNew As ClsMuraPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim boundaryOld As ClsParameterBoundary
        Dim boundaryNew As ClsParameterBoundary

        dlm.WriteLog("********************[MuraPatternRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        boundaryOld = mprOld.Rim
        boundaryNew = mprNew.Rim
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("< Rim.TopY >: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
            boundaryOld.TopY = boundaryNew.TopY
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("< Rim.BottomY >: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
            boundaryOld.BottomY = boundaryNew.BottomY
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("< Rim.LeftX >: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
            boundaryOld.LeftX = boundaryNew.LeftX
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("< Rim.RightX >: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
            boundaryOld.RightX = boundaryNew.RightX
        End If

        If mprOld.UseFFC.Value <> mprNew.UseFFC.Value Then
            dlm.WriteLog("< UseFFC >: " & mprOld.UseFFC.Value & " --> " & mprNew.UseFFC.Value)
            mprOld.UseFFC.Value = mprNew.UseFFC.Value
        End If
        If mprOld.AlignValue.Value <> mprNew.AlignValue.Value Then
            dlm.WriteLog("< AlignValue >: " & mprOld.AlignValue.Value & " --> " & mprNew.AlignValue.Value)
            mprOld.AlignValue.Value = mprNew.AlignValue.Value
        End If
        If mprOld.AlignPercentage.Value <> mprNew.AlignPercentage.Value Then
            dlm.WriteLog("< AlignPercentage >: " & mprOld.AlignPercentage.Value & " --> " & mprNew.AlignPercentage.Value)
            mprOld.AlignPercentage.Value = mprNew.AlignPercentage.Value
        End If

        If mprOld.BlobMura_GlobleSmooth.Value <> mprNew.BlobMura_GlobleSmooth.Value Then
            dlm.WriteLog("< BlobMura_GlobleSmooth >: " & mprOld.BlobMura_GlobleSmooth.Value & " --> " & mprNew.BlobMura_GlobleSmooth.Value)
            mprOld.BlobMura_GlobleSmooth.Value = mprNew.BlobMura_GlobleSmooth.Value
        End If
        If mprOld.MacroMura_GlobleSmooth.Value <> mprNew.MacroMura_GlobleSmooth.Value Then
            dlm.WriteLog("< MacroMura_GlobleSmooth >: " & mprOld.MacroMura_GlobleSmooth.Value & " --> " & mprNew.MacroMura_GlobleSmooth.Value)
            mprOld.MacroMura_GlobleSmooth.Value = mprNew.MacroMura_GlobleSmooth.Value
        End If
        If mprOld.SmoothCount.Value <> mprNew.SmoothCount.Value Then
            dlm.WriteLog("< SmoothCount >: " & mprOld.SmoothCount.Value & " --> " & mprNew.SmoothCount.Value)
            mprOld.SmoothCount.Value = mprNew.SmoothCount.Value
        End If
        If mprOld.DefocusCount.Value <> mprNew.DefocusCount.Value Then
            dlm.WriteLog("< DefocusCount >: " & mprOld.DefocusCount.Value & " --> " & mprNew.DefocusCount.Value)
            mprOld.DefocusCount.Value = mprNew.DefocusCount.Value
        End If

        If mprOld.WhiteBlobMura_BinarizeHeight.Value <> mprNew.WhiteBlobMura_BinarizeHeight.Value Then
            dlm.WriteLog("< WhiteBlobMura_BinarizeHeight >: " & mprOld.WhiteBlobMura_BinarizeHeight.Value & " --> " & mprNew.WhiteBlobMura_BinarizeHeight.Value)
            mprOld.WhiteBlobMura_BinarizeHeight.Value = mprNew.WhiteBlobMura_BinarizeHeight.Value
        End If
        If mprOld.WhiteBlobMura_BinarizeLow.Value <> mprNew.WhiteBlobMura_BinarizeLow.Value Then
            dlm.WriteLog("< WhiteBlobMura_BinarizeLow >: " & mprOld.WhiteBlobMura_BinarizeLow.Value & " --> " & mprNew.WhiteBlobMura_BinarizeLow.Value)
            mprOld.WhiteBlobMura_BinarizeLow.Value = mprNew.WhiteBlobMura_BinarizeLow.Value
        End If
        If mprOld.BlackBlobMura_BinarizeHeight.Value <> mprNew.BlackBlobMura_BinarizeHeight.Value Then
            dlm.WriteLog("< BlackBlobMura_BinarizeHeight >: " & mprOld.BlackBlobMura_BinarizeHeight.Value & " --> " & mprNew.BlackBlobMura_BinarizeHeight.Value)
            mprOld.BlackBlobMura_BinarizeHeight.Value = mprNew.BlackBlobMura_BinarizeHeight.Value
        End If
        If mprOld.BlackBlobMura_BinarizeLow.Value <> mprNew.BlackBlobMura_BinarizeLow.Value Then
            dlm.WriteLog("< BlackBlobMura_BinarizeLow >: " & mprOld.BlackBlobMura_BinarizeLow.Value & " --> " & mprNew.BlackBlobMura_BinarizeLow.Value)
            mprOld.BlackBlobMura_BinarizeLow.Value = mprNew.BlackBlobMura_BinarizeLow.Value
        End If

        If mprOld.WhiteMacroMura_Threshold.Value <> mprNew.WhiteMacroMura_Threshold.Value Then
            dlm.WriteLog("< WhiteMacroMura_Threshold >: " & mprOld.WhiteMacroMura_Threshold.Value & " --> " & mprNew.WhiteMacroMura_Threshold.Value)
            mprOld.WhiteMacroMura_Threshold.Value = mprNew.WhiteMacroMura_Threshold.Value
        End If
        If mprOld.BlackMacroMura_Threshold.Value <> mprNew.BlackMacroMura_Threshold.Value Then
            dlm.WriteLog("< BlackMacroMura_Threshold >: " & mprOld.BlackMacroMura_Threshold.Value & " --> " & mprNew.BlackMacroMura_Threshold.Value)
            mprOld.BlackMacroMura_Threshold.Value = mprNew.BlackMacroMura_Threshold.Value
        End If

        If mprOld.UseRound.Value <> mprNew.UseRound.Value Then
            dlm.WriteLog("< UseRound >: " & mprOld.UseRound.Value & " --> " & mprNew.UseRound.Value)
            mprOld.UseRound.Value = mprNew.UseRound.Value
        End If
        If mprOld.WhiteMura_ThresholdHeight.Value <> mprNew.WhiteMura_ThresholdHeight.Value Then
            dlm.WriteLog("< WhiteMura_ThresholdHeight >: " & mprOld.WhiteMura_ThresholdHeight.Value & " --> " & mprNew.WhiteMura_ThresholdHeight.Value)
            mprOld.WhiteMura_ThresholdHeight.Value = mprNew.WhiteMura_ThresholdHeight.Value
        End If
        If mprOld.WhiteMura_ThresholdLow.Value <> mprNew.WhiteMura_ThresholdLow.Value Then
            dlm.WriteLog("< WhiteMura_ThresholdLow >: " & mprOld.WhiteMura_ThresholdLow.Value & " --> " & mprNew.WhiteMura_ThresholdLow.Value)
            mprOld.WhiteMura_ThresholdLow.Value = mprNew.WhiteMura_ThresholdLow.Value
        End If

        If mprOld.BlackMura_ThresholdHeight.Value <> mprNew.BlackMura_ThresholdHeight.Value Then
            dlm.WriteLog("< BlackMura_ThresholdHeight >: " & mprOld.BlackMura_ThresholdHeight.Value & " --> " & mprNew.BlackMura_ThresholdHeight.Value)
            mprOld.BlackMura_ThresholdHeight.Value = mprNew.BlackMura_ThresholdHeight.Value
        End If
        If mprOld.BlackMura_ThresholdLow.Value <> mprNew.BlackMura_ThresholdLow.Value Then
            dlm.WriteLog("< BlackMura_ThresholdLow >: " & mprOld.BlackMura_ThresholdLow.Value & " --> " & mprNew.BlackMura_ThresholdLow.Value)
            mprOld.BlackMura_ThresholdLow.Value = mprNew.BlackMura_ThresholdLow.Value
        End If

        If mprOld.UseBand.Value <> mprNew.UseBand.Value Then
            dlm.WriteLog("< UseBand >: " & mprOld.UseBand.Value & " --> " & mprNew.UseBand.Value)
            mprOld.UseBand.Value = mprNew.UseBand.Value
        End If
        If mprOld.BandMura_ResizeCount.Value <> mprNew.BandMura_ResizeCount.Value Then
            dlm.WriteLog("< BandMura_ResizeCount >: " & mprOld.BandMura_ResizeCount.Value & " --> " & mprNew.BandMura_ResizeCount.Value)
            mprOld.BandMura_ResizeCount.Value = mprNew.BandMura_ResizeCount.Value
        End If
        If mprOld.BandMura_SmoothCount.Value <> mprNew.BandMura_SmoothCount.Value Then
            dlm.WriteLog("< BandMura_SmoothCount >: " & mprOld.BandMura_SmoothCount.Value & " --> " & mprNew.BandMura_SmoothCount.Value)
            mprOld.BandMura_SmoothCount.Value = mprNew.BandMura_SmoothCount.Value
        End If
        If mprOld.WhiteHBand_Threshold.Value <> mprNew.WhiteHBand_Threshold.Value Then
            dlm.WriteLog("< WhiteHBand_Threshold >: " & mprOld.WhiteHBand_Threshold.Value & " --> " & mprNew.WhiteHBand_Threshold.Value)
            mprOld.WhiteHBand_Threshold.Value = mprNew.WhiteHBand_Threshold.Value
        End If
        If mprOld.BlackHBand_Threshold.Value <> mprNew.BlackHBand_Threshold.Value Then
            dlm.WriteLog("< BlackHBand_Threshold >: " & mprOld.BlackHBand_Threshold.Value & " --> " & mprNew.BlackHBand_Threshold.Value)
            mprOld.BlackHBand_Threshold.Value = mprNew.BlackHBand_Threshold.Value
        End If
        If mprOld.WhiteVBand_Threshold.Value <> mprNew.WhiteVBand_Threshold.Value Then
            dlm.WriteLog("< WhiteVBand_Threshold >: " & mprOld.WhiteVBand_Threshold.Value & " --> " & mprNew.WhiteVBand_Threshold.Value)
            mprOld.WhiteVBand_Threshold.Value = mprNew.WhiteVBand_Threshold.Value
        End If
        If mprOld.BlackVBand_Threshold.Value <> mprNew.BlackVBand_Threshold.Value Then
            dlm.WriteLog("< BlackVBand_Threshold >: " & mprOld.BlackVBand_Threshold.Value & " --> " & mprNew.BlackVBand_Threshold.Value)
            mprOld.BlackVBand_Threshold.Value = mprNew.BlackVBand_Threshold.Value
        End If

        '--- WhiteBlobMura ---
        If mprOld.WhiteBlobMura_AreaMin.Value <> mprNew.WhiteBlobMura_AreaMin.Value Then
            dlm.WriteLog("< WhiteBlobMura_AreaMin >: " & mprOld.WhiteBlobMura_AreaMin.Value & " --> " & mprNew.WhiteBlobMura_AreaMin.Value)
            mprOld.WhiteBlobMura_AreaMin.Value = mprNew.WhiteBlobMura_AreaMin.Value
        End If
        If mprOld.WhiteBlobMura_AreaMax.Value <> mprNew.WhiteBlobMura_AreaMax.Value Then
            dlm.WriteLog("< WhiteBlobMura_AreaMax >: " & mprOld.WhiteBlobMura_AreaMax.Value & " --> " & mprNew.WhiteBlobMura_AreaMax.Value)
            mprOld.WhiteBlobMura_AreaMax.Value = mprNew.WhiteBlobMura_AreaMax.Value
        End If
        If mprOld.WhiteBlobMura_JNDMin.Value <> mprNew.WhiteBlobMura_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteBlobMura_JNDMin >: " & mprOld.WhiteBlobMura_JNDMin.Value & " --> " & mprNew.WhiteBlobMura_JNDMin.Value)
            mprOld.WhiteBlobMura_JNDMin.Value = mprNew.WhiteBlobMura_JNDMin.Value
        End If

        '--- WhiteAGM ---
        If mprOld.WhiteAGM_AreaMin.Value <> mprNew.WhiteAGM_AreaMin.Value Then
            dlm.WriteLog("< WhiteAGM_AreaMin >: " & mprOld.WhiteAGM_AreaMin.Value & " --> " & mprNew.WhiteAGM_AreaMin.Value)
            mprOld.WhiteAGM_AreaMin.Value = mprNew.WhiteAGM_AreaMin.Value
        End If
        If mprOld.WhiteAGM_AreaMax.Value <> mprNew.WhiteAGM_AreaMax.Value Then
            dlm.WriteLog("< WhiteAGM_AreaMax >: " & mprOld.WhiteAGM_AreaMax.Value & " --> " & mprNew.WhiteAGM_AreaMax.Value)
            mprOld.WhiteAGM_AreaMax.Value = mprNew.WhiteAGM_AreaMax.Value
        End If
        If mprOld.WhiteAGM_JNDMin.Value <> mprNew.WhiteAGM_JNDMin.Value Then
            dlm.WriteLog("< WhiteAGM_JNDMin >: " & mprOld.WhiteAGM_JNDMin.Value & " --> " & mprNew.WhiteAGM_JNDMin.Value)
            mprOld.WhiteAGM_JNDMin.Value = mprNew.WhiteAGM_JNDMin.Value
        End If

        '--- WhiteMacroMura ---
        If mprOld.WhiteMacroMura_AreaMin.Value <> mprNew.WhiteMacroMura_AreaMin.Value Then
            dlm.WriteLog("< WhiteMacroMura_AreaMin >: " & mprOld.WhiteMacroMura_AreaMin.Value & " --> " & mprNew.WhiteMacroMura_AreaMin.Value)
            mprOld.WhiteMacroMura_AreaMin.Value = mprNew.WhiteMacroMura_AreaMin.Value
        End If
        If mprOld.WhiteMacroMura_AreaMax.Value <> mprNew.WhiteMacroMura_AreaMax.Value Then
            dlm.WriteLog("< WhiteMacroMura_AreaMax >: " & mprOld.WhiteMacroMura_AreaMax.Value & " --> " & mprNew.WhiteMacroMura_AreaMax.Value)
            mprOld.WhiteMacroMura_AreaMax.Value = mprNew.WhiteMacroMura_AreaMax.Value
        End If
        If mprOld.WhiteMacroMura_JND.Value <> mprNew.WhiteMacroMura_JND.Value Then
            dlm.WriteLog("< WhiteMacroMura_JND >: " & mprOld.WhiteMacroMura_JND.Value & " --> " & mprNew.WhiteMacroMura_JND.Value)
            mprOld.WhiteMacroMura_JND.Value = mprNew.WhiteMacroMura_JND.Value
        End If

        '--- WhiteBandMura ---
        If mprOld.WhiteBandMura_WidthMin.Value <> mprNew.WhiteBandMura_WidthMin.Value Then
            dlm.WriteLog("< WhiteBandMura_WidthMin >: " & mprOld.WhiteBandMura_WidthMin.Value & " --> " & mprNew.WhiteBandMura_WidthMin.Value)
            mprOld.WhiteBandMura_WidthMin.Value = mprNew.WhiteBandMura_WidthMin.Value
        End If
        If mprOld.WhiteBandMura_JND.Value <> mprNew.WhiteBandMura_JND.Value Then
            dlm.WriteLog("< WhiteBandMura_JND >: " & mprOld.WhiteBandMura_JND.Value & " --> " & mprNew.WhiteBandMura_JND.Value)
            mprOld.WhiteBandMura_JND.Value = mprNew.WhiteBandMura_JND.Value
        End If
        If mprOld.WhiteBandMura_SJND.Value <> mprNew.WhiteBandMura_SJND.Value Then
            dlm.WriteLog("< WhiteBandMura_SJND >: " & mprOld.WhiteBandMura_SJND.Value & " --> " & mprNew.WhiteBandMura_SJND.Value)
            mprOld.WhiteBandMura_SJND.Value = mprNew.WhiteBandMura_SJND.Value
        End If

        '--- BlackBlobMura ---
        If mprOld.BlackBlobMura_AreaMin.Value <> mprNew.BlackBlobMura_AreaMin.Value Then
            dlm.WriteLog("< BlackBlobMura_AreaMin >: " & mprOld.BlackBlobMura_AreaMin.Value & " --> " & mprNew.BlackBlobMura_AreaMin.Value)
            mprOld.BlackBlobMura_AreaMin.Value = mprNew.BlackBlobMura_AreaMin.Value
        End If
        If mprOld.BlackBlobMura_AreaMax.Value <> mprNew.BlackBlobMura_AreaMax.Value Then
            dlm.WriteLog("< BlackBlobMura_AreaMax >: " & mprOld.BlackBlobMura_AreaMax.Value & " --> " & mprNew.BlackBlobMura_AreaMax.Value)
            mprOld.BlackBlobMura_AreaMax.Value = mprNew.BlackBlobMura_AreaMax.Value
        End If
        If mprOld.BlackBlobMura_JNDMin.Value <> mprNew.BlackBlobMura_JNDMin.Value Then
            dlm.WriteLog("< BlackBlobMura_JNDMin >: " & mprOld.BlackBlobMura_JNDMin.Value & " --> " & mprNew.BlackBlobMura_JNDMin.Value)
            mprOld.BlackBlobMura_JNDMin.Value = mprNew.BlackBlobMura_JNDMin.Value
        End If

        '--- BlackAGM ---
        If mprOld.BlackAGM_AreaMin.Value <> mprNew.BlackAGM_AreaMin.Value Then
            dlm.WriteLog("< BlackAGM_AreaMin >: " & mprOld.BlackAGM_AreaMin.Value & " --> " & mprNew.BlackAGM_AreaMin.Value)
            mprOld.BlackAGM_AreaMin.Value = mprNew.BlackAGM_AreaMin.Value
        End If
        If mprOld.BlackAGM_AreaMax.Value <> mprNew.BlackAGM_AreaMax.Value Then
            dlm.WriteLog("< BlackAGM_AreaMax >: " & mprOld.BlackAGM_AreaMax.Value & " --> " & mprNew.BlackAGM_AreaMax.Value)
            mprOld.BlackAGM_AreaMax.Value = mprNew.BlackAGM_AreaMax.Value
        End If
        If mprOld.BlackAGM_JNDMin.Value <> mprNew.BlackAGM_JNDMin.Value Then
            dlm.WriteLog("< BlackAGM_JND >: " & mprOld.BlackAGM_JNDMin.Value & " --> " & mprNew.BlackAGM_JNDMin.Value)
            mprOld.BlackAGM_JNDMin.Value = mprNew.BlackAGM_JNDMin.Value
        End If

        '--- BlackMacroMura ---
        If mprOld.BlackMacroMura_AreaMin.Value <> mprNew.BlackMacroMura_AreaMin.Value Then
            dlm.WriteLog("< BlackMacroMura_AreaMin >: " & mprOld.BlackMacroMura_AreaMin.Value & " --> " & mprNew.BlackMacroMura_AreaMin.Value)
            mprOld.BlackMacroMura_AreaMin.Value = mprNew.BlackMacroMura_AreaMin.Value
        End If
        If mprOld.BlackMacroMura_AreaMax.Value <> mprNew.BlackMacroMura_AreaMax.Value Then
            dlm.WriteLog("< BlackMacroMura_AreaMax >: " & mprOld.BlackMacroMura_AreaMax.Value & " --> " & mprNew.BlackMacroMura_AreaMax.Value)
            mprOld.BlackMacroMura_AreaMax.Value = mprNew.BlackMacroMura_AreaMax.Value
        End If
        If mprOld.BlackMacroMura_JND.Value <> mprNew.BlackMacroMura_JND.Value Then
            dlm.WriteLog("< BlackMacroMura_JND >: " & mprOld.BlackMacroMura_JND.Value & " --> " & mprNew.BlackMacroMura_JND.Value)
            mprOld.BlackMacroMura_JND.Value = mprNew.BlackMacroMura_JND.Value
        End If

        '--- BlackBandMura ---
        If mprOld.BlackBandMura_WidthMin.Value <> mprNew.BlackBandMura_WidthMin.Value Then
            dlm.WriteLog("< BlackBandMura_WidthMin >: " & mprOld.BlackBandMura_WidthMin.Value & " --> " & mprNew.BlackBandMura_WidthMin.Value)
            mprOld.BlackBandMura_WidthMin.Value = mprNew.BlackBandMura_WidthMin.Value
        End If
        If mprOld.BlackBandMura_JND.Value <> mprNew.BlackBandMura_JND.Value Then
            dlm.WriteLog("< BlackBandMura_JND >: " & mprOld.BlackBandMura_JND.Value & " --> " & mprNew.BlackBandMura_JND.Value)
            mprOld.BlackBandMura_JND.Value = mprNew.BlackBandMura_JND.Value
        End If
        If mprOld.BlackBandMura_SJND.Value <> mprNew.BlackBandMura_SJND.Value Then
            dlm.WriteLog("< BlackBandMura_SJND >: " & mprOld.BlackBandMura_SJND.Value & " --> " & mprNew.BlackBandMura_SJND.Value)
            mprOld.BlackBandMura_SJND.Value = mprNew.BlackBandMura_SJND.Value
        End If

        If mprOld.SaveOriginal.Value <> mprNew.SaveOriginal.Value Then
            dlm.WriteLog("< SaveOriginal >: " & mprOld.SaveOriginal.Value & " --> " & mprNew.SaveOriginal.Value)
            mprOld.SaveOriginal.Value = mprNew.SaveOriginal.Value
        End If
        If mprOld.SaveDefocus.Value <> mprNew.SaveDefocus.Value Then
            dlm.WriteLog("< SaveDefocus >: " & mprOld.SaveDefocus.Value & " --> " & mprNew.SaveDefocus.Value)
            mprOld.SaveDefocus.Value = mprNew.SaveDefocus.Value
        End If
        If mprOld.SaveSmooth.Value <> mprNew.SaveSmooth.Value Then
            dlm.WriteLog("< SaveSmooth >: " & mprOld.SaveSmooth.Value & " --> " & mprNew.SaveSmooth.Value)
            mprOld.SaveSmooth.Value = mprNew.SaveSmooth.Value
        End If

        If mprOld.SaveBlackBlob.Value <> mprNew.SaveBlackBlob.Value Then
            dlm.WriteLog("< SaveBlackBlob >: " & mprOld.SaveBlackBlob.Value & " --> " & mprNew.SaveBlackBlob.Value)
            mprOld.SaveBlackBlob.Value = mprNew.SaveBlackBlob.Value
        End If
        If mprOld.SaveBlackThreshold.Value <> mprNew.SaveBlackThreshold.Value Then
            dlm.WriteLog("< SaveBlackThreshold >: " & mprOld.SaveBlackThreshold.Value & " --> " & mprNew.SaveBlackThreshold.Value)
            mprOld.SaveBlackThreshold.Value = mprNew.SaveBlackThreshold.Value
        End If
        If mprOld.SaveBlackReconstructArea.Value <> mprNew.SaveBlackReconstructArea.Value Then
            dlm.WriteLog("< SaveBlackReconstructArea >: " & mprOld.SaveBlackReconstructArea.Value & " --> " & mprNew.SaveBlackReconstructArea.Value)
            mprOld.SaveBlackReconstructArea.Value = mprNew.SaveBlackReconstructArea.Value
        End If
        If mprOld.SaveBlackReconstructRim.Value <> mprNew.SaveBlackReconstructRim.Value Then
            dlm.WriteLog("< SaveBlackReconstructRim >: " & mprOld.SaveBlackReconstructRim.Value & " --> " & mprNew.SaveBlackReconstructRim.Value)
            mprOld.SaveBlackReconstructRim.Value = mprNew.SaveBlackReconstructRim.Value
        End If

        If mprOld.SaveWhiteBlob.Value <> mprNew.SaveWhiteBlob.Value Then
            dlm.WriteLog("< SaveWhiteBlob >: " & mprOld.SaveWhiteBlob.Value & " --> " & mprNew.SaveWhiteBlob.Value)
            mprOld.SaveWhiteBlob.Value = mprNew.SaveWhiteBlob.Value
        End If
        If mprOld.SaveWhiteThreshold.Value <> mprNew.SaveWhiteThreshold.Value Then
            dlm.WriteLog("< SaveWhiteThreshold >: " & mprOld.SaveWhiteThreshold.Value & " --> " & mprNew.SaveWhiteThreshold.Value)
            mprOld.SaveWhiteThreshold.Value = mprNew.SaveWhiteThreshold.Value
        End If
        If mprOld.SaveWhiteReconstructArea.Value <> mprNew.SaveWhiteReconstructArea.Value Then
            dlm.WriteLog("< SaveWhiteReconstructArea >: " & mprOld.SaveWhiteReconstructArea.Value & " --> " & mprNew.SaveWhiteReconstructArea.Value)
            mprOld.SaveWhiteReconstructArea.Value = mprNew.SaveWhiteReconstructArea.Value
        End If
        If mprOld.SaveWhiteReconstructRim.Value <> mprNew.SaveWhiteReconstructRim.Value Then
            dlm.WriteLog("< SaveWhiteReconstructRim >: " & mprOld.SaveWhiteReconstructRim.Value & " --> " & mprNew.SaveWhiteReconstructRim.Value)
            mprOld.SaveWhiteReconstructRim.Value = mprNew.SaveWhiteReconstructRim.Value
        End If

        If mprOld.SaveVProject.Value <> mprNew.SaveVProject.Value Then
            dlm.WriteLog("< SaveVProject >: " & mprOld.SaveVProject.Value & " --> " & mprNew.SaveVProject.Value)
            mprOld.SaveVProject.Value = mprNew.SaveVProject.Value
        End If
        If mprOld.SaveHProject.Value <> mprNew.SaveHProject.Value Then
            dlm.WriteLog("< SaveHProject >: " & mprOld.SaveHProject.Value & " --> " & mprNew.SaveHProject.Value)
            mprOld.SaveHProject.Value = mprNew.SaveHProject.Value
        End If

        If mprOld.SaveVBand.Value <> mprNew.SaveVBand.Value Then
            dlm.WriteLog("< SaveVBand >: " & mprOld.SaveVBand.Value & " --> " & mprNew.SaveVBand.Value)
            mprOld.SaveVBand.Value = mprNew.SaveVBand.Value
        End If
        If mprOld.SaveHBand.Value <> mprNew.SaveHBand.Value Then
            dlm.WriteLog("< SaveHBand >: " & mprOld.SaveHBand.Value & " --> " & mprNew.SaveHBand.Value)
            mprOld.SaveHBand.Value = mprNew.SaveHBand.Value
        End If

        If mprOld.PatternName.Value <> mprNew.PatternName.Value Then
            dlm.WriteLog("< PatternName >: " & mprOld.PatternName.Value & " --> " & mprNew.PatternName.Value)
            mprOld.PatternName = mprNew.PatternName
        End If
        If mprOld.ExposureTime.Value <> mprNew.ExposureTime.Value Then
            dlm.WriteLog("< ExposureTime >: " & mprOld.ExposureTime.Value & " --> " & mprNew.ExposureTime.Value)
            mprOld.ExposureTime.Value = mprNew.ExposureTime.Value
        End If

        If mprOld.AutoExposure_Kp.Value <> mprNew.AutoExposure_Kp.Value Then
            dlm.WriteLog("< AutoExposure_Kp >: " & mprOld.AutoExposure_Kp.Value & " --> " & mprNew.AutoExposure_Kp.Value)
            mprOld.AutoExposure_Kp.Value = mprNew.AutoExposure_Kp.Value
        End If
        If mprOld.AutoExposure_LargeErrorRange_UL.Value <> mprNew.AutoExposure_LargeErrorRange_UL.Value Then
            dlm.WriteLog("< AutoExposure_LargeErrorRange_UL >: " & mprOld.AutoExposure_LargeErrorRange_UL.Value & " --> " & mprNew.AutoExposure_LargeErrorRange_UL.Value)
            mprOld.AutoExposure_LargeErrorRange_UL.Value = mprNew.AutoExposure_LargeErrorRange_UL.Value
        End If
        If mprOld.AutoExposure_LargeErrorRange_DL.Value <> mprNew.AutoExposure_LargeErrorRange_DL.Value Then
            dlm.WriteLog("< AutoExposure_LargeErrorRange_DL >: " & mprOld.AutoExposure_LargeErrorRange_DL.Value & " --> " & mprNew.AutoExposure_LargeErrorRange_DL.Value)
            mprOld.AutoExposure_LargeErrorRange_DL.Value = mprNew.AutoExposure_LargeErrorRange_DL.Value
        End If
        If mprOld.AutoExposure_SmallErrorRange.Value <> mprNew.AutoExposure_SmallErrorRange.Value Then
            dlm.WriteLog("< AutoExposure_SmallErrorRange >: " & mprOld.AutoExposure_SmallErrorRange.Value & " --> " & mprNew.AutoExposure_SmallErrorRange.Value)
            mprOld.AutoExposure_SmallErrorRange.Value = mprNew.AutoExposure_SmallErrorRange.Value
        End If
        If mprOld.AutoExposure_TargetMean.Value <> mprNew.AutoExposure_TargetMean.Value Then
            dlm.WriteLog("< AutoExposure_TargetMean >: " & mprOld.AutoExposure_TargetMean.Value & " --> " & mprNew.AutoExposure_TargetMean.Value)
            mprOld.AutoExposure_TargetMean.Value = mprNew.AutoExposure_TargetMean.Value
        End If
    End Sub
#End Region

#Region "--- SetRimBoundary ---"
    Private Sub SetRimBoundary(ByVal boundary As ClsParameterBoundary)
        If boundary.TopY < Me.NumericUpDown_RimTop.Minimum Then
            Me.NumericUpDown_RimTop.Value = Me.NumericUpDown_RimTop.Minimum
            boundary.TopY = Me.NumericUpDown_RimTop.Minimum
        Else
            If boundary.TopY >= Me.NumericUpDown_RimTop.Maximum Then
                boundary.TopY = Me.NumericUpDown_RimTop.Maximum - 1
                Me.NumericUpDown_RimTop.Value = boundary.TopY
            Else
                Me.NumericUpDown_RimTop.Value = boundary.TopY
            End If
        End If

        If boundary.BottomY < Me.NumericUpDown_RimBottom.Minimum Then
            Me.NumericUpDown_RimBottom.Value = Me.NumericUpDown_RimBottom.Minimum
            boundary.BottomY = Me.NumericUpDown_RimBottom.Minimum
        Else
            If boundary.BottomY >= Me.NumericUpDown_RimBottom.Maximum Then
                boundary.BottomY = Me.NumericUpDown_RimBottom.Maximum - 1
                Me.NumericUpDown_RimBottom.Value = boundary.BottomY
            Else
                Me.NumericUpDown_RimBottom.Value = boundary.BottomY
            End If
        End If

        If boundary.LeftX < Me.NumericUpDown_RimLeft.Minimum Then
            Me.NumericUpDown_RimLeft.Value = Me.NumericUpDown_RimLeft.Minimum
            boundary.LeftX = Me.NumericUpDown_RimLeft.Minimum
        Else
            If boundary.LeftX >= Me.NumericUpDown_RimLeft.Maximum Then
                boundary.LeftX = Me.NumericUpDown_RimLeft.Maximum - 1
                Me.NumericUpDown_RimLeft.Value = boundary.LeftX
            Else
                Me.NumericUpDown_RimLeft.Value = boundary.LeftX
            End If
        End If

        If boundary.RightX < Me.NumericUpDown_RimRight.Minimum Then
            Me.NumericUpDown_RimRight.Value = Me.NumericUpDown_RimRight.Minimum
            boundary.RightX = Me.NumericUpDown_RimRight.Minimum
        Else
            If boundary.RightX >= Me.NumericUpDown_RimRight.Maximum Then
                boundary.RightX = Me.NumericUpDown_RimRight.Maximum - 1
                Me.NumericUpDown_RimRight.Value = boundary.RightX
            Else
                Me.NumericUpDown_RimRight.Value = boundary.RightX
            End If
        End If

    End Sub
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_SaveFFCImages.Enabled = En
        Me.Button_FFCImage.Enabled = En
        Me.Button_SaveFFCImages.Enabled = En

        Me.Button_Save.Enabled = En
        Me.Button_Close.Enabled = En

        Me.ComboBox_PatternList.Enabled = En
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- GetPatternIndexInfoCallback ---"
    Delegate Function GetPatternIndexInfoCallback() As Integer
    Private Function GetPatternIndexInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_PatternList.InvokeRequired Then
            Return Me.Invoke(New GetPatternIndexInfoCallback(AddressOf GetPatternIndexInfo), New Object() {})
        Else
            i = Me.ComboBox_PatternList.SelectedIndex
            Me.Update()
            Return i
        End If
    End Function
#End Region

#Region "--- Change Language ---"

    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_AddOne.Text = res.GetString("Button_AddOne.Text")
                Button_Boundary.Text = res.GetString("Button_Boundary.Text")
                Button_CalculateLSQ.Text = res.GetString("Button_CalculateLSQ.Text")
                Button_SaveFFCImages.Text = res.GetString("Button_SaveFFCImages.Text")
                CheckBox_Rim.Text = res.GetString("CheckBox_Rim.Text")
                CheckBox_SaveBlackReconstructArea.Text = res.GetString("CheckBox_SaveBlackReconstructArea.Text")
                CheckBox_SaveBlackReconstructRim.Text = res.GetString("CheckBox_SaveBlackReconstructRim.Text")
                CheckBox_SaveBlackThreshold.Text = res.GetString("CheckBox_SaveBlackThreshold.Text")
                CheckBox_SaveDefocus.Text = res.GetString("CheckBox_SaveDefocus.Text")
                CheckBox_SaveFFCAlignResult.Text = res.GetString("CheckBox_SaveFFCAlignResult.Text")
                CheckBox_SaveFFTResult.Text = res.GetString("CheckBox_SaveFFTResult.Text")
                CheckBox_SaveHBand.Text = res.GetString("CheckBox_SaveHBand.Text")
                CheckBox_SaveOriginal.Text = res.GetString("CheckBox_SaveOriginal.Text")
                CheckBox_SaveResizeBMP.Text = res.GetString("CheckBox_SaveResizeBMP.Text")
                CheckBox_SaveSmooth.Text = res.GetString("CheckBox_SaveSmooth.Text")
                CheckBox_SaveVBand.Text = res.GetString("CheckBox_SaveVBand.Text")
                CheckBox_SaveWhiteReconstructArea.Text = res.GetString("CheckBox_SaveWhiteReconstructArea.Text")
                CheckBox_SaveWhiteReconstructRim.Text = res.GetString("CheckBox_SaveWhiteReconstructRim.Text")
                CheckBox_SaveWhiteThreshold.Text = res.GetString("CheckBox_SaveWhiteThreshold.Text")
                CheckBox_Show.Text = res.GetString("CheckBox_Show.Text")
                CheckBox_ShowRound.Text = res.GetString("CheckBox_ShowRound.Text")
                GroupBox_Area.Text = res.GetString("GroupBox_Area.Text")
                GroupBox_BandModify.Text = res.GetString("GroupBox_BandModify.Text")
                GroupBox_BandParameter.Text = res.GetString("GroupBox_BandParameter.Text")
                GroupBox_Defocus.Text = res.GetString("GroupBox_Defocus.Text")
                GroupBox_GlobleSmooth.Text = res.GetString("GroupBox_GlobleSmooth.Text")
                GroupBox_GoldenSampleParameter.Text = res.GetString("GroupBox_GoldenSampleParameter.Text")
                GroupBox_H.Text = res.GetString("GroupBox_H.Text")
                GroupBox_JND_1.Text = res.GetString("GroupBox_JND_1.Text")
                GroupBox_JND_2.Text = res.GetString("GroupBox_JND_2.Text")
                GroupBox_Manual.Text = res.GetString("GroupBox_Manual.Text")
                GroupBox_Modify.Text = res.GetString("GroupBox_Modify.Text")
                GroupBox_MuraRatio.Text = res.GetString("GroupBox_MuraRatio.Text")
                GroupBox_Parameter.Text = res.GetString("GroupBox_Parameter.Text")
                GroupBox_RimModify.Text = res.GetString("GroupBox_RimModify.Text")
                GroupBox_RimParameter.Text = res.GetString("GroupBox_RimParameter.Text")
                GroupBox_RimType.Text = res.GetString("GroupBox_RimType.Text")
                GroupBox_Round.Text = res.GetString("GroupBox_Round.Text")
                GroupBox_Save.Text = res.GetString("GroupBox_Save.Text")
                GroupBox_V.Text = res.GetString("GroupBox_V.Text")
                GroupBox1.Text = res.GetString("GroupBox1.Text")
                Label_AGM_WhiteAreaMax.Text = res.GetString("Label_AGM_WhiteAreaMax.Text")
                Label_AreaBottom.Text = res.GetString("Label_AreaBottom.Text")
                Label_AreaLeft.Text = res.GetString("Label_AreaLeft.Text")
                Label_AreaRight.Text = res.GetString("Label_AreaRight.Text")
                Label_AreaTop.Text = res.GetString("Label_AreaTop.Text")
                Label_Band_ResizeCount.Text = res.GetString("Label_Band_ResizeCount.Text")
                Label_Band_SmoothCount.Text = res.GetString("Label_Band_SmoothCount.Text")
                Label_BlackAGM_AreaMin.Text = res.GetString("Label_BlackAGM_AreaMin.Text")
                Label_BlackBandMura_JND.Text = res.GetString("Label_BlackBandMura_JND.Text")
                Label_BlackBandMura_WidthMin.Text = res.GetString("Label_BlackBandMura_WidthMin.Text")
                Label_BlackBlob_AreaMax.Text = res.GetString("Label_BlackBlob_AreaMax.Text")
                Label_BlackBlob_AreaMin.Text = res.GetString("Label_BlackBlob_AreaMin.Text")
                Label_BlackBlobMura_JND.Text = res.GetString("Label_BlackBlobMura_JND.Text")
                Label_BlackMacroMura_AreaMax.Text = res.GetString("Label_BlackMacroMura_AreaMax.Text")
                Label_BlackMacroMura_AreaMin.Text = res.GetString("Label_BlackMacroMura_AreaMin.Text")
                Label_BlackMacroMura_JND.Text = res.GetString("Label_BlackMacroMura_JND.Text")
                Label_Bottom.Text = res.GetString("Label_Bottom.Text")
                Label_HBottom.Text = res.GetString("Label_HBottom.Text")
                Label_HTOP.Text = res.GetString("Label_HTOP.Text")
                Label_HValueCount.Text = res.GetString("Label_HValueCount.Text")
                Label_Left.Text = res.GetString("Label_Left.Text")
                Label_Resize.Text = res.GetString("Label_Resize.Text")
                Label_Right.Text = res.GetString("Label_Right.Text")
                Label_RoundHeight.Text = res.GetString("Label_RoundHeight.Text")
                Label_RoundLow.Text = res.GetString("Label_RoundLow.Text")
                Label_Smooth.Text = res.GetString("Label_Smooth.Text")
                Label_Top.Text = res.GetString("Label_Top.Text")
                Label_VLeft.Text = res.GetString("Label_VLeft.Text")
                Label_VRight.Text = res.GetString("Label_VRight.Text")
                Label_VValueCount.Text = res.GetString("Label_VValueCount.Text")
                Label_WhiteAGM_AreaMin.Text = res.GetString("Label_WhiteAGM_AreaMin.Text")
                Label_WhiteAGM_JND.Text = res.GetString("Label_WhiteAGM_JND.Text")
                Label_WhiteBandMura_JND.Text = res.GetString("Label_WhiteBandMura_JND.Text")
                Label_WhiteBandMura_WidthMin.Text = res.GetString("Label_WhiteBandMura_WidthMin.Text")
                Label_WhiteBlob_AreaMax.Text = res.GetString("Label_WhiteBlob_AreaMax.Text")
                Label_WhiteBlob_AreaMin.Text = res.GetString("Label_WhiteBlob_AreaMin.Text")
                Label_WhiteBlobMura_JND.Text = res.GetString("Label_WhiteBlobMura_JND.Text")
                Label_WhiteMacroMura_AreaMax.Text = res.GetString("Label_WhiteMacroMura_AreaMax.Text")
                Label_WhiteMacroMura_AreaMin.Text = res.GetString("Label_WhiteMacroMura_AreaMin.Text")
                Label_WhiteMacroMura_JND.Text = res.GetString("Label_WhiteMacroMura_JND.Text")
                Label1.Text = res.GetString("Label1.Text")
                Label16.Text = res.GetString("Label16.Text")
                Label17.Text = res.GetString("Label17.Text")
                Label18.Text = res.GetString("Label18.Text")
                Label19.Text = res.GetString("Label19.Text")
                Label28.Text = res.GetString("Label28.Text")
                Label29.Text = res.GetString("Label29.Text")
                Label30.Text = res.GetString("Label30.Text")
                Label52.Text = res.GetString("Label52.Text")
                Label53.Text = res.GetString("Label53.Text")
                Label54.Text = res.GetString("Label54.Text")
                Label55.Text = res.GetString("Label55.Text")
                Label68.Text = res.GetString("Label68.Text")
                Label69.Text = res.GetString("Label69.Text")
                Label70.Text = res.GetString("Label70.Text")
                Label71.Text = res.GetString("Label71.Text")
                Label72.Text = res.GetString("Label72.Text")
                Label73.Text = res.GetString("Label73.Text")
                Label74.Text = res.GetString("Label74.Text")
                Label75.Text = res.GetString("Label75.Text")
                Label76.Text = res.GetString("Label76.Text")
                Label77.Text = res.GetString("Label77.Text")
                Labell_BlackBandMura_SJND.Text = res.GetString("Labell_BlackBandMura_SJND.Text")
                Labell_WhiteBandMura_SJND.Text = res.GetString("Labell_WhiteBandMura_SJND.Text")
                RadioButton_Finish.Text = res.GetString("RadioButton_Finish.Text")
                RadioButton_Manual.Text = res.GetString("RadioButton_Manual.Text")
                RadioButton_RoundFinish.Text = res.GetString("RadioButton_RoundFinish.Text")
                RadioButton_RoundManual.Text = res.GetString("RadioButton_RoundManual.Text")
                TabPage_Alignment.Text = res.GetString("TabPage_Alignment.Text")
                TabPage_Band.Text = res.GetString("TabPage_Band.Text")
                TabPage_Center.Text = res.GetString("TabPage_Center.Text")
                TabPage_CPD.Text = res.GetString("TabPage_CPD.Text")
                TabPage_JND_1.Text = res.GetString("TabPage_JND_1.Text")
                TabPage_JND_2.Text = res.GetString("TabPage_JND_2.Text")
                TabPage_Rim.Text = res.GetString("TabPage_Rim.Text")
                TabPage_Save.Text = res.GetString("TabPage_Save.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- Drawing ---"

#Region "--- ReDraw ---"
    Private Sub ReDraw()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)

        If image <> M_NULL Then
            Select Case Me.TabControl_Setting.SelectedIndex
                Case 1   'Mura Area ---
                    Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                        Case 0
                            Me.ReDrawPage10(image)
                        Case 1
                            Me.ReDrawPage11(image)
                    End Select
                Case 2   'Mura Rim ---
                    Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                        Case 0
                            Me.ReDrawPage20(image)
                        Case 1
                            Me.ReDrawPage21(image)
                    End Select
            End Select
        End If
    End Sub
#End Region

#Region "--- Draw Area ---"

    Private Sub ReDrawPage10(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_Show.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_AreaLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.RightX - Me.NumericUpDown_AreaRight.Value + 1
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_AreaTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.BottomY - Me.NumericUpDown_AreaBottom.Value + 1
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub

    Private Sub ReDrawPage11(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_Show.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_AreaLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeX - Me.NumericUpDown_AreaRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_AreaTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeY - Me.NumericUpDown_AreaBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub

#End Region

#Region "--- Draw Rim ---"

    Private Sub ReDrawPage20(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Green
            '--- Initial ---

            '--- ByPass ����� ---
            v = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            '--- ByPass �k��� ---
            v = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            'ByPass �W��� ---
            v = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            'ByPass �U��� ---
            v = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            Me.m_SolidBrush.Color = Color.Red
            v = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage21(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Green
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            Me.m_SolidBrush.Color = Color.Red
            v = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = SizeY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub

#End Region

#Region "--- Draw Round(Top_Bottom_Left_Right) ---"
    Private Sub ReDrawPage20Top(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = Me.m_Boundary.TopY + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage20Bottom(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.BottomY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage20Left(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.LeftX + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage20Right(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.RightX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage21Top(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage21Bottom(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value + SizeY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = SizeY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage21Left(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = SizeY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
    Private Sub ReDrawPage21Right(ByVal image As MIL_ID)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        If Me.CheckBox_ShowRound.Checked Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, SizeX)
            SizeY = MbufInquire(image, M_SIZE_Y, SizeY)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_RimLeft.Value + SizeX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            v = SizeY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_PaintStop = False
    End Sub
#End Region

#End Region

#Region "--- Mouse Event ---"

#Region "--- MouseDown ---"
    Private Sub MouseDownPage10(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_AreaLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = Me.m_Boundary.RightX - Me.NumericUpDown_AreaRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If

            p = (Me.NumericUpDown_AreaTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = Me.m_Boundary.BottomY - Me.NumericUpDown_AreaBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If

        End If
    End Sub
    Private Sub MouseDownPage11(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_AreaLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_AreaRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If

            p = (Me.NumericUpDown_AreaTop.Value - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_AreaBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If

        End If
    End Sub
    Private Sub MouseDownPage20(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If


            p = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If

        End If
    End Sub
    Private Sub MouseDownPage21(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_RimRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_RimBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage20Top(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY + Me.m_Boundary.TopY - Me.NumericUpDown_RimBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage20Bottom(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.BottomY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage20Left(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.LeftX - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = Me.m_Boundary.LeftX + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.NumericUpDown_RimRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage20Right(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value + Me.m_Boundary.RightX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = Me.m_Boundary.RightX - Me.NumericUpDown_RimRight.Value + 1
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value + Me.m_Boundary.TopY - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = Me.m_Boundary.BottomY - Me.NumericUpDown_RimBottom.Value + 1
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage21Top(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_RimRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY - Me.NumericUpDown_RimBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage21Bottom(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_RimRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value + MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_RimBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage21Left(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.NumericUpDown_RimRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_RimBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
    Private Sub MouseDownPage21Right(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            p = (Me.NumericUpDown_RimLeft.Value + MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_RimRight.Value
            p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left1 = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right1 = True
                End If
            End If
            p = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_RimBottom.Value
            p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomY * 0.5 + 3 Then
                    Me.m_Top1 = True
                End If
            Else
                If dis2 < ZoomY * 0.5 + 3 Then
                    Me.m_Bottom1 = True
                End If
            End If
        End If
    End Sub
#End Region

#Region "--- MouseMove ---"
    Private Sub MouseMovePage10()
        If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked Then
            If Me.m_Left1 Then
                Me.NumericUpDown_AreaLeft.Value = Me.m_Form.MouseX - Me.m_Boundary.LeftX
            End If
            If Me.m_Right1 Then
                Me.NumericUpDown_AreaRight.Value = Me.m_Boundary.RightX - Me.m_Form.MouseX
            End If
            If Me.m_Top1 Then
                Me.NumericUpDown_AreaTop.Value = Me.m_Form.MouseY - Me.m_Boundary.TopY
            End If
            If Me.m_Bottom1 Then
                Me.NumericUpDown_AreaBottom.Value = Me.m_Boundary.BottomY - Me.m_Form.MouseY
            End If

            If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
                Me.Refresh()
            End If
        End If
    End Sub
    Private Sub MouseMovePage11()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked And image <> M_NULL Then
            If Me.m_Left1 Then
                Me.NumericUpDown_AreaLeft.Value = Me.m_Form.MouseX
            End If
            If Me.m_Right1 Then
                Me.NumericUpDown_AreaRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
            End If
            If Me.m_Top1 Then
                Me.NumericUpDown_AreaTop.Value = Me.m_Form.MouseY
            End If
            If Me.m_Bottom1 Then
                Me.NumericUpDown_AreaBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
            End If

            If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
                Me.Refresh()
            End If
        End If
    End Sub
    Private Sub MouseMovePage20()
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked Then
            If Me.m_Left1 Then
                Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX - Me.m_Boundary.LeftX
            End If
            If Me.m_Right1 Then
                Me.NumericUpDown_RimRight.Value = Me.m_Boundary.RightX - Me.m_Form.MouseX
            End If
            If Me.m_Top1 Then
                Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY - Me.m_Boundary.TopY
            End If
            If Me.m_Bottom1 Then
                Me.NumericUpDown_RimBottom.Value = Me.m_Boundary.BottomY - Me.m_Form.MouseY
            End If

            If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
                Me.Refresh()
            End If
        End If
    End Sub
    Private Sub MouseMovePage21()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            If Me.m_Left1 Then
                Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX
            End If
            If Me.m_Right1 Then
                Me.NumericUpDown_RimRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
            End If
            If Me.m_Top1 Then
                Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY
            End If
            If Me.m_Bottom1 Then
                Me.NumericUpDown_RimBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
            End If

            If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
                Me.Refresh()
            End If
        End If
    End Sub

    Private Sub MouseMovePage2()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_RoundManual.Checked And Me.CheckBox_ShowRound.Checked And image <> M_NULL Then
            If Me.m_Left1 Then
                Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX + 1
            End If
            If Me.m_Right1 Then
                Me.NumericUpDown_RimRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
            End If
            If Me.m_Top1 Then
                Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY + 1
            End If
            If Me.m_Bottom1 Then
                Me.NumericUpDown_RimBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
            End If
            If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
                Me.Refresh()
            End If
        End If
    End Sub
    Private Sub MouseMovePage20Top()
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX - Me.m_Boundary.LeftX + 1
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = Me.m_Boundary.RightX - Me.m_Form.MouseX + 1
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY - Me.m_Boundary.TopY + 1
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = Me.m_Boundary.TopY + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY - Me.m_Form.MouseY
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
    Private Sub MouseMovePage20Bottom()
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX - Me.m_Boundary.LeftX + 1
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = Me.m_Boundary.RightX - Me.m_Form.MouseX + 1
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY - Me.m_Boundary.BottomY + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = Me.m_Boundary.BottomY - Me.m_Form.MouseY + 1
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
    Private Sub MouseMovePage20Left()
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX - Me.m_Boundary.LeftX + 1
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = Me.m_Boundary.LeftX + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.m_Form.MouseX
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY - Me.m_Boundary.TopY + 1
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = Me.m_Boundary.BottomY - Me.m_Form.MouseY + 1
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
    Private Sub MouseMovePage20Right()
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX - Me.m_Boundary.RightX + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = Me.m_Boundary.RightX - Me.m_Form.MouseX + 1
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY - Me.m_Boundary.TopY + 1
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = Me.m_Boundary.BottomY - Me.m_Form.MouseY + 1
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
    Private Sub MouseMovePage21Top()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX + 1
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY + 1
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY - Me.m_Form.MouseY
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
    Private Sub MouseMovePage21Bottom()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX + 1
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY - MbufInquire(image, M_SIZE_Y, M_NULL) + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY + 1
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
    Private Sub MouseMovePage21Left()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX + 1
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.m_Form.MouseX
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY + 1
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
    Private Sub MouseMovePage21Right()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.m_Left1 Then
            Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX - MbufInquire(image, M_SIZE_X, M_NULL) + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX + 1
        End If
        If Me.m_Right1 Then
            Me.NumericUpDown_RimRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
        End If
        If Me.m_Top1 Then
            Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY + 1
        End If
        If Me.m_Bottom1 Then
            Me.NumericUpDown_RimBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
        End If
        If Me.m_Left1 Or Me.m_Right1 Or Me.m_Top1 Or Me.m_Bottom1 Then
            Me.Refresh()
        End If
    End Sub
#End Region

#End Region

#Region "--- TabControl Event ---"

    Private Sub TabControl_Setting_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl_Setting.SelectedIndexChanged
        If Me.m_CurrentTab >= 0 Then
            Me.TabControl_Setting.SelectedIndex = Me.m_CurrentTab
        Else
            Me.ReDraw()
        End If
    End Sub

#End Region

#Region "--- AxMDisplay Operation ---"

    Private Sub m_Panel_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_PaintStop Then
            Me.ReDraw()
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseDownEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Select Case Me.TabControl_Setting.SelectedIndex
                Case 1 'Mura Area ---
                    Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                        Case 0
                            Me.MouseDownPage10(e)
                        Case 1
                            Me.MouseDownPage11(e)
                    End Select
                Case 2 'Mura Rim ---
                    Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                        Case 0
                            Me.MouseDownPage20(e)
                        Case 1
                            Me.MouseDownPage21(e)
                    End Select
            End Select
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseUpEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_Left1 = False
            Me.m_Right1 = False
            Me.m_Top1 = False
            Me.m_Bottom1 = False
            Me.m_Left2 = False
            Me.m_Right2 = False
            Me.m_Top2 = False
            Me.m_Bottom2 = False
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseMoveEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        Select Case Me.TabControl_Setting.SelectedIndex
            Case 1   'Mura Area ---
                Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                    Case 0
                        Me.MouseMovePage10()
                    Case 1
                        Me.MouseMovePage11()
                End Select
            Case 2   'Mura Rim ---
                Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                    Case 0
                        Me.MouseMovePage20()
                    Case 1
                        Me.MouseMovePage21()
                End Select
        End Select
    End Sub

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Boundary ---"
    Private Sub Button_Boundary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Boundary.Click

        If Me.m_DialogBoundary Is Nothing Then

            If Me.CheckBox_UseFFC.Checked Then
                Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value = True
                Me.GroupBox_SettingFFC.Enabled = True
                Me.NumericUpDown_AlignPercentage.Enabled = True
                Me.Button_SaveFFCImages.Enabled = True
                Me.Button_Calculate_Max.Enabled = True
            ElseIf Me.CheckBox_UseBLFFC.Checked Then
                Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value = False
                Me.GroupBox_SettingFFC.Enabled = False
                Me.NumericUpDown_AlignPercentage.Enabled = False
                Me.Button_SaveFFCImages.Enabled = True
                Me.Button_Calculate_Max.Enabled = False
            Else
                Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value = False
                Me.GroupBox_SettingFFC.Enabled = False
                Me.NumericUpDown_AlignPercentage.Enabled = False
                Me.Button_SaveFFCImages.Enabled = False
                Me.Button_Calculate_Max.Enabled = False
            End If

            Me.m_Form.ComboBox_Type.SelectedIndex = -1
            Me.m_DialogBoundary = New Dialog_MuraBoundary
            Me.m_DialogBoundary.SetMainForm(Me.m_Form, DialogBoundaryTypeDefine.FFC, True)
            Me.AddOwnedForm(Me.m_DialogBoundary)
            Me.m_DialogBoundary.Left = Me.Left
            Me.m_DialogBoundary.Top = Me.Top
            Me.m_DialogBoundary.Show()
            Me.m_Form.GroupBox_Image.Enabled = False
            Me.Hide()

        End If
    End Sub
#End Region

#Region "--- Button_FFCImage ---"
    Private Sub Button_FFCImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FFCImage.Click
        Dim Image As MIL_ID
        Dim Parameter_Lists As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- Initial ---   
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.AlignValue.Value = Me.NumericUpDown_AlignValue.Value
            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraSetting Setting   ==> Request_Command = "DIALOG_MURASETTING_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURASETTING_SETTING"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------

                '--- �Ĥ@�� (�G�ե��P���J�Ѽ�) ---
                Parameter_Lists = "AlignValue," & Me.NumericUpDown_AlignValue.Value & ";"
                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSettingBase Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSetting.Button_FFCImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate FFC Align Image  ==> Request_Command = "CALCULATE_FFCALIGN_IMAGE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_FFCALIGN_IMAGE"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Align Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSetting.Button_FFCImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    Image = Me.m_MainProcess.MuraProcess.Img_CurrentFFCAlign
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_CurrentFFCAlign.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_CurrentFFCAlign.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Image <> M_NULL Then
                            If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Image)
                                Image = M_NULL
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Image)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Me.m_Form.ComboBox_Type.SelectedIndex = 7 And Me.m_Form.ComboBox_Select.SelectedIndex = 1 Then
                Me.m_Form.ImageUpdate()
            Else
                Me.m_Form.CurrentIndex3 = 1
                Me.m_Form.ComboBox_Type.SelectedIndex = 3
                Me.m_Form.ComboBox_Select.SelectedIndex = 1
            End If

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[DDialog_MuraSetting.Button_FFCImage]" & ex.Message)
            MessageBox.Show("[Dialog_MuraSetting.Button_FFCImage]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        If Me.m_Form.ComboBox_CCD.SelectedIndex = -1 Then
            MessageBox.Show("[Dialog_MuraSetting.Button_Save]�Х���� IP No , �~��i���x�s", "ĵ�i", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim i As Integer
        Dim str As String
        Dim dir As String
        Dim Parameter_Lists As String
        Dim PatternName As String
        Dim PatternIndex As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            '[AreaGrabber]
            PatternIndex = Me.GetPatternIndexInfo
            Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '�q[1]�}�l

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.ComboBox_PatternList.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.Setting()
            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraSetting Setting   ==> Request_Command = "DIALOG_MURASETTING_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURASETTING_SETTING"
                TimeOut = 500000 '500 secs

                'UI Recipe Setting -----------------------------------

                '--- Page 1--- (FFC) ---
                Parameter_Lists = "DefocusCount," & Me.NumericUpDown_DefocusCount.Value & ";" & "PitchX," & Me.NumericUpDown_PitchX.Value & ";" & "PitchY," & Me.NumericUpDown_PitchY.Value & ";" & _
                                  "BlobMura_GlobleSmooth," & Me.NumericUpDown_BlobMura_GlobleSmooth.Value & ";" & "MacroMura_GlobleSmooth," & Me.NumericUpDown_MacroMura_GlobleSmooth.Value & ";" & _
                                  "UseFFC," & CheckBox_UseFFC.Checked & ";" & "UseBLFFC," & CheckBox_UseBLFFC.Checked & "," & "AlignValue," & Me.NumericUpDown_AlignValue.Value & ";" & "AlignPercentage," & Me.NumericUpDown_AlignPercentage.Value & ";" & _
                                  "RemoveHVBand," & Me.CheckBox_RemoveHVBand.Checked & ";" & "UseFFT," & Me.CheckBox_UseFFT.Checked & ";" & "FFTFilterRadius," & Me.NumericUpDown_FFTFilterRadius.Value & ";"

                '---Page 2---(Center) ---
                Parameter_Lists = Parameter_Lists & "UseCenter," & Me.CheckBox_Center.Checked & ";" & "WhiteBlobMura_ReconstructHeight," & Me.NUD_WhiteBlobMura_ReconstructHeight.Value & ";" & "WhiteBlobMura_ReconstructLow," & Me.NUD_WhiteBlobMura_ReconstructLow.Value & ";" & _
                                                    "BlackBlobMura_ReconstructHeight," & Me.NUD_BlackBlobMura_ReconstructHeight.Value & ";" & "BlackBlobMura_ReconstructLow," & Me.NUD_BlackBlobMura_ReconstructLow.Value & ";" & _
                                                    "WhiteMacroMura_Threshold," & Me.NUD_WhiteMacroMura_Threshold.Value & ";" & "BlackMacroMura_Threshold," & Me.NUD_BlackMacroMura_Threshold.Value & ";" & _
                                                    "ResizeCount_min," & Me.Num_ResizeCount_Min.Value & ";" & "ResizeCount_mid," & Me.Num_ResizeCount_Mid.Value & ";" & "ResizeCount_max," & Me.Num_ResizeCount_Max.Value & ";" & _
                                                    "UseBaseLine," & Me.CheckBox_UseBaseLine.Checked & ";" & "MacroPowerX," & Me.NumericUpDown_MacroPowerX.Value & ";" & "MacroPowerY," & Me.NumericUpDown_MacroPowerY.Value & ";" & _
                                                    "AreaTop," & Me.NumericUpDown_AreaTop.Value & ";" & "AreaBottom," & Me.NumericUpDown_AreaBottom.Value & ";" & "AreaLeft," & Me.NumericUpDown_AreaLeft.Value & ";" & "AreaRight," & Me.NumericUpDown_AreaRight.Value & ";" & _
                                                    "UseReconstructBW," & Me.CheckBox_UseReconstructBW.Checked & ";" & "BlobMulRatio," & Me.NumericUpDown_BlobMulRatio.Value & ";"

                '---Page 4---(Round) ---
                Parameter_Lists = Parameter_Lists & "UseRound," & Me.CheckBox_Rim.Checked & ";" & "WhiteMura_RimHeight," & Me.NumericUpDown_WhiteMura_RimHeight.Value & ";" & "WhiteMura_RimLow," & Me.NumericUpDown_WhiteMura_RimLow.Value & ";" & _
                                                    "BlackMura_RimHeight," & Me.NumericUpDown_BlackMura_RimHeight.Value & ";" & "BlackMura_RimLow," & Me.NumericUpDown_BlackMura_RimLow.Value & ";" & _
                                                    "Resize," & Me.NumericUpDown_Resize.Text & ";" & "Smooth," & Me.NumericUpDown_Smooth.Text & ";" & _
                                                    "RimTop," & Me.NumericUpDown_RimTop.Value & ";" & "RimBottom," & Me.NumericUpDown_RimBottom.Value & ";" & "RimLeft," & Me.NumericUpDown_RimLeft.Value & ";" & "RimRight," & Me.NumericUpDown_RimRight.Value & ";"

                '---Page 5---(Band) ---
                Parameter_Lists = Parameter_Lists & "Band," & Me.CheckBox_Band.Checked & ";" & "BandMura_ResizeCount," & Me.NumericUpDown_BandMura_ResizeCount.Value & ";" & "BandMura_SmoothCount," & Me.NumericUpDown_BandMura_SmoothCount.Value & ";" & _
                                                    "WhiteHBand_Threshold," & Me.NumericUpDown_WhiteHBand_Threshold.Value & ";" & "BlackHBand_Threshold," & Me.NumericUpDown_BlackHBand_Threshold.Value & ";" & _
                                                    "WhiteVBand_Threshold," & Me.NumericUpDown_WhiteVBand_Threshold.Value & ";" & "BlackVBand_Threshold," & Me.NumericUpDown_BlackVBand_Threshold.Value & ";" & _
                                                    "HTop," & Me.NumericUpDown_HTop.Value & ";" & "HBottom," & Me.NumericUpDown_HBottom.Value & ";" & "HLeft," & Me.NumericUpDown_HLeft.Value & ";" & "HRight," & Me.NumericUpDown_HRight.Value & ";" & _
                                                    "VTop," & Me.NumericUpDown_VTop.Value & ";" & "VBottom," & Me.NumericUpDown_VBottom.Value & ";" & "VLeft," & Me.NumericUpDown_VLeft.Value & ";" & "VRight," & Me.NumericUpDown_VRight.Value & ";" & _
                                                    "UseHValue," & Me.CheckBox_UseHValue.Checked & ";" & "HSlope," & Me.Label_HSlope.Text & ";" & "HConst," & Me.Label_HConst.Text & ";" & "HValue_UseHBand," & Me.CheckBox_HValue_UseHBand.Checked & ";" & "HValue_WhiteHBandTH," & Me.NumericUpDown_HValue_WhiteHBandTH.Value & ";" & "HValue_BalckHBandTH," & Me.NumericUpDown_HValue_BlackHBandTH.Value & ";" & _
                                                    "UseVValue," & Me.CheckBox_UseVValue.Checked & ";" & "VSlope," & Me.Label_VSlope.Text & ";" & "VConst," & Me.Label_VConst.Text & ";" & "VValue_UseVBand," & Me.CheckBox_VValue_UseVBand.Checked & ";" & "VValue_WhiteVBandTH," & Me.NumericUpDown_VValue_WhiteVBandTH.Value & ";" & "VValue_BalckVBandTH," & Me.NumericUpDown_VValue_BlackVBandTH.Value & ";"

                '---Page 6---(JND) --- Use Other Command -- DIALOG_MURAJND_SETTING


                '---Page 7---(Save) ---
                Parameter_Lists = Parameter_Lists & "SaveOriginal," & Me.CheckBox_SaveOriginal.Checked & ";" & "SaveDefocus," & Me.CheckBox_SaveDefocus.Checked & ";" & "SaveSmooth," & Me.CheckBox_SaveSmooth.Checked & ";" & "SaveResizeBMP," & Me.CheckBox_SaveResizeBMP.Checked & ";" & _
                                                    "SaveWhiteThreshold," & Me.CheckBox_SaveWhiteThreshold.Checked & ";" & "SaveWhiteReconstructArea," & Me.CheckBox_SaveWhiteReconstructArea.Checked & ";" & "SaveWhiteReconstructRim," & Me.CheckBox_SaveWhiteReconstructRim.Checked & ";" & _
                                                    "SaveBlackThreshold," & Me.CheckBox_SaveBlackThreshold.Checked & ";" & "SaveBlackReconstructArea," & Me.CheckBox_SaveBlackReconstructArea.Checked & ";" & "SaveBlackReconstructRim," & Me.CheckBox_SaveBlackReconstructRim.Checked & ";" & _
                                                    "SaveVBand," & Me.CheckBox_SaveVBand.Checked & ";" & "SaveHBand," & Me.CheckBox_SaveHBand.Checked & ";" & "SaveFFCAlignResult," & Me.CheckBox_SaveFFCAlignResult.Checked & ";" & "SaveFFTResult," & Me.CheckBox_SaveFFTResult.Checked & ";"
                '---Page 8---(Auto) ---
                Parameter_Lists = Parameter_Lists & "AutoExposure_Kp," & Me.NumericUpDown_AutoExposure_Kp.Value & ";" & "AutoExposure_TargetMean," & Me.NumericUpDown_AutoExposure_TargetMean.Value & ";" & _
                                                    "AutoExposure_LargeErrorRange_UL," & Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value & ";" & "AutoExposure_LargeErrorRange_DL," & Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value & ";" & _
                                                    "AutoExposure_SmallErrorRange," & Me.NumericUpDown_AutoExposure_SmallErrorRange.Value & ";" & _
                                                    "AutoExposure_GrabDelayTime," & Me.NumericUpDown_AutoExposure_GrabDelayTime.Value & ";"
                '---Page 9---(Abnormal) ---
                Parameter_Lists = Parameter_Lists & "GrayAbnormal_PosLimit_1," & Me.NumericUpDown_GrayAbnormal_PosLimit_1.Value & ";" & "GrayAbnormal_NegLimit_1," & Me.NumericUpDown_GrayAbnormal_NegLimit_1.Value & ";" & "GrayAbnormalStandardGray_1," & Me.NumericUpDown_GrayAbnormalStandardGray_1.Value & ";" & _
                                                  "GrayAbnormal_PosLimit_2," & Me.NumericUpDown_GrayAbnormal_PosLimit_2.Value & ";" & "GrayAbnormal_NegLimit_2," & Me.NumericUpDown_GrayAbnormal_NegLimit_2.Value & ";" & "GrayAbnormalStandardGray_2," & Me.NumericUpDown_GrayAbnormalStandardGray_2.Value & ";" & _
                                                  "GrayAbnormal_PosLimit_3," & Me.NumericUpDown_GrayAbnormal_PosLimit_3.Value & ";" & "GrayAbnormal_NegLimit_3," & Me.NumericUpDown_GrayAbnormal_NegLimit_3.Value & ";" & "GrayAbnormalStandardGray_3," & Me.NumericUpDown_GrayAbnormalStandardGray_3.Value & ";" & _
                                                  "GrayAbnormal_Enable," & Me.CheckBox_GrayAbnormal_Enable.Checked & ";" & "MultiRegion," & Me.CheckBox_MultiRegion.Checked & ";"

                'Other ---
                If Me.ComboBox_PatternList.Text <> "" Then
                    Parameter_Lists = Parameter_Lists & "PatternName," & Me.ComboBox_PatternList.Text & ";"
                End If

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSetting.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraJND Setting   ==> Request_Command = "DIALOG_MURAJND_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURAJND_SETTING"
                TimeOut = 100000 '100 secs
                Parameter_Lists = "WhiteBlobMura_AreaMin," & Me.NUD_WhiteBlobMura_AreaMin.Value & ";" & "WhiteBlobMura_AreaMax," & Me.NUD_WhiteBlobMura_AreaMax.Value & ";" & _
                                                  "WhiteBlobMura_JNDMin," & Me.NUD_WhiteBlobMura_JND_Min.Value & ";" & "WhiteBlobMura_JNDMax," & Me.NUD_WhiteBlobMura_JND_Max.Value & ";" & "WhiteBlobMura_ElongationMin," & Me.NUD_WhiteBlobMura_Elongation_Min.Value & ";" & "WhiteBlobMura_ElongationMax," & Me.NUD_WhiteBlobMura_Elongation_Max.Value & ";" & _
                                                  "WhiteMacroMura_AreaMin," & Me.NUD_WhiteMacroMura_AreaMin.Value & ";" & "WhiteMacroMura_AreaMax," & Me.NUD_WhiteMacroMura_AreaMax.Value & ";" & "WhiteMacroMura_JND," & Me.NUD_WhiteMacroMura_JND.Value & ";" & _
                                                  "WhiteBandMura_WidthMin," & Me.NUD_WhiteBandMura_WidthMin.Value & ";" & "WhiteBandMura_JND," & Me.NUD_WhiteBandMura_JND.Value & ";" & "WhiteBandMura_SJND," & Me.NUD_WhiteBandMura_SJND.Value & ";" & _
                                                  "WhiteAGM_AreaMin," & Me.NUD_WhiteAGM_AreaMin.Value & ";" & "WhiteAGM_AreaMax," & Me.NUD_WhiteAGM_AreaMax.Value & ";" & _
                                                  "WhiteAGM_JNDMin," & Me.NUD_WhiteAGM_JND_Min.Value & ";" & "WhiteAGM_JNDMax," & Me.NUD_WhiteAGM_JND_Max.Value & ";" & "WhiteAGM_ElongationMin," & Me.NUD_WhiteAGM_Elongation_Min.Value & ";" & "WhiteAGM_ElongationMax," & Me.NUD_WhiteAGM_Elongation_Max.Value & ";" & _
                                                  "BlackBlobMura_AreaMin," & Me.NUD_BlackBlobMura_AreaMin.Value & ";" & "BlackBlobMura_AreaMax," & Me.NUD_BlackBlobMura_AreaMax.Value & ";" & _
                                                  "BlackBlobMura_JNDMin," & Me.NUD_BlackBlobMura_JND_Min.Value & ";" & "BlackBlobMura_JNDMax," & Me.NUD_BlackBlobMura_JND_Max.Value & ";" & "BlackBlobMura_ElongationMin," & Me.NUD_BlackBlobMura_Elongation_Min.Value & ";" & "BlackBlobMura_ElongationMax," & Me.NUD_BlackBlobMura_Elongation_Max.Value & ";" & _
                                                  "BlackMacroMura_AreaMin," & Me.NUD_BlackMacroMura_AreaMin.Value & ";" & "BlackMacroMura_AreaMax," & Me.NUD_BlackMacroMura_AreaMax.Value & ";" & "BlackMacroMura_JND," & Me.NUD_BlackMacroMura_JND.Value & ";" & _
                                                  "BlackBandMura_WidthMin," & Me.NUD_BlackBandMura_WidthMin.Value & ";" & "BlackBandMura_JND," & Me.NUD_BlackBandMura_JND.Value & ";" & "BlackBandMura_SJND," & Me.NUD_BlackBandMura_SJND.Value & ";" & _
                                                  "BlackAGM_AreaMin," & Me.NUD_BlackAGM_AreaMin.Value & ";" & "BlackAGM_AreaMax," & Me.NUD_BlackAGM_AreaMax.Value & ";" & _
                                                  "BlackAGM_JNDMin," & Me.NUD_BlackAGM_JND_Min.Value & ";" & "BlackAGM_JNDMax," & Me.NUD_BlackAGM_JND_Max.Value & ";" & "BlackAGM_ElongationMin," & Me.NUD_BlackAGM_Elongation_Min.Value & ";" & "BlackAGM_ElongationMax," & Me.NUD_BlackAGM_Elongation_Max.Value

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraJND Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraJND.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraSetting CPD   ==> Request_Command = "DIALOG_MURASETTING_CPD" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURASETTING_CPD"
                TimeOut = 500000 '500 secs

                'UI Recipe Setting -----------------------------------


                '---(CPD) ---
                Parameter_Lists = "WithCoreCPD_Enable," & Me.CheckBox_WithCoreCPD_Enable.Checked & ";" & "WithCoreWhiteCPD_ThHigh," & Me.NumericUpDown_WithCoreWhiteCPD_ThHigh.Value & ";" & "WithCoreWhiteCPD_ThLow," & Me.NumericUpDown_WithCoreWhiteCPD_ThLow.Value & ";" & _
                                                    "WithCoreBlackCPD_ThHigh," & Me.NumericUpDown_WithCoreBlackCPD_ThHigh.Value & ";" & "WithCoreBlackCPD_ThLow," & Me.NumericUpDown_WithCoreBlackCPD_ThLow.Value & ";" & _
                                                    "WithCoreWhiteCPDCompactness_Low," & Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low.Value & ";" & "WithCoreWhiteCPDCompactness_High," & Me.NumericUpDown_WithCoreWhiteCPDCompactness_High.Value & ";" & _
                                                    "WithCoreWhiteCPDElongation_Low," & Me.NumericUpDown_WithCoreWhiteCPDElongation_Low.Value & ";" & "WithCoreWhiteCPDElongation_High," & Me.NumericUpDown_WithCoreWhiteCPDElongation_High.Value & ";" & _
                                                    "WithCoreWhiteCPDBreadth_Low," & Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low.Value & ";" & "WithCoreWhiteCPDBreadth_High," & Me.NumericUpDown_WithCoreWhiteCPDBreadth_High.Value & ";" & _
                                                    "WithCoreBlackCPDCompactness_Low," & Me.NumericUpDown_WithCoreBlackCPDCompactness_Low.Value & ";" & "WithCoreBlackCPDCompactness_High," & Me.NumericUpDown_WithCoreBlackCPDCompactness_High.Value & ";" & _
                                                    "WithCoreBlackCPDElongation_Low," & Me.NumericUpDown_WithCoreBlackCPDElongation_Low.Value & ";" & "WithCoreBlackCPDElongation_High," & Me.NumericUpDown_WithCoreBlackCPDElongation_High.Value & ";" & _
                                                    "WithCoreBlackCPDBreadth_Low," & Me.NumericUpDown_WithCoreBlackCPDBreadth_Low.Value & ";" & "WithCoreBlackCPDBreadth_High," & Me.NumericUpDown_WithCoreBlackCPDBreadth_High.Value & ";" & _
                                                    "WithoutCoreCPD_Enable," & Me.CheckBox_WithoutCoreCPD_Enable.Checked & ";" & "WithoutCoreWhiteCPD_ThHigh," & Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh.Value & ";" & "WithoutCoreWhiteCPD_ThLow," & Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow.Value & ";" & _
                                                    "WithoutCoreBlackCPD_ThHigh," & Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh.Value & ";" & "WithoutCoreBlackCPD_ThLow," & Me.NumericUpDown_WithoutCoreBlackCPD_ThLow.Value & ";" & _
                                                    "WithoutCoreWhiteCPDCompactness_Low," & Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low.Value & ";" & "WithoutCoreWhiteCPDCompactness_High," & Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High.Value & ";" & _
                                                    "WithoutCoreWhiteCPDElongation_Low," & Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low.Value & ";" & "WithoutCoreWhiteCPDElongation_High," & Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High.Value & ";" & _
                                                    "WithoutCoreWhiteCPDBreadth_Low," & Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low.Value & ";" & "WithoutCoreWhiteCPDBreadth_High," & Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High.Value & ";" & _
                                                    "WithoutCoreBlackCPDCompactness_Low," & Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low.Value & ";" & "WithoutCoreBlackCPDCompactness_High," & Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High.Value & ";" & _
                                                    "WithoutCoreBlackCPDElongation_Low," & Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low.Value & ";" & "WithoutCoreBlackCPDElongation_High," & Me.NumericUpDown_WithoutCoreBlackCPDElongation_High.Value & ";" & _
                                                    "WithoutCoreBlackCPDBreadth_Low," & Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low.Value & ";" & "WithoutCoreBlackCPDBreadth_High," & Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High.Value

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSetting.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            dir = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.TextBox_Product.Text & "\Mura"
            If Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If
            str = dir & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("**************************[MuraSave]******************************")
                i = Me.m_MainProcess.MuraPatternRecipeArrayOrder.IndexOf(Me.m_MuraProcess.CurrentMuraPatternRecipe)
                If i >= 0 Then
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[MuraPatternRecipe] �ثe Model�G" & Me.m_MainProcess.ProductName & " ; �ثe Pattern: " & Me.m_MuraProcess.CurrentMuraPatternRecipe.PatternName.Value)
                    Me.Compare(Me.m_MainProcess.MuraPatternRecipeArrayTemp.Item(i), Me.m_MuraProcess.CurrentMuraPatternRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                    Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern�s��]: " & str)
                Else
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("PatternAdd: " & Me.m_MuraProcess.Pattern)
                End If
            End If
            Me.m_MuraProcess.SaveMuraModelRecipe(dir, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
            Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Modeln�s��]: " & dir & "\MuraModelRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml")

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 10000 '10 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSetting.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog(Request_Command & "," & "" & "," & "" & "," & "" & ",(Timeout = " & TimeOut & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Mura Model Recipe  ==> Request_Command = "SAVE_MURA_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_MURA_MODEL_RECIPE"
                TimeOut = 10000 '10 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSetting.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Mura Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

            '--- Enable Button ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraSetting.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_MuraSetting.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_SaveFFCImages ---"
    Private Sub Button_SaveFFCImages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SaveFFCImages.Click
        Dim str As String
        Dim dir As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            dir = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.TextBox_Product.Text & "\Mura"
            If Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If

            If Me.CheckBox_UseBLFFC.Checked Then
                '----------------------------------------------------------------------------------------------
                ' BL FFC IMAGE==> Request_Command = "SAVE_BL_FFC_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_BL_FFC_IMAGE"
                    TimeOut = 200000 '200 secs

                    str = dir & "\ImageBLFFC" & ".tif"
                    str = Me.SavePath(str)

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save BL FFC Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraSetting.Button_SaveFFCImages]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            Else


                If Me.m_MuraProcess.Img_CurrentFFCAlign <> M_NULL Then
                    str = dir & "\ImageFFC_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".tif"
                    MbufSave(str, Me.m_MuraProcess.Img_CurrentFFCAlign)
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("�x�s�G�ե���l�v��: " & str)
                Else
                    MessageBox.Show("�L�G�ե��v��", "�`�N", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                End If

                '----------------------------------------------------------------------------------------------
                ' Save Current FFC Image ==> Request_Command = "SAVE_CURRENT_FFC_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_CURRENT_FFC_IMAGE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current FFC Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraSetting.Button_SaveFFCImages]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraSetting.Button_SaveFFCImages]" & ex.Message)
            MessageBox.Show("[Dialog_MuraSetting.Button_SaveFFCImages]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Calculate_Max ---"
    Private Sub Button_Calculate_Max_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Calculate_Max.Click
        Dim PatternName As String
        Dim Mura_ROI_Mean As Integer

        Me.NumericUpDown_AlignPercentage.Enabled = True
        Me.Button_SaveFFCImages.Enabled = True

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Get Mura ROI Mean Value   ==> Request_Command = "GET_MURA_ROIMEAN" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "GET_MURA_ROIMEAN"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_PatternList.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True

                Mura_ROI_Mean = SubSystemResult.Responses(0).Param1
                Me.Lbl_Max_GrayLevel.Text = Str(Mura_ROI_Mean)
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Mura ROI Mean Value Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraSetting.Button_Calculate_Max]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSetting.Button_Calculate_Max] Get Mura ROI Mean Value   Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSetting.Button_Calculate_Max]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_AddOne ---"
    Private Sub Button_AddOne_Click(sender As System.Object, e As System.EventArgs) Handles Button_AddOne.Click
        Dim lvi As ListViewItem
        If Me.ComboBox_ValueType.Text = "H" Then
            lvi = Me.ListView_HValue.Items.Add(Me.NumericUpDown_Value.Value)
            lvi.SubItems.Add(Me.NumericUpDown_JND.Value)
            Me.Label_HValueCount.Text = "�ƶq : " & Me.ListView_HValue.Items.Count
        ElseIf Me.ComboBox_ValueType.Text = "V" Then
            lvi = Me.ListView_VValue.Items.Add(Me.NumericUpDown_Value.Value)
            lvi.SubItems.Add(Me.NumericUpDown_JND.Value)
            Me.Label_VValueCount.Text = "�ƶq : " & Me.ListView_VValue.Items.Count
        End If
    End Sub
#End Region

#Region "---Button_CalculateLSQ---"
    Private Sub Button_CalculateLSQ_Click(sender As System.Object, e As System.EventArgs) Handles Button_CalculateLSQ.Click
        Dim HValue As Boolean = False
        Dim VValue As Boolean = False
        Dim HPara As String = ""
        Dim VPara As String = ""
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATEL1"
            TimeOut = 100000 '100 secs

            If Me.ListView_HValue.Items.Count < 6 And Me.CheckBox_UseHValue.Checked And Me.Label_HSlope.Text = "0" Then
                MessageBox.Show("�нT�{H Value�ƶq�W�L6�I", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            Else
                If Me.ListView_HValue.Items.Count >= 6 Then
                    HValue = True
                Else
                    HValue = False
                End If

                For i = 0 To Me.ListView_HValue.Items.Count - 1
                    HPara = HPara + Me.ListView_HValue.Items(i).Text + ","
                    If i = Me.ListView_HValue.Items.Count - 1 Then
                        HPara = HPara + Me.ListView_HValue.Items(i).SubItems(1).Text
                    Else
                        HPara = HPara + Me.ListView_HValue.Items(i).SubItems(1).Text + ";"
                    End If
                Next
            End If

            If Me.ListView_VValue.Items.Count < 6 And Me.CheckBox_UseVValue.Checked Then
                MessageBox.Show("�нT�{V Value�ƶq�W�L6�I", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            Else
                If Me.ListView_VValue.Items.Count >= 6 Then
                    VValue = True
                Else
                    VValue = False
                End If
                For i = 0 To Me.ListView_VValue.Items.Count - 1
                    VPara = VPara + Me.ListView_VValue.Items(i).Text + ","
                    If i = Me.ListView_VValue.Items.Count - 1 Then
                        VPara = VPara + Me.ListView_VValue.Items(i).SubItems(1).Text
                    Else
                        VPara = VPara + Me.ListView_VValue.Items(i).SubItems(1).Text + ";"
                    End If
                Next
            End If

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, HValue, VValue, HPara, VPara, , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")

                If HValue Then
                    Me.Label_HSlope.Text = SubSystemResult.Responses(0).Param1
                    Me.Label_HConst.Text = SubSystemResult.Responses(0).Param2
                End If

                If VValue Then
                    Me.Label_VSlope.Text = SubSystemResult.Responses(0).Param3
                    Me.Label_VConst.Text = SubSystemResult.Responses(0).Param4
                End If

                Me.Button_Save.PerformClick()

                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region


#End Region

#Region "--- CheckBox Event ---"

    Private Sub CheckBox_Show_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show.CheckedChanged
        Me.ReDraw()
    End Sub

    Private Sub CheckBox_Round_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Rim.CheckedChanged
        If Me.CheckBox_Rim.Checked Then
            Me.GroupBox_RimType.Enabled = True
            Me.GroupBox_RimParameter.Enabled = True
            Me.UpdateUserLevel()
        Else
            Me.GroupBox_RimType.Enabled = False
            Me.GroupBox_RimParameter.Enabled = False
        End If
    End Sub

    Private Sub CheckBox_ShowRound_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowRound.CheckedChanged
        Me.ReDraw()
    End Sub

    Private Sub CheckBox_Band_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Band.CheckedChanged
        If Me.CheckBox_Band.Checked Then
            Me.GroupBox_BandModify.Enabled = True
            Me.GroupBox_BandParameter.Enabled = True
            Me.UpdateUserLevel()
        Else
            Me.GroupBox_BandModify.Enabled = False
            Me.GroupBox_BandParameter.Enabled = False
        End If
    End Sub

    Private Sub CheckBox_ShowBand_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.ReDraw()
    End Sub

    Private Sub CheckBox_UseBLFFC_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_UseBLFFC.CheckedChanged
        If Me.CheckBox_UseBLFFC.Checked Then
            Me.CheckBox_UseFFC.Enabled = False
            Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value = False
            Me.GroupBox_SettingFFC.Enabled = False
            Me.NumericUpDown_AlignPercentage.Enabled = False
            Me.Button_SaveFFCImages.Enabled = True
            Me.Button_Calculate_Max.Enabled = False
        Else
            Me.CheckBox_UseFFC.Enabled = True
        End If
    End Sub

    Private Sub CheckBox_UseFFC_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_UseFFC.CheckedChanged
        If Me.CheckBox_UseFFC.Checked Then
            Me.CheckBox_UseBLFFC.Enabled = False
            Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value = True
            Me.GroupBox_SettingFFC.Enabled = True
            Me.NumericUpDown_AlignPercentage.Enabled = True
            Me.Button_SaveFFCImages.Enabled = True
            Me.Button_Calculate_Max.Enabled = True
        Else
            Me.CheckBox_UseBLFFC.Enabled = True
        End If
    End Sub

    Private Sub ComboBox_PatternList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_PatternList.SelectedIndexChanged

        Button_Enable(False)

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Button_Enable(True)
            Exit Sub
        End If

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_PatternList.SelectedIndex
        Me.m_MainProcess.SetRecipe(Me.ComboBox_PatternList.Text, Me.m_MainProcess.ErrorCode)

        '----------------------------------------------------------------------------------------------
        ' Set Pattern Info ==> Request_Command = "SET_PATTERNINDEX"  (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ComboBox_PatternList.Text, "NO", , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Button_Enable(True)
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Info Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Info Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Button_Enable(True)
        Me.UpdateData()
        Me.UpdateUserLevel()
        Call Me.m_Form.ImageZoomAll()
    End Sub

    Private Sub CheckBox_GrayAbnormal_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_GrayAbnormal_Enable.CheckedChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.GrayAbnormalEnable.Value = Me.CheckBox_GrayAbnormal_Enable.Checked
        Me.GroupBox_GrayAbnormal_1.Enabled = CheckBox_GrayAbnormal_Enable.Checked
    End Sub

    Private Sub CheckBox_MultiRegion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_MultiRegion.CheckedChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MultiRegion.Value = Me.CheckBox_MultiRegion.Checked
        Me.GroupBox_GrayAbnormal_2.Enabled = CheckBox_MultiRegion.Checked
        Me.GroupBox_GrayAbnormal_3.Enabled = CheckBox_MultiRegion.Checked
    End Sub

    Private Sub CheckBox_WithCoreCPD_Enable_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_WithCoreCPD_Enable.CheckedChanged
        If Me.CheckBox_WithCoreCPD_Enable.Checked Then
            Me.GroupBox_WithCoreCPDRecipe.Enabled = True
        Else
            Me.GroupBox_WithCoreCPDRecipe.Enabled = False
        End If
    End Sub

    Private Sub CheckBox_WithoutCoreCPD_Enable_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_WithoutCoreCPD_Enable.CheckedChanged
        If Me.CheckBox_WithoutCoreCPD_Enable.Checked Then
            Me.GroupBox_WithoutCoreCPDRecipe.Enabled = True
        Else
            Me.GroupBox_WithoutCoreCPDRecipe.Enabled = False
        End If
    End Sub

    Private Sub CheckBox_UseBaseLine_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_UseBaseLine.CheckedChanged
        If Me.CheckBox_UseBaseLine.Checked Then
            NumericUpDown_MacroPowerX.Enabled = True
            NumericUpDown_MacroPowerY.Enabled = True
            Num_ResizeCount_Mid.Enabled = False
            Num_ResizeCount_Max.Enabled = False
        Else
            NumericUpDown_MacroPowerX.Enabled = False
            NumericUpDown_MacroPowerY.Enabled = False
            Num_ResizeCount_Mid.Enabled = True
            Num_ResizeCount_Max.Enabled = True
        End If
    End Sub

    Private Sub CheckBox_UseHValue_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_UseHValue.CheckedChanged
        If Me.CheckBox_UseHValue.Checked Then
            Me.ListView_HValue.Enabled = True
        Else
            Me.ListView_HValue.Enabled = False
        End If
    End Sub

    Private Sub CheckBox_UseVValue_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_UseVValue.CheckedChanged
        If Me.CheckBox_UseVValue.Checked Then
            Me.ListView_VValue.Enabled = True
        Else
            Me.ListView_VValue.Enabled = False
        End If
    End Sub

#End Region

#Region "--- RadioButton ---"

    Private Sub RadioButton_Manual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Manual.CheckedChanged
        If Me.RadioButton_Manual.Checked Then
            Me.m_CurrentTab = Me.TabControl_Setting.SelectedIndex
            Me.GroupBox_Area.Enabled = True
        End If
    End Sub

    Private Sub RadioButton_Finish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Finish.CheckedChanged
        Dim boundary As ClsParameterBoundary
        If Me.RadioButton_Finish.Checked Then
            Me.GroupBox_Area.Enabled = False
            Me.m_CurrentTab = -1
            boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound
            boundary.TopY = Me.NumericUpDown_AreaTop.Value
            boundary.BottomY = Me.NumericUpDown_AreaBottom.Value
            boundary.LeftX = Me.NumericUpDown_AreaLeft.Value
            boundary.RightX = Me.NumericUpDown_AreaRight.Value

        End If
    End Sub

    Private Sub RadioButton_RoundFinish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_RoundFinish.CheckedChanged
        Dim boundary As ClsParameterBoundary
        If Me.RadioButton_RoundFinish.Checked Then
            Me.GroupBox_Round.Enabled = False
            Me.CheckBox_Rim.Enabled = True

            Me.m_CurrentTab = -1
            boundary = Me.m_MuraProcess.CurrentMuraPatternRecipe.Rim

            boundary.TopY = Me.NumericUpDown_RimTop.Value
            boundary.BottomY = Me.NumericUpDown_RimBottom.Value
            boundary.LeftX = Me.NumericUpDown_RimLeft.Value
            boundary.RightX = Me.NumericUpDown_RimRight.Value
        End If
    End Sub

    Private Sub RadioButton_RoundManual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_RoundManual.CheckedChanged
        If Me.RadioButton_RoundManual.Checked Then
            Me.GroupBox_Round.Enabled = True
            Me.CheckBox_Rim.Enabled = False
            Me.m_CurrentTab = Me.TabControl_Setting.SelectedIndex
        End If
    End Sub

#End Region

#Region "--- NumericUpDown_Area Event ---"

#Region "--- ���߰ϰ� ---"

    Private Sub NumericUpDown_AreaTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaTop.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_AreaBottom.Maximum = Me.m_Boundary.BottomY - Me.NumericUpDown_AreaTop.Value
            Me.ReDraw()
        End If
    End Sub

    Private Sub NumericUpDown_AreaBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaBottom.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_AreaTop.Maximum = Me.m_Boundary.BottomY - Me.NumericUpDown_AreaBottom.Value
            Me.ReDraw()
        End If
    End Sub

    Private Sub NumericUpDown_AreaLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaLeft.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_AreaRight.Maximum = Me.m_Boundary.RightX - Me.NumericUpDown_AreaLeft.Value
            Me.ReDraw()
        End If
    End Sub

    Private Sub NumericUpDown_AreaRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaRight.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_AreaLeft.Maximum = Me.m_Boundary.RightX - Me.NumericUpDown_AreaRight.Value
            Me.ReDraw()
        End If
    End Sub

    Private Sub Num_ResizeCount_Max_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Max.ValueChanged
        If Me.Num_ResizeCount_Max.Value <= Me.Num_ResizeCount_Mid.Value Then
            Me.Num_ResizeCount_Mid.Value = Me.Num_ResizeCount_Max.Value - 1
            Me.Num_ResizeCount_Mid2.Value = Me.Num_ResizeCount_Mid.Value
            If Me.Num_ResizeCount_Mid2.Value <= Me.Num_ResizeCount_Min.Value Then
                Me.Num_ResizeCount_Min.Value = Me.Num_ResizeCount_Mid2.Value - 1
            End If
        End If
    End Sub

    Private Sub Num_ResizeCount_Mid_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Mid.ValueChanged
        Me.Num_ResizeCount_Mid2.Value = Me.Num_ResizeCount_Mid.Value
        If Me.Num_ResizeCount_Mid.Value >= Me.Num_ResizeCount_Max.Value Then
            Me.Num_ResizeCount_Max.Value = Me.Num_ResizeCount_Mid.Value + 1
        End If
        If Me.Num_ResizeCount_Mid.Value <= Me.Num_ResizeCount_Min.Value Then
            Me.Num_ResizeCount_Min.Value = Me.Num_ResizeCount_Mid.Value - 1
        End If
    End Sub

    Private Sub Num_ResizeCount_Mid2_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Mid2.ValueChanged
        Me.Num_ResizeCount_Mid.Value = Me.Num_ResizeCount_Mid2.Value
        If Me.Num_ResizeCount_Mid2.Value >= Me.Num_ResizeCount_Max.Value Then
            Me.Num_ResizeCount_Max.Value = Me.Num_ResizeCount_Mid2.Value + 1
        End If
        If Me.Num_ResizeCount_Mid2.Value <= Me.Num_ResizeCount_Min.Value Then
            Me.Num_ResizeCount_Min.Value = Me.Num_ResizeCount_Mid2.Value - 1
        End If
    End Sub

    Private Sub Num_ResizeCount_Min_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Min.ValueChanged
        If Me.Num_ResizeCount_Mid2.Value <= Me.Num_ResizeCount_Min.Value Then
            Me.Num_ResizeCount_Mid2.Value = Me.Num_ResizeCount_Min.Value + 1
            Me.Num_ResizeCount_Mid.Value = Me.Num_ResizeCount_Mid2.Value
            If Me.Num_ResizeCount_Mid.Value >= Me.Num_ResizeCount_Max.Value Then
                Me.Num_ResizeCount_Max.Value = Me.Num_ResizeCount_Mid.Value + 1
            End If
        End If
    End Sub

#End Region

#Region "--- ��t�ϰ� ---"
    Private Sub NumericUpDown_Top_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimTop.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_RimTop.Maximum = Me.NumericUpDown_AreaTop.Value - 1
            Me.ReDraw()
        End If
    End Sub
    Private Sub NumericUpDown_Bottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimBottom.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_AreaBottom.Minimum = Me.NumericUpDown_RimBottom.Value + 1
            Me.ReDraw()
        End If
    End Sub
    Private Sub NumericUpDown_Left_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimLeft.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_AreaLeft.Minimum = Me.NumericUpDown_RimLeft.Value + 1
            Me.ReDraw()
        End If
    End Sub
    Private Sub NumericUpDown_Right_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimRight.ValueChanged
        If Not Me.m_Boundary Is Nothing Then
            Me.NumericUpDown_AreaRight.Minimum = Me.NumericUpDown_RimRight.Value + 1
            Me.ReDraw()
        End If
    End Sub
#End Region

#Region "--- Mura Band ---"
    Private Sub NumericUpDown_HTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_HTop.ValueChanged
        Me.NumericUpDown_HBottom.Maximum = Me.m_Boundary.BottomY - Me.m_Boundary.TopY + 1 - Me.NumericUpDown_HTop.Value
    End Sub
    Private Sub NumericUpDown_HBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_HBottom.ValueChanged
        Me.NumericUpDown_HTop.Maximum = Me.m_Boundary.BottomY - Me.m_Boundary.TopY + 1 - Me.NumericUpDown_HBottom.Value
    End Sub
    Private Sub NumericUpDown_HLeft_ValueChanged(sender As Object, e As System.EventArgs) Handles NumericUpDown_HLeft.ValueChanged
        Me.NumericUpDown_HRight.Maximum = Me.m_Boundary.RightX - Me.m_Boundary.LeftX + 1 - Me.NumericUpDown_HLeft.Value
    End Sub
    Private Sub NumericUpDown_HRight_ValueChanged(sender As Object, e As System.EventArgs) Handles NumericUpDown_HRight.ValueChanged
        Me.NumericUpDown_HLeft.Maximum = Me.m_Boundary.RightX - Me.m_Boundary.LeftX + 1 - Me.NumericUpDown_HRight.Value
    End Sub
    Private Sub NumericUpDown_VTop_ValueChanged(sender As Object, e As System.EventArgs) Handles NumericUpDown_VTop.ValueChanged
        Me.NumericUpDown_VBottom.Maximum = Me.m_Boundary.BottomY - Me.m_Boundary.TopY + 1 - Me.NumericUpDown_VTop.Value
    End Sub
    Private Sub NumericUpDown_VBottom_ValueChanged(sender As Object, e As System.EventArgs) Handles NumericUpDown_VBottom.ValueChanged
        Me.NumericUpDown_VTop.Maximum = Me.m_Boundary.BottomY - Me.m_Boundary.TopY + 1 - Me.NumericUpDown_VBottom.Value
    End Sub
    Private Sub NumericUpDown_VLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_VLeft.ValueChanged
        Me.NumericUpDown_VRight.Maximum = Me.m_Boundary.RightX - Me.m_Boundary.LeftX + 1 - Me.NumericUpDown_VLeft.Value
    End Sub
    Private Sub NumericUpDown_VRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_VRight.ValueChanged
        Me.NumericUpDown_VLeft.Maximum = Me.m_Boundary.RightX - Me.m_Boundary.LeftX + 1 - Me.NumericUpDown_VRight.Value
    End Sub
#End Region

#Region "--- Abnormal ---"
    Private Sub NumericUpDown_GrayAbnormal_PosLimit_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_GrayAbnormal_PosLimit_1.ValueChanged
        Me.Lbl_GrayAbnormal_PosLimit_1.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_1.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit_1.Value) / 100), "#"))
    End Sub

    Private Sub NumericUpDown_GrayAbnormal_NegLimit_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_GrayAbnormal_NegLimit_1.ValueChanged
        Me.Lbl_GrayAbnormal_NegLimit_1.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_1.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit_1.Value) / 100), "#"))
    End Sub

    Private Sub NumericUpDown_GrayAbnormalStandardGray_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_GrayAbnormalStandardGray_1.ValueChanged
        Me.Lbl_GrayAbnormal_PosLimit_1.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_1.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit_1.Value) / 100), "#"))
        Me.Lbl_GrayAbnormal_NegLimit_1.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray_1.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit_1.Value) / 100), "#"))
    End Sub
#End Region

#End Region

#Region "--- Me.SavePath ---"
    Private Function SavePath(ByRef strPath As String)

        strPath = Replace(strPath, "\", "\\")
        If (strPath.Contains("\\\\")) Then
            strPath = Replace(strPath, "\\\\", "\\")
        End If
        Return strPath
    End Function
#End Region

End Class