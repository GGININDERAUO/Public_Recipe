<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_BandMura
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_BandMura))
        Me.NumericUpDown_WhiteHBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.NumericUpDown_WhiteVBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackBand_Thrshold = New System.Windows.Forms.Label()
        Me.Button_Band = New System.Windows.Forms.Button()
        Me.Button_Ok = New System.Windows.Forms.Button()
        Me.Label_HBand_Thrshold = New System.Windows.Forms.Label()
        Me.GroupBox_Parameter = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlackVBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlackHBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BandMura_SmoothCount = New System.Windows.Forms.NumericUpDown()
        Me.Label_Band_SmoothCount = New System.Windows.Forms.Label()
        Me.NumericUpDown_BandMura_ResizeCount = New System.Windows.Forms.NumericUpDown()
        Me.Label_Band_ResizeCount = New System.Windows.Forms.Label()
        Me.GroupBox_Modify = New System.Windows.Forms.GroupBox()
        Me.ComboBox_Show = New System.Windows.Forms.ComboBox()
        Me.CheckBox_Show = New System.Windows.Forms.CheckBox()
        Me.GroupBox_V = New System.Windows.Forms.GroupBox()
        Me.TextBox_VHCount = New System.Windows.Forms.TextBox()
        Me.Button_VLeftBase = New System.Windows.Forms.Button()
        Me.TextBox_VVCount = New System.Windows.Forms.TextBox()
        Me.Button_VRightBase = New System.Windows.Forms.Button()
        Me.Button_VTopBase = New System.Windows.Forms.Button()
        Me.NumericUpDown_VTop = New System.Windows.Forms.NumericUpDown()
        Me.Button_VBottomBase = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumericUpDown_VRight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_VBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_Right = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NumericUpDown_VLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_Left = New System.Windows.Forms.Label()
        Me.RadioButton_Manual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Finish = New System.Windows.Forms.RadioButton()
        Me.GroupBox_H = New System.Windows.Forms.GroupBox()
        Me.TextBox_HHCount = New System.Windows.Forms.TextBox()
        Me.TextBox_HVCount = New System.Windows.Forms.TextBox()
        Me.Button_HLeftBase = New System.Windows.Forms.Button()
        Me.Button_HTopBase = New System.Windows.Forms.Button()
        Me.Button_HRightBase = New System.Windows.Forms.Button()
        Me.Button_HBottomBase = New System.Windows.Forms.Button()
        Me.NumericUpDown_HRight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_HTop = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label_Bottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_HLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NumericUpDown_HBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_Top = New System.Windows.Forms.Label()
        Me.Button_Load = New System.Windows.Forms.Button()
        Me.Label_Select = New System.Windows.Forms.Label()
        Me.ComboBox_Select = New System.Windows.Forms.ComboBox()
        Me.ComboBox_Result = New System.Windows.Forms.ComboBox()
        Me.CheckBox_Result = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Band = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ListView_VBlock = New System.Windows.Forms.ListView()
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ListView_HBlock = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_AutoWidth = New System.Windows.Forms.NumericUpDown()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.CheckBox_ShowBlock = New System.Windows.Forms.CheckBox()
        Me.Button_AddBlockSetting = New System.Windows.Forms.Button()
        Me.ComboBox_SelectBlock = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlockBlackTH = New System.Windows.Forms.NumericUpDown()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlockWhiteTH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlockTop = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlockRight = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlockButtom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlockLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ContextMenuStrip_BlockSetting = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.DeleteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.NumericUpDown_VValue = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_HValue = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_VValue_BlackTH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_HValue_WhiteTH = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.NumericUpDown_VValue_WhiteTH = New System.Windows.Forms.NumericUpDown()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.NumericUpDown_HValue_BlackTH = New System.Windows.Forms.NumericUpDown()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.CheckBox_BandUseRemoveHV = New System.Windows.Forms.CheckBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.CheckBox_EnableBandLeakPoint = New System.Windows.Forms.CheckBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BandLeakPointFilterRadius = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BandVOpenEdgeStrength = New System.Windows.Forms.NumericUpDown()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.CheckBox_EnableBandVOpen = New System.Windows.Forms.CheckBox()
        CType(Me.NumericUpDown_WhiteHBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteVBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Parameter.SuspendLayout()
        CType(Me.NumericUpDown_BlackVBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlackHBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BandMura_SmoothCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BandMura_ResizeCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Modify.SuspendLayout()
        Me.GroupBox_V.SuspendLayout()
        CType(Me.NumericUpDown_VTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_H.SuspendLayout()
        CType(Me.NumericUpDown_HRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NumericUpDown_AutoWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockBlackTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockWhiteTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockButtom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlockLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip_BlockSetting.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.NumericUpDown_VValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VValue_BlackTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HValue_WhiteTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VValue_WhiteTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HValue_BlackTH, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.NumericUpDown_BandLeakPointFilterRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.NumericUpDown_BandVOpenEdgeStrength, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NumericUpDown_WhiteHBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteHBand_Threshold, "NumericUpDown_WhiteHBand_Threshold")
        Me.NumericUpDown_WhiteHBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_WhiteHBand_Threshold.Name = "NumericUpDown_WhiteHBand_Threshold"
        Me.NumericUpDown_WhiteHBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        '
        'NumericUpDown_WhiteVBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteVBand_Threshold, "NumericUpDown_WhiteVBand_Threshold")
        Me.NumericUpDown_WhiteVBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_WhiteVBand_Threshold.Name = "NumericUpDown_WhiteVBand_Threshold"
        Me.NumericUpDown_WhiteVBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_BlackBand_Thrshold
        '
        resources.ApplyResources(Me.Label_BlackBand_Thrshold, "Label_BlackBand_Thrshold")
        Me.Label_BlackBand_Thrshold.Name = "Label_BlackBand_Thrshold"
        '
        'Button_Band
        '
        resources.ApplyResources(Me.Button_Band, "Button_Band")
        Me.Button_Band.Name = "Button_Band"
        '
        'Button_Ok
        '
        resources.ApplyResources(Me.Button_Ok, "Button_Ok")
        Me.Button_Ok.Name = "Button_Ok"
        '
        'Label_HBand_Thrshold
        '
        resources.ApplyResources(Me.Label_HBand_Thrshold, "Label_HBand_Thrshold")
        Me.Label_HBand_Thrshold.Name = "Label_HBand_Thrshold"
        '
        'GroupBox_Parameter
        '
        resources.ApplyResources(Me.GroupBox_Parameter, "GroupBox_Parameter")
        Me.GroupBox_Parameter.Controls.Add(Me.Label2)
        Me.GroupBox_Parameter.Controls.Add(Me.Label1)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_BlackVBand_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_BlackHBand_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_BandMura_SmoothCount)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_Band_SmoothCount)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_BandMura_ResizeCount)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_Band_ResizeCount)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_WhiteHBand_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_WhiteVBand_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_BlackBand_Thrshold)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_HBand_Thrshold)
        Me.GroupBox_Parameter.Name = "GroupBox_Parameter"
        Me.GroupBox_Parameter.TabStop = False
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'NumericUpDown_BlackVBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_BlackVBand_Threshold, "NumericUpDown_BlackVBand_Threshold")
        Me.NumericUpDown_BlackVBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlackVBand_Threshold.Name = "NumericUpDown_BlackVBand_Threshold"
        Me.NumericUpDown_BlackVBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_BlackHBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_BlackHBand_Threshold, "NumericUpDown_BlackHBand_Threshold")
        Me.NumericUpDown_BlackHBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlackHBand_Threshold.Name = "NumericUpDown_BlackHBand_Threshold"
        Me.NumericUpDown_BlackHBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_BandMura_SmoothCount
        '
        resources.ApplyResources(Me.NumericUpDown_BandMura_SmoothCount, "NumericUpDown_BandMura_SmoothCount")
        Me.NumericUpDown_BandMura_SmoothCount.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BandMura_SmoothCount.Name = "NumericUpDown_BandMura_SmoothCount"
        '
        'Label_Band_SmoothCount
        '
        resources.ApplyResources(Me.Label_Band_SmoothCount, "Label_Band_SmoothCount")
        Me.Label_Band_SmoothCount.Name = "Label_Band_SmoothCount"
        '
        'NumericUpDown_BandMura_ResizeCount
        '
        resources.ApplyResources(Me.NumericUpDown_BandMura_ResizeCount, "NumericUpDown_BandMura_ResizeCount")
        Me.NumericUpDown_BandMura_ResizeCount.Maximum = New Decimal(New Integer() {4, 0, 0, 0})
        Me.NumericUpDown_BandMura_ResizeCount.Name = "NumericUpDown_BandMura_ResizeCount"
        '
        'Label_Band_ResizeCount
        '
        resources.ApplyResources(Me.Label_Band_ResizeCount, "Label_Band_ResizeCount")
        Me.Label_Band_ResizeCount.Name = "Label_Band_ResizeCount"
        '
        'GroupBox_Modify
        '
        resources.ApplyResources(Me.GroupBox_Modify, "GroupBox_Modify")
        Me.GroupBox_Modify.Controls.Add(Me.ComboBox_Show)
        Me.GroupBox_Modify.Controls.Add(Me.CheckBox_Show)
        Me.GroupBox_Modify.Controls.Add(Me.GroupBox_V)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Manual)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Finish)
        Me.GroupBox_Modify.Controls.Add(Me.GroupBox_H)
        Me.GroupBox_Modify.Name = "GroupBox_Modify"
        Me.GroupBox_Modify.TabStop = False
        '
        'ComboBox_Show
        '
        resources.ApplyResources(Me.ComboBox_Show, "ComboBox_Show")
        Me.ComboBox_Show.FormattingEnabled = True
        Me.ComboBox_Show.Items.AddRange(New Object() {resources.GetString("ComboBox_Show.Items"), resources.GetString("ComboBox_Show.Items1")})
        Me.ComboBox_Show.Name = "ComboBox_Show"
        '
        'CheckBox_Show
        '
        resources.ApplyResources(Me.CheckBox_Show, "CheckBox_Show")
        Me.CheckBox_Show.Name = "CheckBox_Show"
        '
        'GroupBox_V
        '
        resources.ApplyResources(Me.GroupBox_V, "GroupBox_V")
        Me.GroupBox_V.Controls.Add(Me.TextBox_VHCount)
        Me.GroupBox_V.Controls.Add(Me.Button_VLeftBase)
        Me.GroupBox_V.Controls.Add(Me.TextBox_VVCount)
        Me.GroupBox_V.Controls.Add(Me.Button_VRightBase)
        Me.GroupBox_V.Controls.Add(Me.Button_VTopBase)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VTop)
        Me.GroupBox_V.Controls.Add(Me.Button_VBottomBase)
        Me.GroupBox_V.Controls.Add(Me.Label5)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VRight)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VBottom)
        Me.GroupBox_V.Controls.Add(Me.Label_Right)
        Me.GroupBox_V.Controls.Add(Me.Label6)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VLeft)
        Me.GroupBox_V.Controls.Add(Me.Label_Left)
        Me.GroupBox_V.Name = "GroupBox_V"
        Me.GroupBox_V.TabStop = False
        '
        'TextBox_VHCount
        '
        resources.ApplyResources(Me.TextBox_VHCount, "TextBox_VHCount")
        Me.TextBox_VHCount.Name = "TextBox_VHCount"
        '
        'Button_VLeftBase
        '
        resources.ApplyResources(Me.Button_VLeftBase, "Button_VLeftBase")
        Me.Button_VLeftBase.Name = "Button_VLeftBase"
        Me.Button_VLeftBase.UseVisualStyleBackColor = True
        '
        'TextBox_VVCount
        '
        resources.ApplyResources(Me.TextBox_VVCount, "TextBox_VVCount")
        Me.TextBox_VVCount.Name = "TextBox_VVCount"
        '
        'Button_VRightBase
        '
        resources.ApplyResources(Me.Button_VRightBase, "Button_VRightBase")
        Me.Button_VRightBase.Name = "Button_VRightBase"
        Me.Button_VRightBase.UseVisualStyleBackColor = True
        '
        'Button_VTopBase
        '
        resources.ApplyResources(Me.Button_VTopBase, "Button_VTopBase")
        Me.Button_VTopBase.Name = "Button_VTopBase"
        Me.Button_VTopBase.UseVisualStyleBackColor = True
        '
        'NumericUpDown_VTop
        '
        resources.ApplyResources(Me.NumericUpDown_VTop, "NumericUpDown_VTop")
        Me.NumericUpDown_VTop.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VTop.Name = "NumericUpDown_VTop"
        '
        'Button_VBottomBase
        '
        resources.ApplyResources(Me.Button_VBottomBase, "Button_VBottomBase")
        Me.Button_VBottomBase.Name = "Button_VBottomBase"
        Me.Button_VBottomBase.UseVisualStyleBackColor = True
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'NumericUpDown_VRight
        '
        resources.ApplyResources(Me.NumericUpDown_VRight, "NumericUpDown_VRight")
        Me.NumericUpDown_VRight.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VRight.Name = "NumericUpDown_VRight"
        '
        'NumericUpDown_VBottom
        '
        resources.ApplyResources(Me.NumericUpDown_VBottom, "NumericUpDown_VBottom")
        Me.NumericUpDown_VBottom.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VBottom.Name = "NumericUpDown_VBottom"
        '
        'Label_Right
        '
        resources.ApplyResources(Me.Label_Right, "Label_Right")
        Me.Label_Right.Name = "Label_Right"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'NumericUpDown_VLeft
        '
        resources.ApplyResources(Me.NumericUpDown_VLeft, "NumericUpDown_VLeft")
        Me.NumericUpDown_VLeft.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_VLeft.Name = "NumericUpDown_VLeft"
        '
        'Label_Left
        '
        resources.ApplyResources(Me.Label_Left, "Label_Left")
        Me.Label_Left.Name = "Label_Left"
        '
        'RadioButton_Manual
        '
        resources.ApplyResources(Me.RadioButton_Manual, "RadioButton_Manual")
        Me.RadioButton_Manual.Name = "RadioButton_Manual"
        '
        'RadioButton_Finish
        '
        resources.ApplyResources(Me.RadioButton_Finish, "RadioButton_Finish")
        Me.RadioButton_Finish.Name = "RadioButton_Finish"
        '
        'GroupBox_H
        '
        resources.ApplyResources(Me.GroupBox_H, "GroupBox_H")
        Me.GroupBox_H.Controls.Add(Me.TextBox_HHCount)
        Me.GroupBox_H.Controls.Add(Me.TextBox_HVCount)
        Me.GroupBox_H.Controls.Add(Me.Button_HLeftBase)
        Me.GroupBox_H.Controls.Add(Me.Button_HTopBase)
        Me.GroupBox_H.Controls.Add(Me.Button_HRightBase)
        Me.GroupBox_H.Controls.Add(Me.Button_HBottomBase)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HRight)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HTop)
        Me.GroupBox_H.Controls.Add(Me.Label3)
        Me.GroupBox_H.Controls.Add(Me.Label_Bottom)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HLeft)
        Me.GroupBox_H.Controls.Add(Me.Label4)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HBottom)
        Me.GroupBox_H.Controls.Add(Me.Label_Top)
        Me.GroupBox_H.Name = "GroupBox_H"
        Me.GroupBox_H.TabStop = False
        '
        'TextBox_HHCount
        '
        resources.ApplyResources(Me.TextBox_HHCount, "TextBox_HHCount")
        Me.TextBox_HHCount.Name = "TextBox_HHCount"
        '
        'TextBox_HVCount
        '
        resources.ApplyResources(Me.TextBox_HVCount, "TextBox_HVCount")
        Me.TextBox_HVCount.Name = "TextBox_HVCount"
        '
        'Button_HLeftBase
        '
        resources.ApplyResources(Me.Button_HLeftBase, "Button_HLeftBase")
        Me.Button_HLeftBase.Name = "Button_HLeftBase"
        Me.Button_HLeftBase.UseVisualStyleBackColor = True
        '
        'Button_HTopBase
        '
        resources.ApplyResources(Me.Button_HTopBase, "Button_HTopBase")
        Me.Button_HTopBase.Name = "Button_HTopBase"
        Me.Button_HTopBase.UseVisualStyleBackColor = True
        '
        'Button_HRightBase
        '
        resources.ApplyResources(Me.Button_HRightBase, "Button_HRightBase")
        Me.Button_HRightBase.Name = "Button_HRightBase"
        Me.Button_HRightBase.UseVisualStyleBackColor = True
        '
        'Button_HBottomBase
        '
        resources.ApplyResources(Me.Button_HBottomBase, "Button_HBottomBase")
        Me.Button_HBottomBase.Name = "Button_HBottomBase"
        Me.Button_HBottomBase.UseVisualStyleBackColor = True
        '
        'NumericUpDown_HRight
        '
        resources.ApplyResources(Me.NumericUpDown_HRight, "NumericUpDown_HRight")
        Me.NumericUpDown_HRight.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HRight.Name = "NumericUpDown_HRight"
        '
        'NumericUpDown_HTop
        '
        resources.ApplyResources(Me.NumericUpDown_HTop, "NumericUpDown_HTop")
        Me.NumericUpDown_HTop.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HTop.Name = "NumericUpDown_HTop"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label_Bottom
        '
        resources.ApplyResources(Me.Label_Bottom, "Label_Bottom")
        Me.Label_Bottom.Name = "Label_Bottom"
        '
        'NumericUpDown_HLeft
        '
        resources.ApplyResources(Me.NumericUpDown_HLeft, "NumericUpDown_HLeft")
        Me.NumericUpDown_HLeft.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HLeft.Name = "NumericUpDown_HLeft"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'NumericUpDown_HBottom
        '
        resources.ApplyResources(Me.NumericUpDown_HBottom, "NumericUpDown_HBottom")
        Me.NumericUpDown_HBottom.Maximum = New Decimal(New Integer() {4000, 0, 0, 0})
        Me.NumericUpDown_HBottom.Name = "NumericUpDown_HBottom"
        '
        'Label_Top
        '
        resources.ApplyResources(Me.Label_Top, "Label_Top")
        Me.Label_Top.Name = "Label_Top"
        '
        'Button_Load
        '
        resources.ApplyResources(Me.Button_Load, "Button_Load")
        Me.Button_Load.Name = "Button_Load"
        '
        'Label_Select
        '
        resources.ApplyResources(Me.Label_Select, "Label_Select")
        Me.Label_Select.Name = "Label_Select"
        '
        'ComboBox_Select
        '
        resources.ApplyResources(Me.ComboBox_Select, "ComboBox_Select")
        Me.ComboBox_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Select.Name = "ComboBox_Select"
        '
        'ComboBox_Result
        '
        resources.ApplyResources(Me.ComboBox_Result, "ComboBox_Result")
        Me.ComboBox_Result.FormattingEnabled = True
        Me.ComboBox_Result.Items.AddRange(New Object() {resources.GetString("ComboBox_Result.Items"), resources.GetString("ComboBox_Result.Items1")})
        Me.ComboBox_Result.Name = "ComboBox_Result"
        '
        'CheckBox_Result
        '
        resources.ApplyResources(Me.CheckBox_Result, "CheckBox_Result")
        Me.CheckBox_Result.Name = "CheckBox_Result"
        '
        'CheckBox_Band
        '
        resources.ApplyResources(Me.CheckBox_Band, "CheckBox_Band")
        Me.CheckBox_Band.Name = "CheckBox_Band"
        '
        'GroupBox3
        '
        resources.ApplyResources(Me.GroupBox3, "GroupBox3")
        Me.GroupBox3.Controls.Add(Me.ListView_VBlock)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.TabStop = False
        '
        'ListView_VBlock
        '
        resources.ApplyResources(Me.ListView_VBlock, "ListView_VBlock")
        Me.ListView_VBlock.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10, Me.ColumnHeader11, Me.ColumnHeader12})
        Me.ListView_VBlock.FullRowSelect = True
        Me.ListView_VBlock.GridLines = True
        Me.ListView_VBlock.Name = "ListView_VBlock"
        Me.ListView_VBlock.UseCompatibleStateImageBehavior = False
        Me.ListView_VBlock.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader7
        '
        resources.ApplyResources(Me.ColumnHeader7, "ColumnHeader7")
        '
        'ColumnHeader8
        '
        resources.ApplyResources(Me.ColumnHeader8, "ColumnHeader8")
        '
        'ColumnHeader9
        '
        resources.ApplyResources(Me.ColumnHeader9, "ColumnHeader9")
        '
        'ColumnHeader10
        '
        resources.ApplyResources(Me.ColumnHeader10, "ColumnHeader10")
        '
        'ColumnHeader11
        '
        resources.ApplyResources(Me.ColumnHeader11, "ColumnHeader11")
        '
        'ColumnHeader12
        '
        resources.ApplyResources(Me.ColumnHeader12, "ColumnHeader12")
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.ListView_HBlock)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'ListView_HBlock
        '
        resources.ApplyResources(Me.ListView_HBlock, "ListView_HBlock")
        Me.ListView_HBlock.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6})
        Me.ListView_HBlock.FullRowSelect = True
        Me.ListView_HBlock.GridLines = True
        Me.ListView_HBlock.Name = "ListView_HBlock"
        Me.ListView_HBlock.UseCompatibleStateImageBehavior = False
        Me.ListView_HBlock.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        resources.ApplyResources(Me.ColumnHeader1, "ColumnHeader1")
        '
        'ColumnHeader2
        '
        resources.ApplyResources(Me.ColumnHeader2, "ColumnHeader2")
        '
        'ColumnHeader3
        '
        resources.ApplyResources(Me.ColumnHeader3, "ColumnHeader3")
        '
        'ColumnHeader4
        '
        resources.ApplyResources(Me.ColumnHeader4, "ColumnHeader4")
        '
        'ColumnHeader5
        '
        resources.ApplyResources(Me.ColumnHeader5, "ColumnHeader5")
        '
        'ColumnHeader6
        '
        resources.ApplyResources(Me.ColumnHeader6, "ColumnHeader6")
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_AutoWidth)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Controls.Add(Me.CheckBox_ShowBlock)
        Me.GroupBox1.Controls.Add(Me.Button_AddBlockSetting)
        Me.GroupBox1.Controls.Add(Me.ComboBox_SelectBlock)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_BlockBlackTH)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_BlockWhiteTH)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_BlockTop)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_BlockRight)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_BlockButtom)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_BlockLeft)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'NumericUpDown_AutoWidth
        '
        resources.ApplyResources(Me.NumericUpDown_AutoWidth, "NumericUpDown_AutoWidth")
        Me.NumericUpDown_AutoWidth.Maximum = New Decimal(New Integer() {6576, 0, 0, 0})
        Me.NumericUpDown_AutoWidth.Name = "NumericUpDown_AutoWidth"
        Me.NumericUpDown_AutoWidth.Value = New Decimal(New Integer() {15, 0, 0, 0})
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'CheckBox_ShowBlock
        '
        resources.ApplyResources(Me.CheckBox_ShowBlock, "CheckBox_ShowBlock")
        Me.CheckBox_ShowBlock.Name = "CheckBox_ShowBlock"
        Me.CheckBox_ShowBlock.UseVisualStyleBackColor = True
        '
        'Button_AddBlockSetting
        '
        resources.ApplyResources(Me.Button_AddBlockSetting, "Button_AddBlockSetting")
        Me.Button_AddBlockSetting.Name = "Button_AddBlockSetting"
        '
        'ComboBox_SelectBlock
        '
        resources.ApplyResources(Me.ComboBox_SelectBlock, "ComboBox_SelectBlock")
        Me.ComboBox_SelectBlock.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_SelectBlock.Items.AddRange(New Object() {resources.GetString("ComboBox_SelectBlock.Items"), resources.GetString("ComboBox_SelectBlock.Items1")})
        Me.ComboBox_SelectBlock.Name = "ComboBox_SelectBlock"
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'NumericUpDown_BlockBlackTH
        '
        resources.ApplyResources(Me.NumericUpDown_BlockBlackTH, "NumericUpDown_BlockBlackTH")
        Me.NumericUpDown_BlockBlackTH.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockBlackTH.Name = "NumericUpDown_BlockBlackTH"
        Me.NumericUpDown_BlockBlackTH.Value = New Decimal(New Integer() {65535, 0, 0, 0})
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'NumericUpDown_BlockWhiteTH
        '
        resources.ApplyResources(Me.NumericUpDown_BlockWhiteTH, "NumericUpDown_BlockWhiteTH")
        Me.NumericUpDown_BlockWhiteTH.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockWhiteTH.Name = "NumericUpDown_BlockWhiteTH"
        Me.NumericUpDown_BlockWhiteTH.Value = New Decimal(New Integer() {65535, 0, 0, 0})
        '
        'NumericUpDown_BlockTop
        '
        resources.ApplyResources(Me.NumericUpDown_BlockTop, "NumericUpDown_BlockTop")
        Me.NumericUpDown_BlockTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockTop.Name = "NumericUpDown_BlockTop"
        '
        'NumericUpDown_BlockRight
        '
        resources.ApplyResources(Me.NumericUpDown_BlockRight, "NumericUpDown_BlockRight")
        Me.NumericUpDown_BlockRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockRight.Name = "NumericUpDown_BlockRight"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'NumericUpDown_BlockButtom
        '
        resources.ApplyResources(Me.NumericUpDown_BlockButtom, "NumericUpDown_BlockButtom")
        Me.NumericUpDown_BlockButtom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockButtom.Name = "NumericUpDown_BlockButtom"
        '
        'NumericUpDown_BlockLeft
        '
        resources.ApplyResources(Me.NumericUpDown_BlockLeft, "NumericUpDown_BlockLeft")
        Me.NumericUpDown_BlockLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlockLeft.Name = "NumericUpDown_BlockLeft"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'ContextMenuStrip_BlockSetting
        '
        resources.ApplyResources(Me.ContextMenuStrip_BlockSetting, "ContextMenuStrip_BlockSetting")
        Me.ContextMenuStrip_BlockSetting.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DeleteToolStripMenuItem})
        Me.ContextMenuStrip_BlockSetting.Name = "ContextMenuStrip_BlockSetting"
        '
        'DeleteToolStripMenuItem
        '
        resources.ApplyResources(Me.DeleteToolStripMenuItem, "DeleteToolStripMenuItem")
        Me.DeleteToolStripMenuItem.Name = "DeleteToolStripMenuItem"
        '
        'GroupBox4
        '
        resources.ApplyResources(Me.GroupBox4, "GroupBox4")
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_VValue)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_HValue)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_VValue_BlackTH)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_HValue_WhiteTH)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_VValue_WhiteTH)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_HValue_BlackTH)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.TabStop = False
        '
        'Label18
        '
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        '
        'NumericUpDown_VValue
        '
        resources.ApplyResources(Me.NumericUpDown_VValue, "NumericUpDown_VValue")
        Me.NumericUpDown_VValue.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_VValue.Name = "NumericUpDown_VValue"
        '
        'NumericUpDown_HValue
        '
        resources.ApplyResources(Me.NumericUpDown_HValue, "NumericUpDown_HValue")
        Me.NumericUpDown_HValue.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_HValue.Name = "NumericUpDown_HValue"
        '
        'NumericUpDown_VValue_BlackTH
        '
        resources.ApplyResources(Me.NumericUpDown_VValue_BlackTH, "NumericUpDown_VValue_BlackTH")
        Me.NumericUpDown_VValue_BlackTH.Maximum = New Decimal(New Integer() {9999, 0, 0, 0})
        Me.NumericUpDown_VValue_BlackTH.Name = "NumericUpDown_VValue_BlackTH"
        '
        'NumericUpDown_HValue_WhiteTH
        '
        resources.ApplyResources(Me.NumericUpDown_HValue_WhiteTH, "NumericUpDown_HValue_WhiteTH")
        Me.NumericUpDown_HValue_WhiteTH.Maximum = New Decimal(New Integer() {9999, 0, 0, 0})
        Me.NumericUpDown_HValue_WhiteTH.Name = "NumericUpDown_HValue_WhiteTH"
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'NumericUpDown_VValue_WhiteTH
        '
        resources.ApplyResources(Me.NumericUpDown_VValue_WhiteTH, "NumericUpDown_VValue_WhiteTH")
        Me.NumericUpDown_VValue_WhiteTH.Maximum = New Decimal(New Integer() {9999, 0, 0, 0})
        Me.NumericUpDown_VValue_WhiteTH.Name = "NumericUpDown_VValue_WhiteTH"
        '
        'Label16
        '
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        '
        'NumericUpDown_HValue_BlackTH
        '
        resources.ApplyResources(Me.NumericUpDown_HValue_BlackTH, "NumericUpDown_HValue_BlackTH")
        Me.NumericUpDown_HValue_BlackTH.Maximum = New Decimal(New Integer() {9999, 0, 0, 0})
        Me.NumericUpDown_HValue_BlackTH.Name = "NumericUpDown_HValue_BlackTH"
        '
        'Label17
        '
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        '
        'CheckBox_BandUseRemoveHV
        '
        resources.ApplyResources(Me.CheckBox_BandUseRemoveHV, "CheckBox_BandUseRemoveHV")
        Me.CheckBox_BandUseRemoveHV.Name = "CheckBox_BandUseRemoveHV"
        '
        'GroupBox6
        '
        resources.ApplyResources(Me.GroupBox6, "GroupBox6")
        Me.GroupBox6.Controls.Add(Me.CheckBox_EnableBandLeakPoint)
        Me.GroupBox6.Controls.Add(Me.Label25)
        Me.GroupBox6.Controls.Add(Me.NumericUpDown_BandLeakPointFilterRadius)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.TabStop = False
        '
        'CheckBox_EnableBandLeakPoint
        '
        resources.ApplyResources(Me.CheckBox_EnableBandLeakPoint, "CheckBox_EnableBandLeakPoint")
        Me.CheckBox_EnableBandLeakPoint.Name = "CheckBox_EnableBandLeakPoint"
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        '
        'NumericUpDown_BandLeakPointFilterRadius
        '
        resources.ApplyResources(Me.NumericUpDown_BandLeakPointFilterRadius, "NumericUpDown_BandLeakPointFilterRadius")
        Me.NumericUpDown_BandLeakPointFilterRadius.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BandLeakPointFilterRadius.Name = "NumericUpDown_BandLeakPointFilterRadius"
        '
        'GroupBox5
        '
        resources.ApplyResources(Me.GroupBox5, "GroupBox5")
        Me.GroupBox5.Controls.Add(Me.NumericUpDown_BandVOpenEdgeStrength)
        Me.GroupBox5.Controls.Add(Me.Label19)
        Me.GroupBox5.Controls.Add(Me.CheckBox_EnableBandVOpen)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.TabStop = False
        '
        'NumericUpDown_BandVOpenEdgeStrength
        '
        resources.ApplyResources(Me.NumericUpDown_BandVOpenEdgeStrength, "NumericUpDown_BandVOpenEdgeStrength")
        Me.NumericUpDown_BandVOpenEdgeStrength.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.NumericUpDown_BandVOpenEdgeStrength.Name = "NumericUpDown_BandVOpenEdgeStrength"
        Me.NumericUpDown_BandVOpenEdgeStrength.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Label19
        '
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.Name = "Label19"
        '
        'CheckBox_EnableBandVOpen
        '
        resources.ApplyResources(Me.CheckBox_EnableBandVOpen, "CheckBox_EnableBandVOpen")
        Me.CheckBox_EnableBandVOpen.Name = "CheckBox_EnableBandVOpen"
        '
        'Dialog_BandMura
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.CheckBox_BandUseRemoveHV)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.ComboBox_Result)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CheckBox_Band)
        Me.Controls.Add(Me.CheckBox_Result)
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.Button_Band)
        Me.Controls.Add(Me.Button_Ok)
        Me.Controls.Add(Me.GroupBox_Parameter)
        Me.Controls.Add(Me.GroupBox_Modify)
        Me.Controls.Add(Me.Button_Load)
        Me.Controls.Add(Me.Label_Select)
        Me.Controls.Add(Me.ComboBox_Select)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_BandMura"
        Me.ShowInTaskbar = False
        CType(Me.NumericUpDown_WhiteHBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteVBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Parameter.ResumeLayout(False)
        Me.GroupBox_Parameter.PerformLayout()
        CType(Me.NumericUpDown_BlackVBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlackHBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BandMura_SmoothCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BandMura_ResizeCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Modify.ResumeLayout(False)
        Me.GroupBox_V.ResumeLayout(False)
        Me.GroupBox_V.PerformLayout()
        CType(Me.NumericUpDown_VTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VBottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VLeft, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_H.ResumeLayout(False)
        Me.GroupBox_H.PerformLayout()
        CType(Me.NumericUpDown_HRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.NumericUpDown_AutoWidth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockBlackTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockWhiteTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockButtom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlockLeft, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip_BlockSetting.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.NumericUpDown_VValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VValue_BlackTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HValue_WhiteTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VValue_WhiteTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HValue_BlackTH, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.NumericUpDown_BandLeakPointFilterRadius, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.NumericUpDown_BandVOpenEdgeStrength, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents NumericUpDown_WhiteHBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_WhiteVBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackBand_Thrshold As System.Windows.Forms.Label
    Friend WithEvents Button_Band As System.Windows.Forms.Button
    Friend WithEvents Button_Ok As System.Windows.Forms.Button
    Friend WithEvents Label_HBand_Thrshold As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Parameter As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Modify As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_Show As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_V As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_VRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Right As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Left As System.Windows.Forms.Label
    Friend WithEvents RadioButton_Manual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Finish As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_H As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_HTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Bottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Top As System.Windows.Forms.Label
    Friend WithEvents Button_Load As System.Windows.Forms.Button
    Friend WithEvents Label_Select As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Select As System.Windows.Forms.ComboBox
    Friend WithEvents Label_Band_ResizeCount As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BandMura_ResizeCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Band_SmoothCount As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BandMura_SmoothCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackHBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackVBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Show As System.Windows.Forms.ComboBox
    Friend WithEvents NumericUpDown_VTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Result As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_Result As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Band As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ListView_VBlock As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents ListView_HBlock As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button_AddBlockSetting As System.Windows.Forms.Button
    Friend WithEvents ComboBox_SelectBlock As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlockBlackTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlockWhiteTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlockTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlockRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlockButtom As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlockLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ContextMenuStrip_BlockSetting As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents DeleteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckBox_ShowBlock As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_AutoWidth As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_HValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_VValue_BlackTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_HValue_WhiteTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VValue_WhiteTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HValue_BlackTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_BandUseRemoveHV As System.Windows.Forms.CheckBox
    Friend WithEvents Button_HBottomBase As System.Windows.Forms.Button
    Friend WithEvents TextBox_VHCount As System.Windows.Forms.TextBox
    Friend WithEvents Button_VLeftBase As System.Windows.Forms.Button
    Friend WithEvents TextBox_VVCount As System.Windows.Forms.TextBox
    Friend WithEvents Button_VRightBase As System.Windows.Forms.Button
    Friend WithEvents Button_VTopBase As System.Windows.Forms.Button
    Friend WithEvents Button_VBottomBase As System.Windows.Forms.Button
    Friend WithEvents TextBox_HHCount As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_HVCount As System.Windows.Forms.TextBox
    Friend WithEvents Button_HLeftBase As System.Windows.Forms.Button
    Friend WithEvents Button_HTopBase As System.Windows.Forms.Button
    Friend WithEvents Button_HRightBase As System.Windows.Forms.Button
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_EnableBandLeakPoint As System.Windows.Forms.CheckBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BandLeakPointFilterRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BandVOpenEdgeStrength As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_EnableBandVOpen As System.Windows.Forms.CheckBox
End Class
