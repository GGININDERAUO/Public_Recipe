<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraBoundary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_MuraBoundary))
        Me.Label_BoundaryLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryBottom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BoundaryLeft = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BoundaryRight = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Boundary = New System.Windows.Forms.GroupBox()
        Me.Label_BoundaryRight = New System.Windows.Forms.Label()
        Me.Label_BoundaryTop = New System.Windows.Forms.Label()
        Me.Button_Grab = New System.Windows.Forms.Button()
        Me.Label_Select = New System.Windows.Forms.Label()
        Me.ComboBox_Select = New System.Windows.Forms.ComboBox()
        Me.GroupBox_Grab = New System.Windows.Forms.GroupBox()
        Me.ComboBox_PatnList = New System.Windows.Forms.ComboBox()
        Me.Button_Load = New System.Windows.Forms.Button()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_Ok = New System.Windows.Forms.Button()
        Me.RadioButton_BoundaryFinish = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_ResultRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_ResultRight = New System.Windows.Forms.Label()
        Me.GroupBox_Result = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_ResultLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_ResultLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_ResultTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_ResultBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_ResultBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_ResultTop = New System.Windows.Forms.Label()
        Me.RadioButton_ResultFinish = New System.Windows.Forms.RadioButton()
        Me.CheckBox_ShowResult = New System.Windows.Forms.CheckBox()
        Me.GroupBox_ResultModify = New System.Windows.Forms.GroupBox()
        Me.RadioButton_ResultManual = New System.Windows.Forms.RadioButton()
        Me.CheckBox_ShowBoundary = New System.Windows.Forms.CheckBox()
        Me.Button_Split = New System.Windows.Forms.Button()
        Me.Button_Calculate = New System.Windows.Forms.Button()
        Me.GroupBox_BoundaryModify = New System.Windows.Forms.GroupBox()
        Me.RadioButton_BoundaryManual = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown_DefocusCount = New System.Windows.Forms.NumericUpDown()
        Me.BtnNext_MuraBoundary = New System.Windows.Forms.Button()
        Me.CheckBox_Cal = New System.Windows.Forms.CheckBox()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Boundary.SuspendLayout()
        Me.GroupBox_Grab.SuspendLayout()
        CType(Me.NumericUpDown_ResultRight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Result.SuspendLayout()
        CType(Me.NumericUpDown_ResultLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ResultTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ResultBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ResultModify.SuspendLayout()
        Me.GroupBox_BoundaryModify.SuspendLayout()
        CType(Me.NumericUpDown_DefocusCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label_BoundaryLeft
        '
        resources.ApplyResources(Me.Label_BoundaryLeft, "Label_BoundaryLeft")
        Me.Label_BoundaryLeft.Name = "Label_BoundaryLeft"
        '
        'NumericUpDown_BoundaryTop
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryTop, "NumericUpDown_BoundaryTop")
        Me.NumericUpDown_BoundaryTop.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown_BoundaryTop.Name = "NumericUpDown_BoundaryTop"
        '
        'Label_BoundaryBottom
        '
        resources.ApplyResources(Me.Label_BoundaryBottom, "Label_BoundaryBottom")
        Me.Label_BoundaryBottom.Name = "Label_BoundaryBottom"
        '
        'NumericUpDown_BoundaryBottom
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryBottom, "NumericUpDown_BoundaryBottom")
        Me.NumericUpDown_BoundaryBottom.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryBottom.Name = "NumericUpDown_BoundaryBottom"
        '
        'NumericUpDown_BoundaryLeft
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryLeft, "NumericUpDown_BoundaryLeft")
        Me.NumericUpDown_BoundaryLeft.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown_BoundaryLeft.Name = "NumericUpDown_BoundaryLeft"
        '
        'NumericUpDown_BoundaryRight
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryRight, "NumericUpDown_BoundaryRight")
        Me.NumericUpDown_BoundaryRight.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryRight.Name = "NumericUpDown_BoundaryRight"
        '
        'GroupBox_Boundary
        '
        resources.ApplyResources(Me.GroupBox_Boundary, "GroupBox_Boundary")
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryTop)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryTop)
        Me.GroupBox_Boundary.Name = "GroupBox_Boundary"
        Me.GroupBox_Boundary.TabStop = False
        '
        'Label_BoundaryRight
        '
        resources.ApplyResources(Me.Label_BoundaryRight, "Label_BoundaryRight")
        Me.Label_BoundaryRight.Name = "Label_BoundaryRight"
        '
        'Label_BoundaryTop
        '
        resources.ApplyResources(Me.Label_BoundaryTop, "Label_BoundaryTop")
        Me.Label_BoundaryTop.Name = "Label_BoundaryTop"
        '
        'Button_Grab
        '
        resources.ApplyResources(Me.Button_Grab, "Button_Grab")
        Me.Button_Grab.Name = "Button_Grab"
        '
        'Label_Select
        '
        resources.ApplyResources(Me.Label_Select, "Label_Select")
        Me.Label_Select.Name = "Label_Select"
        '
        'ComboBox_Select
        '
        resources.ApplyResources(Me.ComboBox_Select, "ComboBox_Select")
        Me.ComboBox_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Select.Name = "ComboBox_Select"
        '
        'GroupBox_Grab
        '
        resources.ApplyResources(Me.GroupBox_Grab, "GroupBox_Grab")
        Me.GroupBox_Grab.Controls.Add(Me.Button_Grab)
        Me.GroupBox_Grab.Name = "GroupBox_Grab"
        Me.GroupBox_Grab.TabStop = False
        '
        'ComboBox_PatnList
        '
        resources.ApplyResources(Me.ComboBox_PatnList, "ComboBox_PatnList")
        Me.ComboBox_PatnList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PatnList.FormattingEnabled = True
        Me.ComboBox_PatnList.Name = "ComboBox_PatnList"
        '
        'Button_Load
        '
        resources.ApplyResources(Me.Button_Load, "Button_Load")
        Me.Button_Load.Name = "Button_Load"
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        '
        'Button_Ok
        '
        resources.ApplyResources(Me.Button_Ok, "Button_Ok")
        Me.Button_Ok.Name = "Button_Ok"
        '
        'RadioButton_BoundaryFinish
        '
        resources.ApplyResources(Me.RadioButton_BoundaryFinish, "RadioButton_BoundaryFinish")
        Me.RadioButton_BoundaryFinish.Name = "RadioButton_BoundaryFinish"
        '
        'NumericUpDown_ResultRight
        '
        resources.ApplyResources(Me.NumericUpDown_ResultRight, "NumericUpDown_ResultRight")
        Me.NumericUpDown_ResultRight.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_ResultRight.Name = "NumericUpDown_ResultRight"
        '
        'Label_ResultRight
        '
        resources.ApplyResources(Me.Label_ResultRight, "Label_ResultRight")
        Me.Label_ResultRight.Name = "Label_ResultRight"
        '
        'GroupBox_Result
        '
        resources.ApplyResources(Me.GroupBox_Result, "GroupBox_Result")
        Me.GroupBox_Result.Controls.Add(Me.NumericUpDown_ResultRight)
        Me.GroupBox_Result.Controls.Add(Me.Label_ResultRight)
        Me.GroupBox_Result.Controls.Add(Me.NumericUpDown_ResultLeft)
        Me.GroupBox_Result.Controls.Add(Me.Label_ResultLeft)
        Me.GroupBox_Result.Controls.Add(Me.NumericUpDown_ResultTop)
        Me.GroupBox_Result.Controls.Add(Me.Label_ResultBottom)
        Me.GroupBox_Result.Controls.Add(Me.NumericUpDown_ResultBottom)
        Me.GroupBox_Result.Controls.Add(Me.Label_ResultTop)
        Me.GroupBox_Result.Name = "GroupBox_Result"
        Me.GroupBox_Result.TabStop = False
        '
        'NumericUpDown_ResultLeft
        '
        resources.ApplyResources(Me.NumericUpDown_ResultLeft, "NumericUpDown_ResultLeft")
        Me.NumericUpDown_ResultLeft.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_ResultLeft.Name = "NumericUpDown_ResultLeft"
        '
        'Label_ResultLeft
        '
        resources.ApplyResources(Me.Label_ResultLeft, "Label_ResultLeft")
        Me.Label_ResultLeft.Name = "Label_ResultLeft"
        '
        'NumericUpDown_ResultTop
        '
        resources.ApplyResources(Me.NumericUpDown_ResultTop, "NumericUpDown_ResultTop")
        Me.NumericUpDown_ResultTop.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_ResultTop.Name = "NumericUpDown_ResultTop"
        '
        'Label_ResultBottom
        '
        resources.ApplyResources(Me.Label_ResultBottom, "Label_ResultBottom")
        Me.Label_ResultBottom.Name = "Label_ResultBottom"
        '
        'NumericUpDown_ResultBottom
        '
        resources.ApplyResources(Me.NumericUpDown_ResultBottom, "NumericUpDown_ResultBottom")
        Me.NumericUpDown_ResultBottom.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_ResultBottom.Name = "NumericUpDown_ResultBottom"
        '
        'Label_ResultTop
        '
        resources.ApplyResources(Me.Label_ResultTop, "Label_ResultTop")
        Me.Label_ResultTop.Name = "Label_ResultTop"
        '
        'RadioButton_ResultFinish
        '
        resources.ApplyResources(Me.RadioButton_ResultFinish, "RadioButton_ResultFinish")
        Me.RadioButton_ResultFinish.Name = "RadioButton_ResultFinish"
        '
        'CheckBox_ShowResult
        '
        resources.ApplyResources(Me.CheckBox_ShowResult, "CheckBox_ShowResult")
        Me.CheckBox_ShowResult.Name = "CheckBox_ShowResult"
        '
        'GroupBox_ResultModify
        '
        resources.ApplyResources(Me.GroupBox_ResultModify, "GroupBox_ResultModify")
        Me.GroupBox_ResultModify.Controls.Add(Me.CheckBox_ShowResult)
        Me.GroupBox_ResultModify.Controls.Add(Me.RadioButton_ResultManual)
        Me.GroupBox_ResultModify.Controls.Add(Me.RadioButton_ResultFinish)
        Me.GroupBox_ResultModify.Controls.Add(Me.GroupBox_Result)
        Me.GroupBox_ResultModify.Name = "GroupBox_ResultModify"
        Me.GroupBox_ResultModify.TabStop = False
        '
        'RadioButton_ResultManual
        '
        resources.ApplyResources(Me.RadioButton_ResultManual, "RadioButton_ResultManual")
        Me.RadioButton_ResultManual.Name = "RadioButton_ResultManual"
        '
        'CheckBox_ShowBoundary
        '
        resources.ApplyResources(Me.CheckBox_ShowBoundary, "CheckBox_ShowBoundary")
        Me.CheckBox_ShowBoundary.Name = "CheckBox_ShowBoundary"
        '
        'Button_Split
        '
        resources.ApplyResources(Me.Button_Split, "Button_Split")
        Me.Button_Split.Name = "Button_Split"
        '
        'Button_Calculate
        '
        resources.ApplyResources(Me.Button_Calculate, "Button_Calculate")
        Me.Button_Calculate.Name = "Button_Calculate"
        '
        'GroupBox_BoundaryModify
        '
        resources.ApplyResources(Me.GroupBox_BoundaryModify, "GroupBox_BoundaryModify")
        Me.GroupBox_BoundaryModify.Controls.Add(Me.CheckBox_ShowBoundary)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryManual)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryFinish)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.GroupBox_Boundary)
        Me.GroupBox_BoundaryModify.Name = "GroupBox_BoundaryModify"
        Me.GroupBox_BoundaryModify.TabStop = False
        '
        'RadioButton_BoundaryManual
        '
        resources.ApplyResources(Me.RadioButton_BoundaryManual, "RadioButton_BoundaryManual")
        Me.RadioButton_BoundaryManual.Name = "RadioButton_BoundaryManual"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'NumericUpDown_DefocusCount
        '
        resources.ApplyResources(Me.NumericUpDown_DefocusCount, "NumericUpDown_DefocusCount")
        Me.NumericUpDown_DefocusCount.Name = "NumericUpDown_DefocusCount"
        Me.NumericUpDown_DefocusCount.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'BtnNext_MuraBoundary
        '
        resources.ApplyResources(Me.BtnNext_MuraBoundary, "BtnNext_MuraBoundary")
        Me.BtnNext_MuraBoundary.Name = "BtnNext_MuraBoundary"
        Me.BtnNext_MuraBoundary.UseVisualStyleBackColor = True
        '
        'CheckBox_Cal
        '
        resources.ApplyResources(Me.CheckBox_Cal, "CheckBox_Cal")
        Me.CheckBox_Cal.Name = "CheckBox_Cal"
        Me.CheckBox_Cal.UseVisualStyleBackColor = True
        '
        'Dialog_MuraBoundary
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.CheckBox_Cal)
        Me.Controls.Add(Me.ComboBox_PatnList)
        Me.Controls.Add(Me.BtnNext_MuraBoundary)
        Me.Controls.Add(Me.Button_Load)
        Me.Controls.Add(Me.NumericUpDown_DefocusCount)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label_Select)
        Me.Controls.Add(Me.ComboBox_Select)
        Me.Controls.Add(Me.GroupBox_Grab)
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.Button_Ok)
        Me.Controls.Add(Me.GroupBox_ResultModify)
        Me.Controls.Add(Me.Button_Split)
        Me.Controls.Add(Me.Button_Calculate)
        Me.Controls.Add(Me.GroupBox_BoundaryModify)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraBoundary"
        Me.ShowInTaskbar = False
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Boundary.ResumeLayout(False)
        Me.GroupBox_Grab.ResumeLayout(False)
        CType(Me.NumericUpDown_ResultRight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Result.ResumeLayout(False)
        CType(Me.NumericUpDown_ResultLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ResultTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ResultBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_ResultModify.ResumeLayout(False)
        Me.GroupBox_BoundaryModify.ResumeLayout(False)
        CType(Me.NumericUpDown_DefocusCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label_BoundaryLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BoundaryLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BoundaryRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_Boundary As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BoundaryRight As System.Windows.Forms.Label
    Friend WithEvents Label_BoundaryTop As System.Windows.Forms.Label
    Friend WithEvents Button_Grab As System.Windows.Forms.Button
    Friend WithEvents Label_Select As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Select As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_Grab As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Button_Ok As System.Windows.Forms.Button
    Friend WithEvents Button_Load As System.Windows.Forms.Button
    Friend WithEvents RadioButton_BoundaryFinish As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_ResultRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_ResultRight As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Result As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_ResultLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_ResultLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ResultTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_ResultBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ResultBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_ResultTop As System.Windows.Forms.Label
    Friend WithEvents RadioButton_ResultFinish As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_ShowResult As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_ResultModify As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_ResultManual As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_ShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Split As System.Windows.Forms.Button
    Friend WithEvents Button_Calculate As System.Windows.Forms.Button
    Friend WithEvents GroupBox_BoundaryModify As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BoundaryManual As System.Windows.Forms.RadioButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_DefocusCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents BtnNext_MuraBoundary As System.Windows.Forms.Button
    Friend WithEvents ComboBox_PatnList As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_Cal As System.Windows.Forms.CheckBox
End Class
