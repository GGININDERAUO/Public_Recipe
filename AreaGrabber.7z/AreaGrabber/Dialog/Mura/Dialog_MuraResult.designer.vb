<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraResult
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_MuraResult))
        Me.ColumnHeader_BandX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandRank = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandMinData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandGate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandJND = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandArea = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CheckBox_ShowBand = New System.Windows.Forms.CheckBox()
        Me.CheckBox_ShowBlob = New System.Windows.Forms.CheckBox()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_Ok = New System.Windows.Forms.Button()
        Me.ColumnHeader_BandMaxData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandMinGate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Score = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandMaxGate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BlobJND = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BlobArea = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_X = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BlobRank = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BlobType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ListView_Blob = New System.Windows.Forms.ListView()
        Me.ColumnHeader_BlobData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BlobGate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Y = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MinData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MinGate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MaxData = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MaxGate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BlobScore = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Elongation = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_GrayMin = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_GrayMax = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Fullness = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Compactness = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MinFeretAngle = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MaxGray_Fullness = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_StdDev = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Fatness = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Breadth = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_CPD = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_BandType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ListView_Band = New System.Windows.Forms.ListView()
        Me.ColumnHeader_BandWidth = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Strength = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox_MuraResult = New System.Windows.Forms.GroupBox()
        Me.LblCount_BlackHBand = New System.Windows.Forms.Label()
        Me.LblCount_WhiteHBand = New System.Windows.Forms.Label()
        Me.LblCount_BlackVBand = New System.Windows.Forms.Label()
        Me.LblCount_WhiteVBand = New System.Windows.Forms.Label()
        Me.LblCount_BlackBlobMuraArrayRim = New System.Windows.Forms.Label()
        Me.LblCount_BlackMacroMuraArrayArea = New System.Windows.Forms.Label()
        Me.LblCount_BlackBlobMuraArrayArea = New System.Windows.Forms.Label()
        Me.LblCount_WhiteBlobMuraArrayRim = New System.Windows.Forms.Label()
        Me.LblCount_WhiteMacroMuraArrayArea = New System.Windows.Forms.Label()
        Me.LblCount_WhiteBlobMuraArrayArea = New System.Windows.Forms.Label()
        Me.LblColor_BlackHBand = New System.Windows.Forms.Label()
        Me.LblColor_WhiteHBand = New System.Windows.Forms.Label()
        Me.LblColor_BlackVBand = New System.Windows.Forms.Label()
        Me.LblColor_WhiteVBand = New System.Windows.Forms.Label()
        Me.LblColor_BlackBlobMuraArrayRim = New System.Windows.Forms.Label()
        Me.LblColor_BlackMacroMuraArrayArea = New System.Windows.Forms.Label()
        Me.LblColor_BlackBlobMuraArrayArea = New System.Windows.Forms.Label()
        Me.LblColor_WhiteBlobMuraArrayRim = New System.Windows.Forms.Label()
        Me.LblColor_WhiteMacroMuraArrayArea = New System.Windows.Forms.Label()
        Me.LblColor_WhiteBlobMuraArrayArea = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox_MuraResult.SuspendLayout()
        Me.SuspendLayout()
        '
        'ColumnHeader_BandX
        '
        resources.ApplyResources(Me.ColumnHeader_BandX, "ColumnHeader_BandX")
        '
        'ColumnHeader_BandRank
        '
        resources.ApplyResources(Me.ColumnHeader_BandRank, "ColumnHeader_BandRank")
        '
        'ColumnHeader_BandMinData
        '
        resources.ApplyResources(Me.ColumnHeader_BandMinData, "ColumnHeader_BandMinData")
        '
        'ColumnHeader_BandY
        '
        resources.ApplyResources(Me.ColumnHeader_BandY, "ColumnHeader_BandY")
        '
        'ColumnHeader_BandGate
        '
        resources.ApplyResources(Me.ColumnHeader_BandGate, "ColumnHeader_BandGate")
        '
        'ColumnHeader_BandData
        '
        resources.ApplyResources(Me.ColumnHeader_BandData, "ColumnHeader_BandData")
        '
        'ColumnHeader_BandJND
        '
        resources.ApplyResources(Me.ColumnHeader_BandJND, "ColumnHeader_BandJND")
        '
        'ColumnHeader_BandArea
        '
        resources.ApplyResources(Me.ColumnHeader_BandArea, "ColumnHeader_BandArea")
        '
        'CheckBox_ShowBand
        '
        resources.ApplyResources(Me.CheckBox_ShowBand, "CheckBox_ShowBand")
        Me.CheckBox_ShowBand.Name = "CheckBox_ShowBand"
        '
        'CheckBox_ShowBlob
        '
        resources.ApplyResources(Me.CheckBox_ShowBlob, "CheckBox_ShowBlob")
        Me.CheckBox_ShowBlob.Name = "CheckBox_ShowBlob"
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        '
        'Button_Ok
        '
        resources.ApplyResources(Me.Button_Ok, "Button_Ok")
        Me.Button_Ok.Name = "Button_Ok"
        '
        'ColumnHeader_BandMaxData
        '
        resources.ApplyResources(Me.ColumnHeader_BandMaxData, "ColumnHeader_BandMaxData")
        '
        'ColumnHeader_BandMinGate
        '
        resources.ApplyResources(Me.ColumnHeader_BandMinGate, "ColumnHeader_BandMinGate")
        '
        'ColumnHeader_Score
        '
        resources.ApplyResources(Me.ColumnHeader_Score, "ColumnHeader_Score")
        '
        'ColumnHeader_BandMaxGate
        '
        resources.ApplyResources(Me.ColumnHeader_BandMaxGate, "ColumnHeader_BandMaxGate")
        '
        'ColumnHeader_BlobJND
        '
        resources.ApplyResources(Me.ColumnHeader_BlobJND, "ColumnHeader_BlobJND")
        '
        'ColumnHeader_BlobArea
        '
        resources.ApplyResources(Me.ColumnHeader_BlobArea, "ColumnHeader_BlobArea")
        '
        'ColumnHeader_X
        '
        resources.ApplyResources(Me.ColumnHeader_X, "ColumnHeader_X")
        '
        'ColumnHeader_BlobRank
        '
        resources.ApplyResources(Me.ColumnHeader_BlobRank, "ColumnHeader_BlobRank")
        '
        'ColumnHeader_BlobType
        '
        resources.ApplyResources(Me.ColumnHeader_BlobType, "ColumnHeader_BlobType")
        '
        'ListView_Blob
        '
        resources.ApplyResources(Me.ListView_Blob, "ListView_Blob")
        Me.ListView_Blob.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_BlobType, Me.ColumnHeader_BlobData, Me.ColumnHeader_BlobGate, Me.ColumnHeader_BlobArea, Me.ColumnHeader_BlobJND, Me.ColumnHeader_BlobRank, Me.ColumnHeader_X, Me.ColumnHeader_Y, Me.ColumnHeader_MinData, Me.ColumnHeader_MinGate, Me.ColumnHeader_MaxData, Me.ColumnHeader_MaxGate, Me.ColumnHeader_BlobScore, Me.ColumnHeader_Elongation, Me.ColumnHeader_Pattern, Me.ColumnHeader_GrayMin, Me.ColumnHeader_GrayMax, Me.ColumnHeader_Fullness, Me.ColumnHeader_Compactness, Me.ColumnHeader_MinFeretAngle, Me.ColumnHeader_MaxGray_Fullness, Me.ColumnHeader_StdDev, Me.ColumnHeader_Fatness, Me.ColumnHeader_Breadth, Me.ColumnHeader_CPD})
        Me.ListView_Blob.FullRowSelect = True
        Me.ListView_Blob.GridLines = True
        Me.ListView_Blob.HideSelection = False
        Me.ListView_Blob.MultiSelect = False
        Me.ListView_Blob.Name = "ListView_Blob"
        Me.ListView_Blob.UseCompatibleStateImageBehavior = False
        Me.ListView_Blob.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_BlobData
        '
        resources.ApplyResources(Me.ColumnHeader_BlobData, "ColumnHeader_BlobData")
        '
        'ColumnHeader_BlobGate
        '
        resources.ApplyResources(Me.ColumnHeader_BlobGate, "ColumnHeader_BlobGate")
        '
        'ColumnHeader_Y
        '
        resources.ApplyResources(Me.ColumnHeader_Y, "ColumnHeader_Y")
        '
        'ColumnHeader_MinData
        '
        resources.ApplyResources(Me.ColumnHeader_MinData, "ColumnHeader_MinData")
        '
        'ColumnHeader_MinGate
        '
        resources.ApplyResources(Me.ColumnHeader_MinGate, "ColumnHeader_MinGate")
        '
        'ColumnHeader_MaxData
        '
        resources.ApplyResources(Me.ColumnHeader_MaxData, "ColumnHeader_MaxData")
        '
        'ColumnHeader_MaxGate
        '
        resources.ApplyResources(Me.ColumnHeader_MaxGate, "ColumnHeader_MaxGate")
        '
        'ColumnHeader_BlobScore
        '
        resources.ApplyResources(Me.ColumnHeader_BlobScore, "ColumnHeader_BlobScore")
        '
        'ColumnHeader_Elongation
        '
        resources.ApplyResources(Me.ColumnHeader_Elongation, "ColumnHeader_Elongation")
        '
        'ColumnHeader_Pattern
        '
        resources.ApplyResources(Me.ColumnHeader_Pattern, "ColumnHeader_Pattern")
        '
        'ColumnHeader_GrayMin
        '
        resources.ApplyResources(Me.ColumnHeader_GrayMin, "ColumnHeader_GrayMin")
        '
        'ColumnHeader_GrayMax
        '
        resources.ApplyResources(Me.ColumnHeader_GrayMax, "ColumnHeader_GrayMax")
        '
        'ColumnHeader_Fullness
        '
        resources.ApplyResources(Me.ColumnHeader_Fullness, "ColumnHeader_Fullness")
        '
        'ColumnHeader_Compactness
        '
        resources.ApplyResources(Me.ColumnHeader_Compactness, "ColumnHeader_Compactness")
        '
        'ColumnHeader_MinFeretAngle
        '
        resources.ApplyResources(Me.ColumnHeader_MinFeretAngle, "ColumnHeader_MinFeretAngle")
        '
        'ColumnHeader_MaxGray_Fullness
        '
        resources.ApplyResources(Me.ColumnHeader_MaxGray_Fullness, "ColumnHeader_MaxGray_Fullness")
        '
        'ColumnHeader_StdDev
        '
        resources.ApplyResources(Me.ColumnHeader_StdDev, "ColumnHeader_StdDev")
        '
        'ColumnHeader_Fatness
        '
        resources.ApplyResources(Me.ColumnHeader_Fatness, "ColumnHeader_Fatness")
        '
        'ColumnHeader_Breadth
        '
        resources.ApplyResources(Me.ColumnHeader_Breadth, "ColumnHeader_Breadth")
        '
        'ColumnHeader_CPD
        '
        resources.ApplyResources(Me.ColumnHeader_CPD, "ColumnHeader_CPD")
        '
        'ColumnHeader_BandType
        '
        resources.ApplyResources(Me.ColumnHeader_BandType, "ColumnHeader_BandType")
        '
        'ListView_Band
        '
        resources.ApplyResources(Me.ListView_Band, "ListView_Band")
        Me.ListView_Band.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_BandType, Me.ColumnHeader_BandData, Me.ColumnHeader_BandGate, Me.ColumnHeader_BandArea, Me.ColumnHeader_BandJND, Me.ColumnHeader_BandRank, Me.ColumnHeader_BandX, Me.ColumnHeader_BandY, Me.ColumnHeader_BandMinData, Me.ColumnHeader_BandMinGate, Me.ColumnHeader_BandMaxData, Me.ColumnHeader_BandMaxGate, Me.ColumnHeader_Score, Me.ColumnHeader_BandWidth, Me.ColumnHeader_Strength})
        Me.ListView_Band.FullRowSelect = True
        Me.ListView_Band.GridLines = True
        Me.ListView_Band.HideSelection = False
        Me.ListView_Band.Name = "ListView_Band"
        Me.ListView_Band.UseCompatibleStateImageBehavior = False
        Me.ListView_Band.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_BandWidth
        '
        resources.ApplyResources(Me.ColumnHeader_BandWidth, "ColumnHeader_BandWidth")
        '
        'ColumnHeader_Strength
        '
        resources.ApplyResources(Me.ColumnHeader_Strength, "ColumnHeader_Strength")
        '
        'GroupBox_MuraResult
        '
        resources.ApplyResources(Me.GroupBox_MuraResult, "GroupBox_MuraResult")
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_BlackHBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_WhiteHBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_BlackVBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_WhiteVBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_BlackBlobMuraArrayRim)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_BlackMacroMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_BlackBlobMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_WhiteBlobMuraArrayRim)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_WhiteMacroMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblCount_WhiteBlobMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_BlackHBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_WhiteHBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_BlackVBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_WhiteVBand)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_BlackBlobMuraArrayRim)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_BlackMacroMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_BlackBlobMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_WhiteBlobMuraArrayRim)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_WhiteMacroMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.LblColor_WhiteBlobMuraArrayArea)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label10)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label9)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label8)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label7)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label6)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label5)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label4)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label3)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label2)
        Me.GroupBox_MuraResult.Controls.Add(Me.Label1)
        Me.GroupBox_MuraResult.Name = "GroupBox_MuraResult"
        Me.GroupBox_MuraResult.TabStop = False
        '
        'LblCount_BlackHBand
        '
        resources.ApplyResources(Me.LblCount_BlackHBand, "LblCount_BlackHBand")
        Me.LblCount_BlackHBand.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_BlackHBand.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_BlackHBand.Name = "LblCount_BlackHBand"
        '
        'LblCount_WhiteHBand
        '
        resources.ApplyResources(Me.LblCount_WhiteHBand, "LblCount_WhiteHBand")
        Me.LblCount_WhiteHBand.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_WhiteHBand.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_WhiteHBand.Name = "LblCount_WhiteHBand"
        '
        'LblCount_BlackVBand
        '
        resources.ApplyResources(Me.LblCount_BlackVBand, "LblCount_BlackVBand")
        Me.LblCount_BlackVBand.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_BlackVBand.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_BlackVBand.Name = "LblCount_BlackVBand"
        '
        'LblCount_WhiteVBand
        '
        resources.ApplyResources(Me.LblCount_WhiteVBand, "LblCount_WhiteVBand")
        Me.LblCount_WhiteVBand.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_WhiteVBand.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_WhiteVBand.Name = "LblCount_WhiteVBand"
        '
        'LblCount_BlackBlobMuraArrayRim
        '
        resources.ApplyResources(Me.LblCount_BlackBlobMuraArrayRim, "LblCount_BlackBlobMuraArrayRim")
        Me.LblCount_BlackBlobMuraArrayRim.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_BlackBlobMuraArrayRim.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_BlackBlobMuraArrayRim.Name = "LblCount_BlackBlobMuraArrayRim"
        '
        'LblCount_BlackMacroMuraArrayArea
        '
        resources.ApplyResources(Me.LblCount_BlackMacroMuraArrayArea, "LblCount_BlackMacroMuraArrayArea")
        Me.LblCount_BlackMacroMuraArrayArea.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_BlackMacroMuraArrayArea.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_BlackMacroMuraArrayArea.Name = "LblCount_BlackMacroMuraArrayArea"
        '
        'LblCount_BlackBlobMuraArrayArea
        '
        resources.ApplyResources(Me.LblCount_BlackBlobMuraArrayArea, "LblCount_BlackBlobMuraArrayArea")
        Me.LblCount_BlackBlobMuraArrayArea.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_BlackBlobMuraArrayArea.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_BlackBlobMuraArrayArea.Name = "LblCount_BlackBlobMuraArrayArea"
        '
        'LblCount_WhiteBlobMuraArrayRim
        '
        resources.ApplyResources(Me.LblCount_WhiteBlobMuraArrayRim, "LblCount_WhiteBlobMuraArrayRim")
        Me.LblCount_WhiteBlobMuraArrayRim.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_WhiteBlobMuraArrayRim.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_WhiteBlobMuraArrayRim.Name = "LblCount_WhiteBlobMuraArrayRim"
        '
        'LblCount_WhiteMacroMuraArrayArea
        '
        resources.ApplyResources(Me.LblCount_WhiteMacroMuraArrayArea, "LblCount_WhiteMacroMuraArrayArea")
        Me.LblCount_WhiteMacroMuraArrayArea.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_WhiteMacroMuraArrayArea.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_WhiteMacroMuraArrayArea.Name = "LblCount_WhiteMacroMuraArrayArea"
        '
        'LblCount_WhiteBlobMuraArrayArea
        '
        resources.ApplyResources(Me.LblCount_WhiteBlobMuraArrayArea, "LblCount_WhiteBlobMuraArrayArea")
        Me.LblCount_WhiteBlobMuraArrayArea.BackColor = System.Drawing.Color.FloralWhite
        Me.LblCount_WhiteBlobMuraArrayArea.ForeColor = System.Drawing.Color.Blue
        Me.LblCount_WhiteBlobMuraArrayArea.Name = "LblCount_WhiteBlobMuraArrayArea"
        '
        'LblColor_BlackHBand
        '
        resources.ApplyResources(Me.LblColor_BlackHBand, "LblColor_BlackHBand")
        Me.LblColor_BlackHBand.BackColor = System.Drawing.Color.Gold
        Me.LblColor_BlackHBand.Name = "LblColor_BlackHBand"
        '
        'LblColor_WhiteHBand
        '
        resources.ApplyResources(Me.LblColor_WhiteHBand, "LblColor_WhiteHBand")
        Me.LblColor_WhiteHBand.BackColor = System.Drawing.Color.Gold
        Me.LblColor_WhiteHBand.Name = "LblColor_WhiteHBand"
        '
        'LblColor_BlackVBand
        '
        resources.ApplyResources(Me.LblColor_BlackVBand, "LblColor_BlackVBand")
        Me.LblColor_BlackVBand.BackColor = System.Drawing.Color.Gold
        Me.LblColor_BlackVBand.ForeColor = System.Drawing.Color.Black
        Me.LblColor_BlackVBand.Name = "LblColor_BlackVBand"
        '
        'LblColor_WhiteVBand
        '
        resources.ApplyResources(Me.LblColor_WhiteVBand, "LblColor_WhiteVBand")
        Me.LblColor_WhiteVBand.BackColor = System.Drawing.Color.Gold
        Me.LblColor_WhiteVBand.Name = "LblColor_WhiteVBand"
        '
        'LblColor_BlackBlobMuraArrayRim
        '
        resources.ApplyResources(Me.LblColor_BlackBlobMuraArrayRim, "LblColor_BlackBlobMuraArrayRim")
        Me.LblColor_BlackBlobMuraArrayRim.BackColor = System.Drawing.Color.Gold
        Me.LblColor_BlackBlobMuraArrayRim.Name = "LblColor_BlackBlobMuraArrayRim"
        '
        'LblColor_BlackMacroMuraArrayArea
        '
        resources.ApplyResources(Me.LblColor_BlackMacroMuraArrayArea, "LblColor_BlackMacroMuraArrayArea")
        Me.LblColor_BlackMacroMuraArrayArea.BackColor = System.Drawing.Color.Gold
        Me.LblColor_BlackMacroMuraArrayArea.ForeColor = System.Drawing.Color.Black
        Me.LblColor_BlackMacroMuraArrayArea.Name = "LblColor_BlackMacroMuraArrayArea"
        '
        'LblColor_BlackBlobMuraArrayArea
        '
        resources.ApplyResources(Me.LblColor_BlackBlobMuraArrayArea, "LblColor_BlackBlobMuraArrayArea")
        Me.LblColor_BlackBlobMuraArrayArea.BackColor = System.Drawing.Color.Gold
        Me.LblColor_BlackBlobMuraArrayArea.Name = "LblColor_BlackBlobMuraArrayArea"
        '
        'LblColor_WhiteBlobMuraArrayRim
        '
        resources.ApplyResources(Me.LblColor_WhiteBlobMuraArrayRim, "LblColor_WhiteBlobMuraArrayRim")
        Me.LblColor_WhiteBlobMuraArrayRim.BackColor = System.Drawing.Color.Gold
        Me.LblColor_WhiteBlobMuraArrayRim.Name = "LblColor_WhiteBlobMuraArrayRim"
        '
        'LblColor_WhiteMacroMuraArrayArea
        '
        resources.ApplyResources(Me.LblColor_WhiteMacroMuraArrayArea, "LblColor_WhiteMacroMuraArrayArea")
        Me.LblColor_WhiteMacroMuraArrayArea.BackColor = System.Drawing.Color.Gold
        Me.LblColor_WhiteMacroMuraArrayArea.ForeColor = System.Drawing.Color.Black
        Me.LblColor_WhiteMacroMuraArrayArea.Name = "LblColor_WhiteMacroMuraArrayArea"
        '
        'LblColor_WhiteBlobMuraArrayArea
        '
        resources.ApplyResources(Me.LblColor_WhiteBlobMuraArrayArea, "LblColor_WhiteBlobMuraArrayArea")
        Me.LblColor_WhiteBlobMuraArrayArea.BackColor = System.Drawing.Color.Gold
        Me.LblColor_WhiteBlobMuraArrayArea.Name = "LblColor_WhiteBlobMuraArrayArea"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Dialog_MuraResult
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GroupBox_MuraResult)
        Me.Controls.Add(Me.CheckBox_ShowBand)
        Me.Controls.Add(Me.CheckBox_ShowBlob)
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.Button_Ok)
        Me.Controls.Add(Me.ListView_Blob)
        Me.Controls.Add(Me.ListView_Band)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraResult"
        Me.ShowInTaskbar = False
        Me.GroupBox_MuraResult.ResumeLayout(False)
        Me.GroupBox_MuraResult.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ColumnHeader_BandX As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandRank As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandMinData As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandY As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandGate As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandData As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandJND As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandArea As System.Windows.Forms.ColumnHeader
    Friend WithEvents CheckBox_ShowBand As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_ShowBlob As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Button_Ok As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader_BandMaxData As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandMinGate As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Score As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandMaxGate As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BlobJND As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BlobArea As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_X As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BlobRank As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BlobType As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView_Blob As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_BlobData As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BlobGate As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Y As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MinData As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MinGate As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MaxData As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MaxGate As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BlobScore As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_BandType As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView_Band As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Elongation As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox_MuraResult As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents LblColor_WhiteBlobMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblColor_WhiteMacroMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblColor_WhiteBlobMuraArrayRim As System.Windows.Forms.Label
    Friend WithEvents LblColor_BlackBlobMuraArrayRim As System.Windows.Forms.Label
    Friend WithEvents LblColor_BlackMacroMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblColor_BlackBlobMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblColor_BlackHBand As System.Windows.Forms.Label
    Friend WithEvents LblColor_WhiteHBand As System.Windows.Forms.Label
    Friend WithEvents LblColor_BlackVBand As System.Windows.Forms.Label
    Friend WithEvents LblColor_WhiteVBand As System.Windows.Forms.Label
    Friend WithEvents LblCount_WhiteBlobMuraArrayRim As System.Windows.Forms.Label
    Friend WithEvents LblCount_WhiteMacroMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblCount_WhiteBlobMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblCount_BlackBlobMuraArrayRim As System.Windows.Forms.Label
    Friend WithEvents LblCount_BlackMacroMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblCount_BlackBlobMuraArrayArea As System.Windows.Forms.Label
    Friend WithEvents LblCount_BlackHBand As System.Windows.Forms.Label
    Friend WithEvents LblCount_WhiteHBand As System.Windows.Forms.Label
    Friend WithEvents LblCount_BlackVBand As System.Windows.Forms.Label
    Friend WithEvents LblCount_WhiteVBand As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader_BandWidth As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_GrayMin As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_GrayMax As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Fullness As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Compactness As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MinFeretAngle As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MaxGray_Fullness As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_StdDev As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Fatness As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Breadth As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_CPD As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Strength As System.Windows.Forms.ColumnHeader
End Class
