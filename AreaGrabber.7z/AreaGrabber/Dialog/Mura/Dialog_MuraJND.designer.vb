﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraJND
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CheckBox_AutoAddFalse = New System.Windows.Forms.CheckBox()
        Me.NUD_WhiteBlobMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteBlob_AreaMin = New System.Windows.Forms.Label()
        Me.Label_WhiteBlobMura_JND = New System.Windows.Forms.Label()
        Me.NUD_WhiteBlobMura_JNDMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_Select = New System.Windows.Forms.Label()
        Me.ComboBox_Select = New System.Windows.Forms.ComboBox()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_Ok = New System.Windows.Forms.Button()
        Me.Button_JND = New System.Windows.Forms.Button()
        Me.Button_LoadChild = New System.Windows.Forms.Button()
        Me.NUD_WhiteBlobMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteBlob_AreaMax = New System.Windows.Forms.Label()
        Me.GroupBox_JNDSetting = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.NumericUpDown13 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown14 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown15 = New System.Windows.Forms.NumericUpDown()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.NumericUpDown16 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown17 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown18 = New System.Windows.Forms.NumericUpDown()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.NUD_BlackGapMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackGapMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackGapMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NumericUpDown7 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown8 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown9 = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.NumericUpDown10 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown11 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown12 = New System.Windows.Forms.NumericUpDown()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NUD_BlackCPD_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackCPD_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackCPD_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.NUD_WhiteGapMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteGapMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteGapMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NUD_WhiteCPD_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteCPD_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteCPD_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CheckBox_SaveMuraDefectsImgs = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FilterFalseCPD = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FilterMura = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BlackBandJND = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackBandMura_WidthMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackBandMura_WidthMin = New System.Windows.Forms.Label()
        Me.Label_BlackBandMura_JND = New System.Windows.Forms.Label()
        Me.Labell_BlackBandMura_SJND = New System.Windows.Forms.Label()
        Me.NUD_BlackBandMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBandMura_SJND = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_BlackAGM = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackAGM_JNDMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackAGM_ElongationMax = New System.Windows.Forms.NumericUpDown()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label_BlackAGM_AreaMin = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.NUD_BlackAGM_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackAGM_ElongationMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackAGM_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.NUD_BlackAGM_JNDMin = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label_BlackMacroMura_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_BlackMacroMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackMacroMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackMacroMura_AreaMax = New System.Windows.Forms.Label()
        Me.Label_BlackMacroMura_JND = New System.Windows.Forms.Label()
        Me.NUD_BlackMacroMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_BlackBlobJND = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackBlobMura_ElongationMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_JNDMax = New System.Windows.Forms.NumericUpDown()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label_BlackBlob_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_BlackBlobMura_ElongationMin = New System.Windows.Forms.NumericUpDown()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.NUD_BlackBlobMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_JNDMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackBlob_AreaMax = New System.Windows.Forms.Label()
        Me.Label_BlackBlobMura_JND = New System.Windows.Forms.Label()
        Me.GroupBox_WhiteBandJND = New System.Windows.Forms.GroupBox()
        Me.NUD_WhiteBandMura_WidthMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteBandMura_WidthMin = New System.Windows.Forms.Label()
        Me.Label_WhiteBandMura_JND = New System.Windows.Forms.Label()
        Me.Labell_WhiteBandMura_SJND = New System.Windows.Forms.Label()
        Me.NUD_WhiteBandMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBandMura_SJND = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_WhiteAGM = New System.Windows.Forms.GroupBox()
        Me.NUD_WhiteAGM_JNDMax = New System.Windows.Forms.NumericUpDown()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.NUD_WhiteAGM_ElongationMax = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteAGM_AreaMin = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.NUD_WhiteAGM_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteAGM_ElongationMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteAGM_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.NUD_WhiteAGM_JNDMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_AGM_WhiteAreaMax = New System.Windows.Forms.Label()
        Me.Label_WhiteAGM_JND = New System.Windows.Forms.Label()
        Me.GroupBox_WhiteMacroJND = New System.Windows.Forms.GroupBox()
        Me.Label_WhiteMacroMura_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_WhiteMacroMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteMacroMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteMacroMura_AreaMax = New System.Windows.Forms.Label()
        Me.Label_WhiteMacroMura_JND = New System.Windows.Forms.Label()
        Me.NUD_WhiteMacroMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_WhiteBlobJND = New System.Windows.Forms.GroupBox()
        Me.NUD_WhiteBlobMura_ElongationMax = New System.Windows.Forms.NumericUpDown()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.NUD_WhiteBlobMura_ElongationMin = New System.Windows.Forms.NumericUpDown()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.NUD_WhiteBlobMura_JNDMax = New System.Windows.Forms.NumericUpDown()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.ComboBox_PatternList = New System.Windows.Forms.ComboBox()
        CType(Me.NUD_WhiteBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_JNDMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_JNDSetting.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        CType(Me.NumericUpDown13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackGapMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackGapMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackGapMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackCPD_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackCPD_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackCPD_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.NUD_WhiteGapMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteGapMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteGapMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.NUD_WhiteCPD_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteCPD_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteCPD_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BlackBandJND.SuspendLayout()
        CType(Me.NUD_BlackBandMura_WidthMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBandMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBandMura_SJND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BlackAGM.SuspendLayout()
        CType(Me.NUD_BlackAGM_JNDMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_ElongationMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_ElongationMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_JNDMin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NUD_BlackMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackMacroMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BlackBlobJND.SuspendLayout()
        CType(Me.NUD_BlackBlobMura_ElongationMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_JNDMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_ElongationMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_JNDMin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WhiteBandJND.SuspendLayout()
        CType(Me.NUD_WhiteBandMura_WidthMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBandMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBandMura_SJND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WhiteAGM.SuspendLayout()
        CType(Me.NUD_WhiteAGM_JNDMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_ElongationMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_ElongationMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_JNDMin, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WhiteMacroJND.SuspendLayout()
        CType(Me.NUD_WhiteMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteMacroMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WhiteBlobJND.SuspendLayout()
        CType(Me.NUD_WhiteBlobMura_ElongationMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_ElongationMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_JNDMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CheckBox_AutoAddFalse
        '
        Me.CheckBox_AutoAddFalse.Location = New System.Drawing.Point(708, 562)
        Me.CheckBox_AutoAddFalse.Margin = New System.Windows.Forms.Padding(4)
        Me.CheckBox_AutoAddFalse.Name = "CheckBox_AutoAddFalse"
        Me.CheckBox_AutoAddFalse.Size = New System.Drawing.Size(175, 30)
        Me.CheckBox_AutoAddFalse.TabIndex = 74
        Me.CheckBox_AutoAddFalse.Text = "自动加入False Defect"
        '
        'NUD_WhiteBlobMura_AreaMin
        '
        Me.NUD_WhiteBlobMura_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_WhiteBlobMura_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBlobMura_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_AreaMin.Name = "NUD_WhiteBlobMura_AreaMin"
        Me.NUD_WhiteBlobMura_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBlobMura_AreaMin.TabIndex = 72
        Me.NUD_WhiteBlobMura_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_WhiteBlob_AreaMin
        '
        Me.Label_WhiteBlob_AreaMin.Location = New System.Drawing.Point(8, 22)
        Me.Label_WhiteBlob_AreaMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteBlob_AreaMin.Name = "Label_WhiteBlob_AreaMin"
        Me.Label_WhiteBlob_AreaMin.Size = New System.Drawing.Size(175, 29)
        Me.Label_WhiteBlob_AreaMin.TabIndex = 70
        Me.Label_WhiteBlob_AreaMin.Text = "过滤Blob Mura面积Min :"
        Me.Label_WhiteBlob_AreaMin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_WhiteBlobMura_JND
        '
        Me.Label_WhiteBlobMura_JND.Location = New System.Drawing.Point(7, 88)
        Me.Label_WhiteBlobMura_JND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteBlobMura_JND.Name = "Label_WhiteBlobMura_JND"
        Me.Label_WhiteBlobMura_JND.Size = New System.Drawing.Size(175, 29)
        Me.Label_WhiteBlobMura_JND.TabIndex = 69
        Me.Label_WhiteBlobMura_JND.Text = "过滤Blob Mura JND Min :"
        Me.Label_WhiteBlobMura_JND.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteBlobMura_JNDMin
        '
        Me.NUD_WhiteBlobMura_JNDMin.DecimalPlaces = 2
        Me.NUD_WhiteBlobMura_JNDMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBlobMura_JNDMin.Location = New System.Drawing.Point(195, 88)
        Me.NUD_WhiteBlobMura_JNDMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBlobMura_JNDMin.Name = "NUD_WhiteBlobMura_JNDMin"
        Me.NUD_WhiteBlobMura_JNDMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBlobMura_JNDMin.TabIndex = 71
        Me.NUD_WhiteBlobMura_JNDMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_Select
        '
        Me.Label_Select.Location = New System.Drawing.Point(16, 11)
        Me.Label_Select.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_Select.Name = "Label_Select"
        Me.Label_Select.Size = New System.Drawing.Size(85, 29)
        Me.Label_Select.TabIndex = 67
        Me.Label_Select.Text = "显示影像："
        Me.Label_Select.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ComboBox_Select
        '
        Me.ComboBox_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Select.Location = New System.Drawing.Point(101, 12)
        Me.ComboBox_Select.Margin = New System.Windows.Forms.Padding(4)
        Me.ComboBox_Select.Name = "ComboBox_Select"
        Me.ComboBox_Select.Size = New System.Drawing.Size(169, 23)
        Me.ComboBox_Select.TabIndex = 68
        '
        'Button_Cancel
        '
        Me.Button_Cancel.Location = New System.Drawing.Point(1220, 562)
        Me.Button_Cancel.Margin = New System.Windows.Forms.Padding(4)
        Me.Button_Cancel.Name = "Button_Cancel"
        Me.Button_Cancel.Size = New System.Drawing.Size(81, 29)
        Me.Button_Cancel.TabIndex = 66
        Me.Button_Cancel.Text = "关闭"
        '
        'Button_Ok
        '
        Me.Button_Ok.Location = New System.Drawing.Point(1129, 564)
        Me.Button_Ok.Margin = New System.Windows.Forms.Padding(4)
        Me.Button_Ok.Name = "Button_Ok"
        Me.Button_Ok.Size = New System.Drawing.Size(81, 29)
        Me.Button_Ok.TabIndex = 65
        Me.Button_Ok.Text = "储存"
        '
        'Button_JND
        '
        Me.Button_JND.Location = New System.Drawing.Point(11, 561)
        Me.Button_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.Button_JND.Name = "Button_JND"
        Me.Button_JND.Size = New System.Drawing.Size(201, 30)
        Me.Button_JND.TabIndex = 64
        Me.Button_JND.Text = "计算Mura JND值"
        '
        'Button_LoadChild
        '
        Me.Button_LoadChild.Location = New System.Drawing.Point(515, 15)
        Me.Button_LoadChild.Margin = New System.Windows.Forms.Padding(4)
        Me.Button_LoadChild.Name = "Button_LoadChild"
        Me.Button_LoadChild.Size = New System.Drawing.Size(163, 30)
        Me.Button_LoadChild.TabIndex = 63
        Me.Button_LoadChild.Text = "手动载入图档"
        '
        'NUD_WhiteBlobMura_AreaMax
        '
        Me.NUD_WhiteBlobMura_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_WhiteBlobMura_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBlobMura_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_AreaMax.Name = "NUD_WhiteBlobMura_AreaMax"
        Me.NUD_WhiteBlobMura_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBlobMura_AreaMax.TabIndex = 83
        Me.NUD_WhiteBlobMura_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_WhiteBlob_AreaMax
        '
        Me.Label_WhiteBlob_AreaMax.AutoSize = True
        Me.Label_WhiteBlob_AreaMax.Location = New System.Drawing.Point(8, 62)
        Me.Label_WhiteBlob_AreaMax.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteBlob_AreaMax.Name = "Label_WhiteBlob_AreaMax"
        Me.Label_WhiteBlob_AreaMax.Size = New System.Drawing.Size(163, 15)
        Me.Label_WhiteBlob_AreaMax.TabIndex = 84
        Me.Label_WhiteBlob_AreaMax.Text = "过滤Blob Mura面积Max :"
        '
        'GroupBox_JNDSetting
        '
        Me.GroupBox_JNDSetting.Controls.Add(Me.CheckBox_AutoAddFalse)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox6)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox1)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox9)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox3)
        Me.GroupBox_JNDSetting.Controls.Add(Me.CheckBox_SaveMuraDefectsImgs)
        Me.GroupBox_JNDSetting.Controls.Add(Me.CheckBox_FilterFalseCPD)
        Me.GroupBox_JNDSetting.Controls.Add(Me.Button_Cancel)
        Me.GroupBox_JNDSetting.Controls.Add(Me.CheckBox_FilterMura)
        Me.GroupBox_JNDSetting.Controls.Add(Me.Button_Ok)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox_BlackBandJND)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox_BlackAGM)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox2)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox_BlackBlobJND)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox_WhiteBandJND)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox_WhiteAGM)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox_WhiteMacroJND)
        Me.GroupBox_JNDSetting.Controls.Add(Me.GroupBox_WhiteBlobJND)
        Me.GroupBox_JNDSetting.Controls.Add(Me.Button_JND)
        Me.GroupBox_JNDSetting.Location = New System.Drawing.Point(11, 74)
        Me.GroupBox_JNDSetting.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_JNDSetting.Name = "GroupBox_JNDSetting"
        Me.GroupBox_JNDSetting.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_JNDSetting.Size = New System.Drawing.Size(1317, 601)
        Me.GroupBox_JNDSetting.TabIndex = 85
        Me.GroupBox_JNDSetting.TabStop = False
        Me.GroupBox_JNDSetting.Text = "JND设定"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.GroupBox7)
        Me.GroupBox6.Controls.Add(Me.GroupBox8)
        Me.GroupBox6.Controls.Add(Me.Label21)
        Me.GroupBox6.Controls.Add(Me.NUD_BlackGapMura_AreaMin)
        Me.GroupBox6.Controls.Add(Me.NUD_BlackGapMura_AreaMax)
        Me.GroupBox6.Controls.Add(Me.NUD_BlackGapMura_JND)
        Me.GroupBox6.Controls.Add(Me.Label22)
        Me.GroupBox6.Controls.Add(Me.Label23)
        Me.GroupBox6.Location = New System.Drawing.Point(985, 156)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox6.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox6.TabIndex = 99
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Black Gap Mura"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Label15)
        Me.GroupBox7.Controls.Add(Me.NumericUpDown13)
        Me.GroupBox7.Controls.Add(Me.NumericUpDown14)
        Me.GroupBox7.Controls.Add(Me.NumericUpDown15)
        Me.GroupBox7.Controls.Add(Me.Label16)
        Me.GroupBox7.Controls.Add(Me.Label17)
        Me.GroupBox7.Location = New System.Drawing.Point(3, 139)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox7.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox7.TabIndex = 99
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Black Blob Mura"
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(8, 22)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(175, 29)
        Me.Label15.TabIndex = 70
        Me.Label15.Text = "過濾Blob Mura面積Min :"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown13
        '
        Me.NumericUpDown13.Location = New System.Drawing.Point(195, 22)
        Me.NumericUpDown13.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown13.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NumericUpDown13.Name = "NumericUpDown13"
        Me.NumericUpDown13.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown13.TabIndex = 72
        Me.NumericUpDown13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown14
        '
        Me.NumericUpDown14.Location = New System.Drawing.Point(195, 55)
        Me.NumericUpDown14.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown14.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown14.Name = "NumericUpDown14"
        Me.NumericUpDown14.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown14.TabIndex = 83
        Me.NumericUpDown14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown15
        '
        Me.NumericUpDown15.DecimalPlaces = 2
        Me.NumericUpDown15.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown15.Location = New System.Drawing.Point(195, 88)
        Me.NumericUpDown15.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown15.Name = "NumericUpDown15"
        Me.NumericUpDown15.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown15.TabIndex = 71
        Me.NumericUpDown15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(8, 62)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(163, 15)
        Me.Label16.TabIndex = 84
        Me.Label16.Text = "過濾Blob Mura面積Max :"
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(7, 88)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(175, 29)
        Me.Label17.TabIndex = 69
        Me.Label17.Text = "過濾Blob Mura JND值 :"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label18)
        Me.GroupBox8.Controls.Add(Me.NumericUpDown16)
        Me.GroupBox8.Controls.Add(Me.NumericUpDown17)
        Me.GroupBox8.Controls.Add(Me.NumericUpDown18)
        Me.GroupBox8.Controls.Add(Me.Label19)
        Me.GroupBox8.Controls.Add(Me.Label20)
        Me.GroupBox8.Location = New System.Drawing.Point(-321, 139)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox8.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox8.TabIndex = 98
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "White Blob Mura"
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(8, 22)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(175, 29)
        Me.Label18.TabIndex = 70
        Me.Label18.Text = "過濾Blob Mura面積Min :"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown16
        '
        Me.NumericUpDown16.Location = New System.Drawing.Point(195, 22)
        Me.NumericUpDown16.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown16.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NumericUpDown16.Name = "NumericUpDown16"
        Me.NumericUpDown16.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown16.TabIndex = 72
        Me.NumericUpDown16.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown17
        '
        Me.NumericUpDown17.Location = New System.Drawing.Point(195, 55)
        Me.NumericUpDown17.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown17.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown17.Name = "NumericUpDown17"
        Me.NumericUpDown17.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown17.TabIndex = 83
        Me.NumericUpDown17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown18
        '
        Me.NumericUpDown18.DecimalPlaces = 2
        Me.NumericUpDown18.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown18.Location = New System.Drawing.Point(195, 88)
        Me.NumericUpDown18.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown18.Name = "NumericUpDown18"
        Me.NumericUpDown18.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown18.TabIndex = 71
        Me.NumericUpDown18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(8, 62)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(163, 15)
        Me.Label19.TabIndex = 84
        Me.Label19.Text = "過濾Blob Mura面積Max :"
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(7, 88)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(175, 29)
        Me.Label20.TabIndex = 69
        Me.Label20.Text = "過濾Blob Mura JND值 :"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(8, 22)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(175, 29)
        Me.Label21.TabIndex = 70
        Me.Label21.Text = "过滤Blob Mura面积Min :"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_BlackGapMura_AreaMin
        '
        Me.NUD_BlackGapMura_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_BlackGapMura_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackGapMura_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_BlackGapMura_AreaMin.Name = "NUD_BlackGapMura_AreaMin"
        Me.NUD_BlackGapMura_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackGapMura_AreaMin.TabIndex = 72
        Me.NUD_BlackGapMura_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackGapMura_AreaMax
        '
        Me.NUD_BlackGapMura_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_BlackGapMura_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackGapMura_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_BlackGapMura_AreaMax.Name = "NUD_BlackGapMura_AreaMax"
        Me.NUD_BlackGapMura_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackGapMura_AreaMax.TabIndex = 83
        Me.NUD_BlackGapMura_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackGapMura_JND
        '
        Me.NUD_BlackGapMura_JND.DecimalPlaces = 2
        Me.NUD_BlackGapMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackGapMura_JND.Location = New System.Drawing.Point(195, 88)
        Me.NUD_BlackGapMura_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackGapMura_JND.Name = "NUD_BlackGapMura_JND"
        Me.NUD_BlackGapMura_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackGapMura_JND.TabIndex = 71
        Me.NUD_BlackGapMura_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(8, 62)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(163, 15)
        Me.Label22.TabIndex = 84
        Me.Label22.Text = "过滤Blob Mura面积Max :"
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(7, 88)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(175, 29)
        Me.Label23.TabIndex = 69
        Me.Label23.Text = "过滤Blob Mura JND值 :"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.GroupBox4)
        Me.GroupBox1.Controls.Add(Me.GroupBox5)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.NUD_BlackCPD_AreaMin)
        Me.GroupBox1.Controls.Add(Me.NUD_BlackCPD_AreaMax)
        Me.GroupBox1.Controls.Add(Me.NUD_BlackCPD_JND)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(984, 22)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox1.TabIndex = 97
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Black CPD"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Label7)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown7)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown8)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown9)
        Me.GroupBox4.Controls.Add(Me.Label10)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Location = New System.Drawing.Point(3, 139)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox4.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox4.TabIndex = 99
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Black Blob Mura"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(8, 22)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(175, 29)
        Me.Label7.TabIndex = 70
        Me.Label7.Text = "過濾Blob Mura面積Min :"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown7
        '
        Me.NumericUpDown7.Location = New System.Drawing.Point(195, 22)
        Me.NumericUpDown7.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown7.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NumericUpDown7.Name = "NumericUpDown7"
        Me.NumericUpDown7.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown7.TabIndex = 72
        Me.NumericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown8
        '
        Me.NumericUpDown8.Location = New System.Drawing.Point(195, 55)
        Me.NumericUpDown8.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown8.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown8.Name = "NumericUpDown8"
        Me.NumericUpDown8.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown8.TabIndex = 83
        Me.NumericUpDown8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown9
        '
        Me.NumericUpDown9.DecimalPlaces = 2
        Me.NumericUpDown9.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown9.Location = New System.Drawing.Point(195, 88)
        Me.NumericUpDown9.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown9.Name = "NumericUpDown9"
        Me.NumericUpDown9.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown9.TabIndex = 71
        Me.NumericUpDown9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(8, 62)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(163, 15)
        Me.Label10.TabIndex = 84
        Me.Label10.Text = "過濾Blob Mura面積Max :"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(7, 88)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(175, 29)
        Me.Label11.TabIndex = 69
        Me.Label11.Text = "過濾Blob Mura JND值 :"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Label12)
        Me.GroupBox5.Controls.Add(Me.NumericUpDown10)
        Me.GroupBox5.Controls.Add(Me.NumericUpDown11)
        Me.GroupBox5.Controls.Add(Me.NumericUpDown12)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Location = New System.Drawing.Point(-321, 139)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox5.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox5.TabIndex = 98
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "White Blob Mura"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(8, 22)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(175, 29)
        Me.Label12.TabIndex = 70
        Me.Label12.Text = "過濾Blob Mura面積Min :"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NumericUpDown10
        '
        Me.NumericUpDown10.Location = New System.Drawing.Point(195, 22)
        Me.NumericUpDown10.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown10.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NumericUpDown10.Name = "NumericUpDown10"
        Me.NumericUpDown10.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown10.TabIndex = 72
        Me.NumericUpDown10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown11
        '
        Me.NumericUpDown11.Location = New System.Drawing.Point(195, 55)
        Me.NumericUpDown11.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown11.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown11.Name = "NumericUpDown11"
        Me.NumericUpDown11.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown11.TabIndex = 83
        Me.NumericUpDown11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown12
        '
        Me.NumericUpDown12.DecimalPlaces = 2
        Me.NumericUpDown12.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown12.Location = New System.Drawing.Point(195, 88)
        Me.NumericUpDown12.Margin = New System.Windows.Forms.Padding(4)
        Me.NumericUpDown12.Name = "NumericUpDown12"
        Me.NumericUpDown12.Size = New System.Drawing.Size(109, 25)
        Me.NumericUpDown12.TabIndex = 71
        Me.NumericUpDown12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(8, 62)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(163, 15)
        Me.Label13.TabIndex = 84
        Me.Label13.Text = "過濾Blob Mura面積Max :"
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(7, 88)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(175, 29)
        Me.Label14.TabIndex = 69
        Me.Label14.Text = "過濾Blob Mura JND值 :"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 22)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(175, 29)
        Me.Label1.TabIndex = 70
        Me.Label1.Text = "过滤Blob Mura面积Min :"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_BlackCPD_AreaMin
        '
        Me.NUD_BlackCPD_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_BlackCPD_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackCPD_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_BlackCPD_AreaMin.Name = "NUD_BlackCPD_AreaMin"
        Me.NUD_BlackCPD_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackCPD_AreaMin.TabIndex = 72
        Me.NUD_BlackCPD_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackCPD_AreaMax
        '
        Me.NUD_BlackCPD_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_BlackCPD_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackCPD_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_BlackCPD_AreaMax.Name = "NUD_BlackCPD_AreaMax"
        Me.NUD_BlackCPD_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackCPD_AreaMax.TabIndex = 83
        Me.NUD_BlackCPD_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackCPD_JND
        '
        Me.NUD_BlackCPD_JND.DecimalPlaces = 2
        Me.NUD_BlackCPD_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackCPD_JND.Location = New System.Drawing.Point(195, 88)
        Me.NUD_BlackCPD_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackCPD_JND.Name = "NUD_BlackCPD_JND"
        Me.NUD_BlackCPD_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackCPD_JND.TabIndex = 71
        Me.NUD_BlackCPD_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 62)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(163, 15)
        Me.Label2.TabIndex = 84
        Me.Label2.Text = "过滤Blob Mura面积Max :"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(7, 88)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(175, 29)
        Me.Label3.TabIndex = 69
        Me.Label3.Text = "过滤Blob Mura JND值 :"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label24)
        Me.GroupBox9.Controls.Add(Me.NUD_WhiteGapMura_AreaMin)
        Me.GroupBox9.Controls.Add(Me.NUD_WhiteGapMura_AreaMax)
        Me.GroupBox9.Controls.Add(Me.NUD_WhiteGapMura_JND)
        Me.GroupBox9.Controls.Add(Me.Label25)
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Location = New System.Drawing.Point(661, 156)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox9.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox9.TabIndex = 98
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "White Gap Mura"
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(8, 22)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(175, 29)
        Me.Label24.TabIndex = 70
        Me.Label24.Text = "过滤Blob Mura面积Min :"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteGapMura_AreaMin
        '
        Me.NUD_WhiteGapMura_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_WhiteGapMura_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteGapMura_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_WhiteGapMura_AreaMin.Name = "NUD_WhiteGapMura_AreaMin"
        Me.NUD_WhiteGapMura_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteGapMura_AreaMin.TabIndex = 72
        Me.NUD_WhiteGapMura_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteGapMura_AreaMax
        '
        Me.NUD_WhiteGapMura_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_WhiteGapMura_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteGapMura_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_WhiteGapMura_AreaMax.Name = "NUD_WhiteGapMura_AreaMax"
        Me.NUD_WhiteGapMura_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteGapMura_AreaMax.TabIndex = 83
        Me.NUD_WhiteGapMura_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteGapMura_JND
        '
        Me.NUD_WhiteGapMura_JND.DecimalPlaces = 2
        Me.NUD_WhiteGapMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteGapMura_JND.Location = New System.Drawing.Point(195, 88)
        Me.NUD_WhiteGapMura_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteGapMura_JND.Name = "NUD_WhiteGapMura_JND"
        Me.NUD_WhiteGapMura_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteGapMura_JND.TabIndex = 71
        Me.NUD_WhiteGapMura_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(8, 62)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(163, 15)
        Me.Label25.TabIndex = 84
        Me.Label25.Text = "过滤Blob Mura面积Max :"
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(7, 88)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(175, 29)
        Me.Label26.TabIndex = 69
        Me.Label26.Text = "过滤Blob Mura JND值 :"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.NUD_WhiteCPD_AreaMin)
        Me.GroupBox3.Controls.Add(Me.NUD_WhiteCPD_AreaMax)
        Me.GroupBox3.Controls.Add(Me.NUD_WhiteCPD_JND)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Location = New System.Drawing.Point(660, 22)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox3.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox3.TabIndex = 96
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "White CPD"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(8, 22)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(175, 29)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "过滤Blob Mura面积Min :"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteCPD_AreaMin
        '
        Me.NUD_WhiteCPD_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_WhiteCPD_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteCPD_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_WhiteCPD_AreaMin.Name = "NUD_WhiteCPD_AreaMin"
        Me.NUD_WhiteCPD_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteCPD_AreaMin.TabIndex = 72
        Me.NUD_WhiteCPD_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteCPD_AreaMax
        '
        Me.NUD_WhiteCPD_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_WhiteCPD_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteCPD_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_WhiteCPD_AreaMax.Name = "NUD_WhiteCPD_AreaMax"
        Me.NUD_WhiteCPD_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteCPD_AreaMax.TabIndex = 83
        Me.NUD_WhiteCPD_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteCPD_JND
        '
        Me.NUD_WhiteCPD_JND.DecimalPlaces = 2
        Me.NUD_WhiteCPD_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteCPD_JND.Location = New System.Drawing.Point(195, 88)
        Me.NUD_WhiteCPD_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteCPD_JND.Name = "NUD_WhiteCPD_JND"
        Me.NUD_WhiteCPD_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteCPD_JND.TabIndex = 71
        Me.NUD_WhiteCPD_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(8, 62)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(163, 15)
        Me.Label5.TabIndex = 84
        Me.Label5.Text = "过滤Blob Mura面积Max :"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(7, 88)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(175, 29)
        Me.Label6.TabIndex = 69
        Me.Label6.Text = "过滤Blob Mura JND值 :"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CheckBox_SaveMuraDefectsImgs
        '
        Me.CheckBox_SaveMuraDefectsImgs.AutoSize = True
        Me.CheckBox_SaveMuraDefectsImgs.Location = New System.Drawing.Point(519, 568)
        Me.CheckBox_SaveMuraDefectsImgs.Margin = New System.Windows.Forms.Padding(4)
        Me.CheckBox_SaveMuraDefectsImgs.Name = "CheckBox_SaveMuraDefectsImgs"
        Me.CheckBox_SaveMuraDefectsImgs.Size = New System.Drawing.Size(141, 19)
        Me.CheckBox_SaveMuraDefectsImgs.TabIndex = 103
        Me.CheckBox_SaveMuraDefectsImgs.Text = "Save Defect Images"
        Me.CheckBox_SaveMuraDefectsImgs.UseVisualStyleBackColor = True
        '
        'CheckBox_FilterFalseCPD
        '
        Me.CheckBox_FilterFalseCPD.AutoSize = True
        Me.CheckBox_FilterFalseCPD.Location = New System.Drawing.Point(353, 568)
        Me.CheckBox_FilterFalseCPD.Margin = New System.Windows.Forms.Padding(4)
        Me.CheckBox_FilterFalseCPD.Name = "CheckBox_FilterFalseCPD"
        Me.CheckBox_FilterFalseCPD.Size = New System.Drawing.Size(124, 19)
        Me.CheckBox_FilterFalseCPD.TabIndex = 102
        Me.CheckBox_FilterFalseCPD.Text = "Filter False CPD"
        Me.CheckBox_FilterFalseCPD.UseVisualStyleBackColor = True
        '
        'CheckBox_FilterMura
        '
        Me.CheckBox_FilterMura.Location = New System.Drawing.Point(221, 562)
        Me.CheckBox_FilterMura.Margin = New System.Windows.Forms.Padding(4)
        Me.CheckBox_FilterMura.Name = "CheckBox_FilterMura"
        Me.CheckBox_FilterMura.Size = New System.Drawing.Size(107, 30)
        Me.CheckBox_FilterMura.TabIndex = 101
        Me.CheckBox_FilterMura.Text = "False Defect"
        '
        'GroupBox_BlackBandJND
        '
        Me.GroupBox_BlackBandJND.Controls.Add(Me.NUD_BlackBandMura_WidthMin)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.Label_BlackBandMura_WidthMin)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.Label_BlackBandMura_JND)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.Labell_BlackBandMura_SJND)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.NUD_BlackBandMura_JND)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.NUD_BlackBandMura_SJND)
        Me.GroupBox_BlackBandJND.Location = New System.Drawing.Point(993, 429)
        Me.GroupBox_BlackBandJND.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_BlackBandJND.Name = "GroupBox_BlackBandJND"
        Me.GroupBox_BlackBandJND.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_BlackBandJND.Size = New System.Drawing.Size(316, 128)
        Me.GroupBox_BlackBandJND.TabIndex = 100
        Me.GroupBox_BlackBandJND.TabStop = False
        Me.GroupBox_BlackBandJND.Text = "Black Band Mura"
        '
        'NUD_BlackBandMura_WidthMin
        '
        Me.NUD_BlackBandMura_WidthMin.DecimalPlaces = 2
        Me.NUD_BlackBandMura_WidthMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBandMura_WidthMin.Location = New System.Drawing.Point(195, 86)
        Me.NUD_BlackBandMura_WidthMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBandMura_WidthMin.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBandMura_WidthMin.Name = "NUD_BlackBandMura_WidthMin"
        Me.NUD_BlackBandMura_WidthMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBandMura_WidthMin.TabIndex = 90
        Me.NUD_BlackBandMura_WidthMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BlackBandMura_WidthMin
        '
        Me.Label_BlackBandMura_WidthMin.AutoSize = True
        Me.Label_BlackBandMura_WidthMin.Location = New System.Drawing.Point(8, 91)
        Me.Label_BlackBandMura_WidthMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackBandMura_WidthMin.Name = "Label_BlackBandMura_WidthMin"
        Me.Label_BlackBandMura_WidthMin.Size = New System.Drawing.Size(163, 15)
        Me.Label_BlackBandMura_WidthMin.TabIndex = 89
        Me.Label_BlackBandMura_WidthMin.Text = "过滤Band Mura宽度Min :"
        '
        'Label_BlackBandMura_JND
        '
        Me.Label_BlackBandMura_JND.AutoSize = True
        Me.Label_BlackBandMura_JND.Location = New System.Drawing.Point(8, 29)
        Me.Label_BlackBandMura_JND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackBandMura_JND.Name = "Label_BlackBandMura_JND"
        Me.Label_BlackBandMura_JND.Size = New System.Drawing.Size(149, 15)
        Me.Label_BlackBandMura_JND.TabIndex = 85
        Me.Label_BlackBandMura_JND.Text = "BandMura 过滤JND值 :"
        '
        'Labell_BlackBandMura_SJND
        '
        Me.Labell_BlackBandMura_SJND.AutoSize = True
        Me.Labell_BlackBandMura_SJND.Location = New System.Drawing.Point(8, 60)
        Me.Labell_BlackBandMura_SJND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Labell_BlackBandMura_SJND.Name = "Labell_BlackBandMura_SJND"
        Me.Labell_BlackBandMura_SJND.Size = New System.Drawing.Size(157, 15)
        Me.Labell_BlackBandMura_SJND.TabIndex = 86
        Me.Labell_BlackBandMura_SJND.Text = "BandMura S等级JND值 :"
        '
        'NUD_BlackBandMura_JND
        '
        Me.NUD_BlackBandMura_JND.DecimalPlaces = 2
        Me.NUD_BlackBandMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBandMura_JND.Location = New System.Drawing.Point(195, 21)
        Me.NUD_BlackBandMura_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBandMura_JND.Name = "NUD_BlackBandMura_JND"
        Me.NUD_BlackBandMura_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBandMura_JND.TabIndex = 87
        Me.NUD_BlackBandMura_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackBandMura_SJND
        '
        Me.NUD_BlackBandMura_SJND.DecimalPlaces = 2
        Me.NUD_BlackBandMura_SJND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBandMura_SJND.Location = New System.Drawing.Point(195, 54)
        Me.NUD_BlackBandMura_SJND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBandMura_SJND.Name = "NUD_BlackBandMura_SJND"
        Me.NUD_BlackBandMura_SJND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBandMura_SJND.TabIndex = 88
        Me.NUD_BlackBandMura_SJND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox_BlackAGM
        '
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_JNDMax)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_ElongationMax)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label38)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label_BlackAGM_AreaMin)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label35)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_AreaMin)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_ElongationMin)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_AreaMax)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label36)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_JNDMin)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label8)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label9)
        Me.GroupBox_BlackAGM.Location = New System.Drawing.Point(335, 289)
        Me.GroupBox_BlackAGM.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_BlackAGM.Name = "GroupBox_BlackAGM"
        Me.GroupBox_BlackAGM.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_BlackAGM.Size = New System.Drawing.Size(316, 254)
        Me.GroupBox_BlackAGM.TabIndex = 96
        Me.GroupBox_BlackAGM.TabStop = False
        Me.GroupBox_BlackAGM.Text = "Black Around Gap Mura"
        '
        'NUD_BlackAGM_JNDMax
        '
        Me.NUD_BlackAGM_JNDMax.DecimalPlaces = 2
        Me.NUD_BlackAGM_JNDMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackAGM_JNDMax.Location = New System.Drawing.Point(195, 119)
        Me.NUD_BlackAGM_JNDMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackAGM_JNDMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackAGM_JNDMax.Name = "NUD_BlackAGM_JNDMax"
        Me.NUD_BlackAGM_JNDMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackAGM_JNDMax.TabIndex = 102
        Me.NUD_BlackAGM_JNDMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackAGM_ElongationMax
        '
        Me.NUD_BlackAGM_ElongationMax.DecimalPlaces = 2
        Me.NUD_BlackAGM_ElongationMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackAGM_ElongationMax.Location = New System.Drawing.Point(195, 184)
        Me.NUD_BlackAGM_ElongationMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackAGM_ElongationMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackAGM_ElongationMax.Name = "NUD_BlackAGM_ElongationMax"
        Me.NUD_BlackAGM_ElongationMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackAGM_ElongationMax.TabIndex = 102
        Me.NUD_BlackAGM_ElongationMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label38
        '
        Me.Label38.Location = New System.Drawing.Point(7, 119)
        Me.Label38.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(175, 29)
        Me.Label38.TabIndex = 101
        Me.Label38.Text = "过滤AGM JND Max :"
        Me.Label38.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_BlackAGM_AreaMin
        '
        Me.Label_BlackAGM_AreaMin.Location = New System.Drawing.Point(8, 22)
        Me.Label_BlackAGM_AreaMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackAGM_AreaMin.Name = "Label_BlackAGM_AreaMin"
        Me.Label_BlackAGM_AreaMin.Size = New System.Drawing.Size(175, 29)
        Me.Label_BlackAGM_AreaMin.TabIndex = 70
        Me.Label_BlackAGM_AreaMin.Text = "过滤AGM面积Min :"
        Me.Label_BlackAGM_AreaMin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label35
        '
        Me.Label35.Location = New System.Drawing.Point(7, 184)
        Me.Label35.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(180, 29)
        Me.Label35.TabIndex = 101
        Me.Label35.Text = "Elongarion Max :"
        Me.Label35.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_BlackAGM_AreaMin
        '
        Me.NUD_BlackAGM_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_BlackAGM_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackAGM_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_BlackAGM_AreaMin.Name = "NUD_BlackAGM_AreaMin"
        Me.NUD_BlackAGM_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackAGM_AreaMin.TabIndex = 72
        Me.NUD_BlackAGM_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackAGM_ElongationMin
        '
        Me.NUD_BlackAGM_ElongationMin.DecimalPlaces = 2
        Me.NUD_BlackAGM_ElongationMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackAGM_ElongationMin.Location = New System.Drawing.Point(195, 151)
        Me.NUD_BlackAGM_ElongationMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackAGM_ElongationMin.Name = "NUD_BlackAGM_ElongationMin"
        Me.NUD_BlackAGM_ElongationMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackAGM_ElongationMin.TabIndex = 100
        Me.NUD_BlackAGM_ElongationMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackAGM_AreaMax
        '
        Me.NUD_BlackAGM_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_BlackAGM_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackAGM_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_BlackAGM_AreaMax.Name = "NUD_BlackAGM_AreaMax"
        Me.NUD_BlackAGM_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackAGM_AreaMax.TabIndex = 83
        Me.NUD_BlackAGM_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label36
        '
        Me.Label36.Location = New System.Drawing.Point(7, 151)
        Me.Label36.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(180, 29)
        Me.Label36.TabIndex = 99
        Me.Label36.Text = "Elongation Min :"
        Me.Label36.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_BlackAGM_JNDMin
        '
        Me.NUD_BlackAGM_JNDMin.DecimalPlaces = 2
        Me.NUD_BlackAGM_JNDMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackAGM_JNDMin.Location = New System.Drawing.Point(195, 88)
        Me.NUD_BlackAGM_JNDMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackAGM_JNDMin.Name = "NUD_BlackAGM_JNDMin"
        Me.NUD_BlackAGM_JNDMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackAGM_JNDMin.TabIndex = 71
        Me.NUD_BlackAGM_JNDMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(8, 62)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(134, 15)
        Me.Label8.TabIndex = 84
        Me.Label8.Text = "过滤AGM面积Max :"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(7, 88)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(175, 29)
        Me.Label9.TabIndex = 69
        Me.Label9.Text = "过滤AGM JND Min :"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label_BlackMacroMura_AreaMin)
        Me.GroupBox2.Controls.Add(Me.NUD_BlackMacroMura_AreaMin)
        Me.GroupBox2.Controls.Add(Me.NUD_BlackMacroMura_JND)
        Me.GroupBox2.Controls.Add(Me.Label_BlackMacroMura_AreaMax)
        Me.GroupBox2.Controls.Add(Me.Label_BlackMacroMura_JND)
        Me.GroupBox2.Controls.Add(Me.NUD_BlackMacroMura_AreaMax)
        Me.GroupBox2.Location = New System.Drawing.Point(988, 295)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox2.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox2.TabIndex = 99
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Black Macro Mura"
        '
        'Label_BlackMacroMura_AreaMin
        '
        Me.Label_BlackMacroMura_AreaMin.AutoSize = True
        Me.Label_BlackMacroMura_AreaMin.Location = New System.Drawing.Point(5, 26)
        Me.Label_BlackMacroMura_AreaMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackMacroMura_AreaMin.Name = "Label_BlackMacroMura_AreaMin"
        Me.Label_BlackMacroMura_AreaMin.Size = New System.Drawing.Size(171, 15)
        Me.Label_BlackMacroMura_AreaMin.TabIndex = 90
        Me.Label_BlackMacroMura_AreaMin.Text = "过滤Macro Mura面积Min :"
        '
        'NUD_BlackMacroMura_AreaMin
        '
        Me.NUD_BlackMacroMura_AreaMin.Location = New System.Drawing.Point(195, 20)
        Me.NUD_BlackMacroMura_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackMacroMura_AreaMin.Maximum = New Decimal(New Integer() {1000000000, 0, 0, 0})
        Me.NUD_BlackMacroMura_AreaMin.Name = "NUD_BlackMacroMura_AreaMin"
        Me.NUD_BlackMacroMura_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackMacroMura_AreaMin.TabIndex = 91
        Me.NUD_BlackMacroMura_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackMacroMura_JND
        '
        Me.NUD_BlackMacroMura_JND.DecimalPlaces = 2
        Me.NUD_BlackMacroMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackMacroMura_JND.Location = New System.Drawing.Point(195, 90)
        Me.NUD_BlackMacroMura_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackMacroMura_JND.Name = "NUD_BlackMacroMura_JND"
        Me.NUD_BlackMacroMura_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackMacroMura_JND.TabIndex = 95
        Me.NUD_BlackMacroMura_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BlackMacroMura_AreaMax
        '
        Me.Label_BlackMacroMura_AreaMax.AutoSize = True
        Me.Label_BlackMacroMura_AreaMax.Location = New System.Drawing.Point(5, 62)
        Me.Label_BlackMacroMura_AreaMax.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackMacroMura_AreaMax.Name = "Label_BlackMacroMura_AreaMax"
        Me.Label_BlackMacroMura_AreaMax.Size = New System.Drawing.Size(173, 15)
        Me.Label_BlackMacroMura_AreaMax.TabIndex = 92
        Me.Label_BlackMacroMura_AreaMax.Text = "过滤Macro Mura面积Max :"
        '
        'Label_BlackMacroMura_JND
        '
        Me.Label_BlackMacroMura_JND.AutoSize = True
        Me.Label_BlackMacroMura_JND.Location = New System.Drawing.Point(5, 95)
        Me.Label_BlackMacroMura_JND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackMacroMura_JND.Name = "Label_BlackMacroMura_JND"
        Me.Label_BlackMacroMura_JND.Size = New System.Drawing.Size(161, 15)
        Me.Label_BlackMacroMura_JND.TabIndex = 94
        Me.Label_BlackMacroMura_JND.Text = "过滤Macro Mura JND值 :"
        '
        'NUD_BlackMacroMura_AreaMax
        '
        Me.NUD_BlackMacroMura_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_BlackMacroMura_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackMacroMura_AreaMax.Maximum = New Decimal(New Integer() {1215752192, 23, 0, 0})
        Me.NUD_BlackMacroMura_AreaMax.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.NUD_BlackMacroMura_AreaMax.Name = "NUD_BlackMacroMura_AreaMax"
        Me.NUD_BlackMacroMura_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackMacroMura_AreaMax.TabIndex = 93
        Me.NUD_BlackMacroMura_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox_BlackBlobJND
        '
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_ElongationMax)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_JNDMax)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label31)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label_BlackBlob_AreaMin)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_ElongationMin)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label28)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label32)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_AreaMin)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_AreaMax)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_JNDMin)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label_BlackBlob_AreaMax)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label_BlackBlobMura_JND)
        Me.GroupBox_BlackBlobJND.Location = New System.Drawing.Point(335, 22)
        Me.GroupBox_BlackBlobJND.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_BlackBlobJND.Name = "GroupBox_BlackBlobJND"
        Me.GroupBox_BlackBlobJND.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_BlackBlobJND.Size = New System.Drawing.Size(316, 254)
        Me.GroupBox_BlackBlobJND.TabIndex = 95
        Me.GroupBox_BlackBlobJND.TabStop = False
        Me.GroupBox_BlackBlobJND.Text = "Black Blob Mura"
        '
        'NUD_BlackBlobMura_ElongationMax
        '
        Me.NUD_BlackBlobMura_ElongationMax.DecimalPlaces = 2
        Me.NUD_BlackBlobMura_ElongationMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBlobMura_ElongationMax.Location = New System.Drawing.Point(196, 186)
        Me.NUD_BlackBlobMura_ElongationMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBlobMura_ElongationMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackBlobMura_ElongationMax.Name = "NUD_BlackBlobMura_ElongationMax"
        Me.NUD_BlackBlobMura_ElongationMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBlobMura_ElongationMax.TabIndex = 94
        Me.NUD_BlackBlobMura_ElongationMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackBlobMura_JNDMax
        '
        Me.NUD_BlackBlobMura_JNDMax.DecimalPlaces = 2
        Me.NUD_BlackBlobMura_JNDMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBlobMura_JNDMax.Location = New System.Drawing.Point(196, 121)
        Me.NUD_BlackBlobMura_JNDMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBlobMura_JNDMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackBlobMura_JNDMax.Name = "NUD_BlackBlobMura_JNDMax"
        Me.NUD_BlackBlobMura_JNDMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBlobMura_JNDMax.TabIndex = 88
        Me.NUD_BlackBlobMura_JNDMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label31
        '
        Me.Label31.Location = New System.Drawing.Point(8, 186)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(180, 29)
        Me.Label31.TabIndex = 93
        Me.Label31.Text = "Elongarion Max :"
        Me.Label31.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_BlackBlob_AreaMin
        '
        Me.Label_BlackBlob_AreaMin.Location = New System.Drawing.Point(8, 22)
        Me.Label_BlackBlob_AreaMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackBlob_AreaMin.Name = "Label_BlackBlob_AreaMin"
        Me.Label_BlackBlob_AreaMin.Size = New System.Drawing.Size(175, 29)
        Me.Label_BlackBlob_AreaMin.TabIndex = 70
        Me.Label_BlackBlob_AreaMin.Text = "过滤Blob Mura面积Min :"
        Me.Label_BlackBlob_AreaMin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_BlackBlobMura_ElongationMin
        '
        Me.NUD_BlackBlobMura_ElongationMin.DecimalPlaces = 2
        Me.NUD_BlackBlobMura_ElongationMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBlobMura_ElongationMin.Location = New System.Drawing.Point(196, 154)
        Me.NUD_BlackBlobMura_ElongationMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBlobMura_ElongationMin.Name = "NUD_BlackBlobMura_ElongationMin"
        Me.NUD_BlackBlobMura_ElongationMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBlobMura_ElongationMin.TabIndex = 92
        Me.NUD_BlackBlobMura_ElongationMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label28
        '
        Me.Label28.Location = New System.Drawing.Point(8, 121)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(180, 29)
        Me.Label28.TabIndex = 87
        Me.Label28.Text = "过滤Blob Mura JND Max :"
        Me.Label28.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label32
        '
        Me.Label32.Location = New System.Drawing.Point(8, 154)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(180, 29)
        Me.Label32.TabIndex = 91
        Me.Label32.Text = "Elongation Min :"
        Me.Label32.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_BlackBlobMura_AreaMin
        '
        Me.NUD_BlackBlobMura_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_BlackBlobMura_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBlobMura_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_BlackBlobMura_AreaMin.Name = "NUD_BlackBlobMura_AreaMin"
        Me.NUD_BlackBlobMura_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBlobMura_AreaMin.TabIndex = 72
        Me.NUD_BlackBlobMura_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackBlobMura_AreaMax
        '
        Me.NUD_BlackBlobMura_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_BlackBlobMura_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBlobMura_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_BlackBlobMura_AreaMax.Name = "NUD_BlackBlobMura_AreaMax"
        Me.NUD_BlackBlobMura_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBlobMura_AreaMax.TabIndex = 83
        Me.NUD_BlackBlobMura_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_BlackBlobMura_JNDMin
        '
        Me.NUD_BlackBlobMura_JNDMin.DecimalPlaces = 2
        Me.NUD_BlackBlobMura_JNDMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBlobMura_JNDMin.Location = New System.Drawing.Point(195, 88)
        Me.NUD_BlackBlobMura_JNDMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_BlackBlobMura_JNDMin.Name = "NUD_BlackBlobMura_JNDMin"
        Me.NUD_BlackBlobMura_JNDMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_BlackBlobMura_JNDMin.TabIndex = 71
        Me.NUD_BlackBlobMura_JNDMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BlackBlob_AreaMax
        '
        Me.Label_BlackBlob_AreaMax.AutoSize = True
        Me.Label_BlackBlob_AreaMax.Location = New System.Drawing.Point(8, 62)
        Me.Label_BlackBlob_AreaMax.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackBlob_AreaMax.Name = "Label_BlackBlob_AreaMax"
        Me.Label_BlackBlob_AreaMax.Size = New System.Drawing.Size(163, 15)
        Me.Label_BlackBlob_AreaMax.TabIndex = 84
        Me.Label_BlackBlob_AreaMax.Text = "过滤Blob Mura面积Max :"
        '
        'Label_BlackBlobMura_JND
        '
        Me.Label_BlackBlobMura_JND.Location = New System.Drawing.Point(7, 88)
        Me.Label_BlackBlobMura_JND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_BlackBlobMura_JND.Name = "Label_BlackBlobMura_JND"
        Me.Label_BlackBlobMura_JND.Size = New System.Drawing.Size(175, 29)
        Me.Label_BlackBlobMura_JND.TabIndex = 69
        Me.Label_BlackBlobMura_JND.Text = "过滤Blob Mura JND值 :"
        Me.Label_BlackBlobMura_JND.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox_WhiteBandJND
        '
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.NUD_WhiteBandMura_WidthMin)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.Label_WhiteBandMura_WidthMin)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.Label_WhiteBandMura_JND)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.Labell_WhiteBandMura_SJND)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.NUD_WhiteBandMura_JND)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.NUD_WhiteBandMura_SJND)
        Me.GroupBox_WhiteBandJND.Location = New System.Drawing.Point(664, 429)
        Me.GroupBox_WhiteBandJND.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteBandJND.Name = "GroupBox_WhiteBandJND"
        Me.GroupBox_WhiteBandJND.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteBandJND.Size = New System.Drawing.Size(316, 128)
        Me.GroupBox_WhiteBandJND.TabIndex = 99
        Me.GroupBox_WhiteBandJND.TabStop = False
        Me.GroupBox_WhiteBandJND.Text = "White Band Mura"
        '
        'NUD_WhiteBandMura_WidthMin
        '
        Me.NUD_WhiteBandMura_WidthMin.DecimalPlaces = 2
        Me.NUD_WhiteBandMura_WidthMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBandMura_WidthMin.Location = New System.Drawing.Point(195, 86)
        Me.NUD_WhiteBandMura_WidthMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBandMura_WidthMin.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteBandMura_WidthMin.Name = "NUD_WhiteBandMura_WidthMin"
        Me.NUD_WhiteBandMura_WidthMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBandMura_WidthMin.TabIndex = 90
        Me.NUD_WhiteBandMura_WidthMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_WhiteBandMura_WidthMin
        '
        Me.Label_WhiteBandMura_WidthMin.AutoSize = True
        Me.Label_WhiteBandMura_WidthMin.Location = New System.Drawing.Point(8, 91)
        Me.Label_WhiteBandMura_WidthMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteBandMura_WidthMin.Name = "Label_WhiteBandMura_WidthMin"
        Me.Label_WhiteBandMura_WidthMin.Size = New System.Drawing.Size(163, 15)
        Me.Label_WhiteBandMura_WidthMin.TabIndex = 89
        Me.Label_WhiteBandMura_WidthMin.Text = "过滤Band Mura宽度Min :"
        '
        'Label_WhiteBandMura_JND
        '
        Me.Label_WhiteBandMura_JND.AutoSize = True
        Me.Label_WhiteBandMura_JND.Location = New System.Drawing.Point(8, 29)
        Me.Label_WhiteBandMura_JND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteBandMura_JND.Name = "Label_WhiteBandMura_JND"
        Me.Label_WhiteBandMura_JND.Size = New System.Drawing.Size(149, 15)
        Me.Label_WhiteBandMura_JND.TabIndex = 85
        Me.Label_WhiteBandMura_JND.Text = "BandMura 过滤JND值 :"
        '
        'Labell_WhiteBandMura_SJND
        '
        Me.Labell_WhiteBandMura_SJND.AutoSize = True
        Me.Labell_WhiteBandMura_SJND.Location = New System.Drawing.Point(8, 60)
        Me.Labell_WhiteBandMura_SJND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Labell_WhiteBandMura_SJND.Name = "Labell_WhiteBandMura_SJND"
        Me.Labell_WhiteBandMura_SJND.Size = New System.Drawing.Size(157, 15)
        Me.Labell_WhiteBandMura_SJND.TabIndex = 86
        Me.Labell_WhiteBandMura_SJND.Text = "BandMura S等级JND值 :"
        '
        'NUD_WhiteBandMura_JND
        '
        Me.NUD_WhiteBandMura_JND.DecimalPlaces = 2
        Me.NUD_WhiteBandMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBandMura_JND.Location = New System.Drawing.Point(195, 21)
        Me.NUD_WhiteBandMura_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBandMura_JND.Name = "NUD_WhiteBandMura_JND"
        Me.NUD_WhiteBandMura_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBandMura_JND.TabIndex = 87
        Me.NUD_WhiteBandMura_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteBandMura_SJND
        '
        Me.NUD_WhiteBandMura_SJND.DecimalPlaces = 2
        Me.NUD_WhiteBandMura_SJND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBandMura_SJND.Location = New System.Drawing.Point(195, 54)
        Me.NUD_WhiteBandMura_SJND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBandMura_SJND.Name = "NUD_WhiteBandMura_SJND"
        Me.NUD_WhiteBandMura_SJND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBandMura_SJND.TabIndex = 88
        Me.NUD_WhiteBandMura_SJND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox_WhiteAGM
        '
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_JNDMax)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label37)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_ElongationMax)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label_WhiteAGM_AreaMin)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label33)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_AreaMin)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_ElongationMin)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_AreaMax)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label34)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_JNDMin)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label_AGM_WhiteAreaMax)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label_WhiteAGM_JND)
        Me.GroupBox_WhiteAGM.Location = New System.Drawing.Point(11, 289)
        Me.GroupBox_WhiteAGM.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteAGM.Name = "GroupBox_WhiteAGM"
        Me.GroupBox_WhiteAGM.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteAGM.Size = New System.Drawing.Size(316, 254)
        Me.GroupBox_WhiteAGM.TabIndex = 95
        Me.GroupBox_WhiteAGM.TabStop = False
        Me.GroupBox_WhiteAGM.Text = "White Around Gap Mura"
        '
        'NUD_WhiteAGM_JNDMax
        '
        Me.NUD_WhiteAGM_JNDMax.DecimalPlaces = 2
        Me.NUD_WhiteAGM_JNDMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteAGM_JNDMax.Location = New System.Drawing.Point(195, 120)
        Me.NUD_WhiteAGM_JNDMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteAGM_JNDMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteAGM_JNDMax.Name = "NUD_WhiteAGM_JNDMax"
        Me.NUD_WhiteAGM_JNDMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteAGM_JNDMax.TabIndex = 100
        Me.NUD_WhiteAGM_JNDMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label37
        '
        Me.Label37.Location = New System.Drawing.Point(7, 120)
        Me.Label37.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(175, 29)
        Me.Label37.TabIndex = 99
        Me.Label37.Text = "过滤AGM JND Max :"
        Me.Label37.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteAGM_ElongationMax
        '
        Me.NUD_WhiteAGM_ElongationMax.DecimalPlaces = 2
        Me.NUD_WhiteAGM_ElongationMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteAGM_ElongationMax.Location = New System.Drawing.Point(195, 188)
        Me.NUD_WhiteAGM_ElongationMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteAGM_ElongationMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteAGM_ElongationMax.Name = "NUD_WhiteAGM_ElongationMax"
        Me.NUD_WhiteAGM_ElongationMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteAGM_ElongationMax.TabIndex = 98
        Me.NUD_WhiteAGM_ElongationMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_WhiteAGM_AreaMin
        '
        Me.Label_WhiteAGM_AreaMin.Location = New System.Drawing.Point(8, 22)
        Me.Label_WhiteAGM_AreaMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteAGM_AreaMin.Name = "Label_WhiteAGM_AreaMin"
        Me.Label_WhiteAGM_AreaMin.Size = New System.Drawing.Size(175, 29)
        Me.Label_WhiteAGM_AreaMin.TabIndex = 70
        Me.Label_WhiteAGM_AreaMin.Text = "过滤AGM面积Min :"
        Me.Label_WhiteAGM_AreaMin.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label33
        '
        Me.Label33.Location = New System.Drawing.Point(7, 188)
        Me.Label33.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(180, 29)
        Me.Label33.TabIndex = 97
        Me.Label33.Text = "Elongarion Max :"
        Me.Label33.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteAGM_AreaMin
        '
        Me.NUD_WhiteAGM_AreaMin.Location = New System.Drawing.Point(195, 22)
        Me.NUD_WhiteAGM_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteAGM_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_WhiteAGM_AreaMin.Name = "NUD_WhiteAGM_AreaMin"
        Me.NUD_WhiteAGM_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteAGM_AreaMin.TabIndex = 72
        Me.NUD_WhiteAGM_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteAGM_ElongationMin
        '
        Me.NUD_WhiteAGM_ElongationMin.DecimalPlaces = 2
        Me.NUD_WhiteAGM_ElongationMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteAGM_ElongationMin.Location = New System.Drawing.Point(195, 155)
        Me.NUD_WhiteAGM_ElongationMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteAGM_ElongationMin.Name = "NUD_WhiteAGM_ElongationMin"
        Me.NUD_WhiteAGM_ElongationMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteAGM_ElongationMin.TabIndex = 96
        Me.NUD_WhiteAGM_ElongationMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteAGM_AreaMax
        '
        Me.NUD_WhiteAGM_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_WhiteAGM_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteAGM_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_WhiteAGM_AreaMax.Name = "NUD_WhiteAGM_AreaMax"
        Me.NUD_WhiteAGM_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteAGM_AreaMax.TabIndex = 83
        Me.NUD_WhiteAGM_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label34
        '
        Me.Label34.Location = New System.Drawing.Point(7, 155)
        Me.Label34.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(180, 29)
        Me.Label34.TabIndex = 95
        Me.Label34.Text = "Elongation Min :"
        Me.Label34.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteAGM_JNDMin
        '
        Me.NUD_WhiteAGM_JNDMin.DecimalPlaces = 2
        Me.NUD_WhiteAGM_JNDMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteAGM_JNDMin.Location = New System.Drawing.Point(195, 88)
        Me.NUD_WhiteAGM_JNDMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteAGM_JNDMin.Name = "NUD_WhiteAGM_JNDMin"
        Me.NUD_WhiteAGM_JNDMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteAGM_JNDMin.TabIndex = 71
        Me.NUD_WhiteAGM_JNDMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_AGM_WhiteAreaMax
        '
        Me.Label_AGM_WhiteAreaMax.AutoSize = True
        Me.Label_AGM_WhiteAreaMax.Location = New System.Drawing.Point(8, 62)
        Me.Label_AGM_WhiteAreaMax.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_AGM_WhiteAreaMax.Name = "Label_AGM_WhiteAreaMax"
        Me.Label_AGM_WhiteAreaMax.Size = New System.Drawing.Size(134, 15)
        Me.Label_AGM_WhiteAreaMax.TabIndex = 84
        Me.Label_AGM_WhiteAreaMax.Text = "过滤AGM面积Max :"
        '
        'Label_WhiteAGM_JND
        '
        Me.Label_WhiteAGM_JND.Location = New System.Drawing.Point(7, 88)
        Me.Label_WhiteAGM_JND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteAGM_JND.Name = "Label_WhiteAGM_JND"
        Me.Label_WhiteAGM_JND.Size = New System.Drawing.Size(175, 29)
        Me.Label_WhiteAGM_JND.TabIndex = 69
        Me.Label_WhiteAGM_JND.Text = "过滤AGM JND Min :"
        Me.Label_WhiteAGM_JND.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'GroupBox_WhiteMacroJND
        '
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.Label_WhiteMacroMura_AreaMin)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.NUD_WhiteMacroMura_AreaMin)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.NUD_WhiteMacroMura_JND)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.Label_WhiteMacroMura_AreaMax)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.Label_WhiteMacroMura_JND)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.NUD_WhiteMacroMura_AreaMax)
        Me.GroupBox_WhiteMacroJND.Location = New System.Drawing.Point(664, 290)
        Me.GroupBox_WhiteMacroJND.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteMacroJND.Name = "GroupBox_WhiteMacroJND"
        Me.GroupBox_WhiteMacroJND.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteMacroJND.Size = New System.Drawing.Size(316, 126)
        Me.GroupBox_WhiteMacroJND.TabIndex = 98
        Me.GroupBox_WhiteMacroJND.TabStop = False
        Me.GroupBox_WhiteMacroJND.Text = "White Macro Mura"
        '
        'Label_WhiteMacroMura_AreaMin
        '
        Me.Label_WhiteMacroMura_AreaMin.AutoSize = True
        Me.Label_WhiteMacroMura_AreaMin.Location = New System.Drawing.Point(5, 26)
        Me.Label_WhiteMacroMura_AreaMin.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteMacroMura_AreaMin.Name = "Label_WhiteMacroMura_AreaMin"
        Me.Label_WhiteMacroMura_AreaMin.Size = New System.Drawing.Size(171, 15)
        Me.Label_WhiteMacroMura_AreaMin.TabIndex = 90
        Me.Label_WhiteMacroMura_AreaMin.Text = "过滤Macro Mura面积Min :"
        '
        'NUD_WhiteMacroMura_AreaMin
        '
        Me.NUD_WhiteMacroMura_AreaMin.Location = New System.Drawing.Point(195, 20)
        Me.NUD_WhiteMacroMura_AreaMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteMacroMura_AreaMin.Maximum = New Decimal(New Integer() {1000000000, 0, 0, 0})
        Me.NUD_WhiteMacroMura_AreaMin.Name = "NUD_WhiteMacroMura_AreaMin"
        Me.NUD_WhiteMacroMura_AreaMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteMacroMura_AreaMin.TabIndex = 91
        Me.NUD_WhiteMacroMura_AreaMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NUD_WhiteMacroMura_JND
        '
        Me.NUD_WhiteMacroMura_JND.DecimalPlaces = 2
        Me.NUD_WhiteMacroMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteMacroMura_JND.Location = New System.Drawing.Point(195, 90)
        Me.NUD_WhiteMacroMura_JND.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteMacroMura_JND.Name = "NUD_WhiteMacroMura_JND"
        Me.NUD_WhiteMacroMura_JND.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteMacroMura_JND.TabIndex = 95
        Me.NUD_WhiteMacroMura_JND.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_WhiteMacroMura_AreaMax
        '
        Me.Label_WhiteMacroMura_AreaMax.AutoSize = True
        Me.Label_WhiteMacroMura_AreaMax.Location = New System.Drawing.Point(5, 62)
        Me.Label_WhiteMacroMura_AreaMax.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteMacroMura_AreaMax.Name = "Label_WhiteMacroMura_AreaMax"
        Me.Label_WhiteMacroMura_AreaMax.Size = New System.Drawing.Size(173, 15)
        Me.Label_WhiteMacroMura_AreaMax.TabIndex = 92
        Me.Label_WhiteMacroMura_AreaMax.Text = "过滤Macro Mura面积Max :"
        '
        'Label_WhiteMacroMura_JND
        '
        Me.Label_WhiteMacroMura_JND.AutoSize = True
        Me.Label_WhiteMacroMura_JND.Location = New System.Drawing.Point(5, 95)
        Me.Label_WhiteMacroMura_JND.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_WhiteMacroMura_JND.Name = "Label_WhiteMacroMura_JND"
        Me.Label_WhiteMacroMura_JND.Size = New System.Drawing.Size(161, 15)
        Me.Label_WhiteMacroMura_JND.TabIndex = 94
        Me.Label_WhiteMacroMura_JND.Text = "过滤Macro Mura JND值 :"
        '
        'NUD_WhiteMacroMura_AreaMax
        '
        Me.NUD_WhiteMacroMura_AreaMax.Location = New System.Drawing.Point(195, 55)
        Me.NUD_WhiteMacroMura_AreaMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteMacroMura_AreaMax.Maximum = New Decimal(New Integer() {1215752192, 23, 0, 0})
        Me.NUD_WhiteMacroMura_AreaMax.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.NUD_WhiteMacroMura_AreaMax.Name = "NUD_WhiteMacroMura_AreaMax"
        Me.NUD_WhiteMacroMura_AreaMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteMacroMura_AreaMax.TabIndex = 93
        Me.NUD_WhiteMacroMura_AreaMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'GroupBox_WhiteBlobJND
        '
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_ElongationMax)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label30)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_ElongationMin)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label29)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_JNDMax)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label27)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label_WhiteBlob_AreaMin)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_AreaMin)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_AreaMax)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_JNDMin)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label_WhiteBlob_AreaMax)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label_WhiteBlobMura_JND)
        Me.GroupBox_WhiteBlobJND.Location = New System.Drawing.Point(11, 22)
        Me.GroupBox_WhiteBlobJND.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteBlobJND.Name = "GroupBox_WhiteBlobJND"
        Me.GroupBox_WhiteBlobJND.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox_WhiteBlobJND.Size = New System.Drawing.Size(316, 255)
        Me.GroupBox_WhiteBlobJND.TabIndex = 94
        Me.GroupBox_WhiteBlobJND.TabStop = False
        Me.GroupBox_WhiteBlobJND.Text = "White Blob Mura"
        '
        'NUD_WhiteBlobMura_ElongationMax
        '
        Me.NUD_WhiteBlobMura_ElongationMax.DecimalPlaces = 2
        Me.NUD_WhiteBlobMura_ElongationMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBlobMura_ElongationMax.Location = New System.Drawing.Point(196, 188)
        Me.NUD_WhiteBlobMura_ElongationMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBlobMura_ElongationMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_ElongationMax.Name = "NUD_WhiteBlobMura_ElongationMax"
        Me.NUD_WhiteBlobMura_ElongationMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBlobMura_ElongationMax.TabIndex = 90
        Me.NUD_WhiteBlobMura_ElongationMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label30
        '
        Me.Label30.Location = New System.Drawing.Point(8, 188)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(180, 29)
        Me.Label30.TabIndex = 89
        Me.Label30.Text = "Elongarion Max :"
        Me.Label30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteBlobMura_ElongationMin
        '
        Me.NUD_WhiteBlobMura_ElongationMin.DecimalPlaces = 2
        Me.NUD_WhiteBlobMura_ElongationMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBlobMura_ElongationMin.Location = New System.Drawing.Point(196, 155)
        Me.NUD_WhiteBlobMura_ElongationMin.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBlobMura_ElongationMin.Name = "NUD_WhiteBlobMura_ElongationMin"
        Me.NUD_WhiteBlobMura_ElongationMin.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBlobMura_ElongationMin.TabIndex = 88
        Me.NUD_WhiteBlobMura_ElongationMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label29
        '
        Me.Label29.Location = New System.Drawing.Point(8, 155)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(180, 29)
        Me.Label29.TabIndex = 87
        Me.Label29.Text = "Elongation Min :"
        Me.Label29.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NUD_WhiteBlobMura_JNDMax
        '
        Me.NUD_WhiteBlobMura_JNDMax.DecimalPlaces = 2
        Me.NUD_WhiteBlobMura_JNDMax.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBlobMura_JNDMax.Location = New System.Drawing.Point(196, 122)
        Me.NUD_WhiteBlobMura_JNDMax.Margin = New System.Windows.Forms.Padding(4)
        Me.NUD_WhiteBlobMura_JNDMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_JNDMax.Name = "NUD_WhiteBlobMura_JNDMax"
        Me.NUD_WhiteBlobMura_JNDMax.Size = New System.Drawing.Size(109, 25)
        Me.NUD_WhiteBlobMura_JNDMax.TabIndex = 86
        Me.NUD_WhiteBlobMura_JNDMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label27
        '
        Me.Label27.Location = New System.Drawing.Point(8, 122)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(180, 29)
        Me.Label27.TabIndex = 85
        Me.Label27.Text = "过滤Blob Mura JND Max :"
        Me.Label27.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label_Pattern
        '
        Me.Label_Pattern.Location = New System.Drawing.Point(21, 49)
        Me.Label_Pattern.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label_Pattern.Name = "Label_Pattern"
        Me.Label_Pattern.Size = New System.Drawing.Size(84, 21)
        Me.Label_Pattern.TabIndex = 88
        Me.Label_Pattern.Text = "Pattern :"
        Me.Label_Pattern.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_PatternList
        '
        Me.ComboBox_PatternList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PatternList.Location = New System.Drawing.Point(113, 45)
        Me.ComboBox_PatternList.Margin = New System.Windows.Forms.Padding(4)
        Me.ComboBox_PatternList.Name = "ComboBox_PatternList"
        Me.ComboBox_PatternList.Size = New System.Drawing.Size(157, 23)
        Me.ComboBox_PatternList.TabIndex = 87
        '
        'Dialog_MuraJND
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1344, 680)
        Me.Controls.Add(Me.Label_Pattern)
        Me.Controls.Add(Me.ComboBox_PatternList)
        Me.Controls.Add(Me.GroupBox_JNDSetting)
        Me.Controls.Add(Me.Label_Select)
        Me.Controls.Add(Me.ComboBox_Select)
        Me.Controls.Add(Me.Button_LoadChild)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraJND"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "计算Blob Mura JND"
        CType(Me.NUD_WhiteBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_JNDMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_JNDSetting.ResumeLayout(False)
        Me.GroupBox_JNDSetting.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.NumericUpDown13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackGapMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackGapMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackGapMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackCPD_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackCPD_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackCPD_JND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.NUD_WhiteGapMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteGapMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteGapMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.NUD_WhiteCPD_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteCPD_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteCPD_JND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BlackBandJND.ResumeLayout(False)
        Me.GroupBox_BlackBandJND.PerformLayout()
        CType(Me.NUD_BlackBandMura_WidthMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBandMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBandMura_SJND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BlackAGM.ResumeLayout(False)
        Me.GroupBox_BlackAGM.PerformLayout()
        CType(Me.NUD_BlackAGM_JNDMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_ElongationMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_ElongationMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_JNDMin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NUD_BlackMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackMacroMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BlackBlobJND.ResumeLayout(False)
        Me.GroupBox_BlackBlobJND.PerformLayout()
        CType(Me.NUD_BlackBlobMura_ElongationMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_JNDMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_ElongationMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_JNDMin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WhiteBandJND.ResumeLayout(False)
        Me.GroupBox_WhiteBandJND.PerformLayout()
        CType(Me.NUD_WhiteBandMura_WidthMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBandMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBandMura_SJND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WhiteAGM.ResumeLayout(False)
        Me.GroupBox_WhiteAGM.PerformLayout()
        CType(Me.NUD_WhiteAGM_JNDMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_ElongationMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_ElongationMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_JNDMin, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WhiteMacroJND.ResumeLayout(False)
        Me.GroupBox_WhiteMacroJND.PerformLayout()
        CType(Me.NUD_WhiteMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteMacroMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WhiteBlobJND.ResumeLayout(False)
        Me.GroupBox_WhiteBlobJND.PerformLayout()
        CType(Me.NUD_WhiteBlobMura_ElongationMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_ElongationMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_JNDMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CheckBox_AutoAddFalse As System.Windows.Forms.CheckBox
    Friend WithEvents NUD_WhiteBlobMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_WhiteBlob_AreaMin As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteBlobMura_JND As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_JNDMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Select As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Select As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Button_Ok As System.Windows.Forms.Button
    Friend WithEvents Button_JND As System.Windows.Forms.Button
    Friend WithEvents Button_LoadChild As System.Windows.Forms.Button
    Friend WithEvents NUD_WhiteBlobMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_WhiteBlob_AreaMax As System.Windows.Forms.Label
    Friend WithEvents GroupBox_JNDSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label_WhiteBandMura_JND As System.Windows.Forms.Label
    Friend WithEvents Labell_WhiteBandMura_SJND As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBandMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBandMura_SJND As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_WhiteBlobJND As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_WhiteMacroJND As System.Windows.Forms.GroupBox
    Friend WithEvents Label_WhiteMacroMura_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteMacroMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteMacroMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_WhiteMacroMura_AreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteMacroMura_JND As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteMacroMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_WhiteBandJND As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_WhiteBandMura_WidthMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_WhiteBandMura_WidthMin As System.Windows.Forms.Label
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_PatternList As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_WhiteAGM As System.Windows.Forms.GroupBox
    Friend WithEvents Label_WhiteAGM_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteAGM_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteAGM_JNDMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AGM_WhiteAreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteAGM_JND As System.Windows.Forms.Label
    Friend WithEvents GroupBox_BlackBlobJND As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BlackBlob_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_JNDMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackBlob_AreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_BlackBlobMura_JND As System.Windows.Forms.Label
    Friend WithEvents GroupBox_BlackBandJND As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_BlackBandMura_WidthMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackBandMura_WidthMin As System.Windows.Forms.Label
    Friend WithEvents Label_BlackBandMura_JND As System.Windows.Forms.Label
    Friend WithEvents Labell_BlackBandMura_SJND As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBandMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBandMura_SJND As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_BlackAGM As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BlackAGM_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackAGM_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackAGM_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackAGM_JNDMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BlackMacroMura_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackMacroMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackMacroMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackMacroMura_AreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_BlackMacroMura_JND As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackMacroMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_FilterMura As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FilterFalseCPD As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveMuraDefectsImgs As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown13 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown14 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown15 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown16 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown17 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown18 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackGapMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackGapMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackGapMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown7 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown8 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown9 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown10 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown11 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown12 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackCPD_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackCPD_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackCPD_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteGapMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteGapMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteGapMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteCPD_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteCPD_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteCPD_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackAGM_JNDMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackAGM_ElongationMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackAGM_ElongationMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_ElongationMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_JNDMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_ElongationMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_JNDMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_ElongationMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_ElongationMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_ElongationMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_ElongationMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_JNDMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label27 As System.Windows.Forms.Label
End Class
