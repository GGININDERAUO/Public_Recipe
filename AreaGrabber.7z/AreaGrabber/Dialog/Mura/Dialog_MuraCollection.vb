﻿Public Class Dialog_MuraCollection

    Private m_Form As Main_Form

    Public Sub SetMainForm(ByVal form As Main_Form)
        Me.m_Form = form
    End Sub

#Region "--- Button Event ---"

#Region "--- Button_CenterMura_Click ---"
    Private Sub Button_CenterMura_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_CenterMura.Click
        Me.m_Form.Button_MuraLocation_Click()
    End Sub
#End Region

#Region "--- Button_RoundMura_Click ---"
    Private Sub Button_RoundMura_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_RoundMura.Click
        Me.m_Form.Button_MuraRound_Click()
    End Sub
#End Region

#Region "--- Button_BandMura_Click ---"
    Private Sub Button_BandMura_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_BandMura.Click
        Me.Close()
        Me.m_Form.Button_BandMura_Click()
    End Sub
#End Region

#Region "--- BtnPre_BlobMuraRound_Click ---"
    Private Sub BtnPre_BlobMuraRound_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPre_BlobMuraRound.Click
        Me.Close()
        Me.m_Form.Button_Smooth_Click()
    End Sub
#End Region

#End Region


End Class