<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraSetting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_MuraSetting))
        Me.CheckBox_SaveBlackReconstructArea = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveBlackThreshold = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveWhiteReconstructArea = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveWhiteThreshold = New System.Windows.Forms.CheckBox()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.CheckBox_SaveSmooth = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveOriginal = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveHBand = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveVBand = New System.Windows.Forms.CheckBox()
        Me.TabPage_Save = New System.Windows.Forms.TabPage()
        Me.GroupBox_Save = New System.Windows.Forms.GroupBox()
        Me.CheckBox_SaveFFTResult = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveResizeBMP = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveFFCAlignResult = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveBlackReconstructRim = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveWhiteReconstructRim = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveDefocus = New System.Windows.Forms.CheckBox()
        Me.CheckBox_UseFFC = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_AlignPercentage = New System.Windows.Forms.NumericUpDown()
        Me.Label_AlignpPercentage = New System.Windows.Forms.Label()
        Me.Button_SaveFFCImages = New System.Windows.Forms.Button()
        Me.TabPage_Alignment = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CheckBox_UseFFT = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_FFTFilterRadius = New System.Windows.Forms.NumericUpDown()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.GroupBox_GlobleSmooth = New System.Windows.Forms.GroupBox()
        Me.CheckBox_RemoveHVBand = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_MacroMura_GlobleSmooth = New System.Windows.Forms.NumericUpDown()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlobMura_GlobleSmooth = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Defocus = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_PitchY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_PitchX = New System.Windows.Forms.NumericUpDown()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.NumericUpDown_DefocusCount = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox_FFCOperation = New System.Windows.Forms.GroupBox()
        Me.CheckBox_UseBLFFC = New System.Windows.Forms.CheckBox()
        Me.GroupBox_SettingFFC = New System.Windows.Forms.GroupBox()
        Me.Button_Calculate_Max = New System.Windows.Forms.Button()
        Me.Lbl_Max_GrayLevel = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Button_Boundary = New System.Windows.Forms.Button()
        Me.NumericUpDown_AlignValue = New System.Windows.Forms.NumericUpDown()
        Me.Button_FFCImage = New System.Windows.Forms.Button()
        Me.Label_Align = New System.Windows.Forms.Label()
        Me.TabControl_Setting = New System.Windows.Forms.TabControl()
        Me.TabPage_Center = New System.Windows.Forms.TabPage()
        Me.NumericUpDown_BlobMulRatio = New System.Windows.Forms.NumericUpDown()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.CheckBox_UseReconstructBW = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Center = New System.Windows.Forms.CheckBox()
        Me.GroupBox_MuraRatio = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.NumericUpDown_MacroPowerY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_MacroPowerX = New System.Windows.Forms.NumericUpDown()
        Me.Num_ResizeCount_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Num_ResizeCount_Mid2 = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Num_ResizeCount_Min = New System.Windows.Forms.NumericUpDown()
        Me.Num_ResizeCount_Mid = New System.Windows.Forms.NumericUpDown()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.CheckBox_UseBaseLine = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Parameter = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackBlobMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBlobMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.NUD_BlackMacroMura_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NUD_WhiteBlobMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteMacroMura_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Label_ReconstructLow = New System.Windows.Forms.Label()
        Me.Label_ReconstructHeight = New System.Windows.Forms.Label()
        Me.GroupBox_Modify = New System.Windows.Forms.GroupBox()
        Me.CheckBox_Show = New System.Windows.Forms.CheckBox()
        Me.RadioButton_Manual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Finish = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Area = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_AreaRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_AreaLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_AreaTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_AreaBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaTop = New System.Windows.Forms.Label()
        Me.TabPage_CPD = New System.Windows.Forms.TabPage()
        Me.GroupBox_WithoutCoreCPDRecipe = New System.Windows.Forms.GroupBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low = New System.Windows.Forms.NumericUpDown()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_High = New System.Windows.Forms.NumericUpDown()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low = New System.Windows.Forms.NumericUpDown()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh = New System.Windows.Forms.NumericUpDown()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low = New System.Windows.Forms.NumericUpDown()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High = New System.Windows.Forms.NumericUpDown()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithoutCoreBlackCPD_ThLow = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_WithoutCoreCPD_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_WithCoreCPDRecipe = New System.Windows.Forms.GroupBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithCoreBlackCPDCompactness_High = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreBlackCPDCompactness_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreBlackCPDBreadth_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreBlackCPDBreadth_High = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreBlackCPDElongation_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreBlackCPDElongation_High = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_High = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_High = New System.Windows.Forms.NumericUpDown()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithCoreWhiteCPDElongation_Low = New System.Windows.Forms.NumericUpDown()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithCoreWhiteCPDElongation_High = New System.Windows.Forms.NumericUpDown()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithCoreWhiteCPD_ThLow = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreBlackCPD_ThLow = New System.Windows.Forms.NumericUpDown()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WithCoreWhiteCPD_ThHigh = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WithCoreBlackCPD_ThHigh = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_WithCoreCPD_Enable = New System.Windows.Forms.CheckBox()
        Me.TabPage_Rim = New System.Windows.Forms.TabPage()
        Me.GroupBox_GoldenSampleParameter = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Resize = New System.Windows.Forms.NumericUpDown()
        Me.Label_Resize = New System.Windows.Forms.Label()
        Me.Label_Smooth = New System.Windows.Forms.Label()
        Me.NumericUpDown_Smooth = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_RimType = New System.Windows.Forms.GroupBox()
        Me.GroupBox_RimModify = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowRound = New System.Windows.Forms.CheckBox()
        Me.RadioButton_RoundManual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_RoundFinish = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Round = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_RimRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_Right = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_Left = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_Bottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_Top = New System.Windows.Forms.Label()
        Me.GroupBox_RimParameter = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlackMura_RimLow = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlackMura_RimHeight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteMura_RimLow = New System.Windows.Forms.NumericUpDown()
        Me.Label_RoundLow = New System.Windows.Forms.Label()
        Me.Label_RoundHeight = New System.Windows.Forms.Label()
        Me.NumericUpDown_WhiteMura_RimHeight = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Rim = New System.Windows.Forms.CheckBox()
        Me.TabPage_Band = New System.Windows.Forms.TabPage()
        Me.CheckBox_Band = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BandParameter = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlackVBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlackHBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteHBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteVBand_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackBand_Thrshold = New System.Windows.Forms.Label()
        Me.Label_HBand_Thrshold = New System.Windows.Forms.Label()
        Me.NumericUpDown_BandMura_SmoothCount = New System.Windows.Forms.NumericUpDown()
        Me.Label_Band_SmoothCount = New System.Windows.Forms.Label()
        Me.NumericUpDown_BandMura_ResizeCount = New System.Windows.Forms.NumericUpDown()
        Me.Label_Band_ResizeCount = New System.Windows.Forms.Label()
        Me.GroupBox_BandModify = New System.Windows.Forms.GroupBox()
        Me.GroupBox_V = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_VTop = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_VRight = New System.Windows.Forms.NumericUpDown()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label_VRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_VBottom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_VLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label_VLeft = New System.Windows.Forms.Label()
        Me.GroupBox_H = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_HRight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_HTop = New System.Windows.Forms.NumericUpDown()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label_HBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_HLeft = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_HBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label_HTOP = New System.Windows.Forms.Label()
        Me.TabPage_HVValue = New System.Windows.Forms.TabPage()
        Me.NumericUpDown_VValue_BlackVBandTH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_VValue_WhiteVBandTH = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_VValue_UseVBand = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_HValue_BlackHBandTH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_HValue_WhiteHBandTH = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_HValue_UseHBand = New System.Windows.Forms.CheckBox()
        Me.Label_VConst = New System.Windows.Forms.Label()
        Me.Label_VSlope = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label_HConst = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label_HSlope = New System.Windows.Forms.Label()
        Me.Label_VValueL1 = New System.Windows.Forms.Label()
        Me.Label_HValueL1 = New System.Windows.Forms.Label()
        Me.GroupBox_Manual = New System.Windows.Forms.GroupBox()
        Me.Button_CalculateLSQ = New System.Windows.Forms.Button()
        Me.NumericUpDown_JND = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Value = New System.Windows.Forms.NumericUpDown()
        Me.ComboBox_ValueType = New System.Windows.Forms.ComboBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Button_AddOne = New System.Windows.Forms.Button()
        Me.Button_Clear = New System.Windows.Forms.Button()
        Me.Label_Y = New System.Windows.Forms.Label()
        Me.Label_Value = New System.Windows.Forms.Label()
        Me.Label_VValueCount = New System.Windows.Forms.Label()
        Me.Label_HValueCount = New System.Windows.Forms.Label()
        Me.ListView_VValue = New System.Windows.Forms.ListView()
        Me.ColumnHeader_VValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_VJND = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CheckBox_UseVValue = New System.Windows.Forms.CheckBox()
        Me.ListView_HValue = New System.Windows.Forms.ListView()
        Me.ColumnHeader_HValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_HJND = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CheckBox_UseHValue = New System.Windows.Forms.CheckBox()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.TabPage_JND_1 = New System.Windows.Forms.TabPage()
        Me.GroupBox_JND_1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox_WhiteBandJND = New System.Windows.Forms.GroupBox()
        Me.NUD_WhiteBandMura_WidthMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteBandMura_WidthMin = New System.Windows.Forms.Label()
        Me.Label_WhiteBandMura_JND = New System.Windows.Forms.Label()
        Me.Labell_WhiteBandMura_SJND = New System.Windows.Forms.Label()
        Me.NUD_WhiteBandMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBandMura_SJND = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_WhiteAGM = New System.Windows.Forms.GroupBox()
        Me.NUD_WhiteAGM_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteAGM_AreaMin = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.NUD_WhiteAGM_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteAGM_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteAGM_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.NUD_WhiteAGM_JND_Min = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteAGM_JND_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label_AGM_WhiteAreaMax = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label_WhiteAGM_JND = New System.Windows.Forms.Label()
        Me.GroupBox_WhiteMacroJND = New System.Windows.Forms.GroupBox()
        Me.Label_WhiteMacroMura_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_WhiteMacroMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteMacroMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteMacroMura_AreaMax = New System.Windows.Forms.Label()
        Me.Label_WhiteMacroMura_JND = New System.Windows.Forms.Label()
        Me.NUD_WhiteMacroMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_WhiteBlobJND = New System.Windows.Forms.GroupBox()
        Me.NUD_WhiteBlobMura_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.NUD_WhiteBlobMura_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.NUD_WhiteBlobMura_JND_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label_WhiteBlob_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_WhiteBlobMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBlobMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBlobMura_JND_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label_WhiteBlob_AreaMax = New System.Windows.Forms.Label()
        Me.Label_WhiteBlobMura_JND = New System.Windows.Forms.Label()
        Me.TabPage_JND_2 = New System.Windows.Forms.TabPage()
        Me.GroupBox_JND_2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox_BlackBandJND = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackBandMura_WidthMin = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackBandMura_WidthMin = New System.Windows.Forms.Label()
        Me.Label_BlackBandMura_JND = New System.Windows.Forms.Label()
        Me.Labell_BlackBandMura_SJND = New System.Windows.Forms.Label()
        Me.NUD_BlackBandMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBandMura_SJND = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_BlackAGM = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackAGM_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.NUD_BlackAGM_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.NUD_BlackAGM_JND_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label_BlackAGM_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_BlackAGM_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackAGM_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackAGM_JND_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label_BlackMacroMura_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_BlackMacroMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackMacroMura_JND = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackMacroMura_AreaMax = New System.Windows.Forms.Label()
        Me.Label_BlackMacroMura_JND = New System.Windows.Forms.Label()
        Me.NUD_BlackMacroMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_BlackBlobJND = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackBlobMura_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.NUD_BlackBlobMura_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.NUD_BlackBlobMura_JND_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label_BlackBlob_AreaMin = New System.Windows.Forms.Label()
        Me.NUD_BlackBlobMura_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_JND_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label_BlackBlob_AreaMax = New System.Windows.Forms.Label()
        Me.Label_BlackBlobMura_JND = New System.Windows.Forms.Label()
        Me.TabPage_Auto = New System.Windows.Forms.TabPage()
        Me.GroupBox_AutoExposure = New System.Windows.Forms.GroupBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AutoExposure_GrabDelayTime = New System.Windows.Forms.NumericUpDown()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AutoExposure_LargeErrorRange_DL = New System.Windows.Forms.NumericUpDown()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AutoExposure_SmallErrorRange = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_AutoExposure_LargeErrorRange_UL = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_AutoExposure_TargetMean = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_AutoExposure_Kp = New System.Windows.Forms.NumericUpDown()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage_Abnormal = New System.Windows.Forms.TabPage()
        Me.GroupBox_GrayAbnormal_2 = New System.Windows.Forms.GroupBox()
        Me.Lbl_GrayAbnormal_NegLimit_2 = New System.Windows.Forms.Label()
        Me.Lbl_GrayAbnormal_PosLimit_2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormal_NegLimit_2 = New System.Windows.Forms.NumericUpDown()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormalStandardGray_2 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GrayAbnormal_PosLimit_2 = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_GrayAbnormal_3 = New System.Windows.Forms.GroupBox()
        Me.Lbl_GrayAbnormal_NegLimit_3 = New System.Windows.Forms.Label()
        Me.Lbl_GrayAbnormal_PosLimit_3 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormal_NegLimit_3 = New System.Windows.Forms.NumericUpDown()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormalStandardGray_3 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GrayAbnormal_PosLimit_3 = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_MultiRegion = New System.Windows.Forms.CheckBox()
        Me.GroupBox_GrayAbnormal_1 = New System.Windows.Forms.GroupBox()
        Me.Lbl_GrayAbnormal_NegLimit_1 = New System.Windows.Forms.Label()
        Me.Lbl_GrayAbnormal_PosLimit_1 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormal_NegLimit_1 = New System.Windows.Forms.NumericUpDown()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormalStandardGray_1 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GrayAbnormal_PosLimit_1 = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_GrayAbnormal_Enable = New System.Windows.Forms.CheckBox()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.ComboBox_PatternList = New System.Windows.Forms.ComboBox()
        Me.TabPage_Save.SuspendLayout()
        Me.GroupBox_Save.SuspendLayout()
        CType(Me.NumericUpDown_AlignPercentage, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Alignment.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NumericUpDown_FFTFilterRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_GlobleSmooth.SuspendLayout()
        CType(Me.NumericUpDown_MacroMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlobMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Defocus.SuspendLayout()
        CType(Me.NumericUpDown_PitchY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_PitchX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DefocusCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_FFCOperation.SuspendLayout()
        Me.GroupBox_SettingFFC.SuspendLayout()
        CType(Me.NumericUpDown_AlignValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl_Setting.SuspendLayout()
        Me.TabPage_Center.SuspendLayout()
        CType(Me.NumericUpDown_BlobMulRatio, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MuraRatio.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.NumericUpDown_MacroPowerY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MacroPowerX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Mid2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.Num_ResizeCount_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Mid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Parameter.SuspendLayout()
        CType(Me.NUD_BlackBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackMacroMura_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteMacroMura_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Modify.SuspendLayout()
        Me.GroupBox_Area.SuspendLayout()
        CType(Me.NumericUpDown_AreaRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AreaLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AreaTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AreaBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_CPD.SuspendLayout()
        Me.GroupBox_WithoutCoreCPDRecipe.SuspendLayout()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDElongation_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPD_ThLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WithCoreCPDRecipe.SuspendLayout()
        CType(Me.NumericUpDown_WithCoreBlackCPDCompactness_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDCompactness_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDBreadth_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDBreadth_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDElongation_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDElongation_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDCompactness_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDBreadth_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDElongation_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDElongation_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPD_ThLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreBlackCPD_ThLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPD_ThHigh, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WithCoreBlackCPD_ThHigh, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Rim.SuspendLayout()
        Me.GroupBox_GoldenSampleParameter.SuspendLayout()
        CType(Me.NumericUpDown_Resize, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Smooth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_RimType.SuspendLayout()
        Me.GroupBox_RimModify.SuspendLayout()
        Me.GroupBox_Round.SuspendLayout()
        CType(Me.NumericUpDown_RimRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_RimParameter.SuspendLayout()
        CType(Me.NumericUpDown_BlackMura_RimLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlackMura_RimHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteMura_RimLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteMura_RimHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Band.SuspendLayout()
        Me.GroupBox_BandParameter.SuspendLayout()
        CType(Me.NumericUpDown_BlackVBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlackHBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteHBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteVBand_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BandMura_SmoothCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BandMura_ResizeCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BandModify.SuspendLayout()
        Me.GroupBox_V.SuspendLayout()
        CType(Me.NumericUpDown_VTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_H.SuspendLayout()
        CType(Me.NumericUpDown_HRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_HVValue.SuspendLayout()
        CType(Me.NumericUpDown_VValue_BlackVBandTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_VValue_WhiteVBandTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HValue_BlackHBandTH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HValue_WhiteHBandTH, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Manual.SuspendLayout()
        CType(Me.NumericUpDown_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Value, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_JND_1.SuspendLayout()
        Me.GroupBox_JND_1.SuspendLayout()
        Me.GroupBox_WhiteBandJND.SuspendLayout()
        CType(Me.NUD_WhiteBandMura_WidthMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBandMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBandMura_SJND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WhiteAGM.SuspendLayout()
        CType(Me.NUD_WhiteAGM_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_JND_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteAGM_JND_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WhiteMacroJND.SuspendLayout()
        CType(Me.NUD_WhiteMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteMacroMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_WhiteBlobJND.SuspendLayout()
        CType(Me.NUD_WhiteBlobMura_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_JND_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_JND_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_JND_2.SuspendLayout()
        Me.GroupBox_JND_2.SuspendLayout()
        Me.GroupBox_BlackBandJND.SuspendLayout()
        CType(Me.NUD_BlackBandMura_WidthMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBandMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBandMura_SJND, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BlackAGM.SuspendLayout()
        CType(Me.NUD_BlackAGM_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_JND_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackAGM_JND_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NUD_BlackMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackMacroMura_JND, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BlackBlobJND.SuspendLayout()
        CType(Me.NUD_BlackBlobMura_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_JND_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_JND_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Auto.SuspendLayout()
        Me.GroupBox_AutoExposure.SuspendLayout()
        CType(Me.NumericUpDown_AutoExposure_GrabDelayTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_SmallErrorRange, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_TargetMean, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_Kp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Abnormal.SuspendLayout()
        Me.GroupBox_GrayAbnormal_2.SuspendLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit_2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_GrayAbnormal_3.SuspendLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit_3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_GrayAbnormal_1.SuspendLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit_1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CheckBox_SaveBlackReconstructArea
        '
        resources.ApplyResources(Me.CheckBox_SaveBlackReconstructArea, "CheckBox_SaveBlackReconstructArea")
        Me.CheckBox_SaveBlackReconstructArea.Name = "CheckBox_SaveBlackReconstructArea"
        '
        'CheckBox_SaveBlackThreshold
        '
        resources.ApplyResources(Me.CheckBox_SaveBlackThreshold, "CheckBox_SaveBlackThreshold")
        Me.CheckBox_SaveBlackThreshold.Name = "CheckBox_SaveBlackThreshold"
        '
        'CheckBox_SaveWhiteReconstructArea
        '
        resources.ApplyResources(Me.CheckBox_SaveWhiteReconstructArea, "CheckBox_SaveWhiteReconstructArea")
        Me.CheckBox_SaveWhiteReconstructArea.Name = "CheckBox_SaveWhiteReconstructArea"
        '
        'CheckBox_SaveWhiteThreshold
        '
        resources.ApplyResources(Me.CheckBox_SaveWhiteThreshold, "CheckBox_SaveWhiteThreshold")
        Me.CheckBox_SaveWhiteThreshold.Name = "CheckBox_SaveWhiteThreshold"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        '
        'Button_Close
        '
        resources.ApplyResources(Me.Button_Close, "Button_Close")
        Me.Button_Close.Name = "Button_Close"
        '
        'CheckBox_SaveSmooth
        '
        resources.ApplyResources(Me.CheckBox_SaveSmooth, "CheckBox_SaveSmooth")
        Me.CheckBox_SaveSmooth.Name = "CheckBox_SaveSmooth"
        '
        'CheckBox_SaveOriginal
        '
        resources.ApplyResources(Me.CheckBox_SaveOriginal, "CheckBox_SaveOriginal")
        Me.CheckBox_SaveOriginal.Name = "CheckBox_SaveOriginal"
        '
        'CheckBox_SaveHBand
        '
        resources.ApplyResources(Me.CheckBox_SaveHBand, "CheckBox_SaveHBand")
        Me.CheckBox_SaveHBand.Name = "CheckBox_SaveHBand"
        '
        'CheckBox_SaveVBand
        '
        resources.ApplyResources(Me.CheckBox_SaveVBand, "CheckBox_SaveVBand")
        Me.CheckBox_SaveVBand.Name = "CheckBox_SaveVBand"
        '
        'TabPage_Save
        '
        resources.ApplyResources(Me.TabPage_Save, "TabPage_Save")
        Me.TabPage_Save.Controls.Add(Me.GroupBox_Save)
        Me.TabPage_Save.Name = "TabPage_Save"
        Me.TabPage_Save.UseVisualStyleBackColor = True
        '
        'GroupBox_Save
        '
        resources.ApplyResources(Me.GroupBox_Save, "GroupBox_Save")
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveFFTResult)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveResizeBMP)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveFFCAlignResult)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveBlackReconstructRim)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveWhiteReconstructRim)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveDefocus)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveHBand)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveVBand)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveBlackReconstructArea)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveBlackThreshold)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveWhiteReconstructArea)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveWhiteThreshold)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveSmooth)
        Me.GroupBox_Save.Controls.Add(Me.CheckBox_SaveOriginal)
        Me.GroupBox_Save.Name = "GroupBox_Save"
        Me.GroupBox_Save.TabStop = False
        '
        'CheckBox_SaveFFTResult
        '
        resources.ApplyResources(Me.CheckBox_SaveFFTResult, "CheckBox_SaveFFTResult")
        Me.CheckBox_SaveFFTResult.Name = "CheckBox_SaveFFTResult"
        Me.CheckBox_SaveFFTResult.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveResizeBMP
        '
        resources.ApplyResources(Me.CheckBox_SaveResizeBMP, "CheckBox_SaveResizeBMP")
        Me.CheckBox_SaveResizeBMP.Name = "CheckBox_SaveResizeBMP"
        Me.CheckBox_SaveResizeBMP.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveFFCAlignResult
        '
        resources.ApplyResources(Me.CheckBox_SaveFFCAlignResult, "CheckBox_SaveFFCAlignResult")
        Me.CheckBox_SaveFFCAlignResult.Name = "CheckBox_SaveFFCAlignResult"
        Me.CheckBox_SaveFFCAlignResult.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveBlackReconstructRim
        '
        resources.ApplyResources(Me.CheckBox_SaveBlackReconstructRim, "CheckBox_SaveBlackReconstructRim")
        Me.CheckBox_SaveBlackReconstructRim.Name = "CheckBox_SaveBlackReconstructRim"
        Me.CheckBox_SaveBlackReconstructRim.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveWhiteReconstructRim
        '
        resources.ApplyResources(Me.CheckBox_SaveWhiteReconstructRim, "CheckBox_SaveWhiteReconstructRim")
        Me.CheckBox_SaveWhiteReconstructRim.Name = "CheckBox_SaveWhiteReconstructRim"
        Me.CheckBox_SaveWhiteReconstructRim.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveDefocus
        '
        resources.ApplyResources(Me.CheckBox_SaveDefocus, "CheckBox_SaveDefocus")
        Me.CheckBox_SaveDefocus.Name = "CheckBox_SaveDefocus"
        Me.CheckBox_SaveDefocus.UseVisualStyleBackColor = True
        '
        'CheckBox_UseFFC
        '
        resources.ApplyResources(Me.CheckBox_UseFFC, "CheckBox_UseFFC")
        Me.CheckBox_UseFFC.Name = "CheckBox_UseFFC"
        '
        'NumericUpDown_AlignPercentage
        '
        resources.ApplyResources(Me.NumericUpDown_AlignPercentage, "NumericUpDown_AlignPercentage")
        Me.NumericUpDown_AlignPercentage.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_AlignPercentage.Name = "NumericUpDown_AlignPercentage"
        Me.NumericUpDown_AlignPercentage.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_AlignpPercentage
        '
        resources.ApplyResources(Me.Label_AlignpPercentage, "Label_AlignpPercentage")
        Me.Label_AlignpPercentage.Name = "Label_AlignpPercentage"
        '
        'Button_SaveFFCImages
        '
        resources.ApplyResources(Me.Button_SaveFFCImages, "Button_SaveFFCImages")
        Me.Button_SaveFFCImages.Name = "Button_SaveFFCImages"
        '
        'TabPage_Alignment
        '
        resources.ApplyResources(Me.TabPage_Alignment, "TabPage_Alignment")
        Me.TabPage_Alignment.Controls.Add(Me.GroupBox1)
        Me.TabPage_Alignment.Controls.Add(Me.GroupBox_GlobleSmooth)
        Me.TabPage_Alignment.Controls.Add(Me.GroupBox_Defocus)
        Me.TabPage_Alignment.Controls.Add(Me.Button_SaveFFCImages)
        Me.TabPage_Alignment.Controls.Add(Me.GroupBox_FFCOperation)
        Me.TabPage_Alignment.Name = "TabPage_Alignment"
        Me.TabPage_Alignment.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.CheckBox_UseFFT)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_FFTFilterRadius)
        Me.GroupBox1.Controls.Add(Me.Label66)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'CheckBox_UseFFT
        '
        resources.ApplyResources(Me.CheckBox_UseFFT, "CheckBox_UseFFT")
        Me.CheckBox_UseFFT.Name = "CheckBox_UseFFT"
        Me.CheckBox_UseFFT.UseVisualStyleBackColor = True
        '
        'NumericUpDown_FFTFilterRadius
        '
        resources.ApplyResources(Me.NumericUpDown_FFTFilterRadius, "NumericUpDown_FFTFilterRadius")
        Me.NumericUpDown_FFTFilterRadius.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_FFTFilterRadius.Maximum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.NumericUpDown_FFTFilterRadius.Name = "NumericUpDown_FFTFilterRadius"
        '
        'Label66
        '
        resources.ApplyResources(Me.Label66, "Label66")
        Me.Label66.Name = "Label66"
        '
        'GroupBox_GlobleSmooth
        '
        resources.ApplyResources(Me.GroupBox_GlobleSmooth, "GroupBox_GlobleSmooth")
        Me.GroupBox_GlobleSmooth.Controls.Add(Me.CheckBox_RemoveHVBand)
        Me.GroupBox_GlobleSmooth.Controls.Add(Me.NumericUpDown_MacroMura_GlobleSmooth)
        Me.GroupBox_GlobleSmooth.Controls.Add(Me.Label17)
        Me.GroupBox_GlobleSmooth.Controls.Add(Me.Label18)
        Me.GroupBox_GlobleSmooth.Controls.Add(Me.NumericUpDown_BlobMura_GlobleSmooth)
        Me.GroupBox_GlobleSmooth.Name = "GroupBox_GlobleSmooth"
        Me.GroupBox_GlobleSmooth.TabStop = False
        '
        'CheckBox_RemoveHVBand
        '
        resources.ApplyResources(Me.CheckBox_RemoveHVBand, "CheckBox_RemoveHVBand")
        Me.CheckBox_RemoveHVBand.Name = "CheckBox_RemoveHVBand"
        Me.CheckBox_RemoveHVBand.UseVisualStyleBackColor = True
        '
        'NumericUpDown_MacroMura_GlobleSmooth
        '
        resources.ApplyResources(Me.NumericUpDown_MacroMura_GlobleSmooth, "NumericUpDown_MacroMura_GlobleSmooth")
        Me.NumericUpDown_MacroMura_GlobleSmooth.Name = "NumericUpDown_MacroMura_GlobleSmooth"
        '
        'Label17
        '
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        '
        'Label18
        '
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        '
        'NumericUpDown_BlobMura_GlobleSmooth
        '
        resources.ApplyResources(Me.NumericUpDown_BlobMura_GlobleSmooth, "NumericUpDown_BlobMura_GlobleSmooth")
        Me.NumericUpDown_BlobMura_GlobleSmooth.Name = "NumericUpDown_BlobMura_GlobleSmooth"
        '
        'GroupBox_Defocus
        '
        resources.ApplyResources(Me.GroupBox_Defocus, "GroupBox_Defocus")
        Me.GroupBox_Defocus.Controls.Add(Me.NumericUpDown_PitchY)
        Me.GroupBox_Defocus.Controls.Add(Me.NumericUpDown_PitchX)
        Me.GroupBox_Defocus.Controls.Add(Me.Label11)
        Me.GroupBox_Defocus.Controls.Add(Me.Label10)
        Me.GroupBox_Defocus.Controls.Add(Me.NumericUpDown_DefocusCount)
        Me.GroupBox_Defocus.Controls.Add(Me.Label1)
        Me.GroupBox_Defocus.Name = "GroupBox_Defocus"
        Me.GroupBox_Defocus.TabStop = False
        '
        'NumericUpDown_PitchY
        '
        resources.ApplyResources(Me.NumericUpDown_PitchY, "NumericUpDown_PitchY")
        Me.NumericUpDown_PitchY.Name = "NumericUpDown_PitchY"
        '
        'NumericUpDown_PitchX
        '
        resources.ApplyResources(Me.NumericUpDown_PitchX, "NumericUpDown_PitchX")
        Me.NumericUpDown_PitchX.Name = "NumericUpDown_PitchX"
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'NumericUpDown_DefocusCount
        '
        resources.ApplyResources(Me.NumericUpDown_DefocusCount, "NumericUpDown_DefocusCount")
        Me.NumericUpDown_DefocusCount.Name = "NumericUpDown_DefocusCount"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'GroupBox_FFCOperation
        '
        resources.ApplyResources(Me.GroupBox_FFCOperation, "GroupBox_FFCOperation")
        Me.GroupBox_FFCOperation.Controls.Add(Me.CheckBox_UseBLFFC)
        Me.GroupBox_FFCOperation.Controls.Add(Me.GroupBox_SettingFFC)
        Me.GroupBox_FFCOperation.Controls.Add(Me.CheckBox_UseFFC)
        Me.GroupBox_FFCOperation.Controls.Add(Me.NumericUpDown_AlignPercentage)
        Me.GroupBox_FFCOperation.Controls.Add(Me.Label_AlignpPercentage)
        Me.GroupBox_FFCOperation.Name = "GroupBox_FFCOperation"
        Me.GroupBox_FFCOperation.TabStop = False
        '
        'CheckBox_UseBLFFC
        '
        resources.ApplyResources(Me.CheckBox_UseBLFFC, "CheckBox_UseBLFFC")
        Me.CheckBox_UseBLFFC.Name = "CheckBox_UseBLFFC"
        '
        'GroupBox_SettingFFC
        '
        resources.ApplyResources(Me.GroupBox_SettingFFC, "GroupBox_SettingFFC")
        Me.GroupBox_SettingFFC.Controls.Add(Me.Button_Calculate_Max)
        Me.GroupBox_SettingFFC.Controls.Add(Me.Lbl_Max_GrayLevel)
        Me.GroupBox_SettingFFC.Controls.Add(Me.Label30)
        Me.GroupBox_SettingFFC.Controls.Add(Me.Button_Boundary)
        Me.GroupBox_SettingFFC.Controls.Add(Me.NumericUpDown_AlignValue)
        Me.GroupBox_SettingFFC.Controls.Add(Me.Button_FFCImage)
        Me.GroupBox_SettingFFC.Controls.Add(Me.Label_Align)
        Me.GroupBox_SettingFFC.Name = "GroupBox_SettingFFC"
        Me.GroupBox_SettingFFC.TabStop = False
        '
        'Button_Calculate_Max
        '
        resources.ApplyResources(Me.Button_Calculate_Max, "Button_Calculate_Max")
        Me.Button_Calculate_Max.Name = "Button_Calculate_Max"
        Me.Button_Calculate_Max.UseVisualStyleBackColor = True
        '
        'Lbl_Max_GrayLevel
        '
        resources.ApplyResources(Me.Lbl_Max_GrayLevel, "Lbl_Max_GrayLevel")
        Me.Lbl_Max_GrayLevel.Name = "Lbl_Max_GrayLevel"
        '
        'Label30
        '
        resources.ApplyResources(Me.Label30, "Label30")
        Me.Label30.Name = "Label30"
        '
        'Button_Boundary
        '
        resources.ApplyResources(Me.Button_Boundary, "Button_Boundary")
        Me.Button_Boundary.Name = "Button_Boundary"
        '
        'NumericUpDown_AlignValue
        '
        resources.ApplyResources(Me.NumericUpDown_AlignValue, "NumericUpDown_AlignValue")
        Me.NumericUpDown_AlignValue.Maximum = New Decimal(New Integer() {6000, 0, 0, 0})
        Me.NumericUpDown_AlignValue.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_AlignValue.Name = "NumericUpDown_AlignValue"
        Me.NumericUpDown_AlignValue.Value = New Decimal(New Integer() {4095, 0, 0, 0})
        '
        'Button_FFCImage
        '
        resources.ApplyResources(Me.Button_FFCImage, "Button_FFCImage")
        Me.Button_FFCImage.Name = "Button_FFCImage"
        '
        'Label_Align
        '
        resources.ApplyResources(Me.Label_Align, "Label_Align")
        Me.Label_Align.Name = "Label_Align"
        '
        'TabControl_Setting
        '
        resources.ApplyResources(Me.TabControl_Setting, "TabControl_Setting")
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Alignment)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Center)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_CPD)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Rim)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Band)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_HVValue)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_JND_1)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_JND_2)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Save)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Auto)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Abnormal)
        Me.TabControl_Setting.Name = "TabControl_Setting"
        Me.TabControl_Setting.SelectedIndex = 0
        '
        'TabPage_Center
        '
        resources.ApplyResources(Me.TabPage_Center, "TabPage_Center")
        Me.TabPage_Center.Controls.Add(Me.NumericUpDown_BlobMulRatio)
        Me.TabPage_Center.Controls.Add(Me.Label82)
        Me.TabPage_Center.Controls.Add(Me.CheckBox_UseReconstructBW)
        Me.TabPage_Center.Controls.Add(Me.CheckBox_Center)
        Me.TabPage_Center.Controls.Add(Me.GroupBox_MuraRatio)
        Me.TabPage_Center.Controls.Add(Me.GroupBox_Parameter)
        Me.TabPage_Center.Controls.Add(Me.GroupBox_Modify)
        Me.TabPage_Center.Name = "TabPage_Center"
        Me.TabPage_Center.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BlobMulRatio
        '
        resources.ApplyResources(Me.NumericUpDown_BlobMulRatio, "NumericUpDown_BlobMulRatio")
        Me.NumericUpDown_BlobMulRatio.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BlobMulRatio.Name = "NumericUpDown_BlobMulRatio"
        Me.NumericUpDown_BlobMulRatio.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label82
        '
        resources.ApplyResources(Me.Label82, "Label82")
        Me.Label82.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label82.Name = "Label82"
        '
        'CheckBox_UseReconstructBW
        '
        resources.ApplyResources(Me.CheckBox_UseReconstructBW, "CheckBox_UseReconstructBW")
        Me.CheckBox_UseReconstructBW.Name = "CheckBox_UseReconstructBW"
        Me.CheckBox_UseReconstructBW.UseVisualStyleBackColor = True
        '
        'CheckBox_Center
        '
        resources.ApplyResources(Me.CheckBox_Center, "CheckBox_Center")
        Me.CheckBox_Center.Name = "CheckBox_Center"
        '
        'GroupBox_MuraRatio
        '
        resources.ApplyResources(Me.GroupBox_MuraRatio, "GroupBox_MuraRatio")
        Me.GroupBox_MuraRatio.Controls.Add(Me.GroupBox4)
        Me.GroupBox_MuraRatio.Controls.Add(Me.GroupBox3)
        Me.GroupBox_MuraRatio.Controls.Add(Me.CheckBox_UseBaseLine)
        Me.GroupBox_MuraRatio.Name = "GroupBox_MuraRatio"
        Me.GroupBox_MuraRatio.TabStop = False
        '
        'GroupBox4
        '
        resources.ApplyResources(Me.GroupBox4, "GroupBox4")
        Me.GroupBox4.Controls.Add(Me.Label21)
        Me.GroupBox4.Controls.Add(Me.Label22)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_MacroPowerY)
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_MacroPowerX)
        Me.GroupBox4.Controls.Add(Me.Num_ResizeCount_Max)
        Me.GroupBox4.Controls.Add(Me.Label23)
        Me.GroupBox4.Controls.Add(Me.Num_ResizeCount_Mid2)
        Me.GroupBox4.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.TabStop = False
        '
        'Label21
        '
        resources.ApplyResources(Me.Label21, "Label21")
        Me.Label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label21.Name = "Label21"
        '
        'Label22
        '
        resources.ApplyResources(Me.Label22, "Label22")
        Me.Label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label22.Name = "Label22"
        '
        'NumericUpDown_MacroPowerY
        '
        resources.ApplyResources(Me.NumericUpDown_MacroPowerY, "NumericUpDown_MacroPowerY")
        Me.NumericUpDown_MacroPowerY.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerY.Name = "NumericUpDown_MacroPowerY"
        Me.NumericUpDown_MacroPowerY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_MacroPowerX
        '
        resources.ApplyResources(Me.NumericUpDown_MacroPowerX, "NumericUpDown_MacroPowerX")
        Me.NumericUpDown_MacroPowerX.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerX.Name = "NumericUpDown_MacroPowerX"
        Me.NumericUpDown_MacroPowerX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Num_ResizeCount_Max
        '
        resources.ApplyResources(Me.Num_ResizeCount_Max, "Num_ResizeCount_Max")
        Me.Num_ResizeCount_Max.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.Num_ResizeCount_Max.Minimum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.Num_ResizeCount_Max.Name = "Num_ResizeCount_Max"
        Me.Num_ResizeCount_Max.Value = New Decimal(New Integer() {2, 0, 0, 0})
        '
        'Label23
        '
        resources.ApplyResources(Me.Label23, "Label23")
        Me.Label23.Name = "Label23"
        '
        'Num_ResizeCount_Mid2
        '
        resources.ApplyResources(Me.Num_ResizeCount_Mid2, "Num_ResizeCount_Mid2")
        Me.Num_ResizeCount_Mid2.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.Num_ResizeCount_Mid2.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Num_ResizeCount_Mid2.Name = "Num_ResizeCount_Mid2"
        Me.Num_ResizeCount_Mid2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'GroupBox3
        '
        resources.ApplyResources(Me.GroupBox3, "GroupBox3")
        Me.GroupBox3.Controls.Add(Me.Num_ResizeCount_Min)
        Me.GroupBox3.Controls.Add(Me.Num_ResizeCount_Mid)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.TabStop = False
        '
        'Num_ResizeCount_Min
        '
        resources.ApplyResources(Me.Num_ResizeCount_Min, "Num_ResizeCount_Min")
        Me.Num_ResizeCount_Min.Maximum = New Decimal(New Integer() {8, 0, 0, 0})
        Me.Num_ResizeCount_Min.Name = "Num_ResizeCount_Min"
        '
        'Num_ResizeCount_Mid
        '
        resources.ApplyResources(Me.Num_ResizeCount_Mid, "Num_ResizeCount_Mid")
        Me.Num_ResizeCount_Mid.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.Num_ResizeCount_Mid.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Num_ResizeCount_Mid.Name = "Num_ResizeCount_Mid"
        Me.Num_ResizeCount_Mid.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label20
        '
        resources.ApplyResources(Me.Label20, "Label20")
        Me.Label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label20.Name = "Label20"
        '
        'CheckBox_UseBaseLine
        '
        resources.ApplyResources(Me.CheckBox_UseBaseLine, "CheckBox_UseBaseLine")
        Me.CheckBox_UseBaseLine.Name = "CheckBox_UseBaseLine"
        Me.CheckBox_UseBaseLine.UseVisualStyleBackColor = True
        '
        'GroupBox_Parameter
        '
        resources.ApplyResources(Me.GroupBox_Parameter, "GroupBox_Parameter")
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_BlackBlobMura_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_WhiteBlobMura_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.Label25)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_BlackMacroMura_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_BlackBlobMura_ReconstructHeight)
        Me.GroupBox_Parameter.Controls.Add(Me.Label2)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_WhiteBlobMura_ReconstructHeight)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_WhiteMacroMura_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_ReconstructHeight)
        Me.GroupBox_Parameter.Name = "GroupBox_Parameter"
        Me.GroupBox_Parameter.TabStop = False
        '
        'NUD_BlackBlobMura_ReconstructLow
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_ReconstructLow, "NUD_BlackBlobMura_ReconstructLow")
        Me.NUD_BlackBlobMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBlobMura_ReconstructLow.Name = "NUD_BlackBlobMura_ReconstructLow"
        '
        'NUD_WhiteBlobMura_ReconstructLow
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_ReconstructLow, "NUD_WhiteBlobMura_ReconstructLow")
        Me.NUD_WhiteBlobMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_ReconstructLow.Name = "NUD_WhiteBlobMura_ReconstructLow"
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        '
        'NUD_BlackMacroMura_Threshold
        '
        resources.ApplyResources(Me.NUD_BlackMacroMura_Threshold, "NUD_BlackMacroMura_Threshold")
        Me.NUD_BlackMacroMura_Threshold.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackMacroMura_Threshold.Name = "NUD_BlackMacroMura_Threshold"
        '
        'NUD_BlackBlobMura_ReconstructHeight
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_ReconstructHeight, "NUD_BlackBlobMura_ReconstructHeight")
        Me.NUD_BlackBlobMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBlobMura_ReconstructHeight.Name = "NUD_BlackBlobMura_ReconstructHeight"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'NUD_WhiteBlobMura_ReconstructHeight
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_ReconstructHeight, "NUD_WhiteBlobMura_ReconstructHeight")
        Me.NUD_WhiteBlobMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_ReconstructHeight.Name = "NUD_WhiteBlobMura_ReconstructHeight"
        '
        'NUD_WhiteMacroMura_Threshold
        '
        resources.ApplyResources(Me.NUD_WhiteMacroMura_Threshold, "NUD_WhiteMacroMura_Threshold")
        Me.NUD_WhiteMacroMura_Threshold.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteMacroMura_Threshold.Name = "NUD_WhiteMacroMura_Threshold"
        '
        'Label_ReconstructLow
        '
        resources.ApplyResources(Me.Label_ReconstructLow, "Label_ReconstructLow")
        Me.Label_ReconstructLow.Name = "Label_ReconstructLow"
        '
        'Label_ReconstructHeight
        '
        resources.ApplyResources(Me.Label_ReconstructHeight, "Label_ReconstructHeight")
        Me.Label_ReconstructHeight.Name = "Label_ReconstructHeight"
        '
        'GroupBox_Modify
        '
        resources.ApplyResources(Me.GroupBox_Modify, "GroupBox_Modify")
        Me.GroupBox_Modify.Controls.Add(Me.CheckBox_Show)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Manual)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Finish)
        Me.GroupBox_Modify.Controls.Add(Me.GroupBox_Area)
        Me.GroupBox_Modify.Name = "GroupBox_Modify"
        Me.GroupBox_Modify.TabStop = False
        '
        'CheckBox_Show
        '
        resources.ApplyResources(Me.CheckBox_Show, "CheckBox_Show")
        Me.CheckBox_Show.Name = "CheckBox_Show"
        '
        'RadioButton_Manual
        '
        resources.ApplyResources(Me.RadioButton_Manual, "RadioButton_Manual")
        Me.RadioButton_Manual.Name = "RadioButton_Manual"
        '
        'RadioButton_Finish
        '
        resources.ApplyResources(Me.RadioButton_Finish, "RadioButton_Finish")
        Me.RadioButton_Finish.Name = "RadioButton_Finish"
        '
        'GroupBox_Area
        '
        resources.ApplyResources(Me.GroupBox_Area, "GroupBox_Area")
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaRight)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaRight)
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaLeft)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaLeft)
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaTop)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaBottom)
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaBottom)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaTop)
        Me.GroupBox_Area.Name = "GroupBox_Area"
        Me.GroupBox_Area.TabStop = False
        '
        'NumericUpDown_AreaRight
        '
        resources.ApplyResources(Me.NumericUpDown_AreaRight, "NumericUpDown_AreaRight")
        Me.NumericUpDown_AreaRight.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_AreaRight.Name = "NumericUpDown_AreaRight"
        '
        'Label_AreaRight
        '
        resources.ApplyResources(Me.Label_AreaRight, "Label_AreaRight")
        Me.Label_AreaRight.Name = "Label_AreaRight"
        '
        'NumericUpDown_AreaLeft
        '
        resources.ApplyResources(Me.NumericUpDown_AreaLeft, "NumericUpDown_AreaLeft")
        Me.NumericUpDown_AreaLeft.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_AreaLeft.Name = "NumericUpDown_AreaLeft"
        '
        'Label_AreaLeft
        '
        resources.ApplyResources(Me.Label_AreaLeft, "Label_AreaLeft")
        Me.Label_AreaLeft.Name = "Label_AreaLeft"
        '
        'NumericUpDown_AreaTop
        '
        resources.ApplyResources(Me.NumericUpDown_AreaTop, "NumericUpDown_AreaTop")
        Me.NumericUpDown_AreaTop.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_AreaTop.Name = "NumericUpDown_AreaTop"
        '
        'Label_AreaBottom
        '
        resources.ApplyResources(Me.Label_AreaBottom, "Label_AreaBottom")
        Me.Label_AreaBottom.Name = "Label_AreaBottom"
        '
        'NumericUpDown_AreaBottom
        '
        resources.ApplyResources(Me.NumericUpDown_AreaBottom, "NumericUpDown_AreaBottom")
        Me.NumericUpDown_AreaBottom.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_AreaBottom.Name = "NumericUpDown_AreaBottom"
        '
        'Label_AreaTop
        '
        resources.ApplyResources(Me.Label_AreaTop, "Label_AreaTop")
        Me.Label_AreaTop.Name = "Label_AreaTop"
        '
        'TabPage_CPD
        '
        resources.ApplyResources(Me.TabPage_CPD, "TabPage_CPD")
        Me.TabPage_CPD.Controls.Add(Me.GroupBox_WithoutCoreCPDRecipe)
        Me.TabPage_CPD.Controls.Add(Me.CheckBox_WithoutCoreCPD_Enable)
        Me.TabPage_CPD.Controls.Add(Me.GroupBox_WithCoreCPDRecipe)
        Me.TabPage_CPD.Controls.Add(Me.CheckBox_WithCoreCPD_Enable)
        Me.TabPage_CPD.Name = "TabPage_CPD"
        Me.TabPage_CPD.UseVisualStyleBackColor = True
        '
        'GroupBox_WithoutCoreCPDRecipe
        '
        resources.ApplyResources(Me.GroupBox_WithoutCoreCPDRecipe, "GroupBox_WithoutCoreCPDRecipe")
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label64)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label65)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label62)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label63)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label60)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label61)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPDElongation_High)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label47)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label50)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label39)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label51)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label49)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.Label46)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreBlackCPD_ThLow)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow)
        Me.GroupBox_WithoutCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High)
        Me.GroupBox_WithoutCoreCPDRecipe.Name = "GroupBox_WithoutCoreCPDRecipe"
        Me.GroupBox_WithoutCoreCPDRecipe.TabStop = False
        '
        'Label64
        '
        resources.ApplyResources(Me.Label64, "Label64")
        Me.Label64.Name = "Label64"
        '
        'Label65
        '
        resources.ApplyResources(Me.Label65, "Label65")
        Me.Label65.Name = "Label65"
        '
        'Label62
        '
        resources.ApplyResources(Me.Label62, "Label62")
        Me.Label62.Name = "Label62"
        '
        'Label63
        '
        resources.ApplyResources(Me.Label63, "Label63")
        Me.Label63.Name = "Label63"
        '
        'Label60
        '
        resources.ApplyResources(Me.Label60, "Label60")
        Me.Label60.Name = "Label60"
        '
        'NumericUpDown_WithoutCoreBlackCPDCompactness_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low, "NumericUpDown_WithoutCoreBlackCPDCompactness_Low")
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low.Name = "NumericUpDown_WithoutCoreBlackCPDCompactness_Low"
        '
        'Label61
        '
        resources.ApplyResources(Me.Label61, "Label61")
        Me.Label61.Name = "Label61"
        '
        'NumericUpDown_WithoutCoreBlackCPDBreadth_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low, "NumericUpDown_WithoutCoreBlackCPDBreadth_Low")
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low.Name = "NumericUpDown_WithoutCoreBlackCPDBreadth_Low"
        '
        'NumericUpDown_WithoutCoreBlackCPDBreadth_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High, "NumericUpDown_WithoutCoreBlackCPDBreadth_High")
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High.Name = "NumericUpDown_WithoutCoreBlackCPDBreadth_High"
        '
        'NumericUpDown_WithoutCoreBlackCPDElongation_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low, "NumericUpDown_WithoutCoreBlackCPDElongation_Low")
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low.Name = "NumericUpDown_WithoutCoreBlackCPDElongation_Low"
        '
        'NumericUpDown_WithoutCoreBlackCPDElongation_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPDElongation_High, "NumericUpDown_WithoutCoreBlackCPDElongation_High")
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_High.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPDElongation_High.Name = "NumericUpDown_WithoutCoreBlackCPDElongation_High"
        '
        'Label47
        '
        resources.ApplyResources(Me.Label47, "Label47")
        Me.Label47.Name = "Label47"
        '
        'NumericUpDown_WithoutCoreBlackCPDCompactness_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High, "NumericUpDown_WithoutCoreBlackCPDCompactness_High")
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High.Name = "NumericUpDown_WithoutCoreBlackCPDCompactness_High"
        '
        'NumericUpDown_WithoutCoreWhiteCPDCompactness_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low, "NumericUpDown_WithoutCoreWhiteCPDCompactness_Low")
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low.Name = "NumericUpDown_WithoutCoreWhiteCPDCompactness_Low"
        '
        'NumericUpDown_WithoutCoreWhiteCPDBreadth_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low, "NumericUpDown_WithoutCoreWhiteCPDBreadth_Low")
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low.Name = "NumericUpDown_WithoutCoreWhiteCPDBreadth_Low"
        '
        'Label50
        '
        resources.ApplyResources(Me.Label50, "Label50")
        Me.Label50.Name = "Label50"
        '
        'NumericUpDown_WithoutCoreWhiteCPDBreadth_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High, "NumericUpDown_WithoutCoreWhiteCPDBreadth_High")
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High.Name = "NumericUpDown_WithoutCoreWhiteCPDBreadth_High"
        '
        'NumericUpDown_WithoutCoreBlackCPD_ThHigh
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh, "NumericUpDown_WithoutCoreBlackCPD_ThHigh")
        Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh.Name = "NumericUpDown_WithoutCoreBlackCPD_ThHigh"
        '
        'Label39
        '
        resources.ApplyResources(Me.Label39, "Label39")
        Me.Label39.Name = "Label39"
        '
        'NumericUpDown_WithoutCoreWhiteCPD_ThHigh
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh, "NumericUpDown_WithoutCoreWhiteCPD_ThHigh")
        Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh.Name = "NumericUpDown_WithoutCoreWhiteCPD_ThHigh"
        '
        'NumericUpDown_WithoutCoreWhiteCPDElongation_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low, "NumericUpDown_WithoutCoreWhiteCPDElongation_Low")
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low.Name = "NumericUpDown_WithoutCoreWhiteCPDElongation_Low"
        '
        'Label51
        '
        resources.ApplyResources(Me.Label51, "Label51")
        Me.Label51.Name = "Label51"
        '
        'NumericUpDown_WithoutCoreWhiteCPDElongation_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High, "NumericUpDown_WithoutCoreWhiteCPDElongation_High")
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High.Name = "NumericUpDown_WithoutCoreWhiteCPDElongation_High"
        '
        'Label49
        '
        resources.ApplyResources(Me.Label49, "Label49")
        Me.Label49.Name = "Label49"
        '
        'Label46
        '
        resources.ApplyResources(Me.Label46, "Label46")
        Me.Label46.Name = "Label46"
        '
        'NumericUpDown_WithoutCoreBlackCPD_ThLow
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreBlackCPD_ThLow, "NumericUpDown_WithoutCoreBlackCPD_ThLow")
        Me.NumericUpDown_WithoutCoreBlackCPD_ThLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreBlackCPD_ThLow.Name = "NumericUpDown_WithoutCoreBlackCPD_ThLow"
        '
        'NumericUpDown_WithoutCoreWhiteCPD_ThLow
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow, "NumericUpDown_WithoutCoreWhiteCPD_ThLow")
        Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow.Name = "NumericUpDown_WithoutCoreWhiteCPD_ThLow"
        '
        'NumericUpDown_WithoutCoreWhiteCPDCompactness_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High, "NumericUpDown_WithoutCoreWhiteCPDCompactness_High")
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High.DecimalPlaces = 2
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High.Name = "NumericUpDown_WithoutCoreWhiteCPDCompactness_High"
        '
        'CheckBox_WithoutCoreCPD_Enable
        '
        resources.ApplyResources(Me.CheckBox_WithoutCoreCPD_Enable, "CheckBox_WithoutCoreCPD_Enable")
        Me.CheckBox_WithoutCoreCPD_Enable.Name = "CheckBox_WithoutCoreCPD_Enable"
        '
        'GroupBox_WithCoreCPDRecipe
        '
        resources.ApplyResources(Me.GroupBox_WithCoreCPDRecipe, "GroupBox_WithCoreCPDRecipe")
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label58)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label59)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label56)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label57)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label48)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label40)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPDCompactness_High)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPDCompactness_Low)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPDBreadth_Low)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPDBreadth_High)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPDElongation_Low)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPDElongation_High)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPDCompactness_High)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPDBreadth_High)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label45)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPDElongation_Low)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label44)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPDElongation_High)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label43)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPD_ThLow)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPD_ThLow)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label37)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label36)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.Label38)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreWhiteCPD_ThHigh)
        Me.GroupBox_WithCoreCPDRecipe.Controls.Add(Me.NumericUpDown_WithCoreBlackCPD_ThHigh)
        Me.GroupBox_WithCoreCPDRecipe.Name = "GroupBox_WithCoreCPDRecipe"
        Me.GroupBox_WithCoreCPDRecipe.TabStop = False
        '
        'Label58
        '
        resources.ApplyResources(Me.Label58, "Label58")
        Me.Label58.Name = "Label58"
        '
        'Label59
        '
        resources.ApplyResources(Me.Label59, "Label59")
        Me.Label59.Name = "Label59"
        '
        'Label56
        '
        resources.ApplyResources(Me.Label56, "Label56")
        Me.Label56.Name = "Label56"
        '
        'Label57
        '
        resources.ApplyResources(Me.Label57, "Label57")
        Me.Label57.Name = "Label57"
        '
        'Label48
        '
        resources.ApplyResources(Me.Label48, "Label48")
        Me.Label48.Name = "Label48"
        '
        'Label40
        '
        resources.ApplyResources(Me.Label40, "Label40")
        Me.Label40.Name = "Label40"
        '
        'NumericUpDown_WithCoreBlackCPDCompactness_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPDCompactness_High, "NumericUpDown_WithCoreBlackCPDCompactness_High")
        Me.NumericUpDown_WithCoreBlackCPDCompactness_High.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreBlackCPDCompactness_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreBlackCPDCompactness_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPDCompactness_High.Name = "NumericUpDown_WithCoreBlackCPDCompactness_High"
        '
        'NumericUpDown_WithCoreBlackCPDCompactness_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPDCompactness_Low, "NumericUpDown_WithCoreBlackCPDCompactness_Low")
        Me.NumericUpDown_WithCoreBlackCPDCompactness_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreBlackCPDCompactness_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreBlackCPDCompactness_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPDCompactness_Low.Name = "NumericUpDown_WithCoreBlackCPDCompactness_Low"
        '
        'NumericUpDown_WithCoreBlackCPDBreadth_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPDBreadth_Low, "NumericUpDown_WithCoreBlackCPDBreadth_Low")
        Me.NumericUpDown_WithCoreBlackCPDBreadth_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreBlackCPDBreadth_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreBlackCPDBreadth_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPDBreadth_Low.Name = "NumericUpDown_WithCoreBlackCPDBreadth_Low"
        '
        'NumericUpDown_WithCoreBlackCPDBreadth_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPDBreadth_High, "NumericUpDown_WithCoreBlackCPDBreadth_High")
        Me.NumericUpDown_WithCoreBlackCPDBreadth_High.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreBlackCPDBreadth_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreBlackCPDBreadth_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPDBreadth_High.Name = "NumericUpDown_WithCoreBlackCPDBreadth_High"
        '
        'NumericUpDown_WithCoreBlackCPDElongation_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPDElongation_Low, "NumericUpDown_WithCoreBlackCPDElongation_Low")
        Me.NumericUpDown_WithCoreBlackCPDElongation_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreBlackCPDElongation_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreBlackCPDElongation_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPDElongation_Low.Name = "NumericUpDown_WithCoreBlackCPDElongation_Low"
        '
        'NumericUpDown_WithCoreBlackCPDElongation_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPDElongation_High, "NumericUpDown_WithCoreBlackCPDElongation_High")
        Me.NumericUpDown_WithCoreBlackCPDElongation_High.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreBlackCPDElongation_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreBlackCPDElongation_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPDElongation_High.Name = "NumericUpDown_WithCoreBlackCPDElongation_High"
        '
        'NumericUpDown_WithCoreWhiteCPDCompactness_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPDCompactness_High, "NumericUpDown_WithCoreWhiteCPDCompactness_High")
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_High.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_High.Name = "NumericUpDown_WithCoreWhiteCPDCompactness_High"
        '
        'NumericUpDown_WithCoreWhiteCPDCompactness_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low, "NumericUpDown_WithCoreWhiteCPDCompactness_Low")
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low.Name = "NumericUpDown_WithCoreWhiteCPDCompactness_Low"
        '
        'NumericUpDown_WithCoreWhiteCPDBreadth_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low, "NumericUpDown_WithCoreWhiteCPDBreadth_Low")
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low.Name = "NumericUpDown_WithCoreWhiteCPDBreadth_Low"
        '
        'NumericUpDown_WithCoreWhiteCPDBreadth_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPDBreadth_High, "NumericUpDown_WithCoreWhiteCPDBreadth_High")
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_High.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPDBreadth_High.Name = "NumericUpDown_WithCoreWhiteCPDBreadth_High"
        '
        'Label45
        '
        resources.ApplyResources(Me.Label45, "Label45")
        Me.Label45.Name = "Label45"
        '
        'NumericUpDown_WithCoreWhiteCPDElongation_Low
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPDElongation_Low, "NumericUpDown_WithCoreWhiteCPDElongation_Low")
        Me.NumericUpDown_WithCoreWhiteCPDElongation_Low.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreWhiteCPDElongation_Low.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreWhiteCPDElongation_Low.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPDElongation_Low.Name = "NumericUpDown_WithCoreWhiteCPDElongation_Low"
        '
        'Label44
        '
        resources.ApplyResources(Me.Label44, "Label44")
        Me.Label44.Name = "Label44"
        '
        'NumericUpDown_WithCoreWhiteCPDElongation_High
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPDElongation_High, "NumericUpDown_WithCoreWhiteCPDElongation_High")
        Me.NumericUpDown_WithCoreWhiteCPDElongation_High.DecimalPlaces = 2
        Me.NumericUpDown_WithCoreWhiteCPDElongation_High.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_WithCoreWhiteCPDElongation_High.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPDElongation_High.Name = "NumericUpDown_WithCoreWhiteCPDElongation_High"
        '
        'Label43
        '
        resources.ApplyResources(Me.Label43, "Label43")
        Me.Label43.Name = "Label43"
        '
        'NumericUpDown_WithCoreWhiteCPD_ThLow
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPD_ThLow, "NumericUpDown_WithCoreWhiteCPD_ThLow")
        Me.NumericUpDown_WithCoreWhiteCPD_ThLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPD_ThLow.Name = "NumericUpDown_WithCoreWhiteCPD_ThLow"
        '
        'NumericUpDown_WithCoreBlackCPD_ThLow
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPD_ThLow, "NumericUpDown_WithCoreBlackCPD_ThLow")
        Me.NumericUpDown_WithCoreBlackCPD_ThLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPD_ThLow.Name = "NumericUpDown_WithCoreBlackCPD_ThLow"
        '
        'Label37
        '
        resources.ApplyResources(Me.Label37, "Label37")
        Me.Label37.Name = "Label37"
        '
        'Label36
        '
        resources.ApplyResources(Me.Label36, "Label36")
        Me.Label36.Name = "Label36"
        '
        'Label38
        '
        resources.ApplyResources(Me.Label38, "Label38")
        Me.Label38.Name = "Label38"
        '
        'NumericUpDown_WithCoreWhiteCPD_ThHigh
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreWhiteCPD_ThHigh, "NumericUpDown_WithCoreWhiteCPD_ThHigh")
        Me.NumericUpDown_WithCoreWhiteCPD_ThHigh.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreWhiteCPD_ThHigh.Name = "NumericUpDown_WithCoreWhiteCPD_ThHigh"
        '
        'NumericUpDown_WithCoreBlackCPD_ThHigh
        '
        resources.ApplyResources(Me.NumericUpDown_WithCoreBlackCPD_ThHigh, "NumericUpDown_WithCoreBlackCPD_ThHigh")
        Me.NumericUpDown_WithCoreBlackCPD_ThHigh.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WithCoreBlackCPD_ThHigh.Name = "NumericUpDown_WithCoreBlackCPD_ThHigh"
        '
        'CheckBox_WithCoreCPD_Enable
        '
        resources.ApplyResources(Me.CheckBox_WithCoreCPD_Enable, "CheckBox_WithCoreCPD_Enable")
        Me.CheckBox_WithCoreCPD_Enable.Name = "CheckBox_WithCoreCPD_Enable"
        '
        'TabPage_Rim
        '
        resources.ApplyResources(Me.TabPage_Rim, "TabPage_Rim")
        Me.TabPage_Rim.Controls.Add(Me.GroupBox_GoldenSampleParameter)
        Me.TabPage_Rim.Controls.Add(Me.GroupBox_RimType)
        Me.TabPage_Rim.Controls.Add(Me.GroupBox_RimParameter)
        Me.TabPage_Rim.Controls.Add(Me.CheckBox_Rim)
        Me.TabPage_Rim.Name = "TabPage_Rim"
        Me.TabPage_Rim.UseVisualStyleBackColor = True
        '
        'GroupBox_GoldenSampleParameter
        '
        resources.ApplyResources(Me.GroupBox_GoldenSampleParameter, "GroupBox_GoldenSampleParameter")
        Me.GroupBox_GoldenSampleParameter.Controls.Add(Me.NumericUpDown_Resize)
        Me.GroupBox_GoldenSampleParameter.Controls.Add(Me.Label_Resize)
        Me.GroupBox_GoldenSampleParameter.Controls.Add(Me.Label_Smooth)
        Me.GroupBox_GoldenSampleParameter.Controls.Add(Me.NumericUpDown_Smooth)
        Me.GroupBox_GoldenSampleParameter.Name = "GroupBox_GoldenSampleParameter"
        Me.GroupBox_GoldenSampleParameter.TabStop = False
        '
        'NumericUpDown_Resize
        '
        resources.ApplyResources(Me.NumericUpDown_Resize, "NumericUpDown_Resize")
        Me.NumericUpDown_Resize.Name = "NumericUpDown_Resize"
        '
        'Label_Resize
        '
        resources.ApplyResources(Me.Label_Resize, "Label_Resize")
        Me.Label_Resize.Name = "Label_Resize"
        '
        'Label_Smooth
        '
        resources.ApplyResources(Me.Label_Smooth, "Label_Smooth")
        Me.Label_Smooth.Name = "Label_Smooth"
        '
        'NumericUpDown_Smooth
        '
        resources.ApplyResources(Me.NumericUpDown_Smooth, "NumericUpDown_Smooth")
        Me.NumericUpDown_Smooth.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_Smooth.Name = "NumericUpDown_Smooth"
        '
        'GroupBox_RimType
        '
        resources.ApplyResources(Me.GroupBox_RimType, "GroupBox_RimType")
        Me.GroupBox_RimType.Controls.Add(Me.GroupBox_RimModify)
        Me.GroupBox_RimType.Name = "GroupBox_RimType"
        Me.GroupBox_RimType.TabStop = False
        '
        'GroupBox_RimModify
        '
        resources.ApplyResources(Me.GroupBox_RimModify, "GroupBox_RimModify")
        Me.GroupBox_RimModify.Controls.Add(Me.CheckBox_ShowRound)
        Me.GroupBox_RimModify.Controls.Add(Me.RadioButton_RoundManual)
        Me.GroupBox_RimModify.Controls.Add(Me.RadioButton_RoundFinish)
        Me.GroupBox_RimModify.Controls.Add(Me.GroupBox_Round)
        Me.GroupBox_RimModify.Name = "GroupBox_RimModify"
        Me.GroupBox_RimModify.TabStop = False
        '
        'CheckBox_ShowRound
        '
        resources.ApplyResources(Me.CheckBox_ShowRound, "CheckBox_ShowRound")
        Me.CheckBox_ShowRound.Name = "CheckBox_ShowRound"
        '
        'RadioButton_RoundManual
        '
        resources.ApplyResources(Me.RadioButton_RoundManual, "RadioButton_RoundManual")
        Me.RadioButton_RoundManual.Name = "RadioButton_RoundManual"
        '
        'RadioButton_RoundFinish
        '
        resources.ApplyResources(Me.RadioButton_RoundFinish, "RadioButton_RoundFinish")
        Me.RadioButton_RoundFinish.Name = "RadioButton_RoundFinish"
        '
        'GroupBox_Round
        '
        resources.ApplyResources(Me.GroupBox_Round, "GroupBox_Round")
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimRight)
        Me.GroupBox_Round.Controls.Add(Me.Label_Right)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimLeft)
        Me.GroupBox_Round.Controls.Add(Me.Label_Left)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimTop)
        Me.GroupBox_Round.Controls.Add(Me.Label_Bottom)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimBottom)
        Me.GroupBox_Round.Controls.Add(Me.Label_Top)
        Me.GroupBox_Round.Name = "GroupBox_Round"
        Me.GroupBox_Round.TabStop = False
        '
        'NumericUpDown_RimRight
        '
        resources.ApplyResources(Me.NumericUpDown_RimRight, "NumericUpDown_RimRight")
        Me.NumericUpDown_RimRight.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_RimRight.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_RimRight.Name = "NumericUpDown_RimRight"
        Me.NumericUpDown_RimRight.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Right
        '
        resources.ApplyResources(Me.Label_Right, "Label_Right")
        Me.Label_Right.Name = "Label_Right"
        '
        'NumericUpDown_RimLeft
        '
        resources.ApplyResources(Me.NumericUpDown_RimLeft, "NumericUpDown_RimLeft")
        Me.NumericUpDown_RimLeft.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_RimLeft.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_RimLeft.Name = "NumericUpDown_RimLeft"
        Me.NumericUpDown_RimLeft.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Left
        '
        resources.ApplyResources(Me.Label_Left, "Label_Left")
        Me.Label_Left.Name = "Label_Left"
        '
        'NumericUpDown_RimTop
        '
        resources.ApplyResources(Me.NumericUpDown_RimTop, "NumericUpDown_RimTop")
        Me.NumericUpDown_RimTop.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_RimTop.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_RimTop.Name = "NumericUpDown_RimTop"
        Me.NumericUpDown_RimTop.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Bottom
        '
        resources.ApplyResources(Me.Label_Bottom, "Label_Bottom")
        Me.Label_Bottom.Name = "Label_Bottom"
        '
        'NumericUpDown_RimBottom
        '
        resources.ApplyResources(Me.NumericUpDown_RimBottom, "NumericUpDown_RimBottom")
        Me.NumericUpDown_RimBottom.Maximum = New Decimal(New Integer() {300, 0, 0, 0})
        Me.NumericUpDown_RimBottom.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_RimBottom.Name = "NumericUpDown_RimBottom"
        Me.NumericUpDown_RimBottom.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Top
        '
        resources.ApplyResources(Me.Label_Top, "Label_Top")
        Me.Label_Top.Name = "Label_Top"
        '
        'GroupBox_RimParameter
        '
        resources.ApplyResources(Me.GroupBox_RimParameter, "GroupBox_RimParameter")
        Me.GroupBox_RimParameter.Controls.Add(Me.Label3)
        Me.GroupBox_RimParameter.Controls.Add(Me.NumericUpDown_BlackMura_RimLow)
        Me.GroupBox_RimParameter.Controls.Add(Me.NumericUpDown_BlackMura_RimHeight)
        Me.GroupBox_RimParameter.Controls.Add(Me.NumericUpDown_WhiteMura_RimLow)
        Me.GroupBox_RimParameter.Controls.Add(Me.Label_RoundLow)
        Me.GroupBox_RimParameter.Controls.Add(Me.Label_RoundHeight)
        Me.GroupBox_RimParameter.Controls.Add(Me.NumericUpDown_WhiteMura_RimHeight)
        Me.GroupBox_RimParameter.Name = "GroupBox_RimParameter"
        Me.GroupBox_RimParameter.TabStop = False
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'NumericUpDown_BlackMura_RimLow
        '
        resources.ApplyResources(Me.NumericUpDown_BlackMura_RimLow, "NumericUpDown_BlackMura_RimLow")
        Me.NumericUpDown_BlackMura_RimLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_RimLow.Name = "NumericUpDown_BlackMura_RimLow"
        '
        'NumericUpDown_BlackMura_RimHeight
        '
        resources.ApplyResources(Me.NumericUpDown_BlackMura_RimHeight, "NumericUpDown_BlackMura_RimHeight")
        Me.NumericUpDown_BlackMura_RimHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_RimHeight.Name = "NumericUpDown_BlackMura_RimHeight"
        '
        'NumericUpDown_WhiteMura_RimLow
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteMura_RimLow, "NumericUpDown_WhiteMura_RimLow")
        Me.NumericUpDown_WhiteMura_RimLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_RimLow.Name = "NumericUpDown_WhiteMura_RimLow"
        '
        'Label_RoundLow
        '
        resources.ApplyResources(Me.Label_RoundLow, "Label_RoundLow")
        Me.Label_RoundLow.Name = "Label_RoundLow"
        '
        'Label_RoundHeight
        '
        resources.ApplyResources(Me.Label_RoundHeight, "Label_RoundHeight")
        Me.Label_RoundHeight.Name = "Label_RoundHeight"
        '
        'NumericUpDown_WhiteMura_RimHeight
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteMura_RimHeight, "NumericUpDown_WhiteMura_RimHeight")
        Me.NumericUpDown_WhiteMura_RimHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_RimHeight.Name = "NumericUpDown_WhiteMura_RimHeight"
        '
        'CheckBox_Rim
        '
        resources.ApplyResources(Me.CheckBox_Rim, "CheckBox_Rim")
        Me.CheckBox_Rim.Name = "CheckBox_Rim"
        '
        'TabPage_Band
        '
        resources.ApplyResources(Me.TabPage_Band, "TabPage_Band")
        Me.TabPage_Band.Controls.Add(Me.CheckBox_Band)
        Me.TabPage_Band.Controls.Add(Me.GroupBox_BandParameter)
        Me.TabPage_Band.Controls.Add(Me.GroupBox_BandModify)
        Me.TabPage_Band.Name = "TabPage_Band"
        Me.TabPage_Band.UseVisualStyleBackColor = True
        '
        'CheckBox_Band
        '
        resources.ApplyResources(Me.CheckBox_Band, "CheckBox_Band")
        Me.CheckBox_Band.Name = "CheckBox_Band"
        '
        'GroupBox_BandParameter
        '
        resources.ApplyResources(Me.GroupBox_BandParameter, "GroupBox_BandParameter")
        Me.GroupBox_BandParameter.Controls.Add(Me.Label6)
        Me.GroupBox_BandParameter.Controls.Add(Me.Label27)
        Me.GroupBox_BandParameter.Controls.Add(Me.NumericUpDown_BlackVBand_Threshold)
        Me.GroupBox_BandParameter.Controls.Add(Me.NumericUpDown_BlackHBand_Threshold)
        Me.GroupBox_BandParameter.Controls.Add(Me.NumericUpDown_WhiteHBand_Threshold)
        Me.GroupBox_BandParameter.Controls.Add(Me.NumericUpDown_WhiteVBand_Threshold)
        Me.GroupBox_BandParameter.Controls.Add(Me.Label_BlackBand_Thrshold)
        Me.GroupBox_BandParameter.Controls.Add(Me.Label_HBand_Thrshold)
        Me.GroupBox_BandParameter.Controls.Add(Me.NumericUpDown_BandMura_SmoothCount)
        Me.GroupBox_BandParameter.Controls.Add(Me.Label_Band_SmoothCount)
        Me.GroupBox_BandParameter.Controls.Add(Me.NumericUpDown_BandMura_ResizeCount)
        Me.GroupBox_BandParameter.Controls.Add(Me.Label_Band_ResizeCount)
        Me.GroupBox_BandParameter.Name = "GroupBox_BandParameter"
        Me.GroupBox_BandParameter.TabStop = False
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'Label27
        '
        resources.ApplyResources(Me.Label27, "Label27")
        Me.Label27.Name = "Label27"
        '
        'NumericUpDown_BlackVBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_BlackVBand_Threshold, "NumericUpDown_BlackVBand_Threshold")
        Me.NumericUpDown_BlackVBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlackVBand_Threshold.Name = "NumericUpDown_BlackVBand_Threshold"
        Me.NumericUpDown_BlackVBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_BlackHBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_BlackHBand_Threshold, "NumericUpDown_BlackHBand_Threshold")
        Me.NumericUpDown_BlackHBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_BlackHBand_Threshold.Name = "NumericUpDown_BlackHBand_Threshold"
        Me.NumericUpDown_BlackHBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_WhiteHBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteHBand_Threshold, "NumericUpDown_WhiteHBand_Threshold")
        Me.NumericUpDown_WhiteHBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_WhiteHBand_Threshold.Name = "NumericUpDown_WhiteHBand_Threshold"
        Me.NumericUpDown_WhiteHBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_WhiteVBand_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteVBand_Threshold, "NumericUpDown_WhiteVBand_Threshold")
        Me.NumericUpDown_WhiteVBand_Threshold.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_WhiteVBand_Threshold.Name = "NumericUpDown_WhiteVBand_Threshold"
        Me.NumericUpDown_WhiteVBand_Threshold.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_BlackBand_Thrshold
        '
        resources.ApplyResources(Me.Label_BlackBand_Thrshold, "Label_BlackBand_Thrshold")
        Me.Label_BlackBand_Thrshold.Name = "Label_BlackBand_Thrshold"
        '
        'Label_HBand_Thrshold
        '
        resources.ApplyResources(Me.Label_HBand_Thrshold, "Label_HBand_Thrshold")
        Me.Label_HBand_Thrshold.Name = "Label_HBand_Thrshold"
        '
        'NumericUpDown_BandMura_SmoothCount
        '
        resources.ApplyResources(Me.NumericUpDown_BandMura_SmoothCount, "NumericUpDown_BandMura_SmoothCount")
        Me.NumericUpDown_BandMura_SmoothCount.Name = "NumericUpDown_BandMura_SmoothCount"
        '
        'Label_Band_SmoothCount
        '
        resources.ApplyResources(Me.Label_Band_SmoothCount, "Label_Band_SmoothCount")
        Me.Label_Band_SmoothCount.Name = "Label_Band_SmoothCount"
        '
        'NumericUpDown_BandMura_ResizeCount
        '
        resources.ApplyResources(Me.NumericUpDown_BandMura_ResizeCount, "NumericUpDown_BandMura_ResizeCount")
        Me.NumericUpDown_BandMura_ResizeCount.Name = "NumericUpDown_BandMura_ResizeCount"
        '
        'Label_Band_ResizeCount
        '
        resources.ApplyResources(Me.Label_Band_ResizeCount, "Label_Band_ResizeCount")
        Me.Label_Band_ResizeCount.Name = "Label_Band_ResizeCount"
        '
        'GroupBox_BandModify
        '
        resources.ApplyResources(Me.GroupBox_BandModify, "GroupBox_BandModify")
        Me.GroupBox_BandModify.Controls.Add(Me.GroupBox_V)
        Me.GroupBox_BandModify.Controls.Add(Me.GroupBox_H)
        Me.GroupBox_BandModify.Name = "GroupBox_BandModify"
        Me.GroupBox_BandModify.TabStop = False
        '
        'GroupBox_V
        '
        resources.ApplyResources(Me.GroupBox_V, "GroupBox_V")
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VTop)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VRight)
        Me.GroupBox_V.Controls.Add(Me.Label54)
        Me.GroupBox_V.Controls.Add(Me.Label_VRight)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VBottom)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_VLeft)
        Me.GroupBox_V.Controls.Add(Me.Label55)
        Me.GroupBox_V.Controls.Add(Me.Label_VLeft)
        Me.GroupBox_V.Name = "GroupBox_V"
        Me.GroupBox_V.TabStop = False
        '
        'NumericUpDown_VTop
        '
        resources.ApplyResources(Me.NumericUpDown_VTop, "NumericUpDown_VTop")
        Me.NumericUpDown_VTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_VTop.Name = "NumericUpDown_VTop"
        '
        'NumericUpDown_VRight
        '
        resources.ApplyResources(Me.NumericUpDown_VRight, "NumericUpDown_VRight")
        Me.NumericUpDown_VRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_VRight.Name = "NumericUpDown_VRight"
        '
        'Label54
        '
        resources.ApplyResources(Me.Label54, "Label54")
        Me.Label54.Name = "Label54"
        '
        'Label_VRight
        '
        resources.ApplyResources(Me.Label_VRight, "Label_VRight")
        Me.Label_VRight.Name = "Label_VRight"
        '
        'NumericUpDown_VBottom
        '
        resources.ApplyResources(Me.NumericUpDown_VBottom, "NumericUpDown_VBottom")
        Me.NumericUpDown_VBottom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_VBottom.Name = "NumericUpDown_VBottom"
        '
        'NumericUpDown_VLeft
        '
        resources.ApplyResources(Me.NumericUpDown_VLeft, "NumericUpDown_VLeft")
        Me.NumericUpDown_VLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_VLeft.Name = "NumericUpDown_VLeft"
        '
        'Label55
        '
        resources.ApplyResources(Me.Label55, "Label55")
        Me.Label55.Name = "Label55"
        '
        'Label_VLeft
        '
        resources.ApplyResources(Me.Label_VLeft, "Label_VLeft")
        Me.Label_VLeft.Name = "Label_VLeft"
        '
        'GroupBox_H
        '
        resources.ApplyResources(Me.GroupBox_H, "GroupBox_H")
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HRight)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HTop)
        Me.GroupBox_H.Controls.Add(Me.Label52)
        Me.GroupBox_H.Controls.Add(Me.Label_HBottom)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HLeft)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_HBottom)
        Me.GroupBox_H.Controls.Add(Me.Label53)
        Me.GroupBox_H.Controls.Add(Me.Label_HTOP)
        Me.GroupBox_H.Name = "GroupBox_H"
        Me.GroupBox_H.TabStop = False
        '
        'NumericUpDown_HRight
        '
        resources.ApplyResources(Me.NumericUpDown_HRight, "NumericUpDown_HRight")
        Me.NumericUpDown_HRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_HRight.Name = "NumericUpDown_HRight"
        '
        'NumericUpDown_HTop
        '
        resources.ApplyResources(Me.NumericUpDown_HTop, "NumericUpDown_HTop")
        Me.NumericUpDown_HTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_HTop.Name = "NumericUpDown_HTop"
        '
        'Label52
        '
        resources.ApplyResources(Me.Label52, "Label52")
        Me.Label52.Name = "Label52"
        '
        'Label_HBottom
        '
        resources.ApplyResources(Me.Label_HBottom, "Label_HBottom")
        Me.Label_HBottom.Name = "Label_HBottom"
        '
        'NumericUpDown_HLeft
        '
        resources.ApplyResources(Me.NumericUpDown_HLeft, "NumericUpDown_HLeft")
        Me.NumericUpDown_HLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_HLeft.Name = "NumericUpDown_HLeft"
        '
        'NumericUpDown_HBottom
        '
        resources.ApplyResources(Me.NumericUpDown_HBottom, "NumericUpDown_HBottom")
        Me.NumericUpDown_HBottom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_HBottom.Name = "NumericUpDown_HBottom"
        '
        'Label53
        '
        resources.ApplyResources(Me.Label53, "Label53")
        Me.Label53.Name = "Label53"
        '
        'Label_HTOP
        '
        resources.ApplyResources(Me.Label_HTOP, "Label_HTOP")
        Me.Label_HTOP.Name = "Label_HTOP"
        '
        'TabPage_HVValue
        '
        resources.ApplyResources(Me.TabPage_HVValue, "TabPage_HVValue")
        Me.TabPage_HVValue.Controls.Add(Me.NumericUpDown_VValue_BlackVBandTH)
        Me.TabPage_HVValue.Controls.Add(Me.NumericUpDown_VValue_WhiteVBandTH)
        Me.TabPage_HVValue.Controls.Add(Me.CheckBox_VValue_UseVBand)
        Me.TabPage_HVValue.Controls.Add(Me.NumericUpDown_HValue_BlackHBandTH)
        Me.TabPage_HVValue.Controls.Add(Me.NumericUpDown_HValue_WhiteHBandTH)
        Me.TabPage_HVValue.Controls.Add(Me.CheckBox_HValue_UseHBand)
        Me.TabPage_HVValue.Controls.Add(Me.Label_VConst)
        Me.TabPage_HVValue.Controls.Add(Me.Label_VSlope)
        Me.TabPage_HVValue.Controls.Add(Me.Label24)
        Me.TabPage_HVValue.Controls.Add(Me.Label_HConst)
        Me.TabPage_HVValue.Controls.Add(Me.Label67)
        Me.TabPage_HVValue.Controls.Add(Me.Label_HSlope)
        Me.TabPage_HVValue.Controls.Add(Me.Label_VValueL1)
        Me.TabPage_HVValue.Controls.Add(Me.Label_HValueL1)
        Me.TabPage_HVValue.Controls.Add(Me.GroupBox_Manual)
        Me.TabPage_HVValue.Controls.Add(Me.Label_VValueCount)
        Me.TabPage_HVValue.Controls.Add(Me.Label_HValueCount)
        Me.TabPage_HVValue.Controls.Add(Me.ListView_VValue)
        Me.TabPage_HVValue.Controls.Add(Me.CheckBox_UseVValue)
        Me.TabPage_HVValue.Controls.Add(Me.ListView_HValue)
        Me.TabPage_HVValue.Controls.Add(Me.CheckBox_UseHValue)
        Me.TabPage_HVValue.Controls.Add(Me.Label78)
        Me.TabPage_HVValue.Controls.Add(Me.Label79)
        Me.TabPage_HVValue.Controls.Add(Me.Label80)
        Me.TabPage_HVValue.Controls.Add(Me.Label81)
        Me.TabPage_HVValue.Name = "TabPage_HVValue"
        Me.TabPage_HVValue.UseVisualStyleBackColor = True
        '
        'NumericUpDown_VValue_BlackVBandTH
        '
        resources.ApplyResources(Me.NumericUpDown_VValue_BlackVBandTH, "NumericUpDown_VValue_BlackVBandTH")
        Me.NumericUpDown_VValue_BlackVBandTH.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_VValue_BlackVBandTH.Minimum = New Decimal(New Integer() {10000000, 0, 0, -2147483648})
        Me.NumericUpDown_VValue_BlackVBandTH.Name = "NumericUpDown_VValue_BlackVBandTH"
        Me.NumericUpDown_VValue_BlackVBandTH.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_VValue_WhiteVBandTH
        '
        resources.ApplyResources(Me.NumericUpDown_VValue_WhiteVBandTH, "NumericUpDown_VValue_WhiteVBandTH")
        Me.NumericUpDown_VValue_WhiteVBandTH.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_VValue_WhiteVBandTH.Minimum = New Decimal(New Integer() {10000000, 0, 0, -2147483648})
        Me.NumericUpDown_VValue_WhiteVBandTH.Name = "NumericUpDown_VValue_WhiteVBandTH"
        Me.NumericUpDown_VValue_WhiteVBandTH.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CheckBox_VValue_UseVBand
        '
        resources.ApplyResources(Me.CheckBox_VValue_UseVBand, "CheckBox_VValue_UseVBand")
        Me.CheckBox_VValue_UseVBand.Name = "CheckBox_VValue_UseVBand"
        '
        'NumericUpDown_HValue_BlackHBandTH
        '
        resources.ApplyResources(Me.NumericUpDown_HValue_BlackHBandTH, "NumericUpDown_HValue_BlackHBandTH")
        Me.NumericUpDown_HValue_BlackHBandTH.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_HValue_BlackHBandTH.Minimum = New Decimal(New Integer() {10000000, 0, 0, -2147483648})
        Me.NumericUpDown_HValue_BlackHBandTH.Name = "NumericUpDown_HValue_BlackHBandTH"
        Me.NumericUpDown_HValue_BlackHBandTH.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_HValue_WhiteHBandTH
        '
        resources.ApplyResources(Me.NumericUpDown_HValue_WhiteHBandTH, "NumericUpDown_HValue_WhiteHBandTH")
        Me.NumericUpDown_HValue_WhiteHBandTH.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_HValue_WhiteHBandTH.Minimum = New Decimal(New Integer() {10000000, 0, 0, -2147483648})
        Me.NumericUpDown_HValue_WhiteHBandTH.Name = "NumericUpDown_HValue_WhiteHBandTH"
        Me.NumericUpDown_HValue_WhiteHBandTH.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CheckBox_HValue_UseHBand
        '
        resources.ApplyResources(Me.CheckBox_HValue_UseHBand, "CheckBox_HValue_UseHBand")
        Me.CheckBox_HValue_UseHBand.Name = "CheckBox_HValue_UseHBand"
        '
        'Label_VConst
        '
        resources.ApplyResources(Me.Label_VConst, "Label_VConst")
        Me.Label_VConst.Name = "Label_VConst"
        '
        'Label_VSlope
        '
        resources.ApplyResources(Me.Label_VSlope, "Label_VSlope")
        Me.Label_VSlope.Name = "Label_VSlope"
        '
        'Label24
        '
        resources.ApplyResources(Me.Label24, "Label24")
        Me.Label24.Name = "Label24"
        '
        'Label_HConst
        '
        resources.ApplyResources(Me.Label_HConst, "Label_HConst")
        Me.Label_HConst.Name = "Label_HConst"
        '
        'Label67
        '
        resources.ApplyResources(Me.Label67, "Label67")
        Me.Label67.Name = "Label67"
        '
        'Label_HSlope
        '
        resources.ApplyResources(Me.Label_HSlope, "Label_HSlope")
        Me.Label_HSlope.Name = "Label_HSlope"
        '
        'Label_VValueL1
        '
        resources.ApplyResources(Me.Label_VValueL1, "Label_VValueL1")
        Me.Label_VValueL1.Name = "Label_VValueL1"
        '
        'Label_HValueL1
        '
        resources.ApplyResources(Me.Label_HValueL1, "Label_HValueL1")
        Me.Label_HValueL1.Name = "Label_HValueL1"
        '
        'GroupBox_Manual
        '
        resources.ApplyResources(Me.GroupBox_Manual, "GroupBox_Manual")
        Me.GroupBox_Manual.Controls.Add(Me.Button_CalculateLSQ)
        Me.GroupBox_Manual.Controls.Add(Me.NumericUpDown_JND)
        Me.GroupBox_Manual.Controls.Add(Me.NumericUpDown_Value)
        Me.GroupBox_Manual.Controls.Add(Me.ComboBox_ValueType)
        Me.GroupBox_Manual.Controls.Add(Me.Label26)
        Me.GroupBox_Manual.Controls.Add(Me.Button_AddOne)
        Me.GroupBox_Manual.Controls.Add(Me.Button_Clear)
        Me.GroupBox_Manual.Controls.Add(Me.Label_Y)
        Me.GroupBox_Manual.Controls.Add(Me.Label_Value)
        Me.GroupBox_Manual.Name = "GroupBox_Manual"
        Me.GroupBox_Manual.TabStop = False
        '
        'Button_CalculateLSQ
        '
        resources.ApplyResources(Me.Button_CalculateLSQ, "Button_CalculateLSQ")
        Me.Button_CalculateLSQ.Name = "Button_CalculateLSQ"
        Me.Button_CalculateLSQ.UseVisualStyleBackColor = True
        '
        'NumericUpDown_JND
        '
        resources.ApplyResources(Me.NumericUpDown_JND, "NumericUpDown_JND")
        Me.NumericUpDown_JND.DecimalPlaces = 1
        Me.NumericUpDown_JND.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_JND.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_JND.Name = "NumericUpDown_JND"
        Me.NumericUpDown_JND.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_Value
        '
        resources.ApplyResources(Me.NumericUpDown_Value, "NumericUpDown_Value")
        Me.NumericUpDown_Value.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_Value.Minimum = New Decimal(New Integer() {10000000, 0, 0, -2147483648})
        Me.NumericUpDown_Value.Name = "NumericUpDown_Value"
        Me.NumericUpDown_Value.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ComboBox_ValueType
        '
        resources.ApplyResources(Me.ComboBox_ValueType, "ComboBox_ValueType")
        Me.ComboBox_ValueType.FormattingEnabled = True
        Me.ComboBox_ValueType.Items.AddRange(New Object() {resources.GetString("ComboBox_ValueType.Items"), resources.GetString("ComboBox_ValueType.Items1")})
        Me.ComboBox_ValueType.Name = "ComboBox_ValueType"
        '
        'Label26
        '
        resources.ApplyResources(Me.Label26, "Label26")
        Me.Label26.Name = "Label26"
        '
        'Button_AddOne
        '
        resources.ApplyResources(Me.Button_AddOne, "Button_AddOne")
        Me.Button_AddOne.Name = "Button_AddOne"
        Me.Button_AddOne.UseVisualStyleBackColor = True
        '
        'Button_Clear
        '
        resources.ApplyResources(Me.Button_Clear, "Button_Clear")
        Me.Button_Clear.Name = "Button_Clear"
        '
        'Label_Y
        '
        resources.ApplyResources(Me.Label_Y, "Label_Y")
        Me.Label_Y.Name = "Label_Y"
        '
        'Label_Value
        '
        resources.ApplyResources(Me.Label_Value, "Label_Value")
        Me.Label_Value.Name = "Label_Value"
        '
        'Label_VValueCount
        '
        resources.ApplyResources(Me.Label_VValueCount, "Label_VValueCount")
        Me.Label_VValueCount.Name = "Label_VValueCount"
        '
        'Label_HValueCount
        '
        resources.ApplyResources(Me.Label_HValueCount, "Label_HValueCount")
        Me.Label_HValueCount.Name = "Label_HValueCount"
        '
        'ListView_VValue
        '
        resources.ApplyResources(Me.ListView_VValue, "ListView_VValue")
        Me.ListView_VValue.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_VValue, Me.ColumnHeader_VJND})
        Me.ListView_VValue.FullRowSelect = True
        Me.ListView_VValue.GridLines = True
        Me.ListView_VValue.HideSelection = False
        Me.ListView_VValue.Name = "ListView_VValue"
        Me.ListView_VValue.UseCompatibleStateImageBehavior = False
        Me.ListView_VValue.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_VValue
        '
        resources.ApplyResources(Me.ColumnHeader_VValue, "ColumnHeader_VValue")
        '
        'ColumnHeader_VJND
        '
        resources.ApplyResources(Me.ColumnHeader_VJND, "ColumnHeader_VJND")
        '
        'CheckBox_UseVValue
        '
        resources.ApplyResources(Me.CheckBox_UseVValue, "CheckBox_UseVValue")
        Me.CheckBox_UseVValue.Name = "CheckBox_UseVValue"
        '
        'ListView_HValue
        '
        resources.ApplyResources(Me.ListView_HValue, "ListView_HValue")
        Me.ListView_HValue.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_HValue, Me.ColumnHeader_HJND})
        Me.ListView_HValue.FullRowSelect = True
        Me.ListView_HValue.GridLines = True
        Me.ListView_HValue.HideSelection = False
        Me.ListView_HValue.Name = "ListView_HValue"
        Me.ListView_HValue.UseCompatibleStateImageBehavior = False
        Me.ListView_HValue.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_HValue
        '
        resources.ApplyResources(Me.ColumnHeader_HValue, "ColumnHeader_HValue")
        '
        'ColumnHeader_HJND
        '
        resources.ApplyResources(Me.ColumnHeader_HJND, "ColumnHeader_HJND")
        '
        'CheckBox_UseHValue
        '
        resources.ApplyResources(Me.CheckBox_UseHValue, "CheckBox_UseHValue")
        Me.CheckBox_UseHValue.Name = "CheckBox_UseHValue"
        '
        'Label78
        '
        resources.ApplyResources(Me.Label78, "Label78")
        Me.Label78.Name = "Label78"
        '
        'Label79
        '
        resources.ApplyResources(Me.Label79, "Label79")
        Me.Label79.Name = "Label79"
        '
        'Label80
        '
        resources.ApplyResources(Me.Label80, "Label80")
        Me.Label80.Name = "Label80"
        '
        'Label81
        '
        resources.ApplyResources(Me.Label81, "Label81")
        Me.Label81.Name = "Label81"
        '
        'TabPage_JND_1
        '
        resources.ApplyResources(Me.TabPage_JND_1, "TabPage_JND_1")
        Me.TabPage_JND_1.Controls.Add(Me.GroupBox_JND_1)
        Me.TabPage_JND_1.Name = "TabPage_JND_1"
        Me.TabPage_JND_1.UseVisualStyleBackColor = True
        '
        'GroupBox_JND_1
        '
        resources.ApplyResources(Me.GroupBox_JND_1, "GroupBox_JND_1")
        Me.GroupBox_JND_1.Controls.Add(Me.GroupBox_WhiteBandJND)
        Me.GroupBox_JND_1.Controls.Add(Me.GroupBox_WhiteAGM)
        Me.GroupBox_JND_1.Controls.Add(Me.GroupBox_WhiteMacroJND)
        Me.GroupBox_JND_1.Controls.Add(Me.GroupBox_WhiteBlobJND)
        Me.GroupBox_JND_1.Name = "GroupBox_JND_1"
        Me.GroupBox_JND_1.TabStop = False
        '
        'GroupBox_WhiteBandJND
        '
        resources.ApplyResources(Me.GroupBox_WhiteBandJND, "GroupBox_WhiteBandJND")
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.NUD_WhiteBandMura_WidthMin)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.Label_WhiteBandMura_WidthMin)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.Label_WhiteBandMura_JND)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.Labell_WhiteBandMura_SJND)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.NUD_WhiteBandMura_JND)
        Me.GroupBox_WhiteBandJND.Controls.Add(Me.NUD_WhiteBandMura_SJND)
        Me.GroupBox_WhiteBandJND.Name = "GroupBox_WhiteBandJND"
        Me.GroupBox_WhiteBandJND.TabStop = False
        '
        'NUD_WhiteBandMura_WidthMin
        '
        resources.ApplyResources(Me.NUD_WhiteBandMura_WidthMin, "NUD_WhiteBandMura_WidthMin")
        Me.NUD_WhiteBandMura_WidthMin.DecimalPlaces = 2
        Me.NUD_WhiteBandMura_WidthMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBandMura_WidthMin.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NUD_WhiteBandMura_WidthMin.Name = "NUD_WhiteBandMura_WidthMin"
        '
        'Label_WhiteBandMura_WidthMin
        '
        resources.ApplyResources(Me.Label_WhiteBandMura_WidthMin, "Label_WhiteBandMura_WidthMin")
        Me.Label_WhiteBandMura_WidthMin.Name = "Label_WhiteBandMura_WidthMin"
        '
        'Label_WhiteBandMura_JND
        '
        resources.ApplyResources(Me.Label_WhiteBandMura_JND, "Label_WhiteBandMura_JND")
        Me.Label_WhiteBandMura_JND.Name = "Label_WhiteBandMura_JND"
        '
        'Labell_WhiteBandMura_SJND
        '
        resources.ApplyResources(Me.Labell_WhiteBandMura_SJND, "Labell_WhiteBandMura_SJND")
        Me.Labell_WhiteBandMura_SJND.Name = "Labell_WhiteBandMura_SJND"
        '
        'NUD_WhiteBandMura_JND
        '
        resources.ApplyResources(Me.NUD_WhiteBandMura_JND, "NUD_WhiteBandMura_JND")
        Me.NUD_WhiteBandMura_JND.DecimalPlaces = 1
        Me.NUD_WhiteBandMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_WhiteBandMura_JND.Name = "NUD_WhiteBandMura_JND"
        '
        'NUD_WhiteBandMura_SJND
        '
        resources.ApplyResources(Me.NUD_WhiteBandMura_SJND, "NUD_WhiteBandMura_SJND")
        Me.NUD_WhiteBandMura_SJND.DecimalPlaces = 2
        Me.NUD_WhiteBandMura_SJND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBandMura_SJND.Name = "NUD_WhiteBandMura_SJND"
        '
        'GroupBox_WhiteAGM
        '
        resources.ApplyResources(Me.GroupBox_WhiteAGM, "GroupBox_WhiteAGM")
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_Elongation_Max)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label_WhiteAGM_AreaMin)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label69)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_AreaMin)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_Elongation_Min)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_AreaMax)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label70)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_JND_Min)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.NUD_WhiteAGM_JND_Max)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label_AGM_WhiteAreaMax)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label71)
        Me.GroupBox_WhiteAGM.Controls.Add(Me.Label_WhiteAGM_JND)
        Me.GroupBox_WhiteAGM.Name = "GroupBox_WhiteAGM"
        Me.GroupBox_WhiteAGM.TabStop = False
        '
        'NUD_WhiteAGM_Elongation_Max
        '
        resources.ApplyResources(Me.NUD_WhiteAGM_Elongation_Max, "NUD_WhiteAGM_Elongation_Max")
        Me.NUD_WhiteAGM_Elongation_Max.DecimalPlaces = 1
        Me.NUD_WhiteAGM_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_WhiteAGM_Elongation_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteAGM_Elongation_Max.Name = "NUD_WhiteAGM_Elongation_Max"
        '
        'Label_WhiteAGM_AreaMin
        '
        resources.ApplyResources(Me.Label_WhiteAGM_AreaMin, "Label_WhiteAGM_AreaMin")
        Me.Label_WhiteAGM_AreaMin.Name = "Label_WhiteAGM_AreaMin"
        '
        'Label69
        '
        resources.ApplyResources(Me.Label69, "Label69")
        Me.Label69.Name = "Label69"
        '
        'NUD_WhiteAGM_AreaMin
        '
        resources.ApplyResources(Me.NUD_WhiteAGM_AreaMin, "NUD_WhiteAGM_AreaMin")
        Me.NUD_WhiteAGM_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_WhiteAGM_AreaMin.Name = "NUD_WhiteAGM_AreaMin"
        '
        'NUD_WhiteAGM_Elongation_Min
        '
        resources.ApplyResources(Me.NUD_WhiteAGM_Elongation_Min, "NUD_WhiteAGM_Elongation_Min")
        Me.NUD_WhiteAGM_Elongation_Min.DecimalPlaces = 1
        Me.NUD_WhiteAGM_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_WhiteAGM_Elongation_Min.Name = "NUD_WhiteAGM_Elongation_Min"
        '
        'NUD_WhiteAGM_AreaMax
        '
        resources.ApplyResources(Me.NUD_WhiteAGM_AreaMax, "NUD_WhiteAGM_AreaMax")
        Me.NUD_WhiteAGM_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_WhiteAGM_AreaMax.Name = "NUD_WhiteAGM_AreaMax"
        '
        'Label70
        '
        resources.ApplyResources(Me.Label70, "Label70")
        Me.Label70.Name = "Label70"
        '
        'NUD_WhiteAGM_JND_Min
        '
        resources.ApplyResources(Me.NUD_WhiteAGM_JND_Min, "NUD_WhiteAGM_JND_Min")
        Me.NUD_WhiteAGM_JND_Min.DecimalPlaces = 2
        Me.NUD_WhiteAGM_JND_Min.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteAGM_JND_Min.Name = "NUD_WhiteAGM_JND_Min"
        '
        'NUD_WhiteAGM_JND_Max
        '
        resources.ApplyResources(Me.NUD_WhiteAGM_JND_Max, "NUD_WhiteAGM_JND_Max")
        Me.NUD_WhiteAGM_JND_Max.DecimalPlaces = 2
        Me.NUD_WhiteAGM_JND_Max.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteAGM_JND_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteAGM_JND_Max.Name = "NUD_WhiteAGM_JND_Max"
        '
        'Label_AGM_WhiteAreaMax
        '
        resources.ApplyResources(Me.Label_AGM_WhiteAreaMax, "Label_AGM_WhiteAreaMax")
        Me.Label_AGM_WhiteAreaMax.Name = "Label_AGM_WhiteAreaMax"
        '
        'Label71
        '
        resources.ApplyResources(Me.Label71, "Label71")
        Me.Label71.Name = "Label71"
        '
        'Label_WhiteAGM_JND
        '
        resources.ApplyResources(Me.Label_WhiteAGM_JND, "Label_WhiteAGM_JND")
        Me.Label_WhiteAGM_JND.Name = "Label_WhiteAGM_JND"
        '
        'GroupBox_WhiteMacroJND
        '
        resources.ApplyResources(Me.GroupBox_WhiteMacroJND, "GroupBox_WhiteMacroJND")
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.Label_WhiteMacroMura_AreaMin)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.NUD_WhiteMacroMura_AreaMin)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.NUD_WhiteMacroMura_JND)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.Label_WhiteMacroMura_AreaMax)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.Label_WhiteMacroMura_JND)
        Me.GroupBox_WhiteMacroJND.Controls.Add(Me.NUD_WhiteMacroMura_AreaMax)
        Me.GroupBox_WhiteMacroJND.Name = "GroupBox_WhiteMacroJND"
        Me.GroupBox_WhiteMacroJND.TabStop = False
        '
        'Label_WhiteMacroMura_AreaMin
        '
        resources.ApplyResources(Me.Label_WhiteMacroMura_AreaMin, "Label_WhiteMacroMura_AreaMin")
        Me.Label_WhiteMacroMura_AreaMin.Name = "Label_WhiteMacroMura_AreaMin"
        '
        'NUD_WhiteMacroMura_AreaMin
        '
        resources.ApplyResources(Me.NUD_WhiteMacroMura_AreaMin, "NUD_WhiteMacroMura_AreaMin")
        Me.NUD_WhiteMacroMura_AreaMin.Maximum = New Decimal(New Integer() {1000000000, 0, 0, 0})
        Me.NUD_WhiteMacroMura_AreaMin.Name = "NUD_WhiteMacroMura_AreaMin"
        '
        'NUD_WhiteMacroMura_JND
        '
        resources.ApplyResources(Me.NUD_WhiteMacroMura_JND, "NUD_WhiteMacroMura_JND")
        Me.NUD_WhiteMacroMura_JND.DecimalPlaces = 2
        Me.NUD_WhiteMacroMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteMacroMura_JND.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NUD_WhiteMacroMura_JND.Name = "NUD_WhiteMacroMura_JND"
        '
        'Label_WhiteMacroMura_AreaMax
        '
        resources.ApplyResources(Me.Label_WhiteMacroMura_AreaMax, "Label_WhiteMacroMura_AreaMax")
        Me.Label_WhiteMacroMura_AreaMax.Name = "Label_WhiteMacroMura_AreaMax"
        '
        'Label_WhiteMacroMura_JND
        '
        resources.ApplyResources(Me.Label_WhiteMacroMura_JND, "Label_WhiteMacroMura_JND")
        Me.Label_WhiteMacroMura_JND.Name = "Label_WhiteMacroMura_JND"
        '
        'NUD_WhiteMacroMura_AreaMax
        '
        resources.ApplyResources(Me.NUD_WhiteMacroMura_AreaMax, "NUD_WhiteMacroMura_AreaMax")
        Me.NUD_WhiteMacroMura_AreaMax.Maximum = New Decimal(New Integer() {1215752192, 23, 0, 0})
        Me.NUD_WhiteMacroMura_AreaMax.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.NUD_WhiteMacroMura_AreaMax.Name = "NUD_WhiteMacroMura_AreaMax"
        '
        'GroupBox_WhiteBlobJND
        '
        resources.ApplyResources(Me.GroupBox_WhiteBlobJND, "GroupBox_WhiteBlobJND")
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_Elongation_Max)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label19)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_Elongation_Min)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label68)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_JND_Max)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label16)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label_WhiteBlob_AreaMin)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_AreaMin)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_AreaMax)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.NUD_WhiteBlobMura_JND_Min)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label_WhiteBlob_AreaMax)
        Me.GroupBox_WhiteBlobJND.Controls.Add(Me.Label_WhiteBlobMura_JND)
        Me.GroupBox_WhiteBlobJND.Name = "GroupBox_WhiteBlobJND"
        Me.GroupBox_WhiteBlobJND.TabStop = False
        '
        'NUD_WhiteBlobMura_Elongation_Max
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_Elongation_Max, "NUD_WhiteBlobMura_Elongation_Max")
        Me.NUD_WhiteBlobMura_Elongation_Max.DecimalPlaces = 1
        Me.NUD_WhiteBlobMura_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_WhiteBlobMura_Elongation_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_Elongation_Max.Name = "NUD_WhiteBlobMura_Elongation_Max"
        '
        'Label19
        '
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.Name = "Label19"
        '
        'NUD_WhiteBlobMura_Elongation_Min
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_Elongation_Min, "NUD_WhiteBlobMura_Elongation_Min")
        Me.NUD_WhiteBlobMura_Elongation_Min.DecimalPlaces = 1
        Me.NUD_WhiteBlobMura_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_WhiteBlobMura_Elongation_Min.Name = "NUD_WhiteBlobMura_Elongation_Min"
        '
        'Label68
        '
        resources.ApplyResources(Me.Label68, "Label68")
        Me.Label68.Name = "Label68"
        '
        'NUD_WhiteBlobMura_JND_Max
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_JND_Max, "NUD_WhiteBlobMura_JND_Max")
        Me.NUD_WhiteBlobMura_JND_Max.DecimalPlaces = 2
        Me.NUD_WhiteBlobMura_JND_Max.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBlobMura_JND_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_JND_Max.Name = "NUD_WhiteBlobMura_JND_Max"
        '
        'Label16
        '
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        '
        'Label_WhiteBlob_AreaMin
        '
        resources.ApplyResources(Me.Label_WhiteBlob_AreaMin, "Label_WhiteBlob_AreaMin")
        Me.Label_WhiteBlob_AreaMin.Name = "Label_WhiteBlob_AreaMin"
        '
        'NUD_WhiteBlobMura_AreaMin
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_AreaMin, "NUD_WhiteBlobMura_AreaMin")
        Me.NUD_WhiteBlobMura_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_AreaMin.Name = "NUD_WhiteBlobMura_AreaMin"
        '
        'NUD_WhiteBlobMura_AreaMax
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_AreaMax, "NUD_WhiteBlobMura_AreaMax")
        Me.NUD_WhiteBlobMura_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_AreaMax.Name = "NUD_WhiteBlobMura_AreaMax"
        '
        'NUD_WhiteBlobMura_JND_Min
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_JND_Min, "NUD_WhiteBlobMura_JND_Min")
        Me.NUD_WhiteBlobMura_JND_Min.DecimalPlaces = 2
        Me.NUD_WhiteBlobMura_JND_Min.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_WhiteBlobMura_JND_Min.Name = "NUD_WhiteBlobMura_JND_Min"
        '
        'Label_WhiteBlob_AreaMax
        '
        resources.ApplyResources(Me.Label_WhiteBlob_AreaMax, "Label_WhiteBlob_AreaMax")
        Me.Label_WhiteBlob_AreaMax.Name = "Label_WhiteBlob_AreaMax"
        '
        'Label_WhiteBlobMura_JND
        '
        resources.ApplyResources(Me.Label_WhiteBlobMura_JND, "Label_WhiteBlobMura_JND")
        Me.Label_WhiteBlobMura_JND.Name = "Label_WhiteBlobMura_JND"
        '
        'TabPage_JND_2
        '
        resources.ApplyResources(Me.TabPage_JND_2, "TabPage_JND_2")
        Me.TabPage_JND_2.Controls.Add(Me.GroupBox_JND_2)
        Me.TabPage_JND_2.Name = "TabPage_JND_2"
        Me.TabPage_JND_2.UseVisualStyleBackColor = True
        '
        'GroupBox_JND_2
        '
        resources.ApplyResources(Me.GroupBox_JND_2, "GroupBox_JND_2")
        Me.GroupBox_JND_2.Controls.Add(Me.GroupBox_BlackBandJND)
        Me.GroupBox_JND_2.Controls.Add(Me.GroupBox_BlackAGM)
        Me.GroupBox_JND_2.Controls.Add(Me.GroupBox2)
        Me.GroupBox_JND_2.Controls.Add(Me.GroupBox_BlackBlobJND)
        Me.GroupBox_JND_2.Name = "GroupBox_JND_2"
        Me.GroupBox_JND_2.TabStop = False
        '
        'GroupBox_BlackBandJND
        '
        resources.ApplyResources(Me.GroupBox_BlackBandJND, "GroupBox_BlackBandJND")
        Me.GroupBox_BlackBandJND.Controls.Add(Me.NUD_BlackBandMura_WidthMin)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.Label_BlackBandMura_WidthMin)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.Label_BlackBandMura_JND)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.Labell_BlackBandMura_SJND)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.NUD_BlackBandMura_JND)
        Me.GroupBox_BlackBandJND.Controls.Add(Me.NUD_BlackBandMura_SJND)
        Me.GroupBox_BlackBandJND.Name = "GroupBox_BlackBandJND"
        Me.GroupBox_BlackBandJND.TabStop = False
        '
        'NUD_BlackBandMura_WidthMin
        '
        resources.ApplyResources(Me.NUD_BlackBandMura_WidthMin, "NUD_BlackBandMura_WidthMin")
        Me.NUD_BlackBandMura_WidthMin.DecimalPlaces = 2
        Me.NUD_BlackBandMura_WidthMin.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBandMura_WidthMin.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBandMura_WidthMin.Name = "NUD_BlackBandMura_WidthMin"
        '
        'Label_BlackBandMura_WidthMin
        '
        resources.ApplyResources(Me.Label_BlackBandMura_WidthMin, "Label_BlackBandMura_WidthMin")
        Me.Label_BlackBandMura_WidthMin.Name = "Label_BlackBandMura_WidthMin"
        '
        'Label_BlackBandMura_JND
        '
        resources.ApplyResources(Me.Label_BlackBandMura_JND, "Label_BlackBandMura_JND")
        Me.Label_BlackBandMura_JND.Name = "Label_BlackBandMura_JND"
        '
        'Labell_BlackBandMura_SJND
        '
        resources.ApplyResources(Me.Labell_BlackBandMura_SJND, "Labell_BlackBandMura_SJND")
        Me.Labell_BlackBandMura_SJND.Name = "Labell_BlackBandMura_SJND"
        '
        'NUD_BlackBandMura_JND
        '
        resources.ApplyResources(Me.NUD_BlackBandMura_JND, "NUD_BlackBandMura_JND")
        Me.NUD_BlackBandMura_JND.DecimalPlaces = 1
        Me.NUD_BlackBandMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_BlackBandMura_JND.Name = "NUD_BlackBandMura_JND"
        '
        'NUD_BlackBandMura_SJND
        '
        resources.ApplyResources(Me.NUD_BlackBandMura_SJND, "NUD_BlackBandMura_SJND")
        Me.NUD_BlackBandMura_SJND.DecimalPlaces = 2
        Me.NUD_BlackBandMura_SJND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBandMura_SJND.Name = "NUD_BlackBandMura_SJND"
        '
        'GroupBox_BlackAGM
        '
        resources.ApplyResources(Me.GroupBox_BlackAGM, "GroupBox_BlackAGM")
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_Elongation_Max)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label75)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_Elongation_Min)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label76)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_JND_Max)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label77)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label_BlackAGM_AreaMin)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_AreaMin)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_AreaMax)
        Me.GroupBox_BlackAGM.Controls.Add(Me.NUD_BlackAGM_JND_Min)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label28)
        Me.GroupBox_BlackAGM.Controls.Add(Me.Label29)
        Me.GroupBox_BlackAGM.Name = "GroupBox_BlackAGM"
        Me.GroupBox_BlackAGM.TabStop = False
        '
        'NUD_BlackAGM_Elongation_Max
        '
        resources.ApplyResources(Me.NUD_BlackAGM_Elongation_Max, "NUD_BlackAGM_Elongation_Max")
        Me.NUD_BlackAGM_Elongation_Max.DecimalPlaces = 1
        Me.NUD_BlackAGM_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_BlackAGM_Elongation_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackAGM_Elongation_Max.Name = "NUD_BlackAGM_Elongation_Max"
        '
        'Label75
        '
        resources.ApplyResources(Me.Label75, "Label75")
        Me.Label75.Name = "Label75"
        '
        'NUD_BlackAGM_Elongation_Min
        '
        resources.ApplyResources(Me.NUD_BlackAGM_Elongation_Min, "NUD_BlackAGM_Elongation_Min")
        Me.NUD_BlackAGM_Elongation_Min.DecimalPlaces = 1
        Me.NUD_BlackAGM_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_BlackAGM_Elongation_Min.Name = "NUD_BlackAGM_Elongation_Min"
        '
        'Label76
        '
        resources.ApplyResources(Me.Label76, "Label76")
        Me.Label76.Name = "Label76"
        '
        'NUD_BlackAGM_JND_Max
        '
        resources.ApplyResources(Me.NUD_BlackAGM_JND_Max, "NUD_BlackAGM_JND_Max")
        Me.NUD_BlackAGM_JND_Max.DecimalPlaces = 2
        Me.NUD_BlackAGM_JND_Max.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackAGM_JND_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackAGM_JND_Max.Name = "NUD_BlackAGM_JND_Max"
        '
        'Label77
        '
        resources.ApplyResources(Me.Label77, "Label77")
        Me.Label77.Name = "Label77"
        '
        'Label_BlackAGM_AreaMin
        '
        resources.ApplyResources(Me.Label_BlackAGM_AreaMin, "Label_BlackAGM_AreaMin")
        Me.Label_BlackAGM_AreaMin.Name = "Label_BlackAGM_AreaMin"
        '
        'NUD_BlackAGM_AreaMin
        '
        resources.ApplyResources(Me.NUD_BlackAGM_AreaMin, "NUD_BlackAGM_AreaMin")
        Me.NUD_BlackAGM_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_BlackAGM_AreaMin.Name = "NUD_BlackAGM_AreaMin"
        '
        'NUD_BlackAGM_AreaMax
        '
        resources.ApplyResources(Me.NUD_BlackAGM_AreaMax, "NUD_BlackAGM_AreaMax")
        Me.NUD_BlackAGM_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_BlackAGM_AreaMax.Name = "NUD_BlackAGM_AreaMax"
        '
        'NUD_BlackAGM_JND_Min
        '
        resources.ApplyResources(Me.NUD_BlackAGM_JND_Min, "NUD_BlackAGM_JND_Min")
        Me.NUD_BlackAGM_JND_Min.DecimalPlaces = 2
        Me.NUD_BlackAGM_JND_Min.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackAGM_JND_Min.Name = "NUD_BlackAGM_JND_Min"
        '
        'Label28
        '
        resources.ApplyResources(Me.Label28, "Label28")
        Me.Label28.Name = "Label28"
        '
        'Label29
        '
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Name = "Label29"
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.Label_BlackMacroMura_AreaMin)
        Me.GroupBox2.Controls.Add(Me.NUD_BlackMacroMura_AreaMin)
        Me.GroupBox2.Controls.Add(Me.NUD_BlackMacroMura_JND)
        Me.GroupBox2.Controls.Add(Me.Label_BlackMacroMura_AreaMax)
        Me.GroupBox2.Controls.Add(Me.Label_BlackMacroMura_JND)
        Me.GroupBox2.Controls.Add(Me.NUD_BlackMacroMura_AreaMax)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'Label_BlackMacroMura_AreaMin
        '
        resources.ApplyResources(Me.Label_BlackMacroMura_AreaMin, "Label_BlackMacroMura_AreaMin")
        Me.Label_BlackMacroMura_AreaMin.Name = "Label_BlackMacroMura_AreaMin"
        '
        'NUD_BlackMacroMura_AreaMin
        '
        resources.ApplyResources(Me.NUD_BlackMacroMura_AreaMin, "NUD_BlackMacroMura_AreaMin")
        Me.NUD_BlackMacroMura_AreaMin.Maximum = New Decimal(New Integer() {1000000000, 0, 0, 0})
        Me.NUD_BlackMacroMura_AreaMin.Name = "NUD_BlackMacroMura_AreaMin"
        '
        'NUD_BlackMacroMura_JND
        '
        resources.ApplyResources(Me.NUD_BlackMacroMura_JND, "NUD_BlackMacroMura_JND")
        Me.NUD_BlackMacroMura_JND.DecimalPlaces = 2
        Me.NUD_BlackMacroMura_JND.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackMacroMura_JND.Name = "NUD_BlackMacroMura_JND"
        '
        'Label_BlackMacroMura_AreaMax
        '
        resources.ApplyResources(Me.Label_BlackMacroMura_AreaMax, "Label_BlackMacroMura_AreaMax")
        Me.Label_BlackMacroMura_AreaMax.Name = "Label_BlackMacroMura_AreaMax"
        '
        'Label_BlackMacroMura_JND
        '
        resources.ApplyResources(Me.Label_BlackMacroMura_JND, "Label_BlackMacroMura_JND")
        Me.Label_BlackMacroMura_JND.Name = "Label_BlackMacroMura_JND"
        '
        'NUD_BlackMacroMura_AreaMax
        '
        resources.ApplyResources(Me.NUD_BlackMacroMura_AreaMax, "NUD_BlackMacroMura_AreaMax")
        Me.NUD_BlackMacroMura_AreaMax.Maximum = New Decimal(New Integer() {1215752192, 23, 0, 0})
        Me.NUD_BlackMacroMura_AreaMax.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.NUD_BlackMacroMura_AreaMax.Name = "NUD_BlackMacroMura_AreaMax"
        '
        'GroupBox_BlackBlobJND
        '
        resources.ApplyResources(Me.GroupBox_BlackBlobJND, "GroupBox_BlackBlobJND")
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_Elongation_Max)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label72)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_Elongation_Min)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label73)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_JND_Max)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label74)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label_BlackBlob_AreaMin)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_AreaMin)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_AreaMax)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.NUD_BlackBlobMura_JND_Min)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label_BlackBlob_AreaMax)
        Me.GroupBox_BlackBlobJND.Controls.Add(Me.Label_BlackBlobMura_JND)
        Me.GroupBox_BlackBlobJND.Name = "GroupBox_BlackBlobJND"
        Me.GroupBox_BlackBlobJND.TabStop = False
        '
        'NUD_BlackBlobMura_Elongation_Max
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_Elongation_Max, "NUD_BlackBlobMura_Elongation_Max")
        Me.NUD_BlackBlobMura_Elongation_Max.DecimalPlaces = 1
        Me.NUD_BlackBlobMura_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_BlackBlobMura_Elongation_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackBlobMura_Elongation_Max.Name = "NUD_BlackBlobMura_Elongation_Max"
        '
        'Label72
        '
        resources.ApplyResources(Me.Label72, "Label72")
        Me.Label72.Name = "Label72"
        '
        'NUD_BlackBlobMura_Elongation_Min
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_Elongation_Min, "NUD_BlackBlobMura_Elongation_Min")
        Me.NUD_BlackBlobMura_Elongation_Min.DecimalPlaces = 1
        Me.NUD_BlackBlobMura_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NUD_BlackBlobMura_Elongation_Min.Name = "NUD_BlackBlobMura_Elongation_Min"
        '
        'Label73
        '
        resources.ApplyResources(Me.Label73, "Label73")
        Me.Label73.Name = "Label73"
        '
        'NUD_BlackBlobMura_JND_Max
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_JND_Max, "NUD_BlackBlobMura_JND_Max")
        Me.NUD_BlackBlobMura_JND_Max.DecimalPlaces = 2
        Me.NUD_BlackBlobMura_JND_Max.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBlobMura_JND_Max.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NUD_BlackBlobMura_JND_Max.Name = "NUD_BlackBlobMura_JND_Max"
        '
        'Label74
        '
        resources.ApplyResources(Me.Label74, "Label74")
        Me.Label74.Name = "Label74"
        '
        'Label_BlackBlob_AreaMin
        '
        resources.ApplyResources(Me.Label_BlackBlob_AreaMin, "Label_BlackBlob_AreaMin")
        Me.Label_BlackBlob_AreaMin.Name = "Label_BlackBlob_AreaMin"
        '
        'NUD_BlackBlobMura_AreaMin
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_AreaMin, "NUD_BlackBlobMura_AreaMin")
        Me.NUD_BlackBlobMura_AreaMin.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NUD_BlackBlobMura_AreaMin.Name = "NUD_BlackBlobMura_AreaMin"
        '
        'NUD_BlackBlobMura_AreaMax
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_AreaMax, "NUD_BlackBlobMura_AreaMax")
        Me.NUD_BlackBlobMura_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_BlackBlobMura_AreaMax.Name = "NUD_BlackBlobMura_AreaMax"
        '
        'NUD_BlackBlobMura_JND_Min
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_JND_Min, "NUD_BlackBlobMura_JND_Min")
        Me.NUD_BlackBlobMura_JND_Min.DecimalPlaces = 2
        Me.NUD_BlackBlobMura_JND_Min.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NUD_BlackBlobMura_JND_Min.Name = "NUD_BlackBlobMura_JND_Min"
        '
        'Label_BlackBlob_AreaMax
        '
        resources.ApplyResources(Me.Label_BlackBlob_AreaMax, "Label_BlackBlob_AreaMax")
        Me.Label_BlackBlob_AreaMax.Name = "Label_BlackBlob_AreaMax"
        '
        'Label_BlackBlobMura_JND
        '
        resources.ApplyResources(Me.Label_BlackBlobMura_JND, "Label_BlackBlobMura_JND")
        Me.Label_BlackBlobMura_JND.Name = "Label_BlackBlobMura_JND"
        '
        'TabPage_Auto
        '
        resources.ApplyResources(Me.TabPage_Auto, "TabPage_Auto")
        Me.TabPage_Auto.Controls.Add(Me.GroupBox_AutoExposure)
        Me.TabPage_Auto.Name = "TabPage_Auto"
        Me.TabPage_Auto.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoExposure
        '
        resources.ApplyResources(Me.GroupBox_AutoExposure, "GroupBox_AutoExposure")
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label42)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_GrabDelayTime)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label41)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label9)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label5)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label4)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label15)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label14)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_SmallErrorRange)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_TargetMean)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_Kp)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label13)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label12)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label8)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label7)
        Me.GroupBox_AutoExposure.Name = "GroupBox_AutoExposure"
        Me.GroupBox_AutoExposure.TabStop = False
        '
        'Label42
        '
        resources.ApplyResources(Me.Label42, "Label42")
        Me.Label42.Name = "Label42"
        '
        'NumericUpDown_AutoExposure_GrabDelayTime
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_GrabDelayTime, "NumericUpDown_AutoExposure_GrabDelayTime")
        Me.NumericUpDown_AutoExposure_GrabDelayTime.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_GrabDelayTime.Name = "NumericUpDown_AutoExposure_GrabDelayTime"
        '
        'Label41
        '
        resources.ApplyResources(Me.Label41, "Label41")
        Me.Label41.Name = "Label41"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'NumericUpDown_AutoExposure_LargeErrorRange_DL
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL, "NumericUpDown_AutoExposure_LargeErrorRange_DL")
        Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum = New Decimal(New Integer() {200, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Name = "NumericUpDown_AutoExposure_LargeErrorRange_DL"
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'NumericUpDown_AutoExposure_SmallErrorRange
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_SmallErrorRange, "NumericUpDown_AutoExposure_SmallErrorRange")
        Me.NumericUpDown_AutoExposure_SmallErrorRange.Name = "NumericUpDown_AutoExposure_SmallErrorRange"
        '
        'NumericUpDown_AutoExposure_LargeErrorRange_UL
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL, "NumericUpDown_AutoExposure_LargeErrorRange_UL")
        Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Name = "NumericUpDown_AutoExposure_LargeErrorRange_UL"
        '
        'NumericUpDown_AutoExposure_TargetMean
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_TargetMean, "NumericUpDown_AutoExposure_TargetMean")
        Me.NumericUpDown_AutoExposure_TargetMean.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_TargetMean.Name = "NumericUpDown_AutoExposure_TargetMean"
        '
        'NumericUpDown_AutoExposure_Kp
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_Kp, "NumericUpDown_AutoExposure_Kp")
        Me.NumericUpDown_AutoExposure_Kp.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_Kp.Name = "NumericUpDown_AutoExposure_Kp"
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'TabPage_Abnormal
        '
        resources.ApplyResources(Me.TabPage_Abnormal, "TabPage_Abnormal")
        Me.TabPage_Abnormal.Controls.Add(Me.GroupBox_GrayAbnormal_2)
        Me.TabPage_Abnormal.Controls.Add(Me.GroupBox_GrayAbnormal_3)
        Me.TabPage_Abnormal.Controls.Add(Me.CheckBox_MultiRegion)
        Me.TabPage_Abnormal.Controls.Add(Me.GroupBox_GrayAbnormal_1)
        Me.TabPage_Abnormal.Controls.Add(Me.CheckBox_GrayAbnormal_Enable)
        Me.TabPage_Abnormal.Name = "TabPage_Abnormal"
        Me.TabPage_Abnormal.UseVisualStyleBackColor = True
        '
        'GroupBox_GrayAbnormal_2
        '
        resources.ApplyResources(Me.GroupBox_GrayAbnormal_2, "GroupBox_GrayAbnormal_2")
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.Lbl_GrayAbnormal_NegLimit_2)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.Lbl_GrayAbnormal_PosLimit_2)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.NumericUpDown_GrayAbnormal_NegLimit_2)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.Label92)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.Label93)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.Label94)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.Label95)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.Label96)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.NumericUpDown_GrayAbnormalStandardGray_2)
        Me.GroupBox_GrayAbnormal_2.Controls.Add(Me.NumericUpDown_GrayAbnormal_PosLimit_2)
        Me.GroupBox_GrayAbnormal_2.Name = "GroupBox_GrayAbnormal_2"
        Me.GroupBox_GrayAbnormal_2.TabStop = False
        '
        'Lbl_GrayAbnormal_NegLimit_2
        '
        resources.ApplyResources(Me.Lbl_GrayAbnormal_NegLimit_2, "Lbl_GrayAbnormal_NegLimit_2")
        Me.Lbl_GrayAbnormal_NegLimit_2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_NegLimit_2.Name = "Lbl_GrayAbnormal_NegLimit_2"
        '
        'Lbl_GrayAbnormal_PosLimit_2
        '
        resources.ApplyResources(Me.Lbl_GrayAbnormal_PosLimit_2, "Lbl_GrayAbnormal_PosLimit_2")
        Me.Lbl_GrayAbnormal_PosLimit_2.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_PosLimit_2.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Lbl_GrayAbnormal_PosLimit_2.Name = "Lbl_GrayAbnormal_PosLimit_2"
        '
        'NumericUpDown_GrayAbnormal_NegLimit_2
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_NegLimit_2, "NumericUpDown_GrayAbnormal_NegLimit_2")
        Me.NumericUpDown_GrayAbnormal_NegLimit_2.Name = "NumericUpDown_GrayAbnormal_NegLimit_2"
        '
        'Label92
        '
        resources.ApplyResources(Me.Label92, "Label92")
        Me.Label92.Name = "Label92"
        '
        'Label93
        '
        resources.ApplyResources(Me.Label93, "Label93")
        Me.Label93.Name = "Label93"
        '
        'Label94
        '
        resources.ApplyResources(Me.Label94, "Label94")
        Me.Label94.Name = "Label94"
        '
        'Label95
        '
        resources.ApplyResources(Me.Label95, "Label95")
        Me.Label95.Name = "Label95"
        '
        'Label96
        '
        resources.ApplyResources(Me.Label96, "Label96")
        Me.Label96.Name = "Label96"
        '
        'NumericUpDown_GrayAbnormalStandardGray_2
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormalStandardGray_2, "NumericUpDown_GrayAbnormalStandardGray_2")
        Me.NumericUpDown_GrayAbnormalStandardGray_2.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GrayAbnormalStandardGray_2.Name = "NumericUpDown_GrayAbnormalStandardGray_2"
        '
        'NumericUpDown_GrayAbnormal_PosLimit_2
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_PosLimit_2, "NumericUpDown_GrayAbnormal_PosLimit_2")
        Me.NumericUpDown_GrayAbnormal_PosLimit_2.Name = "NumericUpDown_GrayAbnormal_PosLimit_2"
        '
        'GroupBox_GrayAbnormal_3
        '
        resources.ApplyResources(Me.GroupBox_GrayAbnormal_3, "GroupBox_GrayAbnormal_3")
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.Lbl_GrayAbnormal_NegLimit_3)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.Lbl_GrayAbnormal_PosLimit_3)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.NumericUpDown_GrayAbnormal_NegLimit_3)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.Label85)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.Label86)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.Label87)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.Label88)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.Label89)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.NumericUpDown_GrayAbnormalStandardGray_3)
        Me.GroupBox_GrayAbnormal_3.Controls.Add(Me.NumericUpDown_GrayAbnormal_PosLimit_3)
        Me.GroupBox_GrayAbnormal_3.Name = "GroupBox_GrayAbnormal_3"
        Me.GroupBox_GrayAbnormal_3.TabStop = False
        '
        'Lbl_GrayAbnormal_NegLimit_3
        '
        resources.ApplyResources(Me.Lbl_GrayAbnormal_NegLimit_3, "Lbl_GrayAbnormal_NegLimit_3")
        Me.Lbl_GrayAbnormal_NegLimit_3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_NegLimit_3.Name = "Lbl_GrayAbnormal_NegLimit_3"
        '
        'Lbl_GrayAbnormal_PosLimit_3
        '
        resources.ApplyResources(Me.Lbl_GrayAbnormal_PosLimit_3, "Lbl_GrayAbnormal_PosLimit_3")
        Me.Lbl_GrayAbnormal_PosLimit_3.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_PosLimit_3.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Lbl_GrayAbnormal_PosLimit_3.Name = "Lbl_GrayAbnormal_PosLimit_3"
        '
        'NumericUpDown_GrayAbnormal_NegLimit_3
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_NegLimit_3, "NumericUpDown_GrayAbnormal_NegLimit_3")
        Me.NumericUpDown_GrayAbnormal_NegLimit_3.Name = "NumericUpDown_GrayAbnormal_NegLimit_3"
        '
        'Label85
        '
        resources.ApplyResources(Me.Label85, "Label85")
        Me.Label85.Name = "Label85"
        '
        'Label86
        '
        resources.ApplyResources(Me.Label86, "Label86")
        Me.Label86.Name = "Label86"
        '
        'Label87
        '
        resources.ApplyResources(Me.Label87, "Label87")
        Me.Label87.Name = "Label87"
        '
        'Label88
        '
        resources.ApplyResources(Me.Label88, "Label88")
        Me.Label88.Name = "Label88"
        '
        'Label89
        '
        resources.ApplyResources(Me.Label89, "Label89")
        Me.Label89.Name = "Label89"
        '
        'NumericUpDown_GrayAbnormalStandardGray_3
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormalStandardGray_3, "NumericUpDown_GrayAbnormalStandardGray_3")
        Me.NumericUpDown_GrayAbnormalStandardGray_3.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GrayAbnormalStandardGray_3.Name = "NumericUpDown_GrayAbnormalStandardGray_3"
        '
        'NumericUpDown_GrayAbnormal_PosLimit_3
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_PosLimit_3, "NumericUpDown_GrayAbnormal_PosLimit_3")
        Me.NumericUpDown_GrayAbnormal_PosLimit_3.Name = "NumericUpDown_GrayAbnormal_PosLimit_3"
        '
        'CheckBox_MultiRegion
        '
        resources.ApplyResources(Me.CheckBox_MultiRegion, "CheckBox_MultiRegion")
        Me.CheckBox_MultiRegion.Name = "CheckBox_MultiRegion"
        Me.CheckBox_MultiRegion.UseVisualStyleBackColor = True
        '
        'GroupBox_GrayAbnormal_1
        '
        resources.ApplyResources(Me.GroupBox_GrayAbnormal_1, "GroupBox_GrayAbnormal_1")
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.Lbl_GrayAbnormal_NegLimit_1)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.Lbl_GrayAbnormal_PosLimit_1)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.NumericUpDown_GrayAbnormal_NegLimit_1)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.Label31)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.Label32)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.Label33)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.Label34)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.Label35)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.NumericUpDown_GrayAbnormalStandardGray_1)
        Me.GroupBox_GrayAbnormal_1.Controls.Add(Me.NumericUpDown_GrayAbnormal_PosLimit_1)
        Me.GroupBox_GrayAbnormal_1.Name = "GroupBox_GrayAbnormal_1"
        Me.GroupBox_GrayAbnormal_1.TabStop = False
        '
        'Lbl_GrayAbnormal_NegLimit_1
        '
        resources.ApplyResources(Me.Lbl_GrayAbnormal_NegLimit_1, "Lbl_GrayAbnormal_NegLimit_1")
        Me.Lbl_GrayAbnormal_NegLimit_1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_NegLimit_1.Name = "Lbl_GrayAbnormal_NegLimit_1"
        '
        'Lbl_GrayAbnormal_PosLimit_1
        '
        resources.ApplyResources(Me.Lbl_GrayAbnormal_PosLimit_1, "Lbl_GrayAbnormal_PosLimit_1")
        Me.Lbl_GrayAbnormal_PosLimit_1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_PosLimit_1.ForeColor = System.Drawing.SystemColors.InfoText
        Me.Lbl_GrayAbnormal_PosLimit_1.Name = "Lbl_GrayAbnormal_PosLimit_1"
        '
        'NumericUpDown_GrayAbnormal_NegLimit_1
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_NegLimit_1, "NumericUpDown_GrayAbnormal_NegLimit_1")
        Me.NumericUpDown_GrayAbnormal_NegLimit_1.Name = "NumericUpDown_GrayAbnormal_NegLimit_1"
        '
        'Label31
        '
        resources.ApplyResources(Me.Label31, "Label31")
        Me.Label31.Name = "Label31"
        '
        'Label32
        '
        resources.ApplyResources(Me.Label32, "Label32")
        Me.Label32.Name = "Label32"
        '
        'Label33
        '
        resources.ApplyResources(Me.Label33, "Label33")
        Me.Label33.Name = "Label33"
        '
        'Label34
        '
        resources.ApplyResources(Me.Label34, "Label34")
        Me.Label34.Name = "Label34"
        '
        'Label35
        '
        resources.ApplyResources(Me.Label35, "Label35")
        Me.Label35.Name = "Label35"
        '
        'NumericUpDown_GrayAbnormalStandardGray_1
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormalStandardGray_1, "NumericUpDown_GrayAbnormalStandardGray_1")
        Me.NumericUpDown_GrayAbnormalStandardGray_1.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GrayAbnormalStandardGray_1.Name = "NumericUpDown_GrayAbnormalStandardGray_1"
        '
        'NumericUpDown_GrayAbnormal_PosLimit_1
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_PosLimit_1, "NumericUpDown_GrayAbnormal_PosLimit_1")
        Me.NumericUpDown_GrayAbnormal_PosLimit_1.Name = "NumericUpDown_GrayAbnormal_PosLimit_1"
        '
        'CheckBox_GrayAbnormal_Enable
        '
        resources.ApplyResources(Me.CheckBox_GrayAbnormal_Enable, "CheckBox_GrayAbnormal_Enable")
        Me.CheckBox_GrayAbnormal_Enable.Name = "CheckBox_GrayAbnormal_Enable"
        Me.CheckBox_GrayAbnormal_Enable.UseVisualStyleBackColor = True
        '
        'Label_Pattern
        '
        resources.ApplyResources(Me.Label_Pattern, "Label_Pattern")
        Me.Label_Pattern.Name = "Label_Pattern"
        '
        'ComboBox_PatternList
        '
        resources.ApplyResources(Me.ComboBox_PatternList, "ComboBox_PatternList")
        Me.ComboBox_PatternList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PatternList.Name = "ComboBox_PatternList"
        '
        'Dialog_MuraSetting
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Label_Pattern)
        Me.Controls.Add(Me.ComboBox_PatternList)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.Button_Close)
        Me.Controls.Add(Me.TabControl_Setting)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraSetting"
        Me.ShowInTaskbar = False
        Me.TabPage_Save.ResumeLayout(False)
        Me.GroupBox_Save.ResumeLayout(False)
        Me.GroupBox_Save.PerformLayout()
        CType(Me.NumericUpDown_AlignPercentage, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Alignment.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.NumericUpDown_FFTFilterRadius, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_GlobleSmooth.ResumeLayout(False)
        Me.GroupBox_GlobleSmooth.PerformLayout()
        CType(Me.NumericUpDown_MacroMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlobMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Defocus.ResumeLayout(False)
        Me.GroupBox_Defocus.PerformLayout()
        CType(Me.NumericUpDown_PitchY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_PitchX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DefocusCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_FFCOperation.ResumeLayout(False)
        Me.GroupBox_SettingFFC.ResumeLayout(False)
        Me.GroupBox_SettingFFC.PerformLayout()
        CType(Me.NumericUpDown_AlignValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl_Setting.ResumeLayout(False)
        Me.TabPage_Center.ResumeLayout(False)
        Me.TabPage_Center.PerformLayout()
        CType(Me.NumericUpDown_BlobMulRatio, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MuraRatio.ResumeLayout(False)
        Me.GroupBox_MuraRatio.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.NumericUpDown_MacroPowerY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MacroPowerX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Mid2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.Num_ResizeCount_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Mid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Parameter.ResumeLayout(False)
        Me.GroupBox_Parameter.PerformLayout()
        CType(Me.NUD_BlackBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackMacroMura_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteMacroMura_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Modify.ResumeLayout(False)
        Me.GroupBox_Area.ResumeLayout(False)
        CType(Me.NumericUpDown_AreaRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AreaLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AreaTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AreaBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_CPD.ResumeLayout(False)
        Me.GroupBox_WithoutCoreCPDRecipe.ResumeLayout(False)
        Me.GroupBox_WithoutCoreCPDRecipe.PerformLayout()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDBreadth_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDElongation_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDElongation_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPDCompactness_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDBreadth_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPD_ThHigh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPD_ThHigh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDElongation_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreBlackCPD_ThLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPD_ThLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithoutCoreWhiteCPDCompactness_High, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WithCoreCPDRecipe.ResumeLayout(False)
        Me.GroupBox_WithCoreCPDRecipe.PerformLayout()
        CType(Me.NumericUpDown_WithCoreBlackCPDCompactness_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDCompactness_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDBreadth_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDBreadth_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDElongation_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreBlackCPDElongation_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDCompactness_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDCompactness_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDBreadth_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDBreadth_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDElongation_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPDElongation_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPD_ThLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreBlackCPD_ThLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreWhiteCPD_ThHigh, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WithCoreBlackCPD_ThHigh, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Rim.ResumeLayout(False)
        Me.GroupBox_GoldenSampleParameter.ResumeLayout(False)
        CType(Me.NumericUpDown_Resize, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Smooth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_RimType.ResumeLayout(False)
        Me.GroupBox_RimModify.ResumeLayout(False)
        Me.GroupBox_Round.ResumeLayout(False)
        CType(Me.NumericUpDown_RimRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_RimParameter.ResumeLayout(False)
        Me.GroupBox_RimParameter.PerformLayout()
        CType(Me.NumericUpDown_BlackMura_RimLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlackMura_RimHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteMura_RimLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteMura_RimHeight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Band.ResumeLayout(False)
        Me.GroupBox_BandParameter.ResumeLayout(False)
        Me.GroupBox_BandParameter.PerformLayout()
        CType(Me.NumericUpDown_BlackVBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlackHBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteHBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteVBand_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BandMura_SmoothCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BandMura_ResizeCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BandModify.ResumeLayout(False)
        Me.GroupBox_V.ResumeLayout(False)
        CType(Me.NumericUpDown_VTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VBottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VLeft, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_H.ResumeLayout(False)
        CType(Me.NumericUpDown_HRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_HVValue.ResumeLayout(False)
        Me.TabPage_HVValue.PerformLayout()
        CType(Me.NumericUpDown_VValue_BlackVBandTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_VValue_WhiteVBandTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HValue_BlackHBandTH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HValue_WhiteHBandTH, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Manual.ResumeLayout(False)
        CType(Me.NumericUpDown_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Value, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_JND_1.ResumeLayout(False)
        Me.GroupBox_JND_1.ResumeLayout(False)
        Me.GroupBox_WhiteBandJND.ResumeLayout(False)
        Me.GroupBox_WhiteBandJND.PerformLayout()
        CType(Me.NUD_WhiteBandMura_WidthMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBandMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBandMura_SJND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WhiteAGM.ResumeLayout(False)
        Me.GroupBox_WhiteAGM.PerformLayout()
        CType(Me.NUD_WhiteAGM_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_JND_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteAGM_JND_Max, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WhiteMacroJND.ResumeLayout(False)
        Me.GroupBox_WhiteMacroJND.PerformLayout()
        CType(Me.NUD_WhiteMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteMacroMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_WhiteBlobJND.ResumeLayout(False)
        Me.GroupBox_WhiteBlobJND.PerformLayout()
        CType(Me.NUD_WhiteBlobMura_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_JND_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_JND_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_JND_2.ResumeLayout(False)
        Me.GroupBox_JND_2.ResumeLayout(False)
        Me.GroupBox_BlackBandJND.ResumeLayout(False)
        Me.GroupBox_BlackBandJND.PerformLayout()
        CType(Me.NUD_BlackBandMura_WidthMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBandMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBandMura_SJND, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BlackAGM.ResumeLayout(False)
        Me.GroupBox_BlackAGM.PerformLayout()
        CType(Me.NUD_BlackAGM_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_JND_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackAGM_JND_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NUD_BlackMacroMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackMacroMura_JND, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackMacroMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BlackBlobJND.ResumeLayout(False)
        Me.GroupBox_BlackBlobJND.PerformLayout()
        CType(Me.NUD_BlackBlobMura_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_JND_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_JND_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Auto.ResumeLayout(False)
        Me.GroupBox_AutoExposure.ResumeLayout(False)
        Me.GroupBox_AutoExposure.PerformLayout()
        CType(Me.NumericUpDown_AutoExposure_GrabDelayTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_SmallErrorRange, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_TargetMean, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_Kp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Abnormal.ResumeLayout(False)
        Me.TabPage_Abnormal.PerformLayout()
        Me.GroupBox_GrayAbnormal_2.ResumeLayout(False)
        Me.GroupBox_GrayAbnormal_2.PerformLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit_2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_GrayAbnormal_3.ResumeLayout(False)
        Me.GroupBox_GrayAbnormal_3.PerformLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit_3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_GrayAbnormal_1.ResumeLayout(False)
        Me.GroupBox_GrayAbnormal_1.PerformLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit_1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CheckBox_SaveBlackReconstructArea As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveBlackThreshold As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveWhiteReconstructArea As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveWhiteThreshold As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents CheckBox_SaveSmooth As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveOriginal As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveHBand As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveVBand As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage_Save As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox_UseFFC As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_AlignPercentage As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AlignpPercentage As System.Windows.Forms.Label
    Friend WithEvents Button_SaveFFCImages As System.Windows.Forms.Button
    Friend WithEvents TabPage_Alignment As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_FFCOperation As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_AlignValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Align As System.Windows.Forms.Label
    Friend WithEvents Button_FFCImage As System.Windows.Forms.Button
    Friend WithEvents Button_Boundary As System.Windows.Forms.Button
    Friend WithEvents TabControl_Setting As System.Windows.Forms.TabControl
    Friend WithEvents GroupBox_Save As System.Windows.Forms.GroupBox
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_PatternList As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_Defocus As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_DefocusCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_SaveDefocus As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage_Auto As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_AutoExposure As System.Windows.Forms.GroupBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AutoExposure_SmallErrorRange As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_AutoExposure_LargeErrorRange_UL As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_AutoExposure_TargetMean As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_AutoExposure_Kp As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AutoExposure_LargeErrorRange_DL As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_PitchY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_PitchX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_GlobleSmooth As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_MacroMura_GlobleSmooth As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlobMura_GlobleSmooth As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_SaveWhiteReconstructRim As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveBlackReconstructRim As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveFFCAlignResult As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_SettingFFC As System.Windows.Forms.GroupBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Lbl_Max_GrayLevel As System.Windows.Forms.Label
    Friend WithEvents Button_Calculate_Max As System.Windows.Forms.Button
    Friend WithEvents TabPage_Abnormal As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_GrayAbnormal_1 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_GrayAbnormal_NegLimit_1 As System.Windows.Forms.Label
    Friend WithEvents Lbl_GrayAbnormal_PosLimit_1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormal_NegLimit_1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormalStandardGray_1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_GrayAbnormal_PosLimit_1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_GrayAbnormal_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AutoExposure_GrabDelayTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents TabPage_Center As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_MuraRatio As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Parameter As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_BlackBlobMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBlobMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackMacroMura_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteMacroMura_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_ReconstructLow As System.Windows.Forms.Label
    Friend WithEvents Label_ReconstructHeight As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Modify As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_Show As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_Manual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Finish As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_Area As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_AreaRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AreaLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AreaTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AreaBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaTop As System.Windows.Forms.Label
    Friend WithEvents TabPage_Rim As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_GoldenSampleParameter As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Resize As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Resize As System.Windows.Forms.Label
    Friend WithEvents Label_Smooth As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Smooth As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_RimType As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_RimModify As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowRound As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_RoundManual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_RoundFinish As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_Round As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_RimRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Right As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Left As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Bottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Top As System.Windows.Forms.Label
    Friend WithEvents GroupBox_RimParameter As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlackMura_RimLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackMura_RimHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteMura_RimLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_RoundLow As System.Windows.Forms.Label
    Friend WithEvents Label_RoundHeight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WhiteMura_RimHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Rim As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage_Band As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox_Band As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_BandParameter As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlackVBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackHBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteHBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteVBand_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackBand_Thrshold As System.Windows.Forms.Label
    Friend WithEvents Label_HBand_Thrshold As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BandMura_SmoothCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Band_SmoothCount As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BandMura_ResizeCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Band_ResizeCount As System.Windows.Forms.Label
    Friend WithEvents GroupBox_BandModify As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_V As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_VRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_VRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_VLeft As System.Windows.Forms.Label
    Friend WithEvents GroupBox_H As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_HTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_HBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_HTOP As System.Windows.Forms.Label
    Friend WithEvents TabPage_JND_1 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_JND_1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_WhiteBandJND As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_WhiteBandMura_WidthMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_WhiteBandMura_WidthMin As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteBandMura_JND As System.Windows.Forms.Label
    Friend WithEvents Labell_WhiteBandMura_SJND As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBandMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBandMura_SJND As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_WhiteAGM As System.Windows.Forms.GroupBox
    Friend WithEvents Label_WhiteAGM_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteAGM_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteAGM_JND_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AGM_WhiteAreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteAGM_JND As System.Windows.Forms.Label
    Friend WithEvents GroupBox_WhiteMacroJND As System.Windows.Forms.GroupBox
    Friend WithEvents Label_WhiteMacroMura_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteMacroMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteMacroMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_WhiteMacroMura_AreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteMacroMura_JND As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteMacroMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_WhiteBlobJND As System.Windows.Forms.GroupBox
    Friend WithEvents Label_WhiteBlob_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBlobMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBlobMura_JND_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_WhiteBlob_AreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_WhiteBlobMura_JND As System.Windows.Forms.Label
    Friend WithEvents TabPage_JND_2 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_JND_2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_BlackBandJND As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_BlackBandMura_WidthMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackBandMura_WidthMin As System.Windows.Forms.Label
    Friend WithEvents Label_BlackBandMura_JND As System.Windows.Forms.Label
    Friend WithEvents Labell_BlackBandMura_SJND As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBandMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBandMura_SJND As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_BlackAGM As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BlackAGM_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackAGM_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackAGM_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackAGM_JND_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BlackMacroMura_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackMacroMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackMacroMura_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackMacroMura_AreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_BlackMacroMura_JND As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackMacroMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_BlackBlobJND As System.Windows.Forms.GroupBox
    Friend WithEvents Label_BlackBlob_AreaMin As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_JND_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlackBlob_AreaMax As System.Windows.Forms.Label
    Friend WithEvents Label_BlackBlobMura_JND As System.Windows.Forms.Label
    Friend WithEvents TabPage_CPD As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox_WithoutCoreCPD_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_WithoutCoreCPDRecipe As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPDBreadth_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPDBreadth_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPD_ThHigh As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPD_ThHigh As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPDElongation_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPDElongation_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPD_ThLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPD_ThLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPDCompactness_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreWhiteCPDCompactness_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_WithCoreCPDRecipe As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_WithCoreWhiteCPDBreadth_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreWhiteCPDBreadth_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithCoreWhiteCPDElongation_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreWhiteCPDElongation_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithCoreWhiteCPDCompactness_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreWhiteCPDCompactness_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreWhiteCPD_ThLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreBlackCPD_ThLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithCoreWhiteCPD_ThHigh As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreBlackCPD_ThHigh As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_WithCoreCPD_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_HRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPDCompactness_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPDBreadth_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPDBreadth_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPDElongation_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPDElongation_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithoutCoreBlackCPDCompactness_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WithCoreBlackCPDCompactness_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreBlackCPDCompactness_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreBlackCPDBreadth_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreBlackCPDBreadth_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreBlackCPDElongation_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WithCoreBlackCPDElongation_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_SaveResizeBMP As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_RemoveHVBand As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_UseBLFFC As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_UseFFT As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_FFTFilterRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_SaveFFTResult As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_UseBaseLine As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Center As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Num_ResizeCount_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Num_ResizeCount_Mid As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MacroPowerY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_MacroPowerX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Num_ResizeCount_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Num_ResizeCount_Mid2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents TabPage_HVValue As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox_UseHValue As System.Windows.Forms.CheckBox
    Friend WithEvents ListView_HValue As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_HValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_HJND As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView_VValue As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_VValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_VJND As System.Windows.Forms.ColumnHeader
    Friend WithEvents CheckBox_UseVValue As System.Windows.Forms.CheckBox
    Friend WithEvents Label_VValueCount As System.Windows.Forms.Label
    Friend WithEvents Label_HValueCount As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Manual As System.Windows.Forms.GroupBox
    Friend WithEvents Button_AddOne As System.Windows.Forms.Button
    Friend WithEvents Button_Clear As System.Windows.Forms.Button
    Friend WithEvents Label_Y As System.Windows.Forms.Label
    Friend WithEvents Label_Value As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_JND As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Value As System.Windows.Forms.NumericUpDown
    Friend WithEvents ComboBox_ValueType As System.Windows.Forms.ComboBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Button_CalculateLSQ As System.Windows.Forms.Button
    Friend WithEvents Label_VValueL1 As System.Windows.Forms.Label
    Friend WithEvents Label_HValueL1 As System.Windows.Forms.Label
    Friend WithEvents Label_VConst As System.Windows.Forms.Label
    Friend WithEvents Label_VSlope As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label_HConst As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label_HSlope As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_JND_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteAGM_JND_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents NUD_WhiteBlobMura_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackAGM_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackAGM_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackAGM_JND_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_JND_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_VValue_BlackVBandTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_VValue_WhiteVBandTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_VValue_UseVBand As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_HValue_BlackHBandTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_HValue_WhiteHBandTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_HValue_UseHBand As System.Windows.Forms.CheckBox
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_UseReconstructBW As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_BlobMulRatio As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_GrayAbnormal_2 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_GrayAbnormal_NegLimit_2 As System.Windows.Forms.Label
    Friend WithEvents Lbl_GrayAbnormal_PosLimit_2 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormal_NegLimit_2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label96 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormalStandardGray_2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_GrayAbnormal_PosLimit_2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_GrayAbnormal_3 As System.Windows.Forms.GroupBox
    Friend WithEvents Lbl_GrayAbnormal_NegLimit_3 As System.Windows.Forms.Label
    Friend WithEvents Lbl_GrayAbnormal_PosLimit_3 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormal_NegLimit_3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormalStandardGray_3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_GrayAbnormal_PosLimit_3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_MultiRegion As System.Windows.Forms.CheckBox
End Class
