<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_BlobMuraLocal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_BlobMuraLocal))
        Me.NUD_WhiteBlobMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.Label_ReconstructLow = New System.Windows.Forms.Label()
        Me.Label_ReconstructHeight = New System.Windows.Forms.Label()
        Me.Label_AreaLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_AreaTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_AreaBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_AreaTop = New System.Windows.Forms.Label()
        Me.GroupBox_Parameter = New System.Windows.Forms.GroupBox()
        Me.NUD_BlackBlobMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteBlobMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NUD_BlackMacroMura_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.NUD_BlackBlobMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.NUD_WhiteMacroMura_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Label_Select = New System.Windows.Forms.Label()
        Me.ComboBox_Select = New System.Windows.Forms.ComboBox()
        Me.NumericUpDown_AreaLeft = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Show = New System.Windows.Forms.CheckBox()
        Me.Button_CalculateBlob = New System.Windows.Forms.Button()
        Me.NumericUpDown_AreaRight = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Modify = New System.Windows.Forms.GroupBox()
        Me.RadioButton_Manual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Finish = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Area = New System.Windows.Forms.GroupBox()
        Me.Label_AreaRight = New System.Windows.Forms.Label()
        Me.BtnPre_BlobMuraLocal = New System.Windows.Forms.Button()
        Me.CheckBox_Center = New System.Windows.Forms.CheckBox()
        Me.CheckBox_UseReconstructBW = New System.Windows.Forms.CheckBox()
        CType(Me.NUD_WhiteBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AreaTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AreaBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Parameter.SuspendLayout()
        CType(Me.NUD_BlackBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackMacroMura_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_BlackBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_WhiteMacroMura_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AreaLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AreaRight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Modify.SuspendLayout()
        Me.GroupBox_Area.SuspendLayout()
        Me.SuspendLayout()
        '
        'NUD_WhiteBlobMura_ReconstructHeight
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_ReconstructHeight, "NUD_WhiteBlobMura_ReconstructHeight")
        Me.NUD_WhiteBlobMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_ReconstructHeight.Name = "NUD_WhiteBlobMura_ReconstructHeight"
        '
        'Label_ReconstructLow
        '
        resources.ApplyResources(Me.Label_ReconstructLow, "Label_ReconstructLow")
        Me.Label_ReconstructLow.Name = "Label_ReconstructLow"
        '
        'Label_ReconstructHeight
        '
        resources.ApplyResources(Me.Label_ReconstructHeight, "Label_ReconstructHeight")
        Me.Label_ReconstructHeight.Name = "Label_ReconstructHeight"
        '
        'Label_AreaLeft
        '
        resources.ApplyResources(Me.Label_AreaLeft, "Label_AreaLeft")
        Me.Label_AreaLeft.Name = "Label_AreaLeft"
        '
        'NumericUpDown_AreaTop
        '
        resources.ApplyResources(Me.NumericUpDown_AreaTop, "NumericUpDown_AreaTop")
        Me.NumericUpDown_AreaTop.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_AreaTop.Name = "NumericUpDown_AreaTop"
        '
        'Label_AreaBottom
        '
        resources.ApplyResources(Me.Label_AreaBottom, "Label_AreaBottom")
        Me.Label_AreaBottom.Name = "Label_AreaBottom"
        '
        'NumericUpDown_AreaBottom
        '
        resources.ApplyResources(Me.NumericUpDown_AreaBottom, "NumericUpDown_AreaBottom")
        Me.NumericUpDown_AreaBottom.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_AreaBottom.Name = "NumericUpDown_AreaBottom"
        '
        'Label_AreaTop
        '
        resources.ApplyResources(Me.Label_AreaTop, "Label_AreaTop")
        Me.Label_AreaTop.Name = "Label_AreaTop"
        '
        'GroupBox_Parameter
        '
        resources.ApplyResources(Me.GroupBox_Parameter, "GroupBox_Parameter")
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_BlackBlobMura_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_WhiteBlobMura_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.Label25)
        Me.GroupBox_Parameter.Controls.Add(Me.Label1)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_BlackMacroMura_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_BlackBlobMura_ReconstructHeight)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_WhiteBlobMura_ReconstructHeight)
        Me.GroupBox_Parameter.Controls.Add(Me.NUD_WhiteMacroMura_Threshold)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_ReconstructHeight)
        Me.GroupBox_Parameter.Name = "GroupBox_Parameter"
        Me.GroupBox_Parameter.TabStop = False
        '
        'NUD_BlackBlobMura_ReconstructLow
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_ReconstructLow, "NUD_BlackBlobMura_ReconstructLow")
        Me.NUD_BlackBlobMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBlobMura_ReconstructLow.Name = "NUD_BlackBlobMura_ReconstructLow"
        '
        'NUD_WhiteBlobMura_ReconstructLow
        '
        resources.ApplyResources(Me.NUD_WhiteBlobMura_ReconstructLow, "NUD_WhiteBlobMura_ReconstructLow")
        Me.NUD_WhiteBlobMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteBlobMura_ReconstructLow.Name = "NUD_WhiteBlobMura_ReconstructLow"
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'NUD_BlackMacroMura_Threshold
        '
        resources.ApplyResources(Me.NUD_BlackMacroMura_Threshold, "NUD_BlackMacroMura_Threshold")
        Me.NUD_BlackMacroMura_Threshold.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackMacroMura_Threshold.Name = "NUD_BlackMacroMura_Threshold"
        '
        'NUD_BlackBlobMura_ReconstructHeight
        '
        resources.ApplyResources(Me.NUD_BlackBlobMura_ReconstructHeight, "NUD_BlackBlobMura_ReconstructHeight")
        Me.NUD_BlackBlobMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_BlackBlobMura_ReconstructHeight.Name = "NUD_BlackBlobMura_ReconstructHeight"
        '
        'NUD_WhiteMacroMura_Threshold
        '
        resources.ApplyResources(Me.NUD_WhiteMacroMura_Threshold, "NUD_WhiteMacroMura_Threshold")
        Me.NUD_WhiteMacroMura_Threshold.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NUD_WhiteMacroMura_Threshold.Name = "NUD_WhiteMacroMura_Threshold"
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        '
        'Label_Select
        '
        resources.ApplyResources(Me.Label_Select, "Label_Select")
        Me.Label_Select.Name = "Label_Select"
        '
        'ComboBox_Select
        '
        resources.ApplyResources(Me.ComboBox_Select, "ComboBox_Select")
        Me.ComboBox_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Select.Name = "ComboBox_Select"
        '
        'NumericUpDown_AreaLeft
        '
        resources.ApplyResources(Me.NumericUpDown_AreaLeft, "NumericUpDown_AreaLeft")
        Me.NumericUpDown_AreaLeft.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_AreaLeft.Name = "NumericUpDown_AreaLeft"
        '
        'CheckBox_Show
        '
        resources.ApplyResources(Me.CheckBox_Show, "CheckBox_Show")
        Me.CheckBox_Show.Name = "CheckBox_Show"
        '
        'Button_CalculateBlob
        '
        resources.ApplyResources(Me.Button_CalculateBlob, "Button_CalculateBlob")
        Me.Button_CalculateBlob.Name = "Button_CalculateBlob"
        '
        'NumericUpDown_AreaRight
        '
        resources.ApplyResources(Me.NumericUpDown_AreaRight, "NumericUpDown_AreaRight")
        Me.NumericUpDown_AreaRight.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_AreaRight.Name = "NumericUpDown_AreaRight"
        '
        'GroupBox_Modify
        '
        resources.ApplyResources(Me.GroupBox_Modify, "GroupBox_Modify")
        Me.GroupBox_Modify.Controls.Add(Me.CheckBox_Show)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Manual)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Finish)
        Me.GroupBox_Modify.Controls.Add(Me.GroupBox_Area)
        Me.GroupBox_Modify.Name = "GroupBox_Modify"
        Me.GroupBox_Modify.TabStop = False
        '
        'RadioButton_Manual
        '
        resources.ApplyResources(Me.RadioButton_Manual, "RadioButton_Manual")
        Me.RadioButton_Manual.Name = "RadioButton_Manual"
        '
        'RadioButton_Finish
        '
        resources.ApplyResources(Me.RadioButton_Finish, "RadioButton_Finish")
        Me.RadioButton_Finish.Name = "RadioButton_Finish"
        '
        'GroupBox_Area
        '
        resources.ApplyResources(Me.GroupBox_Area, "GroupBox_Area")
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaRight)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaRight)
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaLeft)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaLeft)
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaTop)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaBottom)
        Me.GroupBox_Area.Controls.Add(Me.NumericUpDown_AreaBottom)
        Me.GroupBox_Area.Controls.Add(Me.Label_AreaTop)
        Me.GroupBox_Area.Name = "GroupBox_Area"
        Me.GroupBox_Area.TabStop = False
        '
        'Label_AreaRight
        '
        resources.ApplyResources(Me.Label_AreaRight, "Label_AreaRight")
        Me.Label_AreaRight.Name = "Label_AreaRight"
        '
        'BtnPre_BlobMuraLocal
        '
        resources.ApplyResources(Me.BtnPre_BlobMuraLocal, "BtnPre_BlobMuraLocal")
        Me.BtnPre_BlobMuraLocal.Name = "BtnPre_BlobMuraLocal"
        Me.BtnPre_BlobMuraLocal.UseVisualStyleBackColor = True
        '
        'CheckBox_Center
        '
        resources.ApplyResources(Me.CheckBox_Center, "CheckBox_Center")
        Me.CheckBox_Center.Name = "CheckBox_Center"
        '
        'CheckBox_UseReconstructBW
        '
        resources.ApplyResources(Me.CheckBox_UseReconstructBW, "CheckBox_UseReconstructBW")
        Me.CheckBox_UseReconstructBW.Name = "CheckBox_UseReconstructBW"
        '
        'Dialog_BlobMuraLocal
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.CheckBox_UseReconstructBW)
        Me.Controls.Add(Me.CheckBox_Center)
        Me.Controls.Add(Me.BtnPre_BlobMuraLocal)
        Me.Controls.Add(Me.GroupBox_Parameter)
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.Label_Select)
        Me.Controls.Add(Me.ComboBox_Select)
        Me.Controls.Add(Me.Button_CalculateBlob)
        Me.Controls.Add(Me.GroupBox_Modify)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_BlobMuraLocal"
        Me.ShowInTaskbar = False
        CType(Me.NUD_WhiteBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AreaTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AreaBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Parameter.ResumeLayout(False)
        Me.GroupBox_Parameter.PerformLayout()
        CType(Me.NUD_BlackBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteBlobMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackMacroMura_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_BlackBlobMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_WhiteMacroMura_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AreaLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AreaRight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Modify.ResumeLayout(False)
        Me.GroupBox_Area.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents NUD_WhiteBlobMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_ReconstructLow As System.Windows.Forms.Label
    Friend WithEvents Label_ReconstructHeight As System.Windows.Forms.Label
    Friend WithEvents Label_AreaLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AreaTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AreaBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_AreaTop As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Parameter As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_WhiteMacroMura_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Label_Select As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Select As System.Windows.Forms.ComboBox
    Friend WithEvents NumericUpDown_AreaLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Show As System.Windows.Forms.CheckBox
    Friend WithEvents Button_CalculateBlob As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_AreaRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_Modify As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_Manual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Finish As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_Area As System.Windows.Forms.GroupBox
    Friend WithEvents Label_AreaRight As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackMacroMura_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_BlackBlobMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NUD_BlackBlobMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NUD_WhiteBlobMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents BtnPre_BlobMuraLocal As System.Windows.Forms.Button
    Friend WithEvents CheckBox_Center As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_UseReconstructBW As System.Windows.Forms.CheckBox
End Class
