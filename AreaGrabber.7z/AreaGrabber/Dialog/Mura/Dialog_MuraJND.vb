﻿Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.IO
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraJND
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess

    '--- 連線參數 ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    Private m_CurrentStep As Integer
    Private m_Have_FFCImage As Boolean
    Private m_SaveImage As Boolean = True

    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL
        Dim i As Integer

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraJND", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess

        '-- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '[AreaGrabber]
        Me.ComboBox_PatternList.Items.Clear()
        For i = 0 To Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1
            Me.ComboBox_PatternList.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
        Next

        If Me.m_Form.GetPatternIndexInfo > Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.m_MainProcess.SetRecipe(Me.m_MuraProcess.MuraPatternRecipeArray.Item(0).PatternName.Value, Me.m_MainProcess.ErrorCode)
            Me.ComboBox_PatternList.SelectedIndex = 0
        Else
            Me.m_MainProcess.SetRecipe(Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.m_Form.GetPatternIndexInfo).PatternName.Value, Me.m_MainProcess.ErrorCode)
            Me.ComboBox_PatternList.SelectedIndex = Me.m_Form.GetPatternIndexInfo
        End If

        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
            image = Me.m_MuraProcess.Img_ChildSample
        Else
            image = Me.m_MuraProcess.Img_ChildOriginal
        End If

        If image <> M_NULL Then
            If language <> "zh-CN" Then
                Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("可視區影像")
            Else
                Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("可视区影像")
            End If
        Else
            Me.m_Form.ComboBox_Type.SelectedIndex = -1
        End If
        image = Me.m_MuraProcess.Img_16U_Defocus_NonPage
        If image <> M_NULL Then
            If language <> "zh-CN" Then
                Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("可視區糊焦影像")
            Else
                Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("可视区糊焦影像")
            End If
        Else
            Me.m_Form.ComboBox_Type.SelectedIndex = -1
        End If

        If Me.m_MuraProcess.Img_CurrentOriginal_NonPage <> M_NULL Or Me.m_MuraProcess.Img_CurrentSample_NonPage <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        Me.m_Form.ImageZoomAll()

        Me.UpdateData()
        Me.UpdateUserLevel()
        Me.Update()
    End Sub

    Private Sub Dialog_JND_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.Finalize()
    End Sub

#Region "--- 方法函示 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_JNDSetting.Enabled = False
            Case 1 'PM
                Me.GroupBox_JNDSetting.Enabled = False
            Case 2 'ENG
                Me.GroupBox_JNDSetting.Enabled = True
            Case 3 'ALL
                Me.GroupBox_JNDSetting.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Me.CheckBox_AutoAddFalse.Checked = Me.m_MuraProcess.MuraModelRecipe.AutoAddFalse.Value
        '--- White Blob Mura ---
        Me.NUD_WhiteBlobMura_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMin.Value
        Me.NUD_WhiteBlobMura_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMax.Value
        Me.NUD_WhiteBlobMura_JNDMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMin.Value
        Me.NUD_WhiteBlobMura_JNDMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMax.Value
        Me.NUD_WhiteBlobMura_ElongationMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMin.Value
        Me.NUD_WhiteBlobMura_ElongationMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMax.Value
        '--- White Macro Mura ---
        Me.NUD_WhiteMacroMura_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMin.Value
        Me.NUD_WhiteMacroMura_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMax.Value
        Me.NUD_WhiteMacroMura_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_JND.Value
        '--- White AGM ---
        Me.NUD_WhiteAGM_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMin.Value
        Me.NUD_WhiteAGM_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMax.Value
        Me.NUD_WhiteAGM_JNDMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMin.Value
        Me.NUD_WhiteAGM_JNDMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMax.Value
        Me.NUD_WhiteAGM_ElongationMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMin.Value
        Me.NUD_WhiteAGM_ElongationMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMax.Value
        '--- White Band Mura ---
        Me.NUD_WhiteBandMura_WidthMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_WidthMin.Value
        Me.NUD_WhiteBandMura_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_JND.Value
        Me.NUD_WhiteBandMura_SJND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_SJND.Value

        '--- Black Blob Mura ---
        Me.NUD_BlackBlobMura_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMin.Value
        Me.NUD_BlackBlobMura_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMax.Value
        Me.NUD_BlackBlobMura_JNDMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMin.Value
        Me.NUD_BlackBlobMura_JNDMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMax.Value
        Me.NUD_BlackBlobMura_ElongationMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMin.Value
        Me.NUD_BlackBlobMura_ElongationMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMax.Value
        '--- Black Macro Mura ---
        Me.NUD_BlackMacroMura_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMin.Value
        Me.NUD_BlackMacroMura_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMax.Value
        Me.NUD_BlackMacroMura_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_JND.Value
        '--- Black AGM ---
        Me.NUD_BlackAGM_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMin.Value
        Me.NUD_BlackAGM_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMax.Value
        Me.NUD_BlackAGM_JNDMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMin.Value
        Me.NUD_BlackAGM_JNDMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMax.Value
        Me.NUD_BlackAGM_ElongationMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMin.Value
        Me.NUD_BlackAGM_ElongationMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMax.Value
        '--- Black Band Mura ---
        Me.NUD_BlackBandMura_WidthMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_WidthMin.Value
        Me.NUD_BlackBandMura_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_JND.Value
        Me.NUD_BlackBandMura_SJND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_SJND.Value

        '---WhiteCPD---
        Me.NUD_WhiteCPD_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_AreaMin
        Me.NUD_WhiteCPD_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_AreaMax
        Me.NUD_WhiteCPD_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_JND
        '---BlackCPD---
        Me.NUD_BlackCPD_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_AreaMin
        Me.NUD_BlackCPD_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_AreaMax
        Me.NUD_BlackCPD_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_JND
        '---WhiteGapMura---
        Me.NUD_WhiteGapMura_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_AreaMin
        Me.NUD_WhiteGapMura_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_AreaMax
        Me.NUD_WhiteGapMura_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_JND
        '---BlackGapMura---
        Me.NUD_BlackGapMura_AreaMin.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_AreaMin
        Me.NUD_BlackGapMura_AreaMax.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_AreaMax
        Me.NUD_BlackGapMura_JND.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_JND
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- GetPatternIndexInfoCallback ---"
    Delegate Function GetPatternIndexInfoCallback() As Integer
    Private Function GetPatternIndexInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_PatternList.InvokeRequired Then
            Return Me.Invoke(New GetPatternIndexInfoCallback(AddressOf GetPatternIndexInfo), New Object() {})
        Else
            i = Me.ComboBox_PatternList.SelectedIndex
            Me.Update()
            Return i
        End If
    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_LoadChild.Enabled = En
        Me.Button_JND.Enabled = En

        Me.Button_Ok.Enabled = En
        Me.Button_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- DoStep ---"
    Private Function DoStep(ByRef ErrorCode As UInt32) As Boolean
        Dim mp As ClsMuraProcess
        Dim boundary As ClsParameterBoundary = Nothing
        Dim boundary2 As ClsParameterBoundary = Nothing
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim str As String
        Dim dir1 As String
        Dim str2 As String = ""
        Dim InputImage_Type As String = ""
        Dim ImageFilePath As String = ""
        Dim Image_Range As String = ""
        Dim DirPath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim shift As Integer
        Dim RoundExpandWidth As Integer

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
        str = ""
        mp = Me.m_MuraProcess

        Select Case Me.m_CurrentStep

            Case 1
                '----------------------------------------------------------------------------------------------
                ' IP Clear Mura Group Defects  ==> Request_Command = "CLEAR_MURAGROUP" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CLEAR_MURAGROUP"
                    TimeOut = 100000 '100 secs

                    '--- Local Action ---
                    mp.MuraGroup.Clear()
                    mp.MuraGroup_All.Clear()

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_Form.OpenFileDialog.FileName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Clear Mura Group Defects Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Calculate Mura Original Boundary  ==> Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"  (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original Boundary Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]邊界分析有誤 (" & SubSystemResult.ErrMessage & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                    '--- Get ROI Boundary ---
                    boundary = Me.m_MuraProcess.BoundaryOriginal
                    If Response_OK Then
                        OutputString = SubSystemResult.Responses(0).Param2
                        strs1 = OutputString.Split(";")

                        If Me.m_MuraProcess.MuraModelRecipe.UseAutoFFC.Value Then
                            boundary = Me.m_MuraProcess.BoundarySample
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)

                            boundary2 = Me.m_MuraProcess.BoundaryOriginal
                            boundary2.TopY = strs1(0)
                            boundary2.BottomY = strs1(1)
                            boundary2.LeftX = strs1(2)
                            boundary2.RightX = strs1(3)
                        Else
                            boundary = Me.m_MuraProcess.BoundaryOriginal
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)
                        End If

                        '--- Update MuraModelRecipe.Boundary ---
                        boundary2 = Me.m_MuraProcess.MuraModelRecipe.Boundary
                        boundary2.TopY = strs1(0)
                        boundary2.BottomY = strs1(1)
                        boundary2.LeftX = strs1(2)
                        boundary2.RightX = strs1(3)
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate Mura Original Boundary Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MURA_ORIGINALROI"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, "TRUE", , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]割取ROI影像有誤 (" & SubSystemResult.ErrMessage & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                    If Response_OK Then
                        '--- Update Processed Image ---
                        '避免影像重疊, 2011/01/30 Rick add
                        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                            Me.m_MuraProcess.CalculateFFCROI(ErrorCode)
                        Else
                            Me.m_MuraProcess.CalculateOriginalROI(ErrorCode)
                        End If
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate Mura Original ROI Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Create Mura Image  ==> Request_Command = "CALCULATE_MURA_CREATEIMAGE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MURA_CREATEIMAGE"
                    TimeOut = 300000 '300 secs
                    Image_Range = "PART"

                    '--- Local Action ---
                    Me.m_MuraProcess.Mura_CreateImage(Me.m_MainProcess.IPBootConfig, Me.m_MuraProcess.BoundaryOriginal, Me.m_MuraProcess.MuraModelRecipe, ErrorCode)

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Image_Range, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Create Mura Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Create Mura Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '--- 存圖確認 --- 
                'mp.Img_ChildOriginal_1.Save("D:\Mura_Img_ChildOriginal.tif")

            Case 2

                If Not Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                    '----------------------------------------------------------------------------------------------
                    ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
                    ' 確認處理的影像：Img_ChildOriginal。(雖然在使用FFC情況下，其為流程控制。)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_ROIEXPAND"
                        TimeOut = 200000 '200 secs
                        InputImage_Type = "CHILD_ORIGINAL"

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate ROI Expand Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

            Case 3
                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 100000 '100 secs

                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        InputImage_Type = "NONE"
                    Else
                        InputImage_Type = "CHILD_ORIGINAL"
                    End If

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, Me.m_SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                    If Me.m_SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate Defocus Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

            Case 4
                If mp.CurrentMuraPatternRecipe.UseFFC.Value Then

                    '----------------------------------------------------------------------------------------------
                    ' Check FFC Image  ==> Request_Command = "CHECK_FFC_IMAGE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CHECK_FFC_IMAGE"
                        TimeOut = 100000 '100 secs

                        '--- Local Action ---
                        dir1 = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
                        str2 = dir1 & "\ImageFFC_C" & Me.m_MainProcess.GrabNo & "_P" & (Me.m_Form.GetPatternIndexInfo + 1) & ".tif"

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str2, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                            If SubSystemResult.Responses(0).Param1.ToUpper = "TRUE" Then
                                Me.m_Have_FFCImage = True
                            Else
                                Me.m_Have_FFCImage = False
                                MsgBox("[Dialog_MuraAutoMannual.DoStep]Pattern = " & Me.m_MuraProcess.CurrentMuraPatternRecipe.PatternName.Value & " 缺少亮校正影像 Data !", MsgBoxStyle.Critical, "[AreaGrabber]")   '2009/09/25 Rick modify

                                '--- Local Action ---
                                Me.m_CurrentStep = 0
                                Return False
                            End If
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Check FFC Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage & "(Path：" & str2 & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Check FFC Image Error ! (" & ex.Message & ")" & "(Path：" & str2 & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message & "(Path：" & str2 & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try


                    If mp.Img_CurrentFFCAlign <> M_NULL Then
                        'mp.CalculateFFCResult(ErrorCode)
                        'mp.CalculateROIExpand(mp.Img_16U_FFCResult_NonPage, ErrorCode)

                        '----------------------------------------------------------------------------------------------
                        ' Calculate FFC Result Image  ==> Request_Command = "CALCULATE_FFCRESULT" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "CALCULATE_FFCRESULT"
                            TimeOut = 300000 '300 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Result Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                                '--- Local Action ---
                                Me.m_CurrentStep = 0
                                Return False
                            End If

                            If Me.m_SaveImage AndAlso Response_OK Then
                                '--- Update Processed Image ---
                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_FFCResult_NonPage.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_FFCResult_NonPage.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If Me.m_MuraProcess.Img_16U_FFCResult_NonPage <> M_NULL Then
                                        If MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(Me.m_MuraProcess.Img_16U_FFCResult_NonPage)
                                            Me.m_MuraProcess.Img_16U_FFCResult_NonPage = M_NULL
                                            Me.m_MuraProcess.Img_16U_FFCResult_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        Me.m_MuraProcess.Img_16U_FFCResult_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_FFCResult_NonPage)

                                    If System.IO.File.Exists(strPath) = True Then
                                        System.IO.File.Delete(strPath)
                                    End If
                                End If
                            End If
                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate FFC Align Image Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End Try

                        '----------------------------------------------------------------------------------------------
                        ' Calculate ROI Expand Image (With FFC) ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "CALCULATE_ROIEXPAND"
                            TimeOut = 200000 '200 secs
                            InputImage_Type = "FFC_RESULT"

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image (With FFC) Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                                '--- Local Action ---
                                Me.m_CurrentStep = 0
                                Return False
                            End If

                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate ROI Expand Image (With FFC)  Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End Try

                        'mp.Img_16U_ROIExpand_NonPage.Save("D:\Img_16U_ROIExpand_NonPage.tif")
                    Else
                        MsgBox("[Dialog_MuraAutoMannual.DoStep]Pattern = " & Me.m_MuraProcess.CurrentMuraPatternRecipe.PatternName.Value & " 缺少亮校正影像 Data !", MsgBoxStyle.Critical, "[AreaGrabber]")   '2009/09/25 Rick modify
                        Me.m_CurrentStep = 0
                        Return False
                    End If
                End If


                '----------------------------------------------------------------------------------------------
                ' Calculate Smooth Image  ==> Request_Command = "CALCULATE_SMOOTH" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_SMOOTH"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.RemoveHVBand.Value Then
                        '--- Prepare Command ---
                        Request_Command = "REMOVE_HVBAND"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    End If
                    If Me.m_SaveImage AndAlso Response_OK Then
                        '[1] --- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)
                                    Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If

                        '[2] --- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)
                                    Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If

                        '[3] --- Update Processed Image ---
                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If
                        shift = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

                        If Me.m_MuraProcess.Img_BlobMura_SmoothChild <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_BlobMura_SmoothChild)
                            Me.m_MuraProcess.Img_BlobMura_SmoothChild = M_NULL
                        End If
                        Me.m_MuraProcess.Img_BlobMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                        '[4] Update Processed Image ---
                        If Me.m_MuraProcess.Img_MacroMura_SmoothChild <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_MacroMura_SmoothChild)
                            Me.m_MuraProcess.Img_MacroMura_SmoothChild = M_NULL
                        End If
                        Me.m_MuraProcess.Img_MacroMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Smooth Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                'mp.Img_16U_BlobMura_Smooth_NonPage.Save("D:\Img_16U_BlobMura_Smooth_NonPage.tif")

            Case 5
                If mp.CurrentMuraPatternRecipe.UseCenter.Value Or mp.CurrentMuraPatternRecipe.UseRound.Value Then
                    '----------------------------------------------------------------------------------------------
                    ' Calculate Area Golden Sample Image  ==> Request_Command = "CALCULATE_AREA_GOLDENSAMPLE" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_AREA_GOLDENSAMPLE"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Area Golden Sample Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then

                            RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

                            '--- Blob Mura ---
                            '[1] Update Processed Image (Img_16U_BlobMura_ResizeH_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_BlobMura_ResizeHChild) ---
                                If Me.m_MuraProcess.Img_BlobMura_ResizeHChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlobMura_ResizeHChild)
                                    Me.m_MuraProcess.Img_BlobMura_ResizeHChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_BlobMura_ResizeHChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            '[3] Update Processed Image (Img_16U_BlobMura_ResizeL_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[4] Update Processed Image (Img_BlobMura_ResizeLChild) ---
                                If Me.m_MuraProcess.Img_BlobMura_ResizeLChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlobMura_ResizeLChild)
                                    Me.m_MuraProcess.Img_BlobMura_ResizeLChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_BlobMura_ResizeLChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            'Macro Mura ---
                            '[1] Update Processed Image (Img_16U_MacroMura_ResizeH_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_MacroMura_ResizeHChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_ResizeHChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_ResizeHChild)
                                    Me.m_MuraProcess.Img_MacroMura_ResizeHChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_MacroMura_ResizeHChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            '[3] Update Processed Image (Img_16U_MacroMura_ResizeL_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[4] Update Processed Image (Img_MacroMura_ResizeLChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_ResizeLChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_ResizeLChild)
                                    Me.m_MuraProcess.Img_MacroMura_ResizeLChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_MacroMura_ResizeLChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Area Golden Sample Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    'mp.Img_16U_GoldenSample_NonPage.Save("D:\Img_16U_GoldenSample_NonPage.tif")
                End If
            Case 6
                If mp.CurrentMuraPatternRecipe.UseCenter.Value Or mp.CurrentMuraPatternRecipe.UseRound.Value Then
                    '影像相減 - Blob Black
                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Area Image  ==> Request_Command = "CALCULATE_BLACK_AREA" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACK_AREA"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_BlobMura_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_BlobMuraArea_BlackChild) ---
                                If Me.m_MuraProcess.Img_BlobMuraArea_BlackChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlobMuraArea_BlackChild)
                                    Me.m_MuraProcess.Img_BlobMuraArea_BlackChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_BlobMuraArea_BlackChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Area Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If mp.CurrentMuraPatternRecipe.UseCenter.Value Then
                    '影像相減 - Blob Black
                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Macro Image  ==> Request_Command = "CALCULATE_BLACK_MACRO" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACK_MACRO"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_MacroMura_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_MacroMura_BlackChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_BlackChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_BlackChild)
                                    Me.m_MuraProcess.Img_MacroMura_BlackChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_MacroMura_BlackChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Macro Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Blob Mura (Area-中心區)  ==> Request_Command = "CALCULATE_BLACKBLOB_AREA" (Dispatcher 2)
                    ' 計算 Black Blob + Macro 
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACKBLOB_AREA"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_BlackReconstructArea_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage)
                                        Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_BlackThreshold_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage)
                                        Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Blob Mura  Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If mp.CurrentMuraPatternRecipe.UseCenter.Value Or mp.CurrentMuraPatternRecipe.UseRound.Value Then
                    '影像相減 - Blob White
                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Area Image  ==> Request_Command = "CALCULATE_WHITE_AREA" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITE_AREA"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_BlobMura_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_BlobMuraArea_WhiteChild) ---
                            If Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild <> M_NULL Then
                                MbufFree(Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild)
                                Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild = M_NULL
                            End If

                            If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                            Else
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                            End If

                            Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Area Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If mp.CurrentMuraPatternRecipe.UseCenter.Value Then
                    '影像相減 - Macro White
                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Macro Image  ==> Request_Command = "CALCULATE_WHITE_MACRO" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITE_MACRO"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_MacroMura_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_MacroMura_WhiteChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_WhiteChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_WhiteChild)
                                    Me.m_MuraProcess.Img_MacroMura_WhiteChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_MacroMura_WhiteChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Macro Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Blob Mura (Area-中心區)  ==> Request_Command = "CALCULATE_WHITEBLOB_AREA" (Dispatcher 2)
                    ' 計算 White Blob + Macro 
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITEBLOB_AREA"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_WhiteReconstructArea_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage)
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_WhiteThreshold_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage)
                                        Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Blob Mura  Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    'mp.Img_16U_BlobMura_White_NonPage.Save("D:\Me.m_Img_16U_BlobMura_White_NonPage.tif")
                    'mp.Img_16U_BlobMura_Black_NonPage.Save("D:\Me.m_Img_16U_BlobMura_Black_NonPage.tif")
                End If
            Case 7
                If mp.CurrentMuraPatternRecipe.UseRound.Value Then

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Reconstruct Rim Image  ==> Request_Command = "CALCULATE_RECONSTRUCT_RIM" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_RECONSTRUCT_RIM"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Reconstruct Rim Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '--- White Reconstruct Rim ---

                            '[1] Update Processed Image (Img_1U_WhiteReconstructRim_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_WhiteReconstructRImChild) ---
                                If Me.m_MuraProcess.Img_WhiteReconstructRImChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_WhiteReconstructRImChild)
                                    Me.m_MuraProcess.Img_WhiteReconstructRImChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_WhiteReconstructRImChild = MbufChild2d(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            'Black Reconstruct Rim ---

                            '[1] Update Processed Image (Img_1U_BlackReconstructRim_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage)
                                        Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_BlackReconstructRimChild) ---
                                If Me.m_MuraProcess.Img_BlackReconstructRimChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlackReconstructRimChild)
                                    Me.m_MuraProcess.Img_BlackReconstructRimChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_BlackReconstructRimChild = MbufChild2d(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Reconstruct Rim Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Rim Mura  ==> Request_Command = "CALCULATE_BLACKBLOB_RIM" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACKBLOB_RIM"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Rim Mura Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Rim Mura  ==> Request_Command = "CALCULATE_WHITEBLOB_RIM" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITEBLOB_RIM"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Rim Mura Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                End If
                If mp.CurrentMuraPatternRecipe.UseBand.Value Then

                    '**** 垂直 BandMura ******************************************************************************

                    '----------------------------------------------------------------------------------------------
                    ' Calculate V-Band Mura ROI Image  ==> Request_Command = "CALCULATE_VROI" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_VROI"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, False, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Response_OK Then
                            '[1] Update Processed Image (Img_BandMura_ChildOriginalV) ---
                            RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
                            If Me.m_MuraProcess.Img_BandMura_ChildOriginalV <> M_NULL Then
                                MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalV)
                                Me.m_MuraProcess.Img_BandMura_ChildOriginalV = M_NULL
                            End If
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) - Me.m_MuraProcess.MuraModelRecipe.Band.RightX - Me.m_MuraProcess.MuraModelRecipe.Band.LeftX - 2 * RoundExpandWidth
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) - 2 * RoundExpandWidth

                            While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
                                SizeX = SizeX - 1
                            End While

                            While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
                                SizeY = SizeY - 1
                            End While

                            Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.TopY, SizeX, SizeY, M_NULL)
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate V-Band Mura ROI Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate V-Band Mura Projection Image  ==> Request_Command = "CALCULATE_VBAND_PROJECT" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_VBAND_PROJECT"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_VProject_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VProject_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VProject_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VProject_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VProject_NonPage)
                                        Me.m_MuraProcess.Img_16U_VProject_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VProject_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate V-Band Mura Projection Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Golden V-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_V" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_GOLDEN_V"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden V-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_VGolden_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VGolden_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VGolden_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VGolden_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VGolden_NonPage)
                                        Me.m_MuraProcess.Img_16U_VGolden_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VGolden_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Golden V-Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try


                    '**** 水平 BandMura ******************************************************************************

                    '----------------------------------------------------------------------------------------------
                    ' Calculate H-Band Mura ROI Image  ==> Request_Command = "CALCULATE_HROI" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_HROI"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, False, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Response_OK Then
                            '[1] Update Processed Image (Img_BandMura_ChildOriginalH) ---
                            RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
                            If Me.m_MuraProcess.Img_BandMura_ChildOriginalH <> M_NULL Then
                                MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalH)
                                Me.m_MuraProcess.Img_BandMura_ChildOriginalH = M_NULL
                            End If

                            While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
                                SizeX = SizeX - 1
                            End While

                            While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)
                                SizeY = SizeY - 1
                            End While

                            Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.TopY, SizeX, SizeY, M_NULL)
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate H-Band Mura ROI Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate H-Band Mura Projection Image  ==> Request_Command = "CALCULATE_HBAND_PROJECT" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_HBAND_PROJECT"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HProject_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HProject_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HProject_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HProject_NonPage)
                                        Me.m_MuraProcess.Img_16U_HProject_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HProject_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate H-Band Mura Projection Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Golden H-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_H" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_GOLDEN_H"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden H-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HGolden_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HGolden_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HGolden_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HGolden_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HGolden_NonPage)
                                        Me.m_MuraProcess.Img_16U_HGolden_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HGolden_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Golden H-Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Band Image  ==> Request_Command = "CALCULATE_WHITE_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITE_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HBand_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_HBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_16U_VBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VBand_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_VBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Band Image  ==> Request_Command = "CALCULATE_BLACK_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACK_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_16U_VBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate H-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_H_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_H_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_HBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_HBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_HBand_White_NonPage)
                                        Me.m_MuraProcess.Img_1U_HBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_HBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_HBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate H-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate V-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_V_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_V_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_VBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_VBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_VBand_White_NonPage)
                                        Me.m_MuraProcess.Img_1U_VBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_VBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_VBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate V-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

            Case 8

                '----------------------------------------------------------------------------------------------
                ' Calculate Mura JND  ==> Request_Command = "CALCULATE_JND" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_JND"
                    TimeOut = 500000 '500 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura JND Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Mura JND Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Shift all Mura Position to global position  ==> Request_Command = "POSITION_SHIFT_ALL" (Dispatcher 2)
                ' Function： Shift to global position
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "POSITION_SHIFT_ALL"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Shift all Mura Position to global position  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Mura JND Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' MappingTable Translation  ==> Request_Command = "CALCULATE_MAPTOTABLE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MAPTOTABLE"
                    TimeOut = 500000 '500 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate MappingTable Translation Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate MappingTable Translation Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try


                If Me.CheckBox_FilterMura.Checked Then
                    '----------------------------------------------------------------------------------------------
                    ' Filter Mura within Regions  ==> Request_Command = "MURA_FILTERREGION_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_FILTERREGION_ANALYSIS"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Filter Mura within Regions Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Filter Mura within Regions Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                '----------------------------------------------------------------------------------------------
                ' Merge all Mura Group  ==> Request_Command = "MERGE_MURAGROUP_ALL" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MERGE_MURAGROUP_ALL"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Merge all Mura Group Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Merge all Mura Group Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                If Me.CheckBox_FilterFalseCPD.Checked Then

                    '----------------------------------------------------------------------------------------------
                    ' Filter Mura With False Defect Table  ==> Request_Command = "MURA_FILTERFALSECPD_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_FILTERFALSECPD_ANALYSIS"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.CheckBox_FilterFalseCPD.Checked, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Filter Mura With False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Filter CPD Mura With False Defect Table Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If Me.CheckBox_FilterMura.Checked And Me.CheckBox_AutoAddFalse.Checked Then

                    '----------------------------------------------------------------------------------------------
                    ' Filter Mura With False Defect Table  ==> Request_Command = "MURA_FILTERWITHFALSE_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_FILTERWITHFALSE_ANALYSIS"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Filter Mura With False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Filter Mura With False Defect Table Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' End Filter Mura With False Defect Table  ==> Request_Command = "MURA_ENDFILTERWITHFALSE_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_ENDFILTERWITHFALSE_ANALYSIS"
                        TimeOut = 600000 '600 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "End Filter Mura With False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]End Filter Mura With False Defect Table Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Reset Mura False  ==> Request_Command = "MURA_RESETFALSE" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_RESETFALSE"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Reset Mura False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Reset Mura False Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                '取得 Mura All Group Defects
                '----------------------------------------------------------------------------------------------
                ' Get all Mura Group Defects ==> Request_Command = "GET_ALL_MURA_RESULT" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "GET_ALL_MURA_RESULT"
                    TimeOut = 500000 '500 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get all Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                    If Response_OK Then
                        '--- 解新 Defect ----
                        OutputString = SubSystemResult.Responses(0).Param2
                        Me.m_MainProcess.AddMuraString(OutputString)
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Merge allGet all Mura Group Defects Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save Mura False Defect Table  ==> Request_Command = "SAVE_MURA_FALSEDEFECTTABLE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_MURA_FALSEDEFECTTABLE"
                    TimeOut = 100000 '100 secs

                    '--- Save MuraFalse Defect Table ---
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\\" & Me.m_Form.GetProductNameInfo & "\\Mura\\MuraFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str)
                    str = str.Replace("\", "\\")

                    '--- Save MuraFalse Defect Table ---
                    str2 = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\\" & Me.m_Form.GetProductNameInfo & "\\Mura\\MuraFalseDefectTableBackup_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str2)
                    str2 = str2.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, str2, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Save Mura False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Save Mura False Defect File Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                Me.m_Form.ResultUpdate()

            Case 9

                If Me.CheckBox_SaveMuraDefectsImgs.Checked Then
                    '----------------------------------------------------------------------------------------------
                    ' Save Mura Defect Image ==> Request_Command = "SAVE_MURA_DEFECTIMAGE" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SAVE_MURA_DEFECTIMAGE"
                        TimeOut = 100000 '100 secs

                        '--- Save MuraFalse Defect Table ---
                        str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                        Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str)
                        str = str.Replace("\", "\\")

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Save Mura Defect Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Return False
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Save Mura Defect Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                Me.m_MainProcess.CountMuraDefect()

                '----------------------------------------------------------------------------------------------
                ' Save intermediate images ==> Request_Command = "SAVE_INTERMEDIATE_IMAGE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_INTERMEDIATE_IMAGE"
                    TimeOut = 200000 '200 secs
                    ImageFilePath = Me.m_MainProcess.IMAGE_PATH & "\\IP" & Me.m_Form.ComboBox_CCD.Text & "\\AAAAAAAA\\ChipNo_C" & Me.m_MainProcess.CCDNo & "_P" & Me.m_Form.GetPatternNameInfo & "_FMura"
                    DirPath = Me.m_MainProcess.IMAGE_PATH & "\\IP" & Me.m_Form.ComboBox_CCD.Text & "\\AAAAAAAA\\"

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, ImageFilePath, DirPath, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save intermediate images Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Save intermediate images Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

        End Select

        If Me.m_CurrentStep >= 10 Then Me.m_CurrentStep = 9
        Return True
    End Function
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Me.Button_LoadChild.Text = res.GetString("Button_LoadChild.Text")
                Me.Button_Ok.Text = res.GetString("Button_Ok.Text")
                Me.Button_Cancel.Text = res.GetString("Button_Cancel.Text")
                Me.Button_JND.Text = res.GetString("Button_JND.Text")
                'WhiteBlob
                Me.Label_WhiteBlob_AreaMin.Text = res.GetString("Label_WhiteBlob_AreaMin.Text")
                Me.Label_WhiteBlob_AreaMax.Text = res.GetString("Label_WhiteBlob_AreaMax.Text")
                Me.Label_WhiteBlobMura_JND.Text = res.GetString("Label_WhiteBlobMura_JND.Text")
                Me.Label27.Text = res.GetString("Label27.Text")
                Me.Label29.Text = res.GetString("Label29.Text")
                Me.Label30.Text = res.GetString("Label30.Text")
                'BlackBlob
                Me.Label_BlackBlob_AreaMin.Text = res.GetString("Label_BlackBlob_AreaMin.Text")
                Me.Label_BlackBlob_AreaMax.Text = res.GetString("Label_BlackBlob_AreaMax.Text")
                Me.Label_BlackBlobMura_JND.Text = res.GetString("Label_BlackBlobMura_JND.Text")
                Me.Label28.Text = res.GetString("Label28.Text")
                Me.Label32.Text = res.GetString("Label32.Text")
                Me.Label31.Text = res.GetString("Label31.Text")
                'WhiteAGM
                Me.Label_WhiteAGM_AreaMin.Text = res.GetString("Label_WhiteAGM_AreaMin.Text")
                Me.Label_AGM_WhiteAreaMax.Text = res.GetString("Label_AGM_WhiteAreaMax.Text")
                Me.Label_WhiteAGM_JND.Text = res.GetString("Label_WhiteAGM_JND.Text")
                Me.Label37.Text = res.GetString("Label37.Text")
                Me.Label34.Text = res.GetString("Label34.Text")
                Me.Label33.Text = res.GetString("Label33.Text")
                'BlackAGM
                Me.Label_BlackAGM_AreaMin.Text = res.GetString("Label_BlackAGM_AreaMin.Text")
                Me.Label8.Text = res.GetString("Label8.Text")
                Me.Label9.Text = res.GetString("Label9.Text")
                Me.Label38.Text = res.GetString("Label38.Text")
                Me.Label36.Text = res.GetString("Label36.Text")
                Me.Label35.Text = res.GetString("Label35.Text")
                'White CPD
                Me.Label4.Text = res.GetString("Label4.Text")
                Me.Label5.Text = res.GetString("Label5.Text")
                Me.Label6.Text = res.GetString("Label6.Text")
                'Black CPD
                Me.Label1.Text = res.GetString("Label1.Text")
                Me.Label2.Text = res.GetString("Label2.Text")
                Me.Label3.Text = res.GetString("Label3.Text")
                'White Gap Mura 
                Me.Label24.Text = res.GetString("Label24.Text")
                Me.Label25.Text = res.GetString("Label25.Text")
                Me.Label26.Text = res.GetString("Label26.Text")
                'Black Gap Mura
                Me.Label21.Text = res.GetString("Label21.Text")
                Me.Label22.Text = res.GetString("Label22.Text")
                Me.Label23.Text = res.GetString("Label23.Text")
                'White Macro Mura
                Me.Label_WhiteMacroMura_AreaMin.Text = res.GetString("Label_WhiteMacroMura_AreaMin.Text")
                Me.Label_WhiteMacroMura_AreaMax.Text = res.GetString("Label_WhiteMacroMura_AreaMax.Text")
                Me.Label_WhiteMacroMura_JND.Text = res.GetString("Label_WhiteMacroMura_JND.Text")
                'Black Macro Mura
                Me.Label_BlackMacroMura_AreaMin.Text = res.GetString("Label_BlackMacroMura_AreaMin.Text")
                Me.Label_BlackMacroMura_AreaMax.Text = res.GetString("Label_BlackMacroMura_AreaMax.Text")
                Me.Label_BlackMacroMura_JND.Text = res.GetString("Label_BlackMacroMura_JND.Text")
                'White Band Mura
                Me.Label_WhiteBandMura_JND.Text = res.GetString("Label_WhiteBandMura_JND.Text")
                Me.Labell_WhiteBandMura_SJND.Text = res.GetString("Labell_WhiteBandMura_SJND.Text")
                Me.Label_WhiteBandMura_WidthMin.Text = res.GetString("Label_WhiteBandMura_WidthMin.Text")
                'Black Band Mura
                Me.Label_BlackBandMura_JND.Text = res.GetString("Label_BlackBandMura_JND.Text")
                Me.Labell_BlackBandMura_SJND.Text = res.GetString("Labell_BlackBandMura_SJND.Text")
                Me.Label_BlackBandMura_WidthMin.Text = res.GetString("Label_BlackBandMura_WidthMin.Text")
                'JND
                Me.GroupBox_JNDSetting.Text = res.GetString("GroupBox_JNDSetting.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_LoadChild ---"
    Private Sub Button_LoadChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LoadChild.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---
            Me.Button_LoadChild.Enabled = False

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                    image = Me.m_MuraProcess.Img_ChildSample
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                Else
                    image = Me.m_MuraProcess.Img_ChildOriginal
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                End If

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, image)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, "IP" & Me.m_Form.ComboBox_CCD.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 100000 '100 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraJND.Button_LoadChild]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_LoadChild.Enabled = True
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then

                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 300000 '300 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraJND.Button_LoadChild]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_LoadChild.Enabled = True
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '--- Display Image ---  
                                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                                    If image <> M_NULL Then
                                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                                        Type = MbufInquire(image, M_TYPE, M_NULL)

                                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                            MbufFree(imageBuffer)
                                            imageBuffer = M_NULL
                                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                        End If
                                        MbufCopy(image, imageBuffer)

                                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                        Me.m_Form.ResetScrollBar()
                                    End If
                                Else
                                    Me.m_Form.CurrentIndex0 = 2
                                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                                    Me.m_Form.ComboBox_Select.SelectedIndex = 2
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                Else
                    '----------------------------------------------------------------------------------------------
                    ' Defocus Original Image  ==> Request_Command = "DEFOCUS_ORIGINAL_2" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "DEFOCUS_ORIGINAL_2"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Defocus Original_2 Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraJND.Button_LoadChild]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_LoadChild.Enabled = True
                            Exit Sub
                        End If

                        If Response_OK Then
                            '--- Update Processed Image ---
                            image = Me.m_MuraProcess.Img_16U_Defocus_NonPage
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "DefocusOriginal_2.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "DefocusOriginal_2.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then

                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If
                '-------------------------------------------------------------------------------------------------------------------------------------------------------

                If Me.ComboBox_Select.Items.Count = 1 Then
                    Me.ComboBox_Select.Items.Add("糊焦後影像")
                End If

                Me.Button_LoadChild.Enabled = True
                Call Me.m_Form.ImageZoomAll()
            End If
        Catch ex As Exception
            Me.Button_LoadChild.Enabled = True
            Me.m_Form.OutputInfo("[Dialog_MuraJND.Button_LoadChild]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraJND.Button_LoadChild]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_JND ---"
    Private Sub Button_JND_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_JND.Click
        Dim errMsg As String = ""
        Dim OutputString As String = ""
        Dim Parameter_Lists As String = ""

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If


        '--- White ---
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMin.Value = Me.NUD_WhiteBlobMura_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMax.Value = Me.NUD_WhiteBlobMura_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMin.Value = Me.NUD_WhiteBlobMura_JNDMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMax.Value = Me.NUD_WhiteBlobMura_JNDMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMin.Value = Me.NUD_WhiteBlobMura_ElongationMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMax.Value = Me.NUD_WhiteBlobMura_ElongationMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMin.Value = Me.NUD_WhiteAGM_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMax.Value = Me.NUD_WhiteAGM_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMin.Value = Me.NUD_WhiteAGM_JNDMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMax.Value = Me.NUD_WhiteAGM_JNDMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMin.Value = Me.NUD_WhiteAGM_ElongationMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMax.Value = Me.NUD_WhiteAGM_ElongationMax.Value

        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMin.Value = Me.NUD_WhiteMacroMura_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMax.Value = Me.NUD_WhiteMacroMura_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_JND.Value = Me.NUD_WhiteMacroMura_JND.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_WidthMin.Value = Me.NUD_WhiteBandMura_WidthMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_JND.Value = Me.NUD_WhiteBandMura_JND.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_SJND.Value = Me.NUD_WhiteBandMura_SJND.Value

        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_AreaMin = Me.NUD_WhiteCPD_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_AreaMax = Me.NUD_WhiteCPD_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_JND = Me.NUD_WhiteCPD_JND.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_AreaMin = Me.NUD_WhiteGapMura_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_AreaMax = Me.NUD_WhiteGapMura_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_JND = Me.NUD_WhiteGapMura_JND.Value

        '--- Black ---
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMin.Value = Me.NUD_BlackBlobMura_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMax.Value = Me.NUD_BlackBlobMura_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMin.Value = Me.NUD_BlackBlobMura_JNDMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMax.Value = Me.NUD_BlackBlobMura_JNDMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMin.Value = Me.NUD_BlackBlobMura_ElongationMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMax.Value = Me.NUD_BlackBlobMura_ElongationMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMin.Value = Me.NUD_BlackAGM_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMax.Value = Me.NUD_BlackAGM_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMin.Value = Me.NUD_BlackAGM_JNDMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMax.Value = Me.NUD_BlackAGM_JNDMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMin.Value = Me.NUD_BlackAGM_ElongationMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMax.Value = Me.NUD_BlackAGM_ElongationMax.Value

        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMin.Value = Me.NUD_BlackMacroMura_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMax.Value = Me.NUD_BlackMacroMura_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_JND.Value = Me.NUD_BlackMacroMura_JND.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_WidthMin.Value = Me.NUD_BlackBandMura_WidthMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_JND.Value = Me.NUD_BlackBandMura_JND.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_SJND.Value = Me.NUD_BlackBandMura_SJND.Value

        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_AreaMin = Me.NUD_BlackCPD_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_AreaMax = Me.NUD_BlackCPD_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_JND = Me.NUD_BlackCPD_JND.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_AreaMin = Me.NUD_BlackGapMura_AreaMin.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_AreaMax = Me.NUD_BlackGapMura_AreaMax.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_JND = Me.NUD_BlackGapMura_JND.Value

        Me.m_MuraProcess.MuraModelRecipe.AutoAddFalse.Value = Me.CheckBox_AutoAddFalse.Checked

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraJND Setting   ==> Request_Command = "DIALOG_MURAJND_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try

            '--- Prepare Command ---
            Request_Command = "DIALOG_MURAJND_SETTING"
            TimeOut = 100000 '100 secs
            Parameter_Lists = "AutoAddFalse," & Me.CheckBox_AutoAddFalse.Checked & ";" & _
                              "WhiteBlobMura_AreaMin," & Me.NUD_WhiteBlobMura_AreaMin.Value & ";" & "WhiteBlobMura_AreaMax," & Me.NUD_WhiteBlobMura_AreaMax.Value & ";" & _
                              "WhiteBlobMura_JNDMin," & Me.NUD_WhiteBlobMura_JNDMin.Value & ";" & "WhiteBlobMura_JNDMax," & Me.NUD_WhiteBlobMura_JNDMax.Value & ";" & "WhiteBlobMura_ElongationMin," & Me.NUD_WhiteBlobMura_ElongationMin.Value & ";" & "WhiteBlobMura_ElongationMax," & Me.NUD_WhiteBlobMura_ElongationMax.Value & ";" & _
                              "WhiteAGM_AreaMin," & Me.NUD_WhiteAGM_AreaMin.Value & ";" & "WhiteAGM_AreaMax," & Me.NUD_WhiteAGM_AreaMax.Value & ";" & _
                              "WhiteAGM_JNDMin," & Me.NUD_WhiteAGM_JNDMin.Value & ";" & "WhiteAGM_JNDMax," & Me.NUD_WhiteAGM_JNDMax.Value & ";" & "WhiteAGM_ElongationMin," & Me.NUD_WhiteAGM_ElongationMin.Value & ";" & "WhiteAGM_ElongationMax," & Me.NUD_WhiteAGM_ElongationMax.Value & ";" & _
                              "WhiteMacroMura_AreaMin," & Me.NUD_WhiteMacroMura_AreaMin.Value & ";" & "WhiteMacroMura_AreaMax," & Me.NUD_WhiteMacroMura_AreaMax.Value & ";" & "WhiteMacroMura_JND," & Me.NUD_WhiteMacroMura_JND.Value & ";" & _
                              "WhiteBandMura_JND," & Me.NUD_WhiteBandMura_JND.Value & ";" & "WhiteBandMura_SJND," & Me.NUD_WhiteBandMura_SJND.Value & ";" & "WhiteBandMura_WidthMin," & Me.NUD_WhiteBandMura_WidthMin.Value & ";" & _
                              "BlackBlobMura_AreaMin," & Me.NUD_BlackBlobMura_AreaMin.Value & ";" & "BlackBlobMura_AreaMax," & Me.NUD_BlackBlobMura_AreaMax.Value & ";" & _
                              "BlackBlobMura_JNDMin," & Me.NUD_BlackBlobMura_JNDMin.Value & ";" & "BlackBlobMura_JNDMax," & Me.NUD_BlackBlobMura_JNDMax.Value & ";" & "BlackBlobMura_ElongationMin," & Me.NUD_BlackBlobMura_ElongationMin.Value & ";" & "BlackBlobMura_ElongationMax," & Me.NUD_BlackBlobMura_ElongationMax.Value & ";" & _
                              "BlackAGM_AreaMin," & Me.NUD_BlackAGM_AreaMin.Value & ";" & "BlackAGM_AreaMax," & Me.NUD_BlackAGM_AreaMax.Value & ";" & "BlackAGM_JND," & Me.NUD_BlackAGM_JNDMin.Value & ";" & _
                              "BlackMacroMura_AreaMin," & Me.NUD_BlackMacroMura_AreaMin.Value & ";" & "BlackMacroMura_AreaMax," & Me.NUD_BlackMacroMura_AreaMax.Value & ";" & "BlackMacroMura_JND," & Me.NUD_BlackMacroMura_JND.Value & ";" & _
                              "BlackBandMura_JND," & Me.NUD_BlackBandMura_JND.Value & ";" & "BlackBandMura_SJND," & Me.NUD_BlackBandMura_SJND.Value & ";" & "BlackBandMura_WidthMin," & Me.NUD_BlackBandMura_WidthMin.Value & ";" & _
                              "WhiteCPD_AreaMin," & Me.NUD_WhiteCPD_AreaMin.Value & ";" & "WhiteCPD_AreaMax," & Me.NUD_WhiteCPD_AreaMax.Value & ";" & "WhiteCPD_JND," & Me.NUD_WhiteCPD_JND.Value & ";" & _
                              "BlackCPD_AreaMin," & Me.NUD_BlackCPD_AreaMin.Value & ";" & "BlackCPD_AreaMax," & Me.NUD_BlackCPD_AreaMax.Value & ";" & "BlackCPD_JND," & Me.NUD_BlackCPD_JND.Value & ";" & _
                              "WhiteGapMura_AreaMin," & Me.NUD_WhiteGapMura_AreaMin.Value & ";" & "WhiteGapMura_AreaMax," & Me.NUD_WhiteGapMura_AreaMax.Value & ";" & "WhiteGapMura_JND," & Me.NUD_WhiteGapMura_JND.Value & ";" & _
                              "BlackGapMura_AreaMin," & Me.NUD_BlackGapMura_AreaMin.Value & ";" & "BlackGapMura_AreaMax," & Me.NUD_BlackGapMura_AreaMax.Value & ";" & "BlackGapMura_JND," & Me.NUD_BlackGapMura_JND.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraJND Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraJND.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.Button_Ok]Dialog_MuraJND Setting Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraJND.Button_Ok]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        For i = 1 To 9
            Me.m_CurrentStep = i
            If Not Me.DoStep(Me.m_MainProcess.ErrorCode) Then
                Me.Enabled = True
                Return
            End If
        Next

        ''----------------------------------------------------------------------------------------------
        '' IP Clear Mura Group Defects  ==> Request_Command = "CLEAR_MURAGROUP" (Dispatcher 1)
        ''----------------------------------------------------------------------------------------------
        'Try
        '    '--- Prepare Command ---
        '    Request_Command = "CLEAR_MURAGROUP"
        '    TimeOut = 100000 '100 secs

        '    '--- Local action ---
        '    Me.m_MuraProcess.MuraGroup_All.Clear()
        '    Me.m_MuraProcess.MuraGroup.Clear()

        '    Response_OK = False
        '    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_Form.OpenFileDialog.FileName, , , , , , , , TimeOut)
        '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

        '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
        '        Response_OK = True
        '    Else
        '        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '        MessageBox.Show("[Dialog_MuraBoundary.Button_JND]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        Exit Sub
        '    End If

        'Catch ex As Exception
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.Button_JND]Clear Mura Group Defects Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        '    MessageBox.Show("[Dialog_MuraBoundary.Button_JND]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        ''----------------------------------------------------------------------------------------------
        '' Calculate Mura Defects  ==> Request_Command = "CALCULATE_DEFECTSAVE" (Dispatcher 2)
        ''----------------------------------------------------------------------------------------------
        'Try
        '    '--- Prepare Command ---
        '    Request_Command = "CALCULATE_DEFECTSAVE"
        '    TimeOut = 500000 '500 secs

        '    Response_OK = False
        '    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
        '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

        '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
        '        Response_OK = True
        '    Else
        '        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '        MessageBox.Show("[Dialog_MuraJND.Button_JND]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        Exit Sub
        '    End If
        'Catch ex As Exception
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.Button_JND]Calculate Mura Defects Error ! (" & ex.Message & ")")
        '    MessageBox.Show("[Dialog_MuraJND.Button_JND]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        ''----------------------------------------------------------------------------------------------
        '' MappingTable Translation  ==> Request_Command = "CALCULATE_MAPTOTABLE" (Dispatcher 2)
        ''----------------------------------------------------------------------------------------------
        'Try
        '    If Me.m_MainProcess.IPBootConfig.Panel_TransferMode.Value = "MAPPINGTABLE" Then
        '        '--- Prepare Command ---
        '        Request_Command = "CALCULATE_MAPTOTABLE"
        '        TimeOut = 300000 '300 secs

        '        Response_OK = False
        '        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
        '        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

        '        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
        '            Response_OK = True
        '        Else
        '            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate MappingTable Translation Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '            MessageBox.Show("[Dialog_MuraJND.Button_JND]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '            Exit Sub
        '        End If
        '    End If

        'Catch ex As Exception
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.Button_JND]Calculate MappingTable Translation Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        '    MessageBox.Show("[Dialog_MuraJND.Button_JND]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        ''----------------------------------------------------------------------------------------------
        '' Merge all Mura Group  ==> Request_Command = "MERGE_MURAGROUP_ALL" (Dispatcher 2)
        ''----------------------------------------------------------------------------------------------
        'Try
        '    '--- Prepare Command ---
        '    Request_Command = "MERGE_MURAGROUP_ALL"
        '    TimeOut = 300000 '300 secs

        '    Response_OK = False
        '    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
        '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

        '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
        '        Response_OK = True
        '    Else
        '        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Merge all Mura Group Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '        MessageBox.Show("[Dialog_MuraJND.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    End If

        'Catch ex As Exception
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.DoStep]Merge all Mura Group Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        '    MessageBox.Show("[Dialog_MuraJND.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        ''----------------------------------------------------------------------------------------------
        '' Get all Mura Group Defects ==> Request_Command = "GET_ALL_MURA_RESULT" (Dispatcher 2)
        ''----------------------------------------------------------------------------------------------
        'Try
        '    '--- Prepare Command ---
        '    Request_Command = "GET_ALL_MURA_RESULT"
        '    TimeOut = 200000 '200 secs

        '    Response_OK = False
        '    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
        '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

        '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
        '        Response_OK = True
        '    Else
        '        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get all Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '        MessageBox.Show("[Dialog_MuraJND.DoStep]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    End If

        '    If Response_OK Then
        '        '--- 解新 Defect ----
        '        OutputString = SubSystemResult.Responses(0).Param2
        '        Me.m_MainProcess.AddMuraString(OutputString)
        '    End If
        'Catch ex As Exception
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Merge allGet all Mura Group Defects Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        '    MessageBox.Show("[Dialog_MuraJND.DoStep]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        Me.m_Form.ShowMuraResult()
    End Sub
#End Region

#Region "--- Button_FilterFalse ---"
    Private Sub Button_FilterFalse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim c As Integer
        Dim Parameter_Lists As String = ""

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.m_MuraProcess.MuraModelRecipe.AutoAddFalse.Value = Me.CheckBox_AutoAddFalse.Checked
        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraJND Setting   ==> Request_Command = "DIALOG_MURAJND_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURAJND_SETTING"
            TimeOut = 100000 '100 secs
            Parameter_Lists = "AutoAddFalse," & Me.CheckBox_AutoAddFalse.Checked

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraJND Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraJND.Button_FilterFalse]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.Button_FilterFalse]Dialog_MuraJND Setting Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraJND.Button_FilterFalse]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Filter Mura False Defects ==> Request_Command = "CALCULATE_MURA_FILTERFALSE" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_MURA_FILTERFALSE"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Filter Mura False Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraJND.Button_FilterFalse]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.Button_FilterFalse]Filter Mura False Defects Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraJND.Button_FilterFalse]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- False Defect Count ---
        c = SubSystemResult.Responses(0).Param2

        If c > 0 Then
            MsgBox("產生" & c & "個False Defect", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_Form.ShowFalse()
        Else
            Me.m_Form.FalseUpdate()
        End If
        Me.m_Form.ResultUpdate()
    End Sub
#End Region

#Region "--- Button_Ok ---"
    Private Sub Button_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Ok.Click
        Dim str As String
        Dim dir As String = ""
        Dim dirPath As String
        Dim Parameter_Lists As String = ""
        Dim PatternName As String
        Dim PatternIndex As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            '[AreaGrabber]
            PatternIndex = Me.GetPatternIndexInfo
            Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '從[1]開始

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.m_Form.ComboBox_Pattern_MainFrm.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraJND.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- White ---
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMin.Value = Me.NUD_WhiteBlobMura_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMax.Value = Me.NUD_WhiteBlobMura_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMin.Value = Me.NUD_WhiteBlobMura_JNDMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMax.Value = Me.NUD_WhiteBlobMura_JNDMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMin.Value = Me.NUD_WhiteBlobMura_ElongationMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMax.Value = Me.NUD_WhiteBlobMura_ElongationMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMin.Value = Me.NUD_WhiteAGM_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMax.Value = Me.NUD_WhiteAGM_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMin.Value = Me.NUD_WhiteAGM_JNDMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMax.Value = Me.NUD_WhiteAGM_JNDMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMin.Value = Me.NUD_WhiteAGM_ElongationMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMax.Value = Me.NUD_WhiteAGM_ElongationMax.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMin.Value = Me.NUD_WhiteMacroMura_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMax.Value = Me.NUD_WhiteMacroMura_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_JND.Value = Me.NUD_WhiteMacroMura_JND.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_WidthMin.Value = Me.NUD_WhiteBandMura_WidthMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_JND.Value = Me.NUD_WhiteBandMura_JND.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_SJND.Value = Me.NUD_WhiteBandMura_SJND.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_AreaMin = Me.NUD_WhiteCPD_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_AreaMax = Me.NUD_WhiteCPD_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteCPD_JND = Me.NUD_WhiteCPD_JND.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_AreaMin = Me.NUD_WhiteGapMura_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_AreaMax = Me.NUD_WhiteGapMura_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.WhiteGapMura_JND = Me.NUD_WhiteGapMura_JND.Value

            '--- Black ---
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMin.Value = Me.NUD_BlackBlobMura_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMax.Value = Me.NUD_BlackBlobMura_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMin.Value = Me.NUD_BlackBlobMura_JNDMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMax.Value = Me.NUD_BlackBlobMura_JNDMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMin.Value = Me.NUD_BlackBlobMura_ElongationMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMax.Value = Me.NUD_BlackBlobMura_ElongationMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMin.Value = Me.NUD_BlackAGM_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMax.Value = Me.NUD_BlackAGM_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMin.Value = Me.NUD_BlackAGM_JNDMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMax.Value = Me.NUD_BlackAGM_JNDMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMin.Value = Me.NUD_BlackAGM_ElongationMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMax.Value = Me.NUD_BlackAGM_ElongationMax.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMin.Value = Me.NUD_BlackMacroMura_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMax.Value = Me.NUD_BlackMacroMura_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_JND.Value = Me.NUD_BlackMacroMura_JND.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_WidthMin.Value = Me.NUD_BlackBandMura_WidthMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_JND.Value = Me.NUD_BlackBandMura_JND.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_SJND.Value = Me.NUD_BlackBandMura_SJND.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_AreaMin = Me.NUD_BlackCPD_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_AreaMax = Me.NUD_BlackCPD_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackCPD_JND = Me.NUD_BlackCPD_JND.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_AreaMin = Me.NUD_BlackGapMura_AreaMin.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_AreaMax = Me.NUD_BlackGapMura_AreaMax.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.CPDRecipe.BlackGapMura_JND = Me.NUD_BlackGapMura_JND.Value

            Me.m_MuraProcess.MuraModelRecipe.AutoAddFalse.Value = Me.CheckBox_AutoAddFalse.Checked

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraJND Setting   ==> Request_Command = "DIALOG_MURAJND_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURAJND_SETTING"
                TimeOut = 100000 '100 secs
                Parameter_Lists = "AutoAddFalse," & Me.CheckBox_AutoAddFalse.Checked & ";" & _
                                  "WhiteBlobMura_AreaMin," & Me.NUD_WhiteBlobMura_AreaMin.Value & ";" & "WhiteBlobMura_AreaMax," & Me.NUD_WhiteBlobMura_AreaMax.Value & ";" & _
                                  "WhiteBlobMura_JNDMin," & Me.NUD_WhiteBlobMura_JNDMin.Value & ";" & "WhiteBlobMura_JNDMax," & Me.NUD_WhiteBlobMura_JNDMax.Value & ";" & "WhiteBlobMura_ElongationMin," & Me.NUD_WhiteBlobMura_ElongationMin.Value & ";" & "WhiteBlobMura_ElongationMax," & Me.NUD_WhiteBlobMura_ElongationMax.Value & ";" & _
                                  "WhiteAGM_AreaMin," & Me.NUD_WhiteAGM_AreaMin.Value & ";" & "WhiteAGM_AreaMax," & Me.NUD_WhiteAGM_AreaMax.Value & ";" & _
                                  "WhiteAGM_JNDMin," & Me.NUD_WhiteAGM_JNDMin.Value & ";" & "WhiteAGM_JNDMax," & Me.NUD_WhiteAGM_JNDMax.Value & ";" & "WhiteAGM_ElongationMin," & Me.NUD_WhiteAGM_ElongationMin.Value & ";" & "WhiteAGM_ElongationMax," & Me.NUD_WhiteAGM_ElongationMax.Value & ";" & _
                                  "WhiteMacroMura_AreaMin," & Me.NUD_WhiteMacroMura_AreaMin.Value & ";" & "WhiteMacroMura_AreaMax," & Me.NUD_WhiteMacroMura_AreaMax.Value & ";" & "WhiteMacroMura_JND," & Me.NUD_WhiteMacroMura_JND.Value & ";" & _
                                  "WhiteBandMura_JND," & Me.NUD_WhiteBandMura_JND.Value & ";" & "WhiteBandMura_SJND," & Me.NUD_WhiteBandMura_SJND.Value & ";" & "WhiteBandMura_WidthMin," & Me.NUD_WhiteBandMura_WidthMin.Value & ";" & _
                                  "BlackBlobMura_AreaMin," & Me.NUD_BlackBlobMura_AreaMin.Value & ";" & "BlackBlobMura_AreaMax," & Me.NUD_BlackBlobMura_AreaMax.Value & ";" & _
                                  "BlackBlobMura_JNDMin," & Me.NUD_BlackBlobMura_JNDMin.Value & ";" & "BlackBlobMura_JNDMax," & Me.NUD_BlackBlobMura_JNDMax.Value & ";" & "BlackBlobMura_ElongationMin," & Me.NUD_BlackBlobMura_ElongationMin.Value & ";" & "BlackBlobMura_ElongationMax," & Me.NUD_BlackBlobMura_ElongationMax.Value & ";" & _
                                  "BlackAGM_AreaMin," & Me.NUD_BlackAGM_AreaMin.Value & ";" & "BlackAGM_AreaMax," & Me.NUD_BlackAGM_AreaMax.Value & ";" & _
                                  "BlackAGM_JNDMin," & Me.NUD_BlackAGM_JNDMin.Value & ";" & "BlackAGM_JNDMax," & Me.NUD_BlackAGM_JNDMax.Value & ";" & "BlackAGM_ElongationMin," & Me.NUD_BlackAGM_ElongationMin.Value & ";" & "BlackAGM_ElongationMax," & Me.NUD_BlackAGM_ElongationMax.Value & ";" & _
                                  "BlackMacroMura_AreaMin," & Me.NUD_BlackMacroMura_AreaMin.Value & ";" & "BlackMacroMura_AreaMax," & Me.NUD_BlackMacroMura_AreaMax.Value & ";" & "BlackMacroMura_JND," & Me.NUD_BlackMacroMura_JND.Value & ";" & _
                                  "BlackBandMura_JND," & Me.NUD_BlackBandMura_JND.Value & ";" & "BlackBandMura_SJND," & Me.NUD_BlackBandMura_SJND.Value & ";" & "BlackBandMura_WidthMin," & Me.NUD_BlackBandMura_WidthMin.Value & ";" & _
                                  "WhiteCPD_AreaMin," & Me.NUD_WhiteCPD_AreaMin.Value & ";" & "WhiteCPD_AreaMax," & Me.NUD_WhiteCPD_AreaMax.Value & ";" & "WhiteCPD_JND," & Me.NUD_WhiteCPD_JND.Value & ";" & _
                                  "BlackCPD_AreaMin," & Me.NUD_BlackCPD_AreaMin.Value & ";" & "BlackCPD_AreaMax," & Me.NUD_BlackCPD_AreaMax.Value & ";" & "BlackCPD_JND," & Me.NUD_BlackCPD_JND.Value & ";" & _
                                  "WhiteGapMura_AreaMin," & Me.NUD_WhiteGapMura_AreaMin.Value & ";" & "WhiteGapMura_AreaMax," & Me.NUD_WhiteGapMura_AreaMax.Value & ";" & "WhiteGapMura_JND," & Me.NUD_WhiteGapMura_JND.Value & ";" & _
                                  "BlackGapMura_AreaMin," & Me.NUD_BlackGapMura_AreaMin.Value & ";" & "BlackGapMura_AreaMax," & Me.NUD_BlackGapMura_AreaMax.Value & ";" & "BlackGapMura_JND," & Me.NUD_BlackGapMura_JND.Value


                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraJND Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraJND.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Save Recipe ---
            dirPath = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraJND.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Mura Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

            '---Enable Button ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraJND.Button_Ok]" & ex.Message)
            MessageBox.Show("[Dialog_MuraJND.Button_Ok]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- BlobMura ---"
    Private Sub NUD_WhiteBlobMura_AreaMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_AreaMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMin.Value = Me.NUD_WhiteBlobMura_AreaMin.Value
    End Sub
    Private Sub NUD_WhiteBlobMura_AreaMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_AreaMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_AreaMax.Value = Me.NUD_WhiteBlobMura_AreaMax.Value
    End Sub
    Private Sub NUD_WhiteBlobMura_JNDMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_JNDMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMin.Value = Me.NUD_WhiteBlobMura_JNDMin.Value
    End Sub
    Private Sub NUD_WhiteBlobMura_JNDMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_JNDMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_JNDMax.Value = Me.NUD_WhiteBlobMura_JNDMax.Value
    End Sub
    Private Sub NUD_WhiteBlobMura_ElongationMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_ElongationMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMin.Value = Me.NUD_WhiteBlobMura_ElongationMin.Value
    End Sub
    Private Sub NUD_WhiteBlobMura_ElongationMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_ElongationMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_ElongationMax.Value = Me.NUD_WhiteBlobMura_ElongationMax.Value
    End Sub

    Private Sub NUD_BlackBlobMura_AreaMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_AreaMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMin.Value = Me.NUD_BlackBlobMura_AreaMin.Value
    End Sub
    Private Sub NUD_BlackBlobMura_AreaMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_AreaMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_AreaMax.Value = Me.NUD_BlackBlobMura_AreaMax.Value
    End Sub
    Private Sub NUD_BlackBlobMura_JNDMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_JNDMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMin.Value = Me.NUD_BlackBlobMura_JNDMin.Value
    End Sub
    Private Sub NUD_BlackBlobMura_JNDMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_JNDMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_JNDMax.Value = Me.NUD_BlackBlobMura_JNDMax.Value
    End Sub
    Private Sub NUD_BlackBlobMura_ElonagtionMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_ElongationMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMin.Value = Me.NUD_BlackBlobMura_ElongationMin.Value
    End Sub
    Private Sub NUD_BlackBlobMura_ElonagtionMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_ElongationMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_ElongationMax.Value = Me.NUD_BlackBlobMura_ElongationMax.Value
    End Sub
#End Region

#Region "--- AGM ---"
    Private Sub NUD_WhiteAGM_AreaMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteAGM_AreaMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMin.Value = Me.NUD_WhiteAGM_AreaMin.Value
    End Sub
    Private Sub NUD_WhiteAGM_AreaMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteAGM_AreaMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_AreaMax.Value = Me.NUD_WhiteAGM_AreaMax.Value
    End Sub
    Private Sub NUD_WhiteAGM_JNDMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteAGM_JNDMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMin.Value = Me.NUD_WhiteAGM_JNDMin.Value
    End Sub
    Private Sub NUD_WhiteAGM_JNDMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteAGM_JNDMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_JNDMax.Value = Me.NUD_WhiteAGM_JNDMax.Value
    End Sub
    Private Sub NUD_WhiteAGM_ElongationMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteAGM_ElongationMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMin.Value = Me.NUD_WhiteAGM_ElongationMin.Value
    End Sub
    Private Sub NUD_WhiteAGM_ElongationMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteAGM_ElongationMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteAGM_ElongationMax.Value = Me.NUD_WhiteAGM_ElongationMax.Value
    End Sub

    Private Sub NUD_BlackAGM_AreaMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackAGM_AreaMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMin.Value = Me.NUD_BlackAGM_AreaMin.Value
    End Sub
    Private Sub NUD_BlackAGM_AreaMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackAGM_AreaMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_AreaMax.Value = Me.NUD_BlackAGM_AreaMax.Value
    End Sub
    Private Sub NUD_BlackAGM_JNDMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackAGM_JNDMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMin.Value = Me.NUD_BlackAGM_JNDMin.Value
    End Sub
    Private Sub NUD_BlackAGM_JNDMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackAGM_JNDMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_JNDMax.Value = Me.NUD_BlackAGM_JNDMax.Value
    End Sub
    Private Sub NUD_BlackAGM_ElongationMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackAGM_ElongationMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMin.Value = Me.NUD_BlackAGM_ElongationMin.Value
    End Sub
    Private Sub NUD_BlackAGM_ElongationMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackAGM_ElongationMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackAGM_ElongationMax.Value = Me.NUD_BlackAGM_ElongationMax.Value
    End Sub
#End Region

#Region "--- MacroMura ---"
    Private Sub NUD_WhiteMacro_AreaMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteMacroMura_AreaMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMin.Value = Me.NUD_WhiteMacroMura_AreaMin.Value
    End Sub
    Private Sub NUD_WhiteMacro_AreaMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteMacroMura_AreaMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_AreaMax.Value = Me.NUD_WhiteMacroMura_AreaMax.Value
    End Sub
    Private Sub NUD_WhiteMacroMura_JND_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteMacroMura_JND.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_JND.Value = Me.NUD_WhiteMacroMura_JND.Value
    End Sub

    Private Sub NUD_BlackMacro_AreaMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackMacroMura_AreaMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMin.Value = Me.NUD_BlackMacroMura_AreaMin.Value
    End Sub
    Private Sub NUD_BlackMacro_AreaMax_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackMacroMura_AreaMax.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_AreaMax.Value = Me.NUD_BlackMacroMura_AreaMax.Value
    End Sub
    Private Sub NUD_BlackMacroMura_JND_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackMacroMura_JND.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_JND.Value = Me.NUD_BlackMacroMura_JND.Value
    End Sub
#End Region

#Region "--- BandMura ---"
    Private Sub NUD_WhiteBandMura_WidthMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBandMura_WidthMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_WidthMin.Value = Me.NUD_WhiteBandMura_WidthMin.Value
    End Sub
    Private Sub NUD_WhiteBandMura_JND_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBandMura_JND.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_JND.Value = Me.NUD_WhiteBandMura_JND.Value
    End Sub
    Private Sub NUD_WhiteBandMura_SJND_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBandMura_SJND.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBandMura_SJND.Value = Me.NUD_WhiteBandMura_SJND.Value
    End Sub

    Private Sub NUD_BlackBandMura_WidthMin_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBandMura_WidthMin.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_WidthMin.Value = Me.NUD_BlackBandMura_WidthMin.Value
    End Sub
    Private Sub NUD_BlackBandMura_JND_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBandMura_JND.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_JND.Value = Me.NUD_BlackBandMura_JND.Value
    End Sub
    Private Sub NUD_BlackBandMura_SJND_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBandMura_SJND.ValueChanged
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBandMura_SJND.Value = Me.NUD_BlackBandMura_SJND.Value
    End Sub
#End Region


#End Region

#Region "--- ComboBox Event ---"
    Private Sub ComboBox_Select_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Select.SelectedIndexChanged
        Select Case Me.ComboBox_Select.SelectedIndex
            Case 0
                Me.m_Form.CurrentIndex1 = 0
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 0
            Case 1
                Me.m_Form.CurrentIndex1 = 19
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 19
        End Select
        Me.m_Form.ImageUpdate()
    End Sub

    Private Sub ComboBox_PatternList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_PatternList.SelectedIndexChanged
        Dim PatternName As String

        '--- Button Control ---   
        Button_Enable(False)

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            '--- Button Control ---   
            Button_Enable(True)
            Exit Sub
        End If

        Try
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_PatternList.SelectedIndex

            Me.UpdateData()
            Me.UpdateUserLevel()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.ComboBox_PatternList_SelectedIndexChanged]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraJND.ComboBox_PatternList_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_PatternList.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Button_Enable(True)
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraJND.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraJND.ComboBox_PatternList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraJND.ComboBox_PatternList_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

#End Region

End Class