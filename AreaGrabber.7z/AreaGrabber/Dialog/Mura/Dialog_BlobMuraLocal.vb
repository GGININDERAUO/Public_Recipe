Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.IO
Imports System.Threading
Imports System.Globalization

Public Class Dialog_BlobMuraLocal

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush

    Private m_BlobSmoothIndex As Integer    'Blob ���ƳB�z�v�� Index
    Private m_MacroSmoothIndex As Integer   'Macro ���ƳB�z�v�� Index
    Private m_BlobResizeHIndex As Integer   'Blob �Y��v��(H) Index
    Private m_BlobResizeLIndex As Integer   'Blob �Y��v��(L) Index
    Private m_MacroResizeHIndex As Integer  'Macro �Y��v��(H) Index
    Private m_MacroResizeLIndex As Integer  'Macro �Y��v��(H) Index
    Private m_BlobWhiteIndex As Integer     'Blob �۴�v��(�G) Index
    Private m_BlobBlackIndex As Integer     'Blob �۴�v��(�t) Index
    Private m_MacroWhiteIndex As Integer    'Macro �۴�v��(�G) Index
    Private m_MacroBlackIndex As Integer    'Macro �۴�v��(�t) Index
    Private m_BlobRecWhiteIndex As Integer  'Blob �v���B�z(�G-Reconstruct) Index
    Private m_BlobRecBlackIndex As Integer  'Blob �v���B�z(�t-Reconstruct) Index
    Private m_MacroThresholdWhiteIndex As Integer   'Macro �v���B�z(�G-Threshold) Index
    Private m_MacroThresholdBlackIndex As Integer   'Macro �v���B�z(�t-Threshold) Index
    Private m_CurrentMuraIndex As Integer   '�O���ثe��ܼv���� Index   '2009/06/12 Rick add

    Private m_AreaLeft As Boolean
    Private m_AreaRight As Boolean
    Private m_AreaTop As Boolean
    Private m_AreaBottom As Boolean
    Private RoundExpandWidth As Integer

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL
        Dim image1 As MIL_ID
        Dim image2 As MIL_ID
        Dim image3 As MIL_ID
        Dim image4 As MIL_ID
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_BlobMuraLocal", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess
        Me.m_FuncProcess = Me.m_MainProcess.FuncProcess

        Try

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_AxMDisplay = Me.m_Form.AxMDisplay
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)
            RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

            Me.m_BlobSmoothIndex = -2
            Me.m_MacroSmoothIndex = -2
            Me.m_BlobResizeHIndex = -2
            Me.m_BlobResizeLIndex = -2
            Me.m_MacroResizeHIndex = -2
            Me.m_MacroResizeLIndex = -2
            Me.m_BlobWhiteIndex = -2
            Me.m_BlobBlackIndex = -2
            Me.m_MacroWhiteIndex = -2
            Me.m_MacroBlackIndex = -2
            Me.m_BlobRecWhiteIndex = -2
            Me.m_BlobRecBlackIndex = -2
            Me.m_MacroThresholdWhiteIndex = -2
            Me.m_MacroThresholdBlackIndex = -2

            image = Me.m_MuraProcess.Img_BlobMura_SmoothChild
            If image <> M_NULL Then
                Me.m_BlobSmoothIndex = Me.ComboBox_Select.Items.Add("Blob ���ƳB�z�v��")
            Else
                Me.m_Form.ComboBox_Type.SelectedIndex = -1
                MessageBox.Show("[Mura�v�����~] �S��Blob ���Ƽv�� ! ", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_CalculateBlob.Enabled = False
            End If
            image = Me.m_MuraProcess.Img_MacroMura_SmoothChild
            If image <> M_NULL Then
                Me.m_MacroSmoothIndex = Me.ComboBox_Select.Items.Add("Macro ���ƳB�z�v��")
            Else
                Me.m_Form.ComboBox_Type.SelectedIndex = -1
                MessageBox.Show("[Mura�v�����~] �S��Macro ���Ƽv�� ! ", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_CalculateBlob.Enabled = False
            End If

            If Me.m_BlobSmoothIndex <> -2 Then
                Me.ComboBox_Select.SelectedIndex = Me.m_BlobSmoothIndex
            Else
                Me.m_Form.ComboBox_Type.SelectedIndex = -1
            End If

            If Me.m_BlobSmoothIndex <> -2 And Me.m_MacroSmoothIndex <> -2 Then

                image1 = Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage
                image2 = Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage
                image3 = Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage
                image4 = Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage

                If image1 <> M_NULL And image2 <> M_NULL And image3 <> M_NULL And image4 <> M_NULL Then
                    Me.m_BlobResizeHIndex = Me.ComboBox_Select.Items.Add("Blob �Y��v��(H)")
                    Me.m_BlobResizeLIndex = Me.ComboBox_Select.Items.Add("Blob �Y��v��(L)")
                    Me.m_MacroResizeHIndex = Me.ComboBox_Select.Items.Add("Macro �Y��v��(H)")
                    Me.m_MacroResizeLIndex = Me.ComboBox_Select.Items.Add("Macro �Y��v��(L)")
                End If

                image1 = Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage
                image2 = Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage
                image3 = Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage
                image4 = Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage

                If image1 <> M_NULL And image2 <> M_NULL And image3 <> M_NULL And image4 <> M_NULL Then
                    Me.m_BlobWhiteIndex = Me.ComboBox_Select.Items.Add("Blob �۴�v��(�G)")
                    Me.m_BlobBlackIndex = Me.ComboBox_Select.Items.Add("Blob �۴�v��(�t)")
                    Me.m_MacroWhiteIndex = Me.ComboBox_Select.Items.Add("Macro �۴�v��(�G)")
                    Me.m_MacroBlackIndex = Me.ComboBox_Select.Items.Add("Macro �۴�v��(�t)")

                    image1 = Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage
                    image2 = Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage
                    image3 = Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage
                    image4 = Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage
                    If image1 <> M_NULL And image2 <> M_NULL And image3 <> M_NULL And image4 <> M_NULL Then
                        Me.m_BlobRecWhiteIndex = Me.ComboBox_Select.Items.Add("Blob �v���B�z(�G-Reconstruct)")
                        Me.m_BlobRecBlackIndex = Me.ComboBox_Select.Items.Add("Blob �v���B�z(�t-Reconstruct)")
                        Me.m_MacroThresholdWhiteIndex = Me.ComboBox_Select.Items.Add("Macro �v���B�z(�G-Threshold)")
                        Me.m_MacroThresholdBlackIndex = Me.ComboBox_Select.Items.Add("Macro �v���B�z(�t-Threshold)")
                    End If
                End If
            End If

            Me.m_CurrentMuraIndex = Me.m_BlobRecWhiteIndex
            Me.m_Form.ImageZoomAll()

            '--- Initial Button --- 
            Me.Button_Save.Enabled = False
            Me.Button_Cancel.Enabled = False
            Me.BtnPre_BlobMuraLocal.Enabled = True

            '--- UI ---
            Me.m_VScrollBar = Me.m_Form.VScrollBar
            Me.m_HScrollBar = Me.m_Form.HScrollBar

            Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
            Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
            Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
            Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll

            If (m_FuncProcess.FuncModelRecipe.AlignType.Value = AlignType.Circle) Then
                Me.NumericUpDown_AreaBottom.Enabled = False
                Me.NumericUpDown_AreaLeft.Enabled = False
                Me.NumericUpDown_AreaRight.Enabled = False
            End If

            '--- UI ---

            Me.UpdateData()
            '--- �v������ ---
            Me.UpdateUserLevel()

        Catch ex As Exception
            Throw New Exception("[Dialog_BlobMuraLocal.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub

#Region "--- Dialog Event ---"

    Private Sub Dialog_BlobMuralLocal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Me.GroupBox_Modify.Enabled = False
        Me.GroupBox_Parameter.Enabled = False

        Me.RadioButton_Finish.Checked = True
        Me.m_AreaLeft = False
        Me.m_AreaRight = False
        Me.m_AreaTop = False
        Me.m_AreaBottom = False

        '--- Initial Button ---  
        Me.Button_Save.Enabled = True
        Me.Button_Cancel.Enabled = True
        Me.BtnPre_BlobMuraLocal.Enabled = True
        Me.Button_CalculateBlob.Enabled = Me.CheckBox_Center.Checked
        Me.GroupBox_Modify.Enabled = Me.CheckBox_Center.Checked
        Me.GroupBox_Parameter.Enabled = Me.CheckBox_Center.Checked

        Me.Update()

    End Sub

    Private Sub Dialog_BlobMuralLocal_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub

#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_Modify.Enabled = False
                Me.GroupBox_Parameter.Enabled = False
            Case 1 'PM
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = False
            Case 2 'ENG
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
            Case 3 'ALL
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim boundary As ClsParameterBoundary
        Dim GrayLevel_Maximum As Double

        Try
            GrayLevel_Maximum = 2 ^ Me.m_MainProcess.IPBootConfig.Digitizer_Datadepth.Value - 1
            boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound

            Me.NumericUpDown_AreaTop.Minimum = 0
            Me.NumericUpDown_AreaBottom.Minimum = 0
            Me.NumericUpDown_AreaLeft.Minimum = 0
            Me.NumericUpDown_AreaRight.Minimum = 0

            Me.NumericUpDown_AreaTop.Maximum = RoundExpandWidth
            Me.NumericUpDown_AreaBottom.Maximum = RoundExpandWidth
            Me.NumericUpDown_AreaLeft.Maximum = RoundExpandWidth
            Me.NumericUpDown_AreaRight.Maximum = RoundExpandWidth

            Me.CheckBox_Center.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseCenter.Value

            If Me.NumericUpDown_AreaTop.Maximum < boundary.TopY Then
                boundary.TopY = RoundExpandWidth - 1
                Me.NumericUpDown_AreaTop.Value = RoundExpandWidth - 1
            Else
                Me.NumericUpDown_AreaTop.Value = boundary.TopY
            End If
            If Me.NumericUpDown_AreaBottom.Maximum < boundary.BottomY Then
                boundary.BottomY = RoundExpandWidth - 1
                Me.NumericUpDown_AreaBottom.Value = RoundExpandWidth - 1
            Else
                Me.NumericUpDown_AreaBottom.Value = boundary.BottomY
            End If
            If Me.NumericUpDown_AreaLeft.Maximum < boundary.LeftX Then
                boundary.LeftX = RoundExpandWidth - 1
                Me.NumericUpDown_AreaLeft.Value = RoundExpandWidth - 1
            Else
                Me.NumericUpDown_AreaLeft.Value = boundary.LeftX
            End If
            If Me.NumericUpDown_AreaRight.Maximum < boundary.RightX Then
                boundary.RightX = RoundExpandWidth - 1
                Me.NumericUpDown_AreaRight.Value = RoundExpandWidth - 1
            Else
                Me.NumericUpDown_AreaRight.Value = boundary.RightX
            End If

            Me.NUD_WhiteBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
            Me.NUD_WhiteBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
            Me.NUD_BlackBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
            Me.NUD_BlackBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
            Me.NUD_WhiteMacroMura_Threshold.Maximum = GrayLevel_Maximum
            Me.NUD_BlackMacroMura_Threshold.Maximum = GrayLevel_Maximum

            Me.NUD_WhiteBlobMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value
            If (Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value >= Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value) Then
                Me.NUD_WhiteBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value - 1
            Else
                Me.NUD_WhiteBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value
            End If
            Me.NUD_WhiteMacroMura_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_Threshold.Value

            Me.NUD_BlackBlobMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value
            If (Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value >= Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value) Then
                Me.NUD_BlackBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value - 1
            Else
                Me.NUD_BlackBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value
            End If

            Me.NUD_BlackMacroMura_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_Threshold.Value

            Me.CheckBox_UseReconstructBW.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseReconstructBW.Value
        Catch ex As Exception
            Throw New Exception("[Dialog_BlobMuraLocal.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- ReDraw ---"
    Private Sub ReDraw()
        Dim image As MIL_ID = M_NULL
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.CheckBox_Show.Checked And Me.ComboBox_Select.SelectedIndex >= 0 And image <> M_NULL Then

            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            v = (Me.NumericUpDown_AreaLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeX - Me.NumericUpDown_AreaRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_AreaTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = SizeY - Me.NumericUpDown_AreaBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = False
    End Sub
#End Region

#Region "--- UpdateSelectdImage ---"
    Private Sub UpdateSelectdImage()
        Dim Image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Try
            Select Case Me.ComboBox_Select.SelectedIndex
                Case Me.m_BlobSmoothIndex   'Blob ���ƳB�z�v��
                    Image = Me.m_MuraProcess.Img_BlobMura_SmoothChild
                Case Me.m_MacroSmoothIndex   'Macro ���ƳB�z�v��
                    Image = Me.m_MuraProcess.Img_MacroMura_SmoothChild
                Case Me.m_BlobResizeHIndex  'Blob �Y��v��(H)
                    Image = Me.m_MuraProcess.Img_BlobMura_ResizeHChild
                Case Me.m_BlobResizeLIndex  'Blob �Y��v��(L)
                    Image = Me.m_MuraProcess.Img_BlobMura_ResizeLChild
                Case Me.m_MacroResizeHIndex  'Macro �Y��v��(H)
                    Image = Me.m_MuraProcess.Img_MacroMura_ResizeHChild
                Case Me.m_MacroResizeLIndex  'Macro �Y��v��(L)
                    Image = Me.m_MuraProcess.Img_MacroMura_ResizeLChild
                Case Me.m_BlobWhiteIndex  'Blob �۴�v��(�G)
                    Image = Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild
                Case Me.m_BlobBlackIndex  'Blob �۴�v��(�t)
                    Image = Me.m_MuraProcess.Img_BlobMuraArea_BlackChild
                Case Me.m_MacroWhiteIndex  'Macro �۴�v��(�G)
                    Image = Me.m_MuraProcess.Img_MacroMura_WhiteChild
                Case Me.m_MacroBlackIndex  'Macro �۴�v��(�t)
                    Image = Me.m_MuraProcess.Img_MacroMura_BlackChild
                Case Me.m_BlobRecWhiteIndex  'Blob �v���B�z(�G-Reconstruct)
                    Image = Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage
                Case Me.m_BlobRecBlackIndex  'Blob �v���B�z(�t-Reconstruct)
                    Image = Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage
                Case Me.m_MacroThresholdWhiteIndex  'Macro �v���B�z(�G-Threshold)
                    Image = Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage
                Case Me.m_MacroThresholdBlackIndex  'Macro �v���B�z(�t-Threshold)
                    Image = Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage
            End Select

            If Image <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                Type = MbufInquire(Image, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(Image, imageBuffer)

                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                MbufControl(Image, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                Me.m_Form.ResetScrollBar()
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraLocal.UpdateSelectdImage] Update Selected Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMurat.BlobMuraLocal]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try
    End Sub
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_CalculateBlob.Enabled = En
        Me.Button_Save.Enabled = En
        Me.Button_Cancel.Enabled = En
        Me.BtnPre_BlobMuraLocal.Enabled = En
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_CalculateBlob.Text = res.GetString("Button_CalculateBlob.Text")
                Button_Cancel.Text = res.GetString("Button_Cancel.Text")
                Button_Save.Text = res.GetString("Button_Save.Text")
                CheckBox_Show.Text = res.GetString("CheckBox_Show.Text")
                GroupBox_Area.Text = res.GetString("GroupBox_Area.Text")
                GroupBox_Modify.Text = res.GetString("GroupBox_Modify.Text")
                GroupBox_Parameter.Text = res.GetString("GroupBox_Parameter.Text")
                Label_AreaBottom.Text = res.GetString("Label_AreaBottom.Text")
                Label_AreaLeft.Text = res.GetString("Label_AreaLeft.Text")
                Label_AreaRight.Text = res.GetString("Label_AreaRight.Text")
                Label_AreaTop.Text = res.GetString("Label_AreaTop.Text")
                Label_Select.Text = res.GetString("Label_Select.Text")
                RadioButton_Finish.Text = res.GetString("RadioButton_Finish.Text")
                RadioButton_Manual.Text = res.GetString("RadioButton_Manual.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_Show_CheckedChanged ---"
    Private Sub CheckBox_Show_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show.CheckedChanged
        Me.ReDraw()
    End Sub
#End Region

#Region "--- CheckBox_Center_CheckedChanged ---"
    Private Sub CheckBox_Center_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_Center.CheckedChanged
        Me.GroupBox_Modify.Enabled = Me.CheckBox_Center.Checked
        Me.GroupBox_Parameter.Enabled = Me.CheckBox_Center.Checked
        Me.Button_CalculateBlob.Enabled = Me.CheckBox_Center.Checked
    End Sub
#End Region

#End Region

#Region "--- RadioButton Event ---"
    Private Sub RadioButton_Finish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Finish.CheckedChanged
        Dim boundaryRound As ClsParameterBoundary
        Dim minSize As Integer

        If Me.RadioButton_Finish.Checked Then
            Me.ComboBox_Select.Enabled = True
            Me.GroupBox_Area.Enabled = False
            Me.Button_Save.Enabled = True
            If Me.m_BlobSmoothIndex <> -2 And Me.m_Form.ComboBox_Type.SelectedIndex <> -1 Then
                If Me.ComboBox_Select.Items.Count >= 4 Then
                    Me.GroupBox_Parameter.Enabled = True
                End If
            End If

            boundaryRound = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound

            minSize = 0
            If Me.NumericUpDown_AreaTop.Value < minSize Then Me.NumericUpDown_AreaTop.Value = minSize
            If Me.NumericUpDown_AreaBottom.Value < minSize Then Me.NumericUpDown_AreaBottom.Value = minSize
            If Me.NumericUpDown_AreaLeft.Value < minSize Then Me.NumericUpDown_AreaLeft.Value = minSize
            If Me.NumericUpDown_AreaRight.Value < minSize Then Me.NumericUpDown_AreaRight.Value = minSize

            boundaryRound.TopY = Me.NumericUpDown_AreaTop.Value
            boundaryRound.BottomY = Me.NumericUpDown_AreaBottom.Value
            boundaryRound.LeftX = Me.NumericUpDown_AreaLeft.Value
            boundaryRound.RightX = Me.NumericUpDown_AreaRight.Value

            Me.UpdateUserLevel()
        End If
    End Sub
    Private Sub RadioButton_Manual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Manual.CheckedChanged
        If Me.RadioButton_Manual.Checked Then
            Me.Button_Save.Enabled = False
            Me.ComboBox_Select.Enabled = False
            Me.GroupBox_Parameter.Enabled = False
            Me.GroupBox_Area.Enabled = True
        End If
    End Sub
#End Region

#Region "--- NumericUpDown Event ---"
    Private Sub NumericUpDown_AreaTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaTop.ValueChanged
        Dim image As MIL_ID = M_NULL
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.NumericUpDown_AreaTop.Value >= RoundExpandWidth Then Me.NumericUpDown_AreaTop.Value = RoundExpandWidth
    End Sub
    Private Sub NumericUpDown_AreaBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaBottom.ValueChanged
        Dim image As MIL_ID = M_NULL
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.NumericUpDown_AreaBottom.Value >= RoundExpandWidth Then Me.NumericUpDown_AreaBottom.Value = RoundExpandWidth
    End Sub
    Private Sub NumericUpDown_AreaLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaLeft.ValueChanged
        Dim image As MIL_ID = M_NULL
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.NumericUpDown_AreaLeft.Value >= RoundExpandWidth Then Me.NumericUpDown_AreaLeft.Value = RoundExpandWidth
    End Sub
    Private Sub NumericUpDown_AreaRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_AreaRight.ValueChanged
        Dim image As MIL_ID = M_NULL
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.NumericUpDown_AreaRight.Value >= RoundExpandWidth Then Me.NumericUpDown_AreaRight.Value = RoundExpandWidth
    End Sub

    Private Sub NumericUpDown_WhiteMura_ReconstructHeight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_ReconstructHeight.ValueChanged
        Me.NUD_WhiteBlobMura_ReconstructLow.Maximum = Me.NUD_WhiteBlobMura_ReconstructHeight.Value - 1
    End Sub
    Private Sub NumericUpDown_BlackMura_ReconstructHeight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_ReconstructHeight.ValueChanged
        Me.NUD_BlackBlobMura_ReconstructLow.Maximum = Me.NUD_BlackBlobMura_ReconstructHeight.Value - 1
    End Sub
    Private Sub NUD_WhiteBlobMura_ReconstructLow_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_WhiteBlobMura_ReconstructLow.ValueChanged
        Me.NUD_WhiteBlobMura_ReconstructHeight.Minimum = Me.NUD_WhiteBlobMura_ReconstructLow.Value + 1
    End Sub
    Private Sub NUD_BlackBlobMura_ReconstructLow_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BlackBlobMura_ReconstructLow.ValueChanged
        Me.NUD_BlackBlobMura_ReconstructHeight.Minimum = Me.NUD_BlackBlobMura_ReconstructLow.Value + 1
    End Sub
#End Region

#Region "--- AxMDisplay Operation ---"
    Private Sub m_Panel_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            If Me.NumericUpDown_AreaTop.Value <= RoundExpandWidth And Me.NumericUpDown_AreaBottom.Value <= RoundExpandWidth And Me.NumericUpDown_AreaLeft.Value <= RoundExpandWidth And Me.NumericUpDown_AreaRight.Value <= RoundExpandWidth Then
                Me.ReDraw()
            End If
        End If
    End Sub
    Private Sub m_Panel_AxMDisplay_MouseDownEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If e.Button = Windows.Forms.MouseButtons.Left And image <> M_NULL Then

            '--- Initial ---
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)


            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
            '--- Initial ---

            If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked Then
                p = (Me.NumericUpDown_AreaLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
                dis1 = Math.Abs(e.X - p)
                p = SizeX - Me.NumericUpDown_AreaRight.Value
                p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                dis2 = Math.Abs(e.X - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomX * 0.5 + 3 Then
                        Me.m_AreaLeft = True
                    End If
                Else
                    If dis2 < ZoomX * 0.5 + 3 Then
                        Me.m_AreaRight = True
                    End If
                End If

                p = (Me.NumericUpDown_AreaTop.Value - Me.m_Form.VScrollBar.Value - 0.5) * ZoomY
                dis1 = Math.Abs(e.Y - p)
                p = SizeY - Me.NumericUpDown_AreaBottom.Value
                p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                dis2 = Math.Abs(e.Y - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomY * 0.5 + 3 Then
                        Me.m_AreaTop = True
                    End If
                Else
                    If dis2 < ZoomY * 0.5 + 3 Then
                        Me.m_AreaBottom = True
                    End If
                End If

            End If
        End If
    End Sub
    Private Sub m_AxMDisplay_MouseUpEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_AreaLeft = False
            Me.m_AreaRight = False
            Me.m_AreaTop = False
            Me.m_AreaBottom = False
        End If
    End Sub
    Private Sub m_AxMDisplay_MouseMoveEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked And image <> M_NULL Then
            If Me.m_AreaLeft And (Me.m_Form.MouseX + 1) < RoundExpandWidth Then
                Me.NumericUpDown_AreaLeft.Value = Me.m_Form.MouseX + 1
            End If
            If Me.m_AreaRight And (MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX) < RoundExpandWidth Then
                Me.NumericUpDown_AreaRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
            End If
            If Me.m_AreaTop And (Me.m_Form.MouseY) < RoundExpandWidth Then
                Me.NumericUpDown_AreaTop.Value = Me.m_Form.MouseY + 1
            End If
            If Me.m_AreaBottom And (MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY) < RoundExpandWidth Then
                Me.NumericUpDown_AreaBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
            End If

            If Me.m_AreaLeft Or Me.m_AreaRight Or Me.m_AreaTop Or Me.m_AreaBottom Then
                Me.Refresh()
            End If
        End If
    End Sub
#End Region

#Region "--- ComboBox Event ---"
    Private Sub ComboBox_Select_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Select.SelectedIndexChanged
        Select Case Me.ComboBox_Select.SelectedIndex
            Case Me.m_BlobSmoothIndex   'Blob ���ƳB�z�v��
                Me.m_Form.CurrentIndex1 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
                Me.m_CurrentMuraIndex = Me.m_BlobSmoothIndex
            Case Me.m_MacroSmoothIndex   'Macro ���ƳB�z�v��
                Me.m_Form.CurrentIndex1 = 3
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 3
                Me.m_CurrentMuraIndex = Me.m_MacroSmoothIndex
            Case Me.m_BlobResizeHIndex  'Blob �Y��v��(H)
                Me.m_Form.CurrentIndex1 = 4
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 4
                Me.m_CurrentMuraIndex = Me.m_BlobResizeHIndex
            Case Me.m_BlobResizeLIndex  'Blob �Y��v��(L)
                Me.m_Form.CurrentIndex1 = 5
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 5
                Me.m_CurrentMuraIndex = Me.m_BlobResizeLIndex
            Case Me.m_MacroResizeHIndex  'Macro �Y��v��(H)
                Me.m_Form.CurrentIndex1 = 6
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 6
                Me.m_CurrentMuraIndex = Me.m_MacroResizeHIndex
            Case Me.m_MacroResizeLIndex  'Macro �Y��v��(L)
                Me.m_Form.CurrentIndex1 = 7
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 7
                Me.m_CurrentMuraIndex = Me.m_MacroResizeLIndex
            Case Me.m_BlobWhiteIndex  'Blob �۴�v��(�G)
                Me.m_Form.CurrentIndex1 = 8
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 8
                Me.m_CurrentMuraIndex = Me.m_BlobWhiteIndex
            Case Me.m_BlobBlackIndex  'Blob �۴�v��(�t)
                Me.m_Form.CurrentIndex1 = 9
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 9
                Me.m_CurrentMuraIndex = Me.m_BlobBlackIndex
            Case Me.m_MacroWhiteIndex  'Macro �۴�v��(�G)
                Me.m_Form.CurrentIndex1 = 10
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 10
                Me.m_CurrentMuraIndex = Me.m_MacroWhiteIndex
            Case Me.m_MacroBlackIndex  'Macro �۴�v��(�t)
                Me.m_Form.CurrentIndex1 = 11
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 11
                Me.m_CurrentMuraIndex = Me.m_MacroBlackIndex
            Case Me.m_BlobRecWhiteIndex  'Blob �v���B�z(�G-Reconstruct)
                Me.m_Form.CurrentIndex1 = 12
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 12
                Me.m_CurrentMuraIndex = Me.m_BlobRecWhiteIndex
            Case Me.m_BlobRecBlackIndex  'Blob �v���B�z(�t-Reconstruct)
                Me.m_Form.CurrentIndex1 = 13
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 13
                Me.m_CurrentMuraIndex = Me.m_BlobRecBlackIndex
            Case Me.m_MacroThresholdWhiteIndex  'Macro �v���B�z(�G-Threshold)
                Me.m_Form.CurrentIndex1 = 14
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 14
                Me.m_CurrentMuraIndex = Me.m_MacroThresholdWhiteIndex
            Case Me.m_MacroThresholdBlackIndex  'Macro �v���B�z(�t-Threshold)
                Me.m_Form.CurrentIndex1 = 15
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 15
                Me.m_CurrentMuraIndex = Me.m_MacroThresholdBlackIndex

        End Select

        Me.GroupBox_Modify.Enabled = True
        If CheckBox_Show.Checked Then Me.ReDraw()
    End Sub
#End Region

#Region "--- Button Event ---"

#Region "--- Button_CalculateBlob ---"
    Private Sub Button_CalculateBlob_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_CalculateBlob.Click
        Dim RefX As Integer
        Dim RefY As Integer
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim RoundExpandWidth As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value = Me.NUD_WhiteBlobMura_ReconstructHeight.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value = Me.NUD_WhiteBlobMura_ReconstructLow.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_Threshold.Value = Me.NUD_WhiteMacroMura_Threshold.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value = Me.NUD_BlackBlobMura_ReconstructHeight.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value = Me.NUD_BlackBlobMura_ReconstructLow.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_Threshold.Value = Me.NUD_BlackMacroMura_Threshold.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.UseReconstructBW.Value = Me.CheckBox_UseReconstructBW.Checked
            '--- Disable Button ---  
            Button_Save.Enabled = False
            Button_Cancel.Enabled = False

            '----------------------------------------------------------------------------------------------
            ' Dialog_BlobMuraLocal Setting   ==> Request_Command = "DIALOG_BLOBMURALOCAL_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_BLOBMURALOCAL_SETTING"
                TimeOut = 100000 '100 secs
                Parameter_Lists = "AreaTop," & Me.NumericUpDown_AreaTop.Value & ";" & "AreaBottom," & Me.NumericUpDown_AreaBottom.Value & ";" & "AreaLeft," & Me.NumericUpDown_AreaLeft.Value & ";" & "AreaRight," & Me.NumericUpDown_AreaRight.Value & ";" & _
                                  "WhiteBlobMura_ReconstructHeight," & Me.NUD_WhiteBlobMura_ReconstructHeight.Value & ";" & "WhiteBlobMura_ReconstructLow," & Me.NUD_WhiteBlobMura_ReconstructLow.Value & ";" & "WhiteMacroMura_Threshold," & Me.NUD_WhiteMacroMura_Threshold.Value & ";" & _
                                  "BlackBlobMura_ReconstructHeight," & Me.NUD_BlackBlobMura_ReconstructHeight.Value & ";" & "BlackBlobMura_ReconstructLow," & Me.NUD_BlackBlobMura_ReconstructLow.Value & ";" & "BlackMacroMura_Threshold," & Me.NUD_BlackMacroMura_Threshold.Value & ";" & _
                                  "UseReconstructBW," & Me.CheckBox_UseReconstructBW.Checked & ";"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraLocal Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '---------------------------------------------------------------------------------------------------------------------------------
            '--- ���oGolden�v�� ---
            '----------------------------------------------------------------------------------------------
            ' Calculate Area Golden Sample Image  ==> Request_Command = "CALCULATE_AREA_GOLDENSAMPLE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_AREA_GOLDENSAMPLE"
                TimeOut = 200000 '200 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Area Golden Sample Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then

                    RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

                    'Blob Mura ---
                    '[1] Update Processed Image (Img_16U_BlobMura_ResizeH_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                   
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_BlobMura_ResizeHChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild)
                            Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 2
                        Me.UpdateSelectdImage()

                    End If

                    '[3] Update Processed Image (Img_16U_BlobMura_ResizeL_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                    
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[4] Update Processed Image (Img_BlobMura_ResizeLChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild)
                            Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 3
                        Me.UpdateSelectdImage()
                    End If

                    'Macro Mura ---
                    '[1] Update Processed Image (Img_16U_MacroMura_ResizeH_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                    
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_MacroMura_ResizeHChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)


                        'Me.ComboBox_Select.SelectedIndex = 4
                        Me.UpdateSelectdImage()
                    End If

                    '[3] Update Processed Image (Img_16U_MacroMura_ResizeL_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                    
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[4] Update Processed Image (Img_MacroMura_ResizeLChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)


                        'Me.ComboBox_Select.SelectedIndex = 5
                        Me.UpdateSelectdImage()
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '---------------------------------------------------------------------------------------------------------------------------------

            '--- ���o�۴�v�� ---
            '----------------------------------------------------------------------------------------------
            ' Calculate White Area Image  ==> Request_Command = "CALCULATE_WHITE_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_WHITE_AREA"
                TimeOut = 200000 '200 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If Response_OK Then
                    '[1] Update Processed Image (Img_16U_BlobMura_White_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                   
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If

                    '[2] Update Processed Image (Img_BlobMuraArea_WhiteChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild)
                        Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                    'Me.ComboBox_Select.SelectedIndex = 6
                    Me.UpdateSelectdImage()
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Black Area Image  ==> Request_Command = "CALCULATE_BLACK_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_BLACK_AREA"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If Response_OK Then
                    '[1] Update Processed Image (Img_16U_BlobMura_Black_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                   
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_BlobMuraArea_BlackChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild)
                            Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = M_NULL
                        End If

                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If

                        Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 7
                        Me.UpdateSelectdImage()

                    End If

                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate White Macro Image  ==> Request_Command = "CALCULATE_WHITE_MACRO" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_WHITE_MACRO"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_16U_MacroMura_White_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                  
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_MacroMura_WhiteChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild = M_NULL
                        End If

                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If

                        Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                    End If

                    'Me.ComboBox_Select.SelectedIndex = 8
                    Me.UpdateSelectdImage()
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Black Macro Image  ==> Request_Command = "CALCULATE_BLACK_MACRO" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_BLACK_MACRO"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_16U_MacroMura_Black_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                  
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_MacroMura_BlackChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild = M_NULL
                        End If

                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If

                        Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 9
                        Me.UpdateSelectdImage()
                    End If

                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.GroupBox_Modify.Enabled = True
            Me.GroupBox_Parameter.Enabled = True
            Me.CheckBox_Show.Checked = True

            '---------------------------------------------------------------------------------------------------------------------------------
            '--- ��i����Blob Mura ---
            '----------------------------------------------------------------------------------------------
            ' Calculate Black Blob Mura (Area-���߰�)  ==> Request_Command = "CALCULATE_BLACKBLOB_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_BLACKBLOB_AREA"
                TimeOut = 500000 '500 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_1U_BlackReconstructArea_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                    
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 10
                        Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                    End If

                    '[2] Update Processed Image (Img_1U_BlackThreshold_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                  
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 11
                        Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate White Blob Mura (Area-���߰�)  ==> Request_Command = "CALCULATE_WHITEBLOB_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_WHITEBLOB_AREA"
                TimeOut = 500000 '500 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_1U_WhiteReconstructArea_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                  
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 12
                        Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If

                    '[2] Update Processed Image (Img_1U_WhiteThreshold_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If
                 
                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 13
                        Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Position shift in Mura_Local  ==> Request_Command = "POSITIONSHIFT_MURALOCAL" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "POSITIONSHIFT_MURALOCAL"
                TimeOut = 100000 '100 secs

                RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RefX, RefY, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Position shift in Mura_Local  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.m_MuraProcess.HavePositionShift_Round = True
            '----------------------------------------------------------------------------------------------------------------------------------

            If CheckBox_Show.Checked Then  Me.ReDraw()

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraSetting.Button_LoadFFCImage]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim str As String
        Dim dir As String
        Dim boundary As ClsParameterBoundary
        Dim mpr As ClsMuraPatternRecipe
        Dim Parameter_Lists As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Me.Button_Save.Enabled = False   '2010/07/12 Rick add
            Me.m_MuraProcess.CurrentMuraPatternRecipe.UseCenter.Value = Me.CheckBox_Center.Checked

            '----------------------------------------------------------------------------------------------
            ' Dialog_BlobMuraLocal Setting   ==> Request_Command = "DIALOG_BLOBMURALOCAL_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_BLOBMURALOCAL_SETTING"
                TimeOut = 100000 '100 secs

                Parameter_Lists = "UseCenter," & Me.CheckBox_Center.Checked & ";" & _
                                  "AreaTop," & Me.NumericUpDown_AreaTop.Value & ";" & "AreaBottom," & Me.NumericUpDown_AreaBottom.Value & ";" & "AreaLeft," & Me.NumericUpDown_AreaLeft.Value & ";" & "AreaRight," & Me.NumericUpDown_AreaRight.Value & ";" & _
                                  "WhiteBlobMura_ReconstructHeight," & Me.NUD_WhiteBlobMura_ReconstructHeight.Value & ";" & "WhiteBlobMura_ReconstructLow," & Me.NUD_WhiteBlobMura_ReconstructLow.Value & ";" & "WhiteMacroMura_Threshold," & Me.NUD_WhiteMacroMura_Threshold.Value & ";" & _
                                  "BlackBlobMura_ReconstructHeight," & Me.NUD_BlackBlobMura_ReconstructHeight.Value & ";" & "BlackBlobMura_ReconstructLow," & Me.NUD_BlackBlobMura_ReconstructLow.Value & ";" & "BlackMacroMura_Threshold," & Me.NUD_BlackMacroMura_Threshold.Value & ";" & _
                                  "UseReconstructBW," & Me.CheckBox_UseReconstructBW.Checked & ";"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraLocal Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Save.Enabled = True
                    Exit Sub
                End If
            Catch ex As Exception
                Me.Button_Save.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraLocal.Button_Save]Dialog_BlobMuraLocal Setting Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '-------------------------------------------------------------------------------------------------------

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MainProcess.MuraPatternRecipeArrayTemp.Count Then
                mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
            Else
                mpr = Me.m_MuraProcess.MuraPatternRecipeArray.Item(0)
            End If

            boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound
            boundary.TopY = Me.NumericUpDown_AreaTop.Value
            boundary.BottomY = Me.NumericUpDown_AreaBottom.Value
            boundary.LeftX = Me.NumericUpDown_AreaLeft.Value
            boundary.RightX = Me.NumericUpDown_AreaRight.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value = Me.NUD_WhiteBlobMura_ReconstructHeight.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value = Me.NUD_WhiteBlobMura_ReconstructLow.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_Threshold.Value = Me.NUD_WhiteMacroMura_Threshold.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value = Me.NUD_BlackBlobMura_ReconstructHeight.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value = Me.NUD_BlackBlobMura_ReconstructLow.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_Threshold.Value = Me.NUD_BlackMacroMura_Threshold.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.UseReconstructBW.Value = Me.CheckBox_UseReconstructBW.Checked

            dir = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If

            str = dir & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)
            Me.m_MuraProcess.SaveAllMuraRecipe(Me.m_MainProcess.RECIPE_PATH, Me.m_Form.TextBox_Product.Text, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 10000 '10 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Save.Enabled = True
                    Exit Sub
                End If

            Catch ex As Exception
                Me.Button_Save.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraLocal.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save All Mura Recipe  ==> Request_Command = "SAVE_ALL_MURA_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_ALL_MURA_RECIPE"
                TimeOut = 10000 '10 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Mura Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Save.Enabled = True
                    Exit Sub
                End If

            Catch ex As Exception
                Me.Button_Save.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraLocal.Button_Ok]Save All Mura Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '--- Mura Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

            '--- Button Control ---   
            Me.Button_Save.Enabled = True
        Catch ex As Exception
            Me.Button_Save.Enabled = True
            Me.m_Form.OutputInfo("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region

#Region "--- BtnPre_BlobMuraLocal ---"
    Private Sub BtnPre_BlobMuraLocal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPre_BlobMuraLocal.Click
        Me.Close()
    End Sub
#End Region

#End Region

#Region "--- UI Event ---"

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If Me.Focused AndAlso CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If Me.Focused AndAlso CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
#End Region

#End Region


End Class