Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.IO
Imports System.Threading
Imports System.Globalization

Public Class Dialog_BandMura
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_CurrentMuraIndex As Integer   '�O���ثe��ܼv���� Index   

    Private m_Left As Boolean
    Private m_Right As Boolean
    Private m_Top As Boolean
    Private m_Bottom As Boolean

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar
    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private WithEvents m_ZoomContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents m_ZoomInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_OriginToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

    Private MuraHBandBlockRecipeList As ClsMuraBandBlockRecipeList
    Private MuraVBandBlockRecipeList As ClsMuraBandBlockRecipeList
    Private DeleteH As Boolean = False
    Private DeleteV As Boolean = False
    Private HBlockRecipePath As String
    Private VBlockRecipePath As String
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image1 As MIL_ID
        Dim image2 As MIL_ID

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_BandMura", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess
        Me.m_Pen = New Pen(Color.Red)

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_SolidBrush = New SolidBrush(Color.White)

        image1 = Me.m_MuraProcess.Img_BandMura_SmoothChild
        If image1 <> M_NULL Then

            Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("Band���Ƽv��")
            'Me.ComboBox_Select.Items.Add("Band���Ƽv��")
            image1 = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
            image2 = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
            If image1 <> M_NULL And image2 <> M_NULL Then
                Me.ComboBox_Select.Items.Add("�������R�v��")
                Me.ComboBox_Select.Items.Add("�������R�v��")
                image1 = Me.m_MuraProcess.Img_16U_HProject_NonPage
                image2 = Me.m_MuraProcess.Img_16U_VProject_NonPage
                If image1 <> M_NULL And image2 <> M_NULL Then
                    Me.ComboBox_Select.Items.Add("������v�v��")
                    Me.ComboBox_Select.Items.Add("������v�v��")

                    image1 = Me.m_MuraProcess.Img_16U_HGolden_NonPage
                    image2 = Me.m_MuraProcess.Img_16U_VGolden_NonPage
                    If image1 <> M_NULL And image2 <> M_NULL Then
                        Me.ComboBox_Select.Items.Add("����Golden Band�v��")
                        Me.ComboBox_Select.Items.Add("����Golden Band�v��")

                        image1 = Me.m_MuraProcess.Img_16U_HBand_White_NonPage
                        image2 = Me.m_MuraProcess.Img_16U_HBand_Black_NonPage
                        If image1 <> M_NULL And image2 <> M_NULL Then
                            Me.ComboBox_Select.Items.Add("����White Band�v��")
                            Me.ComboBox_Select.Items.Add("����Black Band�v��")
                        End If

                        image1 = Me.m_MuraProcess.Img_16U_VBand_White_NonPage
                        image2 = Me.m_MuraProcess.Img_16U_VBand_Black_NonPage
                        If image1 <> M_NULL And image2 <> M_NULL Then
                            Me.ComboBox_Select.Items.Add("����White Band�v��")
                            Me.ComboBox_Select.Items.Add("����Black Band�v��")
                        End If

                        image1 = Me.m_MuraProcess.Img_1U_HBand_White_NonPage
                        image2 = Me.m_MuraProcess.Img_1U_HBand_Black_NonPage
                        If image1 <> M_NULL And image2 <> M_NULL Then
                            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�G-Threshold)")
                            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�t-Threshold)")
                        End If

                        image1 = Me.m_MuraProcess.Img_1U_VBand_White_NonPage
                        image2 = Me.m_MuraProcess.Img_1U_VBand_Black_NonPage
                        If image1 <> M_NULL And image2 <> M_NULL Then
                            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�G-Threshold)")
                            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�t-Threshold)")
                        End If
                    End If
                End If
            End If
        Else
            Me.m_Form.ComboBox_Type.SelectedIndex = -1
            Me.GroupBox_Modify.Enabled = False
            Me.Button_Band.Enabled = False
            Me.GroupBox_Parameter.Enabled = False
            MessageBox.Show("[Mura�v�����~] �S��Blob ���Ƽv�� ! ", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

        Me.m_CurrentMuraIndex = 0   '����White Band�G�ȤƼv��---   
        'Me.m_Form.ImageZoomAll()

        '--- UI ---
        Me.m_VScrollBar = Me.m_Form.VScrollBar
        Me.m_HScrollBar = Me.m_Form.HScrollBar
        Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
        Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
        Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
        Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
        Me.m_ZoomContextMenuStrip = Me.m_Form.ZoomContextMenuStrip
        Me.m_ZoomInToolStripMenuItem = Me.m_Form.ZoomInToolStripMenuItem
        Me.m_ZoomOutToolStripMenuItem = Me.m_Form.ZoomOutToolStripMenuItem
        Me.m_OriginToolStripMenuItem = Me.m_Form.OriginToolStripMenuItem
        Me.m_ZoomAllToolStripMenuItem = Me.m_Form.ZoomAllToolStripMenuItem

        '--- UI ---
        Me.HBlockRecipePath = Me.m_Form.MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_Form.MainProcess.IPBootConfig.CCD.Value & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraHBandBlockRecipe_C" & Me.m_Form.MainProcess.IPBootConfig.GrabNo.Value & "_P" & Me.m_Form.GetPatternIndexInfo + 1 & ".txt"
        Me.VBlockRecipePath = Me.m_Form.MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_Form.MainProcess.IPBootConfig.CCD.Value & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraVBandBlockRecipe_C" & Me.m_Form.MainProcess.IPBootConfig.GrabNo.Value & "_P" & Me.m_Form.GetPatternIndexInfo + 1 & ".txt"
        Me.UpdateData()

        '--- �v������ ---
        Me.UpdateUserLevel()
    End Sub

#Region "--- Dialog Event ---"

    Private Sub Dialog_BandMura_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim strPath_HBand_White As String = ""
        Dim strPath_HBand_Black As String = ""
        Dim strPath_VBand_White As String = ""
        Dim strPath_VBand_Black As String = ""
        Dim IP_Address As String = ""

        Me.m_Form.PaintStop = True
        Me.m_Form.PictureBox_HBand_Black.Visible = False
        Me.m_Form.PictureBox_HBand_White.Visible = False
        Me.m_Form.PictureBox_VBand_Black.Visible = False
        Me.m_Form.PictureBox_VBand_White.Visible = False

        '---Delete Result Image---
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
            strPath_HBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            strPath_HBand_White = strPath_HBand_White.Replace("\\", "\")
            strPath_HBand_Black = strPath_HBand_Black.Replace("\\", "\")
            strPath_VBand_White = strPath_VBand_White.Replace("\\", "\")
            strPath_VBand_Black = strPath_VBand_Black.Replace("\\", "\")
        Else
            strPath_HBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.RepairPath_2(strPath_HBand_White)
            Me.RepairPath_2(strPath_HBand_Black)
            Me.RepairPath_2(strPath_VBand_White)
            Me.RepairPath_2(strPath_VBand_Black)
        End If
        
        If System.IO.File.Exists(strPath_HBand_White) Then
            System.IO.File.Delete(strPath_HBand_White)
        End If
        If System.IO.File.Exists(strPath_HBand_Black) Then
            System.IO.File.Delete(strPath_HBand_Black)
        End If
        If System.IO.File.Exists(strPath_VBand_White) Then
            System.IO.File.Delete(strPath_VBand_White)
        End If
        If System.IO.File.Exists(strPath_VBand_Black) Then
            System.IO.File.Delete(strPath_VBand_Black)
        End If
        Me.m_Panel_AxMDisplay.Refresh()
        Me.CheckBox_Show.Checked = False
        Me.CheckBox_ShowBlock.Checked = False
        Me.m_VScrollBar = Nothing
        Me.m_HScrollBar = Nothing
        Me.m_Button_ZoomIn = Nothing
        Me.m_Button_ZoomOut = Nothing
        Me.m_Button_ZoomO = Nothing
        Me.m_Button_ZoomAll = Nothing
        Me.m_ZoomContextMenuStrip = Nothing
        Me.m_ZoomInToolStripMenuItem = Nothing
        Me.m_ZoomOutToolStripMenuItem = Nothing
        Me.m_OriginToolStripMenuItem = Nothing
        Me.m_ZoomAllToolStripMenuItem = Nothing
        Me.Finalize()
    End Sub

    Private Sub Dialog_BandMura_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Me.RadioButton_Finish.Checked = True
        '--- Initial Button --- 
        Me.ComboBox_Show.Text = "H"
        Me.Button_Ok.Enabled = True
        Me.Button_Cancel.Enabled = True
        Me.GroupBox_Modify.Enabled = Me.CheckBox_Band.Checked
        Me.GroupBox_Parameter.Enabled = Me.CheckBox_Band.Checked
        Me.Button_Band.Enabled = Me.CheckBox_Band.Checked

        Me.CheckBox_Result.Checked = True
        Me.ComboBox_Result.SelectedIndex = 0
        Me.ComboBox_SelectBlock.SelectedIndex = 0

        Me.Update()
    End Sub

#End Region

#Region "--- ��k�禡 ---"

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Load.Enabled = En
        Button_Band.Enabled = En
        Button_Ok.Enabled = En
        Button_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_Modify.Enabled = False
                Me.GroupBox_Parameter.Enabled = False
            Case 1 'PM
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = False
            Case 2 'ENG
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
            Case 3 'ALL
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim HBoundary As ClsParameterBoundary
        Dim VBoundary As ClsParameterBoundary
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        HBoundary = Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand
        VBoundary = Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand
        MuraHBandBlockRecipeList = Me.m_Form.MuraProcess.MuraHBandBlockReicpeListArray.Item(Me.m_Form.GetPatternIndexInfo)
        MuraVBandBlockRecipeList = Me.m_Form.MuraProcess.MuraVBandBlockReicpeListArray.Item(Me.m_Form.GetPatternIndexInfo)

        Me.NumericUpDown_HTop.Value = HBoundary.TopY
        Me.NumericUpDown_HBottom.Value = HBoundary.BottomY
        Me.NumericUpDown_HLeft.Value = HBoundary.LeftX
        Me.NumericUpDown_HRight.Value = HBoundary.RightX
        Me.NumericUpDown_VTop.Value = VBoundary.TopY
        Me.NumericUpDown_VBottom.Value = VBoundary.BottomY
        Me.NumericUpDown_VLeft.Value = VBoundary.LeftX
        Me.NumericUpDown_VRight.Value=VBoundary.RightX

        Me.CheckBox_Band.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseBand.Value
        Me.CheckBox_BandUseRemoveHV.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandUseRemoveHV.Value
        Me.NumericUpDown_BandMura_ResizeCount.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value
        Me.NumericUpDown_BandMura_SmoothCount.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_SmoothCount.Value
        Me.NumericUpDown_WhiteHBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteHBand_Threshold.Value
        Me.NumericUpDown_BlackHBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackHBand_Threshold.Value
        Me.NumericUpDown_WhiteVBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteVBand_Threshold.Value
        Me.NumericUpDown_BlackVBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackVBand_Threshold.Value

        Me.NumericUpDown_HValue_WhiteTH.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.WhiteHBandTH
        Me.NumericUpDown_HValue_BlackTH.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.BlackHBandTH
        Me.NumericUpDown_VValue_WhiteTH.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.WhiteVBandTH
        Me.NumericUpDown_VValue_BlackTH.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.BlackVBandTH

        Me.CheckBox_EnableBandLeakPoint.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.EnableBandLeakPoint.Value
        Me.NumericUpDown_BandLeakPointFilterRadius.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandLeakPointFilterRadius.Value
        Me.CheckBox_EnableBandVOpen.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.EnableBandVOpen.Value
        Me.NumericUpDown_BandVOpenEdgeStrength.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandVOpenEdgeStrength.Value
        'UpdateBandBlockRecipeList
        Me.ListViewReflash()

    End Sub
#End Region

#Region "--- ReDraw ---"
    Private Sub ReDraw()
        Dim image As MIL_ID = M_NULL
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.CheckBox_Show.Checked And Me.ComboBox_Select.SelectedIndex = 0 And image <> M_NULL Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)

            Me.m_SolidBrush.Color = Color.Red
            '--- Initial ---

            If Me.ComboBox_Show.Text = "H" Then
                s = Math.Ceiling(ZoomX)
                Me.m_SolidBrush.Color = Color.Red
                v = (Me.NumericUpDown_HLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = SizeX - Me.NumericUpDown_HRight.Value
                v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_HTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = SizeY - Me.NumericUpDown_HBottom.Value
                v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
            Else
                s = Math.Ceiling(ZoomX)
                Me.m_SolidBrush.Color = Color.Red
                v = (Me.NumericUpDown_VLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = SizeX - Me.NumericUpDown_VRight.Value
                v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_VTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = SizeY - Me.NumericUpDown_VBottom.Value
                v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = False
    End Sub

    Private Sub ReDrawBlock()
        Dim image As MIL_ID = M_NULL
        Dim rect As Rectangle
        Dim s As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer
        Dim mbbr As ClsMuraBandBlockRecipe

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)


        If CheckBox_ShowBlock.Checked Then
            If Me.ComboBox_SelectBlock.SelectedItem = "V" Then
                If Me.ComboBox_Result.SelectedItem = "Black" Then
                    'Me.ComboBox_Select.SelectedIndex = 14
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
                    s = Math.Ceiling(ZoomX)
                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                    For i = 0 To MuraVBandBlockRecipeList.Count - 1
                        mbbr = MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i)
                        rect = New Rectangle
                        rect.X = (mbbr.LeftBoundary - Me.m_Form.HScrollBar.Value) * ZoomX
                        rect.Y = 0
                        rect.Width = (mbbr.RightBoundary - mbbr.LeftBoundary) * ZoomX
                        rect.Height = 128*ZoomY
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    Next
                ElseIf Me.ComboBox_Result.SelectedItem = "White" Then
                    'Me.ComboBox_Select.SelectedIndex = 13
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
                    s = Math.Ceiling(ZoomX)
                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                    For i = 0 To MuraVBandBlockRecipeList.Count - 1
                        mbbr = MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i)
                        rect = New Rectangle
                        rect.X = (mbbr.LeftBoundary - Me.m_Form.HScrollBar.Value) * ZoomX
                        rect.Y = 0
                        rect.Width = (mbbr.RightBoundary - mbbr.LeftBoundary) * ZoomX
                        rect.Height = 128 * ZoomY
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    Next
                End If
            ElseIf Me.ComboBox_SelectBlock.SelectedItem = "H" Then
                If Me.ComboBox_Result.SelectedItem = "Black" Then
                    'Me.ComboBox_Select.SelectedIndex = 12
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
                    s = Math.Ceiling(ZoomX)
                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                    For i = 0 To MuraHBandBlockRecipeList.Count - 1
                        mbbr = MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i)
                        rect = New Rectangle
                        rect.X = 0
                        rect.Y = (mbbr.TopBoundary - Me.m_Form.VScrollBar.Value) * ZoomY
                        rect.Width = 128 * ZoomX
                        rect.Height = (mbbr.ButtomBoundary-mbbr.TopBoundary) * ZoomY
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    Next
                ElseIf Me.ComboBox_Result.SelectedItem = "White" Then
                    'Me.ComboBox_Select.SelectedIndex = 11
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                    MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
                    s = Math.Ceiling(ZoomX)
                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                    For i = 0 To MuraHBandBlockRecipeList.Count - 1
                        mbbr = MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i)
                        rect = New Rectangle
                        rect.X = 0
                        rect.Y = (mbbr.TopBoundary - Me.m_Form.VScrollBar.Value) * ZoomY
                        rect.Width = 128 * ZoomX
                        rect.Height = (mbbr.ButtomBoundary - mbbr.TopBoundary) * ZoomY
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    Next
                End If
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
    End Sub
#End Region

#Region "--- UpdateSelectdImage ---"
    Private Sub UpdateSelectdImage()
        Dim Image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Try
            Select Case Me.ComboBox_Select.SelectedIndex
                Case 0   '���Ƽv�� ---
                    Image = Me.m_MuraProcess.Img_BandMura_SmoothChild
                Case 1   '�������R�v�� ---
                    Image = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
                Case 2   '�������R�v�� ---
                    Image = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
                Case 3   '������v�v�� ---
                    Image = Me.m_MuraProcess.Img_16U_HProject_NonPage
                Case 4   '������v�v�� ---
                    Image = Me.m_MuraProcess.Img_16U_VProject_NonPage
                Case 5   '����Golden Band�v�� ---
                    Image = Me.m_MuraProcess.Img_16U_HGolden_NonPage
                Case 6   '����Golden Band�v�� ---
                    Image = Me.m_MuraProcess.Img_16U_VGolden_NonPage
                Case 7   '����White Band�v��---
                    Image = Me.m_MuraProcess.Img_16U_HBand_White_NonPage
                Case 8   '����Black Band�v��---
                    Image = Me.m_MuraProcess.Img_16U_HBand_Black_NonPage
                Case 9   '����White Band�v��---
                    Image = Me.m_MuraProcess.Img_16U_VBand_White_NonPage
                Case 10  '����Black Band�v��---
                    Image = Me.m_MuraProcess.Img_16U_VBand_Black_NonPage
                Case 11   '����White Band�G�ȤƼv��---
                    Image = Me.m_MuraProcess.Img_1U_HBand_White_NonPage
                Case 12   '����Black Band�G�ȤƼv��---
                    Image = Me.m_MuraProcess.Img_1U_HBand_Black_NonPage
                Case 13   '����White Band�G�ȤƼv��---
                    Image = Me.m_MuraProcess.Img_1U_VBand_White_NonPage
                Case 14   '����Black Band�G�ȤƼv��---
                    Image = Me.m_MuraProcess.Img_1U_VBand_Black_NonPage
            End Select

            If Image <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                Type = MbufInquire(Image, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(Image, imageBuffer)

                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                MbufControl(Image, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_Form.AxMDisplay, M_VIEW_MODE, M_AUTO_SCALE)

                Me.m_Form.ResetScrollBar()
                Me.m_Form.ImageZoomAll
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.UpdateSelectdImage] Update Selected Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.UpdateSelectdImage]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- DeleteBlockRecipe ---"
    Private Sub DeleteBlockRecipe()
        If DeleteH And MuraHBandBlockRecipeList.Count > 0 And Me.ListView_HBlock.SelectedIndices.Count > 0 Then
            Me.MuraHBandBlockRecipeList.RemoveAt(Me.ListView_HBlock.SelectedIndices(0))
            Me.m_Form.MuraProcess.SaveMuraBandBlockRecipe(Me.HBlockRecipePath, Me.MuraHBandBlockRecipeList)
            Me.ListViewReflash()
        ElseIf DeleteV And MuraVBandBlockRecipeList.Count > 0 And Me.ListView_VBlock.SelectedIndices.Count > 0 Then
            Me.MuraVBandBlockRecipeList.RemoveAt(Me.ListView_VBlock.SelectedIndices(0))
            Me.m_Form.MuraProcess.SaveMuraBandBlockRecipe(Me.VBlockRecipePath, Me.MuraVBandBlockRecipeList)
            Me.ListViewReflash()
        End If

        Me.LOAD_ALL_MURA_PATTERN_RECIPE()
        Me.SET_PATTERNINDEX()

    End Sub
#End Region

#Region "---Load All Mura Pattern Recipe---"

    Private Sub LOAD_ALL_MURA_PATTERN_RECIPE()
        Try
            '--- Prepare Command ---
            Request_Command = "LOAD_ALL_MURA_PATTERN_RECIPE"
            TimeOut = 100000 '100 secs
            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BandMura Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Ok]Dialog_BandMura Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Ok]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "---Set PaternIndex---"

    Private Sub SET_PATTERNINDEX()
        Dim PatternName As String
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.m_Form.ComboBox_Pattern_MainFrm.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            System.Threading.Thread.Sleep(1000)
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_Cancel.Text = res.GetString("Button_Cancel.Text")
                Button_Load.Text = res.GetString("Button_Load.Text")
                Button_Ok.Text = res.GetString("Button_Ok.Text")
                CheckBox_Show.Text = res.GetString("CheckBox_Show.Text")
                CheckBox_ShowBlock.Text = res.GetString("CheckBox_ShowBlock.Text")
                ColumnHeader1.Text = res.GetString("ColumnHeader1.Text")
                ColumnHeader10.Text = res.GetString("ColumnHeader10.Text")
                ColumnHeader2.Text = res.GetString("ColumnHeader2.Text")
                ColumnHeader3.Text = res.GetString("ColumnHeader3.Text")
                ColumnHeader4.Text = res.GetString("ColumnHeader4.Text")
                ColumnHeader7.Text = res.GetString("ColumnHeader7.Text")
                ColumnHeader8.Text = res.GetString("ColumnHeader8.Text")
                ColumnHeader9.Text = res.GetString("ColumnHeader9.Text")
                GroupBox_H.Text = res.GetString("GroupBox_H.Text")
                GroupBox_Modify.Text = res.GetString("GroupBox_Modify.Text")
                GroupBox_Parameter.Text = res.GetString("GroupBox_Parameter.Text")
                GroupBox_V.Text = res.GetString("GroupBox_V.Text")
                GroupBox1.Text = res.GetString("GroupBox1.Text")
                Label_Band_ResizeCount.Text = res.GetString("Label_Band_ResizeCount.Text")
                Label_Band_SmoothCount.Text = res.GetString("Label_Band_SmoothCount.Text")
                Label_Bottom.Text = res.GetString("Label_Bottom.Text")
                Label_Left.Text = res.GetString("Label_Left.Text")
                Label_Right.Text = res.GetString("Label_Right.Text")
                Label_Select.Text = res.GetString("Label_Select.Text")
                Label_Top.Text = res.GetString("Label_Top.Text")
                Label10.Text = res.GetString("Label10.Text")
                Label13.Text = res.GetString("Label13.Text")
                Label3.Text = res.GetString("Label3.Text")
                Label4.Text = res.GetString("Label4.Text")
                Label5.Text = res.GetString("Label5.Text")
                Label6.Text = res.GetString("Label6.Text")
                Label7.Text = res.GetString("Label7.Text")
                Label8.Text = res.GetString("Label8.Text")
                Label9.Text = res.GetString("Label9.Text")
                RadioButton_Finish.Text = res.GetString("RadioButton_Finish.Text")
                RadioButton_Manual.Text = res.GetString("RadioButton_Manual.Text")
        End Select
    End Sub
#End Region


#End Region

#Region "--- RadioButton Event ---"
    'Private Sub RadioButton_Finish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Finish.CheckedChanged
    '    Dim boundary As ClsParameterBoundary
    '    Dim image1 As MIL_ID
    '    Dim image2 As MIL_ID
    '    Dim Image_Range As String = ""

    '    '--- �إ߳s�u ---
    '    If Not Me.ConnectToIP Then
    '        Exit Sub
    '    End If

    '    '--- Disable Button ---
    '    Me.Button_Enable(False)

    '    If Me.RadioButton_Finish.Checked Then
    '        Me.GroupBox_H.Enabled = False
    '        Me.GroupBox_V.Enabled = False
    '        Me.ComboBox_Select.Enabled = True

    '        boundary = Me.m_MuraProcess.MuraModelRecipe.Band

    '        If Me.NumericUpDown_HTop.Value <> boundary.TopY Or Me.NumericUpDown_HBottom.Value <> boundary.BottomY Or Me.NumericUpDown_VLeft.Value <> boundary.LeftX Or Me.NumericUpDown_VRight.Value <> boundary.RightX Then
    '            boundary.TopY = Me.NumericUpDown_HTop.Value
    '            boundary.BottomY = Me.NumericUpDown_HBottom.Value
    '            boundary.LeftX = Me.NumericUpDown_VLeft.Value
    '            boundary.RightX = Me.NumericUpDown_VRight.Value

    '            Me.m_MuraProcess.Mura_CreateImage(Me.m_MainProcess.IPBootConfig, Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MuraProcess.MuraModelRecipe, Me.m_MainProcess.ErrorCode)   '20120511 Rick modify
    '        End If

    '        image1 = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
    '        image2 = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
    '        If image1 <> M_NULL And image2 <> M_NULL Then
    '            image1 = Me.m_MuraProcess.Img_16U_HProject_NonPage
    '            image2 = Me.m_MuraProcess.Img_16U_VProject_NonPage
    '            If image1 <> M_NULL And image2 <> M_NULL Then
    '                image1 = Me.m_MuraProcess.Img_16U_HProject_NonPage
    '                image2 = Me.m_MuraProcess.Img_16U_VProject_NonPage
    '                Me.Button_Band.Enabled = True
    '            End If
    '        End If

    '        '----------------------------------------------------------------------------------------------
    '        ' Create Mura Image  ==> Request_Command = "CALCULATE_MURA_CREATEIMAGE" (Dispatcher 2)
    '        '----------------------------------------------------------------------------------------------
    '        Try
    '            '--- Prepare Command ---
    '            Request_Command = "CALCULATE_MURA_CREATEIMAGE"
    '            TimeOut = 200000 '200 secs
    '            Image_Range = "PART"

    '            Response_OK = False
    '            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Image_Range, , , , , , , , TimeOut)
    '            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

    '            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
    '                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
    '                Response_OK = True
    '            Else
    '                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Create Mura Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
    '                MessageBox.Show("[Dialog_BandMura.RadioButton_Finish]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                Me.Button_Enable(True)
    '                Exit Sub
    '            End If

    '            Me.Button_Enable(True)
    '        Catch ex As Exception
    '            Me.Button_Enable(True)
    '            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.RadioButton_Finish]Create Mura Image Error ! (" & ex.Message & ")")
    '            MessageBox.Show("[Dialog_BandMura.RadioButton_Finish]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '        End Try
    '    End If
    'End Sub
    Private Sub RadioButton_Manual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Manual.CheckedChanged
        If Me.RadioButton_Manual.Checked Then
            If ComboBox_Show.Text = "V" Then
                Me.GroupBox_H.Enabled = False
                Me.GroupBox_V.Enabled = True
            Else
                Me.GroupBox_H.Enabled = True
                Me.GroupBox_V.Enabled = False
            End If
            Me.ComboBox_Select.Enabled = False
            Me.Button_Band.Enabled = False
        End If
    End Sub
#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_Show ---"
    Private Sub CheckBox_Show_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show.CheckedChanged
        If ComboBox_Show.Text = "V" Then
            Me.GroupBox_H.Enabled = False
            Me.GroupBox_V.Enabled = True
        Else
            Me.GroupBox_H.Enabled = True
            Me.GroupBox_V.Enabled = False
        End If
        Me.ReDraw()
    End Sub
#End Region

#Region "--- CheckBox_Result ---"
    Private Sub CheckBox_Result_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_Result.CheckedChanged
        If Me.CheckBox_Result.Checked Then
            If Me.ComboBox_Result.Text = "Black" Then
                Me.m_Form.PictureBox_HBand_Black.Visible = True
                Me.m_Form.PictureBox_HBand_White.Visible = False
                Me.m_Form.PictureBox_VBand_Black.Visible = True
                Me.m_Form.PictureBox_VBand_White.Visible = False
            ElseIf Me.ComboBox_Result.Text = "White" Then
                Me.m_Form.PictureBox_HBand_Black.Visible = False
                Me.m_Form.PictureBox_HBand_White.Visible = True
                Me.m_Form.PictureBox_VBand_Black.Visible = False
                Me.m_Form.PictureBox_VBand_White.Visible = True
            End If
        Else
            Me.m_Form.PictureBox_HBand_Black.Visible = False
            Me.m_Form.PictureBox_HBand_White.Visible = False
            Me.m_Form.PictureBox_VBand_Black.Visible = False
            Me.m_Form.PictureBox_VBand_White.Visible = False
        End If
        Me.m_Form.PictureBox_HBand_Black.SizeMode = 1
        Me.m_Form.PictureBox_HBand_White.SizeMode = 1
        Me.m_Form.PictureBox_VBand_Black.SizeMode = 1
        Me.m_Form.PictureBox_VBand_White.SizeMode = 1
    End Sub
#End Region

#Region "--- CheckBox_Band ---"
    Private Sub CheckBox_Band_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Band.CheckedChanged
        Me.GroupBox_Modify.Enabled = Me.CheckBox_Band.Checked
        Me.GroupBox_Parameter.Enabled = Me.CheckBox_Band.Checked
        Me.Button_Band.Enabled = Me.CheckBox_Band.Checked
    End Sub
#End Region

#Region "---CheckBox_ShowBlock---"
    Private Sub CheckBox_ShowBlock_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_ShowBlock.CheckedChanged
        If CheckBox_ShowBlock.Checked Then
            If Me.ComboBox_Select.Items.Count = 1 Then
                Me.Button_Band.PerformClick()
            End If
            If Me.ComboBox_SelectBlock.SelectedItem = "" Then
                MsgBox("�Х����V or H Block", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                Exit Sub
            End If
            If Me.CheckBox_Show.Checked Then
                Me.CheckBox_Show.Checked =False
            End If
            Me.ReDrawBlock()
        Else
            Me.ReDrawBlock()
        End If
    End Sub
#End Region

#End Region

#Region "--- ComboBox Event ---"

    Private Sub ComboBox_Select_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Select.SelectedIndexChanged
        'Select Case Me.ComboBox_Select.SelectedIndex
        '    Case 0   '--- ���Ƽv�� ---
        '        Me.m_Form.CurrentIndex1 = 2
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 1
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 2
        '        Me.m_CurrentMuraIndex = 0
        '    Case 1   '--- �������R�v�� ---
        '        Me.m_Form.CurrentIndex2 = 0
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 0
        '        Me.m_CurrentMuraIndex = 1
        '    Case 2   '--- �������R�v�� ---
        '        Me.m_Form.CurrentIndex2 = 7
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 7
        '        Me.m_CurrentMuraIndex = 2
        '    Case 3   '--- ������v�v�� ---
        '        Me.m_Form.CurrentIndex2 = 1
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 1
        '        Me.m_CurrentMuraIndex = 3
        '    Case 4   '--- ������v�v�� ---
        '        Me.m_Form.CurrentIndex2 = 8
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 8
        '        Me.m_CurrentMuraIndex = 4
        '    Case 5   '--- ����Golden Band�v�� ---
        '        Me.m_Form.CurrentIndex2 = 2
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 2
        '        Me.m_CurrentMuraIndex = 5
        '    Case 6   '--- ����Golden Band�v�� ---
        '        Me.m_Form.CurrentIndex2 = 9
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 9
        '        Me.m_CurrentMuraIndex = 6
        '    Case 7   '--- ����White Band�v��---
        '        Me.m_Form.CurrentIndex2 = 3
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 3
        '        Me.m_CurrentMuraIndex = 7
        '    Case 8   '--- ����Black Band�v��---
        '        Me.m_Form.CurrentIndex2 = 4
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 4
        '        Me.m_CurrentMuraIndex = 8
        '    Case 9   '--- ����White Band�v��---
        '        Me.m_Form.CurrentIndex2 = 10
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 10
        '        Me.m_CurrentMuraIndex = 9
        '    Case 10  '--- ����Black Band�v��---
        '        Me.m_Form.CurrentIndex2 = 11
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 11
        '        Me.m_CurrentMuraIndex = 10
        '    Case 11   '--- ����White Band�G�ȤƼv��---
        '        Me.m_Form.CurrentIndex2 = 5
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 5
        '        Me.m_CurrentMuraIndex = 11
        '    Case 12   '����Black Band�G�ȤƼv��---
        '        Me.m_Form.CurrentIndex2 = 6
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 6
        '        Me.m_CurrentMuraIndex = 12
        '    Case 13   '--- ����White Band�G�ȤƼv��---
        '        Me.m_Form.CurrentIndex2 = 12
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 12
        '        Me.m_CurrentMuraIndex = 13
        '    Case 14   '--- ����Black Band�G�ȤƼv��---
        '        Me.m_Form.CurrentIndex2 = 13
        '        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        '        Me.m_Form.ComboBox_Select.SelectedIndex = 13
        '        Me.m_CurrentMuraIndex = 14
        'End Select

        'If Me.ComboBox_Select.SelectedIndex > 0 Then
        '    Me.GroupBox_Modify.Enabled = False
        'Else
        '    Me.GroupBox_Modify.Enabled = True
        'End If
        'Me.m_Form.ImageUpdate()

        'Select Case Me.ComboBox_Select.SelectedIndex
        '    Case 0, 1, 2
        '        Me.m_Form.ImageZoomAll()
        '    Case Else
        '        Me.m_Form.ImageZoomO()
        'End Select
        UpdateSelectdImage()
        If CheckBox_Show.Checked Then Me.ReDraw()

    End Sub

    Private Sub ComboBox_Show_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ComboBox_Show.SelectedIndexChanged
        If ComboBox_Show.Text = "V" Then
            Me.GroupBox_H.Enabled = False
            Me.GroupBox_V.Enabled = True
        Else
            Me.GroupBox_H.Enabled = True
            Me.GroupBox_V.Enabled = False
        End If
        ReDraw()
    End Sub

    Private Sub ComboBox_Result_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles ComboBox_Result.SelectedIndexChanged
        If Me.CheckBox_Result.Checked Then
            If Me.ComboBox_Result.Text = "Black" Then
                Me.m_Form.PictureBox_HBand_Black.Visible = True
                Me.m_Form.PictureBox_HBand_White.Visible = False
                Me.m_Form.PictureBox_VBand_Black.Visible = True
                Me.m_Form.PictureBox_VBand_White.Visible=False
            ElseIf Me.ComboBox_Result.Text = "White" Then
                Me.m_Form.PictureBox_HBand_Black.Visible = False
                Me.m_Form.PictureBox_HBand_White.Visible = True
                Me.m_Form.PictureBox_VBand_Black.Visible = False
                Me.m_Form.PictureBox_VBand_White.Visible = True
            End If
        End If
    End Sub

#End Region

#Region "--- NumericUpDown Event ---"
    Private Sub NumericUpDown_HTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_HTop.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeY As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_HBottom.Maximum = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_HTop.Value
            Me.ReDraw()
        End If
        Me.TextBox_HVCount.Text = SizeY - Me.NumericUpDown_HTop.Value - Me.NumericUpDown_HBottom.Value - 1
    End Sub
    Private Sub NumericUpDown_HBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_HBottom.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeY As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_HTop.Maximum = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_HBottom.Value
            Me.ReDraw()
        End If
        Me.TextBox_HVCount.Text = SizeY - Me.NumericUpDown_HTop.Value - Me.NumericUpDown_HBottom.Value - 1
    End Sub
    Private Sub NumericUpDown_HLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_HLeft.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeX As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_HRight.Maximum = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_HLeft.Value
            Me.ReDraw()
        End If
        Me.TextBox_HHCount.Text = SizeX - Me.NumericUpDown_HLeft.Value - Me.NumericUpDown_HRight.Value - 1
    End Sub
    Private Sub NumericUpDown_HRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_HRight.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeX As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_HLeft.Maximum = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_HRight.Value
            Me.ReDraw()
        End If
        Me.TextBox_HHCount.Text = SizeX - Me.NumericUpDown_HLeft.Value - Me.NumericUpDown_HRight.Value - 1
    End Sub
    Private Sub NumericUpDown_VTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_VTop.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeY As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_VBottom.Maximum = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_VTop.Value
            Me.ReDraw()
        End If
        Me.TextBox_VVCount.Text = SizeY - Me.NumericUpDown_VTop.Value - Me.NumericUpDown_VBottom.Value - 1
    End Sub
    Private Sub NumericUpDown_VBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_VBottom.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeY As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_VTop.Maximum = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.NumericUpDown_VBottom.Value
            Me.ReDraw()
        End If
        Me.TextBox_VVCount.Text = SizeY - Me.NumericUpDown_VTop.Value - Me.NumericUpDown_VBottom.Value - 1
    End Sub
    Private Sub NumericUpDown_VLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_VLeft.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeX As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_VRight.Maximum = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_VLeft.Value
            Me.ReDraw()
        End If
        Me.TextBox_VHCount.Text = SizeX - Me.NumericUpDown_VLeft.Value - Me.NumericUpDown_VRight.Value - 1
    End Sub
    Private Sub NumericUpDown_VRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_VRight.ValueChanged
        Dim image As MIL_ID = M_NULL
        Dim SizeX As Integer
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        If image <> M_NULL Then
            'Me.NumericUpDown_VLeft.Maximum = MbufInquire(image, M_SIZE_X, M_NULL) - Me.NumericUpDown_VRight.Value
            Me.ReDraw()
        End If
        Me.TextBox_VHCount.Text = SizeX - Me.NumericUpDown_VLeft.Value - Me.NumericUpDown_VRight.Value - 1
    End Sub
#End Region

#Region "--- AxMDisplay Operation ---"

    Private Sub m_Panel_AxMDisplay_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Panel_AxMDisplay.DoubleClick
        Dim image As MIL_ID = M_NULL
        Dim SizeX, SizeY As Integer
        Dim CenterX, CenterY As Integer
        MdispInquire(Me.m_AxMDisplay, M_SELECTED, image)
        MbufInquire(image, M_SIZE_X, SizeX)
        MbufInquire(image, M_SIZE_Y, SizeY)
        If Me.ComboBox_SelectBlock.Text = "" Then

        Else
            CenterX = Me.m_Form.MouseX
            CenterY = Me.m_Form.MouseY

            If Me.ComboBox_SelectBlock.Text = "H" Then
                If CenterY - Me.NumericUpDown_AutoWidth.Value > 0 Then
                    Me.NumericUpDown_BlockTop.Value = CenterY - Me.NumericUpDown_AutoWidth.Value
                Else
                    Me.NumericUpDown_BlockTop.Value = 0
                End If

                If CenterY + Me.NumericUpDown_AutoWidth.Value < SizeY - NumericUpDown_HTop.Value - NumericUpDown_HBottom.Value - 1 Then
                    Me.NumericUpDown_BlockButtom.Value = CenterY + Me.NumericUpDown_AutoWidth.Value
                Else
                    Me.NumericUpDown_BlockButtom.Value = SizeY - NumericUpDown_HTop.Value - NumericUpDown_HBottom.Value - 1
                End If
                Me.NumericUpDown_BlockLeft.Value = 0
                Me.NumericUpDown_BlockRight.Value = 0
            ElseIf Me.ComboBox_SelectBlock.Text = "V" Then
                If CenterX - Me.NumericUpDown_AutoWidth.Value > 0 Then
                    Me.NumericUpDown_BlockLeft.Value = CenterX - Me.NumericUpDown_AutoWidth.Value
                Else
                    Me.NumericUpDown_BlockLeft.Value = 0
                End If

                If CenterX + Me.NumericUpDown_AutoWidth.Value < SizeX - NumericUpDown_VLeft.Value - NumericUpDown_VRight.Value - 1 Then
                    Me.NumericUpDown_BlockRight.Value = CenterX + Me.NumericUpDown_AutoWidth.Value
                Else
                    Me.NumericUpDown_BlockRight.Value = SizeX - NumericUpDown_VLeft.Value - NumericUpDown_VRight.Value - 1
                End If
                Me.NumericUpDown_BlockTop.Value = 0
                Me.NumericUpDown_BlockButtom.Value = 0
            End If
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            Me.ReDraw()
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseDownEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        If e.Button = Windows.Forms.MouseButtons.Left Then

            MdispInquire(Me.m_AxMDisplay, M_SELECTED, image)
            If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked Then
                '--- Initial ---
                'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                'ZoomY = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, M_NULL)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

                MbufInquire(image, M_SIZE_X, SizeX)
                MbufInquire(image, M_SIZE_Y, SizeY)
                '--- Initial ---
                If Me.ComboBox_Show.Text = "H" Then
                    p = (Me.NumericUpDown_HLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
                    dis1 = Math.Abs(e.X - p)
                    p = SizeX - Me.NumericUpDown_HRight.Value
                    p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                    dis2 = Math.Abs(e.X - p)
                    If dis1 < dis2 Then
                        If dis1 < ZoomX * 0.5 + 3 Then
                            Me.m_Left = True
                        End If
                    Else
                        If dis2 < ZoomX * 0.5 + 3 Then
                            Me.m_Right = True
                        End If
                    End If
                    p = (Me.NumericUpDown_HTop.Value - 1 - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                    dis1 = Math.Abs(e.Y - p)
                    p = SizeY - Me.NumericUpDown_HBottom.Value
                    p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                    dis2 = Math.Abs(e.Y - p)
                    If dis1 < dis2 Then
                        If dis1 < ZoomY * 0.5 + 3 Then
                            Me.m_Top = True
                        End If
                    Else
                        If dis2 < ZoomY * 0.5 + 3 Then
                            Me.m_Bottom = True
                        End If
                    End If
                Else
                    p = (Me.NumericUpDown_VLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
                    dis1 = Math.Abs(e.X - p)
                    p = SizeX - Me.NumericUpDown_VRight.Value
                    p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                    dis2 = Math.Abs(e.X - p)
                    If dis1 < dis2 Then
                        If dis1 < ZoomX * 0.5 + 3 Then
                            Me.m_Left = True
                        End If
                    Else
                        If dis2 < ZoomX * 0.5 + 3 Then
                            Me.m_Right = True
                        End If
                    End If
                    p = (Me.NumericUpDown_VTop.Value - 1 - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                    dis1 = Math.Abs(e.Y - p)
                    p = SizeY - Me.NumericUpDown_VBottom.Value
                    p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                    dis2 = Math.Abs(e.Y - p)
                    If dis1 < dis2 Then
                        If dis1 < ZoomY * 0.5 + 3 Then
                            Me.m_Top = True
                        End If
                    Else
                        If dis2 < ZoomY * 0.5 + 3 Then
                            Me.m_Bottom = True
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseUpEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_Left = False
            Me.m_Right = False
            Me.m_Top = False
            Me.m_Bottom = False
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseMoveEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        Dim image As MIL_ID = M_NULL
        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked And image <> M_NULL Then
            If Me.ComboBox_Show.Text = "H" Then
                If Me.m_Left Then
                    Me.NumericUpDown_HLeft.Value = Me.m_Form.MouseX + 1
                End If
                If Me.m_Right Then
                    Me.NumericUpDown_HRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
                End If
                If Me.m_Top Then
                    Me.NumericUpDown_HTop.Value = Me.m_Form.MouseY + 1
                End If
                If Me.m_Bottom Then
                    Me.NumericUpDown_HBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
                End If
            Else
                If Me.m_Left Then
                    Me.NumericUpDown_VLeft.Value = Me.m_Form.MouseX + 1
                End If
                If Me.m_Right Then
                    Me.NumericUpDown_VRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
                End If
                If Me.m_Top Then
                    Me.NumericUpDown_VTop.Value = Me.m_Form.MouseY + 1
                End If
                If Me.m_Bottom Then
                    Me.NumericUpDown_VBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
                End If
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If
    End Sub
#End Region

#Region "--- Button Event ---"

#Region "--- Button_Load ---"
    Private Sub Button_Load_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Load.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Disable Button ---
        Me.Button_Enable(False)

        Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
        Me.m_Form.OpenFileDialog.FileName = ""
        Me.m_Form.OpenFileDialog.ShowDialog()

        If Me.m_Form.OpenFileDialog.FileName <> "" Then

            image = Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage
            '[AreaGrabber] Load Image --- (For Display)
            '[1] image ---
            MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
            MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
            MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
            If image <> M_NULL Then
                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(image)
                    image = M_NULL
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage)

            '----------------------------------------------------------------------------------------------
            ' IP Load Blob Mura Smooth Image  ==> Request_Command = "LOAD_BLOBMURA_SMOOTH" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_BLOBMURA_SMOOTH"
                TimeOut = 10000 '10 secs

                FilePath = Me.m_Form.OpenFileDialog.FileName
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, FilePath, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Blob Mura Smooth Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSmooth.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Load]Load Blob Mura Smooth Image Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_MuraSmooth.Button_Load]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            If Me.ComboBox_Select.SelectedIndex = 0 Then
                If image <> M_NULL Then
                    imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                    Type = MbufInquire(image, M_TYPE, M_NULL)

                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                        MbufFree(imageBuffer)
                        imageBuffer = M_NULL
                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                    MbufCopy(image, imageBuffer)

                    MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                    MbufControl(image, M_MODIFIED, M_DEFAULT)
                    MdispControl(Me.m_Form.AxMDisplay, M_VIEW_MODE, M_AUTO_SCALE)

                    Me.m_Form.ResetScrollBar()
                End If
            Else
                Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("���Ƽv��")
                Me.ComboBox_Select.SelectedIndex = 0
            End If

            Me.m_Form.ImageZoomAll()
        End If
    End Sub
#End Region

#Region "--- Button_Band ---"
    Private Sub Button_Band_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Band.Click
        Dim image As MIL_ID = M_NULL
        Dim RefX As Integer
        Dim RefY As Integer
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim RoundExpandWidth As Integer
        Dim strPath_HBand_White As String = ""
        Dim strPath_HBand_Black As String = ""
        Dim strPath_VBand_White As String = ""
        Dim strPath_VBand_Black As String = ""
        Dim V_MulRatio As Double
        Dim H_MulRatio As Double
        Dim MulMin As Double

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Disable Button ---
        Me.Button_Enable(False)

        '---Delete Result Image---
        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
            strPath_HBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            strPath_HBand_White = strPath_HBand_White.Replace("\\", "\")
            strPath_HBand_Black = strPath_HBand_Black.Replace("\\", "\")
            strPath_VBand_White = strPath_VBand_White.Replace("\\", "\")
            strPath_VBand_Black = strPath_VBand_Black.Replace("\\", "\")
        Else
            strPath_HBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.RepairPath_2(strPath_HBand_White)
            Me.RepairPath_2(strPath_HBand_Black)
            Me.RepairPath_2(strPath_VBand_White)
            Me.RepairPath_2(strPath_VBand_Black)
        End If
        
        If System.IO.File.Exists(strPath_HBand_White) Then
            System.IO.File.Delete(strPath_HBand_White)
        End If
        If System.IO.File.Exists(strPath_HBand_Black) Then
            System.IO.File.Delete(strPath_HBand_Black)
        End If
        If System.IO.File.Exists(strPath_VBand_White) Then
            System.IO.File.Delete(strPath_VBand_White)
        End If
        If System.IO.File.Exists(strPath_VBand_Black) Then
            System.IO.File.Delete(strPath_VBand_Black)
        End If
        '----------------------------------------------------------------------------------------------
        ' Dialog_BandMura Setting   ==> Request_Command = "DIALOG_BANDMURA_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BANDMURA_SETTING"
            TimeOut = 100000 '100 secs

            Parameter_Lists = "HTop," & Me.NumericUpDown_HTop.Value & ";" & "HBottom," & Me.NumericUpDown_HBottom.Value & ";" & "HLeft," & Me.NumericUpDown_HLeft.Value & ";" & "HRight," & Me.NumericUpDown_HRight.Value & ";" & _
                              "VTop," & Me.NumericUpDown_VTop.Value & ";" & "VBottom," & Me.NumericUpDown_VBottom.Value & ";" & "VLeft," & Me.NumericUpDown_VLeft.Value & ";" & "VRight," & Me.NumericUpDown_VRight.Value & ";" & _
                              "BandMura_ResizeCount," & Me.NumericUpDown_BandMura_ResizeCount.Value & ";" & "BandMura_SmoothCount," & Me.NumericUpDown_BandMura_SmoothCount.Value & ";" & _
                              "WhiteHBand_Threshold," & Me.NumericUpDown_WhiteHBand_Threshold.Value & ";" & "BlackHBand_Threshold," & Me.NumericUpDown_BlackHBand_Threshold.Value & ";" & "WhiteVBand_Threshold," & Me.NumericUpDown_WhiteVBand_Threshold.Value & ";" & "BlackVBand_Threshold," & Me.NumericUpDown_BlackVBand_Threshold.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BandMura Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Dialog_BandMura Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        '------�Ψ��v��-----------------------------------------------------------------------------------------------------

        '----------------------------------------------------------------------------------------------
        ' Calculate H-Band Mura ROI Image  ==> Request_Command = "CALCULATE_HROI" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_HROI"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_BandMura_ChildOriginalH.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_BandMura_ChildOriginalH.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_BandMura_ChildOriginalH <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalH, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalH, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalH)
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalH = M_NULL
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_BandMura_ChildOriginalH)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

            'If Response_OK Then
            '    '[1] Update Processed Image (Img_BandMura_ChildOriginalH) ---
            '    RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
            '    If Me.m_MuraProcess.Img_BandMura_ChildOriginalH <> M_NULL Then
            '        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalH)
            '        Me.m_MuraProcess.Img_BandMura_ChildOriginalH = M_NULL
            '    End If
            '    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.BottomY - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.TopY - 2 * RoundExpandWidth
            '    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.RightX - 2 * RoundExpandWidth

            '    'While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
            '    '    SizeX = SizeX - 1
            '    'End While

            '    'While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)
            '    '    SizeY = SizeY - 1
            '    'End While

            '    Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufChild2d(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.TopY, SizeX, SizeY, M_NULL)
            'End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate H-Band Mura ROI Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate V-Band Mura ROI Image  ==> Request_Command = "CALCULATE_VROI" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_VROI"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_BandMura_ChildOriginalV.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_BandMura_ChildOriginalV.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_BandMura_ChildOriginalV <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalV, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalV, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalV)
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalV = M_NULL
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_BandMura_ChildOriginalV)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

            'If Response_OK Then
            '    '[1] Update Processed Image (Img_BandMura_ChildOriginalV) ---
            '    RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
            '    If Me.m_MuraProcess.Img_BandMura_ChildOriginalV <> M_NULL Then
            '        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalV)
            '        Me.m_MuraProcess.Img_BandMura_ChildOriginalV = M_NULL
            '    End If

            '    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.BottomY - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.TopY - 2 * RoundExpandWidth
            '    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.RightX - 2 * RoundExpandWidth

            '    'While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
            '    '    SizeX = SizeX - 1
            '    'End While

            '    'While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
            '    '    SizeY = SizeY - 1
            '    'End While

            '    Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufChild2d(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.TopY, SizeX, SizeY, M_NULL)
            'End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate V-Band Mura ROI Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate H-Band Mura Projection Image  ==> Request_Command = "CALCULATE_HBAND_PROJECT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_HBAND_PROJECT"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HProject_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HProject_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HProject_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HProject_NonPage)
                            Me.m_MuraProcess.Img_16U_HProject_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HProject_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate H-Band Mura Projection Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate V-Band Mura Projection Image  ==> Request_Command = "CALCULATE_VBAND_PROJECT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_VBAND_PROJECT"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_VProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VProject_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VProject_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VProject_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VProject_NonPage)
                            Me.m_MuraProcess.Img_16U_VProject_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VProject_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate V-Band Mura Projection Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try


        If Me.ComboBox_Select.Items.Count = 1 Then
            Me.ComboBox_Select.Items.Add("�������R�v��")
            Me.ComboBox_Select.Items.Add("�������R�v��")
            Me.ComboBox_Select.Items.Add("������v�v��")
            Me.ComboBox_Select.Items.Add("������v�v��")
            If Me.ComboBox_Select.Items.Count >= 4 Then Me.ComboBox_Select.SelectedIndex = 4 '2009/04/27 Rick modify
        End If

        '-------�v���B�z-----------------------------------------------------------------------------------------------------

        '----------------------------------------------------------------------------------------------
        ' Calculate Golden H-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_H" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_GOLDEN_H"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden H-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HGolden_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HGolden_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HGolden_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HGolden_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HGolden_NonPage)
                            Me.m_MuraProcess.Img_16U_HGolden_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HGolden_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate Golden H-Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Golden V-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_V" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_GOLDEN_V"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden V-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_VGolden_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VGolden_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VGolden_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VGolden_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VGolden_NonPage)
                            Me.m_MuraProcess.Img_16U_VGolden_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VGolden_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate Golden V-Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        If Me.ComboBox_Select.Items.Count = 5 Then
            Me.ComboBox_Select.Items.Add("����Golden Band�v��")
            Me.ComboBox_Select.Items.Add("����Golden Band�v��")
            If Me.ComboBox_Select.Items.Count >= 6 Then Me.ComboBox_Select.SelectedIndex = 6 '2009/04/27 Rick modify
        End If

        '-------�v���B�z-----------------------------------------------------------------------------------------------------
        RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
        RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value = Me.NumericUpDown_BandMura_ResizeCount.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_SmoothCount.Value = Me.NumericUpDown_BandMura_SmoothCount.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteHBand_Threshold.Value = Me.NumericUpDown_WhiteHBand_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackHBand_Threshold.Value = Me.NumericUpDown_BlackHBand_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteVBand_Threshold.Value = Me.NumericUpDown_WhiteVBand_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackVBand_Threshold.Value = Me.NumericUpDown_BlackVBand_Threshold.Value

        '----------------------------------------------------------------------------------------------
        ' Calculate White Band Image  ==> Request_Command = "CALCULATE_WHITE_BAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_WHITE_BAND"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HBand_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HBand_White_NonPage)
                            Me.m_MuraProcess.Img_16U_HBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_16U_VBand_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VBand_White_NonPage)
                            Me.m_MuraProcess.Img_16U_VBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate White Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try


        '----------------------------------------------------------------------------------------------
        ' Calculate Black Band Image  ==> Request_Command = "CALCULATE_BLACK_BAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLACK_BAND"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
               
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)
                            Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_16U_VBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
                
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)
                            Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate Black Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate V-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_V_BAND" (Dispatcher 2)
        ' ����ƥ\��]�A�p��X Band Mura���G�A���ثe�S���qIP�Ǧ^���G�A���ݭn�Ǧ^�C
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_V_BAND"
            TimeOut = 500000 '500 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_1U_VBand_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
             
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_VBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_VBand_White_NonPage)
                            Me.m_MuraProcess.Img_1U_VBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_1U_VBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
               
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_VBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)
                            Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                'Update VValue
                Me.NumericUpDown_VValue.Value = SubSystemResult.Responses(0).Param2
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate V-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate H-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_H_BAND" (Dispatcher 2)
        ' ����ƥ\��]�A�p��X Band Mura���G�A���ثe�S���qIP�Ǧ^���G�A���ݭn�Ǧ^�C
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_H_BAND"
            TimeOut = 500000 '500 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_1U_HBand_White_NonPage) ---
                image = Me.m_MuraProcess.Img_1U_HBand_White_NonPage
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
             
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_HBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_HBand_White_NonPage)
                            Me.m_MuraProcess.Img_1U_HBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_1U_HBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
               
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_HBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)
                            Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                Me.NumericUpDown_HValue.Value = SubSystemResult.Responses(0).Param2

            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate H-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_Enable(True)
        End Try

        Me.Button_Enable(True)
        'Me.m_MuraProcess.PositionShift_MuraBand(RefX, RefY)   '�����qIP�Ǧ^���G�A����ݥ��}

        If Me.ComboBox_Select.Items.Count = 7 Then
            Me.ComboBox_Select.Items.Add("����White Band�v��")
            Me.ComboBox_Select.Items.Add("����Black Band�v��")
            Me.ComboBox_Select.Items.Add("����White Band�v��")
            Me.ComboBox_Select.Items.Add("����Black Band�v��")
            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�G-Threshold)")
            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�t-Threshold)")
            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�G-Threshold)")
            Me.ComboBox_Select.Items.Add("����Band�v���B�z(�t-Threshold)")
            If Me.ComboBox_Select.Items.Count >= 14 Then Me.ComboBox_Select.SelectedIndex = 14
        End If

        '---Modify Picturebox Location & Size
        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL)
        SizeX = SizeX - (2 * RoundExpandWidth)
        V_MulRatio = Me.m_Form.Panel_AxMDisplay.Width / SizeX
        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL)
        SizeY = SizeY - (2 * RoundExpandWidth)
        H_MulRatio = Me.m_Form.Panel_AxMDisplay.Height / SizeY
        MulMin = Math.Min(V_MulRatio, H_MulRatio)
        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL)
        SizeX = SizeX - (2 * RoundExpandWidth)
        SizeX = (SizeX - Me.NumericUpDown_VLeft.Value - Me.NumericUpDown_VRight.Value) * MulMin
        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL)
        SizeY = SizeY - (2 * RoundExpandWidth)
        SizeY = (SizeY - Me.NumericUpDown_HTop.Value - Me.NumericUpDown_HBottom.Value) * MulMin
        Me.m_Form.PictureBox_VBand_White.Left = Me.m_Form.Panel_AxMDisplay.Left + Me.NumericUpDown_VLeft.Value * MulMin
        Me.m_Form.PictureBox_VBand_White.Size = New Size(SizeX, 48)
        Me.m_Form.PictureBox_VBand_Black.Left = Me.m_Form.Panel_AxMDisplay.Left + Me.NumericUpDown_VLeft.Value * MulMin
        Me.m_Form.PictureBox_VBand_Black.Size = New Size(SizeX, 48)
        Me.m_Form.PictureBox_HBand_White.Top = Me.m_Form.Panel_AxMDisplay.Top + Me.NumericUpDown_HTop.Value * MulMin
        Me.m_Form.PictureBox_HBand_White.Size = New Size(55, SizeY)
        Me.m_Form.PictureBox_HBand_Black.Top = Me.m_Form.Panel_AxMDisplay.Top + Me.NumericUpDown_HTop.Value * MulMin
        Me.m_Form.PictureBox_HBand_Black.Size = New Size(55, SizeY)

        '---Update Result Image---
        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
            Me.m_Form.PictureBox_HBand_Black.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_HBand_White.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_Black.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_White.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.bmp"
        Else
            Me.m_Form.PictureBox_HBand_Black.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_HBand_White.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_Black.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_White.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.bmp"
        End If

        Me.CheckBox_Result.Checked=True
        Me.UpdateSelectdImage()
        If CheckBox_Show.Checked Then Me.ReDraw()

        'Me.ComboBox_Select.SelectedIndex = 1
        'Me.ComboBox_Select.SelectedIndex = 0

        '--- Disable Button ---   
        Button_Ok.Enabled = True
        Button_Cancel.Enabled = True
    End Sub
#End Region

#Region "--- Button_Ok ---"
    Private Sub Button_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Ok.Click
        Dim str As String
        Dim dir As String = ""
        Dim dirPath As String = ""
        Dim Parameter_Lists As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        Me.Button_Enable(False)

        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseBand.Value = Me.CheckBox_Band.Checked  '2015/03/23 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandUseRemoveHV.Value = Me.CheckBox_BandUseRemoveHV.Checked  '2015/03/23 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value = Me.NumericUpDown_BandMura_ResizeCount.Value   '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_SmoothCount.Value = Me.NumericUpDown_BandMura_SmoothCount.Value   '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteHBand_Threshold.Value = Me.NumericUpDown_WhiteHBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackHBand_Threshold.Value = Me.NumericUpDown_BlackHBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteVBand_Threshold.Value = Me.NumericUpDown_WhiteVBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackVBand_Threshold.Value = Me.NumericUpDown_BlackVBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.TopY = Me.NumericUpDown_HTop.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.BottomY = Me.NumericUpDown_HBottom.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX = Me.NumericUpDown_HLeft.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.RightX = Me.NumericUpDown_HRight.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.TopY = Me.NumericUpDown_VTop.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.BottomY = Me.NumericUpDown_VBottom.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX = Me.NumericUpDown_VLeft.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.RightX = Me.NumericUpDown_VRight.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.WhiteHBandTH = Me.NumericUpDown_HValue_WhiteTH.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.BlackHBandTH = Me.NumericUpDown_HValue_BlackTH.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.WhiteVBandTH = Me.NumericUpDown_VValue_WhiteTH.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HVValueRecipe.BlackVBandTH = Me.NumericUpDown_VValue_BlackTH.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.EnableBandLeakPoint.Value = Me.CheckBox_EnableBandLeakPoint.Checked
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.BandLeakPointFilterRadius.Value = Me.NumericUpDown_BandLeakPointFilterRadius.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.EnableBandVOpen.Value = Me.CheckBox_EnableBandVOpen.Checked
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.BandVOpenEdgeStrength.Value = Me.NumericUpDown_BandVOpenEdgeStrength.Value

        '----------------------------------------------------------------------------------------------
        ' Dialog_BandMura Setting   ==> Request_Command = "DIALOG_BANDMURA_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BANDMURA_SETTING"
            TimeOut = 100000 '100 secs

            Parameter_Lists = "UseBand," & Me.CheckBox_Band.Checked & ";" & "BandUseRemoveHV," & Me.CheckBox_BandUseRemoveHV.Checked & ";" & _
                              "HTop," & Me.NumericUpDown_HTop.Value & ";" & "HBottom," & Me.NumericUpDown_HBottom.Value & ";" & "HLeft," & Me.NumericUpDown_HLeft.Value & ";" & "HRight," & Me.NumericUpDown_HRight.Value & ";" & _
                              "VTop," & Me.NumericUpDown_VTop.Value & ";" & "VBottom," & Me.NumericUpDown_VBottom.Value & ";" & "VLeft," & Me.NumericUpDown_VLeft.Value & ";" & "VRight," & Me.NumericUpDown_VRight.Value & ";" & _
                              "BandMura_ResizeCount," & Me.NumericUpDown_BandMura_ResizeCount.Value & ";" & "BandMura_SmoothCount," & Me.NumericUpDown_BandMura_SmoothCount.Value & ";" & _
                              "WhiteHBand_Threshold," & Me.NumericUpDown_WhiteHBand_Threshold.Value & ";" & "BlackHBand_Threshold," & Me.NumericUpDown_BlackHBand_Threshold.Value & ";" & "WhiteVBand_Threshold," & Me.NumericUpDown_WhiteVBand_Threshold.Value & ";" & "BlackVBand_Threshold," & Me.NumericUpDown_BlackVBand_Threshold.Value & ";" & _
                              "HValue_WhiteTH," & Me.NumericUpDown_HValue_WhiteTH.Value & ";" & "HValue_BlackTH," & Me.NumericUpDown_HValue_BlackTH.Value & ";" & "VValue_WhiteTH," & Me.NumericUpDown_VValue_WhiteTH.Value & ";" & "VValue_BlackTH," & Me.NumericUpDown_VValue_BlackTH.Value & ";" & _
                              "EnableBandLeakPoint," & Me.CheckBox_EnableBandLeakPoint.Checked & ";" & "BandLeakPointFilterRadius," & Me.NumericUpDown_BandLeakPointFilterRadius.Value & ";" & "EnableBandVOpen," & Me.CheckBox_EnableBandVOpen.Checked & ";" & "BandVOpenEdgeStrength," & Me.NumericUpDown_BandVOpenEdgeStrength.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BandMura Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Ok]Dialog_BandMura Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Ok]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Setting Recipe ---

        dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        If Not Directory.Exists(dirPath) Then
            Directory.CreateDirectory(dirPath)
        End If
        str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
        Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)
        Me.m_MuraProcess.SaveMuraModelRecipe(dirPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Ok]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Ok]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Save Mura Model Recipe  ==> Request_Command = "SAVE_MURA_MODEL_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_MURA_MODEL_RECIPE"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Ok]Save Mura Model Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Ok]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

        Me.Button_Enable(True)
    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Dim IP_Address As String = ""
        Dim strPath_HBand_White As String = ""
        Dim strPath_HBand_Black As String = ""
        Dim strPath_VBand_White As String = ""
        Dim strPath_VBand_Black As String = ""

        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '---Delete Result Image---
        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
            strPath_HBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            strPath_HBand_White = strPath_HBand_White.Replace("\\", "\")
            strPath_HBand_Black = strPath_HBand_Black.Replace("\\", "\")
            strPath_VBand_White = strPath_VBand_White.Replace("\\", "\")
            strPath_VBand_Black = strPath_VBand_Black.Replace("\\", "\")
        Else
            strPath_HBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.RepairPath_2(strPath_HBand_White)
            Me.RepairPath_2(strPath_HBand_Black)
            Me.RepairPath_2(strPath_VBand_White)
            Me.RepairPath_2(strPath_VBand_Black)
        End If
        
        If System.IO.File.Exists(strPath_HBand_White) Then
            System.IO.File.Delete(strPath_HBand_White)
        End If
        If System.IO.File.Exists(strPath_HBand_Black) Then
            System.IO.File.Delete(strPath_HBand_Black)
        End If
        If System.IO.File.Exists(strPath_VBand_White) Then
            System.IO.File.Delete(strPath_VBand_White)
        End If
        If System.IO.File.Exists(strPath_VBand_Black) Then
            System.IO.File.Delete(strPath_VBand_Black)
        End If

        Me.m_Form.PictureBox_HBand_Black.Visible = False
        Me.m_Form.PictureBox_HBand_White.Visible = False
        Me.m_Form.PictureBox_VBand_Black.Visible = False
        Me.m_Form.PictureBox_VBand_White.Visible = False

        Me.Close()

    End Sub
#End Region

#Region "--- BtnPre_BlobMuraRound_Click ---"
    Private Sub BtnPre_BlobMuraRound_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub
#End Region

#Region "--- Button_AddBlockSetting_Click ---"
    Private Sub Button_AddBlockSetting_Click(sender As System.Object, e As System.EventArgs) Handles Button_AddBlockSetting.Click
        Dim mbbr As ClsMuraBandBlockRecipe
        Dim i As Integer
        If Me.ComboBox_SelectBlock.Text = "" Then
            MsgBox("�Х����V or H Block", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
            Exit Sub
        Else
            mbbr = New ClsMuraBandBlockRecipe
            mbbr.TopBoundary = Me.NumericUpDown_BlockTop.Value
            mbbr.ButtomBoundary = Me.NumericUpDown_BlockButtom.Value
            mbbr.LeftBoundary = Me.NumericUpDown_BlockLeft.Value
            mbbr.RightBoundary = Me.NumericUpDown_BlockRight.Value
            mbbr.WhiteTH = Me.NumericUpDown_BlockWhiteTH.Value
            mbbr.BlackTH = Me.NumericUpDown_BlockBlackTH.Value
            If mbbr.WhiteTH = 0 Or mbbr.BlackTH = 0 Then
                MsgBox("Threshold���i��0,�Y���˴�V or H�бN��TH�]�w��65535", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                Exit Sub
            End If
            If Me.ComboBox_SelectBlock.Text = "H" Then

                If mbbr.ButtomBoundary - mbbr.TopBoundary <= 0 Then
                    MsgBox("H Block�e�צܤ֬�1", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                    Exit Sub
                End If

                If MuraHBandBlockRecipeList.Count = 0 Then
                    MuraHBandBlockRecipeList.Add(mbbr)
                    Me.m_Form.MuraProcess.SaveMuraBandBlockRecipe(Me.HBlockRecipePath, Me.MuraHBandBlockRecipeList)
                    Me.LOAD_ALL_MURA_PATTERN_RECIPE()
                    Me.SET_PATTERNINDEX()
                    Me.ListViewReflash()
                    Exit Sub
                End If

                For i = 0 To MuraHBandBlockRecipeList.Count - 1
                    If mbbr.TopBoundary > MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i).ButtomBoundary Then
                        If i < MuraHBandBlockRecipeList.Count - 1 Then
                            If mbbr.TopBoundary <= MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).TopBoundary And ((mbbr.ButtomBoundary >= MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).ButtomBoundary) Or (mbbr.ButtomBoundary > MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).TopBoundary)) Then
                                MsgBox("H Block�d�򭫽�", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                                Exit Sub
                            Else
                                If mbbr.ButtomBoundary < MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).TopBoundary Then
                                    MuraHBandBlockRecipeList.Insert(i + 1, mbbr)
                                    Exit For
                                End If
                            End If
                        ElseIf i = MuraHBandBlockRecipeList.Count - 1 And mbbr.ButtomBoundary > MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i).TopBoundary Then
                            MuraHBandBlockRecipeList.Add(mbbr)
                            Exit For
                        Else
                            MsgBox("H Block�d�򭫽�", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                            Exit Sub
                        End If
                    Else
                        If mbbr.ButtomBoundary < MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i).TopBoundary Then
                            MuraHBandBlockRecipeList.Insert(i, mbbr)
                            Exit For
                        Else
                            MsgBox("H Block�d�򭫽�", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                            Exit Sub
                        End If
                    End If
                Next

                Me.m_Form.MuraProcess.SaveMuraBandBlockRecipe(Me.HBlockRecipePath, Me.MuraHBandBlockRecipeList)

            ElseIf Me.ComboBox_SelectBlock.Text = "V" Then

                If mbbr.RightBoundary - mbbr.LeftBoundary <= 0 Then
                    MsgBox("V Block�e�צܤ֬�1", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                    Exit Sub
                End If

                If MuraVBandBlockRecipeList.Count = 0 Then
                    MuraVBandBlockRecipeList.Add(mbbr)
                    Me.m_Form.MuraProcess.SaveMuraBandBlockRecipe(Me.VBlockRecipePath, Me.MuraVBandBlockRecipeList)
                    Me.LOAD_ALL_MURA_PATTERN_RECIPE()
                    Me.SET_PATTERNINDEX()
                    Me.ListViewReflash()
                    Exit Sub
                End If

                For i = 0 To MuraVBandBlockRecipeList.Count - 1
                    If mbbr.LeftBoundary > MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i).RightBoundary Then
                        If i < MuraVBandBlockRecipeList.Count - 1 Then
                            If mbbr.LeftBoundary <= MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).LeftBoundary And ((mbbr.RightBoundary >= MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).RightBoundary) Or (mbbr.RightBoundary > MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).LeftBoundary)) Then
                                MsgBox("V Block�d�򭫽�", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                                Exit Sub
                            Else
                                If mbbr.RightBoundary < MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i + 1).LeftBoundary Then
                                    MuraVBandBlockRecipeList.Insert(i + 1, mbbr)
                                    Exit For
                                End If
                            End If
                        ElseIf i = MuraVBandBlockRecipeList.Count - 1 And mbbr.RightBoundary > MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i).LeftBoundary Then
                            MuraVBandBlockRecipeList.Add(mbbr)
                            Exit For
                        Else
                            MsgBox("V Block�d�򭫽�", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                            Exit Sub
                        End If
                    Else
                        If mbbr.RightBoundary < MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i).LeftBoundary Then
                            MuraVBandBlockRecipeList.Insert(i, mbbr)
                            Exit For
                        Else
                            MsgBox("V Block�d�򭫽�", MsgBoxStyle.Critical, "[BlockRecipeSetting]")
                            Exit Sub
                        End If
                    End If
                Next
                Me.m_Form.MuraProcess.SaveMuraBandBlockRecipe(Me.VBlockRecipePath, Me.MuraVBandBlockRecipeList)
            End If

            Me.LOAD_ALL_MURA_PATTERN_RECIPE()
            Me.SET_PATTERNINDEX()
            Me.ListViewReflash()

            If CheckBox_ShowBlock.Checked Then
                Me.ReDrawBlock()
            End If

        End If
    End Sub
#End Region

    Private Sub Button_HBottomBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_HBottomBase.Click
        Dim RealBottom As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealBottom = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.BottomY - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.TopY - Me.NumericUpDown_HBottom.Value

        Quotient = (RealBottom - Me.NumericUpDown_HTop.Value) \ 50
        Remainder = (RealBottom - Me.NumericUpDown_HTop.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_HTop.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_HTop.Value = 1
                Else
                    Me.NumericUpDown_HTop.Value = Me.NumericUpDown_HTop.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_HTop.Value = Me.NumericUpDown_HTop.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_HTop.Value - ChangeValue < 1 Then
                Me.NumericUpDown_HTop.Value = 1
            Else
                Me.NumericUpDown_HTop.Value = Me.NumericUpDown_HTop.Value - ChangeValue
            End If
        End If
    End Sub

    Private Sub Button_HTopBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_HTopBase.Click
        Dim RealBottom As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealBottom = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.BottomY - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.TopY - Me.NumericUpDown_HBottom.Value

        Quotient = (RealBottom - Me.NumericUpDown_HTop.Value) \ 50
        Remainder = (RealBottom - Me.NumericUpDown_HTop.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_HBottom.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_HBottom.Value = 1
                Else
                    Me.NumericUpDown_HBottom.Value = Me.NumericUpDown_HBottom.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_HBottom.Value = Me.NumericUpDown_HBottom.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_HBottom.Value - ChangeValue < 1 Then
                Me.NumericUpDown_HBottom.Value = 1
            Else
                Me.NumericUpDown_HBottom.Value = Me.NumericUpDown_HBottom.Value - ChangeValue
            End If
        End If
    End Sub

    Private Sub Button_HRightBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_HRightBase.Click
        Dim RealRight As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealRight = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.RightX - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.LeftX - Me.NumericUpDown_HRight.Value

        Quotient = (RealRight - Me.NumericUpDown_HLeft.Value) \ 50
        Remainder = (RealRight - Me.NumericUpDown_HLeft.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_HLeft.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_HLeft.Value = 1
                Else
                    Me.NumericUpDown_HLeft.Value = Me.NumericUpDown_HLeft.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_HLeft.Value = Me.NumericUpDown_HLeft.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_HLeft.Value - ChangeValue < 1 Then
                Me.NumericUpDown_HLeft.Value = 1
            Else
                Me.NumericUpDown_HLeft.Value = Me.NumericUpDown_HLeft.Value - ChangeValue
            End If
        End If
    End Sub

    Private Sub Button_HLeftBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_HLeftBase.Click
        Dim RealRight As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealRight = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.RightX - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.LeftX - Me.NumericUpDown_HRight.Value

        Quotient = (RealRight - Me.NumericUpDown_HLeft.Value) \ 50
        Remainder = (RealRight - Me.NumericUpDown_HLeft.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_HRight.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_HRight.Value = 1
                Else
                    Me.NumericUpDown_HRight.Value = Me.NumericUpDown_HRight.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_HRight.Value = Me.NumericUpDown_HRight.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_HRight.Value - ChangeValue < 1 Then
                Me.NumericUpDown_HRight.Value = 1
            Else
                Me.NumericUpDown_HRight.Value = Me.NumericUpDown_HRight.Value - ChangeValue
            End If
        End If
    End Sub

    Private Sub Button_VBottomBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_VBottomBase.Click
        Dim RealBottom As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealBottom = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.BottomY - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.TopY - Me.NumericUpDown_VBottom.Value

        Quotient = (RealBottom - Me.NumericUpDown_VTop.Value) \ 50
        Remainder = (RealBottom - Me.NumericUpDown_VTop.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_VTop.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_VTop.Value = 1
                Else
                    Me.NumericUpDown_VTop.Value = Me.NumericUpDown_VTop.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_VTop.Value = Me.NumericUpDown_VTop.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_VTop.Value - ChangeValue < 1 Then
                Me.NumericUpDown_VTop.Value = 1
            Else
                Me.NumericUpDown_VTop.Value = Me.NumericUpDown_VTop.Value - ChangeValue
            End If
        End If
    End Sub

    Private Sub Button_VTopBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_VTopBase.Click
        Dim RealBottom As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealBottom = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.BottomY - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.TopY - Me.NumericUpDown_VBottom.Value

        Quotient = (RealBottom - Me.NumericUpDown_VTop.Value) \ 50
        Remainder = (RealBottom - Me.NumericUpDown_VTop.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_VBottom.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_VBottom.Value = 1
                Else
                    Me.NumericUpDown_VBottom.Value = Me.NumericUpDown_VBottom.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_VBottom.Value = Me.NumericUpDown_VBottom.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_VBottom.Value - ChangeValue < 1 Then
                Me.NumericUpDown_VBottom.Value = 1
            Else
                Me.NumericUpDown_VBottom.Value = Me.NumericUpDown_VBottom.Value - ChangeValue
            End If
        End If
    End Sub

    Private Sub Button_VRightBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_VRightBase.Click
        Dim RealRight As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealRight = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.RightX - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.LeftX - Me.NumericUpDown_VRight.Value

        Quotient = (RealRight - Me.NumericUpDown_VLeft.Value) \ 50
        Remainder = (RealRight - Me.NumericUpDown_VLeft.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_VLeft.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_VLeft.Value = 1
                Else
                    Me.NumericUpDown_VLeft.Value = Me.NumericUpDown_VLeft.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_VLeft.Value = Me.NumericUpDown_VLeft.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_VLeft.Value - ChangeValue < 1 Then
                Me.NumericUpDown_VLeft.Value = 1
            Else
                Me.NumericUpDown_VLeft.Value = Me.NumericUpDown_VLeft.Value - ChangeValue
            End If
        End If
    End Sub

    Private Sub Button_VLeftBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_VLeftBase.Click
        Dim RealRight As Integer
        Dim ChangeValue As Integer
        Dim Quotient As Integer
        Dim Remainder As Integer
        RealRight = Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.RightX - Me.m_Form.MuraProcess.MuraModelRecipe.Boundary.LeftX - Me.NumericUpDown_VRight.Value

        Quotient = (RealRight - Me.NumericUpDown_VLeft.Value) \ 50
        Remainder = (RealRight - Me.NumericUpDown_VLeft.Value) Mod 50

        If Quotient > 0 Then
            If Remainder = 0 Then
                ChangeValue = 50
                If Me.NumericUpDown_VRight.Value - ChangeValue < 1 Then
                    Me.NumericUpDown_VRight.Value = 1
                Else
                    Me.NumericUpDown_VRight.Value = Me.NumericUpDown_VRight.Value - ChangeValue
                End If
            Else
                ChangeValue = Remainder + (Quotient - 1) * 50
                Me.NumericUpDown_VRight.Value = Me.NumericUpDown_VRight.Value + ChangeValue
            End If
        Else
            ChangeValue = 50 - Remainder
            If Me.NumericUpDown_VRight.Value - ChangeValue < 1 Then
                Me.NumericUpDown_VRight.Value = 1
            Else
                Me.NumericUpDown_VRight.Value = Me.NumericUpDown_VRight.Value - ChangeValue
            End If
        End If
    End Sub

#End Region

#Region "--- UI Event ---"

    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub ZoomIn_ButtomClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.Click
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub ZoomOut_ButtomClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.Click
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub ZoomO_ButtomClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.Click
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub ZoomAll_ButtomClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.Click
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub ZoomInToolStripMenu_ButtomClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_ZoomInToolStripMenuItem.Click
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub ZoomOutToolStripMenu_ButtomClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_ZoomOutToolStripMenuItem.Click
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub
    Private Sub ZoomAllToolStripMenu_ButtomClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_ZoomAllToolStripMenuItem.Click
        If Me.CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
        If Me.CheckBox_ShowBlock.Checked Then
            Me.ReDrawBlock()
        End If
    End Sub

#End Region


#Region "--- ListView ---"

    Private Sub ListViewReflash()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mhbbr As ClsMuraBandBlockRecipe

        Me.ListView_HBlock.Items.Clear()
        For i = 0 To Me.MuraHBandBlockRecipeList.Count - 1
            mhbbr = Me.MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(i)
            lvi = Me.ListView_HBlock.Items.Add(mhbbr.LeftBoundary)
            lvi.SubItems.Add(mhbbr.TopBoundary)
            lvi.SubItems.Add(mhbbr.RightBoundary)
            lvi.SubItems.Add(mhbbr.ButtomBoundary)
            lvi.SubItems.Add(mhbbr.WhiteTH)
            lvi.SubItems.Add(mhbbr.BlackTH)
        Next

        Me.ListView_VBlock.Items.Clear()
        For i = 0 To Me.MuraVBandBlockRecipeList.Count - 1
            mhbbr = Me.MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(i)
            lvi = Me.ListView_VBlock.Items.Add(mhbbr.LeftBoundary)
            lvi.SubItems.Add(mhbbr.TopBoundary)
            lvi.SubItems.Add(mhbbr.RightBoundary)
            lvi.SubItems.Add(mhbbr.ButtomBoundary)
            lvi.SubItems.Add(mhbbr.WhiteTH)
            lvi.SubItems.Add(mhbbr.BlackTH)
        Next

    End Sub

    Private Sub ListView_HBlock_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_HBlock.Click
        Dim mbbr As ClsMuraBandBlockRecipe
        If Me.ListView_HBlock.SelectedIndices.Count > 0 Then
            mbbr = Me.MuraHBandBlockRecipeList.GetMuraBandBlcokRecipe(Me.ListView_HBlock.SelectedIndices(0))
            Me.NumericUpDown_BlockTop.Value = mbbr.TopBoundary
            Me.NumericUpDown_BlockButtom.Value = mbbr.ButtomBoundary
            Me.NumericUpDown_BlockLeft.Value = mbbr.LeftBoundary
            Me.NumericUpDown_BlockRight.Value = mbbr.RightBoundary
            Me.NumericUpDown_BlockWhiteTH.Value = mbbr.WhiteTH
            Me.NumericUpDown_BlockBlackTH.Value = mbbr.BlackTH
        End If
    End Sub

    Private Sub ListView_HBlock_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView_HBlock.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            Me.ContextMenuStrip = Me.ContextMenuStrip_BlockSetting
            DeleteH = True
            DeleteV = False
        End If
    End Sub

    Private Sub ListView_VBlock_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_VBlock.Click
        Dim mbbr As ClsMuraBandBlockRecipe
        If Me.ListView_VBlock.SelectedIndices.Count > 0 Then
            mbbr = Me.MuraVBandBlockRecipeList.GetMuraBandBlcokRecipe(Me.ListView_VBlock.SelectedIndices(0))
            Me.NumericUpDown_BlockTop.Value = mbbr.TopBoundary
            Me.NumericUpDown_BlockButtom.Value = mbbr.ButtomBoundary
            Me.NumericUpDown_BlockLeft.Value = mbbr.LeftBoundary
            Me.NumericUpDown_BlockRight.Value = mbbr.RightBoundary
            Me.NumericUpDown_BlockWhiteTH.Value = mbbr.WhiteTH
            Me.NumericUpDown_BlockBlackTH.Value = mbbr.BlackTH
        End If
    End Sub

    Private Sub ListView_VBlock_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView_VBlock.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            Me.ContextMenuStrip = Me.ContextMenuStrip_BlockSetting
            DeleteH = False
            DeleteV = True
        End If
    End Sub

#End Region

#Region "--- ContextMenuStrip ---"

#Region "ContextMenuStrip_BlockSetting"

    Private Sub ContextMenuStrip_BlockSetting_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip_BlockSetting.ItemClicked
        If e.ClickedItem Is DeleteToolStripMenuItem Then
            Me.DeleteBlockRecipe()
            Me.DeleteH = True
            Me.DeleteV = False
        End If
    End Sub

#End Region

#End Region

End Class