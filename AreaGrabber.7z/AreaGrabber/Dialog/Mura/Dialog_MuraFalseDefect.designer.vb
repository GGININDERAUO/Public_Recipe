<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraFalseDefect
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_MuraFalseDefect))
        Me.Label_Y = New System.Windows.Forms.Label()
        Me.Label_X = New System.Windows.Forms.Label()
        Me.NumericUpDown_Y = New System.Windows.Forms.NumericUpDown()
        Me.Label_Area = New System.Windows.Forms.Label()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.NumericUpDown_X = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Area = New System.Windows.Forms.NumericUpDown()
        Me.Button_AddOne = New System.Windows.Forms.Button()
        Me.ColumnHeader_NewY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label_NewPosition = New System.Windows.Forms.Label()
        Me.Label_FalsePosition = New System.Windows.Forms.Label()
        Me.ColumnHeader_X = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Label_FalseType = New System.Windows.Forms.Label()
        Me.ListView_False = New System.Windows.Forms.ListView()
        Me.ColumnHeader_CreateTime = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Area = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Y = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox_ManualAddFD = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ComboBox_False_Pattern = New System.Windows.Forms.ComboBox()
        Me.Button_ClearAll = New System.Windows.Forms.Button()
        Me.ComboBox_False_Type = New System.Windows.Forms.ComboBox()
        Me.Label_False_Type = New System.Windows.Forms.Label()
        Me.ColumnHeader_NewX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ComboBox_FalseType = New System.Windows.Forms.ComboBox()
        Me.ColumnHeader_NewArea = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ListView_New = New System.Windows.Forms.ListView()
        Me.ColumnHeader_NewCreateTime = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_NewPattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Button_FalseAdd = New System.Windows.Forms.Button()
        Me.Button_FalseRemove = New System.Windows.Forms.Button()
        Me.TabControl_FalseDefect = New System.Windows.Forms.TabControl()
        Me.TabPage_FalseDefectTable = New System.Windows.Forms.TabPage()
        Me.TabPage_FilterRegion = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ComboBox_FalseLineDirection = New System.Windows.Forms.ComboBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.NumericUpDown_FalseLineWidth = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_EnableFalseLine = New System.Windows.Forms.CheckBox()
        Me.GroupBox_AutoAddFR = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowFilterRegion = New System.Windows.Forms.CheckBox()
        Me.CheckBox_RegionMannual = New System.Windows.Forms.CheckBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.GroupBox_MannualAddFR = New System.Windows.Forms.GroupBox()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.ComboBox_FR_Pattern = New System.Windows.Forms.ComboBox()
        Me.ComboBox_FR_FilterType = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Button_AddRegion = New System.Windows.Forms.Button()
        Me.TextBox_MaxY = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox_MaxX = New System.Windows.Forms.TextBox()
        Me.lbData = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox_MinX = New System.Windows.Forms.TextBox()
        Me.TextBox_MinY = New System.Windows.Forms.TextBox()
        Me.lbGate = New System.Windows.Forms.Label()
        Me.GroupBox_FilterRegion = New System.Windows.Forms.GroupBox()
        Me.Button_FR_ClearAll = New System.Windows.Forms.Button()
        Me.Label_FRCount = New System.Windows.Forms.Label()
        Me.Button_DeleteRegion = New System.Windows.Forms.Button()
        Me.ListView_FilterRegion = New System.Windows.Forms.ListView()
        Me.Ch_LeftX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_TopY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_RightX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_BottomY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_FilterType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_UnFilterRegion = New System.Windows.Forms.TabPage()
        Me.GroupBox_AutoAddUFR = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowUnFilterRegion = New System.Windows.Forms.CheckBox()
        Me.CheckBox_UFRMannual = New System.Windows.Forms.CheckBox()
        Me.btn_UFR_Cancel = New System.Windows.Forms.Button()
        Me.btn_UFR_OK = New System.Windows.Forms.Button()
        Me.GroupBox_MannualAddUFR = New System.Windows.Forms.GroupBox()
        Me.Button_AddUFR = New System.Windows.Forms.Button()
        Me.TextBox_UFR_MaxY = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox_UFR_MaxX = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox_UFR_MinX = New System.Windows.Forms.TextBox()
        Me.TextBox_UFR_MinY = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox_UnFilterRegion = New System.Windows.Forms.GroupBox()
        Me.Label_UFRCount = New System.Windows.Forms.Label()
        Me.Button_DeleteUFR = New System.Windows.Forms.Button()
        Me.ListView_UnFilterRegion = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_AIFilterRegion = New System.Windows.Forms.TabPage()
        Me.GroupBox_CenterMuraTransfer = New System.Windows.Forms.GroupBox()
        Me.Button_CenterMuraTransfer = New System.Windows.Forms.Button()
        Me.GroupBox_AutoAddAFR = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowAIFilterRegion = New System.Windows.Forms.CheckBox()
        Me.CheckBox_AFRMannual = New System.Windows.Forms.CheckBox()
        Me.GroupBox_AIFilterRegion = New System.Windows.Forms.GroupBox()
        Me.Button_AFR_ClearAll = New System.Windows.Forms.Button()
        Me.Label_AFRCount = New System.Windows.Forms.Label()
        Me.Button_DeleteAFR = New System.Windows.Forms.Button()
        Me.ListView_AIFilterRegion = New System.Windows.Forms.ListView()
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btn_AFR_Cancel = New System.Windows.Forms.Button()
        Me.GroupBox_MannualAddAFR = New System.Windows.Forms.GroupBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ComboBox_AFR_Pattern = New System.Windows.Forms.ComboBox()
        Me.ComboBox_AFR_FilterType = New System.Windows.Forms.ComboBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Button_AddAFR = New System.Windows.Forms.Button()
        Me.TextBox_AFR_MaxY = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox_AFR_MaxX = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox_AFR_MinX = New System.Windows.Forms.TextBox()
        Me.TextBox_AFR_MinY = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btn_AFR_OK = New System.Windows.Forms.Button()
        CType(Me.NumericUpDown_Y, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Area, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ManualAddFD.SuspendLayout()
        Me.TabControl_FalseDefect.SuspendLayout()
        Me.TabPage_FalseDefectTable.SuspendLayout()
        Me.TabPage_FilterRegion.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NumericUpDown_FalseLineWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_AutoAddFR.SuspendLayout()
        Me.GroupBox_MannualAddFR.SuspendLayout()
        Me.GroupBox_FilterRegion.SuspendLayout()
        Me.TabPage_UnFilterRegion.SuspendLayout()
        Me.GroupBox_AutoAddUFR.SuspendLayout()
        Me.GroupBox_MannualAddUFR.SuspendLayout()
        Me.GroupBox_UnFilterRegion.SuspendLayout()
        Me.TabPage_AIFilterRegion.SuspendLayout()
        Me.GroupBox_CenterMuraTransfer.SuspendLayout()
        Me.GroupBox_AutoAddAFR.SuspendLayout()
        Me.GroupBox_AIFilterRegion.SuspendLayout()
        Me.GroupBox_MannualAddAFR.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label_Y
        '
        resources.ApplyResources(Me.Label_Y, "Label_Y")
        Me.Label_Y.Name = "Label_Y"
        '
        'Label_X
        '
        resources.ApplyResources(Me.Label_X, "Label_X")
        Me.Label_X.Name = "Label_X"
        '
        'NumericUpDown_Y
        '
        resources.ApplyResources(Me.NumericUpDown_Y, "NumericUpDown_Y")
        Me.NumericUpDown_Y.DecimalPlaces = 2
        Me.NumericUpDown_Y.Maximum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.NumericUpDown_Y.Name = "NumericUpDown_Y"
        '
        'Label_Area
        '
        resources.ApplyResources(Me.Label_Area, "Label_Area")
        Me.Label_Area.Name = "Label_Area"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        '
        'NumericUpDown_X
        '
        resources.ApplyResources(Me.NumericUpDown_X, "NumericUpDown_X")
        Me.NumericUpDown_X.DecimalPlaces = 2
        Me.NumericUpDown_X.Maximum = New Decimal(New Integer() {2900, 0, 0, 0})
        Me.NumericUpDown_X.Name = "NumericUpDown_X"
        '
        'NumericUpDown_Area
        '
        resources.ApplyResources(Me.NumericUpDown_Area, "NumericUpDown_Area")
        Me.NumericUpDown_Area.DecimalPlaces = 2
        Me.NumericUpDown_Area.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_Area.Name = "NumericUpDown_Area"
        '
        'Button_AddOne
        '
        resources.ApplyResources(Me.Button_AddOne, "Button_AddOne")
        Me.Button_AddOne.Name = "Button_AddOne"
        '
        'ColumnHeader_NewY
        '
        resources.ApplyResources(Me.ColumnHeader_NewY, "ColumnHeader_NewY")
        '
        'Label_NewPosition
        '
        resources.ApplyResources(Me.Label_NewPosition, "Label_NewPosition")
        Me.Label_NewPosition.Name = "Label_NewPosition"
        '
        'Label_FalsePosition
        '
        resources.ApplyResources(Me.Label_FalsePosition, "Label_FalsePosition")
        Me.Label_FalsePosition.Name = "Label_FalsePosition"
        '
        'ColumnHeader_X
        '
        resources.ApplyResources(Me.ColumnHeader_X, "ColumnHeader_X")
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        '
        'Label_FalseType
        '
        resources.ApplyResources(Me.Label_FalseType, "Label_FalseType")
        Me.Label_FalseType.Name = "Label_FalseType"
        '
        'ListView_False
        '
        resources.ApplyResources(Me.ListView_False, "ListView_False")
        Me.ListView_False.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_CreateTime, Me.ColumnHeader_Area, Me.ColumnHeader_X, Me.ColumnHeader_Y, Me.ColumnHeader_Pattern})
        Me.ListView_False.FullRowSelect = True
        Me.ListView_False.GridLines = True
        Me.ListView_False.HideSelection = False
        Me.ListView_False.Name = "ListView_False"
        Me.ListView_False.UseCompatibleStateImageBehavior = False
        Me.ListView_False.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_CreateTime
        '
        resources.ApplyResources(Me.ColumnHeader_CreateTime, "ColumnHeader_CreateTime")
        '
        'ColumnHeader_Area
        '
        resources.ApplyResources(Me.ColumnHeader_Area, "ColumnHeader_Area")
        '
        'ColumnHeader_Y
        '
        resources.ApplyResources(Me.ColumnHeader_Y, "ColumnHeader_Y")
        '
        'ColumnHeader_Pattern
        '
        resources.ApplyResources(Me.ColumnHeader_Pattern, "ColumnHeader_Pattern")
        '
        'GroupBox_ManualAddFD
        '
        resources.ApplyResources(Me.GroupBox_ManualAddFD, "GroupBox_ManualAddFD")
        Me.GroupBox_ManualAddFD.Controls.Add(Me.Label8)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.ComboBox_False_Pattern)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.Button_ClearAll)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.ComboBox_False_Type)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.Label_False_Type)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.Label_Y)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.Label_X)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.Label_Area)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.NumericUpDown_Y)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.NumericUpDown_X)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.NumericUpDown_Area)
        Me.GroupBox_ManualAddFD.Controls.Add(Me.Button_AddOne)
        Me.GroupBox_ManualAddFD.Name = "GroupBox_ManualAddFD"
        Me.GroupBox_ManualAddFD.TabStop = False
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'ComboBox_False_Pattern
        '
        resources.ApplyResources(Me.ComboBox_False_Pattern, "ComboBox_False_Pattern")
        Me.ComboBox_False_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_False_Pattern.Name = "ComboBox_False_Pattern"
        '
        'Button_ClearAll
        '
        resources.ApplyResources(Me.Button_ClearAll, "Button_ClearAll")
        Me.Button_ClearAll.Name = "Button_ClearAll"
        Me.Button_ClearAll.UseVisualStyleBackColor = True
        '
        'ComboBox_False_Type
        '
        resources.ApplyResources(Me.ComboBox_False_Type, "ComboBox_False_Type")
        Me.ComboBox_False_Type.FormattingEnabled = True
        Me.ComboBox_False_Type.Items.AddRange(New Object() {resources.GetString("ComboBox_False_Type.Items"), resources.GetString("ComboBox_False_Type.Items1")})
        Me.ComboBox_False_Type.Name = "ComboBox_False_Type"
        '
        'Label_False_Type
        '
        resources.ApplyResources(Me.Label_False_Type, "Label_False_Type")
        Me.Label_False_Type.Name = "Label_False_Type"
        '
        'ColumnHeader_NewX
        '
        resources.ApplyResources(Me.ColumnHeader_NewX, "ColumnHeader_NewX")
        '
        'ComboBox_FalseType
        '
        resources.ApplyResources(Me.ComboBox_FalseType, "ComboBox_FalseType")
        Me.ComboBox_FalseType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FalseType.Items.AddRange(New Object() {resources.GetString("ComboBox_FalseType.Items"), resources.GetString("ComboBox_FalseType.Items1"), resources.GetString("ComboBox_FalseType.Items2"), resources.GetString("ComboBox_FalseType.Items3"), resources.GetString("ComboBox_FalseType.Items4"), resources.GetString("ComboBox_FalseType.Items5"), resources.GetString("ComboBox_FalseType.Items6"), resources.GetString("ComboBox_FalseType.Items7"), resources.GetString("ComboBox_FalseType.Items8"), resources.GetString("ComboBox_FalseType.Items9"), resources.GetString("ComboBox_FalseType.Items10"), resources.GetString("ComboBox_FalseType.Items11"), resources.GetString("ComboBox_FalseType.Items12"), resources.GetString("ComboBox_FalseType.Items13")})
        Me.ComboBox_FalseType.Name = "ComboBox_FalseType"
        '
        'ColumnHeader_NewArea
        '
        resources.ApplyResources(Me.ColumnHeader_NewArea, "ColumnHeader_NewArea")
        '
        'ListView_New
        '
        resources.ApplyResources(Me.ListView_New, "ListView_New")
        Me.ListView_New.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_NewCreateTime, Me.ColumnHeader_NewArea, Me.ColumnHeader_NewX, Me.ColumnHeader_NewY, Me.ColumnHeader_NewPattern})
        Me.ListView_New.FullRowSelect = True
        Me.ListView_New.GridLines = True
        Me.ListView_New.HideSelection = False
        Me.ListView_New.Name = "ListView_New"
        Me.ListView_New.UseCompatibleStateImageBehavior = False
        Me.ListView_New.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_NewCreateTime
        '
        resources.ApplyResources(Me.ColumnHeader_NewCreateTime, "ColumnHeader_NewCreateTime")
        '
        'ColumnHeader_NewPattern
        '
        resources.ApplyResources(Me.ColumnHeader_NewPattern, "ColumnHeader_NewPattern")
        '
        'Button_FalseAdd
        '
        resources.ApplyResources(Me.Button_FalseAdd, "Button_FalseAdd")
        Me.Button_FalseAdd.Name = "Button_FalseAdd"
        '
        'Button_FalseRemove
        '
        resources.ApplyResources(Me.Button_FalseRemove, "Button_FalseRemove")
        Me.Button_FalseRemove.Name = "Button_FalseRemove"
        '
        'TabControl_FalseDefect
        '
        resources.ApplyResources(Me.TabControl_FalseDefect, "TabControl_FalseDefect")
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_FalseDefectTable)
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_FilterRegion)
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_UnFilterRegion)
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_AIFilterRegion)
        Me.TabControl_FalseDefect.Name = "TabControl_FalseDefect"
        Me.TabControl_FalseDefect.SelectedIndex = 0
        '
        'TabPage_FalseDefectTable
        '
        resources.ApplyResources(Me.TabPage_FalseDefectTable, "TabPage_FalseDefectTable")
        Me.TabPage_FalseDefectTable.Controls.Add(Me.ListView_False)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Button_Save)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Button_FalseRemove)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Button_FalseAdd)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Label_NewPosition)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.ListView_New)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Label_FalsePosition)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.GroupBox_ManualAddFD)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Button_Cancel)
        Me.TabPage_FalseDefectTable.Name = "TabPage_FalseDefectTable"
        Me.TabPage_FalseDefectTable.UseVisualStyleBackColor = True
        '
        'TabPage_FilterRegion
        '
        resources.ApplyResources(Me.TabPage_FilterRegion, "TabPage_FilterRegion")
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox1)
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox_AutoAddFR)
        Me.TabPage_FilterRegion.Controls.Add(Me.btnCancel)
        Me.TabPage_FilterRegion.Controls.Add(Me.btnOK)
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox_MannualAddFR)
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox_FilterRegion)
        Me.TabPage_FilterRegion.Name = "TabPage_FilterRegion"
        Me.TabPage_FilterRegion.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.ComboBox_FalseLineDirection)
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_FalseLineWidth)
        Me.GroupBox1.Controls.Add(Me.CheckBox_EnableFalseLine)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'ComboBox_FalseLineDirection
        '
        resources.ApplyResources(Me.ComboBox_FalseLineDirection, "ComboBox_FalseLineDirection")
        Me.ComboBox_FalseLineDirection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FalseLineDirection.FormattingEnabled = True
        Me.ComboBox_FalseLineDirection.Items.AddRange(New Object() {resources.GetString("ComboBox_FalseLineDirection.Items"), resources.GetString("ComboBox_FalseLineDirection.Items1")})
        Me.ComboBox_FalseLineDirection.Name = "ComboBox_FalseLineDirection"
        '
        'Label36
        '
        resources.ApplyResources(Me.Label36, "Label36")
        Me.Label36.Name = "Label36"
        '
        'NumericUpDown_FalseLineWidth
        '
        resources.ApplyResources(Me.NumericUpDown_FalseLineWidth, "NumericUpDown_FalseLineWidth")
        Me.NumericUpDown_FalseLineWidth.Increment = New Decimal(New Integer() {2, 0, 0, 0})
        Me.NumericUpDown_FalseLineWidth.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_FalseLineWidth.Minimum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.NumericUpDown_FalseLineWidth.Name = "NumericUpDown_FalseLineWidth"
        Me.NumericUpDown_FalseLineWidth.Value = New Decimal(New Integer() {6, 0, 0, 0})
        '
        'CheckBox_EnableFalseLine
        '
        resources.ApplyResources(Me.CheckBox_EnableFalseLine, "CheckBox_EnableFalseLine")
        Me.CheckBox_EnableFalseLine.Name = "CheckBox_EnableFalseLine"
        Me.CheckBox_EnableFalseLine.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoAddFR
        '
        resources.ApplyResources(Me.GroupBox_AutoAddFR, "GroupBox_AutoAddFR")
        Me.GroupBox_AutoAddFR.Controls.Add(Me.CheckBox_ShowFilterRegion)
        Me.GroupBox_AutoAddFR.Controls.Add(Me.CheckBox_RegionMannual)
        Me.GroupBox_AutoAddFR.Name = "GroupBox_AutoAddFR"
        Me.GroupBox_AutoAddFR.TabStop = False
        '
        'CheckBox_ShowFilterRegion
        '
        resources.ApplyResources(Me.CheckBox_ShowFilterRegion, "CheckBox_ShowFilterRegion")
        Me.CheckBox_ShowFilterRegion.Name = "CheckBox_ShowFilterRegion"
        Me.CheckBox_ShowFilterRegion.UseVisualStyleBackColor = True
        '
        'CheckBox_RegionMannual
        '
        resources.ApplyResources(Me.CheckBox_RegionMannual, "CheckBox_RegionMannual")
        Me.CheckBox_RegionMannual.Name = "CheckBox_RegionMannual"
        Me.CheckBox_RegionMannual.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        resources.ApplyResources(Me.btnCancel, "btnCancel")
        Me.btnCancel.Name = "btnCancel"
        '
        'btnOK
        '
        resources.ApplyResources(Me.btnOK, "btnOK")
        Me.btnOK.Name = "btnOK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'GroupBox_MannualAddFR
        '
        resources.ApplyResources(Me.GroupBox_MannualAddFR, "GroupBox_MannualAddFR")
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Label_Pattern)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.ComboBox_FR_Pattern)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.ComboBox_FR_FilterType)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Label7)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Button_AddRegion)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MaxY)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Label1)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MaxX)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.lbData)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Label2)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MinX)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MinY)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.lbGate)
        Me.GroupBox_MannualAddFR.Name = "GroupBox_MannualAddFR"
        Me.GroupBox_MannualAddFR.TabStop = False
        '
        'Label_Pattern
        '
        resources.ApplyResources(Me.Label_Pattern, "Label_Pattern")
        Me.Label_Pattern.Name = "Label_Pattern"
        '
        'ComboBox_FR_Pattern
        '
        resources.ApplyResources(Me.ComboBox_FR_Pattern, "ComboBox_FR_Pattern")
        Me.ComboBox_FR_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FR_Pattern.Name = "ComboBox_FR_Pattern"
        '
        'ComboBox_FR_FilterType
        '
        resources.ApplyResources(Me.ComboBox_FR_FilterType, "ComboBox_FR_FilterType")
        Me.ComboBox_FR_FilterType.FormattingEnabled = True
        Me.ComboBox_FR_FilterType.Items.AddRange(New Object() {resources.GetString("ComboBox_FR_FilterType.Items"), resources.GetString("ComboBox_FR_FilterType.Items1"), resources.GetString("ComboBox_FR_FilterType.Items2")})
        Me.ComboBox_FR_FilterType.Name = "ComboBox_FR_FilterType"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'Button_AddRegion
        '
        resources.ApplyResources(Me.Button_AddRegion, "Button_AddRegion")
        Me.Button_AddRegion.Name = "Button_AddRegion"
        Me.Button_AddRegion.UseVisualStyleBackColor = True
        '
        'TextBox_MaxY
        '
        resources.ApplyResources(Me.TextBox_MaxY, "TextBox_MaxY")
        Me.TextBox_MaxY.Name = "TextBox_MaxY"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'TextBox_MaxX
        '
        resources.ApplyResources(Me.TextBox_MaxX, "TextBox_MaxX")
        Me.TextBox_MaxX.Name = "TextBox_MaxX"
        '
        'lbData
        '
        resources.ApplyResources(Me.lbData, "lbData")
        Me.lbData.Name = "lbData"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'TextBox_MinX
        '
        resources.ApplyResources(Me.TextBox_MinX, "TextBox_MinX")
        Me.TextBox_MinX.Name = "TextBox_MinX"
        '
        'TextBox_MinY
        '
        resources.ApplyResources(Me.TextBox_MinY, "TextBox_MinY")
        Me.TextBox_MinY.Name = "TextBox_MinY"
        '
        'lbGate
        '
        resources.ApplyResources(Me.lbGate, "lbGate")
        Me.lbGate.Name = "lbGate"
        '
        'GroupBox_FilterRegion
        '
        resources.ApplyResources(Me.GroupBox_FilterRegion, "GroupBox_FilterRegion")
        Me.GroupBox_FilterRegion.Controls.Add(Me.Button_FR_ClearAll)
        Me.GroupBox_FilterRegion.Controls.Add(Me.Label_FRCount)
        Me.GroupBox_FilterRegion.Controls.Add(Me.Button_DeleteRegion)
        Me.GroupBox_FilterRegion.Controls.Add(Me.ListView_FilterRegion)
        Me.GroupBox_FilterRegion.Name = "GroupBox_FilterRegion"
        Me.GroupBox_FilterRegion.TabStop = False
        '
        'Button_FR_ClearAll
        '
        resources.ApplyResources(Me.Button_FR_ClearAll, "Button_FR_ClearAll")
        Me.Button_FR_ClearAll.Name = "Button_FR_ClearAll"
        Me.Button_FR_ClearAll.UseVisualStyleBackColor = True
        '
        'Label_FRCount
        '
        resources.ApplyResources(Me.Label_FRCount, "Label_FRCount")
        Me.Label_FRCount.Name = "Label_FRCount"
        '
        'Button_DeleteRegion
        '
        resources.ApplyResources(Me.Button_DeleteRegion, "Button_DeleteRegion")
        Me.Button_DeleteRegion.Name = "Button_DeleteRegion"
        Me.Button_DeleteRegion.UseVisualStyleBackColor = True
        '
        'ListView_FilterRegion
        '
        resources.ApplyResources(Me.ListView_FilterRegion, "ListView_FilterRegion")
        Me.ListView_FilterRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Ch_LeftX, Me.Ch_TopY, Me.Ch_RightX, Me.Ch_BottomY, Me.Ch_FilterType, Me.Ch_Pattern})
        Me.ListView_FilterRegion.FullRowSelect = True
        Me.ListView_FilterRegion.GridLines = True
        Me.ListView_FilterRegion.Name = "ListView_FilterRegion"
        Me.ListView_FilterRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_FilterRegion.View = System.Windows.Forms.View.Details
        '
        'Ch_LeftX
        '
        resources.ApplyResources(Me.Ch_LeftX, "Ch_LeftX")
        '
        'Ch_TopY
        '
        resources.ApplyResources(Me.Ch_TopY, "Ch_TopY")
        '
        'Ch_RightX
        '
        resources.ApplyResources(Me.Ch_RightX, "Ch_RightX")
        '
        'Ch_BottomY
        '
        resources.ApplyResources(Me.Ch_BottomY, "Ch_BottomY")
        '
        'Ch_FilterType
        '
        resources.ApplyResources(Me.Ch_FilterType, "Ch_FilterType")
        '
        'Ch_Pattern
        '
        resources.ApplyResources(Me.Ch_Pattern, "Ch_Pattern")
        '
        'TabPage_UnFilterRegion
        '
        resources.ApplyResources(Me.TabPage_UnFilterRegion, "TabPage_UnFilterRegion")
        Me.TabPage_UnFilterRegion.Controls.Add(Me.GroupBox_AutoAddUFR)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.btn_UFR_Cancel)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.btn_UFR_OK)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.GroupBox_MannualAddUFR)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.GroupBox_UnFilterRegion)
        Me.TabPage_UnFilterRegion.Name = "TabPage_UnFilterRegion"
        Me.TabPage_UnFilterRegion.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoAddUFR
        '
        resources.ApplyResources(Me.GroupBox_AutoAddUFR, "GroupBox_AutoAddUFR")
        Me.GroupBox_AutoAddUFR.Controls.Add(Me.CheckBox_ShowUnFilterRegion)
        Me.GroupBox_AutoAddUFR.Controls.Add(Me.CheckBox_UFRMannual)
        Me.GroupBox_AutoAddUFR.Name = "GroupBox_AutoAddUFR"
        Me.GroupBox_AutoAddUFR.TabStop = False
        '
        'CheckBox_ShowUnFilterRegion
        '
        resources.ApplyResources(Me.CheckBox_ShowUnFilterRegion, "CheckBox_ShowUnFilterRegion")
        Me.CheckBox_ShowUnFilterRegion.Name = "CheckBox_ShowUnFilterRegion"
        Me.CheckBox_ShowUnFilterRegion.UseVisualStyleBackColor = True
        '
        'CheckBox_UFRMannual
        '
        resources.ApplyResources(Me.CheckBox_UFRMannual, "CheckBox_UFRMannual")
        Me.CheckBox_UFRMannual.Name = "CheckBox_UFRMannual"
        Me.CheckBox_UFRMannual.UseVisualStyleBackColor = True
        '
        'btn_UFR_Cancel
        '
        resources.ApplyResources(Me.btn_UFR_Cancel, "btn_UFR_Cancel")
        Me.btn_UFR_Cancel.Name = "btn_UFR_Cancel"
        '
        'btn_UFR_OK
        '
        resources.ApplyResources(Me.btn_UFR_OK, "btn_UFR_OK")
        Me.btn_UFR_OK.Name = "btn_UFR_OK"
        Me.btn_UFR_OK.UseVisualStyleBackColor = True
        '
        'GroupBox_MannualAddUFR
        '
        resources.ApplyResources(Me.GroupBox_MannualAddUFR, "GroupBox_MannualAddUFR")
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Button_AddUFR)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MaxY)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label3)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MaxX)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label4)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label5)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MinX)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MinY)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label6)
        Me.GroupBox_MannualAddUFR.Name = "GroupBox_MannualAddUFR"
        Me.GroupBox_MannualAddUFR.TabStop = False
        '
        'Button_AddUFR
        '
        resources.ApplyResources(Me.Button_AddUFR, "Button_AddUFR")
        Me.Button_AddUFR.Name = "Button_AddUFR"
        Me.Button_AddUFR.UseVisualStyleBackColor = True
        '
        'TextBox_UFR_MaxY
        '
        resources.ApplyResources(Me.TextBox_UFR_MaxY, "TextBox_UFR_MaxY")
        Me.TextBox_UFR_MaxY.Name = "TextBox_UFR_MaxY"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'TextBox_UFR_MaxX
        '
        resources.ApplyResources(Me.TextBox_UFR_MaxX, "TextBox_UFR_MaxX")
        Me.TextBox_UFR_MaxX.Name = "TextBox_UFR_MaxX"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'TextBox_UFR_MinX
        '
        resources.ApplyResources(Me.TextBox_UFR_MinX, "TextBox_UFR_MinX")
        Me.TextBox_UFR_MinX.Name = "TextBox_UFR_MinX"
        '
        'TextBox_UFR_MinY
        '
        resources.ApplyResources(Me.TextBox_UFR_MinY, "TextBox_UFR_MinY")
        Me.TextBox_UFR_MinY.Name = "TextBox_UFR_MinY"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'GroupBox_UnFilterRegion
        '
        resources.ApplyResources(Me.GroupBox_UnFilterRegion, "GroupBox_UnFilterRegion")
        Me.GroupBox_UnFilterRegion.Controls.Add(Me.Label_UFRCount)
        Me.GroupBox_UnFilterRegion.Controls.Add(Me.Button_DeleteUFR)
        Me.GroupBox_UnFilterRegion.Controls.Add(Me.ListView_UnFilterRegion)
        Me.GroupBox_UnFilterRegion.Name = "GroupBox_UnFilterRegion"
        Me.GroupBox_UnFilterRegion.TabStop = False
        '
        'Label_UFRCount
        '
        resources.ApplyResources(Me.Label_UFRCount, "Label_UFRCount")
        Me.Label_UFRCount.Name = "Label_UFRCount"
        '
        'Button_DeleteUFR
        '
        resources.ApplyResources(Me.Button_DeleteUFR, "Button_DeleteUFR")
        Me.Button_DeleteUFR.Name = "Button_DeleteUFR"
        Me.Button_DeleteUFR.UseVisualStyleBackColor = True
        '
        'ListView_UnFilterRegion
        '
        resources.ApplyResources(Me.ListView_UnFilterRegion, "ListView_UnFilterRegion")
        Me.ListView_UnFilterRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4})
        Me.ListView_UnFilterRegion.FullRowSelect = True
        Me.ListView_UnFilterRegion.GridLines = True
        Me.ListView_UnFilterRegion.Name = "ListView_UnFilterRegion"
        Me.ListView_UnFilterRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_UnFilterRegion.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        resources.ApplyResources(Me.ColumnHeader1, "ColumnHeader1")
        '
        'ColumnHeader2
        '
        resources.ApplyResources(Me.ColumnHeader2, "ColumnHeader2")
        '
        'ColumnHeader3
        '
        resources.ApplyResources(Me.ColumnHeader3, "ColumnHeader3")
        '
        'ColumnHeader4
        '
        resources.ApplyResources(Me.ColumnHeader4, "ColumnHeader4")
        '
        'TabPage_AIFilterRegion
        '
        resources.ApplyResources(Me.TabPage_AIFilterRegion, "TabPage_AIFilterRegion")
        Me.TabPage_AIFilterRegion.Controls.Add(Me.GroupBox_CenterMuraTransfer)
        Me.TabPage_AIFilterRegion.Controls.Add(Me.GroupBox_AutoAddAFR)
        Me.TabPage_AIFilterRegion.Controls.Add(Me.GroupBox_AIFilterRegion)
        Me.TabPage_AIFilterRegion.Controls.Add(Me.btn_AFR_Cancel)
        Me.TabPage_AIFilterRegion.Controls.Add(Me.GroupBox_MannualAddAFR)
        Me.TabPage_AIFilterRegion.Controls.Add(Me.btn_AFR_OK)
        Me.TabPage_AIFilterRegion.Name = "TabPage_AIFilterRegion"
        Me.TabPage_AIFilterRegion.UseVisualStyleBackColor = True
        '
        'GroupBox_CenterMuraTransfer
        '
        resources.ApplyResources(Me.GroupBox_CenterMuraTransfer, "GroupBox_CenterMuraTransfer")
        Me.GroupBox_CenterMuraTransfer.Controls.Add(Me.Button_CenterMuraTransfer)
        Me.GroupBox_CenterMuraTransfer.Name = "GroupBox_CenterMuraTransfer"
        Me.GroupBox_CenterMuraTransfer.TabStop = False
        '
        'Button_CenterMuraTransfer
        '
        resources.ApplyResources(Me.Button_CenterMuraTransfer, "Button_CenterMuraTransfer")
        Me.Button_CenterMuraTransfer.Name = "Button_CenterMuraTransfer"
        Me.Button_CenterMuraTransfer.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoAddAFR
        '
        resources.ApplyResources(Me.GroupBox_AutoAddAFR, "GroupBox_AutoAddAFR")
        Me.GroupBox_AutoAddAFR.Controls.Add(Me.CheckBox_ShowAIFilterRegion)
        Me.GroupBox_AutoAddAFR.Controls.Add(Me.CheckBox_AFRMannual)
        Me.GroupBox_AutoAddAFR.Name = "GroupBox_AutoAddAFR"
        Me.GroupBox_AutoAddAFR.TabStop = False
        '
        'CheckBox_ShowAIFilterRegion
        '
        resources.ApplyResources(Me.CheckBox_ShowAIFilterRegion, "CheckBox_ShowAIFilterRegion")
        Me.CheckBox_ShowAIFilterRegion.Name = "CheckBox_ShowAIFilterRegion"
        Me.CheckBox_ShowAIFilterRegion.UseVisualStyleBackColor = True
        '
        'CheckBox_AFRMannual
        '
        resources.ApplyResources(Me.CheckBox_AFRMannual, "CheckBox_AFRMannual")
        Me.CheckBox_AFRMannual.Name = "CheckBox_AFRMannual"
        Me.CheckBox_AFRMannual.UseVisualStyleBackColor = True
        '
        'GroupBox_AIFilterRegion
        '
        resources.ApplyResources(Me.GroupBox_AIFilterRegion, "GroupBox_AIFilterRegion")
        Me.GroupBox_AIFilterRegion.Controls.Add(Me.Button_AFR_ClearAll)
        Me.GroupBox_AIFilterRegion.Controls.Add(Me.Label_AFRCount)
        Me.GroupBox_AIFilterRegion.Controls.Add(Me.Button_DeleteAFR)
        Me.GroupBox_AIFilterRegion.Controls.Add(Me.ListView_AIFilterRegion)
        Me.GroupBox_AIFilterRegion.Name = "GroupBox_AIFilterRegion"
        Me.GroupBox_AIFilterRegion.TabStop = False
        '
        'Button_AFR_ClearAll
        '
        resources.ApplyResources(Me.Button_AFR_ClearAll, "Button_AFR_ClearAll")
        Me.Button_AFR_ClearAll.Name = "Button_AFR_ClearAll"
        Me.Button_AFR_ClearAll.UseVisualStyleBackColor = True
        '
        'Label_AFRCount
        '
        resources.ApplyResources(Me.Label_AFRCount, "Label_AFRCount")
        Me.Label_AFRCount.Name = "Label_AFRCount"
        '
        'Button_DeleteAFR
        '
        resources.ApplyResources(Me.Button_DeleteAFR, "Button_DeleteAFR")
        Me.Button_DeleteAFR.Name = "Button_DeleteAFR"
        Me.Button_DeleteAFR.UseVisualStyleBackColor = True
        '
        'ListView_AIFilterRegion
        '
        resources.ApplyResources(Me.ListView_AIFilterRegion, "ListView_AIFilterRegion")
        Me.ListView_AIFilterRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10})
        Me.ListView_AIFilterRegion.FullRowSelect = True
        Me.ListView_AIFilterRegion.GridLines = True
        Me.ListView_AIFilterRegion.Name = "ListView_AIFilterRegion"
        Me.ListView_AIFilterRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_AIFilterRegion.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader5
        '
        resources.ApplyResources(Me.ColumnHeader5, "ColumnHeader5")
        '
        'ColumnHeader6
        '
        resources.ApplyResources(Me.ColumnHeader6, "ColumnHeader6")
        '
        'ColumnHeader7
        '
        resources.ApplyResources(Me.ColumnHeader7, "ColumnHeader7")
        '
        'ColumnHeader8
        '
        resources.ApplyResources(Me.ColumnHeader8, "ColumnHeader8")
        '
        'ColumnHeader9
        '
        resources.ApplyResources(Me.ColumnHeader9, "ColumnHeader9")
        '
        'ColumnHeader10
        '
        resources.ApplyResources(Me.ColumnHeader10, "ColumnHeader10")
        '
        'btn_AFR_Cancel
        '
        resources.ApplyResources(Me.btn_AFR_Cancel, "btn_AFR_Cancel")
        Me.btn_AFR_Cancel.Name = "btn_AFR_Cancel"
        '
        'GroupBox_MannualAddAFR
        '
        resources.ApplyResources(Me.GroupBox_MannualAddAFR, "GroupBox_MannualAddAFR")
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.Label9)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.ComboBox_AFR_Pattern)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.ComboBox_AFR_FilterType)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.Label10)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.Button_AddAFR)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.TextBox_AFR_MaxY)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.Label11)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.TextBox_AFR_MaxX)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.Label12)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.Label13)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.TextBox_AFR_MinX)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.TextBox_AFR_MinY)
        Me.GroupBox_MannualAddAFR.Controls.Add(Me.Label14)
        Me.GroupBox_MannualAddAFR.Name = "GroupBox_MannualAddAFR"
        Me.GroupBox_MannualAddAFR.TabStop = False
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'ComboBox_AFR_Pattern
        '
        resources.ApplyResources(Me.ComboBox_AFR_Pattern, "ComboBox_AFR_Pattern")
        Me.ComboBox_AFR_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_AFR_Pattern.Name = "ComboBox_AFR_Pattern"
        '
        'ComboBox_AFR_FilterType
        '
        resources.ApplyResources(Me.ComboBox_AFR_FilterType, "ComboBox_AFR_FilterType")
        Me.ComboBox_AFR_FilterType.FormattingEnabled = True
        Me.ComboBox_AFR_FilterType.Items.AddRange(New Object() {resources.GetString("ComboBox_AFR_FilterType.Items"), resources.GetString("ComboBox_AFR_FilterType.Items1"), resources.GetString("ComboBox_AFR_FilterType.Items2")})
        Me.ComboBox_AFR_FilterType.Name = "ComboBox_AFR_FilterType"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'Button_AddAFR
        '
        resources.ApplyResources(Me.Button_AddAFR, "Button_AddAFR")
        Me.Button_AddAFR.Name = "Button_AddAFR"
        Me.Button_AddAFR.UseVisualStyleBackColor = True
        '
        'TextBox_AFR_MaxY
        '
        resources.ApplyResources(Me.TextBox_AFR_MaxY, "TextBox_AFR_MaxY")
        Me.TextBox_AFR_MaxY.Name = "TextBox_AFR_MaxY"
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'TextBox_AFR_MaxX
        '
        resources.ApplyResources(Me.TextBox_AFR_MaxX, "TextBox_AFR_MaxX")
        Me.TextBox_AFR_MaxX.Name = "TextBox_AFR_MaxX"
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'TextBox_AFR_MinX
        '
        resources.ApplyResources(Me.TextBox_AFR_MinX, "TextBox_AFR_MinX")
        Me.TextBox_AFR_MinX.Name = "TextBox_AFR_MinX"
        '
        'TextBox_AFR_MinY
        '
        resources.ApplyResources(Me.TextBox_AFR_MinY, "TextBox_AFR_MinY")
        Me.TextBox_AFR_MinY.Name = "TextBox_AFR_MinY"
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'btn_AFR_OK
        '
        resources.ApplyResources(Me.btn_AFR_OK, "btn_AFR_OK")
        Me.btn_AFR_OK.Name = "btn_AFR_OK"
        Me.btn_AFR_OK.UseVisualStyleBackColor = True
        '
        'Dialog_MuraFalseDefect
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.TabControl_FalseDefect)
        Me.Controls.Add(Me.Label_FalseType)
        Me.Controls.Add(Me.ComboBox_FalseType)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraFalseDefect"
        Me.ShowInTaskbar = False
        CType(Me.NumericUpDown_Y, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Area, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_ManualAddFD.ResumeLayout(False)
        Me.GroupBox_ManualAddFD.PerformLayout()
        Me.TabControl_FalseDefect.ResumeLayout(False)
        Me.TabPage_FalseDefectTable.ResumeLayout(False)
        Me.TabPage_FilterRegion.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.NumericUpDown_FalseLineWidth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_AutoAddFR.ResumeLayout(False)
        Me.GroupBox_AutoAddFR.PerformLayout()
        Me.GroupBox_MannualAddFR.ResumeLayout(False)
        Me.GroupBox_MannualAddFR.PerformLayout()
        Me.GroupBox_FilterRegion.ResumeLayout(False)
        Me.TabPage_UnFilterRegion.ResumeLayout(False)
        Me.GroupBox_AutoAddUFR.ResumeLayout(False)
        Me.GroupBox_AutoAddUFR.PerformLayout()
        Me.GroupBox_MannualAddUFR.ResumeLayout(False)
        Me.GroupBox_MannualAddUFR.PerformLayout()
        Me.GroupBox_UnFilterRegion.ResumeLayout(False)
        Me.TabPage_AIFilterRegion.ResumeLayout(False)
        Me.GroupBox_CenterMuraTransfer.ResumeLayout(False)
        Me.GroupBox_AutoAddAFR.ResumeLayout(False)
        Me.GroupBox_AutoAddAFR.PerformLayout()
        Me.GroupBox_AIFilterRegion.ResumeLayout(False)
        Me.GroupBox_MannualAddAFR.ResumeLayout(False)
        Me.GroupBox_MannualAddAFR.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label_Y As System.Windows.Forms.Label
    Friend WithEvents Label_X As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Y As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Area As System.Windows.Forms.Label
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_X As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Area As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_AddOne As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader_NewY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label_NewPosition As System.Windows.Forms.Label
    Friend WithEvents Label_FalsePosition As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader_X As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Label_FalseType As System.Windows.Forms.Label
    Friend WithEvents ListView_False As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Area As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Y As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox_ManualAddFD As System.Windows.Forms.GroupBox
    Friend WithEvents ColumnHeader_NewX As System.Windows.Forms.ColumnHeader
    Friend WithEvents ComboBox_FalseType As System.Windows.Forms.ComboBox
    Friend WithEvents ColumnHeader_NewArea As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView_New As System.Windows.Forms.ListView
    Friend WithEvents Button_FalseAdd As System.Windows.Forms.Button
    Friend WithEvents Button_FalseRemove As System.Windows.Forms.Button
    Friend WithEvents Label_False_Type As System.Windows.Forms.Label
    Friend WithEvents ComboBox_False_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Button_ClearAll As System.Windows.Forms.Button
    Friend WithEvents TabControl_FalseDefect As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_FalseDefectTable As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_FilterRegion As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_FilterRegion As System.Windows.Forms.GroupBox
    Friend WithEvents ListView_FilterRegion As System.Windows.Forms.ListView
    Friend WithEvents Ch_TopY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_LeftX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_RightX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_BottomY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label_FRCount As System.Windows.Forms.Label
    Friend WithEvents Button_DeleteRegion As System.Windows.Forms.Button
    Friend WithEvents GroupBox_MannualAddFR As System.Windows.Forms.GroupBox
    Friend WithEvents Button_AddRegion As System.Windows.Forms.Button
    Friend WithEvents TextBox_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents lbData As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MinX As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_MinY As System.Windows.Forms.TextBox
    Friend WithEvents lbGate As System.Windows.Forms.Label
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents CheckBox_ShowFilterRegion As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_RegionMannual As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_AutoAddFR As System.Windows.Forms.GroupBox
    Friend WithEvents TabPage_UnFilterRegion As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_AutoAddUFR As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowUnFilterRegion As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_UFRMannual As System.Windows.Forms.CheckBox
    Friend WithEvents btn_UFR_Cancel As System.Windows.Forms.Button
    Friend WithEvents btn_UFR_OK As System.Windows.Forms.Button
    Friend WithEvents GroupBox_MannualAddUFR As System.Windows.Forms.GroupBox
    Friend WithEvents Button_AddUFR As System.Windows.Forms.Button
    Friend WithEvents TextBox_UFR_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox_UFR_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox_UFR_MinX As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_UFR_MinY As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_UnFilterRegion As System.Windows.Forms.GroupBox
    Friend WithEvents Label_UFRCount As System.Windows.Forms.Label
    Friend WithEvents Button_DeleteUFR As System.Windows.Forms.Button
    Friend WithEvents ListView_UnFilterRegion As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_FilterType As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_FR_FilterType As System.Windows.Forms.ComboBox
    Friend WithEvents Button_FR_ClearAll As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader_CreateTime As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_NewCreateTime As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_FR_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents Ch_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_NewPattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_False_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_FalseLineDirection As System.Windows.Forms.ComboBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_FalseLineWidth As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_EnableFalseLine As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage_AIFilterRegion As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_AutoAddAFR As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowAIFilterRegion As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_AFRMannual As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_AIFilterRegion As System.Windows.Forms.GroupBox
    Friend WithEvents Button_AFR_ClearAll As System.Windows.Forms.Button
    Friend WithEvents Label_AFRCount As System.Windows.Forms.Label
    Friend WithEvents Button_DeleteAFR As System.Windows.Forms.Button
    Friend WithEvents ListView_AIFilterRegion As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents btn_AFR_Cancel As System.Windows.Forms.Button
    Friend WithEvents GroupBox_MannualAddAFR As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_AFR_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_AFR_FilterType As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Button_AddAFR As System.Windows.Forms.Button
    Friend WithEvents TextBox_AFR_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox_AFR_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox_AFR_MinX As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_AFR_MinY As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btn_AFR_OK As System.Windows.Forms.Button
    Friend WithEvents GroupBox_CenterMuraTransfer As System.Windows.Forms.GroupBox
    Friend WithEvents Button_CenterMuraTransfer As System.Windows.Forms.Button
End Class
