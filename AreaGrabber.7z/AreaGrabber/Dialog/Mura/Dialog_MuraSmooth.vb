Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.IO
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraSmooth

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_AxMDisplay As MIL_ID
    Friend WithEvents m_DialogBoundary As Dialog_MuraBoundary

    Private m_ChildOriginalIndex As Integer
    Private m_ChildSampleIndex As Integer
    Private m_DefocusOriginalIndex As Integer
    Private m_FFCAlignIndex As Integer
    Private m_FFCResultIndex As Integer
    Private m_BlobSmoothIndex As Integer
    Private m_MacroSmoothIndex As Integer
    Private m_CurrentIndex As Integer
    Private m_DialogBoundaryType As DialogBoundaryTypeDefine

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- Temp ---
    Private m_Align_Type As Integer
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal type As DialogBoundaryTypeDefine, ByVal language As String)
        Dim image As MIL_ID = M_NULL

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraSmooth", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo("zh-CN")
        Thread.CurrentThread.CurrentUICulture = New CultureInfo("zh-CN")
        Me.changeLanguage("zh-CN")
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '---UpdateUserLevel---
        Me.UpdateUserLevel()

        '--- Display ---
        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay

        Me.m_ChildOriginalIndex = -2
        Me.m_ChildSampleIndex = -2
        Me.m_DefocusOriginalIndex = -2
        Me.m_FFCAlignIndex = -2
        Me.m_FFCResultIndex = -2
        Me.m_BlobSmoothIndex = -2
        Me.m_MacroSmoothIndex = -2

        Me.m_DialogBoundaryType = type

        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
            image = Me.m_MuraProcess.Img_ChildSample
        Else
            image = Me.m_MuraProcess.Img_ChildOriginal
        End If

        If image <> M_NULL Then
            Me.m_ChildOriginalIndex = Me.ComboBox_Select.Items.Add("�i���ϼv��")
            Me.ComboBox_Select.SelectedIndex = Me.m_ChildOriginalIndex
        Else
            Me.m_Form.ComboBox_Type.SelectedIndex = -1
            Me.Button_FFCAlign.Enabled = False
            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                MessageBox.Show("[Mura�v���ѼƦ��~]�S���G�ե��v��Data ", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            Me.Button_Smooth.Enabled = False
        End If

        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Or Me.m_MuraProcess.MuraModelRecipe.UseBLFFC.Value Then
            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                Me.Button_FFCAlign.Enabled = True
                Me.Button_BLFFCAlign.Enabled = False
            Else
                Me.Button_FFCAlign.Enabled = False
                Me.Button_BLFFCAlign.Enabled = True
            End If
        Else
            Me.Button_FFCAlign.Enabled = False
            Me.Button_BLFFCAlign.Enabled = False

            image = Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage
            If image <> M_NULL Then
                Me.m_BlobSmoothIndex = Me.ComboBox_Select.Items.Add("Blob ���ƳB�z�v��")
            End If

            image = Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage
            If image <> M_NULL Then
                Me.m_MacroSmoothIndex = Me.ComboBox_Select.Items.Add("Macro ���ƳB�z�v��")
            End If
        End If

        image = Me.m_MuraProcess.Img_16U_Defocus_NonPage
        If image <> M_NULL Then
            Me.m_DefocusOriginalIndex = Me.ComboBox_Select.Items.Add("�k�J��v��")
            Me.ComboBox_Select.SelectedIndex = Me.m_DefocusOriginalIndex
        Else
            Me.m_Form.ComboBox_Type.SelectedIndex = -1
            Me.Button_FFCAlign.Enabled = False
            Me.Button_Smooth.Enabled = False
        End If

        '--- Initial Variables ---
        Me.m_Align_Type = Me.m_MainProcess.FuncProcess.FuncModelRecipe.AlignType.Value

        '--- Initial Button ---   
        Me.Button_Save.Enabled = True
        Me.Button_Cancel.Enabled = False
        Me.BtnNext_MuraSmooth.Enabled = False
        Me.BtnPre_MuraSmooth.Enabled = True
        If Not Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
            Me.Button_Smooth.Enabled = True
        Else
            Me.Button_Smooth.Enabled = False
        End If

        If Me.m_Align_Type = AlignType.Circle Then
            Me.NumericUpDown_Circle_ByPassRadius.Enabled = True
        ElseIf Me.m_Align_Type = AlignType.Rectangle Then
            Me.NumericUpDown_Circle_ByPassRadius.Enabled = False
        End If

        Me.UpdateData()
        Me.Update()
    End Sub

#Region "--- Dialog Event ---"
    Private Sub m_DialogBoundary_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogBoundary.Closing
        Me.m_DialogBoundary = Nothing
        Me.m_Form.Focus()
        Me.Enabled = True
        If Me.m_MuraProcess.Img_ChildSample <> M_NULL Then
            If Me.m_ChildSampleIndex = -2 Then
                If Me.m_ChildOriginalIndex = -2 Then
                    Me.m_ChildSampleIndex = 0
                Else
                    Me.m_ChildSampleIndex = 1
                End If
                Me.ComboBox_Select.Items.Insert(Me.m_ChildSampleIndex, "�G�ե��i���ϼv��")
                Me.ComboBox_Select.SelectedIndex = Me.m_ChildSampleIndex
                If Me.m_BlobSmoothIndex <> -2 Then
                    Me.m_BlobSmoothIndex += 1
                End If
                If Me.m_MacroSmoothIndex <> -2 Then
                    Me.m_MacroSmoothIndex += 1
                End If
                If Me.m_FFCResultIndex <> -2 Then
                    Me.m_FFCResultIndex += 1
                End If
                If Me.m_FFCAlignIndex <> -2 Then
                    Me.m_FFCAlignIndex += 1
                End If
            Else
                Me.ComboBox_Select.SelectedIndex = Me.m_ChildSampleIndex
            End If
        Else
            If Me.m_CurrentIndex = -1 Then
                'Me.m_AxMDisplay.Image = Nothing
                MdispSelect(Me.m_AxMDisplay, M_NULL)   '2012/08/10 Rick modify

                Me.m_Form.ResetScrollBar()
            Else
                Me.ComboBox_Select.SelectedIndex = Me.m_CurrentIndex
            End If
        End If
    End Sub
#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim mpr As ClsMuraPatternRecipe = Me.m_MuraProcess.CurrentMuraPatternRecipe
        Me.NumericUpDown_BlobMura_GlobleSmooth.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value
        Me.NumericUpDown_MacroMura_GlobleSmooth.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value
        Me.NumericUpDown_Circle_ByPassRadius.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value

        Me.Num_ResizeCount_Min.Value = mpr.ResizeCount_min.Value
        Me.Num_ResizeCount_Mid.Value = mpr.ResizeCount_mid.Value
        Me.Num_ResizeCount_Mid2.Value = mpr.ResizeCount_mid.Value
        Me.Num_ResizeCount_Max.Value = mpr.ResizeCount_max.Value

        Me.CheckBox_UseBaseLine.Checked = mpr.UseBaseLine.Value
        Me.NumericUpDown_MacroPowerX.Value = mpr.MacroPowerX.Value
        Me.NumericUpDown_MacroPowerY.Value = mpr.MacroPowerY.Value

        Me.CheckBox_UseFFT.Checked = mpr.UseFFT.Value

        If Not mpr.UseFFT.Value Then
            Me.Button_CalculateFFT.Enabled = False
            Me.NumericUpDown_FFTFilterRadius.Enabled = False
        End If

        Me.NumericUpDown_FFTFilterRadius.Value = mpr.FFTFilterRadius.Value

        Me.CheckBox_RemoveHVBand.Checked = mpr.RemoveHVBand.Value
    End Sub
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.NumericUpDown_BlobMura_GlobleSmooth.Enabled = False
                Me.NumericUpDown_MacroMura_GlobleSmooth.Enabled = False
                Me.NumericUpDown_Circle_ByPassRadius.Enabled = False
                Me.GroupBox_MuraRatio.Enabled = False
            Case 1 'PM
                Me.NumericUpDown_BlobMura_GlobleSmooth.Enabled = False
                Me.NumericUpDown_MacroMura_GlobleSmooth.Enabled = False
                Me.NumericUpDown_Circle_ByPassRadius.Enabled = False
                Me.GroupBox_MuraRatio.Enabled = False
            Case 2 'ENG
                Me.NumericUpDown_BlobMura_GlobleSmooth.Enabled = True
                Me.NumericUpDown_MacroMura_GlobleSmooth.Enabled = True
                Me.NumericUpDown_Circle_ByPassRadius.Enabled = True
                Me.GroupBox_MuraRatio.Enabled = True
            Case 3 'ALL
                Me.NumericUpDown_BlobMura_GlobleSmooth.Enabled = True
                Me.NumericUpDown_MacroMura_GlobleSmooth.Enabled = True
                Me.NumericUpDown_Circle_ByPassRadius.Enabled = True
                Me.GroupBox_MuraRatio.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        'Me.Button_LoadChild.Enabled = En
        Me.Button_Smooth.Enabled = En
        Me.Button_Save.Enabled = En
        Me.Button_Cancel.Enabled = En
        Me.BtnNext_MuraSmooth.Enabled = En
        Me.BtnPre_MuraSmooth.Enabled = En
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "---Smooth---"

    Public Sub Smooth()
        Dim boundary As ClsParameterBoundary = Nothing
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim Image_Range As String = ""
        Dim InputImage_Type As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim shift As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress


        '--- Disable Button ---
        Me.Button_Enable(False)

        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value = Me.NumericUpDown_BlobMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value = Me.NumericUpDown_MacroMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value = Me.NumericUpDown_Circle_ByPassRadius.Value

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraSmooth Setting   ==> Request_Command = "DIALOG_MURASMOOTH_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURASMOOTH_SETTING"
            TimeOut = 100000 '100 secs
            Parameter_Lists = "BlobMura_GlobleSmooth," & Me.NumericUpDown_BlobMura_GlobleSmooth.Value & ";" & "MacroMura_GlobleSmooth," & Me.NumericUpDown_MacroMura_GlobleSmooth.Value & ";" & "Circle_ByPassRadius," & Me.NumericUpDown_Circle_ByPassRadius.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSmooth Setting Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Smooth]Dialog_MuraSmooth Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Smooth Image  ==> Request_Command = "CALCULATE_SMOOTH" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_SMOOTH"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If Me.CheckBox_RemoveHVBand.Checked Then
                '--- Prepare Command ---
                Request_Command = "REMOVE_HVBAND"
                TimeOut = 200000 '200 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            End If


            If SaveImage AndAlso Response_OK Then
                '[1] --- Update Blob Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] --- Update Macro Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[3] --- Update Band Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BandMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BandMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[4] --- Update Defocus Image ---
                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                Else
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                End If

                shift = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

                '[5] --- Update Blob Smooth Child Image ---
                If Me.m_MuraProcess.Img_BlobMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_BlobMura_SmoothChild)
                    Me.m_MuraProcess.Img_BlobMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_BlobMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                '[6] --- Update Macro Smooth Child Image ---
                If Me.m_MuraProcess.Img_MacroMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_MacroMura_SmoothChild)
                    Me.m_MuraProcess.Img_MacroMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_MacroMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                '[7] --- Update Band Smooth Child Image ---
                If Me.m_MuraProcess.Img_BandMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_BandMura_SmoothChild)
                    Me.m_MuraProcess.Img_BandMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_BandMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Smooth]Calculate Smooth Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_BlobSmoothIndex = -2 Then
            Me.m_BlobSmoothIndex = Me.ComboBox_Select.Items.Add("Blob ���ƳB�z�v��")
        End If
        If Me.m_MacroSmoothIndex = -2 Then
            Me.m_MacroSmoothIndex = Me.ComboBox_Select.Items.Add("Macro ���ƳB�z�v��")
        End If
        If Me.ComboBox_Select.SelectedIndex = Me.m_BlobSmoothIndex Then
            Me.m_Form.ImageUpdate()
        Else
            Me.ComboBox_Select.SelectedIndex = Me.m_BlobSmoothIndex
        End If

        Me.Button_Enable(True)
    End Sub

#End Region

#Region "---BLFFC---"
    Public Sub BLFFC()
        Dim Image As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type, OffsetX, OffsetY As Integer
        Dim boundary As ClsParameterBoundary = Nothing
        Dim InputImage_Type As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Button_BLFFCAlign.Enabled = False
        Me.Button_Smooth.Enabled = False
        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '----------------------------------------------------------------------------------------------
        ' Calculate FFC Result Image  ==> Request_Command = "CALCULATE_FFCRESULT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLFFC"
            TimeOut = 300000 '300 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Result Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_FFCAlign.Enabled = True
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image ---
                Image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_CurrentOriginal_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_CurrentOriginal_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Image <> M_NULL Then
                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Image)
                            Image = M_NULL
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Image)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_BLFFCAlign]Calculate BLFFC Align Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_FFCAlign.Enabled = True
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_MURA_ORIGINALROI"
            TimeOut = 300000 '300 secs
            SaveImage = False

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Response_OK Then
                boundary = Me.m_MuraProcess.BoundaryOriginal
                OffsetX = boundary.LeftX
                OffsetY = boundary.TopY
                SizeX = boundary.RightX - OffsetX
                SizeY = boundary.BottomY - OffsetY
                Me.m_MuraProcess.Img_ChildOriginal = MbufChild2d(Me.m_MuraProcess.Img_CurrentOriginal_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)

            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_ROIEXPAND"
            TimeOut = 200000 '200 secs
            InputImage_Type = "CHILD_ORIGINAL"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_DEFOCUS"
            TimeOut = 200000 '200 secs
            InputImage_Type = "CHILD_ORIGINAL"
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image 
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                    'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        Me.m_Form.ImageUpdate()

        Me.Button_BLFFCAlign.Enabled = True
        Me.Button_Smooth.Enabled = True
    End Sub
#End Region

#Region "---CalculateFFT---"
    Public Sub CalculateFFT()
        Dim Image As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type, OffsetX, OffsetY As Integer
        Dim boundary As ClsParameterBoundary = Nothing
        Dim InputImage_Type As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Button_Smooth.Enabled = False
        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '----------------------------------------------------------------------------------------------
        ' Calculate FFC Result Image  ==> Request_Command = "CALCULATE_FFCRESULT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_FFT"
            TimeOut = 300000 '300 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Result Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_FFCAlign.Enabled = True
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image ---
                Image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_CurrentOriginal_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_CurrentOriginal_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Image <> M_NULL Then
                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Image)
                            Image = M_NULL
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Image)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_BLFFCAlign]Calculate BLFFC Align Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_FFCAlign.Enabled = True
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_MURA_ORIGINALROI"
            TimeOut = 300000 '300 secs
            SaveImage = False

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Response_OK Then
                boundary = Me.m_MuraProcess.BoundaryOriginal
                OffsetX = boundary.LeftX
                OffsetY = boundary.TopY
                SizeX = boundary.RightX - OffsetX
                SizeY = boundary.BottomY - OffsetY
                Me.m_MuraProcess.Img_ChildOriginal = MbufChild2d(Me.m_MuraProcess.Img_CurrentOriginal_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)

            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_ROIEXPAND"
            TimeOut = 200000 '200 secs
            InputImage_Type = "CHILD_ORIGINAL"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_DEFOCUS"
            TimeOut = 200000 '200 secs
            InputImage_Type = "CHILD_ORIGINAL"
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image 
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                    'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        Me.m_Form.ImageUpdate()

        Me.Button_Smooth.Enabled = True
    End Sub
#End Region

#Region "---FFCAlign---"

    Public Sub FFCAlign()
        Dim Image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim InputImage_Type As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Button_FFCAlign.Enabled = False

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '----------------------------------------------------------------------------------------------
        ' Calculate FFC Result Image  ==> Request_Command = "CALCULATE_FFCRESULT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_FFCRESULT"
            TimeOut = 300000 '300 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Result Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_FFCAlign.Enabled = True
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image ---
                Image = Me.m_MuraProcess.Img_16U_FFCResult_NonPage
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_FFCResult_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_FFCResult_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Image <> M_NULL Then
                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Image)
                            Image = M_NULL
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Image)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_FFCAlign]Calculate FFC Align Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_FFCAlign.Enabled = True
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate ROI Expand Image (with FFC)[2]  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_ROIEXPAND"
            TimeOut = 300000 '300 secs
            InputImage_Type = "FFC_RESULT"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image (with FFC) Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraBoundary.Button_FFCAlign]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_FFCAlign.Enabled = True
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_FFCAlign]Calculate ROI Expand Image (with FFC) Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_FFCAlign.Enabled = True
        End Try

        'Me.m_MuraProcess.Img_16U_ROIExpand_NonPage.Save("D:\Img_16U_ROIExpand_NonPage.tif")

        If Me.m_FFCResultIndex = -2 Then
            Me.m_FFCResultIndex = Me.ComboBox_Select.Items.Add("�G�ե����G�v��")
        End If
        If Me.ComboBox_Select.SelectedIndex = Me.m_FFCResultIndex Then
            Me.m_Form.ImageUpdate()
        Else
            Me.ComboBox_Select.SelectedIndex = Me.m_FFCResultIndex
        End If
        Me.Button_FFCAlign.Enabled = True
        Me.Button_Smooth.Enabled = True
    End Sub

#End Region

#Region "---Save---"

    Public Sub Save()
        Dim mpr As ClsMuraPatternRecipe = Me.m_MuraProcess.CurrentMuraPatternRecipe
        Dim str As String
        Dim dirPath As String
        Dim Parameter_Lists As String = ""
        Dim dir As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        Me.Button_Enable(False)

        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value = Me.NumericUpDown_BlobMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value = Me.NumericUpDown_MacroMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value = Me.NumericUpDown_Circle_ByPassRadius.Value

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraSmooth Setting   ==> Request_Command = "DIALOG_MURASMOOTH_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURASMOOTH_SETTING"
            TimeOut = 10000 '10 secs
            Parameter_Lists = "BlobMura_GlobleSmooth," & Me.NumericUpDown_BlobMura_GlobleSmooth.Value & ";" & "MacroMura_GlobleSmooth," & Me.NumericUpDown_MacroMura_GlobleSmooth.Value & ";" & "Circle_ByPassRadius," & Me.NumericUpDown_Circle_ByPassRadius.Value & ";" & _
                              "ResizeCount_min," & Me.Num_ResizeCount_Min.Value & ";" & "ResizeCount_mid," & Me.Num_ResizeCount_Mid.Value & ";" & "ResizeCount_max," & Me.Num_ResizeCount_Max.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSmooth Setting Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Save]Dialog_MuraSmooth Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '---  Mura ��ҰѼ� ---
        mpr.ResizeCount_min.Value = Me.Num_ResizeCount_Min.Value
        mpr.ResizeCount_mid.Value = Me.Num_ResizeCount_Mid.Value
        mpr.ResizeCount_max.Value = Me.Num_ResizeCount_Max.Value

        dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        If Not Directory.Exists(dirPath) Then
            Directory.CreateDirectory(dirPath)
        End If
        str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"

        Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

        '-------------------------------------------------------------------------------------------------------

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            TimeOut = 10000 '10 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & "), " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

        Me.Button_Enable(True)
    End Sub

#End Region

#End Region

#Region "--- ComboBox Event ---"
    Private Sub ComboBox_Select_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Select.SelectedIndexChanged
        Select Case Me.ComboBox_Select.SelectedIndex
            Case -1
                Me.m_Form.ComboBox_Type.SelectedIndex = -1
            Case Me.m_ChildOriginalIndex   '�i���ϼv��
                Me.m_Form.CurrentIndex1 = 0
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 0
            Case Me.m_ChildSampleIndex    '�G�ե��i���ϼv��
                Me.m_Form.CurrentIndex3 = 0
                Me.m_Form.ComboBox_Type.SelectedIndex = 3
                Me.m_Form.ComboBox_Select.SelectedIndex = 0
            Case Me.m_DefocusOriginalIndex '�i���Ͻk�J��v��
                Me.m_Form.CurrentIndex1 = 19
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 19
            Case Me.m_FFCAlignIndex       '�G�ե��v��(�t��)
                Me.m_Form.CurrentIndex3 = 1
                Me.m_Form.ComboBox_Type.SelectedIndex = 3
                Me.m_Form.ComboBox_Select.SelectedIndex = 1
            Case Me.m_FFCResultIndex   '�G�ե����G�v��
                Me.m_Form.CurrentIndex1 = 1
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 1
            Case Me.m_BlobSmoothIndex   'Blob ���ƳB�z�v��
                Me.m_Form.CurrentIndex1 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            Case Me.m_MacroSmoothIndex   'Macro ���ƳB�z�v��
                Me.m_Form.CurrentIndex1 = 3
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 3
        End Select
        Me.m_Form.ImageZoomAll()   '2009/03/10 Rick add
    End Sub
#End Region

#Region "--- Button Event ---"

    '#Region "--- Button_LoadChild ---"
    '    Private Sub Button_LoadChild_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LoadChild.Click
    '        Dim image As MIL_ID = M_NULL
    '        Dim imageBuffer As MIL_ID = M_NULL
    '        Dim FilePath As String = ""
    '        Dim IP_Address As String = ""
    '        Dim SizeX, SizeY, Type As Integer

    '        '--- �إ߳s�u ---
    '        If Not Me.ConnectToIP Then
    '            Exit Sub
    '        End If

    '        '--- Initial ---
    '        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

    '        '--- Disable Button ---
    '        Me.Button_Enable(False)

    '        Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
    '        Me.m_Form.OpenFileDialog.FileName = ""
    '        Me.m_Form.OpenFileDialog.ShowDialog()

    '        If Me.m_Form.OpenFileDialog.FileName <> "" Then
    '            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
    '                image = Me.m_MuraProcess.Img_ChildSample
    '            Else
    '                image = Me.m_MuraProcess.Img_ChildOriginal
    '            End If

    '            '[AreaGrabber] Load Image --- (For Display)
    '            '[1] image ---
    '            MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
    '            MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
    '            MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
    '            If image <> M_NULL Then
    '                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
    '                    MbufFree(image)
    '                    image = M_NULL
    '                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '                End If
    '            Else
    '                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '            End If
    '            MbufLoad(Me.m_Form.OpenFileDialog.FileName, image)

    '            If image <> M_NULL Then
    '                '----------------------------------------------------------------------------------------------
    '                ' IP Load Child Original\Sample Image  ==> Request_Command = "LOAD_CHILD_ORIGINAL\LOAD_CHILD_SAMPLE" (Dispatcher 1)
    '                '----------------------------------------------------------------------------------------------
    '                Try
    '                    '--- Prepare Command ---
    '                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
    '                        Request_Command = "LOAD_CHILD_SAMPLE"
    '                    Else
    '                        Request_Command = "LOAD_CHILD_ORIGINAL"
    '                    End If
    '                    TimeOut = 10000 '10 secs

    '                    FilePath = Me.m_Form.OpenFileDialog.FileName
    '                    Response_OK = False
    '                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, FilePath, , , , , , , , TimeOut)
    '                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

    '                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
    '                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
    '                        Response_OK = True
    '                    Else
    '                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Child Original\Sample Image Error !(" & SubSystemResult.ErrMessage & "), " & CStr(Me.m_MainProcess.ErrorCode))
    '                        MessageBox.Show("[Dialog_MuraSmooth.Button_LoadChild]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                        Me.Button_Enable(True)
    '                        Exit Sub
    '                    End If

    '                Catch ex As Exception
    '                    Me.Button_Enable(True)
    '                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_LoadChild]Func Load Child Original\Sample Image Error ! (" & ex.Message & ")")
    '                    MessageBox.Show("[Dialog_MuraSmooth.Button_LoadChild]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                End Try

    '                '----------------------------------------------------------------------------------------------
    '                ' Defocus Original Image  ==> Request_Command = "DEFOCUS_ORIGINAL" (Dispatcher 1)
    '                '----------------------------------------------------------------------------------------------
    '                Try
    '                    '--- Prepare Command ---
    '                    Request_Command = "DEFOCUS_ORIGINAL"
    '                    TimeOut = 10000 '10 secs

    '                    Response_OK = False
    '                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
    '                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

    '                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
    '                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
    '                        Response_OK = True
    '                    Else
    '                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Defocus Original Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
    '                        MessageBox.Show("[Dialog_MuraSmooth.Button_LoadChild]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                        Me.Button_Enable(True)
    '                        Exit Sub
    '                    End If

    '                    If Response_OK Then
    '                        '--- Update Processed Image ---
    '                        image = Me.m_MuraProcess.Img_16U_Defocus_NonPage
    '                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "DefocusOriginal.tif"
    '                        Me.RepairPath_2(strPath)
    '                        If System.IO.File.Exists(strPath) Then
    '                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
    '                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
    '                            MbufDiskInquire(strPath, M_TYPE, Type)
    '                            If image <> M_NULL Then
    '                                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
    '                                    MbufFree(image)
    '                                    image = M_NULL
    '                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '                                End If
    '                            Else
    '                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '                            End If

    '                            '--- Load Remote Image ---
    '                            MbufLoad(strPath, image)

    '                            If System.IO.File.Exists(strPath) = True Then
    '                                System.IO.File.Delete(strPath)
    '                            End If
    '                        End If
    '                    End If
    '                Catch ex As Exception
    '                    Me.Button_Enable(True)
    '                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_LoadChild]Defocus Original Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
    '                    MessageBox.Show("[Dialog_MuraSmooth.Button_LoadChild]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                End Try

    '                Me.m_ChildOriginalIndex = 0
    '                Me.ComboBox_Select.Items.Insert(Me.m_ChildOriginalIndex, "�i���ϼv��")
    '                Me.ComboBox_Select.SelectedIndex = Me.m_ChildOriginalIndex
    '                If Me.m_BlobSmoothIndex <> -2 Then
    '                    Me.m_BlobSmoothIndex += 1
    '                End If
    '                If Me.m_MacroSmoothIndex <> -2 Then
    '                    Me.m_MacroSmoothIndex += 1
    '                End If
    '                If Me.m_FFCResultIndex <> -2 Then
    '                    Me.m_FFCResultIndex += 1
    '                End If
    '                If Me.m_FFCAlignIndex <> -2 Then
    '                    Me.m_FFCAlignIndex += 1
    '                End If
    '                If Me.m_ChildSampleIndex <> -2 Then
    '                    Me.m_ChildSampleIndex += 1
    '                End If
    '            Else
    '                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
    '                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
    '                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
    '                If image <> M_NULL Then
    '                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
    '                        MbufFree(image)
    '                        image = M_NULL
    '                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '                    End If
    '                Else
    '                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '                End If
    '                MbufLoad(Me.m_Form.OpenFileDialog.FileName, image)

    '                '----------------------------------------------------------------------------------------------
    '                ' Defocus Original Image  ==> Request_Command = "DEFOCUS_ORIGINAL" (Dispatcher 2)
    '                '----------------------------------------------------------------------------------------------
    '                Try
    '                    '--- Prepare Command ---
    '                    Request_Command = "DEFOCUS_ORIGINAL"
    '                    TimeOut = 10000 '10 secs

    '                    Response_OK = False
    '                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
    '                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

    '                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
    '                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
    '                        Response_OK = True
    '                    Else
    '                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Defocus Original Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
    '                        MessageBox.Show("[Dialog_MuraSmooth.Button_LoadChild]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                        Me.Button_Enable(True)
    '                        Exit Sub
    '                    End If

    '                    If Response_OK Then
    '                        '--- Update Processed Image ---
    '                        image = Me.m_MuraProcess.Img_16U_Defocus_NonPage
    '                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "DefocusOriginal.tif"
    '                        Me.RepairPath_2(strPath)
    '                        If System.IO.File.Exists(strPath) Then
    '                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
    '                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
    '                            MbufDiskInquire(strPath, M_TYPE, Type)
    '                            If image <> M_NULL Then
    '                                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
    '                                    MbufFree(image)
    '                                    image = M_NULL
    '                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '                                End If
    '                            Else
    '                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
    '                            End If

    '                            '--- Load Remote Image ---
    '                            MbufLoad(strPath, image)

    '                            If System.IO.File.Exists(strPath) = True Then
    '                                System.IO.File.Delete(strPath)
    '                            End If
    '                        End If
    '                    End If
    '                Catch ex As Exception
    '                    Me.Button_Enable(True)
    '                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_LoadChild]Defocus Original Image Error ! (" & ex.Message & ")")
    '                    MessageBox.Show("[Dialog_MuraSmooth.Button_LoadChild]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
    '                End Try

    '                If Me.ComboBox_Select.SelectedIndex = 0 Then
    '                    If image <> M_NULL Then
    '                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
    '                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
    '                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
    '                        Type = MbufInquire(image, M_TYPE, M_NULL)

    '                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
    '                            MbufFree(imageBuffer)
    '                            imageBuffer = M_NULL
    '                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
    '                        End If
    '                        MbufCopy(image, imageBuffer)

    '                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
    '                        MbufControl(image, M_MODIFIED, M_DEFAULT)
    '                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

    '                        Me.m_Form.ResetScrollBar()
    '                    End If
    '                Else
    '                    Me.ComboBox_Select.SelectedIndex = 0
    '                End If
    '            End If

    '            If Me.m_BlobSmoothIndex <> -2 Then
    '                Me.ComboBox_Select.Items.RemoveAt(Me.m_BlobSmoothIndex)
    '                Me.m_BlobSmoothIndex = -2
    '            End If
    '            If Me.m_MacroSmoothIndex <> -2 Then
    '                Me.ComboBox_Select.Items.RemoveAt(Me.m_MacroSmoothIndex)
    '                Me.m_MacroSmoothIndex = -2
    '            End If
    '            If Me.m_FFCResultIndex <> -2 Then
    '                Me.ComboBox_Select.Items.RemoveAt(Me.m_FFCResultIndex)
    '                Me.m_FFCResultIndex = -2
    '            End If
    '            If Me.m_MuraProcess.Img_CurrentFFCAlign <> M_NULL And Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
    '                Me.Button_FFCAlign.Enabled = True
    '            End If

    '            Me.Button_Smooth.Enabled = True
    '            Me.m_Form.ImageZoomAll()
    '        End If
    '    End Sub
    '#End Region

#Region "--- Button_FFCAlign ---"
    Private Sub Button_FFCAlign_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FFCAlign.Click
        Dim Image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim InputImage_Type As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Button_FFCAlign.Enabled = False

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '----------------------------------------------------------------------------------------------
        ' Calculate FFC Result Image  ==> Request_Command = "CALCULATE_FFCRESULT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_FFCRESULT"
            TimeOut = 300000 '300 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Result Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_FFCAlign.Enabled = True
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image ---
                Image = Me.m_MuraProcess.Img_16U_FFCResult_NonPage
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_FFCResult_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_FFCResult_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Image <> M_NULL Then
                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Image)
                            Image = M_NULL
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Image)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_FFCAlign]Calculate FFC Align Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_FFCAlign.Enabled = True
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate ROI Expand Image (with FFC)[2]  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_ROIEXPAND"
            TimeOut = 300000 '300 secs
            InputImage_Type = "FFC_RESULT"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image (with FFC) Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraBoundary.Button_FFCAlign]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_FFCAlign.Enabled = True
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_FFCAlign]Calculate ROI Expand Image (with FFC) Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_FFCAlign.Enabled = True
        End Try

        'Me.m_MuraProcess.Img_16U_ROIExpand_NonPage.Save("D:\Img_16U_ROIExpand_NonPage.tif")

        If Me.m_FFCResultIndex = -2 Then
            Me.m_FFCResultIndex = Me.ComboBox_Select.Items.Add("�G�ե����G�v��")
        End If
        If Me.ComboBox_Select.SelectedIndex = Me.m_FFCResultIndex Then
            Me.m_Form.ImageUpdate()
        Else
            Me.ComboBox_Select.SelectedIndex = Me.m_FFCResultIndex
        End If
        Me.Button_FFCAlign.Enabled = True
        Me.Button_Smooth.Enabled = True
    End Sub
#End Region

#Region "---Buttom_BLFFCAlign---"
    Private Sub Button_BLFFCAlign_Click(sender As System.Object, e As System.EventArgs) Handles Button_BLFFCAlign.Click
        Dim Image As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type, OffsetX, OffsetY As Integer
        Dim boundary As ClsParameterBoundary = Nothing
        Dim InputImage_Type As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Button_BLFFCAlign.Enabled = False
        Me.Button_Smooth.Enabled = False
        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '----------------------------------------------------------------------------------------------
        ' Calculate FFC Result Image  ==> Request_Command = "CALCULATE_FFCRESULT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLFFC"
            TimeOut = 300000 '300 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Result Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_FFCAlign.Enabled = True
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image ---
                Image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_CurrentOriginal_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_CurrentOriginal_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Image <> M_NULL Then
                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Image)
                            Image = M_NULL
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Image)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_BLFFCAlign]Calculate BLFFC Align Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_FFCAlign]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.Button_FFCAlign.Enabled = True
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_MURA_ORIGINALROI"
            TimeOut = 300000 '300 secs
            SaveImage = False

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Response_OK Then
                boundary = Me.m_MuraProcess.BoundaryOriginal
                OffsetX = boundary.LeftX
                OffsetY = boundary.TopY
                SizeX = boundary.RightX - OffsetX
                SizeY = boundary.BottomY - OffsetY
                Me.m_MuraProcess.Img_ChildOriginal = MbufChild2d(Me.m_MuraProcess.Img_CurrentOriginal_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)

            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_ROIEXPAND"
            TimeOut = 200000 '200 secs
            InputImage_Type = "CHILD_ORIGINAL"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_DEFOCUS"
            TimeOut = 200000 '200 secs
            InputImage_Type = "CHILD_ORIGINAL"
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- Update Processed Image 
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                    'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        Me.m_Form.ImageUpdate()

        Me.Button_BLFFCAlign.Enabled = True
        Me.Button_Smooth.Enabled = True

    End Sub
#End Region

#Region "--- Button_Smooth ---"
    Private Sub Button_Smooth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Smooth.Click
        Dim boundary As ClsParameterBoundary = Nothing
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim Image_Range As String = ""
        Dim InputImage_Type As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim shift As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress


        '--- Disable Button ---
        Me.Button_Enable(False)

        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value = Me.NumericUpDown_BlobMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value = Me.NumericUpDown_MacroMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value = Me.NumericUpDown_Circle_ByPassRadius.Value

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraSmooth Setting   ==> Request_Command = "DIALOG_MURASMOOTH_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURASMOOTH_SETTING"
            TimeOut = 100000 '100 secs
            Parameter_Lists = "BlobMura_GlobleSmooth," & Me.NumericUpDown_BlobMura_GlobleSmooth.Value & ";" & "MacroMura_GlobleSmooth," & Me.NumericUpDown_MacroMura_GlobleSmooth.Value & ";" & "Circle_ByPassRadius," & Me.NumericUpDown_Circle_ByPassRadius.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSmooth Setting Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Smooth]Dialog_MuraSmooth Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Smooth Image  ==> Request_Command = "CALCULATE_SMOOTH" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_SMOOTH"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

            If Me.CheckBox_RemoveHVBand.Checked Then
                '--- Prepare Command ---
                Request_Command = "REMOVE_HVBAND"
                TimeOut = 200000 '200 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            End If


            If SaveImage AndAlso Response_OK Then
                '[1] --- Update Blob Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] --- Update Macro Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[3] --- Update Band Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BandMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BandMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[4] --- Update Defocus Image ---
                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                Else
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                End If

                shift = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

                '[5] --- Update Blob Smooth Child Image ---
                If Me.m_MuraProcess.Img_BlobMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_BlobMura_SmoothChild)
                    Me.m_MuraProcess.Img_BlobMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_BlobMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                '[6] --- Update Macro Smooth Child Image ---
                If Me.m_MuraProcess.Img_MacroMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_MacroMura_SmoothChild)
                    Me.m_MuraProcess.Img_MacroMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_MacroMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                '[7] --- Update Band Smooth Child Image ---
                If Me.m_MuraProcess.Img_BandMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_BandMura_SmoothChild)
                    Me.m_MuraProcess.Img_BandMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_BandMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)
                'MbufSave("D:\Test.tif", Me.m_MuraProcess.Img_BandMura_SmoothChild)
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Smooth]Calculate Smooth Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_BlobSmoothIndex = -2 Then
            Me.m_BlobSmoothIndex = Me.ComboBox_Select.Items.Add("Blob ���ƳB�z�v��")
        End If
        If Me.m_MacroSmoothIndex = -2 Then
            Me.m_MacroSmoothIndex = Me.ComboBox_Select.Items.Add("Macro ���ƳB�z�v��")
        End If
        Me.m_Form.ComboBox_Type.SelectedIndex = 1
        Me.m_Form.ComboBox_Select.SelectedIndex = 2
        Me.m_Form.ImageUpdate()
        Me.m_Form.ComboBox_Type.SelectedIndex = 1
        Me.m_Form.ComboBox_Select.SelectedIndex = 3
        Me.m_Form.ImageUpdate()
        'If Me.ComboBox_Select.SelectedIndex = Me.m_BlobSmoothIndex Then

        'Else
        '    Me.ComboBox_Select.SelectedIndex = Me.m_BlobSmoothIndex
        'End If

        Me.Button_Enable(True)
    End Sub
#End Region

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim mpr As ClsMuraPatternRecipe = Me.m_MuraProcess.CurrentMuraPatternRecipe
        Dim str As String
        Dim dirPath As String
        Dim Parameter_Lists As String = ""
        Dim dir As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        Me.Button_Enable(False)

        '---AreaGrab Save Setting---
        Me.Setting()

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraSmooth Setting   ==> Request_Command = "DIALOG_MURASMOOTH_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURASMOOTH_SETTING"
            TimeOut = 10000 '10 secs
            Parameter_Lists = "BlobMura_GlobleSmooth," & Me.NumericUpDown_BlobMura_GlobleSmooth.Value & ";" & "MacroMura_GlobleSmooth," & Me.NumericUpDown_MacroMura_GlobleSmooth.Value & ";" & "Circle_ByPassRadius," & Me.NumericUpDown_Circle_ByPassRadius.Value & ";" & _
                              "ResizeCount_min," & Me.Num_ResizeCount_Min.Value & ";" & "ResizeCount_mid," & Me.Num_ResizeCount_Mid.Value & ";" & "ResizeCount_max," & Me.Num_ResizeCount_Max.Value & ";" & "RemoveHVBand," & Me.CheckBox_RemoveHVBand.Checked & ";" & _
                              "UseBaseLine," & Me.CheckBox_UseBaseLine.Checked & ";" & "MacroPowerX," & Me.NumericUpDown_MacroPowerX.Value & ";" & "MacroPowerY," & Me.NumericUpDown_MacroPowerY.Value & ";" & _
                              "UseFFT," & Me.CheckBox_UseFFT.Checked & ";" & "FFTFilterRadius," & Me.NumericUpDown_FFTFilterRadius.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSmooth Setting Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Save]Dialog_MuraSmooth Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '---  Mura ��ҰѼ� ---
        mpr.ResizeCount_min.Value = Num_ResizeCount_Min.Value
        mpr.ResizeCount_mid.Value = Num_ResizeCount_Mid.Value
        mpr.ResizeCount_max.Value = Num_ResizeCount_Max.Value

        dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        If Not Directory.Exists(dirPath) Then
            Directory.CreateDirectory(dirPath)
        End If
        str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"

        Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

        '-------------------------------------------------------------------------------------------------------

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            TimeOut = 10000 '10 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & "), " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

        Me.Button_Enable(True)
    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region

#Region "---Buttom_CalculateFFC---"

    Private Sub Button_CalculateFFT_Click(sender As System.Object, e As System.EventArgs) Handles Button_CalculateFFT.Click
        Me.CalculateFFT()
    End Sub

#End Region

#Region "--- BtnNext_MuraSmooth ---"
    Private Sub BtnNext_MuraSmooth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNext_MuraSmooth.Click
        Me.Close()
        Me.m_Form.Button_Collection_Click()
    End Sub
#End Region

#Region "--- BtnPre_MuraSmooth ---"
    Private Sub BtnPre_MuraSmooth_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPre_MuraSmooth.Click
        Me.Close()
        Me.m_Form.Button_Boundary_Click()
    End Sub
#End Region



#End Region

#Region "---Numeric Event---"

    Private Sub Num_ResizeCount_Max_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Max.ValueChanged
        If Me.Num_ResizeCount_Max.Value <= Me.Num_ResizeCount_Mid.Value Then
            Me.Num_ResizeCount_Mid.Value = Me.Num_ResizeCount_Max.Value - 1
            Me.Num_ResizeCount_Mid2.Value = Me.Num_ResizeCount_Mid.Value
            If Me.Num_ResizeCount_Mid2.Value <= Me.Num_ResizeCount_Min.Value Then
                Me.Num_ResizeCount_Min.Value = Me.Num_ResizeCount_Mid2.Value - 1
            End If
        End If
    End Sub

    Private Sub Num_ResizeCount_Mid_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Mid.ValueChanged
        Me.Num_ResizeCount_Mid2.Value = Me.Num_ResizeCount_Mid.Value
        If Me.Num_ResizeCount_Mid.Value >= Me.Num_ResizeCount_Max.Value Then
            Me.Num_ResizeCount_Max.Value = Me.Num_ResizeCount_Mid.Value + 1
        End If
        If Me.Num_ResizeCount_Mid.Value <= Me.Num_ResizeCount_Min.Value Then
            Me.Num_ResizeCount_Min.Value = Me.Num_ResizeCount_Mid.Value - 1
        End If
    End Sub

    Private Sub Num_ResizeCount_Mid2_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Mid2.ValueChanged
        Me.Num_ResizeCount_Mid.Value = Me.Num_ResizeCount_Mid2.Value
        If Me.Num_ResizeCount_Mid2.Value >= Me.Num_ResizeCount_Max.Value Then
            Me.Num_ResizeCount_Max.Value = Me.Num_ResizeCount_Mid2.Value + 1
        End If
        If Me.Num_ResizeCount_Mid2.Value <= Me.Num_ResizeCount_Min.Value Then
            Me.Num_ResizeCount_Min.Value = Me.Num_ResizeCount_Mid2.Value - 1
        End If
    End Sub

    Private Sub Num_ResizeCount_Min_ValueChanged(sender As Object, e As System.EventArgs) Handles Num_ResizeCount_Min.ValueChanged
        If Me.Num_ResizeCount_Mid2.Value <= Me.Num_ResizeCount_Min.Value Then
            Me.Num_ResizeCount_Mid2.Value = Me.Num_ResizeCount_Min.Value + 1
            Me.Num_ResizeCount_Mid.Value = Me.Num_ResizeCount_Mid2.Value
            If Me.Num_ResizeCount_Mid.Value >= Me.Num_ResizeCount_Max.Value Then
                Me.Num_ResizeCount_Max.Value = Me.Num_ResizeCount_Mid.Value + 1
            End If
        End If
    End Sub

#End Region

#Region "---CheckBox Event---"

    Private Sub CheckBox_UseBaseLine_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_UseBaseLine.CheckedChanged
        If Me.CheckBox_UseBaseLine.Checked Then
            NumericUpDown_MacroPowerX.Enabled = True
            NumericUpDown_MacroPowerY.Enabled = True
            Num_ResizeCount_Mid.Enabled = False
            Num_ResizeCount_Max.Enabled = False
        Else
            NumericUpDown_MacroPowerX.Enabled = False
            NumericUpDown_MacroPowerY.Enabled = False
            Num_ResizeCount_Mid.Enabled = True
            Num_ResizeCount_Max.Enabled = True
        End If
    End Sub

    Private Sub CheckBox_UseFFT_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_UseFFT.CheckedChanged
        If Me.CheckBox_UseFFT.Checked Then
            Me.Button_CalculateFFT.Enabled = True
            Me.NumericUpDown_FFTFilterRadius.Enabled = True
        Else
            Me.Button_CalculateFFT.Enabled = False
            Me.NumericUpDown_FFTFilterRadius.Enabled = False
        End If
    End Sub

#End Region

#Region "---Setting ---"
    Private Sub Setting()
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value = Me.NumericUpDown_BlobMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value = Me.NumericUpDown_MacroMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value = Me.NumericUpDown_Circle_ByPassRadius.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFT.Value = Me.CheckBox_UseFFT.Checked
        Me.m_MuraProcess.CurrentMuraPatternRecipe.FFTFilterRadius.Value = Me.NumericUpDown_FFTFilterRadius.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseBaseLine.Value = Me.CheckBox_UseBaseLine.Checked
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroPowerX.Value = Me.NumericUpDown_MacroPowerX.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroPowerY.Value = Me.NumericUpDown_MacroPowerY.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.RemoveHVBand.Value = Me.CheckBox_RemoveHVBand.Checked
    End Sub
#End Region

#Region "--- Change Language ---"

    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_CalculateFFT.Text = res.GetString("Button_CalculateFFT.Text")
                Button_Cancel.Text = res.GetString("Button_Cancel.Text")
                Button_Save.Text = res.GetString("Button_Save.Text")
                Button_Smooth.Text = res.GetString("Button_Smooth.Text")
                GroupBox_MuraRatio.Text = res.GetString("GroupBox_MuraRatio.Text")
                GroupBox4.Text = res.GetString("GroupBox4.Text")
                Label_GlobleSmooth.Text = res.GetString("Label_GlobleSmooth.Text")
                Label_Select.Text = res.GetString("Label_Select.Text")
                Label1.Text = res.GetString("Label1.Text")
        End Select
    End Sub
#End Region

End Class