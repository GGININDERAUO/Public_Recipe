Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.IO
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraSettingBase
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_MeasProcess As ClsMeasProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_AxMDisplay As MIL_ID

    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_CurrentTab As Integer
    Private m_Boundary As ClsParameterBoundary

    Private m_Left As Boolean
    Private m_Right As Boolean
    Private m_Top As Boolean
    Private m_Bottom As Boolean
    Private m_Inverse As Boolean

    Private m_ModelChanged As Boolean
    Private m_PatternChanged As Boolean

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- �h�s�u�Ѽ� ---
    Private m_ConnectedIP As ArrayList
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraSettingBase", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo("zh-CN")
        Thread.CurrentThread.CurrentUICulture = New CultureInfo("zh-CN")
        Me.changeLanguage("zh-CN")
        '------------

        Me.m_Form = form
        Me.m_MainProcess = Me.m_Form.MainProcess
        Me.m_MuraProcess = Me.m_Form.MainProcess.MuraProcess
        Me.m_MeasProcess = Me.m_Form.MainProcess.MeasProcess

        Me.m_ModelChanged = False
        Me.m_PatternChanged = False

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_SolidBrush = New SolidBrush(Color.White)

        If Me.m_Form.GetPatternIndexInfo > Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
        End If

        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
        If image <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        '--- UI ---
        Me.m_VScrollBar = Me.m_Form.VScrollBar
        Me.m_HScrollBar = Me.m_Form.HScrollBar

        Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
        Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
        Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
        Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
        '--- UI ---

        Me.UpdateData()
        Me.UpdateUserLevel()
    End Sub

#Region "--- Dialog Event ---"
    Private Sub Dialog_MuraSettingBase_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex > Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
        End If
        Me.m_Form.ImageUpdate()
        Me.m_Form.ImageZoomAll()
        Me.Update()
    End Sub

    Private Sub Dialog_MuraSettingBase_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub
#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.TabControl_Setting.Enabled = False
                Me.Button_Save.Enabled = False
            Case 1 'PM
                Me.TabControl_Setting.Enabled = True
                Me.GroupBox_MuraFalseDefect.Enabled = False
                Me.GroupBox_ResizeFullImage.Enabled = False

                Me.ListView_Pattern.Enabled = False

                Me.Button_ImagePath.Enabled = True
                Me.NumericUpDown_DeleteDay.Enabled = True
                Me.NumericUpDown_DeleteScale.Enabled = True

                Me.Button_Save.Enabled = True
            Case 2 'ENG
                Me.TabControl_Setting.Enabled = True
                Me.GroupBox_ResizeFullImage.Enabled = True

                Me.ListView_Pattern.Enabled = True

                Me.Button_ImagePath.Enabled = True
                Me.NumericUpDown_DeleteDay.Enabled = True
                Me.NumericUpDown_DeleteScale.Enabled = True

            Case 3 'ALL
                Me.TabControl_Setting.Enabled = True
                Me.GroupBox_ResizeFullImage.Enabled = True

                Me.ListView_Pattern.Enabled = True

                Me.Button_ImagePath.Enabled = True
                Me.NumericUpDown_DeleteDay.Enabled = True
                Me.NumericUpDown_DeleteScale.Enabled = True

                Me.Button_Save.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- ConnectToMultiIP ---"
    Public Function ConnectToMultiIP() As Boolean
        Dim ipnwc As ClsIPNetWorkConfig
        Dim i As Integer
        Dim ErrMsg = ""

        Me.m_ConnectedIP = New ArrayList
        ipnwc = Me.m_MainProcess.IPNetworkConfig

        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then
                ip = New ClsIPInfo
                ip.CCDNo = i
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
                System.Threading.Thread.Sleep(200)

                If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                    ErrMsg = ErrMsg + "IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )" & " ; "
                    Me.m_MainProcess.IsIPConnected = False
                Else
                    Me.m_ConnectedIP.Add(ip.CCDNo)
                End If

            End If

        Next

        If ErrMsg <> "" Then
            MsgBox(ErrMsg, MsgBoxStyle.Critical, "[AreaGrabber]")
            Return False
        Else
            Me.m_MainProcess.IsIPConnected = True
            Return True
        End If

    End Function
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim i As Integer
        Dim mmr As ClsMuraModelRecipe
        Dim IPBootConfig As ClsIPBootConfig
        Try
            mmr = Me.m_MuraProcess.MuraModelRecipe
            IPBootConfig = Me.m_MainProcess.IPBootConfig
            Me.m_Boundary = mmr.Boundary

            Me.Text = "[Mura] Model�򥻳]�w [ " & Me.m_Form.TextBox_Product.Text & " ]"

            '--- �p��JND���ഫ�]�w ---
            If IPBootConfig.Digitizer_Datadepth.Value >= 8 Then
                mmr.Divid.Value = 2 ^ (IPBootConfig.Digitizer_Datadepth.Value - 8)
            Else
                MessageBox.Show("[Dialog_MuraSettingBase.UpdateData] Digitizer's DataDepth �ƭȳ]�w�p��8�A�Э��s�T�{ IPBootConfig��<Digitizer_Datadepth>�Ѽ�", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            '--- �Ĥ@�� ---
            Me.CheckBox_AutoAdd.Checked = mmr.AutoAddFalse.Value
            Me.NumericUpDown_FalseCount.Value = mmr.FalseCount.Value
            Me.NumericUpDown_Distance.Value = mmr.Distance.Value
            Me.NumericUpDown_AreaMisalliance.Value = mmr.AreaMisalliance.Value

            Me.NumericUpDown_FilterBandDistance.Value = mmr.FB_Distance.Value
            Me.CheckBox_UseAutoFFC.Checked = mmr.UseAutoFFC.Value
            Me.NumericUpDown_CountToChangeFFC.Value = mmr.CountToChangeFFC.Value

            '--- �ĤG�� ---
            Me.ListView_Pattern.Items.Clear()
            For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                Me.ListView_Pattern.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next

            '--- �ĥ|�� ---
            Me.TextBox_DataRootPath.Text = Me.m_MainProcess.IPBootConfig.DataRootPath.Value
            Me.NumericUpDown_DeleteDay.Value = IPBootConfig.DeleteDay.Value
            Me.NumericUpDown_DeleteScale.Value = IPBootConfig.DeleteScale.Value
            Me.NumericUpDown_ResizeCount.Value = mmr.ResizeCount.Value

            If mmr.RemoveHVSaveType.Value = "L6A" Then
                Me.ComboBox_RemoveHVSaveType.SelectedIndex = 1
            ElseIf mmr.RemoveHVSaveType.Value = "ODTest" Then
                Me.ComboBox_RemoveHVSaveType.SelectedIndex = 2
            Else
                Me.ComboBox_RemoveHVSaveType.SelectedIndex = 0
            End If

            Me.CheckBox_UseSemu.Checked = mmr.UseSemu.Value

        Catch ex As Exception
            Throw New Exception("[Dialog_MuraSettingBase.UpdateData]UpdateData Error! (" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim mmr As ClsMuraModelRecipe
        Dim IPBootConfig As ClsIPBootConfig

        Try
            mmr = Me.m_MuraProcess.MuraModelRecipe
            IPBootConfig = Me.m_MainProcess.IPBootConfig

            '--- �p��JND���ഫ�]�w ---
            If Me.m_MainProcess.IPBootConfig.Digitizer_Datadepth.Value >= 8 Then
                mmr.Divid.Value = 2 ^ (Me.m_MainProcess.IPBootConfig.Digitizer_Datadepth.Value - 8)
            Else
                MessageBox.Show("[Dialog_MuraSettingBase.UpdateData] Digitizer's DataDepth �ƭȳ]�w�p��8�A�Э��s�T�{ IPBootConfig��<Digitizer_Datadepth>�Ѽ�", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
            '--- �Ĥ@�� ---
            mmr.ResizeCount.Value = Me.NumericUpDown_ResizeCount.Value

            '--- �ĤG�� ---
            mmr.AutoAddFalse.Value = Me.CheckBox_AutoAdd.Checked
            mmr.FalseCount.Value = Me.NumericUpDown_FalseCount.Value
            mmr.Distance.Value = Me.NumericUpDown_Distance.Value
            mmr.AreaMisalliance.Value = Me.NumericUpDown_AreaMisalliance.Value

            mmr.FB_Distance.Value = Me.NumericUpDown_FilterBandDistance.Value
            mmr.UseAutoFFC.Value = Me.CheckBox_UseAutoFFC.Checked
            mmr.CountToChangeFFC.Value = Me.NumericUpDown_CountToChangeFFC.Value

            '--- �ĤT�� ---
            Me.m_MainProcess.IPBootConfig.DataRootPath.Value = Me.TextBox_DataRootPath.Text
            Me.m_MainProcess.IPBootConfig.DeleteDay.Value = Me.NumericUpDown_DeleteDay.Value
            Me.m_MainProcess.IPBootConfig.DeleteScale.Value = Me.NumericUpDown_DeleteScale.Value
            If Me.ComboBox_RemoveHVSaveType.SelectedIndex = 1 Then
                mmr.RemoveHVSaveType.Value = "L6A"
            ElseIf Me.ComboBox_RemoveHVSaveType.SelectedIndex = 2 Then
                mmr.RemoveHVSaveType.Value = "ODTest"
            Else
                mmr.RemoveHVSaveType.Value = "Standard"
            End If

            mmr.UseSemu.Value = Me.CheckBox_UseSemu.Checked

        Catch ex As Exception
            Throw New Exception("[Dialog_MuraSettingBase.Setting]Setting Error! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Compare ---"
    Private Sub Compare(ByVal mmrOld As ClsMuraModelRecipe, ByVal mmrNew As ClsMuraModelRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)

        dlm.WriteLog("********************[MuraModelRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)
        '--- �Ĥ@�� ---
        If mmrOld.AutoAddFalse.Value <> mmrNew.AutoAddFalse.Value Then
            dlm.WriteLog("[MuraModelRecipe]AutoAddFalse: " & mmrOld.AutoAddFalse.Value & " --> " & mmrNew.AutoAddFalse.Value)
            mmrOld.AutoAddFalse.Value = mmrNew.AutoAddFalse.Value
        End If
        If mmrOld.FalseCount.Value <> mmrNew.FalseCount.Value Then
            dlm.WriteLog("[MuraModelRecipe]FalseCount: " & mmrOld.FalseCount.Value & " --> " & mmrNew.FalseCount.Value)
            mmrOld.FalseCount.Value = mmrNew.FalseCount.Value
        End If
        If mmrOld.Distance.Value <> mmrNew.Distance.Value Then
            dlm.WriteLog("[MuraModelRecipe]Distance: " & mmrOld.Distance.Value & " --> " & mmrNew.Distance.Value)
            mmrOld.Distance.Value = mmrNew.Distance.Value
        End If
        If mmrOld.AreaMisalliance.Value <> mmrNew.AreaMisalliance.Value Then
            dlm.WriteLog("[MuraModelRecipe]AreaMisalliance: " & mmrOld.AreaMisalliance.Value & " --> " & mmrNew.AreaMisalliance.Value)
            mmrOld.AreaMisalliance.Value = mmrNew.AreaMisalliance.Value
        End If
        If mmrOld.FB_Distance.Value <> mmrNew.FB_Distance.Value Then
            dlm.WriteLog("[MuraModelRecipe]FB_Distance: " & mmrOld.FB_Distance.Value & " --> " & mmrNew.FB_Distance.Value)
            mmrOld.FB_Distance.Value = mmrNew.FB_Distance.Value
        End If

        If mmrOld.UseAutoFFC.Value <> mmrNew.UseAutoFFC.Value Then
            dlm.WriteLog("[MuraModelRecipe]UseAutoFFC: " & mmrOld.UseAutoFFC.Value & " --> " & mmrNew.UseAutoFFC.Value)
            mmrOld.UseAutoFFC.Value = mmrNew.UseAutoFFC.Value
        End If
        If mmrOld.CountToChangeFFC.Value <> mmrNew.CountToChangeFFC.Value Then
            dlm.WriteLog("[MuraModelRecipe]CountToChangeFFC: " & mmrOld.CountToChangeFFC.Value & " --> " & mmrNew.CountToChangeFFC.Value)
            mmrOld.CountToChangeFFC.Value = mmrNew.CountToChangeFFC.Value
        End If

        '--- Other ---
        If mmrOld.GoldenResizeCount.Value <> mmrNew.GoldenResizeCount.Value Then
            dlm.WriteLog("[MuraModelRecipe]GoldenResizeCount: " & mmrOld.GoldenResizeCount.Value & " --> " & mmrNew.GoldenResizeCount.Value)
            mmrOld.GoldenResizeCount.Value = mmrNew.GoldenResizeCount.Value
        End If
        If mmrOld.PitchX.Value <> mmrNew.PitchX.Value Then
            dlm.WriteLog("[MuraModelRecipe]PitchX: " & mmrOld.PitchX.Value & " --> " & mmrNew.PitchX.Value)
            mmrOld.PitchX.Value = mmrNew.PitchX.Value
        End If
        If mmrOld.PitchY.Value <> mmrNew.PitchY.Value Then
            dlm.WriteLog("[MuraModelRecipe]PitchY: " & mmrOld.PitchY.Value & " --> " & mmrNew.PitchY.Value)
            mmrOld.PitchX.Value = mmrNew.PitchY.Value
        End If
        If mmrOld.ResizeCount.Value <> mmrNew.ResizeCount.Value Then
            dlm.WriteLog("[MuraModelRecipe]ResizeCount: " & mmrOld.ResizeCount.Value & " --> " & mmrNew.ResizeCount.Value)
            mmrOld.ResizeCount.Value = mmrNew.ResizeCount.Value
        End If

    End Sub

    Private Sub Compare(ByVal mprOld As ClsMuraPatternRecipe, ByVal mprNew As ClsMuraPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim boundaryOld As ClsParameterBoundary
        Dim boundaryNew As ClsParameterBoundary

        dlm.WriteLog("********************[MuraPatternRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        boundaryOld = mprOld.Rim
        boundaryNew = mprNew.Rim
        If boundaryOld.TopY <> boundaryNew.TopY Then
            dlm.WriteLog("< Rim.TopY >: " & boundaryOld.TopY & " --> " & boundaryNew.TopY)
        End If
        If boundaryOld.BottomY <> boundaryNew.BottomY Then
            dlm.WriteLog("< Rim.BottomY >: " & boundaryOld.BottomY & " --> " & boundaryNew.BottomY)
        End If
        If boundaryOld.LeftX <> boundaryNew.LeftX Then
            dlm.WriteLog("< Rim.LeftX >: " & boundaryOld.LeftX & " --> " & boundaryNew.LeftX)
        End If
        If boundaryOld.RightX <> boundaryNew.RightX Then
            dlm.WriteLog("< Rim.RightX >: " & boundaryOld.RightX & " --> " & boundaryNew.RightX)
        End If

        If mprOld.UseFFC.Value <> mprNew.UseFFC.Value Then
            dlm.WriteLog("< UseFFC >: " & mprOld.UseFFC.Value & " --> " & mprNew.UseFFC.Value)
        End If
        If mprOld.AlignValue.Value <> mprNew.AlignValue.Value Then
            dlm.WriteLog("< AlignValue >: " & mprOld.AlignValue.Value & " --> " & mprNew.AlignValue.Value)
        End If
        If mprOld.AlignPercentage.Value <> mprNew.AlignPercentage.Value Then
            dlm.WriteLog("AlignPercentage >: " & mprOld.AlignPercentage.Value & " --> " & mprNew.AlignPercentage.Value)
        End If

        If mprOld.BlobMura_GlobleSmooth.Value <> mprNew.BlobMura_GlobleSmooth.Value Then
            dlm.WriteLog("< BlobMura_GlobleSmooth >: " & mprOld.BlobMura_GlobleSmooth.Value & " --> " & mprNew.BlobMura_GlobleSmooth.Value)
        End If
        If mprOld.SmoothCount.Value <> mprNew.SmoothCount.Value Then
            dlm.WriteLog("< SmoothCount >: " & mprOld.SmoothCount.Value & " --> " & mprNew.SmoothCount.Value)
        End If

        If mprOld.WhiteBlobMura_BinarizeHeight.Value <> mprNew.WhiteBlobMura_BinarizeHeight.Value Then
            dlm.WriteLog("< WhiteBlobMura_BinarizeHeight >: " & mprOld.WhiteBlobMura_BinarizeHeight.Value & " --> " & mprNew.WhiteBlobMura_BinarizeHeight.Value)
        End If
        If mprOld.WhiteMacroMura_Threshold.Value <> mprNew.WhiteMacroMura_Threshold.Value Then
            dlm.WriteLog("< WhiteMacroMura_Threshold >: " & mprOld.WhiteMacroMura_Threshold.Value & " --> " & mprNew.WhiteMacroMura_Threshold.Value)
        End If
        If mprOld.BlackBlobMura_BinarizeHeight.Value <> mprNew.BlackBlobMura_BinarizeHeight.Value Then
            dlm.WriteLog("< BlackBlobMura_BinarizeHeight >: " & mprOld.BlackBlobMura_BinarizeHeight.Value & " --> " & mprNew.BlackBlobMura_BinarizeHeight.Value)
        End If
        If mprOld.BlackMacroMura_Threshold.Value <> mprNew.BlackMacroMura_Threshold.Value Then
            dlm.WriteLog("< BlackMacroMura_Threshold >: " & mprOld.BlackMacroMura_Threshold.Value & " --> " & mprNew.BlackMacroMura_Threshold.Value)
        End If


        If mprOld.UseRound.Value <> mprNew.UseRound.Value Then
            dlm.WriteLog("< UseRound >: " & mprOld.UseRound.Value & " --> " & mprNew.UseRound.Value)
        End If
        If mprOld.WhiteMura_ThresholdHeight.Value <> mprNew.WhiteMura_ThresholdHeight.Value Then
            dlm.WriteLog("< WhiteMura_ThresholdHeight >: " & mprOld.WhiteMura_ThresholdHeight.Value & " --> " & mprNew.WhiteMura_ThresholdHeight.Value)
        End If
        If mprOld.WhiteMura_ThresholdLow.Value <> mprNew.WhiteMura_ThresholdLow.Value Then
            dlm.WriteLog("< WhiteMura_ThresholdLow >: " & mprOld.WhiteMura_ThresholdLow.Value & " --> " & mprNew.WhiteMura_ThresholdLow.Value)
        End If
        If mprOld.BlackMura_ThresholdHeight.Value <> mprNew.BlackMura_ThresholdHeight.Value Then
            dlm.WriteLog("< BlackMura_ThresholdHeight >: " & mprOld.BlackMura_ThresholdHeight.Value & " --> " & mprNew.BlackMura_ThresholdHeight.Value)
        End If
        If mprOld.BlackMura_ThresholdLow.Value <> mprNew.BlackMura_ThresholdLow.Value Then
            dlm.WriteLog("< BlackMura_ThresholdLow >: " & mprOld.BlackMura_ThresholdLow.Value & " --> " & mprNew.BlackMura_ThresholdLow.Value)
        End If

        If mprOld.UseBand.Value <> mprNew.UseBand.Value Then
            dlm.WriteLog("UseBand >: " & mprOld.UseBand.Value & " --> " & mprNew.UseBand.Value)
        End If
        If mprOld.BandMura_ResizeCount.Value <> mprNew.BandMura_ResizeCount.Value Then
            dlm.WriteLog("< BandMura_ResizeCount >: " & mprOld.BandMura_ResizeCount.Value & " --> " & mprNew.BandMura_ResizeCount.Value)
        End If
        If mprOld.BandMura_SmoothCount.Value <> mprNew.BandMura_SmoothCount.Value Then
            dlm.WriteLog("< BandMura_SmoothCount >: " & mprOld.BandMura_SmoothCount.Value & " --> " & mprNew.BandMura_SmoothCount.Value)
        End If
        If mprOld.WhiteHBand_Threshold.Value <> mprNew.WhiteHBand_Threshold.Value Then
            dlm.WriteLog("< WhiteHBand_Threshold >: " & mprOld.WhiteHBand_Threshold.Value & " --> " & mprNew.WhiteHBand_Threshold.Value)
        End If
        If mprOld.BlackHBand_Threshold.Value <> mprNew.BlackHBand_Threshold.Value Then
            dlm.WriteLog("< BlackHBand_Threshold >: " & mprOld.BlackHBand_Threshold.Value & " --> " & mprNew.BlackHBand_Threshold.Value)
        End If
        If mprOld.WhiteVBand_Threshold.Value <> mprNew.WhiteVBand_Threshold.Value Then
            dlm.WriteLog("< WhiteVBand_Threshold >: " & mprOld.WhiteVBand_Threshold.Value & " --> " & mprNew.WhiteVBand_Threshold.Value)
        End If
        If mprOld.BlackVBand_Threshold.Value <> mprNew.BlackVBand_Threshold.Value Then
            dlm.WriteLog("< BlackVBand_Threshold >: " & mprOld.BlackVBand_Threshold.Value & " --> " & mprNew.BlackVBand_Threshold.Value)
        End If

        '--- WhiteBlobMura ---
        If mprOld.WhiteBlobMura_AreaMin.Value <> mprNew.WhiteBlobMura_AreaMin.Value Then
            dlm.WriteLog("< WhiteBlobMura_AreaMin >: " & mprOld.WhiteBlobMura_AreaMin.Value & " --> " & mprNew.WhiteBlobMura_AreaMin.Value)
        End If
        If mprOld.WhiteBlobMura_AreaMax.Value <> mprNew.WhiteBlobMura_AreaMax.Value Then
            dlm.WriteLog("< WhiteBlobMura_AreaMax >: " & mprOld.WhiteBlobMura_AreaMax.Value & " --> " & mprNew.WhiteBlobMura_AreaMax.Value)
        End If
        If mprOld.WhiteBlobMura_JNDMin.Value <> mprNew.WhiteBlobMura_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteBlobMura_JNDMin >: " & mprOld.WhiteBlobMura_JNDMin.Value & " --> " & mprNew.WhiteBlobMura_JNDMin.Value)
        End If

        '--- WhiteAGM ---
        If mprOld.WhiteAGM_AreaMin.Value <> mprNew.WhiteAGM_AreaMin.Value Then
            dlm.WriteLog("< WhiteAGM_AreaMin >: " & mprOld.WhiteAGM_AreaMin.Value & " --> " & mprNew.WhiteAGM_AreaMin.Value)
        End If
        If mprOld.WhiteAGM_AreaMax.Value <> mprNew.WhiteAGM_AreaMax.Value Then
            dlm.WriteLog("< WhiteAGM_AreaMax >: " & mprOld.WhiteAGM_AreaMax.Value & " --> " & mprNew.WhiteAGM_AreaMax.Value)
        End If
        If mprOld.WhiteAGM_JNDMin.Value <> mprNew.WhiteAGM_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteAGM_JND >: " & mprOld.WhiteAGM_JNDMin.Value & " --> " & mprNew.WhiteAGM_JNDMin.Value)
        End If

        '--- WhiteMacroMura ---
        If mprOld.WhiteMacroMura_AreaMin.Value <> mprNew.WhiteMacroMura_AreaMin.Value Then
            dlm.WriteLog("< WhiteMacroMura_AreaMin >: " & mprOld.WhiteMacroMura_AreaMin.Value & " --> " & mprNew.WhiteMacroMura_AreaMin.Value)
        End If
        If mprOld.WhiteMacroMura_AreaMax.Value <> mprNew.WhiteMacroMura_AreaMax.Value Then
            dlm.WriteLog("< WhiteMacroMura_AreaMax >: " & mprOld.WhiteMacroMura_AreaMax.Value & " --> " & mprNew.WhiteMacroMura_AreaMax.Value)
        End If
        If mprOld.WhiteMacroMura_JND.Value <> mprNew.WhiteMacroMura_JND.Value Then   '10/15 Rick add
            dlm.WriteLog("< WhiteMacroMura_JND >: " & mprOld.WhiteMacroMura_JND.Value & " --> " & mprNew.WhiteMacroMura_JND.Value)
        End If

        '--- WhiteBandMura ---
        If mprOld.WhiteBandMura_WidthMin.Value <> mprNew.WhiteBandMura_WidthMin.Value Then   '2009/05/14 Rick add
            dlm.WriteLog("< WhiteBandMura_WidthMin >: " & mprOld.WhiteBandMura_WidthMin.Value & " --> " & mprNew.WhiteBandMura_WidthMin.Value)
        End If
        If mprOld.WhiteBandMura_JND.Value <> mprNew.WhiteBandMura_JND.Value Then
            dlm.WriteLog("< WhiteBandMura_JND >: " & mprOld.WhiteBandMura_JND.Value & " --> " & mprNew.WhiteBandMura_JND.Value)
        End If
        If mprOld.WhiteBandMura_SJND.Value <> mprNew.WhiteBandMura_SJND.Value Then
            dlm.WriteLog("< WhiteBandMura_SJND >: " & mprOld.WhiteBandMura_SJND.Value & " --> " & mprNew.WhiteBandMura_SJND.Value)
        End If

        '--- BlackBlobMura ---
        If mprOld.BlackBlobMura_AreaMin.Value <> mprNew.BlackBlobMura_AreaMin.Value Then
            dlm.WriteLog("< BlackBlobMura_AreaMin >: " & mprOld.BlackBlobMura_AreaMin.Value & " --> " & mprNew.BlackBlobMura_AreaMin.Value)
        End If
        If mprOld.BlackBlobMura_AreaMax.Value <> mprNew.BlackBlobMura_AreaMax.Value Then
            dlm.WriteLog("< BlackBlobMura_AreaMax >: " & mprOld.BlackBlobMura_AreaMax.Value & " --> " & mprNew.BlackBlobMura_AreaMax.Value)
        End If
        If mprOld.BlackBlobMura_JNDMin.Value <> mprNew.BlackBlobMura_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackBlobMura_JNDMin >: " & mprOld.BlackBlobMura_JNDMin.Value & " --> " & mprNew.BlackBlobMura_JNDMin.Value)
        End If

        '--- BlackAGM ---
        If mprOld.BlackAGM_AreaMin.Value <> mprNew.BlackAGM_AreaMin.Value Then
            dlm.WriteLog("< BlackAGM_AreaMin >: " & mprOld.BlackAGM_AreaMin.Value & " --> " & mprNew.BlackAGM_AreaMin.Value)
        End If
        If mprOld.BlackAGM_AreaMax.Value <> mprNew.BlackAGM_AreaMax.Value Then
            dlm.WriteLog("< BlackAGM_AreaMax >: " & mprOld.BlackAGM_AreaMax.Value & " --> " & mprNew.BlackAGM_AreaMax.Value)
        End If
        If mprOld.BlackAGM_JNDMin.Value <> mprNew.BlackAGM_JNDMin.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackAGM_JND >: " & mprOld.BlackAGM_JNDMin.Value & " --> " & mprNew.BlackAGM_JNDMin.Value)
        End If

        '--- BlackMacroMura ---
        If mprOld.BlackMacroMura_AreaMin.Value <> mprNew.BlackMacroMura_AreaMin.Value Then
            dlm.WriteLog("< BlackMacroMura_AreaMin >: " & mprOld.BlackMacroMura_AreaMin.Value & " --> " & mprNew.BlackMacroMura_AreaMin.Value)
        End If
        If mprOld.BlackMacroMura_AreaMax.Value <> mprNew.BlackMacroMura_AreaMax.Value Then
            dlm.WriteLog("< BlackMacroMura_AreaMax >: " & mprOld.BlackMacroMura_AreaMax.Value & " --> " & mprNew.BlackMacroMura_AreaMax.Value)
        End If
        If mprOld.BlackMacroMura_JND.Value <> mprNew.BlackMacroMura_JND.Value Then   '10/15 Rick add
            dlm.WriteLog("< BlackMacroMura_JND >: " & mprOld.BlackMacroMura_JND.Value & " --> " & mprNew.BlackMacroMura_JND.Value)
        End If

        '--- BlackBandMura ---
        If mprOld.BlackBandMura_WidthMin.Value <> mprNew.BlackBandMura_WidthMin.Value Then   '2009/05/14 Rick add
            dlm.WriteLog("< BlackBandMura_WidthMin >: " & mprOld.BlackBandMura_WidthMin.Value & " --> " & mprNew.BlackBandMura_WidthMin.Value)
        End If
        If mprOld.BlackBandMura_JND.Value <> mprNew.BlackBandMura_JND.Value Then
            dlm.WriteLog("< BlackBandMura_JND >: " & mprOld.BlackBandMura_JND.Value & " --> " & mprNew.BlackBandMura_JND.Value)
        End If
        If mprOld.BlackBandMura_SJND.Value <> mprNew.BlackBandMura_SJND.Value Then
            dlm.WriteLog("< BlackBandMura_SJND >: " & mprOld.BlackBandMura_SJND.Value & " --> " & mprNew.BlackBandMura_SJND.Value)
        End If

        If mprOld.SaveOriginal.Value <> mprNew.SaveOriginal.Value Then
            dlm.WriteLog("< SaveOriginal >: " & mprOld.SaveOriginal.Value & " --> " & mprNew.SaveOriginal.Value)
        End If
        If mprOld.SaveSmooth.Value <> mprNew.SaveSmooth.Value Then
            dlm.WriteLog("< SaveSmooth >: " & mprOld.SaveSmooth.Value & " --> " & mprNew.SaveSmooth.Value)
        End If

        If mprOld.SaveBlackBlob.Value <> mprNew.SaveBlackBlob.Value Then
            dlm.WriteLog("< SaveBlackBlob >: " & mprOld.SaveBlackBlob.Value & " --> " & mprNew.SaveBlackBlob.Value)
        End If
        If mprOld.SaveBlackThreshold.Value <> mprNew.SaveBlackThreshold.Value Then
            dlm.WriteLog("< SaveBlackThreshold >: " & mprOld.SaveBlackThreshold.Value & " --> " & mprNew.SaveBlackThreshold.Value)
        End If
        If mprOld.SaveBlackReconstructArea.Value <> mprNew.SaveBlackReconstructArea.Value Then
            dlm.WriteLog("< SaveBlackReconstructArea >: " & mprOld.SaveBlackReconstructArea.Value & " --> " & mprNew.SaveBlackReconstructArea.Value)
        End If
        If mprOld.SaveBlackReconstructRim.Value <> mprNew.SaveBlackReconstructRim.Value Then
            dlm.WriteLog("< SaveBlackReconstructRim >: " & mprOld.SaveBlackReconstructRim.Value & " --> " & mprNew.SaveBlackReconstructRim.Value)
        End If

        If mprOld.SaveWhiteBlob.Value <> mprNew.SaveWhiteBlob.Value Then
            dlm.WriteLog("< SaveWhiteBlob >: " & mprOld.SaveWhiteBlob.Value & " --> " & mprNew.SaveWhiteBlob.Value)
        End If
        If mprOld.SaveWhiteThreshold.Value <> mprNew.SaveWhiteThreshold.Value Then
            dlm.WriteLog("< SaveWhiteThreshold >: " & mprOld.SaveWhiteThreshold.Value & " --> " & mprNew.SaveWhiteThreshold.Value)
        End If
        If mprOld.SaveWhiteReconstructArea.Value <> mprNew.SaveWhiteReconstructArea.Value Then
            dlm.WriteLog("< SaveWhiteReconstructArea >: " & mprOld.SaveWhiteReconstructArea.Value & " --> " & mprNew.SaveWhiteReconstructArea.Value)
        End If
        If mprOld.SaveWhiteReconstructRim.Value <> mprNew.SaveWhiteReconstructRim.Value Then
            dlm.WriteLog("< SaveWhiteReconstructRim >: " & mprOld.SaveWhiteReconstructRim.Value & " --> " & mprNew.SaveWhiteReconstructRim.Value)
        End If

        If mprOld.SaveVProject.Value <> mprNew.SaveVProject.Value Then
            dlm.WriteLog("< SaveVProject >: " & mprOld.SaveVProject.Value & " --> " & mprNew.SaveVProject.Value)
        End If
        If mprOld.SaveHProject.Value <> mprNew.SaveHProject.Value Then
            dlm.WriteLog("< SaveHProject >: " & mprOld.SaveHProject.Value & " --> " & mprNew.SaveHProject.Value)
        End If

        If mprOld.SaveVBand.Value <> mprNew.SaveVBand.Value Then
            dlm.WriteLog("< SaveVBand >: " & mprOld.SaveVBand.Value & " --> " & mprNew.SaveVBand.Value)
        End If
        If mprOld.SaveHBand.Value <> mprNew.SaveHBand.Value Then
            dlm.WriteLog("< SaveHBand >: " & mprOld.SaveHBand.Value & " --> " & mprNew.SaveHBand.Value)
        End If

        If mprOld.PatternName.Value <> mprNew.PatternName.Value Then
            dlm.WriteLog("< PatternName >: " & mprOld.PatternName.Value & " --> " & mprNew.PatternName.Value)
        End If
        If mprOld.ExposureTime.Value <> mprNew.ExposureTime.Value Then
            dlm.WriteLog("< ExposureTime >: " & mprOld.ExposureTime.Value & " --> " & mprNew.ExposureTime.Value)
        End If

    End Sub

    Private Sub Compare(ByVal mpraOldOrder As ClsMuraPatternRecipeArray, ByVal mpraOld As ClsMuraPatternRecipeArray, ByVal mpraNew As ClsMuraPatternRecipeArray, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        Dim i As Integer
        Dim j As Integer
        Dim mpp As ClsMuraPatternRecipe
        Dim mppOldOrder As ClsMuraPatternRecipe
        Dim mppOld As ClsMuraPatternRecipe
        Dim mppNew As ClsMuraPatternRecipe
        Dim bool As Boolean
        Dim bools(mpraNew.Count - 1) As Boolean
        For j = 0 To mpraNew.Count - 1
            bools(j) = True
        Next
        dlm.WriteLog("**********************[MuraPattern]**************************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)
        For i = 0 To mpraOldOrder.Count - 1
            mppOldOrder = mpraOldOrder.Item(i)
            mppOld = mpraOld.Item(i)
            bool = True

            For j = 0 To mpraNew.Count - 1
                mppNew = mpraNew.Item(j)
                If mppOldOrder Is mppNew Then
                    If i <> j Then
                        dlm.WriteLog("[Mura]PatternReorder: " & i + 1 & " --> " & j + 1)
                    Else
                        dlm.WriteLog("[Mura]Pattern: " & i + 1)
                    End If
                    Me.Compare(mppOld, mppNew, dlm)
                    bool = False
                    bools(j) = False
                    Exit For
                End If
            Next
            If bool Then
                dlm.WriteLog("[Mura]PatternRemove: " & i + 1)
            End If
        Next

        For j = 0 To mpraNew.Count - 1
            If bools(j) Then
                dlm.WriteLog("[Mura]PatternAdd: " & j + 1)
            End If
        Next
        mpraOldOrder.Clear()
        mpraOld.Clear()
        For i = 0 To mpraNew.Count - 1
            mpp = mpraNew.Item(i)
            mpraOldOrder.Add(mpp)
            mpraOld.Add(New ClsMuraPatternRecipe(mpp))
        Next
    End Sub
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Save.Enabled = En
        Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- RepairPath2 ---"
    Private Sub RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
    End Sub
#End Region

#Region "--- Repair_PatternName ---"
    Private Sub Repair_PatternName(ByRef strPatternName)
        Dim strFirst As String
        Dim strSecond As String
        strFirst = Mid(strPatternName, 1, 1)
        strSecond = Mid(strPatternName, 2, 1)

        If strFirst <> "M" And strSecond <> "_" Then
            If strFirst <> "_" Then strPatternName = "_" & strPatternName
            If Mid(strPatternName, 1, 1) <> "M" Then strPatternName = "M" & strPatternName
            Exit Sub
        Else
            Exit Sub
        End If

    End Sub
#End Region

#Region "--- Change Language ---"

    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                CheckBox_AutoAdd.Text = res.GetString("CheckBox_AutoAdd.Text")
                CheckBox_UseAutoFFC.Text = res.GetString("CheckBox_UseAutoFFC.Text")
                GroupBox_ResizeFullImage.Text = res.GetString("GroupBox_ResizeFullImage.Text")
                Label_AreaMisalliance.Text = res.GetString("Label_AreaMisalliance.Text")
                Label_DeleteDay.Text = res.GetString("Label_DeleteDay.Text")
                Label_DeleteScale.Text = res.GetString("Label_DeleteScale.Text")
                Label_Distance.Text = res.GetString("Label_Distance.Text")
                Label_FalseCount.Text = res.GetString("Label_FalseCount.Text")
                Label_ImagePath.Text = res.GetString("Label_ImagePath.Text")
                Label1.Text = res.GetString("Label1.Text")
                Label2.Text = res.GetString("Label2.Text")
                Label29.Text = res.GetString("Label29.Text")
                Label3.Text = res.GetString("Label3.Text")
                TabPage_False.Text = res.GetString("TabPage_False.Text")
                TabPage_Other.Text = res.GetString("TabPage_Other.Text")
                TabPage_Pattern.Text = res.GetString("TabPage_Pattern.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_LoadImage ---"
    Private Sub Button_LoadImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim ResizeRatio As Double
        Dim fmr As ClsFuncModelRecipe
        Dim mmr As ClsMuraModelRecipe
        Dim SaveImage As Boolean = False
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Disable Button ---
            Me.Button_Enable(False)

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.RECIPE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex > Me.m_MainProcess.MuraPatternRecipeArrayOrder.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("���ˬd�Ҷ}�Ҫ��v���ɮ׬O�_�ŦX�ثeIP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                ResizeRatio = 2 ^ (-Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value)
                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 10000 '10 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraSettingBase.Button_LoadImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_LoadImage]Load Image Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                If MbufInquire(image, M_SIZE_X, M_NULL) > (ResizeRatio * Me.m_MainProcess.IPBootConfig.ImageSizeX.Value) And MbufInquire(image, M_SIZE_Y, M_NULL) > (ResizeRatio * Me.m_MainProcess.IPBootConfig.ImageSizeY.Value) Then
                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 10000 '10 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraBoundary.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                        fmr = Me.m_MainProcess.FuncProcess.FuncModelRecipe
                        mmr = Me.m_MuraProcess.MuraModelRecipe
                        mmr.Boundary.TopY = fmr.Boundary.TopY * ResizeRatio
                        mmr.Boundary.BottomY = fmr.Boundary.BottomY * ResizeRatio
                        mmr.Boundary.LeftX = fmr.Boundary.LeftX * ResizeRatio
                        mmr.Boundary.RightX = fmr.Boundary.RightX * ResizeRatio
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_LoadImage]Load Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    'Do Nothing
                Else
                    Me.m_Form.CurrentIndex0 = 2
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 2
                End If

                Me.m_Form.ImageUpdate()
                Me.m_Form.ResetScrollBar()
                Call Me.m_Form.ImageZoomAll()
            End If

            '--- Enable Button ---
            Me.Button_Enable(True)

        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.LoadImage]" & ex.Message)
            MessageBox.Show("[Dialog_MuraSettingBase.Button_LoadImage_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Close ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        If Me.m_Form.ComboBox_CCD.SelectedIndex = -1 Then
            MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]�Х���� IP No , �~��i���x�s", "ĵ�i", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Dim i As Integer
        Dim dir As String = ""
        Dim Parameter_Lists As String = ""
        Dim Selected_IP_Index As Integer

        Try
            '--- Disable Button ---
            Me.Button_Enable(False)

            Me.Setting()
            If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("**************************[MuraSave]******************************")
                Me.Compare(Me.m_MainProcess.MuraModelRecipeTemp, Me.m_MuraProcess.MuraModelRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                Me.Compare(Me.m_MainProcess.MuraPatternRecipeArrayOrder, Me.m_MainProcess.MuraPatternRecipeArrayTemp, Me.m_MuraProcess.MuraPatternRecipeArray, Me.m_MainProcess.RecipeDailyLogManager)
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern�s��]: " & Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.TextBox_Product.Text & "\Mura\*_" & Me.m_MainProcess.GrabNo)
            End If
            Me.m_MuraProcess.SaveAllMuraRecipe(Me.m_MainProcess.RECIPE_PATH, Me.m_Form.TextBox_Product.Text, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
            Me.m_MuraProcess.SaveAllFFCImages(Me.m_MainProcess.RECIPE_PATH, Me.m_Form.TextBox_Product.Text, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
            Me.m_MainProcess.SaveBoot()

            '========== ��� IP ====================
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If
            Selected_IP_Index = Me.m_Form.ComboBox_CCD.SelectedIndex

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraSettingBase Setting   ==> Request_Command = "DIALOG_MURASETTINGBASE_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURASETTINGBASE_SETTING"
                TimeOut = 200000 '200 secs

                'UI Recipe Setting -----------------------------------

                '--- �Ĥ@�� ---
                Parameter_Lists = Parameter_Lists & "AutoAddFalse," & Me.CheckBox_AutoAdd.Checked & ";" & "FalseCount," & Me.NumericUpDown_FalseCount.Value & ";" & "Distance," & Me.NumericUpDown_Distance.Value & ";" & "AreaMisalliance," & Me.NumericUpDown_AreaMisalliance.Value & ";" & _
                                  "FB_Distance," & Me.NumericUpDown_FalseCount.Value & ";" & "UseAutoFFC," & Me.CheckBox_UseAutoFFC.Checked & ";" & "CountToChangeFFC," & Me.NumericUpDown_CountToChangeFFC.Value & ";"
                '--- Others ---
                Parameter_Lists = Parameter_Lists & "DataRootPath," & Me.TextBox_DataRootPath.Text & ";" & "DeleteDay," & Me.NumericUpDown_DeleteDay.Value & ";" & "DeleteScale," & Me.NumericUpDown_DeleteScale.Value & ";" & "ResizeCount," & Me.NumericUpDown_ResizeCount.Value & ";" & _
                                  "RemoveHVSaveType," & Me.ComboBox_RemoveHVSaveType.SelectedItem.ToString & ";" & "UseSemu," & Me.CheckBox_UseSemu.Checked

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSettingBase Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Save]Dialog_MuraSettingBase Setting Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Boot Config Recipe ==> Request_Command = "SAVE_BOOT" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_BOOT"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Boot Config Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Save]Save Boot Config Recipe Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Me.m_ModelChanged Or Me.m_PatternChanged Then
                '========== �h�� IP ====================

                '[SAVE_ALL_FUNC_RECIPE] \ SAVE_ALL_MURA_RECIPE ---
                For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                    If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                        '--- �_�u�M�� ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = i
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                            MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If

                        If Me.m_IPBootConfig.MuraUI.Value Then
                            '----------------------------------------------------------------------------------------------
                            ' Save All Mura Recipe  ==> Request_Command = "SAVE_ALL_MURA_RECIPE" (Dispatcher 1)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "SAVE_ALL_MURA_RECIPE"
                                TimeOut = 200000 '200 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Mura Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Save]Save All Mura Recipe Error ! (" & ex.Message & ")")
                                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                            End Try

                            '----------------------------------------------------------------------------------------------
                            ' Save Current FFC Image ==> Request_Command = "SAVE_CURRENT_FFC_IMAGE" (Dispatcher 1)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "SAVE_CURRENT_FFC_IMAGE"
                                TimeOut = 200000 '200 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current FFC Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Save]Save Current FFC Image Error ! (" & ex.Message & ")")
                                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                            End Try
                        End If

                    End If

                Next

            Else

                '----------------------------------------------------------------------------------------------
                ' Save All Mura Recipe  ==> Request_Command = "SAVE_ALL_MURA_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_ALL_MURA_RECIPE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Mura Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Save]Save All Mura Recipe Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save Current FFC Image ==> Request_Command = "SAVE_CURRENT_FFC_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_CURRENT_FFC_IMAGE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current FFC Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraSettingBase.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Save]Save Current FFC Image Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            '--- Mura Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

            '--- Enable Button ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraSettingBase.Button_Save_Click]" & ex.Message)
            MessageBox.Show("[Dialog_MuraSettingBase.Button_Save_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_ImagePath ---"
    Private Sub Button_ImagePath_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ImagePath.Click
        Me.FolderBrowserDialog.SelectedPath = Me.TextBox_DataRootPath.Text
        Me.FolderBrowserDialog.ShowDialog()
        If Me.FolderBrowserDialog.SelectedPath <> "" Then
            Me.TextBox_DataRootPath.Text = Me.FolderBrowserDialog.SelectedPath
        End If
    End Sub
#End Region

#End Region

#Region "--- Pattern ---"

    Private Sub ListView_Pattern_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs) Handles ListView_Pattern.AfterLabelEdit
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim bool_Index As Boolean
        Dim str As String
        Dim strOld As String
        Dim PatternName As String

        '--- Disable Button ---   
        Me.Button_Enable(False)

        If Not e.Label Is Nothing Then
            If e.Label = "" Then
                e.CancelEdit = True
                MsgBox("Pattern �W�٤��i�ť�", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            Else

                '--- �إ߳s�u ---
                If Not Me.ConnectToMultiIP Then
                    '--- Enable Button ---    
                    Me.Button_Enable(True)
                    Exit Sub
                End If
                Me.m_PatternChanged = True

                bool_Index = True
                str = e.Label.ToUpper
                For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                    If e.Item <> i Then
                        If str = Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value.ToUpper Then
                            e.CancelEdit = True
                            bool_Index = False
                            MsgBox("Pattern �W�٤��i����", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If
                    End If
                Next

                PatternName = e.Label
                Repair_PatternName(PatternName)

                If bool_Index Then

                    For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                        '--- ���o Grab No ---
                        If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                            MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If

                        '--- Change CCDNo ---  
                        Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                        Me.m_MuraProcess.MuraPatternRecipeArray.Item(e.Item).PatternName.Value = PatternName
                        ClsMuraPatternRecipe.WriteXML(Me.m_MuraProcess.MuraPatternRecipeArray.Item(e.Item), Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & e.Item + 1 & ".xml")
                    Next

                    '--- Re New Label ---  
                    Me.ListView_Pattern.Items.Clear()
                    For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                        Me.ListView_Pattern.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
                    Next
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Item(e.Item + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value) = PatternName
                    Me.Update()

                    strOld = Me.m_MuraProcess.MuraPatternRecipeArray.Item(e.Item).PatternName.Value
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern Name Change]" & "Pattern�W�١G" & strOld & " ----> " & PatternName)

                    '[MURA_PATTERN_EDIT]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '--- �_�u�M�� ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                                MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Edit Mura Pattern  ==> Request_Command = "MURA_PATTERN_EDIT" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "MURA_PATTERN_EDIT"
                                TimeOut = 300000 '300 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, e.Item, PatternName, , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---  
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Edit Mura Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.ListView_Pattern_AfterLabelEdit]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---   
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.ListView_Pattern_AfterLabelEdit]Edit Mura Pattern Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_MuraSettingBase.ListView_Pattern_AfterLabelEdit]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next

                End If
            End If
        End If

        '---  Button ---   
        Me.Button_Enable(True)

        Me.ListView_Pattern.LabelEdit = False
    End Sub
    Private Sub ListView_Pattern_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView_Pattern.MouseDown
        Dim lvi As ListViewItem
        If e.Button = Windows.Forms.MouseButtons.Right Then
            lvi = Me.ListView_Pattern.GetItemAt(e.X, e.Y)
            If lvi Is Nothing Then
                Me.ToolStripMenuItem_RemovePattern.Enabled = False
            Else
                Me.ToolStripMenuItem_RemovePattern.Enabled = True
            End If
        End If
    End Sub
    Private Sub ListView_Pattern_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Pattern.MouseEnter
        Me.ListView_Pattern.ContextMenuStrip = Me.ContextMenuStrip_Pattern
    End Sub
    Private Sub ListView_Pattern_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Pattern.MouseLeave
        Me.ListView_Pattern.ContextMenuStrip = Nothing
    End Sub

    Private Sub Button_Up_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim mpr As ClsMuraPatternRecipe
        Dim image As MIL_ID = M_NULL
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim SelectPatternIndex As Integer
        Dim lvi As ListViewItem
        Dim Selected_CCDNo As Integer

        If Me.ListView_Pattern.SelectedIndices.Count > 0 Then
            Selected_CCDNo = Me.m_Form.ComboBox_CCD.SelectedIndex

            Me.m_PatternChanged = True

            '--- Disable Button ---    
            Me.Button_Enable(False)

            '--- �إ߳s�u ---
            If Not Me.ConnectToMultiIP Then
                '--- Enable Button ---   
                Me.Button_Enable(True)
                Exit Sub
            End If

            i = Me.ListView_Pattern.SelectedIndices(0)
            SelectPatternIndex = i

            If i > 0 Then
                lvi = Me.ListView_Pattern.Items.Item(i)
                Me.ListView_Pattern.Items.RemoveAt(i)
                Me.ListView_Pattern.Items.Insert(i - 1, lvi)

                For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                    '--- ���o Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                        MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.Button_Enable(True)
                        Exit Sub
                    End If

                    '--- Change CCDNo ---  
                    Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                    mpr = Me.m_MuraProcess.MuraPatternRecipeArray.Item(i)
                    Me.m_MuraProcess.MuraPatternRecipeArray.RemoveAt(i)
                    Me.m_MuraProcess.MuraPatternRecipeArray.Insert(i - 1, mpr)
                    image = Me.m_MuraProcess.Img_FFCAlignArray.Item(i)
                    Me.m_MuraProcess.Img_FFCAlignArray.RemoveAt(i)

                    Me.m_MainProcess.MuraPatternRecipeArrayTemp.RemoveAt(i)
                    Me.m_MainProcess.MuraPatternRecipeArrayTemp.Insert(i - 1, mpr)
                    Me.m_MainProcess.MuraPatternRecipeArrayOrder.RemoveAt(i)
                    Me.m_MainProcess.MuraPatternRecipeArrayOrder.Insert(i - 1, mpr)
                    Me.m_MuraProcess.Img_FFCAlignArray.Insert(i - 1, image)

                    Me.RecipeUpdate(CCDNo, GrabNo)
                Next

                If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i Then
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(i - 1, lvi.Text)
                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i - 1
                ElseIf Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i - 1 Then
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(i - 1, lvi.Text)
                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i
                    Me.m_MuraProcess.Pattern = i + 1
                Else
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(i - 1, lvi.Text)
                End If
                lvi.Focused = True
                lvi.Checked = True

                '[MURA_PATTERN_UP]
                For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                        '--- �_�u�M�� ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = i
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                            MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Move Mura Pattern Sequence Up ==> Request_Command = "MURA_PATTERN_UP" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_PATTERN_UP"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SelectPatternIndex, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---   
                            Me.Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Move Mura Pattern Up Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraSettingBase.Button_Up]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---    
                        Me.Button_Enable(True)
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Up]Move Mura Pattern Up Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraSettingBase.Button_Up]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Next

            End If

            Me.m_Form.ComboBox_CCD.SelectedIndex = Selected_CCDNo

            '--- Enable Button ---    
            Me.Button_Enable(True)
        End If

        Me.ListView_Pattern.Focus()
    End Sub
    Private Sub Button_Down_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim mpr As ClsMuraPatternRecipe
        Dim image As MIL_ID = M_NULL
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim lvi As ListViewItem
        Dim SelectPatternIndex As Integer
        Dim Selected_CCDNo As Integer

        If Me.ListView_Pattern.SelectedIndices.Count > 0 Then
            Selected_CCDNo = Me.m_Form.ComboBox_CCD.SelectedIndex

            Me.m_PatternChanged = True

            '--- Disable Button ---    
            Me.Button_Enable(False)

            '--- �إ߳s�u ---
            If Not Me.ConnectToMultiIP Then
                '--- Enable Button ---    
                Me.Button_Enable(True)
                Exit Sub
            End If

            i = Me.ListView_Pattern.SelectedIndices(0)
            SelectPatternIndex = i

            If i < Me.ListView_Pattern.Items.Count - 1 Then
                lvi = Me.ListView_Pattern.Items.Item(i)
                Me.ListView_Pattern.Items.RemoveAt(i)
                Me.ListView_Pattern.Items.Insert(i + 1, lvi)

                For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                    '--- ���o Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then

                        MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Exit Sub
                    End If

                    '--- Change CCDNo ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                    mpr = Me.m_MuraProcess.MuraPatternRecipeArray.Item(i)
                    Me.m_MuraProcess.MuraPatternRecipeArray.RemoveAt(i)
                    Me.m_MuraProcess.MuraPatternRecipeArray.Insert(i + 1, mpr)

                    Me.m_MainProcess.MuraPatternRecipeArrayTemp.RemoveAt(i)
                    Me.m_MainProcess.MuraPatternRecipeArrayTemp.Insert(i + 1, mpr)
                    Me.m_MainProcess.MuraPatternRecipeArrayOrder.RemoveAt(i)
                    Me.m_MainProcess.MuraPatternRecipeArrayOrder.Insert(i + 1, mpr)

                    image = Me.m_MuraProcess.Img_FFCAlignArray.Item(i)
                    Me.m_MuraProcess.Img_FFCAlignArray.RemoveAt(i)
                    Me.m_MuraProcess.Img_FFCAlignArray.Insert(i + 1, image)

                    RecipeUpdate(CCDNo, GrabNo)
                Next

                If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i Then
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(i + 1, lvi.Text)
                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + 1
                ElseIf Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + 1 Then
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(i + 1, lvi.Text)
                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i
                    Me.m_MuraProcess.Pattern = i + 1
                Else
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(i + 1, lvi.Text)
                End If
                lvi.Focused = True
                lvi.Checked = True
            End If

            '[MURA_PATTERN_DOWN]
            For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                    '--- �_�u�M�� ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = i
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                    If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                        MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Move Mura Pattern Sequence Down ==> Request_Command = "MURA_PATTERN_DOWN" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_PATTERN_DOWN"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SelectPatternIndex, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---   
                            Me.Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Move Mura Pattern Down Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraSettingBase.Button_Down]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---    
                        Me.Button_Enable(True)
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.Button_Down]Move Mura Pattern Down Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraSettingBase.Button_Down]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End If
            Next

            Me.m_Form.ComboBox_CCD.SelectedIndex = Selected_CCDNo

            '--- Enable Button ---    
            Me.Button_Enable(True)
        End If

        Me.ListView_Pattern.Focus()
    End Sub

    Private Sub ContextMenuStrip_Pattern_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip_Pattern.ItemClicked
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim PatternIndex As Integer
        Dim RemovePattern As String = ""
        Dim str As String
        Dim mpr As ClsMuraPatternRecipe
        Dim image As MIL_ID = M_NULL
        Dim PatternName As String = ""
        Dim SelectPattern As Integer
        Dim PatternStrs As String()

        '--- Disable Button ---   
        Me.Button_Enable(False)

        '--- �إ߳s�u ---
        If Not Me.ConnectToMultiIP Then
            '--- Enable Button ---   
            Me.Button_Enable(True)
            Exit Sub
        End If

        If e.ClickedItem Is Me.ToolStripMenuItem_AddPattern Then
            Me.m_PatternChanged = True

            i = Me.ListView_Pattern.Items.Count + 1
            str = InputBox("�п�JPatternName", "PatternName")
            If str = "" Then Exit Sub
            Me.ListView_Pattern.Items.Add(str)

            For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                '--- ���o Grab No ---
                If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                    MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count)
                    Exit Sub
                End If

                '--- �_�u�M�� ---
                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                ip = New ClsIPInfo
                ip.CCDNo = CCDNo
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                    MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.m_MainProcess.IsIPConnected = False
                End If

                '----------------------------------------------------------------------------------------------
                'Check Pattern Count & Pattern Name  ==> Request_Command = "GET_ALL_MURA_PATTERN" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "GET_ALL_MURA_PATTERN"
                    TimeOut = 300000 '300 secs
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    PatternStrs = SubSystemResult.Responses(0).Param2.Split(";")
                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If CInt(SubSystemResult.Responses(0).Param1) <> Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                            MessageBox.Show("[GET_ALL_MURA_PATTERN] Please Check CCD" & CCDNo & " , MuraModelRecipe_C" & GrabNo & ".xml PatternCount  Value Error", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count - 1)
                            'Kill IP ---    
                            Me.m_Form.Button_KillIP.PerformClick()
                            Exit Sub
                        End If
                        For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                            If PatternStrs(i) <> Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value Then
                                MessageBox.Show("[GET_ALL_MURA_PATTERN] Please Check CCD" & CCDNo & " , MuraPatternRecipe_C" & GrabNo & "_P." & i + 1 & ".xml PatternName Value Error", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count - 1)
                                'Kill IP ---    
                                Me.m_Form.Button_KillIP.PerformClick()
                                Exit Sub
                            End If
                        Next
                    Else
                        Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "GET_ALL_MURA_PATTERN Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSeting.GET_ALL_MURA_PATTERN]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count - 1)
                        'Kill IP ---    
                        Me.m_Form.Button_KillIP.PerformClick()
                        Exit Sub
                    End If

                Catch ex As Exception
                    Exit Sub
                End Try
            Next

            '--- PatternName ---
            If Me.ListView_Pattern.SelectedItems.Count = 1 Then
                PatternName = Me.ListView_Pattern.SelectedItems(0).Text
                For j = 0 To Me.ListView_Pattern.Items.Count - 1
                    If Me.ListView_Pattern.SelectedItems(0).Text = Me.ListView_Pattern.Items(j).Text Then
                        SelectPattern = j
                        Exit For
                    End If
                Next
            Else
                PatternName = Me.ListView_Pattern.Items(0).Text
                SelectPattern = 0
            End If

            For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                '--- ���o Grab No ---
                If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                    MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Exit Sub
                End If

                '--- Change CCDNo ---    
                Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = SelectPattern

                '----------------------------------------------------------------------------------------------
                ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SET_PATTERNINDEX"
                    TimeOut = 300000 '300 secs


                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    Button_Enable(True)
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value += 1
                mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
                mpr = New ClsMuraPatternRecipe(mpr)
                mpr.UseFFC.Value = False
                mpr.PatternName.Value = str
                Me.m_MuraProcess.MuraPatternRecipeArray.Add(mpr)
                Me.m_MainProcess.MuraPatternRecipeArrayTemp.Add(mpr)
                Me.m_MainProcess.MuraPatternRecipeArrayOrder.Add(mpr)
                Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Count()

                If Me.m_MuraProcess.Img_FFCAlignArray.Count < Me.m_MuraProcess.MuraPatternRecipeArray.Count Then
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, 1, 1, 16 + M_UNSIGNED, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    Me.m_MuraProcess.Img_FFCAlignArray.Add(image)
                End If

                Me.RecipeUpdate(CCDNo, GrabNo)
            Next
            Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1, str)
            Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern Add]" & "�W�[�@��Pattern�APattern�W�١G" & str)

            '[MURA_PATTERN_ADD]
            For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                    '--- �_�u�M�� ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = i
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                    If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                        MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Add Mura Pattern  ==> Request_Command = "MURA_PATTERN_ADD" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_PATTERN_ADD"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---   
                            Me.Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add Mura Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---   
                        Me.Button_Enable(True)
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]Add Mura Pattern Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End If
            Next
        Else
            If Me.ListView_Pattern.Items.Count = 1 Then
                MsgBox("�ܤ֫O�d�@��Pattern", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            Else
                If MsgBox("�O�_�R��", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    Me.m_PatternChanged = True

                    i = Me.ListView_Pattern.SelectedIndices(0)
                    PatternIndex = i

                    If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i Then
                        If i = 0 Then
                            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i
                        Else
                            If Me.m_Form.ComboBox_Pattern_MainFrm.Items.Count - 1 = i Then
                                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i - 1
                            Else
                                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + 1
                            End If
                        End If
                    End If

                    Me.ListView_Pattern.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)

                    RemovePattern = Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).PatternName.Value
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern Delete]" & "�R���@��Pattern�A�W�١G" & RemovePattern)

                    For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        '--- ���o Grab No ---
                        If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                            MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If

                        '--- Change CCDNo ---   
                        Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                        image = Me.m_MuraProcess.Img_FFCAlignArray.Item(PatternIndex)
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If
                        Me.m_MuraProcess.Img_FFCAlignArray.RemoveAt(PatternIndex)
                        Me.m_MuraProcess.Img_FFCAlignArray.Add(image)

                        Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value -= 1
                        Me.m_MuraProcess.MuraPatternRecipeArray.RemoveAt(PatternIndex)
                        Me.m_MainProcess.MuraPatternRecipeArrayTemp.RemoveAt(PatternIndex)
                        Me.m_MainProcess.MuraPatternRecipeArrayOrder.RemoveAt(PatternIndex)
                        Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Count()

                        File.Delete(Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_MainProcess.IPBootConfig.ProductList.Item(Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value).Value & "\Mura\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & PatternIndex + 1 & ".xml")
                        Me.RecipeUpdate(CCDNo, GrabNo)
                    Next

                    '[MURA_PATTERN_DELETE]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '--- �_�u�M�� ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                                MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Delete Mura Pattern  ==> Request_Command = "MURA_PATTERN_DELETE" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "MURA_PATTERN_DELETE"
                                TimeOut = 100000 '100 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RemovePattern, , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---   
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete Mura Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---    
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]Delete Mura Pattern Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next
                End If
            End If
        End If

        'Change CCDNo ---    
        Me.m_Form.ComboBox_CCD.SelectedIndex = 0

        '--- Enable Button ---   
        Me.Button_Enable(True)
    End Sub

    Private Sub RecipeUpdate(ByVal CCDNo As Integer, ByVal GrabNo As String)
        Dim i As Integer
        Dim strOld_Path As String = ""
        Dim strModelPath As String = ""
        Dim strPatternPath As String = ""
        Dim mmr As ClsMuraModelRecipe

        strOld_Path = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        strModelPath = strOld_Path & "\MuraModelRecipe_C" & GrabNo & ".xml"
        Me.RepairPath_2(strModelPath)
        If System.IO.File.Exists(strModelPath) Then
            mmr = ClsMuraModelRecipe.ReadXML(strModelPath)
            mmr.PatternCount.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Count()
            MILOperationLib.ClsMuraModelRecipe.WriteXML(mmr, strModelPath)

            For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count() - 1
                strPatternPath = strOld_Path & "\MuraPatternRecipe_C" & GrabNo & "_P" & i + 1 & ".xml"
                Me.RepairPath_2(strPatternPath)
                ClsMuraPatternRecipe.WriteXML(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i), strPatternPath)
            Next
        End If
    End Sub
#End Region

#Region "--- Model ---"
    Private Sub ListView_Model_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs)
        Dim strOld_Path As String
        Dim strNew_Mura As String
        Dim strOld_Mura As String
        Dim strNew_Func As String
        Dim strOld_Func As String
        Dim strNew_Func_Backup As String
        Dim strOld_Func_Backup As String
        Dim strNew_Measurement As String
        Dim strOld_Measurement As String
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim bool As Boolean
        Dim str As String
        Dim CurrentCCD As Integer

        If Not e.Label Is Nothing Then

            '--- Disable Button ---  
            Me.Button_Enable(False)

            If Not Me.ConnectToMultiIP Then
                '--- Enable Button ---   
                Me.Button_Enable(True)
                Exit Sub
            End If

            If e.Label = "" Then
                e.CancelEdit = True
                MsgBox("Model �W�٤��i�ť�", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            Else
                '--- Edit Model Name ---

                Me.m_ModelChanged = True
                CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

                For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    '--- ���o Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then

                        MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Exit Sub
                    End If

                    '--- Change CCDNo ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("********************[ModelRecipe]**********************")
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

                    bool = True
                    str = e.Label.ToUpper
                    For i = 0 To Me.m_MainProcess.IPBootConfig.ProductList.Count - 1
                        If e.Item <> i Then
                            If str = Me.m_MainProcess.IPBootConfig.ProductList.Item(i).Value.ToUpper Then
                                e.CancelEdit = True
                                bool = False
                                MsgBox("Model �W�٤��i����", MsgBoxStyle.Critical, "[AreaGrabber]")
                            ElseIf e.Item = i Then
                                If str = Me.m_MainProcess.IPBootConfig.ProductList.Item(i).Value.ToUpper Then
                                    e.CancelEdit = True
                                    bool = False
                                    MsgBox("Model �W�٤��i���ơA�S���j�p�g����", MsgBoxStyle.Critical, "[AreaGrabber]")
                                End If
                            End If
                        End If
                    Next


                    If bool Then
                        str = Me.m_MainProcess.IPBootConfig.ProductList.Item(e.Item).Value
                        strOld_Path = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & Me.m_MainProcess.IPBootConfig.ProductList.Item(e.Item).Value
                        Me.RepairPath_2(strOld_Path)
                        strOld_Mura = strOld_Path & "\Mura"
                        Me.RepairPath_2(strOld_Mura)
                        strNew_Mura = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & e.Label & "\Mura"
                        Me.RepairPath_2(strNew_Mura)
                        strOld_Func = strOld_Path & "\Func"
                        Me.RepairPath_2(strOld_Func)
                        strNew_Func = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & e.Label & "\Func"
                        Me.RepairPath_2(strNew_Func)
                        strOld_Func_Backup = strOld_Path & "\Func\Backup"
                        Me.RepairPath_2(strOld_Func_Backup)
                        strNew_Func_Backup = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & e.Label & "\Func\Backup"
                        Me.RepairPath_2(strNew_Func_Backup)
                        strOld_Measurement = strOld_Path & "\Measurement"
                        Me.RepairPath_2(strOld_Measurement)
                        strNew_Measurement = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & e.Label & "\Measurement"
                        Me.RepairPath_2(strNew_Measurement)

                        If Not Directory.Exists(strNew_Mura) Then
                            Directory.CreateDirectory(strNew_Mura)
                        End If
                        If Not Directory.Exists(strNew_Func) Then
                            Directory.CreateDirectory(strNew_Func)
                        End If
                        If Not Directory.Exists(strNew_Func_Backup) Then
                            Directory.CreateDirectory(strNew_Func_Backup)
                        End If
                        If Not Directory.Exists(strNew_Measurement) Then
                            Directory.CreateDirectory(strNew_Measurement)
                        End If

                        '--- �إ� Recipe ---
                        '[1][Mura Recipe]
                        Me.m_Form.CopyDirectory(strOld_Mura, strNew_Mura)

                        '[2][Func Recipe]
                        Me.m_Form.CopyDirectory(strOld_Func, strNew_Func)
                        Me.m_Form.CopyDirectory(strOld_Func_Backup, strNew_Func_Backup)

                        '[3][Measurement Recipe]
                        Me.m_Form.CopyDirectory(strOld_Measurement, strNew_Measurement)

                        '[1]
                        If Directory.Exists(strOld_Mura) Then
                            Me.m_Form.DeleteDirectory(strOld_Mura)
                        End If

                        '[2]
                        If Directory.Exists(strOld_Func & "\Backup") Then
                            Me.m_Form.DeleteDirectory(strOld_Func & "\Backup")
                        End If

                        '[3]
                        If Directory.Exists(strOld_Func) Then
                            Me.m_Form.DeleteDirectory(strOld_Func)
                        End If

                        '[4]
                        If Directory.Exists(strOld_Measurement) Then
                            Me.m_Form.DeleteDirectory(strOld_Measurement)
                        End If

                        '[5]
                        If Directory.Exists(strOld_Path) Then
                            Me.m_Form.DeleteDirectory(strOld_Path)
                        End If

                        Me.m_MainProcess.IPBootConfig.ProductList.Item(e.Item).Value = e.Label
                        If Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value = e.Item Then
                            Me.m_Form.TextBox_Product.Text = e.Label
                            Me.m_Form.MainProcess.ProductName = e.Label
                        End If
                        Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Model Name Change]" & "Model�W�١G" & str & " ---> " & e.Label)
                        Me.m_MainProcess.SaveBoot()

                    End If

                Next

                If bool Then

                    '[MODEL_EDIT]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '--- �_�u�M�� ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                                MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Edit One Model  ==> Request_Command = "MODEL_EDIT" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "MODEL_EDIT"
                                TimeOut = 300000 '300 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, e.Item, e.Label, , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---    
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Edit One Model Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---   
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Edit One Model Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next

                    '--- Change CCDNo to Current CCD ---   
                    Me.m_Form.ComboBox_CCD.SelectedIndex = CurrentCCD
                End If
            End If

            '--- Enable Button ---   
            Me.Button_Enable(True)
        End If
    End Sub


#End Region

End Class