<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_BlobMuraRound
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_BlobMuraRound))
        Me.NumericUpDown_WhiteMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Parameter = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlackMura_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlackMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.Label_ReconstructLow = New System.Windows.Forms.Label()
        Me.Label_ReconstructHeight = New System.Windows.Forms.Label()
        Me.NumericUpDown_WhiteMura_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.NumericUpDown_RimRight = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Manual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Finish = New System.Windows.Forms.RadioButton()
        Me.Label_Right = New System.Windows.Forms.Label()
        Me.GroupBox_Round = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_RimLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_Left = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_Bottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_RimBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_Top = New System.Windows.Forms.Label()
        Me.CheckBox_Show = New System.Windows.Forms.CheckBox()
        Me.Button_CalculateBlob = New System.Windows.Forms.Button()
        Me.GroupBox_Modify = New System.Windows.Forms.GroupBox()
        Me.Label_Select = New System.Windows.Forms.Label()
        Me.ComboBox_Select = New System.Windows.Forms.ComboBox()
        Me.GroupBox_Load = New System.Windows.Forms.GroupBox()
        Me.Label_BlobSmooth = New System.Windows.Forms.Label()
        Me.Button_LoadBlobSmooth = New System.Windows.Forms.Button()
        Me.BtnPre_BlobMuraRound = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.CheckBox_Rim = New System.Windows.Forms.CheckBox()
        Me.GroupBox_AutoAddORR = New System.Windows.Forms.GroupBox()
        Me.CheckBox_Show_Other_RimRegion = New System.Windows.Forms.CheckBox()
        Me.CheckBox_ORR_Mannual = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Other_RimRegion_Setting = New System.Windows.Forms.GroupBox()
        Me.Button_ORR_CLearAll = New System.Windows.Forms.Button()
        Me.Button_ORR_DeleteOne = New System.Windows.Forms.Button()
        Me.Label_ORRCount = New System.Windows.Forms.Label()
        Me.ListView_Other_RimRegion = New System.Windows.Forms.ListView()
        Me.Ch_LeftX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_TopY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_RightX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_BottomY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_White_Reconstruct_High = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_White_Reconstruct_Low = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_Black_Reconstruct_High = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_Black_Reconstruct_Low = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox_MannualAddORR = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlackMura_ORR_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BlackMura_ORR_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteMura_ORR_ReconstructLow = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight = New System.Windows.Forms.NumericUpDown()
        Me.Button_ORR_AddOne = New System.Windows.Forms.Button()
        Me.TextBox_ORR_MaxY = New System.Windows.Forms.TextBox()
        Me.lb_ORR_Bottom = New System.Windows.Forms.Label()
        Me.TextBox_ORR_MaxX = New System.Windows.Forms.TextBox()
        Me.lb_ORR_Left = New System.Windows.Forms.Label()
        Me.lb_ORR_Right = New System.Windows.Forms.Label()
        Me.TextBox_ORR_MinX = New System.Windows.Forms.TextBox()
        Me.TextBox_ORR_MinY = New System.Windows.Forms.TextBox()
        Me.lb_ORR_Top = New System.Windows.Forms.Label()
        Me.CheckBox_WhiteRimBlobValue = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BlackRimBlobValue = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WhiteRimBlobValue = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_BlackRimBlobValue = New System.Windows.Forms.CheckBox()
        CType(Me.NumericUpDown_WhiteMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Parameter.SuspendLayout()
        CType(Me.NumericUpDown_BlackMura_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlackMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimRight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Round.SuspendLayout()
        CType(Me.NumericUpDown_RimLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_RimBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Modify.SuspendLayout()
        Me.GroupBox_Load.SuspendLayout()
        Me.GroupBox_AutoAddORR.SuspendLayout()
        Me.GroupBox_Other_RimRegion_Setting.SuspendLayout()
        Me.GroupBox_MannualAddORR.SuspendLayout()
        CType(Me.NumericUpDown_BlackMura_ORR_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BlackMura_ORR_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteMura_ORR_ReconstructLow, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NumericUpDown_BlackRimBlobValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WhiteRimBlobValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NumericUpDown_WhiteMura_ReconstructLow
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteMura_ReconstructLow, "NumericUpDown_WhiteMura_ReconstructLow")
        Me.NumericUpDown_WhiteMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_ReconstructLow.Name = "NumericUpDown_WhiteMura_ReconstructLow"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_WhiteMura_ReconstructLow, resources.GetString("NumericUpDown_WhiteMura_ReconstructLow.ToolTip"))
        '
        'GroupBox_Parameter
        '
        resources.ApplyResources(Me.GroupBox_Parameter, "GroupBox_Parameter")
        Me.GroupBox_Parameter.Controls.Add(Me.Label1)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_BlackMura_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_BlackMura_ReconstructHeight)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_WhiteMura_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_ReconstructLow)
        Me.GroupBox_Parameter.Controls.Add(Me.Label_ReconstructHeight)
        Me.GroupBox_Parameter.Controls.Add(Me.NumericUpDown_WhiteMura_ReconstructHeight)
        Me.GroupBox_Parameter.Name = "GroupBox_Parameter"
        Me.GroupBox_Parameter.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_Parameter, resources.GetString("GroupBox_Parameter.ToolTip"))
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        Me.ToolTip1.SetToolTip(Me.Label1, resources.GetString("Label1.ToolTip"))
        '
        'NumericUpDown_BlackMura_ReconstructLow
        '
        resources.ApplyResources(Me.NumericUpDown_BlackMura_ReconstructLow, "NumericUpDown_BlackMura_ReconstructLow")
        Me.NumericUpDown_BlackMura_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_ReconstructLow.Name = "NumericUpDown_BlackMura_ReconstructLow"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_BlackMura_ReconstructLow, resources.GetString("NumericUpDown_BlackMura_ReconstructLow.ToolTip"))
        '
        'NumericUpDown_BlackMura_ReconstructHeight
        '
        resources.ApplyResources(Me.NumericUpDown_BlackMura_ReconstructHeight, "NumericUpDown_BlackMura_ReconstructHeight")
        Me.NumericUpDown_BlackMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_ReconstructHeight.Name = "NumericUpDown_BlackMura_ReconstructHeight"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_BlackMura_ReconstructHeight, resources.GetString("NumericUpDown_BlackMura_ReconstructHeight.ToolTip"))
        '
        'Label_ReconstructLow
        '
        resources.ApplyResources(Me.Label_ReconstructLow, "Label_ReconstructLow")
        Me.Label_ReconstructLow.Name = "Label_ReconstructLow"
        Me.ToolTip1.SetToolTip(Me.Label_ReconstructLow, resources.GetString("Label_ReconstructLow.ToolTip"))
        '
        'Label_ReconstructHeight
        '
        resources.ApplyResources(Me.Label_ReconstructHeight, "Label_ReconstructHeight")
        Me.Label_ReconstructHeight.Name = "Label_ReconstructHeight"
        Me.ToolTip1.SetToolTip(Me.Label_ReconstructHeight, resources.GetString("Label_ReconstructHeight.ToolTip"))
        '
        'NumericUpDown_WhiteMura_ReconstructHeight
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteMura_ReconstructHeight, "NumericUpDown_WhiteMura_ReconstructHeight")
        Me.NumericUpDown_WhiteMura_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_ReconstructHeight.Name = "NumericUpDown_WhiteMura_ReconstructHeight"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_WhiteMura_ReconstructHeight, resources.GetString("NumericUpDown_WhiteMura_ReconstructHeight.ToolTip"))
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        Me.ToolTip1.SetToolTip(Me.Button_Cancel, resources.GetString("Button_Cancel.ToolTip"))
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        Me.ToolTip1.SetToolTip(Me.Button_Save, resources.GetString("Button_Save.ToolTip"))
        '
        'NumericUpDown_RimRight
        '
        resources.ApplyResources(Me.NumericUpDown_RimRight, "NumericUpDown_RimRight")
        Me.NumericUpDown_RimRight.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_RimRight.Name = "NumericUpDown_RimRight"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_RimRight, resources.GetString("NumericUpDown_RimRight.ToolTip"))
        Me.NumericUpDown_RimRight.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'RadioButton_Manual
        '
        resources.ApplyResources(Me.RadioButton_Manual, "RadioButton_Manual")
        Me.RadioButton_Manual.Name = "RadioButton_Manual"
        Me.ToolTip1.SetToolTip(Me.RadioButton_Manual, resources.GetString("RadioButton_Manual.ToolTip"))
        '
        'RadioButton_Finish
        '
        resources.ApplyResources(Me.RadioButton_Finish, "RadioButton_Finish")
        Me.RadioButton_Finish.Name = "RadioButton_Finish"
        Me.ToolTip1.SetToolTip(Me.RadioButton_Finish, resources.GetString("RadioButton_Finish.ToolTip"))
        '
        'Label_Right
        '
        resources.ApplyResources(Me.Label_Right, "Label_Right")
        Me.Label_Right.Name = "Label_Right"
        Me.ToolTip1.SetToolTip(Me.Label_Right, resources.GetString("Label_Right.ToolTip"))
        '
        'GroupBox_Round
        '
        resources.ApplyResources(Me.GroupBox_Round, "GroupBox_Round")
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimRight)
        Me.GroupBox_Round.Controls.Add(Me.Label_Right)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimLeft)
        Me.GroupBox_Round.Controls.Add(Me.Label_Left)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimTop)
        Me.GroupBox_Round.Controls.Add(Me.Label_Bottom)
        Me.GroupBox_Round.Controls.Add(Me.NumericUpDown_RimBottom)
        Me.GroupBox_Round.Controls.Add(Me.Label_Top)
        Me.GroupBox_Round.Name = "GroupBox_Round"
        Me.GroupBox_Round.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_Round, resources.GetString("GroupBox_Round.ToolTip"))
        '
        'NumericUpDown_RimLeft
        '
        resources.ApplyResources(Me.NumericUpDown_RimLeft, "NumericUpDown_RimLeft")
        Me.NumericUpDown_RimLeft.Maximum = New Decimal(New Integer() {1600, 0, 0, 0})
        Me.NumericUpDown_RimLeft.Name = "NumericUpDown_RimLeft"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_RimLeft, resources.GetString("NumericUpDown_RimLeft.ToolTip"))
        Me.NumericUpDown_RimLeft.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Left
        '
        resources.ApplyResources(Me.Label_Left, "Label_Left")
        Me.Label_Left.Name = "Label_Left"
        Me.ToolTip1.SetToolTip(Me.Label_Left, resources.GetString("Label_Left.ToolTip"))
        '
        'NumericUpDown_RimTop
        '
        resources.ApplyResources(Me.NumericUpDown_RimTop, "NumericUpDown_RimTop")
        Me.NumericUpDown_RimTop.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_RimTop.Name = "NumericUpDown_RimTop"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_RimTop, resources.GetString("NumericUpDown_RimTop.ToolTip"))
        Me.NumericUpDown_RimTop.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Bottom
        '
        resources.ApplyResources(Me.Label_Bottom, "Label_Bottom")
        Me.Label_Bottom.Name = "Label_Bottom"
        Me.ToolTip1.SetToolTip(Me.Label_Bottom, resources.GetString("Label_Bottom.ToolTip"))
        '
        'NumericUpDown_RimBottom
        '
        resources.ApplyResources(Me.NumericUpDown_RimBottom, "NumericUpDown_RimBottom")
        Me.NumericUpDown_RimBottom.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_RimBottom.Name = "NumericUpDown_RimBottom"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_RimBottom, resources.GetString("NumericUpDown_RimBottom.ToolTip"))
        Me.NumericUpDown_RimBottom.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Top
        '
        resources.ApplyResources(Me.Label_Top, "Label_Top")
        Me.Label_Top.Name = "Label_Top"
        Me.ToolTip1.SetToolTip(Me.Label_Top, resources.GetString("Label_Top.ToolTip"))
        '
        'CheckBox_Show
        '
        resources.ApplyResources(Me.CheckBox_Show, "CheckBox_Show")
        Me.CheckBox_Show.Name = "CheckBox_Show"
        Me.ToolTip1.SetToolTip(Me.CheckBox_Show, resources.GetString("CheckBox_Show.ToolTip"))
        '
        'Button_CalculateBlob
        '
        resources.ApplyResources(Me.Button_CalculateBlob, "Button_CalculateBlob")
        Me.Button_CalculateBlob.Name = "Button_CalculateBlob"
        Me.ToolTip1.SetToolTip(Me.Button_CalculateBlob, resources.GetString("Button_CalculateBlob.ToolTip"))
        '
        'GroupBox_Modify
        '
        resources.ApplyResources(Me.GroupBox_Modify, "GroupBox_Modify")
        Me.GroupBox_Modify.Controls.Add(Me.CheckBox_Show)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Manual)
        Me.GroupBox_Modify.Controls.Add(Me.RadioButton_Finish)
        Me.GroupBox_Modify.Controls.Add(Me.GroupBox_Round)
        Me.GroupBox_Modify.Name = "GroupBox_Modify"
        Me.GroupBox_Modify.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_Modify, resources.GetString("GroupBox_Modify.ToolTip"))
        '
        'Label_Select
        '
        resources.ApplyResources(Me.Label_Select, "Label_Select")
        Me.Label_Select.Name = "Label_Select"
        Me.ToolTip1.SetToolTip(Me.Label_Select, resources.GetString("Label_Select.ToolTip"))
        '
        'ComboBox_Select
        '
        resources.ApplyResources(Me.ComboBox_Select, "ComboBox_Select")
        Me.ComboBox_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Select.Name = "ComboBox_Select"
        Me.ToolTip1.SetToolTip(Me.ComboBox_Select, resources.GetString("ComboBox_Select.ToolTip"))
        '
        'GroupBox_Load
        '
        resources.ApplyResources(Me.GroupBox_Load, "GroupBox_Load")
        Me.GroupBox_Load.Controls.Add(Me.Label_BlobSmooth)
        Me.GroupBox_Load.Controls.Add(Me.Button_LoadBlobSmooth)
        Me.GroupBox_Load.Name = "GroupBox_Load"
        Me.GroupBox_Load.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_Load, resources.GetString("GroupBox_Load.ToolTip"))
        '
        'Label_BlobSmooth
        '
        resources.ApplyResources(Me.Label_BlobSmooth, "Label_BlobSmooth")
        Me.Label_BlobSmooth.Name = "Label_BlobSmooth"
        Me.ToolTip1.SetToolTip(Me.Label_BlobSmooth, resources.GetString("Label_BlobSmooth.ToolTip"))
        '
        'Button_LoadBlobSmooth
        '
        resources.ApplyResources(Me.Button_LoadBlobSmooth, "Button_LoadBlobSmooth")
        Me.Button_LoadBlobSmooth.Name = "Button_LoadBlobSmooth"
        Me.ToolTip1.SetToolTip(Me.Button_LoadBlobSmooth, resources.GetString("Button_LoadBlobSmooth.ToolTip"))
        '
        'BtnPre_BlobMuraRound
        '
        resources.ApplyResources(Me.BtnPre_BlobMuraRound, "BtnPre_BlobMuraRound")
        Me.BtnPre_BlobMuraRound.Name = "BtnPre_BlobMuraRound"
        Me.ToolTip1.SetToolTip(Me.BtnPre_BlobMuraRound, resources.GetString("BtnPre_BlobMuraRound.ToolTip"))
        Me.BtnPre_BlobMuraRound.UseVisualStyleBackColor = True
        '
        'ToolTip1
        '
        Me.ToolTip1.ForeColor = System.Drawing.SystemColors.Highlight
        Me.ToolTip1.IsBalloon = True
        '
        'CheckBox_Rim
        '
        resources.ApplyResources(Me.CheckBox_Rim, "CheckBox_Rim")
        Me.CheckBox_Rim.Name = "CheckBox_Rim"
        Me.ToolTip1.SetToolTip(Me.CheckBox_Rim, resources.GetString("CheckBox_Rim.ToolTip"))
        '
        'GroupBox_AutoAddORR
        '
        resources.ApplyResources(Me.GroupBox_AutoAddORR, "GroupBox_AutoAddORR")
        Me.GroupBox_AutoAddORR.Controls.Add(Me.CheckBox_Show_Other_RimRegion)
        Me.GroupBox_AutoAddORR.Controls.Add(Me.CheckBox_ORR_Mannual)
        Me.GroupBox_AutoAddORR.Name = "GroupBox_AutoAddORR"
        Me.GroupBox_AutoAddORR.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_AutoAddORR, resources.GetString("GroupBox_AutoAddORR.ToolTip"))
        '
        'CheckBox_Show_Other_RimRegion
        '
        resources.ApplyResources(Me.CheckBox_Show_Other_RimRegion, "CheckBox_Show_Other_RimRegion")
        Me.CheckBox_Show_Other_RimRegion.Name = "CheckBox_Show_Other_RimRegion"
        Me.ToolTip1.SetToolTip(Me.CheckBox_Show_Other_RimRegion, resources.GetString("CheckBox_Show_Other_RimRegion.ToolTip"))
        Me.CheckBox_Show_Other_RimRegion.UseVisualStyleBackColor = True
        '
        'CheckBox_ORR_Mannual
        '
        resources.ApplyResources(Me.CheckBox_ORR_Mannual, "CheckBox_ORR_Mannual")
        Me.CheckBox_ORR_Mannual.Name = "CheckBox_ORR_Mannual"
        Me.ToolTip1.SetToolTip(Me.CheckBox_ORR_Mannual, resources.GetString("CheckBox_ORR_Mannual.ToolTip"))
        Me.CheckBox_ORR_Mannual.UseVisualStyleBackColor = True
        '
        'GroupBox_Other_RimRegion_Setting
        '
        resources.ApplyResources(Me.GroupBox_Other_RimRegion_Setting, "GroupBox_Other_RimRegion_Setting")
        Me.GroupBox_Other_RimRegion_Setting.Controls.Add(Me.Button_ORR_CLearAll)
        Me.GroupBox_Other_RimRegion_Setting.Controls.Add(Me.Button_ORR_DeleteOne)
        Me.GroupBox_Other_RimRegion_Setting.Controls.Add(Me.Label_ORRCount)
        Me.GroupBox_Other_RimRegion_Setting.Controls.Add(Me.ListView_Other_RimRegion)
        Me.GroupBox_Other_RimRegion_Setting.Name = "GroupBox_Other_RimRegion_Setting"
        Me.GroupBox_Other_RimRegion_Setting.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_Other_RimRegion_Setting, resources.GetString("GroupBox_Other_RimRegion_Setting.ToolTip"))
        '
        'Button_ORR_CLearAll
        '
        resources.ApplyResources(Me.Button_ORR_CLearAll, "Button_ORR_CLearAll")
        Me.Button_ORR_CLearAll.Name = "Button_ORR_CLearAll"
        Me.ToolTip1.SetToolTip(Me.Button_ORR_CLearAll, resources.GetString("Button_ORR_CLearAll.ToolTip"))
        Me.Button_ORR_CLearAll.UseVisualStyleBackColor = True
        '
        'Button_ORR_DeleteOne
        '
        resources.ApplyResources(Me.Button_ORR_DeleteOne, "Button_ORR_DeleteOne")
        Me.Button_ORR_DeleteOne.Name = "Button_ORR_DeleteOne"
        Me.ToolTip1.SetToolTip(Me.Button_ORR_DeleteOne, resources.GetString("Button_ORR_DeleteOne.ToolTip"))
        Me.Button_ORR_DeleteOne.UseVisualStyleBackColor = True
        '
        'Label_ORRCount
        '
        resources.ApplyResources(Me.Label_ORRCount, "Label_ORRCount")
        Me.Label_ORRCount.Name = "Label_ORRCount"
        Me.ToolTip1.SetToolTip(Me.Label_ORRCount, resources.GetString("Label_ORRCount.ToolTip"))
        '
        'ListView_Other_RimRegion
        '
        resources.ApplyResources(Me.ListView_Other_RimRegion, "ListView_Other_RimRegion")
        Me.ListView_Other_RimRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Ch_LeftX, Me.Ch_TopY, Me.Ch_RightX, Me.Ch_BottomY, Me.Ch_White_Reconstruct_High, Me.Ch_White_Reconstruct_Low, Me.Ch_Black_Reconstruct_High, Me.Ch_Black_Reconstruct_Low})
        Me.ListView_Other_RimRegion.FullRowSelect = True
        Me.ListView_Other_RimRegion.GridLines = True
        Me.ListView_Other_RimRegion.Name = "ListView_Other_RimRegion"
        Me.ToolTip1.SetToolTip(Me.ListView_Other_RimRegion, resources.GetString("ListView_Other_RimRegion.ToolTip"))
        Me.ListView_Other_RimRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_Other_RimRegion.View = System.Windows.Forms.View.Details
        '
        'Ch_LeftX
        '
        resources.ApplyResources(Me.Ch_LeftX, "Ch_LeftX")
        '
        'Ch_TopY
        '
        resources.ApplyResources(Me.Ch_TopY, "Ch_TopY")
        '
        'Ch_RightX
        '
        resources.ApplyResources(Me.Ch_RightX, "Ch_RightX")
        '
        'Ch_BottomY
        '
        resources.ApplyResources(Me.Ch_BottomY, "Ch_BottomY")
        '
        'Ch_White_Reconstruct_High
        '
        resources.ApplyResources(Me.Ch_White_Reconstruct_High, "Ch_White_Reconstruct_High")
        '
        'Ch_White_Reconstruct_Low
        '
        resources.ApplyResources(Me.Ch_White_Reconstruct_Low, "Ch_White_Reconstruct_Low")
        '
        'Ch_Black_Reconstruct_High
        '
        resources.ApplyResources(Me.Ch_Black_Reconstruct_High, "Ch_Black_Reconstruct_High")
        '
        'Ch_Black_Reconstruct_Low
        '
        resources.ApplyResources(Me.Ch_Black_Reconstruct_Low, "Ch_Black_Reconstruct_Low")
        '
        'GroupBox_MannualAddORR
        '
        resources.ApplyResources(Me.GroupBox_MannualAddORR, "GroupBox_MannualAddORR")
        Me.GroupBox_MannualAddORR.Controls.Add(Me.Label2)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.NumericUpDown_BlackMura_ORR_ReconstructLow)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.NumericUpDown_BlackMura_ORR_ReconstructHeight)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.NumericUpDown_WhiteMura_ORR_ReconstructLow)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.Label3)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.Label4)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.Button_ORR_AddOne)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.TextBox_ORR_MaxY)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.lb_ORR_Bottom)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.TextBox_ORR_MaxX)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.lb_ORR_Left)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.lb_ORR_Right)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.TextBox_ORR_MinX)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.TextBox_ORR_MinY)
        Me.GroupBox_MannualAddORR.Controls.Add(Me.lb_ORR_Top)
        Me.GroupBox_MannualAddORR.Name = "GroupBox_MannualAddORR"
        Me.GroupBox_MannualAddORR.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox_MannualAddORR, resources.GetString("GroupBox_MannualAddORR.ToolTip"))
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        Me.ToolTip1.SetToolTip(Me.Label2, resources.GetString("Label2.ToolTip"))
        '
        'NumericUpDown_BlackMura_ORR_ReconstructLow
        '
        resources.ApplyResources(Me.NumericUpDown_BlackMura_ORR_ReconstructLow, "NumericUpDown_BlackMura_ORR_ReconstructLow")
        Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Name = "NumericUpDown_BlackMura_ORR_ReconstructLow"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_BlackMura_ORR_ReconstructLow, resources.GetString("NumericUpDown_BlackMura_ORR_ReconstructLow.ToolTip"))
        '
        'NumericUpDown_BlackMura_ORR_ReconstructHeight
        '
        resources.ApplyResources(Me.NumericUpDown_BlackMura_ORR_ReconstructHeight, "NumericUpDown_BlackMura_ORR_ReconstructHeight")
        Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Name = "NumericUpDown_BlackMura_ORR_ReconstructHeight"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_BlackMura_ORR_ReconstructHeight, resources.GetString("NumericUpDown_BlackMura_ORR_ReconstructHeight.ToolTip"))
        '
        'NumericUpDown_WhiteMura_ORR_ReconstructLow
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteMura_ORR_ReconstructLow, "NumericUpDown_WhiteMura_ORR_ReconstructLow")
        Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Name = "NumericUpDown_WhiteMura_ORR_ReconstructLow"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_WhiteMura_ORR_ReconstructLow, resources.GetString("NumericUpDown_WhiteMura_ORR_ReconstructLow.ToolTip"))
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        Me.ToolTip1.SetToolTip(Me.Label3, resources.GetString("Label3.ToolTip"))
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        Me.ToolTip1.SetToolTip(Me.Label4, resources.GetString("Label4.ToolTip"))
        '
        'NumericUpDown_WhiteMura_ORR_ReconstructHeight
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight, "NumericUpDown_WhiteMura_ORR_ReconstructHeight")
        Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Name = "NumericUpDown_WhiteMura_ORR_ReconstructHeight"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight, resources.GetString("NumericUpDown_WhiteMura_ORR_ReconstructHeight.ToolTip"))
        '
        'Button_ORR_AddOne
        '
        resources.ApplyResources(Me.Button_ORR_AddOne, "Button_ORR_AddOne")
        Me.Button_ORR_AddOne.Name = "Button_ORR_AddOne"
        Me.ToolTip1.SetToolTip(Me.Button_ORR_AddOne, resources.GetString("Button_ORR_AddOne.ToolTip"))
        Me.Button_ORR_AddOne.UseVisualStyleBackColor = True
        '
        'TextBox_ORR_MaxY
        '
        resources.ApplyResources(Me.TextBox_ORR_MaxY, "TextBox_ORR_MaxY")
        Me.TextBox_ORR_MaxY.Name = "TextBox_ORR_MaxY"
        Me.ToolTip1.SetToolTip(Me.TextBox_ORR_MaxY, resources.GetString("TextBox_ORR_MaxY.ToolTip"))
        '
        'lb_ORR_Bottom
        '
        resources.ApplyResources(Me.lb_ORR_Bottom, "lb_ORR_Bottom")
        Me.lb_ORR_Bottom.Name = "lb_ORR_Bottom"
        Me.ToolTip1.SetToolTip(Me.lb_ORR_Bottom, resources.GetString("lb_ORR_Bottom.ToolTip"))
        '
        'TextBox_ORR_MaxX
        '
        resources.ApplyResources(Me.TextBox_ORR_MaxX, "TextBox_ORR_MaxX")
        Me.TextBox_ORR_MaxX.Name = "TextBox_ORR_MaxX"
        Me.ToolTip1.SetToolTip(Me.TextBox_ORR_MaxX, resources.GetString("TextBox_ORR_MaxX.ToolTip"))
        '
        'lb_ORR_Left
        '
        resources.ApplyResources(Me.lb_ORR_Left, "lb_ORR_Left")
        Me.lb_ORR_Left.Name = "lb_ORR_Left"
        Me.ToolTip1.SetToolTip(Me.lb_ORR_Left, resources.GetString("lb_ORR_Left.ToolTip"))
        '
        'lb_ORR_Right
        '
        resources.ApplyResources(Me.lb_ORR_Right, "lb_ORR_Right")
        Me.lb_ORR_Right.Name = "lb_ORR_Right"
        Me.ToolTip1.SetToolTip(Me.lb_ORR_Right, resources.GetString("lb_ORR_Right.ToolTip"))
        '
        'TextBox_ORR_MinX
        '
        resources.ApplyResources(Me.TextBox_ORR_MinX, "TextBox_ORR_MinX")
        Me.TextBox_ORR_MinX.Name = "TextBox_ORR_MinX"
        Me.ToolTip1.SetToolTip(Me.TextBox_ORR_MinX, resources.GetString("TextBox_ORR_MinX.ToolTip"))
        '
        'TextBox_ORR_MinY
        '
        resources.ApplyResources(Me.TextBox_ORR_MinY, "TextBox_ORR_MinY")
        Me.TextBox_ORR_MinY.Name = "TextBox_ORR_MinY"
        Me.ToolTip1.SetToolTip(Me.TextBox_ORR_MinY, resources.GetString("TextBox_ORR_MinY.ToolTip"))
        '
        'lb_ORR_Top
        '
        resources.ApplyResources(Me.lb_ORR_Top, "lb_ORR_Top")
        Me.lb_ORR_Top.Name = "lb_ORR_Top"
        Me.ToolTip1.SetToolTip(Me.lb_ORR_Top, resources.GetString("lb_ORR_Top.ToolTip"))
        '
        'CheckBox_WhiteRimBlobValue
        '
        resources.ApplyResources(Me.CheckBox_WhiteRimBlobValue, "CheckBox_WhiteRimBlobValue")
        Me.CheckBox_WhiteRimBlobValue.Name = "CheckBox_WhiteRimBlobValue"
        Me.ToolTip1.SetToolTip(Me.CheckBox_WhiteRimBlobValue, resources.GetString("CheckBox_WhiteRimBlobValue.ToolTip"))
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_BlackRimBlobValue)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_WhiteRimBlobValue)
        Me.GroupBox1.Controls.Add(Me.CheckBox_BlackRimBlobValue)
        Me.GroupBox1.Controls.Add(Me.CheckBox_WhiteRimBlobValue)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        Me.ToolTip1.SetToolTip(Me.GroupBox1, resources.GetString("GroupBox1.ToolTip"))
        '
        'NumericUpDown_BlackRimBlobValue
        '
        resources.ApplyResources(Me.NumericUpDown_BlackRimBlobValue, "NumericUpDown_BlackRimBlobValue")
        Me.NumericUpDown_BlackRimBlobValue.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_BlackRimBlobValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BlackRimBlobValue.Name = "NumericUpDown_BlackRimBlobValue"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_BlackRimBlobValue, resources.GetString("NumericUpDown_BlackRimBlobValue.ToolTip"))
        Me.NumericUpDown_BlackRimBlobValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_WhiteRimBlobValue
        '
        resources.ApplyResources(Me.NumericUpDown_WhiteRimBlobValue, "NumericUpDown_WhiteRimBlobValue")
        Me.NumericUpDown_WhiteRimBlobValue.Maximum = New Decimal(New Integer() {1200, 0, 0, 0})
        Me.NumericUpDown_WhiteRimBlobValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_WhiteRimBlobValue.Name = "NumericUpDown_WhiteRimBlobValue"
        Me.ToolTip1.SetToolTip(Me.NumericUpDown_WhiteRimBlobValue, resources.GetString("NumericUpDown_WhiteRimBlobValue.ToolTip"))
        Me.NumericUpDown_WhiteRimBlobValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CheckBox_BlackRimBlobValue
        '
        resources.ApplyResources(Me.CheckBox_BlackRimBlobValue, "CheckBox_BlackRimBlobValue")
        Me.CheckBox_BlackRimBlobValue.Name = "CheckBox_BlackRimBlobValue"
        Me.ToolTip1.SetToolTip(Me.CheckBox_BlackRimBlobValue, resources.GetString("CheckBox_BlackRimBlobValue.ToolTip"))
        '
        'Dialog_BlobMuraRound
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox_MannualAddORR)
        Me.Controls.Add(Me.GroupBox_AutoAddORR)
        Me.Controls.Add(Me.GroupBox_Other_RimRegion_Setting)
        Me.Controls.Add(Me.CheckBox_Rim)
        Me.Controls.Add(Me.BtnPre_BlobMuraRound)
        Me.Controls.Add(Me.GroupBox_Parameter)
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.Button_CalculateBlob)
        Me.Controls.Add(Me.GroupBox_Modify)
        Me.Controls.Add(Me.Label_Select)
        Me.Controls.Add(Me.ComboBox_Select)
        Me.Controls.Add(Me.GroupBox_Load)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_BlobMuraRound"
        Me.ShowInTaskbar = False
        Me.ToolTip1.SetToolTip(Me, resources.GetString("$this.ToolTip"))
        CType(Me.NumericUpDown_WhiteMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Parameter.ResumeLayout(False)
        Me.GroupBox_Parameter.PerformLayout()
        CType(Me.NumericUpDown_BlackMura_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlackMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteMura_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimRight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Round.ResumeLayout(False)
        CType(Me.NumericUpDown_RimLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_RimBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Modify.ResumeLayout(False)
        Me.GroupBox_Load.ResumeLayout(False)
        Me.GroupBox_Load.PerformLayout()
        Me.GroupBox_AutoAddORR.ResumeLayout(False)
        Me.GroupBox_AutoAddORR.PerformLayout()
        Me.GroupBox_Other_RimRegion_Setting.ResumeLayout(False)
        Me.GroupBox_Other_RimRegion_Setting.PerformLayout()
        Me.GroupBox_MannualAddORR.ResumeLayout(False)
        Me.GroupBox_MannualAddORR.PerformLayout()
        CType(Me.NumericUpDown_BlackMura_ORR_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BlackMura_ORR_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteMura_ORR_ReconstructLow, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.NumericUpDown_BlackRimBlobValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WhiteRimBlobValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

End Sub
    Friend WithEvents NumericUpDown_WhiteMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_Parameter As System.Windows.Forms.GroupBox
    Friend WithEvents Label_ReconstructLow As System.Windows.Forms.Label
    Friend WithEvents Label_ReconstructHeight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WhiteMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_RimRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Manual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Finish As System.Windows.Forms.RadioButton
    Friend WithEvents Label_Right As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Round As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_RimLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Left As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Bottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_RimBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Top As System.Windows.Forms.Label
    Friend WithEvents CheckBox_Show As System.Windows.Forms.CheckBox
    Friend WithEvents Button_CalculateBlob As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Modify As System.Windows.Forms.GroupBox
    Friend WithEvents Label_Select As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Select As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_Load As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlackMura_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackMura_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BlobSmooth As System.Windows.Forms.Label
    Friend WithEvents Button_LoadBlobSmooth As System.Windows.Forms.Button
    Friend WithEvents BtnPre_BlobMuraRound As System.Windows.Forms.Button
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents CheckBox_Rim As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_AutoAddORR As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_Show_Other_RimRegion As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_ORR_Mannual As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Other_RimRegion_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Button_ORR_CLearAll As System.Windows.Forms.Button
    Friend WithEvents Button_ORR_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents Label_ORRCount As System.Windows.Forms.Label
    Friend WithEvents ListView_Other_RimRegion As System.Windows.Forms.ListView
    Friend WithEvents Ch_LeftX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_TopY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_RightX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_BottomY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_White_Reconstruct_High As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_White_Reconstruct_Low As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox_MannualAddORR As System.Windows.Forms.GroupBox
    Friend WithEvents Button_ORR_AddOne As System.Windows.Forms.Button
    Friend WithEvents TextBox_ORR_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents lb_ORR_Bottom As System.Windows.Forms.Label
    Friend WithEvents TextBox_ORR_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents lb_ORR_Left As System.Windows.Forms.Label
    Friend WithEvents lb_ORR_Right As System.Windows.Forms.Label
    Friend WithEvents TextBox_ORR_MinX As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_ORR_MinY As System.Windows.Forms.TextBox
    Friend WithEvents lb_ORR_Top As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlackMura_ORR_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BlackMura_ORR_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteMura_ORR_ReconstructLow As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WhiteMura_ORR_ReconstructHeight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Ch_Black_Reconstruct_High As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_Black_Reconstruct_Low As System.Windows.Forms.ColumnHeader
    Friend WithEvents CheckBox_WhiteRimBlobValue As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_BlackRimBlobValue As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_BlackRimBlobValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WhiteRimBlobValue As System.Windows.Forms.NumericUpDown
End Class
