Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraFalseDefect
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_RegionPaintStop As Boolean

    Private m_Size As Integer

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim Image As MIL_ID
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraFalseDefect", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess

        If Not Me.m_MainProcess.CheckIP() Then
            Me.m_MainProcess.IsIPConnected = False
            MessageBox.Show("Can't connect to IP-" & Me.m_MainProcess.CCDNo & "�APLZ restart IP !", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Me.m_MainProcess.IsIPConnected = True
        End If

        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_Pen = New Pen(Color.White)
        Me.m_SolidBrush = New SolidBrush(Color.White)
        Me.m_Size = 15
        Button_DeleteRegion.Enabled = False

        Me.ComboBox_FalseType.SelectedIndex = 0

        If Me.m_Form.GetPatternIndexInfo > Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
        End If
        Image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
        If Image <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        Me.m_Form.ImageUpdate()
        Me.m_Form.ImageZoomAll()

        Me.UpdateData()
        '--- �v������ ---
        Me.UpdateUserLevel()
    End Sub

#Region "--- Dialog Event ---"

    Private Sub Dialog_MuraFalseDefect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Me.LoadFalseDefectTable()
        Me.LoadFalseDefectTemp()
        Me.ShowListView()
        Me.Update()
    End Sub

    Private Sub Dialog_FalseDefect_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Try
            Me.m_Form.PaintStop = True
            Me.CheckBox_ShowFilterRegion.Checked = False
            Me.CheckBox_RegionMannual.Checked = False

            Me.CheckBox_ShowUnFilterRegion.Checked = False
            Me.CheckBox_UFRMannual.Checked = False

            Me.CheckBox_ShowAIFilterRegion.Checked = False
            Me.CheckBox_AFRMannual.Checked = False
            Me.m_Panel_AxMDisplay.Refresh()
            Me.Finalize()
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Dialog_MuraFalseDefect_Closing]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Dialog_MuraFalseDefect_Closing]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- ��k�禡 ---"

#Region "--- LoadFalseDefectTable ---"
    Private Sub LoadFalseDefectTable()
        Dim i As Integer
        Dim j As Integer
        Dim Index As Integer
        Dim mba As ClsMuraFalseArray = Nothing
        Dim mf As ClsMuraFalse
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim strs2() As String
        Dim strs3() As String
        Dim Defect_Count As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Load Mura False Defect Table   ==> Request_Command = "LOAD_MURA_FALSEDEFECT_TABLE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_MURA_FALSEDEFECT_TABLE"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Func False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.LoadFalseDefectTable]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.LoadFalseDefectTable]Load Mura False Defect Table Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Response_OK Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2

                '--- �ѪR Func False ----
                OutputString = SubSystemResult.Responses(0).Param1
                strs1 = OutputString.Split("$")

                For Index = 0 To (strs1.Length / 2 - 1)
                    If strs1(2 * Index) <> "" And strs1(2 * Index) <> ";" Then
                        Select Case strs1(2 * (Index - 1) + 1)

                            Case "WhiteMuraFalseArea"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseArea
                            Case "BlackMuraFalseArea"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseArea
                            Case "WhiteMuraFalseRim"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRim
                            Case "BlackMuraFalseRim"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRim
                            Case "WhiteMuraFalseTop"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTop
                            Case "BlackMuraFalseTop"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTop
                            Case "WhiteMuraFalseBottom"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottom
                            Case "BlackMuraFalseBottom"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottom
                            Case "WhiteMuraFalseLeft"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeft
                            Case "BlackMuraFalseLeft"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeft
                            Case "WhiteMuraFalseRight"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRight
                            Case "BlackMuraFalseRight"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRight
                            Case "MuraBandFalseV"
                                mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseV
                            Case "MuraBandFalseH"
                                mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseH
                        End Select

                        strs2 = strs1(2 * Index).Split(";")
                        Defect_Count = strs2.Length
                        If mba.Count > 0 Then mba.Clear()

                        For i = 0 To Defect_Count - 1
                            If strs2(i) <> "" Then
                                strs3 = strs2(i).Split(",")

                                If (strs3.Length > 1) Then
                                    mf = New ClsMuraFalse()

                                    For j = 0 To strs3.Length / 2 - 1
                                        Select Case strs3(j * 2)
                                            Case "CreateTime"
                                                mf.CreateTime = strs3(j + 1)
                                            Case "CenterX"
                                                mf.CenterX = CDbl(strs3(j * 2 + 1))
                                            Case "CenterY"
                                                mf.CenterY = CDbl(strs3(j * 2 + 1))
                                            Case "Area"
                                                mf.Area = CDbl(strs3(j * 2 + 1))
                                            Case "Pattern"
                                                mf.Pattern = strs3(j * 2 + 1)
                                        End Select
                                    Next
                                    mba.Add(mf)
                                End If
                            End If
                        Next

                    End If
                Next
            End If

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.LoadFalseDefectTable]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraFalseDefect.LoadFalseDefectTable]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- LoadFalseDefectTemp ---"
    Private Sub LoadFalseDefectTemp()
        Dim i As Integer
        Dim j As Integer
        Dim Index As Integer
        Dim mba As ClsMuraFalseArray = Nothing
        Dim mf As ClsMuraFalse
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim strs2() As String
        Dim strs3() As String
        Dim Defect_Count As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Load Mura False Defect Temp   ==> Request_Command = "LOAD_MURA_FALSEDEFECT_TEMP " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_MURA_FALSEDEFECT_TEMP"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Func False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.LoadFalseDefectTemp]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.LoadFalseDefectTemp]Load Mura False Defect Temp Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Clear Func False ----
            OutputString = SubSystemResult.Responses(0).Param1
            strs1 = OutputString.Split("$")
            For Index = 0 To (strs1.Length / 2 - 1)
                If strs1(2 * Index) <> "" And strs1(2 * Index) <> ";" Then
                    Select Case strs1(2 * (Index - 1) + 1)

                        Case "WhiteMuraFalseAreaHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaHistory
                        Case "BlackMuraFalseAreaHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseAreaHistory
                        Case "WhiteMuraFalseRimHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimHistory
                        Case "BlackMuraFalseRimHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimHistory
                        Case "WhiteMuraFalseTopHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopHistory
                        Case "BlackMuraFalseTopHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopHistory
                        Case "WhiteMuraFalseBottomHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomHistory
                        Case "BlackMuraFalseBottomHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                        Case "WhiteMuraFalseLeftHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftHistory
                        Case "BlackMuraFalseLeftHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftHistory
                        Case "WhiteMuraFalseRightHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightHistory
                        Case "BlackMuraFalseRightHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightHistory
                        Case "MuraBandFalseVHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVHistory
                        Case "MuraBandFalseHHistory"
                            mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHHistory
                    End Select

                    If mba.Count > 0 Then mba.Clear()
                End If
            Next

            If Response_OK Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2

                '--- �ѪR Func False ----
                OutputString = SubSystemResult.Responses(0).Param1
                strs1 = OutputString.Split("$")

                For Index = 0 To (strs1.Length / 2 - 1)
                    If strs1(2 * Index) <> "" And strs1(2 * Index) <> ";" Then
                        Select Case strs1(2 * (Index - 1) + 1)

                            Case "WhiteMuraFalseAreaHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaHistory
                            Case "BlackMuraFalseAreaHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseAreaHistory
                            Case "WhiteMuraFalseRimHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimHistory
                            Case "BlackMuraFalseRimHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimHistory
                            Case "WhiteMuraFalseTopHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopHistory
                            Case "BlackMuraFalseTopHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopHistory
                            Case "WhiteMuraFalseBottomHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomHistory
                            Case "BlackMuraFalseBottomHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                            Case "WhiteMuraFalseLeftHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftHistory
                            Case "BlackMuraFalseLeftHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftHistory
                            Case "WhiteMuraFalseRightHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightHistory
                            Case "BlackMuraFalseRightHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightHistory
                            Case "MuraBandFalseVHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVHistory
                            Case "MuraBandFalseHHistory"
                                mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHHistory
                        End Select

                        strs2 = strs1(2 * Index).Split(";")
                        Defect_Count = strs2.Length
                        If mba.Count > 0 Then mba.Clear()

                        For i = 0 To Defect_Count - 1
                            If strs2(i) <> "" Then
                                strs3 = strs2(i).Split(",")

                                If (strs3.Length > 1) Then
                                    mf = New ClsMuraFalse()

                                    For j = 0 To strs3.Length / 2 - 1
                                        Select Case strs3(j * 2)
                                            Case "CreateTime"
                                                mf.CreateTime = strs3(j + 1)
                                            Case "CenterX"
                                                mf.CenterX = CDbl(strs3(j * 2 + 1))
                                            Case "CenterY"
                                                mf.CenterY = CDbl(strs3(j * 2 + 1))
                                            Case "Area"
                                                mf.Area = CDbl(strs3(j * 2 + 1))
                                            Case "Pattern"
                                                mf.Pattern = strs3(j * 2 + 1)
                                        End Select
                                    Next
                                    mba.Add(mf)
                                End If
                            End If
                        Next

                    End If
                Next
            End If

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.LoadFalseDefectTemp]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.LoadFalseDefectTemp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_ManualAddFD.Enabled = False
                Me.Button_FalseAdd.Enabled = False
                Me.Button_FalseRemove.Enabled = False
                Me.GroupBox_FilterRegion.Enabled = False
                Me.GroupBox_AutoAddFR.Enabled = False
                Me.GroupBox_MannualAddFR.Enabled = False
                Me.Button_Save.Enabled = False

                Me.GroupBox_UnFilterRegion.Enabled = False
                Me.GroupBox_AutoAddUFR.Enabled = False
                Me.GroupBox_MannualAddUFR.Enabled = False

            Case 1 'PM
                Me.GroupBox_ManualAddFD.Enabled = True
                Me.Button_FalseAdd.Enabled = True
                Me.Button_FalseRemove.Enabled = True
                Me.Button_Save.Enabled = True
                Me.ComboBox_False_Pattern.Enabled = False

                '--- FilterRegion -----
                Me.GroupBox_FilterRegion.Enabled = False
                Me.GroupBox_AutoAddFR.Enabled = False
                Me.GroupBox_MannualAddFR.Enabled = False
                Me.ComboBox_FR_Pattern.Enabled = False

                '--- Un-FilterRegion -----
                Me.GroupBox_UnFilterRegion.Enabled = False
                Me.GroupBox_AutoAddUFR.Enabled = False
                Me.GroupBox_MannualAddUFR.Enabled = False

            Case 2 'ENG
                Me.GroupBox_ManualAddFD.Enabled = True
                Me.Button_FalseAdd.Enabled = True
                Me.Button_FalseRemove.Enabled = True
                Me.Button_Save.Enabled = True
                Me.ComboBox_False_Pattern.Enabled = True

                '--- FilterRegion -----
                Me.GroupBox_FilterRegion.Enabled = True
                Me.GroupBox_AutoAddFR.Enabled = True
                Me.GroupBox_MannualAddFR.Enabled = True
                Me.ComboBox_FR_Pattern.Enabled = True

                '--- Un-FilterRegion -----
                Me.GroupBox_UnFilterRegion.Enabled = True
                Me.GroupBox_AutoAddUFR.Enabled = True
                Me.GroupBox_MannualAddUFR.Enabled = True
            Case 3 'ALL
                Me.GroupBox_ManualAddFD.Enabled = True
                Me.Button_FalseAdd.Enabled = True
                Me.Button_FalseRemove.Enabled = True
                Me.Button_Save.Enabled = True
                Me.ComboBox_False_Pattern.Enabled = True

                '--- FilterRegion -----
                Me.GroupBox_FilterRegion.Enabled = True
                Me.GroupBox_AutoAddFR.Enabled = True
                Me.GroupBox_MannualAddFR.Enabled = True
                Me.ComboBox_FR_Pattern.Enabled = True

                '--- Un-FilterRegion -----
                Me.GroupBox_UnFilterRegion.Enabled = True
                Me.GroupBox_AutoAddUFR.Enabled = True
                Me.GroupBox_MannualAddUFR.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- UpdateData ---"
    Private Sub UpdateData()
        Dim i As Integer

        Try
            '--- Pattern Update --- 
            '--- False defect Table ---
            Me.ComboBox_False_Pattern.Items.Clear()
            Me.ComboBox_False_Pattern.Items.Add("ALL")
            For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                Me.ComboBox_False_Pattern.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_False_Type.SelectedIndex = 0
            Me.ComboBox_False_Pattern.SelectedIndex = 0

            '--- Filter Region ---
            Me.ComboBox_FR_Pattern.Items.Clear()
            Me.ComboBox_FR_Pattern.Items.Add("ALL")
            For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                Me.ComboBox_FR_Pattern.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_FR_FilterType.SelectedIndex = 0
            Me.ComboBox_FR_Pattern.SelectedIndex = 0

            '--- AI Filter Region ---
            Me.ComboBox_AFR_Pattern.Items.Clear()
            Me.ComboBox_AFR_Pattern.Items.Add("ALL")
            For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                Me.ComboBox_AFR_Pattern.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_AFR_FilterType.SelectedIndex = 0
            Me.ComboBox_AFR_Pattern.SelectedIndex = 0

        Catch ex As Exception
            Throw New Exception("[Dialog_MuraFalseDefect.UpdateData]Update Data Error! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Button_Enable_1 ---"
    Private Sub Button_Enable_1(ByVal En As Boolean)
        Me.Button_FalseAdd.Enabled = En
        Me.Button_FalseRemove.Enabled = En

        Me.Button_AddOne.Enabled = En
        Me.Button_ClearAll.Enabled = En

        Me.Button_Save.Enabled = En
        Me.Button_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_2 ---"
    Private Sub Button_Enable_2(ByVal En As Boolean)
        Me.Button_DeleteRegion.Enabled = En
        Me.Button_FR_ClearAll.Enabled = En

        Me.Button_AddRegion.Enabled = En

        Me.btnOK.Enabled = En
        Me.btnCancel.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_3 ---"
    Private Sub Button_Enable_3(ByVal En As Boolean)
        Me.Button_AddUFR.Enabled = En
        Me.Button_DeleteUFR.Enabled = En

        Me.btn_UFR_OK.Enabled = En
        Me.btn_UFR_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_4 ---"
    Private Sub Button_Enable_4(ByVal En As Boolean)
        Me.Button_AddAFR.Enabled = En
        Me.Button_DeleteAFR.Enabled = En
        Me.Button_AFR_ClearAll.Enabled = En
        Me.btn_AFR_OK.Enabled = En
        Me.btn_AFR_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_AddAFR.Text = res.GetString("Button_AddAFR.Text")
                Button_AddOne.Text = res.GetString("Button_AddOne.Text")
                Button_AddRegion.Text = res.GetString("Button_AddRegion.Text")
                Button_AddUFR.Text = res.GetString("Button_AddUFR.Text")
                Button_AFR_ClearAll.Text = res.GetString("Button_AFR_ClearAll.Text")
                Button_CenterMuraTransfer.Text = res.GetString("Button_CenterMuraTransfer.Text")
                Button_DeleteAFR.Text = res.GetString("Button_DeleteAFR.Text")
                Button_DeleteRegion.Text = res.GetString("Button_DeleteRegion.Text")
                Button_DeleteUFR.Text = res.GetString("Button_DeleteUFR.Text")
                Button_FR_ClearAll.Text = res.GetString("Button_FR_ClearAll.Text")
                Ch_BottomY.Text = res.GetString("Ch_BottomY.Text")
                Ch_LeftX.Text = res.GetString("Ch_LeftX.Text")
                Ch_RightX.Text = res.GetString("Ch_RightX.Text")
                Ch_TopY.Text = res.GetString("Ch_TopY.Text")
                CheckBox_AFRMannual.Text = res.GetString("CheckBox_AFRMannual.Text")
                CheckBox_EnableFalseLine.Text = res.GetString("CheckBox_EnableFalseLine.Text")
                CheckBox_RegionMannual.Text = res.GetString("CheckBox_RegionMannual.Text")
                CheckBox_ShowAIFilterRegion.Text = res.GetString("CheckBox_ShowAIFilterRegion.Text")
                CheckBox_ShowFilterRegion.Text = res.GetString("CheckBox_ShowFilterRegion.Text")
                CheckBox_ShowUnFilterRegion.Text = res.GetString("CheckBox_ShowUnFilterRegion.Text")
                CheckBox_UFRMannual.Text = res.GetString("CheckBox_UFRMannual.Text")
                ColumnHeader1.Text = res.GetString("ColumnHeader1.Text")
                ColumnHeader2.Text = res.GetString("ColumnHeader2.Text")
                ColumnHeader3.Text = res.GetString("ColumnHeader3.Text")
                ColumnHeader4.Text = res.GetString("ColumnHeader4.Text")
                ColumnHeader5.Text = res.GetString("ColumnHeader5.Text")
                ColumnHeader6.Text = res.GetString("ColumnHeader6.Text")
                ColumnHeader7.Text = res.GetString("ColumnHeader7.Text")
                ColumnHeader8.Text = res.GetString("ColumnHeader8.Text")
                GroupBox_ManualAddFD.Text = res.GetString("GroupBox_ManualAddFD.Text")
                Label_Area.Text = res.GetString("Label_Area.Text")
                Label_False_Type.Text = res.GetString("Label_False_Type.Text")
                Label_FalsePosition.Text = res.GetString("Label_FalsePosition.Text")
                Label_FalseType.Text = res.GetString("Label_FalseType.Text")
                Label_NewPosition.Text = res.GetString("Label_NewPosition.Text")
                Label1.Text = res.GetString("Label1.Text")
                Label11.Text = res.GetString("Label11.Text")
                Label12.Text = res.GetString("Label12.Text")
                Label13.Text = res.GetString("Label13.Text")
                Label14.Text = res.GetString("Label14.Text")
                Label2.Text = res.GetString("Label2.Text")
                Label3.Text = res.GetString("Label3.Text")
                Label36.Text = res.GetString("Label36.Text")
                Label4.Text = res.GetString("Label4.Text")
                Label5.Text = res.GetString("Label5.Text")
                Label6.Text = res.GetString("Label6.Text")
                lbData.Text = res.GetString("lbData.Text")
                lbGate.Text = res.GetString("lbGate.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- Show Event ---"
    Public Sub ShowListView()
        Me.ShowFalse()
        Me.ShowNew()
        Me.ShowFilterRegion()
        Me.ShowUnFilterRegion()
        Me.ShowAIFilterRegion()
    End Sub
    Public Sub ShowFalse()
        Select Case Me.ComboBox_FalseType.SelectedIndex
            Case 0
                Me.ShowWhiteAreaFalse()
            Case 1
                Me.ShowBlackAreaFalse()
            Case 2
                Me.ShowWhiteRimFalse()
            Case 3
                Me.ShowBlackRimFalse()
            Case 4
                Me.ShowWhiteTopFalse()
            Case 5
                Me.ShowBlackTopFalse()
            Case 6
                Me.ShowWhiteBottomFalse()
            Case 7
                Me.ShowBlackBottomFalse()
            Case 8
                Me.ShowWhiteLeftFalse()
            Case 9
                Me.ShowBlackLeftFalse()
            Case 10
                Me.ShowWhiteRightFalse()
            Case 11
                Me.ShowBlackRightFalse()
            Case 12
                Me.ShowBandVFalse()
            Case 13
                Me.ShowBandHFalse()
        End Select
    End Sub
    Public Sub ShowNew()
        Select Case Me.ComboBox_FalseType.SelectedIndex
            Case 0
                Me.ShowWhiteAreaNew()
            Case 1
                Me.ShowBlackAreaNew()
            Case 2
                Me.ShowWhiteRimNew()
            Case 3
                Me.ShowBlackRimNew()
            Case 4
                Me.ShowWhiteTopNew()
            Case 5
                Me.ShowBlackTopNew()
            Case 6
                Me.ShowWhiteBottomNew()
            Case 7
                Me.ShowBlackBottomNew()
            Case 8
                Me.ShowWhiteLeftNew()
            Case 9
                Me.ShowBlackLeftNew()
            Case 10
                Me.ShowWhiteRightNew()
            Case 11
                Me.ShowBlackRightNew()
            Case 12
                Me.ShowBandVNew()
            Case 13
                Me.ShowBandHNew()
        End Select
    End Sub

    Public Sub ShowFilterRegion()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraPositionArray
        Dim mb As ClsMuraPosition

        Me.ListView_FilterRegion.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraPosition(i)
            lvi = Me.ListView_FilterRegion.Items.Add(mb.MinX)
            lvi.SubItems.Add(mb.MinY)
            lvi.SubItems.Add(mb.MaxX)
            lvi.SubItems.Add(mb.MaxY)

            If mb.FilterType = "" Then
                lvi.SubItems.Add("Blob")
            Else
                lvi.SubItems.Add(mb.FilterType)
            End If

            If Me.ComboBox_FR_Pattern.Text = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern)
            End If

        Next
        Me.Label_FRCount.Text = "�ƶq = " & mba.Count
        Me.DrawMark()
    End Sub

    Public Sub ShowUnFilterRegion()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraPositionArray
        Dim mb As ClsMuraPosition

        Me.ListView_UnFilterRegion.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraPosition(i)
            lvi = Me.ListView_UnFilterRegion.Items.Add(mb.MinX)
            lvi.SubItems.Add(mb.MinY)
            lvi.SubItems.Add(mb.MaxX)
            lvi.SubItems.Add(mb.MaxY)
        Next
        Me.Label_UFRCount.Text = "�ƶq = " & mba.Count
        Me.DrawMark2()
    End Sub

    Public Sub ShowAIFilterRegion()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraPositionArray
        Dim mb As ClsMuraPosition

        Me.ListView_AIFilterRegion.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraPosition(i)
            lvi = Me.ListView_AIFilterRegion.Items.Add(mb.MinX)
            lvi.SubItems.Add(mb.MinY)
            lvi.SubItems.Add(mb.MaxX)
            lvi.SubItems.Add(mb.MaxY)

            If mb.FilterType = "" Then
                lvi.SubItems.Add("Blob")
            Else
                lvi.SubItems.Add(mb.FilterType)
            End If

            If Me.ComboBox_AFR_Pattern.Text = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern)
            End If

        Next
        Me.Label_AFRCount.Text = "�ƶq = " & mba.Count
        Me.DrawMark3()
    End Sub
#End Region

#Region "--- Button Event ---"

#Region "--- Mura False Defect ---"

    Private Sub Button_FalseAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FalseAdd.Click
        Dim i As Integer
        Dim j As Integer
        Dim mf As ClsMuraFalse
        Dim mba As ClsMuraFalseArray = Nothing
        Dim mbah As ClsMuraFalseArray = Nothing
        Dim type As String = ""
        Dim c As Integer
        Dim MuraFalse As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)

            Select Case Me.ComboBox_FalseType.SelectedIndex
                Case 0
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseArea
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaHistory
                    type = "WhiteMuraFalseArea"
                Case 1
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseArea
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseAreaHistory
                    type = "BlackMuraFalseArea"
                Case 2
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRim
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimHistory
                    type = "WhiteMuraFalseRim"
                Case 3
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRim
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimHistory
                    type = "BlackMuraFalseRim"
                Case 4
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTop
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopHistory
                    type = "WhiteMuraFalseTop"
                Case 5
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTop
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopHistory
                    type = "BlackMuraFalseTop"
                Case 6
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottom
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomHistory
                    type = "WhiteMuraFalseBottom"
                Case 7
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottom
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                    type = "BlackMuraFalseBottom"
                Case 8
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeft
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftHistory
                    type = "WhiteMuraFalseLeft"
                Case 9
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeft
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftHistory
                    type = "BlackMuraFalseLeft"
                Case 10
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRight
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightHistory
                    type = "WhiteMuraFalseRight"
                Case 11
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRight
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightHistory
                    type = "BlackMuraFalseRight"
                Case 12
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseV
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVHistory
                    type = "MuraBandFalseV"
                Case 13
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseH
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHHistory
                    type = "MuraBandFalseH"
            End Select


            c = Me.m_MuraProcess.MuraModelRecipe.FalseCount.Value
            For i = Me.ListView_New.SelectedItems.Count - 1 To 0 Step -1
                j = Me.ListView_New.SelectedItems.Item(i).Index
                Me.ListView_New.Items.RemoveAt(j)
                mf = mbah.GetMuraFalse(j)
                mf.Count = c
                mba.Add(mf)
                mbah.Remove(mf)

                '--- Prepare Mura False Data ---
                MuraFalse = MuraFalse & "CreateTime," & mf.CreateTime & ",CenterX," & mf.CenterX & ",CenterY," & mf.CenterY & ",Area," & mf.Area & ",Pattern," & mf.Pattern
            Next
            Me.ShowFalse()

            '----------------------------------------------------------------------------------------------
            ' Move Mura False From Temp To Table  ==> Request_Command = "MURA_FALSE_TEMPTOTABLE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "MURA_FALSE_TEMPTOTABLE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, MuraFalse, j, Me.ComboBox_FalseType.SelectedIndex, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.Button_Enable_1(True)
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Move Mura False From Temp To Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_FalseAdd]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.Button_Enable_1(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_FalseAdd]Move Mura False From Temp To Table Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_FalseAdd]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_FalseAdd]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Button_FalseRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FalseRemove.Click
        Dim i As Integer
        Dim j As Integer
        Dim mf As ClsMuraFalse
        Dim mba As ClsMuraFalseArray = Nothing
        Dim mbah As ClsMuraFalseArray = Nothing
        Dim type As String = ""
        Dim MuraFalse As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)

            Select Case Me.ComboBox_FalseType.SelectedIndex
                Case 0
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseArea
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaHistory
                    type = "WhiteMuraFalseArea"
                Case 1
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseArea
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseAreaHistory
                    type = "BlackMuraFalseArea"
                Case 2
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRim
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimHistory
                    type = "WhiteMuraFalseRim"
                Case 3
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRim
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimHistory
                    type = "BlackMuraFalseRim"
                Case 4
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTop
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopHistory
                    type = "WhiteMuraFalseTop"
                Case 5
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTop
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopHistory
                    type = "BlackMuraFalseTop"
                Case 6
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottom
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomHistory
                    type = "WhiteMuraFalseBottom"
                Case 7
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottom
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                    type = "BlackMuraFalseBottom"
                Case 8
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeft
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftHistory
                    type = "WhiteMuraFalseLeft"
                Case 9
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeft
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftHistory
                    type = "BlackMuraFalseLeft"
                Case 10
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRight
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightHistory
                    type = "WhiteMuraFalseRight"
                Case 11
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRight
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightHistory
                    type = "BlackMuraFalseRight"
                Case 12
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseV
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVHistory
                    type = "MuraBandFalseV"
                Case 13
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseH
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHHistory
                    type = "MuraBandFalseH"
            End Select

            For i = Me.ListView_False.SelectedItems.Count - 1 To 0 Step -1
                j = Me.ListView_False.SelectedItems.Item(i).Index
                Me.ListView_False.Items.RemoveAt(j)
                mf = mba.GetMuraFalse(j)
                mba.GetMuraFalse(j).Count -= 1
                mbah.Add(mf)
                mba.RemoveAt(j)

                '--- Prepare Mura False Data ---
                MuraFalse = MuraFalse & "CreateTime," & mf.CreateTime & ",CenterX," & mf.CenterX & ",CenterY," & mf.CenterY & ",Area," & mf.Area & ",Pattern," & mf.Pattern
            Next
            Me.ShowNew()

            '----------------------------------------------------------------------------------------------
            ' Move Mura False From Table To Temp  ==> Request_Command = "MURA_FALSE_TABLETOTEMP " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "MURA_FALSE_TABLETOTEMP"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, MuraFalse, j, Me.ComboBox_FalseType.SelectedIndex, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Move Mura False From Table To Temp Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_FalseRemove]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_FalseRemove]Move Mura False From Table To Temp Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_FalseRemove]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_FalseRemove]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_AddOne.Click
        Dim mba As ClsMuraFalseArray = Nothing
        Dim mbah As ClsMuraFalseArray = Nothing
        Dim mf As ClsMuraFalse
        Dim type As String = ""
        Dim MuraFalse As String = ""
        Dim Destination As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)

            Select Case Me.ComboBox_FalseType.SelectedIndex
                Case 0
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseArea
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaHistory
                    type = "WhiteMuraFalseArea"
                Case 1
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseArea
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                    type = "BlackMuraFalseArea"
                Case 2
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRim
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimHistory
                    type = "WhiteMuraFalseRim"
                Case 3
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRim
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimHistory
                    type = "BlackMuraFalseRim"
                Case 4
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTop
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopHistory
                    type = "WhiteMuraFalseTop"
                Case 5
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTop
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopHistory
                    type = "BlackMuraFalseTop"
                Case 6
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottom
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomHistory
                    type = "WhiteMuraFalseBottom"
                Case 7
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottom
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                    type = "BlackMuraFalseBottom"
                Case 8
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeft
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftHistory
                    type = "WhiteMuraFalseLeft"
                Case 9
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeft
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftHistory
                    type = "BlackMuraFalseLeft"
                Case 10
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRight
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightHistory
                    type = "WhiteMuraFalseRight"
                Case 11
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRight
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightHistory
                    type = "BlackMuraFalseRight"
                Case 12
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseV
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVHistory
                    type = "MuraBandFalseV"
                Case 13
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseH
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHHistory
                    type = "MuraBandFalseH"
            End Select

            If Me.ComboBox_False_Type.SelectedIndex = -1 Then Exit Sub
            mf = New ClsMuraFalse
            mf.CreateTime = Format(Now(), "yyMMdd_HHmmss")
            mf.Area = Me.NumericUpDown_Area.Value
            mf.CenterX = Me.NumericUpDown_X.Value
            mf.CenterY = Me.NumericUpDown_Y.Value
            mf.Count = Me.m_MuraProcess.MuraModelRecipe.FalseCount.Value

            If Me.ComboBox_False_Pattern.Text = "" Then
                mf.Pattern = "ALL"
            Else
                mf.Pattern = Me.ComboBox_False_Pattern.Text
            End If

            Select Case Me.ComboBox_False_Type.SelectedIndex
                Case 0
                    mba.Add(mf)
                    Me.ShowFalse()
                    Destination = "TABLE"
                Case 1
                    mbah.Add(mf)
                    Me.ShowNew()
                    Destination = "TEMP"
            End Select

            '--- Prepare Mura False Data ---
            MuraFalse = MuraFalse & "CreateTime," & mf.CreateTime & ",CenterX," & mf.CenterX & ",CenterY," & mf.CenterY & ",Area," & mf.Area & ",Pattern," & mf.Pattern

            '-----------------------------------------------------------------------------------------------------

            '----------------------------------------------------------------------------------------------
            ' Add One Mura False   ==> Request_Command = "MURA_FALSE_ADDONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "MURA_FALSE_ADDONE"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, MuraFalse, Me.ComboBox_FalseType.SelectedIndex, Destination, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Mura False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_FalseRemove]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_FalseRemove]Add One Mura False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_AddOne]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_AddOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim str As String
        Dim str2 As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)

            '----------------------------------------------------------------------------------------------
            ' Save Mura False Defect Table  ==> Request_Command = "SAVE_MURA_FALSEDEFECTTABLE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_FALSEDEFECTTABLE"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save MuraFalse Defect Table ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str)
                str = str.Replace("\", "\\")

                '--- Save MuraFalse Defect Table ---
                str2 = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFalseDefectTableBackup_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str2)
                str2 = str2.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, str2, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Save Mura False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_Save] Save Mura False Defect Table Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub Button_ClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ClearAll.Click
        Dim str As String = ""
        Dim str2 As String = ""
        Dim Destination As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)

            Select Case ComboBox_False_Type.SelectedIndex
                Case 0
                    Call Me.m_MuraProcess.ClearFalseDefectTable(Me.m_MainProcess.ErrorCode)
                    Me.ListView_False.Items.Clear()
                    Destination = "TABLE"
                Case 1
                    Call Me.m_MuraProcess.ClearFalseDefectTemp(Me.m_MainProcess.ErrorCode)
                    Me.ListView_New.Items.Clear()
                    Destination = "TEMP"
            End Select

            '----------------------------------------------------------------------------------------------
            ' Clear all Mura False   ==> Request_Command = "MURA_FALSE_CLEAR " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "MURA_FALSE_CLEAR"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Destination, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Mura False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_ClearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_ClearAll]Clear all Mura False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Mura False Defect Table  ==> Request_Command = "SAVE_MURA_FALSEDEFECTTABLE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_FALSEDEFECTTABLE"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save MuraFalse Defect Table ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\\" & Me.m_Form.GetProductNameInfo & "\\Mura\\MuraFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str)
                str = str.Replace("\", "\\")

                '--- Save MuraFalse Defect Table ---
                str2 = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\\" & Me.m_Form.GetProductNameInfo & "\\Mura\\MuraFalseDefectTableBackup_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str2)
                str2 = str2.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, str2, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Save Mura False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_ClearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_ClearAll] Save Mura False Defect Table Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_ClearAll]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_ClearAll]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

#End Region

#Region "--- Filter Region ---"

    Private Sub Button_AddRegion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_AddRegion.Click
        Dim mb As New ClsMuraPosition
        Dim str As String
        Dim FilterRegion As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_2(False)

            If Me.TextBox_MinX.Text <> "" AndAlso Me.TextBox_MaxX.Text <> "" AndAlso Me.TextBox_MinY.Text <> "" AndAlso Me.TextBox_MaxY.Text <> "" Then
                mb.MinX = CInt(Me.TextBox_MinX.Text)
                mb.MinY = CInt(Me.TextBox_MinY.Text)
                mb.MaxX = CInt(Me.TextBox_MaxX.Text)
                mb.MaxY = CInt(Me.TextBox_MaxY.Text)

                If Me.ComboBox_FR_FilterType.Text = "" Then
                    mb.FilterType = "Blob"
                Else
                    mb.FilterType = Me.ComboBox_FR_FilterType.Text
                End If

                If Me.ComboBox_FR_Pattern.Text = "" Then
                    mb.Pattern = "ALL"
                Else
                    mb.Pattern = Me.ComboBox_FR_Pattern.Text
                End If

                Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Add(mb)
                Me.ShowFilterRegion()

                '--- Update Filter Region ---
                FilterRegion = FilterRegion & "MinX," & mb.MinX & ",MinY," & mb.MinY & ",MaxX," & mb.MaxX & ",MaxY," & mb.MaxY & ",FilterType," & mb.FilterType & ",Pattern," & mb.Pattern

                '----------------------------------------------------------------------------------------------
                ' Add One Filter Region   ==> Request_Command = "MURA_FILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_FILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FilterRegion, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_2(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_AddRegion]Add One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            Me.TextBox_MinX.Text = ""
            Me.TextBox_MinY.Text = ""
            Me.TextBox_MaxX.Text = ""
            Me.TextBox_MaxY.Text = ""

            '----------------------------------------------------------------------------------------------
            ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_FILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura Filter Region ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFilterRegion(str)
                str = str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_AddRegion]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_AddRegion]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_AddRegion]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button_FR_ClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FR_ClearAll.Click
        Dim Str As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_2(False)

            If Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Count > 0 Then
                Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Clear()
                Me.TextBox_MinX.Text = 0
                Me.TextBox_MinY.Text = 0
                Me.TextBox_MaxX.Text = 0
                Me.TextBox_MaxY.Text = 0
                Me.m_Form.PaintStop = True
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.ShowFilterRegion()
                Me.DrawMuraFilterRegion(0, 0)

                '----------------------------------------------------------------------------------------------
                ' Clear all Mura Filter Region   ==> Request_Command = "MURA_FILTERREGION_CLEAR" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_FILTERREGION_CLEAR"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Mura Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.Button_FR_ClearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_2(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_FR_ClearAll]Clear all Mura Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            If Not Response_OK Then Exit Sub

            '----------------------------------------------------------------------------------------------
            ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_FILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura Filter Region ---
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_FR_ClearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_FR_ClearAll]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_FR_ClearAll]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_FR_ClearAll]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button_DeleteRegion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DeleteRegion.Click
        If Me.ListView_FilterRegion.SelectedItems.Count <= 0 Then Exit Sub
        Dim Str As String
        Dim Delete_Index As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_2(False)

            Delete_Index = ListView_FilterRegion.SelectedIndices(0)
            If Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Count > 0 AndAlso Me.ListView_FilterRegion.SelectedIndices.Count <> 0 Then
                Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Remove(Delete_Index)
                Me.TextBox_MinX.Text = 0
                Me.TextBox_MinY.Text = 0
                Me.TextBox_MaxX.Text = 0
                Me.TextBox_MaxY.Text = 0
                Me.m_Form.PaintStop = True
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.ShowFilterRegion()
                Me.DrawMuraFilterRegion(0, 0)
            End If

            '----------------------------------------------------------------------------------------------
            ' Delete One Mura Filter Region   ==> Request_Command = "MURA_FILTERREGION_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "MURA_FILTERREGION_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Mura Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_DeleteRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_DeleteRegion]Delete One Mura Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_FILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura Filter Region ---
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_DeleteRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_DeleteRegion]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_DeleteRegion]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_DeleteRegion]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Dim Str As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_2(False)

            Me.m_Panel_AxMDisplay.Refresh()

            '----------------------------------------------------------------------------------------------
            ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_FILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura Filter Region ---
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.btnOK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.btnOK]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.btnOK]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.btnOK]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

#End Region

#Region "--- Un-Filter Region ---"

    Private Sub Button_AddUFR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_AddUFR.Click
        Dim mb As New ClsMuraPosition
        Dim str As String
        Dim UnFilterRegion As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_3(False)

            If Me.TextBox_UFR_MinX.Text <> "" AndAlso Me.TextBox_UFR_MaxX.Text <> "" AndAlso Me.TextBox_UFR_MinY.Text <> "" AndAlso Me.TextBox_UFR_MaxY.Text <> "" Then
                mb.MinX = CInt(Me.TextBox_UFR_MinX.Text)
                mb.MinY = CInt(Me.TextBox_UFR_MinY.Text)
                mb.MaxX = CInt(Me.TextBox_UFR_MaxX.Text)
                mb.MaxY = CInt(Me.TextBox_UFR_MaxY.Text)
                Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion.Add(mb)
                Me.ShowUnFilterRegion()

                '--- Update UN_Filter Region ---
                UnFilterRegion = UnFilterRegion & "MinX," & mb.MinX & ",MinY," & mb.MinY & ",MaxX," & mb.MaxX & ",MaxY," & mb.MaxY

                '----------------------------------------------------------------------------------------------
                ' Add One Un-Filter Region   ==> Request_Command = "MURA_UNFILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_UNFILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, UnFilterRegion, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_3(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_AddRegion]Add One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            Me.TextBox_UFR_MinX.Text = ""
            Me.TextBox_UFR_MinY.Text = ""
            Me.TextBox_UFR_MaxX.Text = ""
            Me.TextBox_UFR_MaxY.Text = ""

            '----------------------------------------------------------------------------------------------
            ' Save Mura Un-Filter Region File ==> Request_Command = "SAVE_MURA_UNFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_UNFILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura Un-Filter region ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraUnFilterRegion(str)
                str = str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_AddUFR]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_AddUFR]Save Mura Un-Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_3(True)
        Catch ex As Exception
            Me.Button_Enable_3(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_AddUFR]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_AddUFR]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button_DeleteUFR_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DeleteUFR.Click   '07/23 Rick add
        Dim Str As String
        Dim Delete_Index As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_3(False)

            Delete_Index = ListView_UnFilterRegion.SelectedIndices(0)
            If Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion.Count > 0 Then
                Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion.Remove(Delete_Index)
                Me.TextBox_UFR_MinX.Text = 0
                Me.TextBox_UFR_MinY.Text = 0
                Me.TextBox_UFR_MaxX.Text = 0
                Me.TextBox_UFR_MaxY.Text = 0
                Me.m_Form.PaintStop = True
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.ShowUnFilterRegion()
                Me.DrawMuraUnFilterRegion(0, 0)

                '----------------------------------------------------------------------------------------------
                ' Delete One Mura Un-Filter Region   ==> Request_Command = "MURA_UNFILTERREGION_DELETEONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_UNFILTERREGION_DELETEONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Mura Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.Button_DeleteRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_3(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_DeleteRegion]Delete One Mura Un-Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            '----------------------------------------------------------------------------------------------
            ' Save Mura Un-Filter Region File ==> Request_Command = "SAVE_MURA_UNFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_UNFILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura Un-Filter region ---
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraUnFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_DeleteUFR]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_DeleteUFR]Save Mura Un-Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_3(True)
        Catch ex As Exception
            Me.Button_Enable_3(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_DeleteUFR]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_DeleteUFR]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub btn_UFR_OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_UFR_OK.Click
        Dim Str As String
        Dim MuraUnFilterRegionString As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.m_Panel_AxMDisplay.Refresh()
        '----------------------------------------------------------------------------------------------
        ' Save Mura Un-Filter Region File ==> Request_Command = "SAVE_MURA_UNFILTERREGION" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            Request_Command = "SAVE_MURA_UNFILTERREGION"

            '--- Prepare Command ---
            TimeOut = 100000 '100 secs

            '--- Save Mura Un-Filter region ---
            Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
            Me.m_MuraProcess.MuraFalseFilter.SaveMuraUnFilterRegion(Str)
            Str = Str.Replace("\", "\\")

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraFalseDefect.btn_UFR_OK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.btn_UFR_OK]Save Mura Un-Filter Region File Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraFalseDefect.btn_UFR_OK]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Me.Close()
    End Sub

    Private Sub btn_UFR_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn_UFR_Cancel.Click
        Me.Close()
    End Sub

#End Region

#Region "--- AIFilter Region ---"

    Private Sub Button_AddAFR_Click(sender As System.Object, e As System.EventArgs) Handles Button_AddAFR.Click
        Dim mb As New ClsMuraPosition
        Dim str As String
        Dim AFR As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_4(False)

            If Me.TextBox_AFR_MinX.Text <> "" AndAlso Me.TextBox_AFR_MaxX.Text <> "" AndAlso Me.TextBox_AFR_MinY.Text <> "" AndAlso Me.TextBox_AFR_MaxY.Text <> "" Then
                mb.MinX = CInt(Me.TextBox_AFR_MinX.Text)
                mb.MinY = CInt(Me.TextBox_AFR_MinY.Text)
                mb.MaxX = CInt(Me.TextBox_AFR_MaxX.Text)
                mb.MaxY = CInt(Me.TextBox_AFR_MaxY.Text)

                If Me.ComboBox_AFR_FilterType.Text = "" Then
                    mb.FilterType = "Blob"
                Else
                    mb.FilterType = Me.ComboBox_AFR_FilterType.Text
                End If

                If Me.ComboBox_AFR_Pattern.Text = "" Then
                    mb.Pattern = "ALL"
                Else
                    mb.Pattern = Me.ComboBox_AFR_Pattern.Text
                End If

                Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Add(mb)
                Me.ShowAIFilterRegion()

                '--- Update Filter Region ---
                AFR = AFR & "MinX," & mb.MinX & ",MinY," & mb.MinY & ",MaxX," & mb.MaxX & ",MaxY," & mb.MaxY & ",FilterType," & mb.FilterType & ",Pattern," & mb.Pattern

                '----------------------------------------------------------------------------------------------
                ' Add One Filter Region   ==> Request_Command = "MURA_AIFILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_AIFILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, AFR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One AI Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAIFalseDefect.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAIFalseDefect.Button_AddRegion]Add One AI Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            Me.TextBox_AFR_MinX.Text = ""
            Me.TextBox_AFR_MinY.Text = ""
            Me.TextBox_AFR_MaxX.Text = ""
            Me.TextBox_AFR_MaxY.Text = ""

            '----------------------------------------------------------------------------------------------
            ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_AIFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_AIFILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura AI Filter Region ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraAIFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraAIFilterRegion(str)
                str = str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura AI Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraAIFalseDefect.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAIFalseDefect.Button_AddRegion]Save Mura AI Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_4(True)
        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_MuraAIFalseDefect.Button_AddRegion]" & ex.Message)
            MessageBox.Show("[Dialog_MuraAIFalseDefect.Button_AddRegion]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button_DeleteAFR_Click(sender As System.Object, e As System.EventArgs) Handles Button_DeleteAFR.Click
        If Me.ListView_AIFilterRegion.SelectedItems.Count <= 0 Then Exit Sub
        Dim Str As String
        Dim Delete_Index As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_4(False)

            Delete_Index = ListView_AIFilterRegion.SelectedIndices(0)
            If Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Count > 0 AndAlso Me.ListView_AIFilterRegion.SelectedIndices.Count <> 0 Then
                Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Remove(Delete_Index)
                Me.TextBox_AFR_MinX.Text = 0
                Me.TextBox_AFR_MinY.Text = 0
                Me.TextBox_AFR_MaxX.Text = 0
                Me.TextBox_AFR_MaxY.Text = 0
                Me.m_Form.PaintStop = True
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.ShowAIFilterRegion()
                Me.DrawMuraAIFilterRegion(0, 0)
            End If

            '----------------------------------------------------------------------------------------------
            ' Delete One Mura Filter Region   ==> Request_Command = "MURA_AIFILTERREGION_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "MURA_AIFILTERREGION_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One AI Mura Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraAIFalseDefect.Button_DeleteRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAIFalseDefect.Button_DeleteRegion]Delete One Mura Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_AIFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_AIFILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura AI Filter Region ---
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraAIFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraAIFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura AI Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraAIFalseDefect.Button_DeleteRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAIFalseDefect.Button_DeleteRegion]Save Mura AI Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_4(True)
        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_MuraAIFalseDefect.Button_DeleteRegion]" & ex.Message)
            MessageBox.Show("[Dialog_MuraAIFalseDefect.Button_DeleteRegion]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button_AFR_ClearAll_Click(sender As System.Object, e As System.EventArgs) Handles Button_AFR_ClearAll.Click
        Dim Str As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_4(False)

            If Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Count > 0 Then
                Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Clear()
                Me.TextBox_AFR_MinX.Text = 0
                Me.TextBox_AFR_MinY.Text = 0
                Me.TextBox_AFR_MaxX.Text = 0
                Me.TextBox_AFR_MaxY.Text = 0
                Me.m_Form.PaintStop = True
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.ShowAIFilterRegion()
                Me.DrawMuraAIFilterRegion(0, 0)

                '----------------------------------------------------------------------------------------------
                ' Clear all Mura Filter Region   ==> Request_Command = "MURA_FILTERREGION_CLEAR" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_AIFILTERREGION_CLEAR"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Mura AI Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.Button_AFR_ClearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_AFR_ClearAll]Clear all Mura AI Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            If Not Response_OK Then Exit Sub

            '----------------------------------------------------------------------------------------------
            ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_AIFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_MURA_AIFILTERREGION"

                '--- Prepare Command ---
                TimeOut = 100000 '100 secs

                '--- Save Mura Filter Region ---
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraAIFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraAIFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura AI Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraFalseDefect.Button_AFR_ClearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.Button_FR_ClearAll]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Enable Button ---
            Me.Button_Enable_4(True)
        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.Button_FR_ClearAll]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.Button_FR_ClearAll]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btn_AFR_OK_Click(sender As System.Object, e As System.EventArgs) Handles btn_AFR_OK.Click
        Dim Str As String
        Dim MuraAIFilterRegionString As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.m_Panel_AxMDisplay.Refresh()
        '----------------------------------------------------------------------------------------------
        ' Save Mura Un-Filter Region File ==> Request_Command = "SAVE_MURA_AIFILTERREGION" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            Request_Command = "SAVE_MURA_AIFILTERREGION"

            '--- Prepare Command ---
            TimeOut = 100000 '100 secs

            '--- Save Mura AIFilter region ---
            Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraAIFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
            Me.m_MuraProcess.MuraFalseFilter.SaveMuraAIFilterRegion(Str)
            Str = Str.Replace("\", "\\")

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura AIFilter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraFalseDefect.btn_AFR_OK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.btn_AFR_OK]Save Mura AIFilter Region File Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraFalseDefect.btn_AFR_OK]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btn_AFR_Cancel_Click(sender As System.Object, e As System.EventArgs) Handles btn_AFR_Cancel.Click
        Me.Close()
    End Sub

    Private Sub Button_CenterMuraTransfer_Click(sender As System.Object, e As System.EventArgs) Handles Button_CenterMuraTransfer.Click
        TextBox_AFR_MinX.Text = String.Format("{0}", Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX)
        TextBox_AFR_MinY.Text = String.Format("{0}", Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY + Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY)
        TextBox_AFR_MaxX.Text = String.Format("{0}", Me.m_MuraProcess.MuraModelRecipe.Boundary.RightX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX)
        TextBox_AFR_MaxY.Text = String.Format("{0}", Me.m_MuraProcess.MuraModelRecipe.Boundary.BottomY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY)
    End Sub

#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region


#End Region

#Region "--- ListView Event ---"

#Region "--- False Defect ---"

    Private Sub ListView_False_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_False.Click
        Dim SelectIndex As Integer
        Dim mba As ClsMuraFalseArray = Nothing
        Dim type As String = ""

        Select Case Me.ComboBox_FalseType.SelectedIndex
            Case 0
                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseArea
                type = "WhiteMuraFalseArea"
            Case 1
                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseArea
                type = "BlackMuraFalseArea"
            Case 2
                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRim
                type = "WhiteMuraFalseRim"
            Case 3
                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRim
                type = "BlackMuraFalseRim"
            Case 4
                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTop
                type = "WhiteMuraFalseTop"
            Case 5
                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTop
                type = "BlackMuraFalseTop"
            Case 6
                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottom
                type = "WhiteMuraFalseBottom"
            Case 7
                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottom
                type = "BlackMuraFalseBottom"
            Case 8
                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeft
                type = "WhiteMuraFalseLeft"
            Case 9
                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeft
                type = "BlackMuraFalseLeft"
            Case 10
                mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRight
                type = "WhiteMuraFalseRight"
            Case 11
                mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRight
                type = "BlackMuraFalseRight"
            Case 12
                mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseV
                type = "MuraBandFalseV"
            Case 13
                mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseH
                type = "MuraBandFalseH"
        End Select

        If mba.Count > 0 Then
            SelectIndex = ListView_False.SelectedIndices(0)
            Me.NumericUpDown_X.Text = ListView_False.Items(SelectIndex).SubItems(1).Text
            Me.NumericUpDown_Y.Text = ListView_False.Items(SelectIndex).SubItems(2).Text
            Me.NumericUpDown_Area.Text = ListView_False.Items(SelectIndex).SubItems(3).Text

            If ListView_False.Items(SelectIndex).SubItems(4).Text = "" Then
                Me.ComboBox_False_Pattern.Text = "ALL"
            Else
                Me.ComboBox_False_Pattern.Text = ListView_False.Items(SelectIndex).SubItems(4).Text
            End If
        End If

    End Sub

    Private Sub ListView_False_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_False.KeyUp
        Dim i As Integer
        Dim j As Integer
        Dim Delete_Index As Integer
        Dim Destination As String = "TABLE"
        Dim mba As ClsMuraFalseArray = Nothing

        If e.KeyCode = Keys.Delete AndAlso ListView_False.SelectedIndices.Count <> 0 Then

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)

            Select Case Me.ComboBox_FalseType.SelectedIndex
                Case 0
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseArea
                Case 1
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseArea
                Case 2
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRim
                Case 3
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRim
                Case 4
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTop
                Case 5
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTop
                Case 6
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottom
                Case 7
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottom
                Case 8
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeft
                Case 9
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeft
                Case 10
                    mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRight
                Case 11
                    mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRight
                Case 12
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseV
                Case 13
                    mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseH
            End Select
            For i = Me.ListView_False.SelectedItems.Count - 1 To 0 Step -1
                j = Me.ListView_False.SelectedItems.Item(i).Index
                Me.ListView_False.Items.RemoveAt(j)
                mba.RemoveAt(j)
            Next

            Try
                Delete_Index = ListView_False.SelectedIndices(0)

                If Delete_Index < 0 Then Exit Sub
                '----------------------------------------------------------------------------------------------
                ' Delete One Mura False   ==> Request_Command = "MURA_FALSE_DELETEONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_FALSE_DELETEONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, Me.ComboBox_FalseType.SelectedIndex, Destination, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Mura False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.ListView_False_KeyUp]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.ListView_False_KeyUp]Delete One Mura False Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Call ShowFalse()

                '--- Enable Button ---
                Me.Button_Enable_1(True)
            Catch ex As Exception
                Me.Button_Enable_1(True)
                Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.ListView_False_KeyUp]" & ex.Message)
                MessageBox.Show("[Dialog_MuraFalseDefect.ListView_False_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub ListView_New_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_New.KeyUp
        Dim i As Integer
        Dim j As Integer
        Dim Delete_Index As Integer
        Dim Destination As String = "TEMP"
        Dim mbab As ClsMuraFalseArray = Nothing
        Dim mbah As ClsMuraFalseArray = Nothing


        If e.KeyCode = Keys.Delete AndAlso ListView_New.SelectedIndices.Count <> 0 Then

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)

            Select Case Me.ComboBox_FalseType.SelectedIndex
                Case 0
                    mbab = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaHistory
                Case 1
                    mbab = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseAreaBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                Case 2
                    mbab = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimHistory
                Case 3
                    mbab = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimHistory
                Case 4
                    mbab = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopHistory
                Case 5
                    mbab = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopHistory
                Case 6
                    mbab = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomHistory
                Case 7
                    mbab = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
                Case 8
                    mbab = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftHistory
                Case 9
                    mbab = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftHistory
                Case 10
                    mbab = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightHistory
                Case 11
                    mbab = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightHistory
                Case 12
                    mbab = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVHistory
                Case 13
                    mbab = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHBuffer
                    mbah = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHHistory
            End Select
            For i = Me.ListView_False.SelectedItems.Count - 1 To 0 Step -1
                j = Me.ListView_False.SelectedItems.Item(i).Index
                Me.ListView_False.Items.RemoveAt(j)
                mbah.Remove(mbab.GetMuraFalse(j))
                mbab.RemoveAt(j)
            Next

            Try
                Delete_Index = ListView_New.SelectedIndices(0)

                If Delete_Index < 0 Then Exit Sub
                '----------------------------------------------------------------------------------------------
                ' Delete One Mura False   ==> Request_Command = "MURA_FALSE_DELETEONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_FALSE_DELETEONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, Me.ComboBox_FalseType.SelectedIndex, Destination, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Mura False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.ListView_New_KeyUp]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.ListView_New_KeyUp]Delete One Mura False Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Call ShowNew()

                '--- Enable Button ---
                Me.Button_Enable_1(True)
            Catch ex As Exception
                Me.Button_Enable_1(True)
                Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.ListView_New_KeyUp]" & ex.Message)
                MessageBox.Show("[Dialog_MuraFalseDefect.ListView_New_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub ListView_False_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_False.SelectedIndexChanged
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark()
        End If
    End Sub

    Private Sub ListView_New_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_New.SelectedIndexChanged
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark()
        End If
    End Sub

#End Region

#Region "--- Filter Region ---"

    Private Sub ListView_FilterRegion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_FilterRegion.Click
        Dim SelectIndex As Integer
        If Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Count > 0 Then
            SelectIndex = ListView_FilterRegion.SelectedIndices(0)
            Me.TextBox_MinX.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(0).Text
            Me.TextBox_MinY.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(1).Text
            Me.TextBox_MaxX.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(2).Text
            Me.TextBox_MaxY.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(3).Text
            Me.ComboBox_FR_FilterType.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(4).Text
            If ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = "" Then
                Me.ComboBox_FR_Pattern.Text = "ALL"
            Else
                Me.ComboBox_FR_Pattern.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text
            End If

            Button_DeleteRegion.Enabled = True
        End If
    End Sub

    Private Sub ListView_FilterRegion_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_FilterRegion.KeyUp
        Try
            If e.KeyCode = Keys.Delete And Me.ListView_FilterRegion.SelectedIndices.Count <> 0 Then
                Button_DeleteRegion_Click(sender, e)
            End If
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.ListView_FilterRegion_KeyUp]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.ListView_FilterRegion_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ComboBox_FR_FilterType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_FR_FilterType.SelectedIndexChanged   '11/08 Rick add
        Dim SelectIndex As Integer
        Dim mb As ClsMuraPosition
        Dim FilterRegion As String = ""

        If Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Count > 0 And ListView_FilterRegion.SelectedItems.Count > 0 Then
            Try
                SelectIndex = ListView_FilterRegion.SelectedIndices(0)
                Me.TextBox_MinX.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(0).Text
                Me.TextBox_MinY.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(1).Text
                Me.TextBox_MaxX.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(2).Text
                Me.TextBox_MaxY.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(3).Text

                ListView_FilterRegion.Items(SelectIndex).SubItems(4).Text = Me.ComboBox_FR_FilterType.Text

                mb = Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.GetMuraPosition(SelectIndex)
                mb.MinX = Me.TextBox_MinX.Text
                mb.MinY = Me.TextBox_MinY.Text
                mb.MaxX = Me.TextBox_MaxX.Text
                mb.MaxY = Me.TextBox_MaxY.Text
                mb.FilterType = Me.ComboBox_FR_FilterType.Text
                mb.Pattern = Me.ComboBox_FR_Pattern.Text

                If Me.ComboBox_FR_FilterType.Text = "" Then
                    mb.FilterType = "Blob"
                Else
                    mb.FilterType = Me.ComboBox_FR_FilterType.Text
                End If

                If Me.ComboBox_FR_Pattern.Text = "" Then
                    ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = "ALL"
                    mb.Pattern = "ALL"
                Else
                    ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = Me.ComboBox_FR_Pattern.Text
                    mb.Pattern = Me.ComboBox_FR_Pattern.Text
                End If

                '--- Disable Button ---
                Me.Button_Enable_2(False)

                '--- Update Filter Region ---
                FilterRegion = "MinX," & mb.MinX & ",MinY," & mb.MinY & ",MaxX," & mb.MaxX & ",MaxY," & mb.MaxY & ",FilterType," & mb.FilterType & ",Pattern," & mb.Pattern

                '----------------------------------------------------------------------------------------------
                ' Modify One Filter Region   ==> Request_Command = "MURA_FILTERREGION_MODIFYONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_FILTERREGION_MODIFYONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SelectIndex, FilterRegion, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Modify One Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.ComboBox_FR_FilterType_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_2(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.ComboBox_FR_FilterType_SelectedIndexChanged]Modify One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '--- Enable Button ---
                Me.Button_Enable_2(True)
            Catch ex As Exception
                Me.Button_Enable_2(True)
                Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.ComboBox_FR_FilterType_SelectedIndexChanged]" & ex.Message)
                MessageBox.Show("[Dialog_MuraFalseDefect.ComboBox_FR_FilterType_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        End If
    End Sub

#End Region

#Region "--- Un-Filter Region ---"

    Private Sub ListView_UnFilterRegion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_UnFilterRegion.Click
        Dim SelectIndex As Integer
        If Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion.Count > 0 Then
            SelectIndex = ListView_UnFilterRegion.SelectedIndices(0)
            Me.TextBox_UFR_MinX.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(0).Text
            Me.TextBox_UFR_MinY.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(1).Text
            Me.TextBox_UFR_MaxX.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(2).Text
            Me.TextBox_UFR_MaxY.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(3).Text
            Me.Button_DeleteUFR.Enabled = True
        End If
    End Sub

    Private Sub ListView_UnFilterRegion_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_UnFilterRegion.KeyUp
        If e.KeyCode = Keys.Delete And Me.ListView_UnFilterRegion.SelectedIndices.Count <> 0 Then
            Me.Button_DeleteUFR_Click(sender, e)
        End If

        Dim str As String
        str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
        Me.m_MuraProcess.MuraFalseFilter.SaveMuraUnFilterRegion(str)
    End Sub

#End Region

#Region "--- AIFilter Region ---"

    Private Sub ListView_AIFilterRegion_Click(sender As System.Object, e As System.EventArgs) Handles ListView_AIFilterRegion.Click
        Dim SelectIndex As Integer
        If Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Count > 0 Then
            SelectIndex = ListView_AIFilterRegion.SelectedIndices(0)
            Me.TextBox_AFR_MinX.Text = ListView_AIFilterRegion.Items(SelectIndex).SubItems(0).Text
            Me.TextBox_AFR_MinY.Text = ListView_AIFilterRegion.Items(SelectIndex).SubItems(1).Text
            Me.TextBox_AFR_MaxX.Text = ListView_AIFilterRegion.Items(SelectIndex).SubItems(2).Text
            Me.TextBox_AFR_MaxY.Text = ListView_AIFilterRegion.Items(SelectIndex).SubItems(3).Text
            Me.ComboBox_AFR_FilterType.Text = ListView_AIFilterRegion.Items(SelectIndex).SubItems(4).Text
            If ListView_AIFilterRegion.Items(SelectIndex).SubItems(5).Text = "" Then
                Me.ComboBox_FR_Pattern.Text = "ALL"
            Else
                Me.ComboBox_AFR_Pattern.Text = ListView_AIFilterRegion.Items(SelectIndex).SubItems(5).Text
            End If

            Button_DeleteAFR.Enabled = True
        End If
    End Sub

    Private Sub ListView_AIFilterRegion_KeyUp(sender As System.Object, e As System.Windows.Forms.KeyEventArgs) Handles ListView_AIFilterRegion.KeyUp
        Try
            If e.KeyCode = Keys.Delete And Me.ListView_AIFilterRegion.SelectedIndices.Count <> 0 Then
                Button_DeleteAFR_Click(sender, e)
            End If
        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.ListView_FilterRegion_KeyUp]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.ListView_FilterRegion_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#End Region

#Region "--- Drawing Event ---"

    Private Sub m_AxMDisplay_PaintEvent(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop And Me.CheckBox_ShowFilterRegion.Checked Then
            Me.DrawMark()
        End If

        If Not Me.m_Form.PaintStop And Me.CheckBox_ShowUnFilterRegion.Checked Then
            Me.DrawMark2()
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseDownEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_RegionMannual.Checked And Me.CheckBox_ShowFilterRegion.Checked Then   '�ƹ�����
            Me.CheckBox_UFRMannual.Checked = False
            Me.m_Panel_AxMDisplay.Refresh()
            Me.m_RegionPaintStop = False
            Me.TextBox_MinX.Text = Me.m_Form.MouseX
            Me.TextBox_MinY.Text = Me.m_Form.MouseY
        End If

        If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_UFRMannual.Checked And Me.CheckBox_ShowUnFilterRegion.Checked Then   '�ƹ�����
            Me.m_Panel_AxMDisplay.Refresh()
            Me.m_RegionPaintStop = False
            Me.TextBox_UFR_MinX.Text = Me.m_Form.MouseX
            Me.TextBox_UFR_MinY.Text = Me.m_Form.MouseY
        End If

        If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_AFRMannual.Checked And Me.CheckBox_ShowAIFilterRegion.Checked Then   '�ƹ�����
            Me.m_Panel_AxMDisplay.Refresh()
            Me.m_RegionPaintStop = False
            Me.TextBox_AFR_MinX.Text = Me.m_Form.MouseX
            Me.TextBox_AFR_MinY.Text = Me.m_Form.MouseY
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseMove(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove

        '--- Filter Region ---
        If Me.CheckBox_ShowFilterRegion.Checked And Me.CheckBox_RegionMannual.Checked And Not Me.m_RegionPaintStop Then
            Me.CheckBox_UFRMannual.Checked = False
            'Me.m_Form.PaintStop = True
            Me.m_Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
            If e.Button = Windows.Forms.MouseButtons.Left Then
                Me.TextBox_MaxX.Text = Me.m_Form.MouseX
                Me.TextBox_MaxY.Text = Me.m_Form.MouseY
            End If
            Me.DrawMark()
        End If

        '--- Un-Filter Region ---
        If Me.CheckBox_ShowUnFilterRegion.Checked And Me.CheckBox_UFRMannual.Checked And Not Me.m_RegionPaintStop Then
            'Me.m_Form.PaintStop = True
            Me.m_Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
            If e.Button = Windows.Forms.MouseButtons.Left Then
                Me.TextBox_UFR_MaxX.Text = Me.m_Form.MouseX
                Me.TextBox_UFR_MaxY.Text = Me.m_Form.MouseY
            End If
            Me.DrawMark2()
        End If

        '--- AIFilter Region ---
        If Me.CheckBox_ShowAIFilterRegion.Checked And Me.CheckBox_AFRMannual.Checked And Not Me.m_RegionPaintStop Then
            'Me.m_Form.PaintStop = True
            Me.m_Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
            If e.Button = Windows.Forms.MouseButtons.Left Then
                Me.TextBox_AFR_MaxX.Text = Me.m_Form.MouseX
                Me.TextBox_AFR_MaxY.Text = Me.m_Form.MouseY
            End If
            Me.DrawMark3()
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseUpEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_1(False)
            Me.Button_Enable_2(False)
            Me.Button_Enable_3(False)
            Me.Button_Enable_4(False)

            'Filter Region ---
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_RegionMannual.Checked Then
                Dim mb As New ClsMuraPosition
                Dim str As String
                Dim FilterRegion As String = ""
                Dim FilterPattern As String = ""

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    mb.MinX = CInt(Me.TextBox_MinX.Text)
                    mb.MinY = CInt(Me.TextBox_MinY.Text)
                    mb.MaxX = CInt(Me.TextBox_MaxX.Text)
                    mb.MaxY = CInt(Me.TextBox_MaxY.Text)
                ElseIf Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                    mb.MinX = CInt(Me.TextBox_MinX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mb.MinY = CInt(Me.TextBox_MinY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                    mb.MaxX = CInt(Me.TextBox_MaxX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mb.MaxY = CInt(Me.TextBox_MaxY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                End If

                If Me.ComboBox_FR_FilterType.Text = "" Then
                    mb.FilterType = "Blob"
                Else
                    mb.FilterType = Me.ComboBox_FR_FilterType.Text
                End If

                If Me.ComboBox_FR_Pattern.Text = "" Then
                    mb.Pattern = "ALL"
                    FilterPattern = "ALL"
                Else
                    mb.Pattern = Me.ComboBox_FR_Pattern.Text
                    FilterPattern = Me.ComboBox_FR_Pattern.Text
                End If

                Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Add(mb)
                Me.ShowFilterRegion()
                '---------------------------------------
                '--- Update Filter Region ---
                FilterRegion = FilterRegion & "MinX," & Me.TextBox_MinX.Text & ",MinY," & Me.TextBox_MinY.Text & ",MaxX," & Me.TextBox_MaxX.Text & ",MaxY," & Me.TextBox_MaxY.Text & ",FilterType," & Me.ComboBox_FR_FilterType.Text & ",Pattern," & FilterPattern

                '----------------------------------------------------------------------------------------------
                ' Add One Filter Region   ==> Request_Command = "MURA_FILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_FILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FilterRegion, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]Add One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.TextBox_MinX.Text = ""
                Me.TextBox_MinY.Text = ""
                Me.TextBox_MaxX.Text = ""
                Me.TextBox_MaxY.Text = ""
                'Me.m_Form.PaintStop = True

                Me.Label_FRCount.Text = "�ƶq = " & Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion.Count

                If (Response_OK = False) Then
                    Me.Button_Enable_1(True)
                    Me.Button_Enable_2(True)
                    Me.Button_Enable_3(True)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If

                '----------------------------------------------------------------------------------------------
                ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_FILTERREGION" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_MURA_FILTERREGION"

                    '--- Prepare Command ---
                    TimeOut = 100000 '100 secs

                    '--- Save Mura Filter Region ---
                    str = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraFilterRegion(str)
                    str = str.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            '--- Un-Filter Region ---
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_UFRMannual.Checked Then
                Dim mb As New ClsMuraPosition
                Dim str As String
                Dim UFR As String = ""

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    mb.MinX = CInt(Me.TextBox_UFR_MinX.Text)
                    mb.MinY = CInt(Me.TextBox_UFR_MinY.Text)
                    mb.MaxX = CInt(Me.TextBox_UFR_MaxX.Text)
                    mb.MaxY = CInt(Me.TextBox_UFR_MaxY.Text)
                ElseIf Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                    mb.MinX = CInt(Me.TextBox_UFR_MinX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mb.MinY = CInt(Me.TextBox_UFR_MinY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                    mb.MaxX = CInt(Me.TextBox_UFR_MaxX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mb.MaxY = CInt(Me.TextBox_UFR_MaxY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                End If

                Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion.Add(mb)
                Me.ShowUnFilterRegion()
                '---------------------------------------
                '--- Update Un-Filter Region ---
                UFR = UFR & "MinX," & Me.TextBox_UFR_MinX.Text & ",MinY," & Me.TextBox_UFR_MinY.Text & ",MaxX," & Me.TextBox_UFR_MaxX.Text & ",MaxY," & Me.TextBox_UFR_MaxY.Text & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Un-Filter Region   ==> Request_Command = "MURA_UNFILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_UNFILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, UFR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]Add One Un-Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.TextBox_UFR_MinX.Text = ""
                Me.TextBox_UFR_MinY.Text = ""
                Me.TextBox_UFR_MaxX.Text = ""
                Me.TextBox_UFR_MaxY.Text = ""
                'Me.m_Form.PaintStop = True

                Me.Label_UFRCount.Text = "�ƶq = " & Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion.Count

                If (Response_OK = False) Then
                    Me.Button_Enable_1(True)
                    Me.Button_Enable_2(True)
                    Me.Button_Enable_3(True)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If

                '----------------------------------------------------------------------------------------------
                ' Save Mura Un-Filter Region File ==> Request_Command = "SAVE_MURA_UNFILTERREGION" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_MURA_UNFILTERREGION"

                    '--- Prepare Command ---
                    TimeOut = 100000 '100 secs

                    '--- Save Mura Filter Region ---
                    str = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraUnFilterRegion(str)
                    str = str.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]Save Mura Un-Filter Region File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                str = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_MuraProcess.MuraFalseFilter.SaveMuraUnFilterRegion(str)
            End If

            'AI Filter Region ---
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_AFRMannual.Checked Then
                Dim mb As New ClsMuraPosition
                Dim str As String
                Dim AFR As String = ""
                Dim FilterPattern As String = ""

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    mb.MinX = CInt(Me.TextBox_AFR_MinX.Text)
                    mb.MinY = CInt(Me.TextBox_AFR_MinY.Text)
                    mb.MaxX = CInt(Me.TextBox_AFR_MaxX.Text)
                    mb.MaxY = CInt(Me.TextBox_AFR_MaxY.Text)
                ElseIf Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                    mb.MinX = CInt(Me.TextBox_AFR_MinX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mb.MinY = CInt(Me.TextBox_AFR_MinY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                    mb.MaxX = CInt(Me.TextBox_AFR_MaxX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mb.MaxY = CInt(Me.TextBox_AFR_MaxY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                End If

                If Me.ComboBox_AFR_FilterType.Text = "" Then
                    mb.FilterType = "Blob"
                Else
                    mb.FilterType = Me.ComboBox_AFR_FilterType.Text
                End If

                If Me.ComboBox_AFR_Pattern.Text = "" Then
                    mb.Pattern = "ALL"
                    FilterPattern = "ALL"
                Else
                    mb.Pattern = Me.ComboBox_AFR_Pattern.Text
                    FilterPattern = Me.ComboBox_AFR_Pattern.Text
                End If

                Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Add(mb)
                Me.ShowAIFilterRegion()
                '---------------------------------------
                '--- Update Filter Region ---
                AFR = AFR & "MinX," & Me.TextBox_AFR_MinX.Text & ",MinY," & Me.TextBox_AFR_MinY.Text & ",MaxX," & Me.TextBox_AFR_MaxX.Text & ",MaxY," & Me.TextBox_AFR_MaxY.Text & ",FilterType," & Me.ComboBox_AFR_FilterType.Text & ",Pattern," & FilterPattern

                '----------------------------------------------------------------------------------------------
                ' Add One Filter Region   ==> Request_Command = "MURA_AIFILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_AIFILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, AFR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]Add One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.TextBox_AFR_MinX.Text = ""
                Me.TextBox_AFR_MinY.Text = ""
                Me.TextBox_AFR_MaxX.Text = ""
                Me.TextBox_AFR_MaxY.Text = ""
                'Me.m_Form.PaintStop = True

                Me.Label_AFRCount.Text = "�ƶq = " & Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion.Count

                If (Response_OK = False) Then
                    Me.Button_Enable_1(True)
                    Me.Button_Enable_2(True)
                    Me.Button_Enable_3(True)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If

                '----------------------------------------------------------------------------------------------
                ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_AIFILTERREGION" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_MURA_AIFILTERREGION"

                    '--- Prepare Command ---
                    TimeOut = 100000 '100 secs

                    '--- Save Mura Filter Region ---
                    str = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraAIFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraAIFilterRegion(str)
                    str = str.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            '--- Enable Button ---
            Me.Button_Enable_1(True)
            Me.Button_Enable_2(True)
            Me.Button_Enable_3(True)
            Me.Button_Enable_4(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.Button_Enable_2(True)
            Me.Button_Enable_3(True)
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.AxMDisplay_MouseUpEvent]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#Region "--- m_AxMDisplay_MouseDoubleClick ---"
    Private Sub m_AxMDisplay_MouseDoubleClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.DoubleClick
        Dim image As MIL_ID = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        Dim SizeX As Integer
        Dim SizeY As Integer

        If Me.CheckBox_EnableFalseLine.Checked Then
            If Me.ComboBox_FalseLineDirection.Text = "V" Then
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                Me.TextBox_MinX.Text = CStr(Me.m_Form.MouseX - Me.NumericUpDown_FalseLineWidth.Value / 2)
                Me.TextBox_MaxX.Text = CStr(Me.m_Form.MouseX + Me.NumericUpDown_FalseLineWidth.Value / 2)
                Me.TextBox_MinY.Text = CStr(0)
                Me.TextBox_MaxY.Text = CStr(SizeY - 1)
            Else
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                Me.TextBox_MinX.Text = CStr(0)
                Me.TextBox_MaxX.Text = CStr(SizeX)
                Me.TextBox_MinY.Text = CStr(Me.m_Form.MouseY - Me.NumericUpDown_FalseLineWidth.Value / 2)
                Me.TextBox_MaxY.Text = CStr(Me.m_Form.MouseY + Me.NumericUpDown_FalseLineWidth.Value / 2)
            End If
            Me.Button_AddRegion.PerformClick()
        End If
    End Sub
#End Region

#Region "--- DrawFalseDefect ---"

    Private Sub DrawMark()
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL
        Dim SizeX, SizeY As Integer

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        'Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = -Me.m_MuraProcess.BoundaryOriginal.LeftX
        offY = -Me.m_MuraProcess.BoundaryOriginal.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    If Me.ComboBox_FalseType.SelectedIndex < 12 Then
                        Me.DrawFalse(0, 0)
                        Me.DrawNew(0, 0)
                    ElseIf Me.ComboBox_FalseType.SelectedIndex = 12 Then
                        Me.DrawVBandFalse(0, 0, Me.m_MuraProcess.BoundaryOriginal.BottomY)
                        Me.DrawVBandNew(0, 0, Me.m_MuraProcess.BoundaryOriginal.BottomY)
                    Else
                        Me.DrawHBandFalse(0, 0, Me.m_MuraProcess.BoundaryOriginal.RightX)
                        Me.DrawHBandNew(0, 0, Me.m_MuraProcess.BoundaryOriginal.RightX)
                    End If
                End If
                Me.DrawMuraFilterRegion(0, 0)
            Case 1
                If Me.ComboBox_FalseType.SelectedIndex < 12 Then
                    Me.DrawFalse(offX, offY)
                    Me.DrawNew(offX, offY)
                    Me.DrawMuraFilterRegion(-offX, -offY)
                End If
            Case 2
                If Me.ComboBox_FalseType.SelectedIndex = 4 Or Me.ComboBox_FalseType.SelectedIndex = 5 Then
                    Me.DrawFalse(offX, offY)
                    Me.DrawNew(offX, offY)
                End If
            Case 3
                If Me.ComboBox_FalseType.SelectedIndex = 6 Or Me.ComboBox_FalseType.SelectedIndex = 7 Then
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_Y, M_NULL)
                    Me.DrawFalse(offX, SizeY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY + offY)
                    Me.DrawNew(offX, SizeY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY + offY)
                End If
            Case 4
                If Me.ComboBox_FalseType.SelectedIndex = 8 Or Me.ComboBox_FalseType.SelectedIndex = 9 Then
                    Me.DrawFalse(offX, offY)
                    Me.DrawNew(offX, offY)
                End If
            Case 5
                If Me.ComboBox_FalseType.SelectedIndex = 10 Or Me.ComboBox_FalseType.SelectedIndex = 11 Then
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_X, M_NULL)
                    Me.DrawFalse(SizeX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX + offX, offY)
                    Me.DrawNew(SizeX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX + offX, offY)
                End If
            Case 6
                If Me.m_Form.ComboBox_Select.SelectedIndex < 3 Then
                    If Me.ComboBox_FalseType.SelectedIndex = 13 Then
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        Me.DrawHBandFalse(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY + offY, 0, SizeX)
                        Me.DrawHBandNew(-Me.m_MuraProcess.MuraModelRecipe.Band.TopY + offY, 0, SizeX)
                    End If
                Else
                    If Me.ComboBox_FalseType.SelectedIndex = 12 Then
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Me.DrawVBandFalse(-Me.m_MuraProcess.MuraModelRecipe.Band.LeftX + offX, 0, SizeY)
                        Me.DrawVBandNew(-Me.m_MuraProcess.MuraModelRecipe.Band.LeftX + offX, 0, SizeY)
                    End If
                End If
        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = False
    End Sub

    Private Sub DrawFalse(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)

        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY


        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red
        For i = 0 To Me.ListView_False.SelectedItems.Count - 1
            lvi = Me.ListView_False.SelectedItems.Item(i)
            x = lvi.SubItems(1).Text
            y = lvi.SubItems(2).Text
            x = (x - ox + 0.5) * s - hr
            y = (y - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub

    Private Sub DrawNew(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)

        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MbufInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MbufInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Green
        For i = 0 To Me.ListView_New.SelectedItems.Count - 1
            lvi = Me.ListView_New.SelectedItems.Item(i)
            x = lvi.SubItems(1).Text
            y = lvi.SubItems(2).Text
            x = (x - ox + 0.5) * s - hr
            y = (y - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub

    Private Sub DrawHBandFalse(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim Image As MIL_ID
        Dim i As Integer
        Dim h As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim size As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem
        rect = New Rectangle
        Me.m_Pen.Color = Color.Red

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, size)

        ox = Me.m_Form.HScrollBar.Value - s
        oy = Me.m_Form.VScrollBar.Value - offset

        Me.m_SolidBrush.Color = Color.Red
        For i = 0 To Me.ListView_False.SelectedItems.Count - 1
            lvi = Me.ListView_False.SelectedItems.Item(i)
            h = (-ox + 0.5) * size
            rect.X = h
            h = (lvi.SubItems(2).Text - oy) * size
            rect.Y = h
            rect.Width = (e - s + 1) * size
            rect.Height = Math.Ceiling(size)
            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next
    End Sub

    Private Sub DrawHBandNew(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim Image As MIL_ID
        Dim i As Integer
        Dim h As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim size As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem
        rect = New Rectangle
        Me.m_Pen.Color = Color.Green

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, size)

        ox = Me.m_Form.HScrollBar.Value - s
        oy = Me.m_Form.VScrollBar.Value - offset
        MbufInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, size)
        Me.m_SolidBrush.Color = Color.Red
        For i = 0 To Me.ListView_New.SelectedItems.Count - 1
            lvi = Me.ListView_New.SelectedItems.Item(i)
            h = (-ox + 0.5) * size
            rect.X = h
            h = (lvi.SubItems(2).Text - oy) * size
            rect.Y = h
            rect.Width = (e - s + 1) * size
            rect.Height = Math.Ceiling(size)
            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next
    End Sub

    Private Sub DrawVBandFalse(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim Image As MIL_ID
        Dim i As Integer
        Dim v As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim size As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem
        rect = New Rectangle

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, size)

        Me.m_Pen.Color = Color.Green
        ox = Me.m_Form.HScrollBar.Value - offset
        oy = Me.m_Form.VScrollBar.Value - s

        Me.m_SolidBrush.Color = Color.Red
        For i = 0 To Me.ListView_False.SelectedItems.Count - 1
            lvi = Me.ListView_False.SelectedItems.Item(i)
            v = (lvi.SubItems(1).Text - ox) * size
            rect.X = v
            v = (-oy + 0.5) * size
            rect.Y = v
            rect.Width = Math.Ceiling(size)
            rect.Height = (e - s + 1) * size
            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next
    End Sub

    Private Sub DrawVBandNew(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim Image As MIL_ID
        Dim i As Integer
        Dim v As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim size As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem
        rect = New Rectangle
        Me.m_Pen.Color = Color.Green
        ox = Me.m_Form.HScrollBar.Value - offset
        oy = Me.m_Form.VScrollBar.Value - s

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        MdispInquire(Image, M_ZOOM_FACTOR_X, size)


        Me.m_SolidBrush.Color = Color.Green
        For i = 0 To Me.ListView_New.SelectedItems.Count - 1
            lvi = Me.ListView_New.SelectedItems.Item(i)
            v = (lvi.SubItems(1).Text - ox) * size
            rect.X = v
            v = (-oy + 0.5) * size
            rect.Y = v
            rect.Width = Math.Ceiling(size)
            rect.Height = (e - s + 1) * size
            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next
    End Sub

#End Region

#Region "--- Draw Filter Region ---"

    Private Sub DrawMuraFilterRegion(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID
        Dim rect As Rectangle
        Dim s As Double
        Dim i As Integer
        Dim intLabelLeft As Integer
        Dim intLabelRight As Integer
        Dim intLabelTop As Integer
        Dim intLabelBottom As Integer
        Dim mfra As ClsMuraPositionArray
        Dim mfr As ClsMuraPosition

        Try
            Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)

            rect = New Rectangle
            If Me.CheckBox_ShowFilterRegion.Checked Then
                mfra = Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion
                Me.m_Pen.Color = Color.Yellow
                Me.m_Pen.Width = s

                For i = 0 To mfra.Count - 1
                    mfr = mfra.GetMuraPosition(i)
                    If Not (mfr.MinX = 0 And mfr.MinY = 0 And mfr.MaxX = 0 And mfr.MaxY = 0) Then
                        intLabelLeft = (mfr.MinX - Me.m_Form.HScrollBar.Value - offX) * s
                        intLabelRight = (mfr.MaxX - Me.m_Form.HScrollBar.Value - offX) * s
                        intLabelTop = (mfr.MinY - Me.m_Form.VScrollBar.Value - offY) * s
                        intLabelBottom = (mfr.MaxY - Me.m_Form.VScrollBar.Value - offY) * s

                        rect.X = intLabelLeft
                        rect.Y = intLabelTop
                        rect.Width = intLabelRight - intLabelLeft + 1
                        rect.Height = intLabelBottom - intLabelTop + 1
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    End If
                Next

            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.DrawMuraFilterRegion]DrawMura Filter Region Error!(" & ex.Message & ")")
        End Try
    End Sub

#End Region

#Region "--- Draw Un-Filter Region---"

    Private Sub DrawMark2()
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = -Me.m_MuraProcess.BoundaryOriginal.LeftX
        offY = -Me.m_MuraProcess.BoundaryOriginal.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                Me.DrawMuraUnFilterRegion(0, 0)
        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_Form.PaintStop = False
    End Sub

    Private Sub DrawMuraUnFilterRegion(ByVal offX As Integer, ByVal offY As Integer)
        Dim image As MIL_ID
        Dim rect As Rectangle
        Dim s As Double
        Dim i As Integer
        Dim intLabelLeft As Integer
        Dim intLabelRight As Integer
        Dim intLabelTop As Integer
        Dim intLabelBottom As Integer
        Dim mfra As ClsMuraPositionArray
        Dim mfr As ClsMuraPosition

        Try
            image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)

            rect = New Rectangle
            If Me.CheckBox_ShowUnFilterRegion.Checked Then
                's = MbufInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
                MbufInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)
                mfra = Me.m_MuraProcess.MuraFalseFilter.MuraUnFilterRegion
                Me.m_Pen.Color = Color.Yellow
                Me.m_Pen.Width = s

                For i = 0 To mfra.Count - 1
                    mfr = mfra.GetMuraPosition(i)
                    If Not (mfr.MinX = 0 And mfr.MinY = 0 And mfr.MaxX = 0 And mfr.MaxY = 0) Then
                        intLabelLeft = (mfr.MinX - Me.m_Form.HScrollBar.Value - offX) * s
                        intLabelRight = (mfr.MaxX - Me.m_Form.HScrollBar.Value - offX) * s
                        intLabelTop = (mfr.MinY - Me.m_Form.VScrollBar.Value - offY) * s
                        intLabelBottom = (mfr.MaxY - Me.m_Form.VScrollBar.Value - offY) * s

                        rect.X = intLabelLeft
                        rect.Y = intLabelTop
                        rect.Width = intLabelRight - intLabelLeft + 1
                        rect.Height = intLabelBottom - intLabelTop + 1
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    End If
                Next

            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.DrawMuraUnFilterRegion]Draw Mura Un-Filter Region Error!(" & ex.Message & ")")
        End Try
    End Sub

#End Region

#Region "--- Draw AIFilter Region---"

    Private Sub DrawMark3()
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = -Me.m_MuraProcess.BoundaryOriginal.LeftX
        offY = -Me.m_MuraProcess.BoundaryOriginal.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                Me.DrawMuraAIFilterRegion(0, 0)
        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_Form.PaintStop = False
    End Sub

    Private Sub DrawMuraAIFilterRegion(ByVal offX As Integer, ByVal offY As Integer)
        Dim image As MIL_ID
        Dim rect As Rectangle
        Dim s As Double
        Dim i As Integer
        Dim intLabelLeft As Integer
        Dim intLabelRight As Integer
        Dim intLabelTop As Integer
        Dim intLabelBottom As Integer
        Dim mfra As ClsMuraPositionArray
        Dim mfr As ClsMuraPosition

        Try
            image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)

            rect = New Rectangle
            If Me.CheckBox_ShowAIFilterRegion.Checked Then
                's = MbufInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
                MbufInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)
                mfra = Me.m_MuraProcess.MuraFalseFilter.MuraAIFilterRegion
                Me.m_Pen.Color = Color.Yellow
                Me.m_Pen.Width = s

                For i = 0 To mfra.Count - 1
                    mfr = mfra.GetMuraPosition(i)
                    If Not (mfr.MinX = 0 And mfr.MinY = 0 And mfr.MaxX = 0 And mfr.MaxY = 0) Then
                        intLabelLeft = (mfr.MinX - Me.m_Form.HScrollBar.Value - offX) * s
                        intLabelRight = (mfr.MaxX - Me.m_Form.HScrollBar.Value - offX) * s
                        intLabelTop = (mfr.MinY - Me.m_Form.VScrollBar.Value - offY) * s
                        intLabelBottom = (mfr.MaxY - Me.m_Form.VScrollBar.Value - offY) * s

                        rect.X = intLabelLeft
                        rect.Y = intLabelTop
                        rect.Width = intLabelRight - intLabelLeft + 1
                        rect.Height = intLabelBottom - intLabelTop + 1
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    End If
                Next

            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.DrawMuraAIFilterRegion]Draw Mura AIFilter Region Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- Show ListView Event ---"
    Private Sub ShowWhiteRimFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRim
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteAreaFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseArea
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteTopFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTop
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteBottomFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottom
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteLeftFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeft
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteRightFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRight
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub

    Private Sub ShowWhiteRimNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRimHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteAreaNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseAreaHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteTopNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseTopHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteBottomNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseBottomHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteLeftNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseLeftHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowWhiteRightNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.WhiteMuraFalseRightHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub

    Private Sub ShowBlackRimFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRim
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackAreaFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseArea
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackTopFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTop
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackBottomFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottom
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackLeftFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeft
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackRightFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRight
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub

    Private Sub ShowBlackRimNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRimHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackAreaNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseAreaHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackTopNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseTopHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackBottomNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseBottomHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackLeftNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseLeftHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBlackRightNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.BlackMuraFalseRightHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub

    Private Sub ShowBandHFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseH
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add("NULL")
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBandVFalse()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_False.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseV
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_False.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add("NULL")

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub

    Private Sub ShowBandHNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseHHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add("NULL")
            lvi.SubItems.Add(mb.CenterY.ToString("0.00"))

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
    Private Sub ShowBandVNew()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mba As ClsMuraFalseArray
        Dim mb As ClsMuraFalse
        Me.ListView_New.Items.Clear()
        mba = Me.m_MuraProcess.MuraFalseFilter.MuraBandFalseVHistory
        For i = 0 To mba.Count - 1
            mb = mba.GetMuraFalse(i)
            lvi = Me.ListView_New.Items.Add(mb.CreateTime.ToString)
            lvi.SubItems.Add(mb.Area.ToString("0.00"))
            lvi.SubItems.Add(mb.CenterX.ToString("0.00"))
            lvi.SubItems.Add("NULL")

            If mb.Pattern = "" Then
                lvi.SubItems.Add("ALL")
            Else
                lvi.SubItems.Add(mb.Pattern.ToString)
            End If
        Next
    End Sub
#End Region

#Region "--- CheckBox Event ---"

    Private Sub ComboBox_FalseType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_FalseType.SelectedIndexChanged
        Me.ShowFalse()
        Me.ShowNew()
    End Sub

    Private Sub ComboBox_FR_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_FR_Pattern.SelectedIndexChanged
        Dim SelectIndex As Integer
        Dim mb As ClsMuraPosition
        Dim mba As ClsMuraPositionArray
        Dim FilterRegion As String = ""
        Dim str As String = ""

        If ListView_FilterRegion.SelectedIndices.Count <> 0 Then
            Try
                mba = Me.m_MuraProcess.MuraFalseFilter.MuraFilterRegion
                SelectIndex = ListView_FilterRegion.SelectedIndices(0)
                mb = mba.GetMuraPosition(SelectIndex)

                If Me.ComboBox_FR_FilterType.Text = "" Then
                    mb.FilterType = "Blob"
                Else
                    mb.FilterType = Me.ComboBox_FR_FilterType.Text
                End If

                If Me.ComboBox_FR_Pattern.Text = "" Then
                    ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = "ALL"
                    mb.Pattern = "ALL"
                Else
                    ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = Me.ComboBox_FR_Pattern.Text
                    mb.Pattern = Me.ComboBox_FR_Pattern.Text
                End If

                '--- Disable Button ---
                Me.Button_Enable_2(False)

                '--- Update Filter Region ---
                FilterRegion = "MinX," & mb.MinX & ",MinY," & mb.MinY & ",MaxX," & mb.MaxX & ",MaxY," & mb.MaxY & ",FilterType," & mb.FilterType & ",Pattern," & mb.Pattern

                '----------------------------------------------------------------------------------------------
                ' Modify One Filter Region   ==> Request_Command = "MURA_FILTERREGION_MODIFYONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MURA_FILTERREGION_MODIFYONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SelectIndex, FilterRegion, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Modify One Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.ComboBox_FR_Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_2(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.ComboBox_FR_Pattern_SelectedIndexChanged]Modify One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                '----------------------------------------------------------------------------------------------
                ' Save Mura Filter Region File ==> Request_Command = "SAVE_MURA_FILTERREGION" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_MURA_FILTERREGION"

                    '--- Prepare Command ---
                    TimeOut = 100000 '100 secs

                    '--- Save Mura Filter Region ---
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraFilterRegion(str)
                    str = str.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraFalseDefect.btnOK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_2(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraFalseDefect.btnOK]Save Mura Filter Region File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                '--- Enable Button ---
                Me.Button_Enable_2(True)
            Catch ex As Exception
                Me.Button_Enable_2(True)
                Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.ComboBox_FR_Pattern_SelectedIndexChanged]" & ex.Message)
                MessageBox.Show("[Dialog_MuraFalseDefect.ComboBox_FR_Pattern_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub CheckBox_ShowFilterRegion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowFilterRegion.CheckedChanged
        If Me.CheckBox_ShowFilterRegion.Checked Then
            Me.CheckBox_EnableFalseLine.Enabled = False
            Me.DrawMark()
        Else
            Me.CheckBox_EnableFalseLine.Enabled = True
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub

    Private Sub CheckBox_ShowUnFilterRegion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowUnFilterRegion.CheckedChanged
        If Me.CheckBox_ShowFilterRegion.Checked Then
            Me.DrawMark2()
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub

    Private Sub CheckBox_ShowAIFilterRegion_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_ShowAIFilterRegion.CheckedChanged
        If Me.CheckBox_ShowAIFilterRegion.Checked Then
            Me.DrawMark3()
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub

    Private Sub CheckBox_EnableFalseLine_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_EnableFalseLine.CheckedChanged
        If Me.CheckBox_EnableFalseLine.Checked Then
            Me.ComboBox_FalseLineDirection.SelectedIndex = 0
            Me.CheckBox_ShowFilterRegion.Enabled = False
            Me.CheckBox_RegionMannual.Enabled = False
        Else
            Me.ComboBox_FR_FilterType.SelectedIndex = 0
            Me.CheckBox_ShowFilterRegion.Enabled = True
            Me.CheckBox_RegionMannual.Enabled = True
        End If
    End Sub

    Private Sub ComboBox_FalseLineDirection_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_FalseLineDirection.SelectedIndexChanged
        If Me.ComboBox_FalseLineDirection.Text = "V" Then
            Me.ComboBox_FR_FilterType.Text = "V-Band"
        Else
            Me.ComboBox_FR_FilterType.Text = "H-Band"
        End If
    End Sub

#End Region

#Region "--- TabControl ---"
    Private Sub TabControl_FalseDefect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl_FalseDefect.Click
        Try
            Me.CheckBox_ShowFilterRegion.Checked = False
            Me.CheckBox_RegionMannual.Checked = False
            Me.CheckBox_ShowUnFilterRegion.Checked = False
            Me.CheckBox_UFRMannual.Checked = False
            Me.CheckBox_ShowAIFilterRegion.Checked = False
            Me.CheckBox_AFRMannual.Checked = False
            Me.m_Panel_AxMDisplay.Refresh()
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_MuraFalseDefect.TabControl_FalseDefect]" & ex.Message)
            MessageBox.Show("[Dialog_MuraFalseDefect.TabControl_FalseDefect]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

End Class