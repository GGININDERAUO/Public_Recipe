<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraSmooth
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_MuraSmooth))
        Me.Label_GlobleSmooth = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlobMura_GlobleSmooth = New System.Windows.Forms.NumericUpDown()
        Me.Label_Select = New System.Windows.Forms.Label()
        Me.ComboBox_Select = New System.Windows.Forms.ComboBox()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Button_Smooth = New System.Windows.Forms.Button()
        Me.Button_BLFFCAlign = New System.Windows.Forms.Button()
        Me.Button_FFCAlign = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown_MacroMura_GlobleSmooth = New System.Windows.Forms.NumericUpDown()
        Me.BtnNext_MuraSmooth = New System.Windows.Forms.Button()
        Me.BtnPre_MuraSmooth = New System.Windows.Forms.Button()
        Me.GroupBox_MuraRatio = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Num_ResizeCount_Min = New System.Windows.Forms.NumericUpDown()
        Me.Num_ResizeCount_Mid = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NumericUpDown_MacroPowerY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_MacroPowerX = New System.Windows.Forms.NumericUpDown()
        Me.Num_ResizeCount_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Num_ResizeCount_Mid2 = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_UseBaseLine = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Circle_ByPassRadius = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_RemoveHVBand = New System.Windows.Forms.CheckBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_FFTFilterRadius = New System.Windows.Forms.NumericUpDown()
        Me.Button_CalculateFFT = New System.Windows.Forms.Button()
        Me.CheckBox_UseFFT = New System.Windows.Forms.CheckBox()
        CType(Me.NumericUpDown_BlobMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MacroMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MuraRatio.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.Num_ResizeCount_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Mid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NumericUpDown_MacroPowerY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MacroPowerX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Num_ResizeCount_Mid2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Circle_ByPassRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.NumericUpDown_FFTFilterRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label_GlobleSmooth
        '
        resources.ApplyResources(Me.Label_GlobleSmooth, "Label_GlobleSmooth")
        Me.Label_GlobleSmooth.Name = "Label_GlobleSmooth"
        '
        'NumericUpDown_BlobMura_GlobleSmooth
        '
        resources.ApplyResources(Me.NumericUpDown_BlobMura_GlobleSmooth, "NumericUpDown_BlobMura_GlobleSmooth")
        Me.NumericUpDown_BlobMura_GlobleSmooth.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BlobMura_GlobleSmooth.Name = "NumericUpDown_BlobMura_GlobleSmooth"
        '
        'Label_Select
        '
        resources.ApplyResources(Me.Label_Select, "Label_Select")
        Me.Label_Select.Name = "Label_Select"
        '
        'ComboBox_Select
        '
        resources.ApplyResources(Me.ComboBox_Select, "ComboBox_Select")
        Me.ComboBox_Select.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Select.Name = "ComboBox_Select"
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        '
        'Button_Smooth
        '
        resources.ApplyResources(Me.Button_Smooth, "Button_Smooth")
        Me.Button_Smooth.Name = "Button_Smooth"
        '
        'Button_BLFFCAlign
        '
        resources.ApplyResources(Me.Button_BLFFCAlign, "Button_BLFFCAlign")
        Me.Button_BLFFCAlign.Name = "Button_BLFFCAlign"
        '
        'Button_FFCAlign
        '
        resources.ApplyResources(Me.Button_FFCAlign, "Button_FFCAlign")
        Me.Button_FFCAlign.Name = "Button_FFCAlign"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'NumericUpDown_MacroMura_GlobleSmooth
        '
        resources.ApplyResources(Me.NumericUpDown_MacroMura_GlobleSmooth, "NumericUpDown_MacroMura_GlobleSmooth")
        Me.NumericUpDown_MacroMura_GlobleSmooth.Name = "NumericUpDown_MacroMura_GlobleSmooth"
        '
        'BtnNext_MuraSmooth
        '
        resources.ApplyResources(Me.BtnNext_MuraSmooth, "BtnNext_MuraSmooth")
        Me.BtnNext_MuraSmooth.Name = "BtnNext_MuraSmooth"
        Me.BtnNext_MuraSmooth.UseVisualStyleBackColor = True
        '
        'BtnPre_MuraSmooth
        '
        resources.ApplyResources(Me.BtnPre_MuraSmooth, "BtnPre_MuraSmooth")
        Me.BtnPre_MuraSmooth.Name = "BtnPre_MuraSmooth"
        Me.BtnPre_MuraSmooth.UseVisualStyleBackColor = True
        '
        'GroupBox_MuraRatio
        '
        resources.ApplyResources(Me.GroupBox_MuraRatio, "GroupBox_MuraRatio")
        Me.GroupBox_MuraRatio.Controls.Add(Me.GroupBox1)
        Me.GroupBox_MuraRatio.Controls.Add(Me.GroupBox2)
        Me.GroupBox_MuraRatio.Controls.Add(Me.CheckBox_UseBaseLine)
        Me.GroupBox_MuraRatio.Name = "GroupBox_MuraRatio"
        Me.GroupBox_MuraRatio.TabStop = False
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.Num_ResizeCount_Min)
        Me.GroupBox1.Controls.Add(Me.Num_ResizeCount_Mid)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'Num_ResizeCount_Min
        '
        resources.ApplyResources(Me.Num_ResizeCount_Min, "Num_ResizeCount_Min")
        Me.Num_ResizeCount_Min.Maximum = New Decimal(New Integer() {8, 0, 0, 0})
        Me.Num_ResizeCount_Min.Name = "Num_ResizeCount_Min"
        '
        'Num_ResizeCount_Mid
        '
        resources.ApplyResources(Me.Num_ResizeCount_Mid, "Num_ResizeCount_Mid")
        Me.Num_ResizeCount_Mid.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.Num_ResizeCount_Mid.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Num_ResizeCount_Mid.Name = "Num_ResizeCount_Mid"
        Me.Num_ResizeCount_Mid.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Name = "Label3"
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_MacroPowerY)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_MacroPowerX)
        Me.GroupBox2.Controls.Add(Me.Num_ResizeCount_Max)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Num_ResizeCount_Mid2)
        Me.GroupBox2.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label8.Name = "Label8"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Name = "Label7"
        '
        'NumericUpDown_MacroPowerY
        '
        resources.ApplyResources(Me.NumericUpDown_MacroPowerY, "NumericUpDown_MacroPowerY")
        Me.NumericUpDown_MacroPowerY.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerY.Name = "NumericUpDown_MacroPowerY"
        Me.NumericUpDown_MacroPowerY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_MacroPowerX
        '
        resources.ApplyResources(Me.NumericUpDown_MacroPowerX, "NumericUpDown_MacroPowerX")
        Me.NumericUpDown_MacroPowerX.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MacroPowerX.Name = "NumericUpDown_MacroPowerX"
        Me.NumericUpDown_MacroPowerX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Num_ResizeCount_Max
        '
        resources.ApplyResources(Me.Num_ResizeCount_Max, "Num_ResizeCount_Max")
        Me.Num_ResizeCount_Max.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.Num_ResizeCount_Max.Minimum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.Num_ResizeCount_Max.Name = "Num_ResizeCount_Max"
        Me.Num_ResizeCount_Max.Value = New Decimal(New Integer() {2, 0, 0, 0})
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'Num_ResizeCount_Mid2
        '
        resources.ApplyResources(Me.Num_ResizeCount_Mid2, "Num_ResizeCount_Mid2")
        Me.Num_ResizeCount_Mid2.Maximum = New Decimal(New Integer() {9, 0, 0, 0})
        Me.Num_ResizeCount_Mid2.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.Num_ResizeCount_Mid2.Name = "Num_ResizeCount_Mid2"
        Me.Num_ResizeCount_Mid2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CheckBox_UseBaseLine
        '
        resources.ApplyResources(Me.CheckBox_UseBaseLine, "CheckBox_UseBaseLine")
        Me.CheckBox_UseBaseLine.Name = "CheckBox_UseBaseLine"
        Me.CheckBox_UseBaseLine.UseVisualStyleBackColor = True
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Name = "Label5"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'NumericUpDown_Circle_ByPassRadius
        '
        resources.ApplyResources(Me.NumericUpDown_Circle_ByPassRadius, "NumericUpDown_Circle_ByPassRadius")
        Me.NumericUpDown_Circle_ByPassRadius.Name = "NumericUpDown_Circle_ByPassRadius"
        '
        'CheckBox_RemoveHVBand
        '
        resources.ApplyResources(Me.CheckBox_RemoveHVBand, "CheckBox_RemoveHVBand")
        Me.CheckBox_RemoveHVBand.Name = "CheckBox_RemoveHVBand"
        Me.CheckBox_RemoveHVBand.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        resources.ApplyResources(Me.GroupBox3, "GroupBox3")
        Me.GroupBox3.Controls.Add(Me.Button_FFCAlign)
        Me.GroupBox3.Controls.Add(Me.Button_BLFFCAlign)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.TabStop = False
        '
        'GroupBox4
        '
        resources.ApplyResources(Me.GroupBox4, "GroupBox4")
        Me.GroupBox4.Controls.Add(Me.NumericUpDown_FFTFilterRadius)
        Me.GroupBox4.Controls.Add(Me.Button_CalculateFFT)
        Me.GroupBox4.Controls.Add(Me.CheckBox_UseFFT)
        Me.GroupBox4.Controls.Add(Me.Label5)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.TabStop = False
        '
        'NumericUpDown_FFTFilterRadius
        '
        resources.ApplyResources(Me.NumericUpDown_FFTFilterRadius, "NumericUpDown_FFTFilterRadius")
        Me.NumericUpDown_FFTFilterRadius.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_FFTFilterRadius.Maximum = New Decimal(New Integer() {2500, 0, 0, 0})
        Me.NumericUpDown_FFTFilterRadius.Name = "NumericUpDown_FFTFilterRadius"
        Me.NumericUpDown_FFTFilterRadius.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'Button_CalculateFFT
        '
        resources.ApplyResources(Me.Button_CalculateFFT, "Button_CalculateFFT")
        Me.Button_CalculateFFT.Name = "Button_CalculateFFT"
        '
        'CheckBox_UseFFT
        '
        resources.ApplyResources(Me.CheckBox_UseFFT, "CheckBox_UseFFT")
        Me.CheckBox_UseFFT.Name = "CheckBox_UseFFT"
        Me.CheckBox_UseFFT.UseVisualStyleBackColor = True
        '
        'Dialog_MuraSmooth
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.CheckBox_RemoveHVBand)
        Me.Controls.Add(Me.NumericUpDown_Circle_ByPassRadius)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox_MuraRatio)
        Me.Controls.Add(Me.BtnPre_MuraSmooth)
        Me.Controls.Add(Me.BtnNext_MuraSmooth)
        Me.Controls.Add(Me.NumericUpDown_MacroMura_GlobleSmooth)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label_GlobleSmooth)
        Me.Controls.Add(Me.NumericUpDown_BlobMura_GlobleSmooth)
        Me.Controls.Add(Me.Label_Select)
        Me.Controls.Add(Me.ComboBox_Select)
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.Button_Smooth)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraSmooth"
        Me.ShowInTaskbar = False
        CType(Me.NumericUpDown_BlobMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MacroMura_GlobleSmooth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MuraRatio.ResumeLayout(False)
        Me.GroupBox_MuraRatio.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.Num_ResizeCount_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Mid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NumericUpDown_MacroPowerY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MacroPowerX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Num_ResizeCount_Mid2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Circle_ByPassRadius, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.NumericUpDown_FFTFilterRadius, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label_GlobleSmooth As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlobMura_GlobleSmooth As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Select As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Select As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Button_Smooth As System.Windows.Forms.Button
    Friend WithEvents Button_FFCAlign As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MacroMura_GlobleSmooth As System.Windows.Forms.NumericUpDown
    Friend WithEvents BtnNext_MuraSmooth As System.Windows.Forms.Button
    Friend WithEvents BtnPre_MuraSmooth As System.Windows.Forms.Button
    Friend WithEvents GroupBox_MuraRatio As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Circle_ByPassRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_RemoveHVBand As System.Windows.Forms.CheckBox
    Friend WithEvents Num_ResizeCount_Mid2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Num_ResizeCount_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Num_ResizeCount_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Num_ResizeCount_Mid As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_BLFFCAlign As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MacroPowerY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_MacroPowerX As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_UseBaseLine As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_FFTFilterRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_CalculateFFT As System.Windows.Forms.Button
    Friend WithEvents CheckBox_UseFFT As System.Windows.Forms.CheckBox
End Class
