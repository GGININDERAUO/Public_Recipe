﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraCollection
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button_CenterMura = New System.Windows.Forms.Button()
        Me.Button_RoundMura = New System.Windows.Forms.Button()
        Me.Button_BandMura = New System.Windows.Forms.Button()
        Me.BtnPre_BlobMuraRound = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button_CenterMura
        '
        Me.Button_CenterMura.Location = New System.Drawing.Point(12, 25)
        Me.Button_CenterMura.Name = "Button_CenterMura"
        Me.Button_CenterMura.Size = New System.Drawing.Size(139, 46)
        Me.Button_CenterMura.TabIndex = 0
        Me.Button_CenterMura.Text = "Center Mura"
        Me.Button_CenterMura.UseVisualStyleBackColor = True
        '
        'Button_RoundMura
        '
        Me.Button_RoundMura.Location = New System.Drawing.Point(157, 25)
        Me.Button_RoundMura.Name = "Button_RoundMura"
        Me.Button_RoundMura.Size = New System.Drawing.Size(139, 46)
        Me.Button_RoundMura.TabIndex = 1
        Me.Button_RoundMura.Text = "Round Mura"
        Me.Button_RoundMura.UseVisualStyleBackColor = True
        '
        'Button_BandMura
        '
        Me.Button_BandMura.Location = New System.Drawing.Point(12, 77)
        Me.Button_BandMura.Name = "Button_BandMura"
        Me.Button_BandMura.Size = New System.Drawing.Size(139, 46)
        Me.Button_BandMura.TabIndex = 2
        Me.Button_BandMura.Text = "Band Mura"
        Me.Button_BandMura.UseVisualStyleBackColor = True
        '
        'BtnPre_BlobMuraRound
        '
        Me.BtnPre_BlobMuraRound.Location = New System.Drawing.Point(228, 100)
        Me.BtnPre_BlobMuraRound.Name = "BtnPre_BlobMuraRound"
        Me.BtnPre_BlobMuraRound.Size = New System.Drawing.Size(68, 23)
        Me.BtnPre_BlobMuraRound.TabIndex = 66
        Me.BtnPre_BlobMuraRound.Text = "<<上一步"
        Me.BtnPre_BlobMuraRound.UseVisualStyleBackColor = True
        '
        'Dialog_MuraCollection
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(310, 145)
        Me.Controls.Add(Me.BtnPre_BlobMuraRound)
        Me.Controls.Add(Me.Button_BandMura)
        Me.Controls.Add(Me.Button_RoundMura)
        Me.Controls.Add(Me.Button_CenterMura)
        Me.Name = "Dialog_MuraCollection"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Dialog_MuraCollection"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button_CenterMura As System.Windows.Forms.Button
    Friend WithEvents Button_RoundMura As System.Windows.Forms.Button
    Friend WithEvents Button_BandMura As System.Windows.Forms.Button
    Friend WithEvents BtnPre_BlobMuraRound As System.Windows.Forms.Button
End Class
