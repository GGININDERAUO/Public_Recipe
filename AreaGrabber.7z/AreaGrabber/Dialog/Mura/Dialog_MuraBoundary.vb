Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl

Imports System.IO
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraBoundary
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_DialogBoundaryType As DialogBoundaryTypeDefine
    Private m_Left As Boolean
    Private m_Right As Boolean
    Private m_Top As Boolean
    Private m_Bottom As Boolean
    Private m_FFCOperation As Boolean
    Private m_Have_MDigitizer As Boolean
    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal type As DialogBoundaryTypeDefine, ByVal language As String, Optional ByVal FFCOperation As Boolean = False)
        Dim image As MIL_ID = M_NULL
        Dim i As Integer
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraBoundary", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------
        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess
        Me.m_FFCOperation = FFCOperation

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Check Digitizer  ==> Request_Command = "CHECK_DIGITIZER" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CHECK_DIGITIZER"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                If SubSystemResult.Responses(0).Param1.ToUpper = "TRUE" Then
                    Me.m_Have_MDigitizer = True
                Else
                    Me.m_Have_MDigitizer = False
                End If
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Check Digitizer Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.SetMainForm]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.SetMainForm]Check Digitizer Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraBoundary.SetMainForm]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Have_MDigitizer Then
            Me.GroupBox_Grab.Enabled = True
        Else
            Me.GroupBox_Grab.Enabled = False
        End If

        '--- [AreaGrabber] ---
        Me.ComboBox_PatnList.Items.Clear()
        For i = 0 To Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1
            Me.ComboBox_PatnList.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
        Next

        If Me.m_Form.GetPatternIndexInfo <> -1 Then
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex >= Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.ComboBox_PatnList.SelectedIndex = 0
            Else
                Me.ComboBox_PatnList.SelectedIndex = Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex
            End If
        Else
            Me.ComboBox_PatnList.SelectedIndex = 0
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
            Me.m_MainProcess.SetRecipe(Me.ComboBox_PatnList.Text, Me.m_MainProcess.ErrorCode)
        End If

        If Me.m_MainProcess.IPBootConfig.CardSystem.Value = "" Then
            Me.Button_Grab.Enabled = False
        End If

        '--- [FFC Operation]Disable UI ---   
        If Me.m_FFCOperation Then
            Me.ComboBox_PatnList.Enabled = False
            Me.Button_Ok.Enabled = False
        End If

        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Form.Panel_AxMDisplay.Width, Me.m_Form.Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_SolidBrush = New SolidBrush(Color.White)
        Me.m_DialogBoundaryType = type
        Select Case Me.m_DialogBoundaryType
            Case DialogBoundaryTypeDefine.FFC
                image = Me.m_MuraProcess.Img_CurrentSample_NonPage

                If image <> M_NULL Then
                    Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("���R�v��")
                    image = Me.m_MuraProcess.Img_ChildSample
                    If image <> M_NULL Then
                        Me.ComboBox_Select.Items.Add("�G�ե��i���ϼv��")
                    End If
                Else
                    Me.m_Form.ComboBox_Type.SelectedIndex = -1
                    Me.DisableOp()
                End If

                image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                If image <> M_NULL Then
                    Me.m_Form.CurrentIndex0 = 1
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 1
                End If
            Case DialogBoundaryTypeDefine.ORIGINAL
                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                If image <> M_NULL Then
                    Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("���R�v��")
                    image = Me.m_MuraProcess.Img_ChildOriginal
                    If image <> M_NULL Then
                        Me.ComboBox_Select.Items.Add("�i���ϼv��")
                    End If
                Else
                    Me.m_Form.ComboBox_Type.SelectedIndex = -1
                    Me.DisableOp()
                End If

                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                If image <> M_NULL Then
                    Me.m_Form.CurrentIndex0 = 2
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 2
                End If
        End Select

        '--- UI ---
        Me.m_VScrollBar = Me.m_Form.VScrollBar
        Me.m_HScrollBar = Me.m_Form.HScrollBar

        Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
        Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
        Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
        Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
        '--- UI ---

        Me.UpdateData()
    End Sub

#Region "--- Dialog Event ---"
    Private Sub Dialog_MuraBoundary_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Me.RadioButton_BoundaryFinish.Checked = True
        Me.RadioButton_ResultFinish.Checked = True
        Me.m_Left = False
        Me.m_Right = False
        Me.m_Top = False
        Me.m_Bottom = False

        '--- Initial Button ---   
        Me.Button_Ok.Enabled = False
        Me.Button_Cancel.Enabled = False
        Me.BtnNext_MuraBoundary.Enabled = False

        Me.m_Form.ImageUpdate()
        Me.m_Form.ImageZoomAll()
        Me.UpdateUserLevel()
    End Sub

    Private Sub Dialog_MuraBoundary_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub

#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.NumericUpDown_DefocusCount.Enabled = False
            Case 1 'PM
                Me.NumericUpDown_DefocusCount.Enabled = False
            Case 2 'ENG
                Me.NumericUpDown_DefocusCount.Enabled = True
            Case 3 'ALL
                Me.NumericUpDown_DefocusCount.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- EnableOp ---"
    Private Sub EnableOp()
        Me.Button_Calculate.Enabled = True
        Me.Button_Split.Enabled = True
        Me.GroupBox_BoundaryModify.Enabled = True
        Me.GroupBox_ResultModify.Enabled = True
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- DisableOp ---"
    Private Sub DisableOp()
        Me.Button_Calculate.Enabled = False
        Me.Button_Split.Enabled = False
        Me.GroupBox_BoundaryModify.Enabled = False
        Me.GroupBox_ResultModify.Enabled = False
    End Sub
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim boundary As ClsParameterBoundary
        boundary = Me.m_MuraProcess.MuraModelRecipe.Boundary
        Me.NumericUpDown_BoundaryTop.Maximum = boundary.BottomY - 1
        Me.NumericUpDown_BoundaryBottom.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 1
        Me.NumericUpDown_BoundaryBottom.Minimum = boundary.TopY + 1
        Me.NumericUpDown_BoundaryLeft.Maximum = boundary.RightX - 1
        Me.NumericUpDown_BoundaryRight.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 1
        Me.NumericUpDown_BoundaryRight.Minimum = boundary.LeftX + 1

        If boundary.TopY > Me.NumericUpDown_BoundaryTop.Maximum Then boundary.TopY = Me.NumericUpDown_BoundaryTop.Maximum - 1
        If boundary.BottomY >= Me.NumericUpDown_BoundaryBottom.Maximum Then boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Maximum - 1
        If boundary.LeftX > Me.NumericUpDown_BoundaryLeft.Maximum Then boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Maximum - 1
        If boundary.RightX >= Me.NumericUpDown_BoundaryRight.Maximum Then boundary.RightX = Me.NumericUpDown_BoundaryRight.Maximum - 1

        If boundary.TopY <= Me.NumericUpDown_BoundaryTop.Minimum Then boundary.TopY = Me.NumericUpDown_BoundaryTop.Minimum
        If boundary.BottomY <= Me.NumericUpDown_BoundaryBottom.Minimum Then boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Minimum
        If boundary.LeftX <= Me.NumericUpDown_BoundaryLeft.Minimum Then boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Minimum
        If boundary.RightX <= Me.NumericUpDown_BoundaryRight.Minimum Then boundary.RightX = Me.NumericUpDown_BoundaryRight.Minimum


        Me.NumericUpDown_BoundaryTop.Value = boundary.TopY
        Me.NumericUpDown_BoundaryBottom.Value = boundary.BottomY
        Me.NumericUpDown_BoundaryLeft.Value = boundary.LeftX
        Me.NumericUpDown_BoundaryRight.Value = boundary.RightX

        Me.NumericUpDown_ResultTop.Maximum = boundary.BottomY - 1
        Me.NumericUpDown_ResultBottom.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 1
        Me.NumericUpDown_ResultBottom.Minimum = boundary.TopY + 1
        Me.NumericUpDown_ResultLeft.Maximum = boundary.RightX - 1
        Me.NumericUpDown_ResultRight.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 1
        Me.NumericUpDown_ResultRight.Minimum = boundary.LeftX + 1

        Me.NumericUpDown_ResultTop.Value = boundary.TopY
        Me.NumericUpDown_ResultBottom.Value = boundary.BottomY
        Me.NumericUpDown_ResultLeft.Value = boundary.LeftX
        Me.NumericUpDown_ResultRight.Value = boundary.RightX

        Me.NumericUpDown_DefocusCount.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value
    End Sub
#End Region

#Region "--- ReDraw ---"
    Private Sub ReDraw()
        Dim image As MIL_ID = M_NULL
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.ComboBox_Select.SelectedIndex = 0 And image <> M_NULL AndAlso Me.CheckBox_ShowBoundary.Checked Then

            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, M_NULL)

            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

            '[1] Draw Center Area Boundary ---
            Me.m_SolidBrush.Color = Color.Red
            v = (Me.NumericUpDown_BoundaryLeft.Value - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_BoundaryRight.Value - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_BoundaryTop.Value - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_BoundaryBottom.Value - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            '[2] Draw Rim Boundary ---
            Me.m_SolidBrush.Color = Color.Green
            v = (Me.NumericUpDown_ResultLeft.Value - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_ResultRight.Value - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_ResultTop.Value - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_ResultBottom.Value - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = False
    End Sub

#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_Load.Enabled = En
        Me.Button_Calculate.Enabled = En
        Me.Button_Split.Enabled = En
        Me.Button_Ok.Enabled = En
        Me.Button_Cancel.Enabled = En
        Me.BtnNext_MuraBoundary.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_2 ---"
    Private Sub Button_Enable_2(ByVal En As Boolean)
        Me.Button_Load.Enabled = En
        Me.Button_Calculate.Enabled = En
        Me.Button_Split.Enabled = En
        Me.Button_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- GetPatternIndexInfoCallback ---"
    Delegate Function GetPatternIndexInfoCallback() As Integer
    Private Function GetPatternIndexInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_PatnList.InvokeRequired Then
            Return Me.Invoke(New GetPatternIndexInfoCallback(AddressOf GetPatternIndexInfo), New Object() {})
        Else
            i = Me.ComboBox_PatnList.SelectedIndex
            Me.Update()
            Return i
        End If
    End Function
#End Region

#Region "--- ZommEnable ---"
    Private Sub ZoomEnable(ByVal En As Boolean)
        Me.m_Form.SetButton_ZoomIn(En)
        Me.m_Form.SetButton_ZoomOut(En)
        Me.m_Form.SetButton_ZoomO(En)
        Me.m_Form.SetButton_ZoomAll(En)
    End Sub
#End Region

#Region "---Split---"

    Public Sub Split()
        'Dim image As MIL_ID = M_NULL
        Dim InputImage_Type As String = ""
        Dim SaveImage As Boolean = False
        Dim Image_Range As String = ""
        Dim IP_Address As String = ""
        Dim OffsetX, OffsetY As Integer
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial --- 
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value = Me.NumericUpDown_DefocusCount.Value

            '----------------------------------------------------------------------------------------------
            ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_ORIGINALROI"
                TimeOut = 300000 '300 secs
                SaveImage = False

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    If Me.m_FFCOperation Then
                        Button_Enable_2(True)
                    Else
                        Button_Enable(True)
                    End If

                    Exit Sub
                End If

                If Response_OK Then
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        '[1] Me.m_MuraProcess.Img_ChildSample
                        If Me.m_MuraProcess.Img_ChildSample <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_ChildSample)
                            Me.m_MuraProcess.Img_ChildSample = M_NULL
                        End If

                        OffsetX = Me.NumericUpDown_ResultLeft.Value
                        OffsetY = Me.NumericUpDown_ResultTop.Value
                        SizeX = Me.NumericUpDown_ResultRight.Value - Me.NumericUpDown_ResultLeft.Value
                        SizeY = Me.NumericUpDown_ResultBottom.Value - Me.NumericUpDown_ResultTop.Value
                        Me.m_MuraProcess.Img_ChildSample = MbufChild2d(Me.m_MuraProcess.Img_CurrentSample_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)
                    Else
                        '[1] Me.m_MuraProcess.Img_ChildOriginal
                        If Me.m_MuraProcess.Img_ChildOriginal <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_ChildOriginal)
                            Me.m_MuraProcess.Img_ChildOriginal = M_NULL
                        End If

                        OffsetX = Me.NumericUpDown_ResultLeft.Value
                        OffsetY = Me.NumericUpDown_ResultTop.Value
                        SizeX = Me.NumericUpDown_ResultRight.Value - Me.NumericUpDown_ResultLeft.Value
                        SizeY = Me.NumericUpDown_ResultBottom.Value - Me.NumericUpDown_ResultTop.Value
                        Me.m_MuraProcess.Img_ChildOriginal = MbufChild2d(Me.m_MuraProcess.Img_CurrentOriginal_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.m_MuraProcess.Mura_CreateImage(Me.m_MainProcess.IPBootConfig, Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MuraProcess.MuraModelRecipe, Me.m_MainProcess.ErrorCode)   '09/22 Rick add
            If Me.ComboBox_Select.Items.Count = 1 Then
                Me.ComboBox_Select.Items.Add("�i���ϼv��")
            End If

            '----------------------------------------------------------------------------------------------
            ' Create Mura Image  ==> Request_Command = "CALCULATE_MURA_CREATEIMAGE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_CREATEIMAGE"
                TimeOut = 200000 '200 secs
                Image_Range = "PART"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Image_Range, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Create Mura Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    If Me.m_FFCOperation Then
                        Button_Enable_2(True)
                    Else
                        Button_Enable(True)
                    End If
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '2009/03/28 Rick modify ---
            If Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.ORIGINAL Then

                '----------------------------------------------------------------------------------------------
                ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_ROIEXPAND"
                    TimeOut = 200000 '200 secs
                    InputImage_Type = "CHILD_ORIGINAL"

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        If Me.m_FFCOperation Then
                            Button_Enable_2(True)
                        Else
                            Button_Enable(True)
                        End If
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 200000 '200 secs
                    InputImage_Type = "CHILD_ORIGINAL"
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        If Me.m_FFCOperation Then
                            Button_Enable_2(True)
                        Else
                            Button_Enable(True)
                        End If
                        Exit Sub
                    End If

                    If SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image 
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            ElseIf Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.FFC Then

                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 100000 '100 secs
                    InputImage_Type = "NONE"
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        If Me.m_FFCOperation Then
                            Button_Enable_2(True)
                        Else
                            Button_Enable(True)
                        End If
                        Exit Sub
                    End If

                    If SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            If Response_OK Then

                If Me.ComboBox_Select.Items.Count = 2 Then
                    Me.ComboBox_Select.Items.Add("�k�J��v��")
                End If
                Me.ComboBox_Select.SelectedIndex = 1
                Me.m_Form.CurrentIndex1 = 19
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 19
                Me.m_Form.ImageUpdate()
                Me.m_Form.ImageZoomAll()
            End If

            '--- Button Control ---   
            If Me.m_FFCOperation Then
                Button_Enable_2(True)
            Else
                Button_Enable(True)
            End If
        Catch ex As Exception
            If Me.m_FFCOperation Then
                Button_Enable_2(True)
            Else
                Button_Enable(True)
            End If
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Split]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Me.Update()
    End Sub

#End Region

#Region "---Calculate---"
    Public Sub Calculate()
        Dim boundary As ClsParameterBoundary = Nothing
        Dim boundary2 As ClsParameterBoundary = Nothing
        Dim ResizeRatio As Single
        Dim Parameter_Lists As String = ""
        Dim OutputString As String = ""
        Dim strs1() As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Calculate Mura Original Boundary  ==> Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original Boundary Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                '--- Get ROI Boundary ---
                boundary = Me.m_MuraProcess.BoundaryOriginal
                If Response_OK Then
                    OutputString = SubSystemResult.Responses(0).Param2
                    strs1 = OutputString.Split(";")

                    Select Case Me.m_DialogBoundaryType
                        Case DialogBoundaryTypeDefine.FFC
                            boundary = Me.m_MuraProcess.BoundarySample
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)

                            boundary2 = Me.m_MuraProcess.BoundaryOriginal
                            boundary2.TopY = strs1(0)
                            boundary2.BottomY = strs1(1)
                            boundary2.LeftX = strs1(2)
                            boundary2.RightX = strs1(3)
                        Case DialogBoundaryTypeDefine.ORIGINAL
                            boundary = Me.m_MuraProcess.BoundaryOriginal
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)
                    End Select

                    '--- Update MuraModelRecipe.Boundary ---
                    boundary2 = Me.m_MuraProcess.MuraModelRecipe.Boundary
                    boundary2.TopY = strs1(0)
                    boundary2.BottomY = strs1(1)
                    boundary2.LeftX = strs1(2)
                    boundary2.RightX = strs1(3)
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '--- Check Boundary ---
            ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value
            If boundary.RightX >= Me.m_MainProcess.IPBootConfig.ImageSizeX.Value / ResizeRatio Then
                boundary.RightX = (Me.m_MainProcess.IPBootConfig.ImageSizeX.Value / ResizeRatio) - 1
            End If
            If boundary.BottomY >= Me.m_MainProcess.IPBootConfig.ImageSizeY.Value / ResizeRatio Then
                boundary.BottomY = (Me.m_MainProcess.IPBootConfig.ImageSizeY.Value / ResizeRatio) - 1
            End If

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Calculate]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Button_Calculate.Text = res.GetString("Button_Calculate.Text")
                Button_Cancel.Text = res.GetString("Button_Cancel.Text")
                Button_Grab.Text = res.GetString("Button_Grab.Text")
                Button_Load.Text = res.GetString("Button_Load.Text")
                Button_Ok.Text = res.GetString("Button_Ok.Text")
                Button_Split.Text = res.GetString("Button_Split.Text")
                CheckBox_ShowBoundary.Text = res.GetString("CheckBox_ShowBoundary.Text")
                CheckBox_ShowResult.Text = res.GetString("CheckBox_ShowResult.Text")
                GroupBox_Boundary.Text = res.GetString("GroupBox_Boundary.Text")
                GroupBox_BoundaryModify.Text = res.GetString("GroupBox_BoundaryModify.Text")
                GroupBox_Grab.Text = res.GetString("GroupBox_Grab.Text")
                GroupBox_Result.Text = res.GetString("GroupBox_Result.Text")
                GroupBox_ResultModify.Text = res.GetString("GroupBox_ResultModify.Text")
                Label_BoundaryBottom.Text = res.GetString("Label_BoundaryBottom.Text")
                Label_BoundaryLeft.Text = res.GetString("Label_BoundaryLeft.Text")
                Label_BoundaryRight.Text = res.GetString("Label_BoundaryRight.Text")
                Label_BoundaryTop.Text = res.GetString("Label_BoundaryTop.Text")
                Label_ResultBottom.Text = res.GetString("Label_ResultBottom.Text")
                Label_ResultLeft.Text = res.GetString("Label_ResultLeft.Text")
                Label_ResultRight.Text = res.GetString("Label_ResultRight.Text")
                Label_ResultTop.Text = res.GetString("Label_ResultTop.Text")
                Label_Select.Text = res.GetString("Label_Select.Text")
                Label1.Text = res.GetString("Label1.Text")
                RadioButton_BoundaryFinish.Text = res.GetString("RadioButton_BoundaryFinish.Text")
                RadioButton_BoundaryManual.Text = res.GetString("RadioButton_BoundaryManual.Text")
                RadioButton_ResultFinish.Text = res.GetString("RadioButton_ResultFinish.Text")
                RadioButton_ResultManual.Text = res.GetString("RadioButton_ResultManual.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown_Boundary Event ---"
    Private Sub NumericUpDown_BoundaryTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryTop.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_BoundaryBottom.Minimum = Me.NumericUpDown_BoundaryTop.Value + 1
    End Sub
    Private Sub NumericUpDown_BoundaryBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryBottom.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_BoundaryTop.Maximum = Me.NumericUpDown_BoundaryBottom.Value - 1
    End Sub
    Private Sub NumericUpDown_BoundaryLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryLeft.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_BoundaryRight.Minimum = Me.NumericUpDown_BoundaryLeft.Value + 1
    End Sub
    Private Sub NumericUpDown_BoundaryRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BoundaryRight.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_BoundaryLeft.Maximum = Me.NumericUpDown_BoundaryRight.Value - 1
    End Sub
#End Region

#Region "--- NumericUpDown_Result Event ---"
    Private Sub NumericUpDown_ResultTop_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_ResultTop.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_ResultBottom.Minimum = Me.NumericUpDown_ResultTop.Value + 1
    End Sub
    Private Sub NumericUpDown_ResultBottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_ResultBottom.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_ResultTop.Maximum = Me.NumericUpDown_ResultBottom.Value - 1
    End Sub
    Private Sub NumericUpDown_ResultLeft_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_ResultLeft.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_ResultRight.Minimum = Me.NumericUpDown_ResultLeft.Value + 1
    End Sub
    Private Sub NumericUpDown_ResultRight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_ResultRight.ValueChanged
        Me.ReDraw()
        Me.NumericUpDown_ResultLeft.Maximum = Me.NumericUpDown_ResultRight.Value - 1
    End Sub
#End Region

#Region "--- RadioButton_Boundary Event ---"
    Private Sub RadioButton_BoundaryManual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BoundaryManual.CheckedChanged
        If Me.RadioButton_BoundaryManual.Checked Then
            Me.GroupBox_Boundary.Enabled = True
            Me.GroupBox_ResultModify.Enabled = False
            Me.ComboBox_Select.Enabled = False
            Me.Button_Load.Enabled = False
            Me.Button_Calculate.Enabled = False
            Me.Button_Split.Enabled = False
            Me.Button_Ok.Enabled = False
        End If
    End Sub
    Private Sub RadioButton_BoundaryFinish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BoundaryFinish.CheckedChanged
        If Me.RadioButton_BoundaryFinish.Checked Then
            Dim boundary As ClsParameterBoundary
            boundary = Me.m_MuraProcess.MuraModelRecipe.Boundary
            boundary.TopY = Me.NumericUpDown_BoundaryTop.Value
            boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Value
            boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Value
            boundary.RightX = Me.NumericUpDown_BoundaryRight.Value
            Me.GroupBox_Boundary.Enabled = False
            Me.ComboBox_Select.Enabled = True
            Me.Button_Load.Enabled = True
            If Me.GroupBox_BoundaryModify.Enabled Then
                Me.GroupBox_ResultModify.Enabled = True
                Me.Button_Calculate.Enabled = True
                Me.Button_Split.Enabled = True
            End If
            Me.Button_Ok.Enabled = True

        End If
    End Sub
#End Region

#Region "--- RadioButton_Result Event ---"
    Private Sub RadioButton_ResultManual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_ResultManual.CheckedChanged
        If Me.RadioButton_ResultManual.Checked Then
            Me.GroupBox_Result.Enabled = True
            Me.GroupBox_BoundaryModify.Enabled = False
            Me.ComboBox_Select.Enabled = False
            Me.Button_Load.Enabled = False
            Me.Button_Calculate.Enabled = False
            Me.Button_Split.Enabled = False
            Me.Button_Ok.Enabled = False
        End If
    End Sub
    Private Sub RadioButton_ResultFinish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_ResultFinish.CheckedChanged
        If Me.RadioButton_ResultFinish.Checked Then
            Dim boundary As ClsParameterBoundary = Nothing
            Select Case Me.m_DialogBoundaryType
                Case DialogBoundaryTypeDefine.FFC
                    boundary = Me.m_MuraProcess.BoundarySample
                Case DialogBoundaryTypeDefine.ORIGINAL
                    boundary = Me.m_MuraProcess.BoundaryOriginal
            End Select
            boundary.TopY = Me.NumericUpDown_ResultTop.Value
            boundary.BottomY = Me.NumericUpDown_ResultBottom.Value
            boundary.LeftX = Me.NumericUpDown_ResultLeft.Value
            boundary.RightX = Me.NumericUpDown_ResultRight.Value
            Me.GroupBox_Result.Enabled = False
            Me.ComboBox_Select.Enabled = True
            Me.Button_Load.Enabled = True
            If Me.GroupBox_ResultModify.Enabled Then
                Me.GroupBox_BoundaryModify.Enabled = True
                Me.Button_Calculate.Enabled = True
                Me.Button_Split.Enabled = True
            End If
            Me.Button_Ok.Enabled = True
        End If
    End Sub
#End Region

#Region "--- CheckBox Event ---"
    Private Sub CheckBox_ShowBoundary_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowBoundary.CheckedChanged
        Me.ReDraw()
    End Sub
    Private Sub CheckBox_ShowResult_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowResult.CheckedChanged
        Me.ReDraw()
    End Sub
#End Region

#Region "--- ComboBox Event ---"
    Private Sub ComboBox_Select_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Select.SelectedIndexChanged
        Select Case Me.m_DialogBoundaryType
            Case DialogBoundaryTypeDefine.FFC
                Select Case Me.ComboBox_Select.SelectedIndex
                    Case -1
                        Me.m_Form.CurrentIndex0 = 0
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 0
                    Case 0    '--- ��ϼv�� ---
                        Me.m_Form.CurrentIndex0 = 1
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 1
                        Me.EnableOp()
                    Case 1   '--- �G�ե��i���ϼv�� ---
                        Me.m_Form.CurrentIndex3 = 0
                        Me.m_Form.ComboBox_Type.SelectedIndex = 3
                        Me.m_Form.ComboBox_Select.SelectedIndex = 0
                        Me.DisableOp()
                    Case 2   '--- �i���Ͻk�J��v�� ---
                        Me.m_Form.CurrentIndex1 = 19
                        Me.m_Form.ComboBox_Type.SelectedIndex = 1
                        Me.m_Form.ComboBox_Select.SelectedIndex = 19
                        Me.DisableOp()
                End Select
            Case DialogBoundaryTypeDefine.ORIGINAL
                Select Case Me.ComboBox_Select.SelectedIndex
                    Case -1
                        Me.m_Form.CurrentIndex0 = 0
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 0
                    Case 0
                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2
                        Me.EnableOp()
                    Case 1
                        Me.m_Form.CurrentIndex1 = 0
                        Me.m_Form.ComboBox_Type.SelectedIndex = 1
                        Me.m_Form.ComboBox_Select.SelectedIndex = 0
                    Case 2
                        Me.m_Form.CurrentIndex1 = 19
                        Me.m_Form.ComboBox_Type.SelectedIndex = 1
                        Me.m_Form.ComboBox_Select.SelectedIndex = 19
                End Select
        End Select
        Me.m_Form.ImageZoomAll()
        Me.ReDraw()
    End Sub

    Private Sub ComboBox_PatnList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_PatnList.SelectedIndexChanged
        Dim PatternName As String
        Dim PatternIndex As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        'Disable ComboBox ---
        Me.ComboBox_PatnList.Enabled = False

        PatternIndex = Me.GetPatternIndexInfo
        Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '�q[1]�}�l
        Me.NumericUpDown_DefocusCount.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_PatnList.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.ComboBox_PatnList.Enabled = True
                Exit Sub
            End If

            System.Threading.Thread.Sleep(1000)
            Me.ComboBox_PatnList.Enabled = True
        Catch ex As Exception
            Me.ComboBox_PatnList.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Grab ---"
    Private Sub Button_Grab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Grab.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim ExpTime As Double

        Me.Button_Load.Enabled = False
        Me.Button_Grab.Enabled = False

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Me.Button_Load.Enabled = True
            Me.Button_Grab.Enabled = True
            Exit Sub
        End If

        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
            image = Me.m_MainProcess.Img_16U_Grab_1
            If image <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                Type = MbufInquire(image, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(image, imageBuffer)

                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                MbufControl(image, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                Me.m_Form.ResetScrollBar()
            End If
        Else
            Me.m_Form.CurrentIndex0 = 0
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 0
        End If

        Me.m_Form.ImageZoomAll()
        Me.ZoomEnable(False)

        'Thread --- Update Grab Image ---
        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Disable Button ---
            Me.Button_Grab.Enabled = False

            '--- Step 1 ---
            Try
                '--- Prepare Command ---
                Request_Command = "UPDATE_EXPOSURETIME"
                ExpTime = Me.m_MuraProcess.CurrentMuraPatternRecipe.ExposureTime.Value
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ExpTime, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Response_OK = False
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Update Current Exposure Time Error ! (" & ex.Message & ")")
                'MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "GRAB_ONESHOT"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , Me.CheckBox_Cal.Checked, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Load.Enabled = True
                    Me.Button_Grab.Enabled = True
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Grab Image ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        image = Me.m_MainProcess.Img_16U_Grab_1

                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)

                        Me.m_Form.ImageUpdate()
                        Me.ZoomEnable(False)
                    End If

                    imageBuffer = Me.m_MainProcess.Img_16U_Grab_1
                    If Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.ORIGINAL Then
                        image = Me.m_MuraProcess.Img_ChildOriginal
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If
                        image = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If
                        image = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If

                        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                        SizeX = MbufInquire(imageBuffer, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(imageBuffer, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)
                        If image <> M_NULL Then
                            If SizeX <> MbufInquire(image, M_SIZE_X, M_NULL) Or SizeY <> MbufInquire(image, M_SIZE_Y, M_NULL) Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        End If
                    Else
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- ��s��l�v�� ---
                    If Response_OK Then
                        MbufCopy(imageBuffer, image)
                    End If
                Else
                    image = Me.m_MuraProcess.Img_ChildSample
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If

                    image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                    SizeX = MbufInquire(imageBuffer, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(imageBuffer, M_SIZE_Y, M_NULL)
                    Type = MbufInquire(image, M_TYPE, M_NULL)
                    If image <> M_NULL Then
                        If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image)
                            image = M_NULL
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- ��s��l�v�� ---
                    If Response_OK Then
                        MbufCopy(imageBuffer, image)
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Step 2 ---
            '----------------------------------------------------------------------------------------------
            ' IP LOAD GRAB IMAGE  ==> Request_Command = "LOAD_GRABIMAGE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_GRABIMAGE"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Grab Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Load.Enabled = True
                    Me.Button_Grab.Enabled = False
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Step 3 ---
            If Response_OK Then

                '----------------------------------------------------------------------------------------------
                ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "RESIZE_ORIGINAL"
                    TimeOut = 100000 '100 secs
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Grab.Enabled = True
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.Button_Grab.Enabled = True
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.Button_Grab]Resize Original Image Error ! (" & ex.Message & "(" & ex.StackTrace & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Grab]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image ---
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                    Else
                        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                    End If

                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                            MbufCopy(image, Me.m_MuraProcess.Img_CurrentSample_NonPage)
                        Else
                            MbufCopy(image, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)
                        End If

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If

                    Me.ComboBox_Select.Enabled = True
                    Me.ComboBox_Select.Items.Clear()
                    Me.ComboBox_Select.Items.Add("���R�v��")
                    Me.ComboBox_Select.SelectedIndex = 0
                    Me.EnableOp()
                    Me.Button_Load.Enabled = True
                    Me.Button_Grab.Enabled = True
                    Call Me.m_Form.ImageZoomAll()
                End If

                Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            End If

            'Enable Button
            Me.ZoomEnable(True)
            Me.Button_Grab.Enabled = True
            Me.Button_Load.Enabled = True

        Catch ex As Exception
            Me.ZoomEnable(True)
            Me.Button_Load.Enabled = True
            Me.Button_Grab.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.Button_Grab](" & ex.Message & ")(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Grab]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try
    End Sub
#End Region

#Region "--- Button_Load ---"
    Private Sub Button_Load_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Load.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim strPath As String
        Dim SaveImage As Boolean = False
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim ResizeRatio As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
            ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value

            '--- Button Control ---   
            Me.Button_Load.Enabled = False

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                Select Case Me.m_DialogBoundaryType
                    Case DialogBoundaryTypeDefine.FFC
                        image = Me.m_MuraProcess.Img_ChildSample
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If
                        image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                    Case DialogBoundaryTypeDefine.ORIGINAL
                        image = Me.m_MuraProcess.Img_ChildOriginal
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If
                        image = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If
                        image = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
                        If image <> M_NULL Then
                            MbufFree(image)
                            image = M_NULL
                        End If
                        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                End Select

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, image)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("���ˬd�Ҷ}�Ҫ��v���ɮ׬O�_�ŦX�ثeIP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 1000000 '1000 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        'If SubSystemResult.Responses(0).Param1 = "1" Then
                        '    Me.m_Form.CheckBox_IsAligned.Checked = True
                        '    Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                        '    Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                        '    Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                        '    Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                        '    Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.LeftX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX / ResizeRatio)
                        '    Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.TopY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY / ResizeRatio)
                        '    Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.RightX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX / ResizeRatio)
                        '    Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.BottomY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY / ResizeRatio)
                        '    Me.NumericUpDown_BoundaryLeft.Value = Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.LeftX
                        '    Me.NumericUpDown_BoundaryTop.Value = Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.TopY
                        '    Me.NumericUpDown_BoundaryRight.Value = Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.RightX
                        '    Me.NumericUpDown_BoundaryBottom.Value = Me.m_MainProcess.MuraProcess.MuraModelRecipe.Boundary.BottomY
                        '    strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                        '    RepairPath_2(strPath)
                        '    MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                        'Else
                        'Me.m_Form.CheckBox_IsAligned.Checked = False
                        'End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Load.Enabled = True
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Transfer Mura Boundary  ==> Request_Command = "Transfer_Mura_Boundary" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                'Try
                '    '--- Prepare Command ---
                '    Request_Command = "Transfer_Mura_Boundary"
                '    TimeOut = 10000 '10 secs

                '    Response_OK = False
                '    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                '        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                '        Response_OK = True
                '    Else
                '        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                '        Button_Enable(True)
                '        Exit Sub
                '    End If
                'Catch ex As Exception
                '    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                'End Try

                '--- Resize \ Defocus image ---
                If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 100000 '100 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraBoundary.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Load.Enabled = True
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)

                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    Me.m_MuraProcess.Img_CurrentSample_NonPage = image
                                Else
                                    Me.m_MuraProcess.Img_CurrentOriginal_NonPage = image
                                End If

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)
                                'If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                '    MbufCopy(image, Me.m_MuraProcess.Img_CurrentSample_NonPage)
                                'Else
                                '    MbufCopy(image, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)
                                'End If

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            Me.m_Form.ImageUpdate()
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                Else
                    '----------------------------------------------------------------------------------------------
                    ' Defocus Original Image  ==> Request_Command = "DEFOCUS_ORIGINAL_2" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "DEFOCUS_ORIGINAL_2"
                        TimeOut = 1000000 '1000 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Defocus Original_2 Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraBoundary.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Load.Enabled = True
                            Exit Sub
                        End If

                        If Response_OK Then
                            '--- Update Processed Image ---
                            image = Me.m_MuraProcess.Img_16U_Defocus_NonPage
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "DefocusOriginal_2.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "DefocusOriginal_2.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = image

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)
                                'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                Me.m_Form.ImageUpdate()
                            End If
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If

                Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("���R�v��")
                Me.ComboBox_Select.SelectedIndex = 0

                Select Case Me.m_DialogBoundaryType
                    Case DialogBoundaryTypeDefine.FFC
                        If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then

                        Else
                            If Me.m_FFCOperation Then
                                If Me.m_Form.ComboBox_Select.SelectedIndex > 0 Then Me.m_Form.ComboBox_Select.SelectedIndex = 1
                            Else
                                If Me.m_Form.ComboBox_Select.SelectedIndex > 0 Then Me.m_Form.ComboBox_Select.SelectedIndex = 2
                            End If
                        End If
                    Case DialogBoundaryTypeDefine.ORIGINAL
                        If Me.ComboBox_Select.SelectedIndex = 0 Then

                        Else
                            If Me.m_Form.ComboBox_Select.SelectedIndex > -1 Then Me.ComboBox_Select.SelectedIndex = 0
                        End If
                End Select

                If Me.ComboBox_Select.Items.Count = 2 Then
                    Me.ComboBox_Select.Items.RemoveAt(1)
                End If

                Me.m_Form.Show()
                Call Me.m_Form.ImageZoomAll()
                Me.CheckBox_ShowBoundary.Checked = True
            End If

            '--- Button Control ---   
            Me.Button_Load.Enabled = True
        Catch ex As Exception
            Me.Button_Load.Enabled = True
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Load]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Load]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Me.Update()
    End Sub
#End Region

#Region "--- Button_Calculate ---"
    Private Sub Button_Calculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Calculate.Click
        Dim boundary As ClsParameterBoundary = Nothing
        Dim boundary2 As ClsParameterBoundary = Nothing
        Dim ResizeRatio As Single
        Dim Parameter_Lists As String = ""
        Dim OutputString As String = ""
        Dim strs1() As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraBoundary Setting   ==> Request_Command = "DIALOG_MURABOUNDARY_SETTING"  (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURABOUNDARY_SETTING"
                TimeOut = 200000 '200 secs

                Parameter_Lists = "BoundaryTop," & Me.NumericUpDown_BoundaryTop.Value & ";" & "BoundaryBottom," & Me.NumericUpDown_BoundaryBottom.Value & ";" & "BoundaryLeft," & Me.NumericUpDown_BoundaryLeft.Value & ";" & _
                                  "BoundaryRight," & Me.NumericUpDown_BoundaryRight.Value & ";" & "DefocusCount," & Me.NumericUpDown_DefocusCount.Value

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraBoundary Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    If Me.m_FFCOperation Then
                        Button_Enable_2(True)
                    Else
                        Button_Enable(True)
                    End If
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Mura Original Boundary  ==> Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original Boundary Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    If Me.m_FFCOperation Then
                        Button_Enable_2(True)
                    Else
                        Button_Enable(True)
                    End If
                    Exit Sub
                End If

                '--- Get ROI Boundary ---
                boundary = Me.m_MuraProcess.BoundaryOriginal
                If Response_OK Then
                    OutputString = SubSystemResult.Responses(0).Param2
                    strs1 = OutputString.Split(";")

                    Select Case Me.m_DialogBoundaryType
                        Case DialogBoundaryTypeDefine.FFC
                            boundary = Me.m_MuraProcess.BoundarySample
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)

                            boundary2 = Me.m_MuraProcess.BoundaryOriginal
                            boundary2.TopY = strs1(0)
                            boundary2.BottomY = strs1(1)
                            boundary2.LeftX = strs1(2)
                            boundary2.RightX = strs1(3)
                        Case DialogBoundaryTypeDefine.ORIGINAL
                            boundary = Me.m_MuraProcess.BoundaryOriginal
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)
                    End Select

                    '--- Update MuraModelRecipe.Boundary ---
                    boundary2 = Me.m_MuraProcess.MuraModelRecipe.Boundary
                    boundary2.TopY = strs1(0)
                    boundary2.BottomY = strs1(1)
                    boundary2.LeftX = strs1(2)
                    boundary2.RightX = strs1(3)
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '--- Check Boundary ---
            ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value
            If boundary.RightX >= Me.m_MainProcess.IPBootConfig.ImageSizeX.Value / ResizeRatio Then
                boundary.RightX = (Me.m_MainProcess.IPBootConfig.ImageSizeX.Value / ResizeRatio) - 1
            End If
            If boundary.BottomY >= Me.m_MainProcess.IPBootConfig.ImageSizeY.Value / ResizeRatio Then
                boundary.BottomY = (Me.m_MainProcess.IPBootConfig.ImageSizeY.Value / ResizeRatio) - 1
            End If

            If Not Response_OK Then
                MsgBox("��ɤ��R���~", MsgBoxStyle.Critical, "[AreaGrabber]")
            Else
                Me.NumericUpDown_ResultTop.Value = boundary.TopY
                Me.NumericUpDown_ResultBottom.Value = boundary.BottomY
                Me.NumericUpDown_ResultLeft.Value = boundary.LeftX
                Me.NumericUpDown_ResultRight.Value = boundary.RightX
                Me.CheckBox_ShowResult.Checked = True
            End If

            '--- Button Control ---   
            If Me.m_FFCOperation Then
                Button_Enable_2(True)
            Else
                Button_Enable(True)
            End If
        Catch ex As Exception
            If Me.m_FFCOperation Then
                Button_Enable_2(True)
            Else
                Button_Enable(True)
            End If
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Calculate]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Split ---"
    Private Sub Button_Split_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Split.Click
        'Dim image As MIL_ID = M_NULL
        Dim InputImage_Type As String = ""
        Dim SaveImage As Boolean = False
        Dim Image_Range As String = ""
        Dim IP_Address As String = ""
        Dim OffsetX, OffsetY As Integer
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial --- 
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value = Me.NumericUpDown_DefocusCount.Value

            '----------------------------------------------------------------------------------------------
            ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_ORIGINALROI"
                TimeOut = 300000 '300 secs
                SaveImage = False

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    If Me.m_FFCOperation Then
                        Button_Enable_2(True)
                    Else
                        Button_Enable(True)
                    End If

                    Exit Sub
                End If

                If Response_OK Then
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        '[1] Me.m_MuraProcess.Img_ChildSample
                        If Me.m_MuraProcess.Img_ChildSample <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_ChildSample)
                            Me.m_MuraProcess.Img_ChildSample = M_NULL
                        End If

                        OffsetX = Me.NumericUpDown_ResultLeft.Value
                        OffsetY = Me.NumericUpDown_ResultTop.Value
                        SizeX = Me.NumericUpDown_ResultRight.Value - Me.NumericUpDown_ResultLeft.Value
                        SizeY = Me.NumericUpDown_ResultBottom.Value - Me.NumericUpDown_ResultTop.Value
                        Me.m_MuraProcess.Img_ChildSample = MbufChild2d(Me.m_MuraProcess.Img_CurrentSample_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)
                    Else
                        '[1] Me.m_MuraProcess.Img_ChildOriginal
                        If Me.m_MuraProcess.Img_ChildOriginal <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_ChildOriginal)
                            Me.m_MuraProcess.Img_ChildOriginal = M_NULL
                        End If

                        OffsetX = Me.NumericUpDown_ResultLeft.Value
                        OffsetY = Me.NumericUpDown_ResultTop.Value
                        SizeX = Me.NumericUpDown_ResultRight.Value - Me.NumericUpDown_ResultLeft.Value
                        SizeY = Me.NumericUpDown_ResultBottom.Value - Me.NumericUpDown_ResultTop.Value
                        Me.m_MuraProcess.Img_ChildOriginal = MbufChild2d(Me.m_MuraProcess.Img_CurrentOriginal_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.m_MuraProcess.Mura_CreateImage(Me.m_MainProcess.IPBootConfig, Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MuraProcess.MuraModelRecipe, Me.m_MainProcess.ErrorCode)   '09/22 Rick add
            If Me.ComboBox_Select.Items.Count = 1 Then
                Me.ComboBox_Select.Items.Add("�i���ϼv��")
            End If

            '----------------------------------------------------------------------------------------------
            ' Create Mura Image  ==> Request_Command = "CALCULATE_MURA_CREATEIMAGE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_CREATEIMAGE"
                TimeOut = 200000 '200 secs
                Image_Range = "PART"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Image_Range, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Create Mura Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    If Me.m_FFCOperation Then
                        Button_Enable_2(True)
                    Else
                        Button_Enable(True)
                    End If
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '2009/03/28 Rick modify ---
            If Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.ORIGINAL Then

                '----------------------------------------------------------------------------------------------
                ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_ROIEXPAND"
                    TimeOut = 200000 '200 secs
                    InputImage_Type = "CHILD_ORIGINAL"

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        If Me.m_FFCOperation Then
                            Button_Enable_2(True)
                        Else
                            Button_Enable(True)
                        End If
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 200000 '200 secs
                    InputImage_Type = "CHILD_ORIGINAL"
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        If Me.m_FFCOperation Then
                            Button_Enable_2(True)
                        Else
                            Button_Enable(True)
                        End If
                        Exit Sub
                    End If

                    If SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image 
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            ElseIf Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.FFC Then

                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 100000 '100 secs
                    InputImage_Type = "NONE"
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        If Me.m_FFCOperation Then
                            Button_Enable_2(True)
                        Else
                            Button_Enable(True)
                        End If
                        Exit Sub
                    End If

                    If SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            If Response_OK Then

                If Me.ComboBox_Select.Items.Count = 2 Then
                    Me.ComboBox_Select.Items.Add("�k�J��v��")
                End If
                Me.ComboBox_Select.SelectedIndex = 1
                Me.m_Form.CurrentIndex1 = 19
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 19
                Me.m_Form.ImageUpdate()
                Me.m_Form.ImageZoomAll()
            End If

            '--- Button Control ---   
            If Me.m_FFCOperation Then
                Button_Enable_2(True)
            Else
                Button_Enable(True)
            End If
        Catch ex As Exception
            If Me.m_FFCOperation Then
                Button_Enable_2(True)
            Else
                Button_Enable(True)
            End If
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Split]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Me.Update()
    End Sub
#End Region

#Region "--- Button_Ok ---"
    Private Sub Button_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Ok.Click
        Dim str As String
        Dim dirPath As String
        Dim Parameter_Lists As String = ""
        Dim PatternName As String
        Dim PatternIndex As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value = Me.NumericUpDown_DefocusCount.Value

            dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)
            Me.m_MuraProcess.SaveMuraModelRecipe(dirPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

            '[AreaGrabber]
            PatternIndex = Me.GetPatternIndexInfo
            Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '�q[1]�}�l

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.ComboBox_PatnList.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.Button_Ok]Set Pattern Index Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraBoundary Setting   ==> Request_Command = "DIALOG_MURABOUNDARY_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURABOUNDARY_SETTING"
                TimeOut = 100000 '100 secs

                Parameter_Lists = "BoundaryTop," & Me.NumericUpDown_BoundaryTop.Value & ";" & "BoundaryBottom," & Me.NumericUpDown_BoundaryBottom.Value & ";" & "BoundaryLeft," & Me.NumericUpDown_BoundaryLeft.Value & ";" & _
                                  "BoundaryRight," & Me.NumericUpDown_BoundaryRight.Value & ";" & "DefocusCount," & Me.NumericUpDown_DefocusCount.Value

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraBoundary Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Mura Model Recipe  ==> Request_Command = "SAVE_MURA_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_MURA_MODEL_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Ok]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region

#Region "--- BtnNext_MuraBoundary ---"
    Private Sub BtnNext_MuraBoundary_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnNext_MuraBoundary.Click
        Me.Close()
        Me.m_Form.Button_Smooth_Click()
    End Sub
#End Region

#End Region

#Region "--- AxMDisplay Operation ---"

#Region "--- m_AxMDisplay_PaintEvent ---"
    Private Sub m_AxMDisplay_PaintEvent(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            Me.ReDraw()
        End If
    End Sub
#End Region

#Region "--- m_Panel_AxMDisplay_MouseDownEvent ---"

    Private Sub m_Panel_AxMDisplay_MouseDownEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If e.Button = Windows.Forms.MouseButtons.Left Then

            If Me.RadioButton_BoundaryManual.Checked And Me.CheckBox_ShowBoundary.Checked Then

                '--- Initial ---
                'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
                '--- Initial ---

                p = (Me.NumericUpDown_BoundaryLeft.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                dis1 = Math.Abs(e.X - p)
                p = (Me.NumericUpDown_BoundaryRight.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                dis2 = Math.Abs(e.X - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomX * 0.5 + 3 Then
                        Me.m_Left = True
                    End If
                Else
                    If dis2 < ZoomX * 0.5 + 3 Then
                        Me.m_Right = True
                    End If
                End If
                p = (Me.NumericUpDown_BoundaryTop.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                dis1 = Math.Abs(e.Y - p)
                p = (Me.NumericUpDown_BoundaryBottom.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                dis2 = Math.Abs(e.Y - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomX * 0.5 + 3 Then
                        Me.m_Top = True
                    End If
                Else
                    If dis2 < ZoomX * 0.5 + 3 Then
                        Me.m_Bottom = True
                    End If
                End If
            End If
            If Me.RadioButton_ResultManual.Checked And Me.CheckBox_ShowResult.Checked Then
                p = (Me.NumericUpDown_ResultLeft.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                dis1 = Math.Abs(e.X - p)
                p = (Me.NumericUpDown_ResultRight.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                dis2 = Math.Abs(e.X - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomX * 0.5 + 3 Then
                        Me.m_Left = True
                    End If
                Else
                    If dis2 < ZoomX * 0.5 + 3 Then
                        Me.m_Right = True
                    End If
                End If
                p = (Me.NumericUpDown_ResultTop.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomX
                dis1 = Math.Abs(e.Y - p)
                p = (Me.NumericUpDown_ResultBottom.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomX
                dis2 = Math.Abs(e.Y - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomX * 0.5 + 3 Then
                        Me.m_Top = True
                    End If
                Else
                    If dis2 < ZoomX * 0.5 + 3 Then
                        Me.m_Bottom = True
                    End If
                End If
            End If
        End If
    End Sub
#End Region

#Region "--- m_Panel_AxMDisplay_MouseUpEvent ---"
    Private Sub m_Panel_AxMDisplay_MouseUpEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_Left = False
            Me.m_Right = False
            Me.m_Top = False
            Me.m_Bottom = False
        End If
    End Sub
#End Region

#Region "--- m_Panel_AxMDisplay_MouseMove ---"
    Private Sub m_Panel_AxMDisplay_MouseMove(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        If Me.RadioButton_BoundaryManual.Checked And Me.CheckBox_ShowBoundary.Checked Then
            If Me.m_Left Then
                Me.NumericUpDown_BoundaryLeft.Value = Me.m_Form.MouseX
            End If
            If Me.m_Right Then
                Me.NumericUpDown_BoundaryRight.Value = Me.m_Form.MouseX
            End If
            If Me.m_Top Then
                Me.NumericUpDown_BoundaryTop.Value = Me.m_Form.MouseY
            End If
            If Me.m_Bottom Then
                Me.NumericUpDown_BoundaryBottom.Value = Me.m_Form.MouseY
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If
        If Me.RadioButton_ResultManual.Checked And Me.CheckBox_ShowResult.Checked Then
            If Me.m_Left Then
                Me.NumericUpDown_ResultLeft.Value = Me.m_Form.MouseX
            End If
            If Me.m_Right Then
                Me.NumericUpDown_ResultRight.Value = Me.m_Form.MouseX
            End If
            If Me.m_Top Then
                Me.NumericUpDown_ResultTop.Value = Me.m_Form.MouseY
            End If
            If Me.m_Bottom Then
                Me.NumericUpDown_ResultBottom.Value = Me.m_Form.MouseY
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- UI Event ---"

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If Me.Focused AndAlso CheckBox_ShowBoundary.Checked Then Me.ReDraw()
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If Me.Focused AndAlso CheckBox_ShowBoundary.Checked Then Me.ReDraw()
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDraw()
        End If
    End Sub
#End Region

#End Region


End Class

Public Enum DialogBoundaryTypeDefine As Byte
    FFC = 1
    ORIGINAL = 2
End Enum