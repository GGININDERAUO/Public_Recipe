<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraAutoManual
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_MuraAutoManual))
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.Button_Ok = New System.Windows.Forms.Button()
        Me.Label_Percentage = New System.Windows.Forms.Label()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.ProgressBar = New System.Windows.Forms.ProgressBar()
        Me.Label_ExposureTime = New System.Windows.Forms.Label()
        Me.NumericUpDown_ExposureTime = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_ExposureTime = New System.Windows.Forms.GroupBox()
        Me.TrackBar_ExposureTime = New System.Windows.Forms.TrackBar()
        Me.Label_Time = New System.Windows.Forms.Label()
        Me.GroupBox_Grab = New System.Windows.Forms.GroupBox()
        Me.ComboBox_ColorBand = New System.Windows.Forms.ComboBox()
        Me.Button_Grab = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button_Continue = New System.Windows.Forms.Button()
        Me.GroupBox_ImageSource = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox_PatnList = New System.Windows.Forms.ComboBox()
        Me.Button_Load = New System.Windows.Forms.Button()
        Me.Button_Next = New System.Windows.Forms.Button()
        Me.RadioButton_Auto = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Manual = New System.Windows.Forms.RadioButton()
        Me.CheckBox_FilterMura = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveMuraDefectsImgs = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Mode = New System.Windows.Forms.GroupBox()
        Me.CheckBox_AutoAddFalse = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FilterFalseCPD = New System.Windows.Forms.CheckBox()
        Me.CheckBox_UpdateImage = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FFCReplace = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveResult = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Result = New System.Windows.Forms.GroupBox()
        CType(Me.NumericUpDown_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ExposureTime.SuspendLayout()
        CType(Me.TrackBar_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Grab.SuspendLayout()
        Me.GroupBox_ImageSource.SuspendLayout()
        Me.GroupBox_Mode.SuspendLayout()
        Me.GroupBox_Result.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        '
        'Button_Ok
        '
        resources.ApplyResources(Me.Button_Ok, "Button_Ok")
        Me.Button_Ok.Name = "Button_Ok"
        '
        'Label_Percentage
        '
        resources.ApplyResources(Me.Label_Percentage, "Label_Percentage")
        Me.Label_Percentage.Name = "Label_Percentage"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.UseVisualStyleBackColor = True
        '
        'ProgressBar
        '
        resources.ApplyResources(Me.ProgressBar, "ProgressBar")
        Me.ProgressBar.Name = "ProgressBar"
        '
        'Label_ExposureTime
        '
        resources.ApplyResources(Me.Label_ExposureTime, "Label_ExposureTime")
        Me.Label_ExposureTime.Name = "Label_ExposureTime"
        '
        'NumericUpDown_ExposureTime
        '
        resources.ApplyResources(Me.NumericUpDown_ExposureTime, "NumericUpDown_ExposureTime")
        Me.NumericUpDown_ExposureTime.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Maximum = New Decimal(New Integer() {2000000, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Name = "NumericUpDown_ExposureTime"
        Me.NumericUpDown_ExposureTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'GroupBox_ExposureTime
        '
        resources.ApplyResources(Me.GroupBox_ExposureTime, "GroupBox_ExposureTime")
        Me.GroupBox_ExposureTime.Controls.Add(Me.Button_Save)
        Me.GroupBox_ExposureTime.Controls.Add(Me.Label_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.NumericUpDown_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.TrackBar_ExposureTime)
        Me.GroupBox_ExposureTime.Name = "GroupBox_ExposureTime"
        Me.GroupBox_ExposureTime.TabStop = False
        '
        'TrackBar_ExposureTime
        '
        resources.ApplyResources(Me.TrackBar_ExposureTime, "TrackBar_ExposureTime")
        Me.TrackBar_ExposureTime.LargeChange = 10000
        Me.TrackBar_ExposureTime.Maximum = 2000000
        Me.TrackBar_ExposureTime.Minimum = 1
        Me.TrackBar_ExposureTime.Name = "TrackBar_ExposureTime"
        Me.TrackBar_ExposureTime.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_ExposureTime.Value = 1
        '
        'Label_Time
        '
        resources.ApplyResources(Me.Label_Time, "Label_Time")
        Me.Label_Time.Name = "Label_Time"
        '
        'GroupBox_Grab
        '
        resources.ApplyResources(Me.GroupBox_Grab, "GroupBox_Grab")
        Me.GroupBox_Grab.Controls.Add(Me.ComboBox_ColorBand)
        Me.GroupBox_Grab.Controls.Add(Me.Button_Grab)
        Me.GroupBox_Grab.Controls.Add(Me.Label9)
        Me.GroupBox_Grab.Controls.Add(Me.Button_Continue)
        Me.GroupBox_Grab.Name = "GroupBox_Grab"
        Me.GroupBox_Grab.TabStop = False
        '
        'ComboBox_ColorBand
        '
        resources.ApplyResources(Me.ComboBox_ColorBand, "ComboBox_ColorBand")
        Me.ComboBox_ColorBand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_ColorBand.ForeColor = System.Drawing.Color.Red
        Me.ComboBox_ColorBand.FormattingEnabled = True
        Me.ComboBox_ColorBand.Items.AddRange(New Object() {resources.GetString("ComboBox_ColorBand.Items"), resources.GetString("ComboBox_ColorBand.Items1"), resources.GetString("ComboBox_ColorBand.Items2"), resources.GetString("ComboBox_ColorBand.Items3")})
        Me.ComboBox_ColorBand.Name = "ComboBox_ColorBand"
        '
        'Button_Grab
        '
        resources.ApplyResources(Me.Button_Grab, "Button_Grab")
        Me.Button_Grab.Name = "Button_Grab"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'Button_Continue
        '
        resources.ApplyResources(Me.Button_Continue, "Button_Continue")
        Me.Button_Continue.Name = "Button_Continue"
        '
        'GroupBox_ImageSource
        '
        resources.ApplyResources(Me.GroupBox_ImageSource, "GroupBox_ImageSource")
        Me.GroupBox_ImageSource.Controls.Add(Me.Label1)
        Me.GroupBox_ImageSource.Controls.Add(Me.ComboBox_PatnList)
        Me.GroupBox_ImageSource.Controls.Add(Me.GroupBox_Grab)
        Me.GroupBox_ImageSource.Controls.Add(Me.Button_Load)
        Me.GroupBox_ImageSource.Name = "GroupBox_ImageSource"
        Me.GroupBox_ImageSource.TabStop = False
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'ComboBox_PatnList
        '
        resources.ApplyResources(Me.ComboBox_PatnList, "ComboBox_PatnList")
        Me.ComboBox_PatnList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PatnList.FormattingEnabled = True
        Me.ComboBox_PatnList.Name = "ComboBox_PatnList"
        '
        'Button_Load
        '
        resources.ApplyResources(Me.Button_Load, "Button_Load")
        Me.Button_Load.Name = "Button_Load"
        '
        'Button_Next
        '
        resources.ApplyResources(Me.Button_Next, "Button_Next")
        Me.Button_Next.Name = "Button_Next"
        '
        'RadioButton_Auto
        '
        resources.ApplyResources(Me.RadioButton_Auto, "RadioButton_Auto")
        Me.RadioButton_Auto.Name = "RadioButton_Auto"
        '
        'RadioButton_Manual
        '
        resources.ApplyResources(Me.RadioButton_Manual, "RadioButton_Manual")
        Me.RadioButton_Manual.Name = "RadioButton_Manual"
        '
        'CheckBox_FilterMura
        '
        resources.ApplyResources(Me.CheckBox_FilterMura, "CheckBox_FilterMura")
        Me.CheckBox_FilterMura.Name = "CheckBox_FilterMura"
        '
        'CheckBox_SaveMuraDefectsImgs
        '
        resources.ApplyResources(Me.CheckBox_SaveMuraDefectsImgs, "CheckBox_SaveMuraDefectsImgs")
        Me.CheckBox_SaveMuraDefectsImgs.Name = "CheckBox_SaveMuraDefectsImgs"
        Me.CheckBox_SaveMuraDefectsImgs.UseVisualStyleBackColor = True
        '
        'GroupBox_Mode
        '
        resources.ApplyResources(Me.GroupBox_Mode, "GroupBox_Mode")
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_AutoAddFalse)
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_FilterFalseCPD)
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_UpdateImage)
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_SaveMuraDefectsImgs)
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_FilterMura)
        Me.GroupBox_Mode.Controls.Add(Me.RadioButton_Manual)
        Me.GroupBox_Mode.Controls.Add(Me.RadioButton_Auto)
        Me.GroupBox_Mode.Controls.Add(Me.Button_Next)
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_FFCReplace)
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_SaveResult)
        Me.GroupBox_Mode.Name = "GroupBox_Mode"
        Me.GroupBox_Mode.TabStop = False
        '
        'CheckBox_AutoAddFalse
        '
        resources.ApplyResources(Me.CheckBox_AutoAddFalse, "CheckBox_AutoAddFalse")
        Me.CheckBox_AutoAddFalse.Name = "CheckBox_AutoAddFalse"
        '
        'CheckBox_FilterFalseCPD
        '
        resources.ApplyResources(Me.CheckBox_FilterFalseCPD, "CheckBox_FilterFalseCPD")
        Me.CheckBox_FilterFalseCPD.Name = "CheckBox_FilterFalseCPD"
        Me.CheckBox_FilterFalseCPD.UseVisualStyleBackColor = True
        '
        'CheckBox_UpdateImage
        '
        resources.ApplyResources(Me.CheckBox_UpdateImage, "CheckBox_UpdateImage")
        Me.CheckBox_UpdateImage.Checked = True
        Me.CheckBox_UpdateImage.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_UpdateImage.Name = "CheckBox_UpdateImage"
        Me.CheckBox_UpdateImage.UseVisualStyleBackColor = True
        '
        'CheckBox_FFCReplace
        '
        resources.ApplyResources(Me.CheckBox_FFCReplace, "CheckBox_FFCReplace")
        Me.CheckBox_FFCReplace.Name = "CheckBox_FFCReplace"
        '
        'CheckBox_SaveResult
        '
        resources.ApplyResources(Me.CheckBox_SaveResult, "CheckBox_SaveResult")
        Me.CheckBox_SaveResult.Name = "CheckBox_SaveResult"
        '
        'GroupBox_Result
        '
        resources.ApplyResources(Me.GroupBox_Result, "GroupBox_Result")
        Me.GroupBox_Result.Controls.Add(Me.Label_Time)
        Me.GroupBox_Result.Controls.Add(Me.ProgressBar)
        Me.GroupBox_Result.Controls.Add(Me.Label_Percentage)
        Me.GroupBox_Result.Name = "GroupBox_Result"
        Me.GroupBox_Result.TabStop = False
        '
        'Dialog_MuraAutoManual
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GroupBox_Mode)
        Me.Controls.Add(Me.GroupBox_Result)
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.Button_Ok)
        Me.Controls.Add(Me.GroupBox_ExposureTime)
        Me.Controls.Add(Me.GroupBox_ImageSource)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraAutoManual"
        Me.ShowInTaskbar = False
        CType(Me.NumericUpDown_ExposureTime,System.ComponentModel.ISupportInitialize).EndInit
        Me.GroupBox_ExposureTime.ResumeLayout(false)
        Me.GroupBox_ExposureTime.PerformLayout
        CType(Me.TrackBar_ExposureTime,System.ComponentModel.ISupportInitialize).EndInit
        Me.GroupBox_Grab.ResumeLayout(false)
        Me.GroupBox_Grab.PerformLayout
        Me.GroupBox_ImageSource.ResumeLayout(false)
        Me.GroupBox_ImageSource.PerformLayout
        Me.GroupBox_Mode.ResumeLayout(false)
        Me.GroupBox_Mode.PerformLayout
        Me.GroupBox_Result.ResumeLayout(false)
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button
    Friend WithEvents Button_Ok As System.Windows.Forms.Button
    Friend WithEvents Label_Percentage As System.Windows.Forms.Label
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents ProgressBar As System.Windows.Forms.ProgressBar
    Friend WithEvents Label_ExposureTime As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ExposureTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_ExposureTime As System.Windows.Forms.GroupBox
    Friend WithEvents TrackBar_ExposureTime As System.Windows.Forms.TrackBar
    Friend WithEvents Label_Time As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Grab As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Grab As System.Windows.Forms.Button
    Friend WithEvents Button_Continue As System.Windows.Forms.Button
    Friend WithEvents GroupBox_ImageSource As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Load As System.Windows.Forms.Button
    Friend WithEvents ComboBox_PatnList As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Next As System.Windows.Forms.Button
    Friend WithEvents RadioButton_Auto As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Manual As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_FilterMura As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveMuraDefectsImgs As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Mode As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_UpdateImage As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FilterFalseCPD As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Result As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_ColorBand As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_AutoAddFalse As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_SaveResult As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FFCReplace As System.Windows.Forms.CheckBox
End Class
