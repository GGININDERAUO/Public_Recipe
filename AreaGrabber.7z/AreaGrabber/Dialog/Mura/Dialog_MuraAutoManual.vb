Imports MILOperationLib
Imports AUO.SubSystemControl
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.IO
Imports ClassLibrary
Imports System.Threading
Imports System.Globalization

Public Class Dialog_MuraAutoManual
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_CurrentStep As Integer
    Private m_Continue As Boolean
    Private m_Have_MDigitizer As Boolean
    Private m_Have_FFCImage As Boolean
    Private m_Thread1_RunCommand As Threading.Thread = Nothing  '�u����R�O�v����� 1
    Private m_Thread1_RunCommandFinishEvent As System.Threading.ManualResetEvent
    Private m_SaveImage As Boolean
    Private m_ContinueGrab As Boolean
    Private m_Grab_OK As Boolean
    Private m_ReadWriteLock As New System.Threading.ReaderWriterLock()
    Private m_ReadyToUpdateImage As Boolean

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '--- Master\Slave Mode ---
    Private m_MasterSlaveMode_Enable As Boolean
    Private m_Master_ID As Integer
    Private m_Slave_ID As Integer
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_MuraAutoManual", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess
        Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
        Me.m_Continue = False
        Me.WaitGrabReady()

        Me.m_MasterSlaveMode_Enable = Me.m_IPBootConfig.MasterSlaveMode_Enable.Value  '2014/12/04 Rick add
        Me.m_Master_ID = 0
        Me.m_Slave_ID = 1

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Check Digitizer  ==> Request_Command = "CHECK_DIGITIZER" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CHECK_DIGITIZER"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                If SubSystemResult.Responses(0).Param1.ToUpper = "TRUE" Then
                    Me.m_Have_MDigitizer = True
                Else
                    Me.m_Have_MDigitizer = False
                End If
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Check Digitizer Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.SetMainForm]Check Digitizer Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
        If image <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        Me.m_Form.ImageZoomAll()

        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
            If Me.m_MuraProcess.Img_CurrentSample_NonPage <> M_NULL Then
                Me.GroupBox_Mode.Enabled = True
            Else
                Me.GroupBox_Mode.Enabled = False
            End If
        Else
            If Me.m_MuraProcess.Img_CurrentOriginal_NonPage <> M_NULL Then
                Me.GroupBox_Mode.Enabled = True
            Else
                Me.GroupBox_Mode.Enabled = False
            End If
        End If

        If Me.m_Have_MDigitizer Then
            Me.GroupBox_Grab.Enabled = True
        Else
            Me.GroupBox_Grab.Enabled = False
        End If

        Me.m_ContinueGrab = False
        Me.m_Grab_OK = False
        Me.GroupBox_ExposureTime.Enabled = False
        Me.Button_Grab.Enabled = False

        '--- �v������ ---
        Me.UpdateUserLevel()

    End Sub

#Region "--- Dialog Event ---"

#Region "--- Dialog_AutoManual_Load ---"
    Private Sub Dialog_AutoManual_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Me.RadioButton_Auto.Checked = True
        Me.Button_Grab.Enabled = False

        Try
            Me.m_ReadyToUpdateImage = False

            '--- Pattern Lists ---
            Me.ComboBox_PatnList.Items.Clear()
            For i = 0 To Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1
                Me.ComboBox_PatnList.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next

            If Me.m_Form.GetPatternIndexInfo > Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
                Me.ComboBox_PatnList.SelectedIndex = 0
            Else
                Me.ComboBox_PatnList.SelectedIndex = Me.m_Form.GetPatternIndexInfo
            End If

            '--- Color Band List ---
            Me.ComboBox_ColorBand.Items.Clear()
            If Me.m_IPBootConfig.Digitizer_Type.Value = DigitizerType.Color Then
                Me.ComboBox_ColorBand.Items.Add("R")
                Me.ComboBox_ColorBand.Items.Add("G")
                Me.ComboBox_ColorBand.Items.Add("B")
                Me.ComboBox_ColorBand.Items.Add("L")
                Me.ComboBox_ColorBand.ForeColor = Color.Red
            Else
                Me.ComboBox_ColorBand.Enabled = False
            End If

            If Me.m_MuraProcess.Img_CurrentOriginal_NonPage <> M_NULL Then
                Me.GroupBox_Mode.Enabled = True
            Else
                Me.GroupBox_Mode.Enabled = False
            End If

            If Not Me.m_Have_MDigitizer Then
                Button_Continue.Enabled = False
            End If
            Me.m_Form.ImageUpdate()
            Me.m_ReadyToUpdateImage = True
            Me.m_Form.ComboBox_Pattern_MainFrm.Enabled = False
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.FormLoad]" & ex.Message)
        End Try

        Me.Update()
    End Sub
#End Region

#Region "--- Dialog_AutoManual_Closing ---"
    Private Sub Dialog_AutoManual_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.ComboBox_Pattern_MainFrm.Enabled = True
        Me.WaitGrabReady()

        '--- ���� RunCommand thread ---
        Me.m_Thread1_RunCommand = Nothing
        Me.m_Continue = False
        Me.Dispose()
    End Sub
#End Region

#End Region

#Region "<--- Property --->"
    Public Property ContinueGrab() As Boolean
        Get
            Return Me.m_ContinueGrab
        End Get
        Set(ByVal Value As Boolean)
            Me.m_ContinueGrab = Value
        End Set
    End Property
#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_ImageSource.Enabled = False
                Me.GroupBox_ExposureTime.Enabled = False
                Me.GroupBox_Mode.Enabled = False
            Case 1 'PM
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = False
                Me.GroupBox_Mode.Enabled = True
            Case 2 'ENG
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
            Case 3 'ALL
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- DoStep ---"
    Private Function DoStep(ByRef ErrorCode As UInt32) As Boolean
        Dim mp As ClsMuraProcess
        Dim boundary As ClsParameterBoundary = Nothing
        Dim boundary2 As ClsParameterBoundary = Nothing
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim str As String
        Dim dir1 As String
        Dim str2 As String = ""
        Dim InputImage_Type As String = ""
        Dim ImageFilePath As String = ""
        Dim Image_Range As String = ""
        Dim DirPath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim RoundExpandWidth As Integer = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
        Dim ResizeBMPFileName As String = ""
        Dim ResizeBMPWithDefectFileName As String = ""
        Dim ResizeBMPCount As Integer = 1

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
        str = ""
        mp = Me.m_MuraProcess

        Select Case Me.m_CurrentStep

            Case 1
                '----------------------------------------------------------------------------------------------
                ' IP Clear Mura Group Defects  ==> Request_Command = "CLEAR_MURAGROUP" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CLEAR_MURAGROUP"
                    TimeOut = 100000 '100 secs

                    '--- Local Action ---
                    mp.MuraGroup.Clear()
                    mp.MuraGroup_All.Clear()

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_Form.OpenFileDialog.FileName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Clear Mura Group Defects Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Calculate_BLFFC ==> Request_Command = "CALCULATE_BLFFC" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                If Me.m_MuraProcess.MuraModelRecipe.UseBLFFC.Value Then
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLFFC"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate_BLFFC Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                '----------------------------------------------------------------------------------------------
                ' CALCULATE_FFT ==> Request_Command = "CALCULATE_FFT" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFT.Value Then
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_FFT"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "CALCULATE_FFT Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]CALCULATE_FFT Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                '----------------------------------------------------------------------------------------------
                ' Calculate Mura Original Boundary  ==> Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"  (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original Boundary Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]��ɤ��R���~ (" & SubSystemResult.ErrMessage & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                    '--- Get ROI Boundary ---
                    boundary = Me.m_MuraProcess.BoundaryOriginal
                    If Response_OK Then
                        OutputString = SubSystemResult.Responses(0).Param2
                        strs1 = OutputString.Split(";")

                        If Me.m_MuraProcess.MuraModelRecipe.UseAutoFFC.Value Then
                            boundary = Me.m_MuraProcess.BoundarySample
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)

                            boundary2 = Me.m_MuraProcess.BoundaryOriginal
                            boundary2.TopY = strs1(0)
                            boundary2.BottomY = strs1(1)
                            boundary2.LeftX = strs1(2)
                            boundary2.RightX = strs1(3)
                        Else
                            boundary = Me.m_MuraProcess.BoundaryOriginal
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)
                        End If

                        '--- Update MuraModelRecipe.Boundary ---
                        boundary2 = Me.m_MuraProcess.MuraModelRecipe.Boundary
                        boundary2.TopY = strs1(0)
                        boundary2.BottomY = strs1(1)
                        boundary2.LeftX = strs1(2)
                        boundary2.RightX = strs1(3)
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate Mura Original Boundary Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MURA_ORIGINALROI"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, "TRUE", , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]�Ψ�ROI�v�����~ (" & SubSystemResult.ErrMessage & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                    If Response_OK Then
                        '--- Update Processed Image ---
                        '�קK�v�����|, 2011/01/30 Rick add
                        If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                            Me.m_MuraProcess.CalculateFFCROI(ErrorCode)
                        Else
                            Me.m_MuraProcess.CalculateOriginalROI(ErrorCode)
                        End If
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate Mura Original ROI Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Create Mura Image  ==> Request_Command = "CALCULATE_MURA_CREATEIMAGE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MURA_CREATEIMAGE"
                    TimeOut = 300000 '300 secs
                    Image_Range = "PART"

                    '--- Local Action ---
                    Me.m_MuraProcess.Mura_CreateImage(Me.m_MainProcess.IPBootConfig, Me.m_MuraProcess.BoundaryOriginal, Me.m_MuraProcess.MuraModelRecipe, ErrorCode)

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Image_Range, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Create Mura Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Create Mura Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '--- �s�ϽT�{ --- 
                'mp.Img_ChildOriginal_1.Save("D:\Mura_Img_ChildOriginal.tif")

            Case 2

                If Not Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                    '----------------------------------------------------------------------------------------------
                    ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
                    ' �T�{�B�z���v���GImg_ChildOriginal�C(���M�b�ϥ�FFC���p�U�A�䬰�y�{����C)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_ROIEXPAND"
                        TimeOut = 200000 '200 secs
                        InputImage_Type = "CHILD_ORIGINAL"

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate ROI Expand Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

            Case 3
                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 100000 '100 secs

                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        InputImage_Type = "NONE"
                    Else
                        InputImage_Type = "CHILD_ORIGINAL"
                    End If

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, Me.m_SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                    If Me.m_SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.DoStep]Calculate Defocus Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

            Case 4
                If mp.CurrentMuraPatternRecipe.UseFFC.Value Then

                    '----------------------------------------------------------------------------------------------
                    ' Change_FFC
                    '----------------------------------------------------------------------------------------------
                    If Me.CheckBox_FFCReplace.Checked Then
                        Request_Command = "CALCULATE_FFCALIGN_IMAGE"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Align Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraSetting.Button_FFCImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                            Exit Function
                        End If

                        Try
                            '--- Prepare Command ---
                            Request_Command = "SAVE_CURRENT_FFC_IMAGE"
                            TimeOut = 200000 '200 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current FFC Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_MuraSetting.Button_SaveFFCImages]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Return False
                                Exit Function
                            End If

                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try

                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Check FFC Image  ==> Request_Command = "CHECK_FFC_IMAGE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CHECK_FFC_IMAGE"
                        TimeOut = 100000 '100 secs

                        '--- Local Action ---
                        dir1 = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
                        str2 = dir1 & "\ImageFFC_C" & Me.m_MainProcess.GrabNo & "_P" & (Me.m_Form.GetPatternIndexInfo + 1) & ".tif"

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str2, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                            If SubSystemResult.Responses(0).Param1.ToUpper = "TRUE" Then
                                Me.m_Have_FFCImage = True
                            Else
                                Me.m_Have_FFCImage = False
                                MsgBox("[Dialog_MuraAutoMannual.DoStep]Pattern = " & Me.m_MuraProcess.CurrentMuraPatternRecipe.PatternName.Value & " �ʤ֫G�ե��v�� Data !", MsgBoxStyle.Critical, "[AreaGrabber]")   '2009/09/25 Rick modify

                                '--- Local Action ---
                                Me.m_CurrentStep = 0
                                Me.ProgressBar.Value = 0
                                Return False
                            End If
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Check FFC Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage & "(Path�G" & str2 & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Check FFC Image Error ! (" & ex.Message & ")" & "(Path�G" & str2 & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message & "(Path�G" & str2 & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try


                    If mp.Img_CurrentFFCAlign <> M_NULL Then
                        'mp.CalculateFFCResult(ErrorCode)
                        'mp.CalculateROIExpand(mp.Img_16U_FFCResult_NonPage, ErrorCode)

                        '----------------------------------------------------------------------------------------------
                        ' Calculate FFC Result Image  ==> Request_Command = "CALCULATE_FFCRESULT" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "CALCULATE_FFCRESULT"
                            TimeOut = 300000 '300 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate FFC Result Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                                '--- Local Action ---
                                Me.m_CurrentStep = 0
                                Me.ProgressBar.Value = 0
                                Return False
                            End If

                            If Me.m_SaveImage AndAlso Response_OK Then
                                '--- Update Processed Image ---
                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_FFCResult_NonPage.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_FFCResult_NonPage.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If Me.m_MuraProcess.Img_16U_FFCResult_NonPage <> M_NULL Then
                                        If MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(Me.m_MuraProcess.Img_16U_FFCResult_NonPage)
                                            Me.m_MuraProcess.Img_16U_FFCResult_NonPage = M_NULL
                                            Me.m_MuraProcess.Img_16U_FFCResult_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        Me.m_MuraProcess.Img_16U_FFCResult_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_FFCResult_NonPage)

                                    If System.IO.File.Exists(strPath) = True Then
                                        System.IO.File.Delete(strPath)
                                    End If
                                End If
                            End If
                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate FFC Align Image Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End Try

                        '----------------------------------------------------------------------------------------------
                        ' Calculate ROI Expand Image (With FFC) ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "CALCULATE_ROIEXPAND"
                            TimeOut = 200000 '200 secs
                            InputImage_Type = "FFC_RESULT"

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image (With FFC) Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                                '--- Local Action ---
                                Me.m_CurrentStep = 0
                                Me.ProgressBar.Value = 0
                                Return False
                            End If

                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate ROI Expand Image (With FFC)  Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End Try

                        'mp.Img_16U_ROIExpand_NonPage.Save("D:\Img_16U_ROIExpand_NonPage.tif")
                    Else
                        MsgBox("[Dialog_MuraAutoMannual.DoStep]Pattern = " & Me.m_MuraProcess.CurrentMuraPatternRecipe.PatternName.Value & " �ʤ֫G�ե��v�� Data !", MsgBoxStyle.Critical, "[AreaGrabber]")   '2009/09/25 Rick modify
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If
                End If

                '----------------------------------------------------------------------------------------------
                ' Calculate Smooth Image  ==> Request_Command = "CALCULATE_SMOOTH" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_SMOOTH"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.RemoveHVBand.Value Then
                        '--- Prepare Command ---
                        Request_Command = "REMOVE_HVBAND"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If
                    End If

                    If Me.m_SaveImage AndAlso Response_OK Then
                        '[1] --- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)
                                    Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If

                        '[2] --- Update Processed Image ---
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)
                                    Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If

                        '----------------------------------------------------------------------------------------------
                        ' Calculate Smooth Image  ==> Request_Command = "CALCULATE_SMOOTH" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------

                        '[3] --- Update Processed Image ---
                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If

                        If Me.m_MuraProcess.Img_BlobMura_SmoothChild <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_BlobMura_SmoothChild)
                            Me.m_MuraProcess.Img_BlobMura_SmoothChild = M_NULL
                        End If
                        Me.m_MuraProcess.Img_BlobMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        '[4] Update Processed Image ---
                        If Me.m_MuraProcess.Img_MacroMura_SmoothChild <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_MacroMura_SmoothChild)
                            Me.m_MuraProcess.Img_MacroMura_SmoothChild = M_NULL
                        End If
                        Me.m_MuraProcess.Img_MacroMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Smooth Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                'mp.Img_16U_BlobMura_Smooth_NonPage.Save("D:\Img_16U_BlobMura_Smooth_NonPage.tif")

            Case 5
                If mp.CurrentMuraPatternRecipe.UseCenter.Value Or mp.CurrentMuraPatternRecipe.UseRound.Value Then
                    '----------------------------------------------------------------------------------------------
                    ' Calculate Area Golden Sample Image  ==> Request_Command = "CALCULATE_AREA_GOLDENSAMPLE" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_AREA_GOLDENSAMPLE"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Area Golden Sample Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then

                            '--- Blob Mura ---
                            '[1] Update Processed Image (Img_16U_BlobMura_ResizeH_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_BlobMura_ResizeHChild) ---
                                If Me.m_MuraProcess.Img_BlobMura_ResizeHChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlobMura_ResizeHChild)
                                    Me.m_MuraProcess.Img_BlobMura_ResizeHChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_BlobMura_ResizeHChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            '[3] Update Processed Image (Img_16U_BlobMura_ResizeL_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[4] Update Processed Image (Img_BlobMura_ResizeLChild) ---
                                If Me.m_MuraProcess.Img_BlobMura_ResizeLChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlobMura_ResizeLChild)
                                    Me.m_MuraProcess.Img_BlobMura_ResizeLChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_BlobMura_ResizeLChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            'Macro Mura ---
                            '[1] Update Processed Image (Img_16U_MacroMura_ResizeH_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_MacroMura_ResizeHChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_ResizeHChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_ResizeHChild)
                                    Me.m_MuraProcess.Img_MacroMura_ResizeHChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_MacroMura_ResizeHChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            '[3] Update Processed Image (Img_16U_MacroMura_ResizeL_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[4] Update Processed Image (Img_MacroMura_ResizeLChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_ResizeLChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_ResizeLChild)
                                    Me.m_MuraProcess.Img_MacroMura_ResizeLChild = M_NULL
                                End If
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_MuraProcess.Img_MacroMura_ResizeLChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Area Golden Sample Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    'mp.Img_16U_GoldenSample_NonPage.Save("D:\Img_16U_GoldenSample_NonPage.tif")
                End If
            Case 6
                If mp.CurrentMuraPatternRecipe.UseCenter.Value Or mp.CurrentMuraPatternRecipe.UseRound.Value Then
                    '�v���۴� - Blob Black
                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Area Image  ==> Request_Command = "CALCULATE_BLACK_AREA" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACK_AREA"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_BlobMura_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_BlobMuraArea_BlackChild) ---
                                If Me.m_MuraProcess.Img_BlobMuraArea_BlackChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlobMuraArea_BlackChild)
                                    Me.m_MuraProcess.Img_BlobMuraArea_BlackChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_BlobMuraArea_BlackChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Area Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If mp.CurrentMuraPatternRecipe.UseCenter.Value Then
                    '�v���۴� - Blob Black
                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Macro Image  ==> Request_Command = "CALCULATE_BLACK_MACRO" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACK_MACRO"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_MacroMura_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_MacroMura_BlackChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_BlackChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_BlackChild)
                                    Me.m_MuraProcess.Img_MacroMura_BlackChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_MacroMura_BlackChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Macro Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Blob Mura (Area-���߰�)  ==> Request_Command = "CALCULATE_BLACKBLOB_AREA" (Dispatcher 2)
                    ' �p�� Black Blob + Macro 
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACKBLOB_AREA"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_BlackReconstructArea_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage)
                                        Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_BlackThreshold_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage)
                                        Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Blob Mura  Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If mp.CurrentMuraPatternRecipe.UseCenter.Value Or mp.CurrentMuraPatternRecipe.UseRound.Value Then
                    '�v���۴� - Blob White
                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Area Image  ==> Request_Command = "CALCULATE_WHITE_AREA" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITE_AREA"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_BlobMura_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_BlobMuraArea_WhiteChild) ---
                            If Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild <> M_NULL Then
                                MbufFree(Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild)
                                Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild = M_NULL
                            End If

                            If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                            Else
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                            End If

                            Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Area Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If mp.CurrentMuraPatternRecipe.UseCenter.Value Then
                    '�v���۴� - Macro White
                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Macro Image  ==> Request_Command = "CALCULATE_WHITE_MACRO" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITE_MACRO"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_MacroMura_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_MacroMura_WhiteChild) ---
                                If Me.m_MuraProcess.Img_MacroMura_WhiteChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_MacroMura_WhiteChild)
                                    Me.m_MuraProcess.Img_MacroMura_WhiteChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_MacroMura_WhiteChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Macro Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Blob Mura (Area-���߰�)  ==> Request_Command = "CALCULATE_WHITEBLOB_AREA" (Dispatcher 2)
                    ' �p�� White Blob + Macro 
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITEBLOB_AREA"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_WhiteReconstructArea_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage)
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_WhiteThreshold_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage)
                                        Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Blob Mura  Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    'mp.Img_16U_BlobMura_White_NonPage.Save("D:\Me.m_Img_16U_BlobMura_White_NonPage.tif")
                    'mp.Img_16U_BlobMura_Black_NonPage.Save("D:\Me.m_Img_16U_BlobMura_Black_NonPage.tif")
                End If
            Case 7
                If mp.CurrentMuraPatternRecipe.UseRound.Value Then

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Reconstruct Rim Image  ==> Request_Command = "CALCULATE_RECONSTRUCT_RIM" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_RECONSTRUCT_RIM"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Reconstruct Rim Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '--- White Reconstruct Rim ---

                            '[1] Update Processed Image (Img_1U_WhiteReconstructRim_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_WhiteReconstructRImChild) ---
                                If Me.m_MuraProcess.Img_WhiteReconstructRImChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_WhiteReconstructRImChild)
                                    Me.m_MuraProcess.Img_WhiteReconstructRImChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_WhiteReconstructRImChild = MbufChild2d(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                            'Black Reconstruct Rim ---

                            '[1] Update Processed Image (Img_1U_BlackReconstructRim_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage)
                                        Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If

                                '[2] Update Processed Image (Img_BlackReconstructRimChild) ---
                                If Me.m_MuraProcess.Img_BlackReconstructRimChild <> M_NULL Then
                                    MbufFree(Me.m_MuraProcess.Img_BlackReconstructRimChild)
                                    Me.m_MuraProcess.Img_BlackReconstructRimChild = M_NULL
                                End If

                                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                                Else
                                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                                End If

                                Me.m_MuraProcess.Img_BlackReconstructRimChild = MbufChild2d(Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                            End If

                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Reconstruct Rim Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Rim Mura  ==> Request_Command = "CALCULATE_BLACKBLOB_RIM" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACKBLOB_RIM"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Rim Mura Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Rim Mura  ==> Request_Command = "CALCULATE_WHITEBLOB_RIM" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITEBLOB_RIM"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Rim Mura Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                End If
                If mp.CurrentMuraPatternRecipe.UseBand.Value Then

                    '**** ���� BandMura ******************************************************************************

                    '----------------------------------------------------------------------------------------------
                    ' Calculate V-Band Mura ROI Image  ==> Request_Command = "CALCULATE_VROI" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_VROI"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_VGolden_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_BandMura_ChildOriginalV.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_BandMura_ChildOriginalV.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_BandMura_ChildOriginalV <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalV, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalV, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalV)
                                        Me.m_MuraProcess.Img_BandMura_ChildOriginalV = M_NULL
                                        Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_BandMura_ChildOriginalV)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                        'If Response_OK Then
                        '    '[1] Update Processed Image (Img_BandMura_ChildOriginalV) ---
                        '    'RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
                        '    If Me.m_MuraProcess.Img_BandMura_ChildOriginalV <> M_NULL Then
                        '        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalV)
                        '        Me.m_MuraProcess.Img_BandMura_ChildOriginalV = M_NULL
                        '    End If
                        '    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) - Me.m_MuraProcess.MuraModelRecipe.Band.RightX - Me.m_MuraProcess.MuraModelRecipe.Band.LeftX - 2 * RoundExpandWidth
                        '    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) - 2 * RoundExpandWidth

                        '    While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
                        '        SizeX = SizeX - 1
                        '    End While

                        '    While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
                        '        SizeY = SizeY - 1
                        '    End While

                        '    Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.TopY, SizeX, SizeY, M_NULL)
                        'End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate V-Band Mura ROI Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate V-Band Mura Projection Image  ==> Request_Command = "CALCULATE_VBAND_PROJECT" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_VBAND_PROJECT"
                        TimeOut = 200000 '200 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_VProject_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VProject_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VProject_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VProject_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VProject_NonPage)
                                        Me.m_MuraProcess.Img_16U_VProject_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VProject_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate V-Band Mura Projection Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Golden V-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_V" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_GOLDEN_V"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden V-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_VGolden_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VGolden_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VGolden_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VGolden_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VGolden_NonPage)
                                        Me.m_MuraProcess.Img_16U_VGolden_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VGolden_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Golden V-Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try


                    '**** ���� BandMura ******************************************************************************

                    '----------------------------------------------------------------------------------------------
                    ' Calculate H-Band Mura ROI Image  ==> Request_Command = "CALCULATE_HROI" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_HROI"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_VGolden_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_BandMura_ChildOriginalH.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_BandMura_ChildOriginalH.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_BandMura_ChildOriginalH <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalH, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalH, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalH)
                                        Me.m_MuraProcess.Img_BandMura_ChildOriginalH = M_NULL
                                        Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_BandMura_ChildOriginalH)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                        'If Response_OK Then
                        '    '[1] Update Processed Image (Img_BandMura_ChildOriginalH) ---
                        '    'RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
                        '    If Me.m_MuraProcess.Img_BandMura_ChildOriginalH <> M_NULL Then
                        '        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalH)
                        '        Me.m_MuraProcess.Img_BandMura_ChildOriginalH = M_NULL
                        '    End If

                        '    While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
                        '        SizeX = SizeX - 1
                        '    End While

                        '    While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)
                        '        SizeY = SizeY - 1
                        '    End While

                        '    Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.TopY, SizeX, SizeY, M_NULL)
                        'End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate H-Band Mura ROI Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate H-Band Mura Projection Image  ==> Request_Command = "CALCULATE_HBAND_PROJECT" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_HBAND_PROJECT"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HProject_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HProject_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HProject_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HProject_NonPage)
                                        Me.m_MuraProcess.Img_16U_HProject_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HProject_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate H-Band Mura Projection Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Golden H-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_H" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_GOLDEN_H"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden H-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HGolden_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HGolden_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HGolden_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HGolden_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HGolden_NonPage)
                                        Me.m_MuraProcess.Img_16U_HGolden_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HGolden_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Golden H-Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate White Band Image  ==> Request_Command = "CALCULATE_WHITE_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_WHITE_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HBand_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_HBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_16U_VBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VBand_White_NonPage)
                                        Me.m_MuraProcess.Img_16U_VBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate White Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate Black Band Image  ==> Request_Command = "CALCULATE_BLACK_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_BLACK_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_16U_HBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_HBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_16U_VBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_16U_VBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Black Band Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate H-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_H_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_H_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_HBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_HBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_HBand_White_NonPage)
                                        Me.m_MuraProcess.Img_1U_HBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_HBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_HBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate H-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Calculate V-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_V_BAND" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_V_BAND"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                        If Me.m_SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image (Img_1U_VBand_White_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_VBand_White_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_VBand_White_NonPage)
                                        Me.m_MuraProcess.Img_1U_VBand_White_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_White_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            '[2] Update Processed Image (Img_1U_VBand_Black_NonPage) ---
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If Me.m_MuraProcess.Img_1U_VBand_Black_NonPage <> M_NULL Then
                                    If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)
                                        Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = M_NULL
                                        Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate V-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

            Case 8

                '----------------------------------------------------------------------------------------------
                ' Calculate Mura JND  ==> Request_Command = "CALCULATE_JND" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_JND"
                    TimeOut = 500000 '500 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura JND Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Mura JND Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Shift all Mura Position to global position  ==> Request_Command = "POSITION_SHIFT_ALL" (Dispatcher 2)
                ' Function�G Shift to global position
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "POSITION_SHIFT_ALL"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Shift all Mura Position to global position  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Mura JND Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' MappingTable Translation  ==> Request_Command = "CALCULATE_MAPTOTABLE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_MAPTOTABLE"
                    TimeOut = 500000 '500 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate MappingTable Translation Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate MappingTable Translation Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try


                If Me.CheckBox_FilterMura.Checked Then
                    '----------------------------------------------------------------------------------------------
                    ' Filter Mura within Regions  ==> Request_Command = "MURA_FILTERREGION_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_FILTERREGION_ANALYSIS"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Filter Mura within Regions Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Calculate Filter Mura within Regions Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                '----------------------------------------------------------------------------------------------
                ' Merge all Mura Group  ==> Request_Command = "MERGE_MURAGROUP_ALL" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "MERGE_MURAGROUP_ALL"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Merge all Mura Group Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Merge all Mura Group Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                If Me.CheckBox_FilterFalseCPD.Checked Then

                    '----------------------------------------------------------------------------------------------
                    ' Filter Mura With False Defect Table  ==> Request_Command = "MURA_FILTERFALSECPD_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_FILTERFALSECPD_ANALYSIS"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.CheckBox_FilterFalseCPD.Checked, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Filter Mura With False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Filter CPD Mura With False Defect Table Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                If Me.CheckBox_FilterMura.Checked And Me.CheckBox_AutoAddFalse.Checked Then

                    '----------------------------------------------------------------------------------------------
                    ' Filter Mura With False Defect Table  ==> Request_Command = "MURA_FILTERWITHFALSE_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_FILTERWITHFALSE_ANALYSIS"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Filter Mura With False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Filter Mura With False Defect Table Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' End Filter Mura With False Defect Table  ==> Request_Command = "MURA_ENDFILTERWITHFALSE_ANALYSIS" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_ENDFILTERWITHFALSE_ANALYSIS"
                        TimeOut = 600000 '600 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "End Filter Mura With False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]End Filter Mura With False Defect Table Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try



                    '----------------------------------------------------------------------------------------------
                    ' Reset Mura False  ==> Request_Command = "MURA_RESETFALSE" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "MURA_RESETFALSE"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Reset Mura False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Reset Mura False Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                '���o Mura All Group Defects
                '----------------------------------------------------------------------------------------------
                ' Get all Mura Group Defects ==> Request_Command = "GET_ALL_MURA_RESULT" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "GET_ALL_MURA_RESULT"
                    TimeOut = 500000 '500 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get all Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If

                    If Response_OK Then
                        '--- �ѷs Defect ----
                        OutputString = SubSystemResult.Responses(0).Param2
                        Me.m_MainProcess.AddMuraString(OutputString)
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Merge allGet all Mura Group Defects Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save all Mura Group Defects ==> Request_Command = "GET_ALL_MURA_RESULT" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                If Me.CheckBox_SaveResult.Checked Then
                    Dim MuraResultPath As String = ""
                    Dim MuraResultFile As String = ""
                    MuraResultPath = Me.m_MainProcess.IPBootConfig.CharacteristicPath.Value & "\" & Format(Now, "yyyyMMddHH").Substring(0, 8)
                    If Not System.IO.Directory.Exists(MuraResultPath) Then
                        System.IO.Directory.CreateDirectory(MuraResultPath)
                    End If
                    MuraResultFile = MuraResultPath & "\" & Me.m_Form.PanelID & ".txt"
                    Try
                        '--- Prepare Command ---
                        Request_Command = "GET_ALL_MURA_RESULT"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, MuraResultFile, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get all Mura Group Defects Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Merge allGet all Mura Group Defects Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If


                '----------------------------------------------------------------------------------------------
                ' Save Mura False Defect Table  ==> Request_Command = "SAVE_MURA_FALSEDEFECTTABLE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_MURA_FALSEDEFECTTABLE"
                    TimeOut = 100000 '100 secs

                    '--- Save MuraFalse Defect Table ---
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\\" & Me.m_Form.GetProductNameInfo & "\\Mura\\MuraFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str)
                    str = str.Replace("\", "\\")

                    '--- Save MuraFalse Defect Table ---
                    str2 = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\\" & Me.m_Form.GetProductNameInfo & "\\Mura\\MuraFalseDefectTableBackup_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str2)
                    str2 = str2.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, str2, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Save Mura False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                        '--- Local Action ---
                        Me.m_CurrentStep = 0
                        Me.ProgressBar.Value = 0
                        Return False
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Save Mura False Defect File Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return False
                End Try

                Me.m_Form.ResultUpdate()

            Case 9

                If Me.CheckBox_SaveMuraDefectsImgs.Checked Then

                    '----------------------------------------------------------------------------------------------
                    ' Save intermediate images ==> Request_Command = "SAVE_INTERMEDIATE_IMAGE" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SAVE_INTERMEDIATE_IMAGE"
                        TimeOut = 200000 '200 secs
                        ImageFilePath = Me.m_MainProcess.IMAGE_PATH & "\\IP" & Me.m_Form.ComboBox_CCD.Text & "\\AAAAAAAA\\ChipNo_C" & Me.m_MainProcess.CCDNo & "_P" & Me.m_Form.GetPatternNameInfo & "_FMura"
                        DirPath = Me.m_MainProcess.IMAGE_PATH & "\\IP" & Me.m_Form.ComboBox_CCD.Text & "\\AAAAAAAA\\"

                        If Me.m_MuraProcess.CurrentMuraPatternRecipe.SaveResizeBMP.Value Then
                            If System.IO.Directory.Exists(Me.m_MainProcess.IPBootConfig.ResizeBMPPath.Value & "\IP" & Me.m_Form.ComboBox_CCD.Text & "\AAAAAAAA") Then
                                System.IO.Directory.CreateDirectory(Me.m_MainProcess.IPBootConfig.ResizeBMPPath.Value & "\IP" & Me.m_Form.ComboBox_CCD.Text & "\AAAAAAAA")
                            End If
                            If System.IO.Directory.Exists(Me.m_MainProcess.IPBootConfig.ResizeBMPWithDefectPath.Value & "\IP" & Me.m_Form.ComboBox_CCD.Text & "\AAAAAAAA") Then
                                System.IO.Directory.CreateDirectory(Me.m_MainProcess.IPBootConfig.ResizeBMPWithDefectPath.Value & "\IP" & Me.m_Form.ComboBox_CCD.Text & "\AAAAAAAA")
                            End If
                            ResizeBMPFileName = Me.m_MainProcess.IPBootConfig.ResizeBMPPath.Value & "\\IP" & Me.m_Form.ComboBox_CCD.Text & "\\AAAAAAAA\\ChipNo_C" & Me.m_MainProcess.CCDNo & "_P" & Me.m_Form.GetPatternNameInfo & "_FMura"
                            ResizeBMPWithDefectFileName = Me.m_MainProcess.IPBootConfig.ResizeBMPWithDefectPath.Value & "\\IP" & Me.m_Form.ComboBox_CCD.Text & "\\AAAAAAAA\\ChipNo_C" & Me.m_MainProcess.CCDNo & "_P" & Me.m_Form.GetPatternNameInfo & "_FMura"
                            ResizeBMPCount = Me.m_MainProcess.IPBootConfig.ResizeBMPCount.Value
                        End If

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, ImageFilePath, DirPath, ResizeBMPFileName, ResizeBMPWithDefectFileName, ResizeBMPCount, , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save intermediate images Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Save intermediate images Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Save Mura Defect Image ==> Request_Command = "SAVE_MURA_DEFECTIMAGE" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SAVE_MURA_DEFECTIMAGE"
                        TimeOut = 100000 '100 secs

                        '--- Save MuraFalse Defect Table ---
                        str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                        Me.m_MuraProcess.MuraFalseFilter.SaveMuraFalse(str)
                        str = str.Replace("\", "\\")

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Save Mura Defect Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            '--- Local Action ---
                            Me.m_CurrentStep = 0
                            Me.ProgressBar.Value = 0
                            Return False
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoMannual.DoStep]Save Mura Defect Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoMannual.DoStep]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Return False
                    End Try
                End If

                Me.m_MainProcess.CountMuraDefect()

                Me.Button_Next.Enabled = False
        End Select

        If Me.m_CurrentStep >= 10 Then Me.m_CurrentStep = 9
        Me.ProgressBar.Value = 100 * Me.m_CurrentStep / 9.0
        Return True
    End Function
#End Region

#Region "--- Compare ---"
    Private Sub Compare(ByVal mprOld As ClsMuraPatternRecipe, ByVal mprNew As ClsMuraPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[Exposure Time Change]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        If mprOld.ExposureTime.Value <> mprNew.ExposureTime.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< ExposureTime >: " & mprOld.ExposureTime.Value & " --> " & mprNew.ExposureTime.Value)
            mprOld.ExposureTime = mprNew.ExposureTime
        End If
    End Sub
#End Region

#Region "--- WaitGrabReady ---"
    Private Sub WaitGrabReady()
        Dim i As Integer = 10

        If Not Me.m_ReadyToUpdateImage Then Exit Sub

        If Me.m_ContinueGrab Then
            Me.m_ContinueGrab = False
            While (Not Me.m_Grab_OK And i >= 0)
                System.Threading.Thread.Sleep(200)
                'Application.DoEvents()
                i = i - 1
            End While

            Me.m_Grab_OK = True
        End If

    End Sub
#End Region

#Region "--- UpdateExposureTime ---"
    Public Sub UpdateExposureTime()
        Dim ExposureTime As Long

        If Me.m_Have_MDigitizer Then

            '[AreaGrabber]
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                ExposureTime = Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex).ExposureTime.Value
            Else
                ExposureTime = Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex - Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value).ExposureTime.Value
            End If

            '--- �n���ɶ��̤p�ݨD 16000 ---
            'If ExposureTime < 16000 Then ExposureTime = 16000

            Me.TrackBar_ExposureTime.Value = ExposureTime
            Me.NumericUpDown_ExposureTime.Value = ExposureTime

        End If
    End Sub
#End Region

#Region "--- UpdateGrabImage ---"
    Public Sub UpdateGrabImage()
        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim strPath_Exists As Boolean
        Dim ColorBand As String
        ColorBand = Me.GetColorBandInfo  'Image Band (R\G\B\L --> Color�۾� �G�ť� --> Mono�۾�)

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
            End If

            If System.IO.File.Exists(strPath) Then
                Directory.CreateDirectory(strPath)
            End If

            '--- Disable ScrollBar ---
            Me.ScrollBar_Enable(False)

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)

            Me.m_Grab_OK = False

            Try
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                SyncLock Me.m_MainProcess.IP_Dispatcher1
                    '--- Prepare Command ---
                    Request_Command = "GRAB_ONESHOT"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ColorBand, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                End SyncLock

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.UpdateGrabImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Response_OK = False
                Me.m_ContinueGrab = False
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                Me.RepairPath_2(strPath)
            End If

            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
            MbufDiskInquire(strPath, M_TYPE, Type)
            strPath_Exists = System.IO.File.Exists(strPath)

            If Response_OK Then
                '--- Update Processed Image ---
                Grab_Success = Grab_Success + 1
                Image = Me.m_MainProcess.Img_16U_Grab_1

                If strPath_Exists Then
                    If Image <> M_NULL Then
                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Image)
                            Image = M_NULL
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Image)

                    Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                    Me.m_Form.ImageUpdate()
                End If
            End If

            Do
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GRAB_ONESHOT"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.UpdateGrabImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    If Response_OK Then
                        '--- Update Processed Image ---
                        Grab_Success = Grab_Success + 1
                        Image = Me.m_MainProcess.Img_16U_Grab_1

                        If strPath_Exists Then
                            If Image <> M_NULL Then
                                If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image)
                                    Image = M_NULL
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Image)

                            Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                            Me.m_Form.ImageUpdate()
                        End If
                    End If

                    'Me.m_Grab_OK = True
                Catch ex As Exception
                    Response_OK = False
                    Me.m_ContinueGrab = False
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Loop While (Me.m_ContinueGrab And Me.Button_Continue.Enabled = False)

            Me.m_Grab_OK = True
            Me.ScrollBar_Enable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            Me.ScrollBar_Enable(True)
            Me.SetButton_Grab(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_ADJmean.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_ADJmean.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- ScrollBar_Enable ---"
    Private Sub ScrollBar_Enable(ByVal En As Boolean)
        Me.m_Form.HScrollBar_Enable(En)
        Me.m_Form.VScrollBar_Enable(En)
    End Sub
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_Cancel.Text = res.GetString("Button_Cancel.Text")
                Button_Continue.Text = res.GetString("Button_Continue.Text")
                Button_Grab.Text = res.GetString("Button_Grab.Text")
                Button_Load.Text = res.GetString("Button_Load.Text")
                Button_Ok.Text = res.GetString("Button_Ok.Text")
                GroupBox_ExposureTime.Text = res.GetString("GroupBox_ExposureTime.Text")
                GroupBox_Grab.Text = res.GetString("GroupBox_Grab.Text")
                GroupBox_ImageSource.Text = res.GetString("GroupBox_ImageSource.Text")
                Label_Time.Text = res.GetString("Label_Time.Text")
                RadioButton_Auto.Text = res.GetString("RadioButton_Auto.Text")
                RadioButton_Manual.Text = res.GetString("RadioButton_Manual.Text")
        End Select
    End Sub
#End Region


#End Region

#Region "--- ��k�禡 (MasterSlave Mode) ---"

#Region "--- MS_ConnectToIP ---"
    Public Function MS_ConnectToIP()
        Dim Master_GrabNo As String = ""
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        '--- �إ� Master IP �s�u ---
        ip = New ClsIPInfo
        ip.CCDNo = 1
        Me.m_Form.Change_GrabNo(ip.CCDNo, Master_GrabNo)
        ip.GrabNo = Master_GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)

        '--- �إ� Slave IP �s�u ---
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)

        For Each r As ClsIPInfo In Me.m_MainProcess.IPInfo
            Me.m_MainProcess.Init_IP(r.CCDNo, Me.m_MainProcess.IPNetworkConfig.Total_IP)
        Next

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- MS_UpdateGrabImage ---"
    Public Sub MS_UpdateGrabImage()
        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim strPath_Exists As Boolean
        Dim ColorBand As String
        ColorBand = Me.GetColorBandInfo  'Image Band (R\G\B\L --> Color�۾� �G�ť� --> Mono�۾�)

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
            End If

            If System.IO.File.Exists(strPath) Then
                Directory.CreateDirectory(strPath)
            End If

            '--- Disable ScrollBar ---
            'Me.ScrollBar_Enable(False)

            '--- �إ߳s�u ---
            If Not Me.MS_ConnectToIP Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)

            Me.m_Grab_OK = False

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                Me.RepairPath_2(strPath)
            End If

            Do
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GRAB_ONESHOT"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Master_ID, Request_Command, ColorBand, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.UpdateGrabImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    If Response_OK Then
                        '--- Update Processed Image ---
                        Grab_Success = Grab_Success + 1
                        Image = Me.m_MainProcess.Img_16U_Grab_1

                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        strPath_Exists = System.IO.File.Exists(strPath)

                        If strPath_Exists Then
                            If Image <> M_NULL Then
                                If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image)
                                    Image = M_NULL
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Image)

                            Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                            Me.m_Form.ImageUpdate()
                            'Me.ZoomEnable(False)
                        End If
                    End If

                Catch ex As Exception
                    Response_OK = False
                    Me.m_ContinueGrab = False
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Loop While (Me.m_ContinueGrab And Me.Button_Continue.Enabled = False)

            Me.m_Grab_OK = True
            Me.ScrollBar_Enable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            Me.ScrollBar_Enable(True)
            Me.SetButton_Grab(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_ADJmean.MS_UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_ADJmean.MS_UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Continue ---"
    Private Sub Button_Continue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Continue.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Me.Button_Continue.Enabled = False
        Me.Button_Load.Enabled = False
        Me.Button_Next.Enabled = False

        '--- Stop Grab First ---
        Me.WaitGrabReady()

        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
            image = Me.m_MainProcess.Img_16U_Grab_1
            If image <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                Type = MbufInquire(image, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(image, imageBuffer)

                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                MbufControl(image, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                Me.m_Form.ResetScrollBar()
            End If
        Else
            Me.m_Form.CurrentIndex0 = 0
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 0
        End If

        Me.m_Form.ImageZoomAll()
        Me.UpdateExposureTime()

        If Me.ComboBox_PatnList.Text = "" Then
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.Button_Grab.Enabled = False

            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_Save.Enabled = True
            Me.Button_Next.Enabled = True
            MsgBox("�п��Pattern")
        Else
            Me.GroupBox_Mode.Enabled = False
            Me.GroupBox_ExposureTime.Enabled = True
            Me.TrackBar_ExposureTime.Enabled = False
            Me.NumericUpDown_ExposureTime.Enabled = False
            Me.Button_Save.Enabled = False
        End If
        Me.UpdateUserLevel()


        'Thread --- Update Grab Image
        '---�Ұ� Run Command Thread ---
        Me.m_ContinueGrab = True
        Try
            If Not Me.m_Thread1_RunCommand Is Nothing Then
                Me.m_Thread1_RunCommand = Nothing
            End If

            If Not (Not Me.m_Thread1_RunCommand Is Nothing) Then
                Try
                    'If Not Me.m_MasterSlaveMode_Enable Then ' ��~~�L~~~~~~~~~~
                    If True Then
                        Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.UpdateGrabImage)
                        Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        Me.m_Thread1_RunCommand.Start()
                    Else
                        '--- MasterSlave Mode ---
                        Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.MS_UpdateGrabImage)
                        Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        Me.m_Thread1_RunCommand.Start()
                    End If
                Catch ex As Exception
                    Throw New Exception(ex.Message)
                End Try
            End If
        Catch ex As Exception
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.Button_Grab.Enabled = False
            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_Save.Enabled = True
            Me.Button_Next.Enabled = True
            Me.m_ContinueGrab = False
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Continue](" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#Region "--- Button_Grab ---"
    Private Sub Button_Grab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Grab.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            Me.Button_Grab.Enabled = False
            Me.Button_Save.Enabled = False

            '--- ����s����� ---
            Me.WaitGrabReady()

            '--- Finish Grab Image Thread ---  '2013/01/25 Rick add
            If Not Me.m_Thread1_RunCommand Is Nothing Then
                Me.m_Thread1_RunCommand = Nothing
            End If

            '--- �إ߳s�u ---
            'If Not Me.m_MasterSlaveMode_Enable Then ' ��~~�L~~~~~~~~~~
            If True Then
                If Not Me.ConnectToIP Then
                    Me.Button_Continue.Enabled = True
                    Me.Button_Load.Enabled = True
                    Me.SetButton_Grab(False)
                    Exit Sub
                End If
            Else '--- M\S Mode ---
                If Not Me.MS_ConnectToIP Then
                    Me.Button_Continue.Enabled = True
                    Me.Button_Load.Enabled = True
                    Me.SetButton_Grab(False)
                    Exit Sub
                End If
            End If

            Me.m_Continue = False  '�������
            imageBuffer = Me.m_MainProcess.Img_16U_Grab_1

            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                image = Me.m_MuraProcess.Img_ChildSample
                If image <> M_NULL Then
                    MbufFree(image)
                    image = M_NULL
                End If
                image = Me.m_MuraProcess.Img_CurrentSample_NonPage
            Else
                image = Me.m_MuraProcess.Img_ChildOriginal
                If image <> M_NULL Then
                    MbufFree(image)
                    image = M_NULL
                End If
                image = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
                If image <> M_NULL Then
                    MbufFree(image)
                    image = M_NULL
                End If
                image = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
                If image <> M_NULL Then
                    MbufFree(image)
                    image = M_NULL
                End If
                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
            End If

            SizeX = MbufInquire(imageBuffer, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(imageBuffer, M_SIZE_Y, M_NULL)
            Type = MbufInquire(imageBuffer, M_TYPE, M_NULL)

            If image <> M_NULL Then
                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If


            'If Not Me.m_MasterSlaveMode_Enable Then ' ��~~�L~~~~~~~~~~
            If True Then
                '----------------------------------------------------------------------------------------------
                ' IP LOAD GRAB IMAGE  ==> Request_Command = "LOAD_GRABIMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_GRABIMAGE"
                    TimeOut = 100000 '100 secs
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Grab Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Continue.Enabled = True
                        Me.Button_Load.Enabled = True
                        Me.Button_Grab.Enabled = False
                        Exit Sub
                    End If

                    If Response_OK Then
                        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage   'Mura
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If image <> M_NULL Then
                                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(image)
                                    image = M_NULL
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, image)

                            'If System.IO.File.Exists(strPath) = True Then
                            '    System.IO.File.Delete(strPath)
                            'End If
                        End If
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Grab]Mura Load Grab Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.Button_Grab]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Throw New Exception(ex.Message)
                End Try

            Else  '--- M\S Mode ---
                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 200000 '200 secs

                    '--- Initial ---  
                    IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                        Me.RepairPath_2(strPath)
                    End If


                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Slave_ID, Request_Command, "", "", strPath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        If Me.m_Have_MDigitizer Then
                            Me.GroupBox_ExposureTime.Enabled = True
                            Me.GroupBox_Mode.Enabled = True
                        End If
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Grab]Load Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.Button_Grab]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Throw New Exception(ex.Message)
                End Try
            End If


            '----------------------------------------------------------------------------------------------
            ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "RESIZE_ORIGINAL"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                'If Not Me.m_MasterSlaveMode_Enable Then ' ��~~�L~~~~~~~~~~
                If True Then
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                Else
                    Me.m_MainProcess.IP_Dispatcher2.PrepareRequest(m_Slave_ID, Request_Command, SaveImage, , , , , , , , TimeOut)
                End If

                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Continue.Enabled = True
                    Me.Button_Load.Enabled = True
                    Me.Button_Grab.Enabled = False
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image ---
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                    Else
                        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                    End If

                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Grab]Mura Resize Image Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.Button_Grab]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Throw New Exception(ex.Message)
            End Try

            'Show Image
            If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                If image <> M_NULL Then
                    imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                    Type = MbufInquire(image, M_TYPE, M_NULL)

                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                        MbufFree(imageBuffer)
                        imageBuffer = M_NULL
                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                    MbufCopy(image, imageBuffer)

                    MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                    MbufControl(image, M_MODIFIED, M_DEFAULT)
                    MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                    Me.m_Form.ResetScrollBar()
                End If
            Else
                Me.m_Form.CurrentIndex0 = 0
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 0
            End If

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            End If

            Me.m_Form.ImageZoomAll()
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.Button_Grab.Enabled = False

            Me.GroupBox_Mode.Enabled = True
            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_Save.Enabled = True
            Me.Button_Next.Enabled = True

        Catch ex As Exception
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.Button_Grab.Enabled = False

            Me.GroupBox_Mode.Enabled = False
            Me.TrackBar_ExposureTime.Enabled = False
            Me.NumericUpDown_ExposureTime.Enabled = False
            Me.m_ContinueGrab = False
            Me.Button_Next.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Grab]Grab Image Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- Button_Load ---"
    Private Sub Button_Load_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Load.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- ����s����� ---
        Me.WaitGrabReady()

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Try
            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()

            If Me.m_Form.GetPatternIndexInfo >= Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
            End If
            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                If Me.m_Form.OpenFileDialog.FileName.Split("_")(0) <> "" Then
                    Me.m_Form.PanelID = System.IO.Path.GetFileNameWithoutExtension(Me.m_Form.OpenFileDialog.FileName).Split("_")(0)
                Else
                    Me.m_Form.PanelID = "AAAAAAAA"
                End If

                'Check File Name
                If (Me.m_Form.OpenFileDialog.FileName.Contains("_FFunc") Or Me.m_Form.OpenFileDialog.FileName.Contains("_FMura")) And Me.m_MainProcess.IPBootConfig.GigE_SerialNum.Value <> "5978" Then
                    If System.IO.Path.GetFileNameWithoutExtension(Me.m_Form.OpenFileDialog.FileName).Split("_")(2) <> Me.m_MainProcess.CCDNo Then
                        If MsgBox("���J�v���D�ҿ��CCD,�L�k���J!", vbOKCancel, "�нT�{") = MsgBoxResult.Cancel Then
                            Me.Button_Load.Enabled = True
                            Me.Button_Save.Enabled = True
                            Exit Sub
                        Else
                            Me.Button_Load.Enabled = True
                            Me.Button_Save.Enabled = True
                            Exit Sub
                        End If
                    End If
                End If

                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                    image = Me.m_MuraProcess.Img_ChildSample
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                Else
                    image = Me.m_MuraProcess.Img_ChildOriginal
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
                    If image <> M_NULL Then
                        MbufFree(image)
                        image = M_NULL
                    End If
                    image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                End If

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, image)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("���ˬd�Ҷ}�Ҫ��v���ɮ׬O�_�ŦX�ثeIP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 200000 '200 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        If SubSystemResult.Responses(0).Param1 = "1" Then
                            Me.m_Form.CheckBox_IsAligned.Checked = True
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                            strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                            RepairPath_2(strPath)
                            MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                        Else
                            Me.m_Form.CheckBox_IsAligned.Checked = False
                        End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Load]Load Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_MuraAutoManual.Button_Load]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Throw New Exception(ex.Message)
                End Try

                '----------------------------------------------------------------------------------------------
                ' Transfer Mura Boundary  ==> Request_Command = "Transfer_Mura_Boundary" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "Transfer_Mura_Boundary"
                    TimeOut = 10000 '10 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 100000 '100 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoManual.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Load]Mura Resize Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.Button_Load]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    Try
                        '----------------------------------------------------------------------------------------------
                        ' Defocus Original Image  ==> Request_Command = "DEFOCUS_ORIGINAL_2" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        '--- Prepare Command ---
                        Request_Command = "DEFOCUS_ORIGINAL_2"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Defocus Original_2 Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_MuraAutoManual.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                        If Response_OK Then
                            '--- Update Processed Image ---
                            image = Me.m_MuraProcess.Img_16U_Defocus_NonPage
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "DefocusOriginal_2.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "DefocusOriginal_2.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.Button_Load]Mura Defocus Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_MuraAutoManual.Button_Load]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End If

                If Response_OK Then
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        If Me.m_Form.ComboBox_Select.SelectedIndex = 1 Then
                            If image <> M_NULL Then
                                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                                Type = MbufInquire(image, M_TYPE, M_NULL)

                                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                    MbufFree(imageBuffer)
                                    imageBuffer = M_NULL
                                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                End If
                                MbufCopy(image, imageBuffer)

                                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                                MbufControl(image, M_MODIFIED, M_DEFAULT)
                                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                Me.m_Form.ResetScrollBar()
                            End If
                        Else
                            If Me.m_Form.ComboBox_Select.SelectedIndex > 0 Then Me.m_Form.ComboBox_Select.SelectedIndex = 1
                        End If
                    Else
                        If Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
                            If image <> M_NULL Then
                                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                                Type = MbufInquire(image, M_TYPE, M_NULL)

                                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                    MbufFree(imageBuffer)
                                    imageBuffer = M_NULL
                                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                End If
                                MbufCopy(image, imageBuffer)

                                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                                MbufControl(image, M_MODIFIED, M_DEFAULT)
                                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                Me.m_Form.ResetScrollBar()
                            End If
                        Else
                            If Me.m_Form.ComboBox_Select.SelectedIndex > -1 Then Me.m_Form.ComboBox_Select.SelectedIndex = 0
                        End If
                    End If

                    Me.m_Form.CurrentIndex0 = 2
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 2

                    Me.GroupBox_Mode.Enabled = True
                    Me.Button_Next.Enabled = True
                    Call Me.m_Form.ImageZoomAll()
                End If

                For i = 0 To Me.ComboBox_PatnList.Items.Count - 1
                    If Me.m_Form.OpenFileDialog.FileName.Contains(Me.ComboBox_PatnList.Items(i)) Then
                        Me.ComboBox_PatnList.SelectedIndex = i
                        Exit For
                    End If
                Next

            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Load]" & ex.Message)
            MessageBox.Show("[Dialog_MuraAutoManual.Button_Load_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Next ---"
    Private Sub Button_Next_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Next.Click
        Dim i As Integer
        Dim t As Integer
        Dim PatternName As String
        Dim PatternIndex As Integer
        Dim Time As Double

        Me.Enabled = False
        MappTimer(M_TIMER_RESET + M_SYNCHRONOUS)

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        Me.Button_Next.Enabled = False
        Me.m_SaveImage = Me.CheckBox_UpdateImage.Checked

        '[AreaGrabber]
        PatternIndex = Me.GetPatternIndexInfo
        Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)   '�q[1]�}�l

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_PatnList.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.RadioButton_Auto.Checked Then
            For i = 1 To 9
                Me.m_CurrentStep = i
                If Not Me.DoStep(Me.m_MainProcess.ErrorCode) Then
                    Me.Enabled = True
                    Return
                End If
            Next
        Else
            Me.m_CurrentStep += 1
            Me.DoStep(Me.m_MainProcess.ErrorCode)
        End If

        MappTimer(M_TIMER_READ + M_SYNCHRONOUS, Time)
        t = Time * 1000
        Me.Label_Time.Text = "���R�Ҫ�ɶ� : " & t & " ms"
        Me.Enabled = True
        Me.Button_Next.Enabled = True
        Me.m_Form.ComboBox_Type.SelectedIndex = 1
        Me.m_Form.ComboBox_Select.SelectedIndex = 0
        Me.m_Form.ShowMuraResult()
    End Sub
#End Region

#Region "--- Button_Ok ---"
    Private Sub Button_Ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Ok.Click
        Me.m_Form.ShowMuraResult()
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim i As Integer
        Dim dir As String = ""
        Dim Str As String = ""
        Dim Parameter_Lists As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Button_Save.Enabled = False
        Me.GroupBox_Mode.Enabled = False

        '--- ����s����� ---
        Me.WaitGrabReady()

        i = Me.m_MainProcess.MuraPatternRecipeArrayOrder.IndexOf(Me.m_MuraProcess.CurrentMuraPatternRecipe)
        Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
        Me.Compare(Me.m_MainProcess.MuraPatternRecipeArrayTemp.Item(i), Me.m_MuraProcess.MuraPatternRecipeArray.Item(i), Me.m_MainProcess.RecipeDailyLogManager)

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraAutoManual Setting   ==> Request_Command = "DIALOG_MURAAUTOMANUAL_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURAAUTOMANUAL_SETTING"
            TimeOut = 100000 '100 secs

            Parameter_Lists = "ExposureTime," & Me.NumericUpDown_ExposureTime.Value & ";"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraAutoManual Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Save.Enabled = True
                Me.GroupBox_Mode.Enabled = True
                Exit Sub
            End If
        Catch ex As Exception
            Me.Button_Save.Enabled = True
            Me.GroupBox_Mode.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Save]Dialog_MuraAutoManual Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraAutoManual.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Throw New Exception("Dialog_MuraAutoManual Setting Error ! (" & ex.Message & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            TimeOut = 100000 '100 secs

            '--- Local action ---
            Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.TextBox_Product.Text & "\Mura\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(Str, Me.m_MainProcess.ErrorCode)

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Save.Enabled = True
                Me.GroupBox_Mode.Enabled = True
                Exit Sub
            End If

        Catch ex As Exception
            Me.Button_Save.Enabled = True
            Me.GroupBox_Mode.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraAutoManual.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Me.Button_Save.Enabled = True
        Me.GroupBox_Mode.Enabled = True

        '--- Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

    End Sub
#End Region


#End Region

#Region "--- RadioButton Event ---"

#Region "--- RadioButton_Auto ---"
    Private Sub RadioButton_Auto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Auto.CheckedChanged
        If Me.RadioButton_Auto.Checked Then
            Me.m_CurrentStep = 0
            Me.ProgressBar.Value = 0
            Me.Button_Next.Enabled = True
        End If
    End Sub
#End Region

#Region "--- RadioButton_Manual ---"
    Private Sub RadioButton_Manual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Manual.CheckedChanged
        If Me.RadioButton_Manual.Checked Then
            Me.m_CurrentStep = 0
            Me.ProgressBar.Value = 0
            Me.Button_Next.Enabled = True
        End If
    End Sub
#End Region

#End Region

#Region "--- TrackBar Event ---"

#Region "--- TrackBar_ExposureTime_MouseUp ---"
    Private Sub TrackBar_ExposureTime_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_ExposureTime.MouseUp

        '--- ��s�n���ɶ� ---
        '--- �������̤p�n���ɶ� 16000 ---  
        'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
        Me.NumericUpDown_ExposureTime.Value = Me.TrackBar_ExposureTime.Value
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- NumericUpDown_ExposureTime ---"
    Private Sub NumericUpDown_ExposureTime_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles NumericUpDown_ExposureTime.ValueChanged
        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        Dim PatternName As String = ""
        Dim PatternIndex As Integer
        Dim SizeX, SizeY, Type As Integer

        If Not Me.m_ReadyToUpdateImage Then Exit Sub

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Stop Grab First ---
        Me.WaitGrabReady()

        '[AreaGrabber]
        PatternIndex = Me.GetPatternIndexInfo
        Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)   '�q[1]�}�l

        If Me.ComboBox_PatnList.SelectedIndex >= 0 Then
            Me.TrackBar_ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
        Else
            Exit Sub
        End If

        '--- Button Disable ---
        Me.Button_Save.Enabled = False
        Me.GroupBox_Mode.Enabled = False
        Me.TrackBar_ExposureTime.Enabled = False

        If Not Me.m_MainProcess Is Nothing Then

            Try
                '----------------------------------------------------------------------------------------------
                ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SET_PATTERNINDEX"
                    TimeOut = 100000 '100 secs

                    '--- PatternName ---
                    PatternName = Me.ComboBox_PatnList.Text

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Set Pattern Index Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                If Not Me.m_Form Is Nothing Then
                    If Not Me.m_Form Is Nothing AndAlso Me.m_IPBootConfig.CardSystem.Value <> "" Then

                        If Me.m_Have_MDigitizer Then

                            '----------------------------------------------------------------------------------------------
                            ' Update Current Exposure Time  ==> Request_Command = "UPDATE_EXPOSURETIME" (Dispatcher 1)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "UPDATE_EXPOSURETIME"
                                TimeOut = 100000 '100 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NumericUpDown_ExposureTime.Value, , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    Response_OK = False
                                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If
                            Catch ex As Exception
                                Response_OK = False
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Update Current Exposure Time Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If

                        If Response_OK Then
                            '----------------------------------------------------------------------------------------------
                            ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                            '----------------------------------------------------------------------------------------------
                            Try
                                SyncLock Me.m_MainProcess.IP_Dispatcher1

                                    '--- Prepare Command ---
                                    Request_Command = "GRAB_ONESHOT"
                                    TimeOut = 100000 '100 secs

                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                End SyncLock

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    Response_OK = True
                                Else
                                    Response_OK = False
                                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraAutoManual.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                                If Response_OK Then
                                    '--- Update Processed Image ---
                                    Image = Me.m_MainProcess.Img_16U_Grab_1
                                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                                        strPath = strPath.Replace("\\", "\")
                                    Else
                                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                                        Me.RepairPath_2(strPath)
                                    End If

                                    If System.IO.File.Exists(strPath) Then
                                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                        MbufDiskInquire(strPath, M_TYPE, Type)
                                        If Image <> M_NULL Then
                                            If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                                MbufFree(Image)
                                                Image = M_NULL
                                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                            End If
                                        Else
                                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If

                                        '--- Load Remote Image ---
                                        MbufLoad(strPath, Image)

                                        Me.m_Form.ImageUpdate()
                                        Me.Button_Save.Enabled = True
                                    End If
                                End If
                            Catch ex As Exception
                                Response_OK = False
                                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                            End Try
                        End If

                        '--- Stop Grab First ---
                        Me.Button_Continue.Enabled = True
                        Me.Button_Grab.Enabled = False
                    End If
                End If
            Catch ex As Exception
                Me.Button_Continue.Enabled = True
                Me.Button_Load.Enabled = True
                Me.Button_Grab.Enabled = False
                Me.Button_Save.Enabled = True
                Me.GroupBox_Mode.Enabled = True
                Me.TrackBar_ExposureTime.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message)
            End Try
        End If

        System.Threading.Thread.Sleep(200)
        Me.Button_Save.Enabled = True
        Me.TrackBar_ExposureTime.Enabled = True
        Me.GroupBox_Mode.Enabled = True
    End Sub
#End Region

#End Region

#Region "--- ComboBox Event ---"

#Region "--- ComboBox_PatnList_SelectedIndexChanged ---"
    Private Sub ComboBox_PatnList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_PatnList.SelectedIndexChanged
        Dim PatternName As String
        Dim PatternIndex As Integer

        '--- ����s����� ---
        Me.WaitGrabReady()

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '[AreaGrabber]
        PatternIndex = Me.GetPatternIndexInfo
        Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)   '�q[1]�}�l
        Me.TrackBar_ExposureTime.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).ExposureTime.Value

        '--- ��s�n���ɶ� ---
        '--- �������̤p�n���ɶ� 16000 ---  
        'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
        Me.NumericUpDown_ExposureTime.Value = Me.TrackBar_ExposureTime.Value

        '[AreaGrabber]
        Me.Button_Continue.Enabled = True
        Me.Button_Load.Enabled = True
        Me.Button_Grab.Enabled = False
        Me.TrackBar_ExposureTime.Enabled = False
        Me.NumericUpDown_ExposureTime.Enabled = False
        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_PatnList.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.ComboBox_PatnList_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            '--- ��s�n���ɶ� ---
            '--- �������̤p�n���ɶ� 16000 --- 
            'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
            Me.NumericUpDown_ExposureTime.Value = Me.TrackBar_ExposureTime.Value

            If Me.m_Have_MDigitizer Then

                '----------------------------------------------------------------------------------------------
                ' Update Current Exposure Time  ==> Request_Command = "UPDATE_EXPOSURETIME" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "UPDATE_EXPOSURETIME"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NumericUpDown_ExposureTime.Value, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Response_OK = False
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Update Current Exposure Time Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraAutoManual.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- ComboBox_ColorBand_SelectedIndexChanged ---"
    Private Sub ComboBox_ColorBand_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_ColorBand.SelectedIndexChanged
        Select Case Me.ComboBox_ColorBand.Text
            Case "R"
                Me.ComboBox_ColorBand.ForeColor = Color.Red
            Case "G"
                Me.ComboBox_ColorBand.ForeColor = Color.Green
            Case "B"
                Me.ComboBox_ColorBand.ForeColor = Color.Blue
            Case "L"
                Me.ComboBox_ColorBand.ForeColor = Color.Black
        End Select
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_UpdateImage ---"
    Private Sub CheckBox_UpdateImage_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_UpdateImage.CheckedChanged
        Me.m_SaveImage = Me.CheckBox_UpdateImage.Checked
    End Sub
#End Region

#End Region

#Region "--- ��s�ثe�����A ---"

#Region "--- GetPatternIndexInfoCallback ---"
    Delegate Function GetPatternIndexInfoCallback() As Integer
    Private Function GetPatternIndexInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_PatnList.InvokeRequired Then
            Return Me.Invoke(New GetPatternIndexInfoCallback(AddressOf GetPatternIndexInfo), New Object() {})
        Else
            i = Me.ComboBox_PatnList.SelectedIndex
            Me.Update()
            Return i
        End If
    End Function
#End Region

#Region "--- SetButton_GrabCallback ---"
    Private Delegate Function SetButton_GrabCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Grab(ByVal En As Boolean) As Boolean
        If Me.Button_Grab.InvokeRequired Then
            Me.Invoke(New SetButton_GrabCallback(AddressOf SetButton_Grab), New Object() {En})
        Else
            Me.Button_Grab.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- GetColorBandInfoCallback ---"
    Delegate Function GetColorBandInfoCallback() As String
    Private Function GetColorBandInfo() As String
        Dim ColorBand As String
        If Me.ComboBox_ColorBand.InvokeRequired Then
            Return Me.Invoke(New GetColorBandInfoCallback(AddressOf GetColorBandInfo), New Object() {})
        Else
            ColorBand = Me.ComboBox_ColorBand.Text
            Me.Update()
            Return ColorBand
        End If
    End Function
#End Region

#End Region




End Class