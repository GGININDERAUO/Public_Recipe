Imports ClassLibrary
Imports AUO.SubSystemControl
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.IO
Imports System.Windows.Forms
Imports System.Threading
Imports System.Globalization

Public Class Dialog_BlobMuraRound

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen

    Private m_BlobSmoothIndex As Integer    'Blob ���ƳB�z�v�� Index
    Private m_BlobWhiteIndex As Integer     'Blob �۴�v��(�G) Index
    Private m_BlobBlackIndex As Integer     'Blob �۴�v��(�t) Index
    Private m_BlobRecWhiteIndex As Integer  'Blob �v���B�z(�G-Reconstruct) Index
    Private m_BlobRecBlackIndex As Integer  'Blob �v���B�z(�t-Reconstruct) Index
    Private m_CurrentMuraIndex As Integer   '�O���ثe��ܼv���� Index   '2009/06/12 Rick add

    Private m_Left As Boolean
    Private m_Right As Boolean
    Private m_Top As Boolean
    Private m_Bottom As Boolean

    Private m_Blob As Boolean
    Private RoundExpandWidth As Integer

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL
        Dim image1 As MIL_ID
        Dim image2 As MIL_ID
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_BlobMuraRound", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess

        If Not Me.m_MainProcess.CheckIP() Then
            Me.m_MainProcess.IsIPConnected = False
            MessageBox.Show("Can't connect to IP-" & Me.m_MainProcess.CCDNo & "�APLZ restart IP !", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Me.m_MainProcess.IsIPConnected = True
        End If

        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_SolidBrush = New SolidBrush(Color.White)
        Me.m_Pen = New Pen(Color.White)
        RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

        Me.m_BlobSmoothIndex = -2
        Me.m_BlobWhiteIndex = -2
        Me.m_BlobBlackIndex = -2
        Me.m_BlobRecWhiteIndex = -2
        Me.m_BlobRecBlackIndex = -2

        image = Me.m_MuraProcess.Img_BlobMura_SmoothChild
        If image <> M_NULL Then
            Me.m_BlobSmoothIndex = Me.ComboBox_Select.Items.Add("Blob ���ƳB�z�v��")
            Me.Label_BlobSmooth.Text = "OK"
            Me.GroupBox_Parameter.Enabled = True
            Me.Button_CalculateBlob.Enabled = True
        Else
            Me.m_Form.ComboBox_Type.SelectedIndex = -1
            Me.Button_CalculateBlob.Enabled = False
        End If

        If Me.m_BlobSmoothIndex <> -2 Then
            Me.ComboBox_Select.SelectedIndex = Me.m_BlobSmoothIndex
        Else
            Me.m_Form.ComboBox_Type.SelectedIndex = -1
        End If

        If Me.m_BlobSmoothIndex <> -2 Then
            image1 = Me.m_MuraProcess.Img_16U_BlobMura_White_NonPage
            image2 = Me.m_MuraProcess.Img_16U_BlobMura_Black_NonPage
            If image1 <> M_NULL And image2 <> M_NULL Then
                Me.m_BlobWhiteIndex = Me.ComboBox_Select.Items.Add("Blob �۴�v��(�G)")
                Me.m_BlobBlackIndex = Me.ComboBox_Select.Items.Add("Blob �۴�v��(�t)")
            End If

            image1 = Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage
            image2 = Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage
            If image1 <> M_NULL And image2 <> M_NULL Then
                Me.m_BlobRecWhiteIndex = Me.ComboBox_Select.Items.Add("Blob �v���B�z(�G-Reconstruct)")
                Me.m_BlobRecBlackIndex = Me.ComboBox_Select.Items.Add("Blob �v���B�z(�t-Reconstruct)")
            End If
        End If

        If Me.m_BlobSmoothIndex = -2 Then
            Me.GroupBox_Modify.Enabled = False
            Me.GroupBox_Parameter.Enabled = False
            Me.Button_CalculateBlob.Enabled = False
            Me.m_Blob = False
            MessageBox.Show("[Mura�v�����~] �S�����Ƽv�� ! ", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            image1 = Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage
            image2 = Me.m_MuraProcess.Img_1U_BlackReconstructRim_NonPage
            If image1 <> M_NULL And image2 <> M_NULL And image <> M_NULL Then
                Me.m_Blob = True
            Else
                Me.m_Blob = False
            End If
        End If

        Me.m_CurrentMuraIndex = m_BlobRecWhiteIndex
        Me.m_Form.ImageZoomAll()

        '--- UI ---
        Me.m_VScrollBar = Me.m_Form.VScrollBar
        Me.m_HScrollBar = Me.m_Form.HScrollBar

        Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
        Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
        Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
        Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll

        Me.Button_ORR_DeleteOne.Enabled = False
        '--- UI ---

        Me.UpdateData()
        '--- �v������ ---
        Me.UpdateUserLevel()
    End Sub

#Region "--- Dialog Event ---"

    Private Sub Dialog_BlobMuraRound_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Me.RadioButton_Finish.Checked = True

        '--- Initial Button ---  
        Me.Button_Save.Enabled = True
        Me.Button_Cancel.Enabled = True
        Me.BtnPre_BlobMuraRound.Enabled = True
        Me.Button_CalculateBlob.Enabled = Me.CheckBox_Rim.Checked
        Me.GroupBox_Modify.Enabled = Me.CheckBox_Rim.Checked
        Me.GroupBox_Parameter.Enabled = Me.CheckBox_Rim.Checked

        Call Me.MuraBlob_OtherRimRegionReflash()

        Me.Update()
    End Sub

    Private Sub Dialog_BlobMuraRound_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.PaintStop = True
        Me.CheckBox_Show_Other_RimRegion.Checked = False
        Me.CheckBox_ORR_Mannual.Checked = False

        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub

#End Region

#Region "--- ��k�禡 ---"

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_CalculateBlob.Enabled = En
        Me.Button_Save.Enabled = En
        Me.Button_Cancel.Enabled = En
        Me.BtnPre_BlobMuraRound.Enabled = En

        Me.Button_ORR_CLearAll.Enabled = En
        Me.Button_ORR_DeleteOne.Enabled = En
        Me.Button_ORR_AddOne.Enabled = En
    End Sub
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_Modify.Enabled = False
                Me.GroupBox_Parameter.Enabled = False
                Me.GroupBox_Other_RimRegion_Setting.Enabled = False
                Me.GroupBox_AutoAddORR.Enabled = False
                Me.GroupBox_MannualAddORR.Enabled = False
            Case 1 'PM
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = False
                Me.GroupBox_Other_RimRegion_Setting.Enabled = True
                Me.GroupBox_AutoAddORR.Enabled = True
                Me.GroupBox_MannualAddORR.Enabled = True
            Case 2 'ENG
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
                Me.GroupBox_Other_RimRegion_Setting.Enabled = True
                Me.GroupBox_AutoAddORR.Enabled = True
                Me.GroupBox_MannualAddORR.Enabled = True
            Case 3 'ALL
                Me.GroupBox_Modify.Enabled = True
                Me.GroupBox_Parameter.Enabled = True
                Me.GroupBox_Other_RimRegion_Setting.Enabled = True
                Me.GroupBox_AutoAddORR.Enabled = True
                Me.GroupBox_MannualAddORR.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim boundary As ClsParameterBoundary

        Me.NumericUpDown_RimTop.Minimum = 0 ' original value = 1
        Me.NumericUpDown_RimBottom.Minimum = 0 ' original value = 1
        Me.NumericUpDown_RimLeft.Minimum = 0 ' original value = 1
        Me.NumericUpDown_RimRight.Minimum = 0 ' original value = 1

        boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound
        If boundary.TopY > 1 Then Me.NumericUpDown_RimTop.Maximum = boundary.TopY - 1
        If boundary.BottomY > 1 Then Me.NumericUpDown_RimBottom.Maximum = boundary.BottomY - 1
        If boundary.LeftX > 1 Then Me.NumericUpDown_RimLeft.Maximum = boundary.LeftX - 1
        If boundary.RightX > 1 Then Me.NumericUpDown_RimRight.Maximum = boundary.RightX - 1

        Me.CheckBox_Rim.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseRound.Value
        If boundary.TopY <= Me.NumericUpDown_RimTop.Minimum Then boundary.TopY = Me.NumericUpDown_RimTop.Minimum
        If boundary.BottomY <= Me.NumericUpDown_RimBottom.Minimum Then boundary.BottomY = Me.NumericUpDown_RimBottom.Minimum
        If boundary.LeftX <= Me.NumericUpDown_RimLeft.Maximum Then boundary.LeftX = Me.NumericUpDown_RimLeft.Minimum
        If boundary.RightX <= Me.NumericUpDown_RimRight.Minimum Then boundary.RightX = Me.NumericUpDown_RimRight.Minimum

        Me.NumericUpDown_WhiteMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdHeight.Value
        Me.NumericUpDown_WhiteMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdLow.Value

        Me.NumericUpDown_BlackMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdHeight.Value
        Me.NumericUpDown_BlackMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdLow.Value

        Me.SetBoundary(Me.m_MuraProcess.CurrentMuraPatternRecipe.Rim)

    End Sub
#End Region

#Region "--- SetMaxMin ---"
    Private Sub SetMaxMin(ByVal x As Integer, ByVal y As Integer, ByVal boundary As ClsParameterBoundary)
        Me.NumericUpDown_RimTop.Maximum = y - boundary.BottomY
        Me.NumericUpDown_RimBottom.Maximum = y - boundary.TopY
        Me.NumericUpDown_RimLeft.Maximum = x - boundary.RightX
        Me.NumericUpDown_RimRight.Maximum = x - boundary.LeftX
    End Sub
#End Region

#Region "--- SetBoundary ---"
    Private Sub SetBoundary(ByVal boundary As ClsParameterBoundary)

        'Top ---
        If boundary.TopY < Me.NumericUpDown_RimTop.Minimum Then
            Me.NumericUpDown_RimTop.Value = Me.NumericUpDown_RimTop.Minimum
            boundary.TopY = Me.NumericUpDown_RimTop.Minimum
        Else
            If boundary.TopY >= Me.NumericUpDown_RimTop.Maximum Then
                boundary.TopY = Me.NumericUpDown_RimTop.Maximum - 1
                Me.NumericUpDown_RimTop.Value = boundary.TopY
            Else
                Me.NumericUpDown_RimTop.Value = boundary.TopY
            End If
        End If

        'Bottom ---
        If boundary.BottomY < Me.NumericUpDown_RimBottom.Minimum Then
            Me.NumericUpDown_RimBottom.Value = Me.NumericUpDown_RimBottom.Minimum
            boundary.BottomY = Me.NumericUpDown_RimBottom.Minimum
        Else
            If boundary.BottomY >= Me.NumericUpDown_RimBottom.Maximum Then
                boundary.BottomY = Me.NumericUpDown_RimBottom.Maximum - 1
                Me.NumericUpDown_RimBottom.Value = boundary.BottomY
            Else
                Me.NumericUpDown_RimBottom.Value = boundary.BottomY
            End If
        End If

        'Left ---
        If boundary.LeftX < Me.NumericUpDown_RimLeft.Minimum Then
            Me.NumericUpDown_RimLeft.Value = Me.NumericUpDown_RimLeft.Minimum
            boundary.LeftX = Me.NumericUpDown_RimLeft.Minimum
        Else
            If boundary.LeftX >= Me.NumericUpDown_RimLeft.Maximum Then
                boundary.LeftX = Me.NumericUpDown_RimLeft.Maximum - 1
                Me.NumericUpDown_RimLeft.Value = boundary.LeftX
            Else
                Me.NumericUpDown_RimLeft.Value = boundary.LeftX
            End If
        End If

        'Right ---
        If boundary.RightX < Me.NumericUpDown_RimRight.Minimum Then
            Me.NumericUpDown_RimRight.Value = Me.NumericUpDown_RimRight.Minimum
            boundary.RightX = Me.NumericUpDown_RimRight.Minimum
        Else
            If boundary.RightX >= Me.NumericUpDown_RimRight.Maximum Then
                boundary.RightX = Me.NumericUpDown_RimRight.Maximum - 1
                Me.NumericUpDown_RimRight.Value = boundary.RightX
            Else
                Me.NumericUpDown_RimRight.Value = boundary.RightX
            End If
        End If

    End Sub
#End Region

#Region "--- ReDraw ---"
    Private Sub ReDraw()
        Dim image As MIL_ID = M_NULL
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.CheckBox_Show.Checked And Me.ComboBox_Select.SelectedIndex >= 0 And image <> M_NULL Then
            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)
            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

            Me.m_SolidBrush.Color = Color.Green
            '--- Initial ---

            '[1] ����u ---
            v = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            '[2] �k��u ---
            v = SizeX - Me.NumericUpDown_RimRight.Value
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            '[3] �W��u ---
            v = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            '[4] �U��u ---
            v = SizeY - Me.NumericUpDown_RimBottom.Value
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

            '--- �e���߰ϰ� ---

            Me.m_SolidBrush.Color = Color.Red
            '[1] ����u ---
            v = (Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            '[2] �k��u ---
            v = SizeX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX
            v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            '[3] �W��u ---
            v = (Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            '[4] �U��u ---
            v = SizeY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY
            v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If

        End If
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = False
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- MuraBlob_OtherRimRegionReflash ---"
    Public Sub MuraBlob_OtherRimRegionReflash()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim mbrra As ClsMuraBlobRimRegionRecipeArray
        Dim mbrr As ClsMuraBlobRimRegionRecipe
        Dim Boundary As ClsParameterBoundary = Me.m_MuraProcess.MuraModelRecipe.Boundary

        Me.ListView_Other_RimRegion.Items.Clear()

        mbrra = Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray
        For i = 0 To mbrra.RRRG.Count - 1
            mbrr = mbrra.RRRG.Item(i)
            lvi = Me.ListView_Other_RimRegion.Items.Add(mbrr.LeftX - Boundary.LeftX)
            lvi.SubItems.Add(mbrr.TopY - Boundary.TopY)
            lvi.SubItems.Add(mbrr.RightX - Boundary.LeftX)
            lvi.SubItems.Add(mbrr.BottomY - Boundary.TopY)
            lvi.SubItems.Add(mbrr.White_TH)
            lvi.SubItems.Add(mbrr.White_TL)
            lvi.SubItems.Add(mbrr.Black_TH)
            lvi.SubItems.Add(mbrr.Black_TL)
        Next
        Me.Label_ORRCount.Text = "�ƶq = " & mbrra.RRRG.Count
        Me.DrawMark()
    End Sub
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_CalculateBlob.Text = res.GetString("Button_CalculateBlob.Text")
                Button_Cancel.Text = res.GetString("Button_Cancel.Text")
                Button_LoadBlobSmooth.Text = res.GetString("Button_LoadBlobSmooth.Text")
                Button_ORR_AddOne.Text = res.GetString("Button_ORR_AddOne.Text")
                Button_ORR_CLearAll.Text = res.GetString("Button_ORR_CLearAll.Text")
                Button_ORR_DeleteOne.Text = res.GetString("Button_ORR_DeleteOne.Text")
                Button_Save.Text = res.GetString("Button_Save.Text")
                Ch_BottomY.Text = res.GetString("Ch_BottomY.Text")
                Ch_LeftX.Text = res.GetString("Ch_LeftX.Text")
                Ch_RightX.Text = res.GetString("Ch_RightX.Text")
                Ch_TopY.Text = res.GetString("Ch_TopY.Text")
                CheckBox_ORR_Mannual.Text = res.GetString("CheckBox_ORR_Mannual.Text")
                CheckBox_Show.Text = res.GetString("CheckBox_Show.Text")
                CheckBox_Show_Other_RimRegion.Text = res.GetString("CheckBox_Show_Other_RimRegion.Text")
                GroupBox_Load.Text = res.GetString("GroupBox_Load.Text")
                GroupBox_Modify.Text = res.GetString("GroupBox_Modify.Text")
                GroupBox_Parameter.Text = res.GetString("GroupBox_Parameter.Text")
                GroupBox_Round.Text = res.GetString("GroupBox_Round.Text")
                Label_Bottom.Text = res.GetString("Label_Bottom.Text")
                Label_Left.Text = res.GetString("Label_Left.Text")
                Label_ReconstructHeight.Text = res.GetString("Label_ReconstructHeight.Text")
                Label_ReconstructLow.Text = res.GetString("Label_ReconstructLow.Text")
                Label_Right.Text = res.GetString("Label_Right.Text")
                Label_Select.Text = res.GetString("Label_Select.Text")
                Label_Top.Text = res.GetString("Label_Top.Text")
                Label3.Text = res.GetString("Label3.Text")
                Label4.Text = res.GetString("Label4.Text")
                lb_ORR_Bottom.Text = res.GetString("lb_ORR_Bottom.Text")
                lb_ORR_Left.Text = res.GetString("lb_ORR_Left.Text")
                lb_ORR_Right.Text = res.GetString("lb_ORR_Right.Text")
                lb_ORR_Top.Text = res.GetString("lb_ORR_Top.Text")
                RadioButton_Finish.Text = res.GetString("RadioButton_Finish.Text")
                RadioButton_Manual.Text = res.GetString("RadioButton_Manual.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- ComboBox Event ---"

    Private Sub ComboBox_Select_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Select.SelectedIndexChanged

        Select Case Me.ComboBox_Select.SelectedIndex
            Case Me.m_BlobSmoothIndex   'Blob ���ƳB�z�v��
                Me.m_Form.CurrentIndex1 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
                Me.m_CurrentMuraIndex = Me.m_BlobSmoothIndex
            Case Me.m_BlobWhiteIndex   'Blob �۴�v��(�G)
                Me.m_Form.CurrentIndex1 = 8
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 8
                Me.m_CurrentMuraIndex = Me.m_BlobWhiteIndex
            Case Me.m_BlobBlackIndex  'Blob �۴�v��(�t)
                Me.m_Form.CurrentIndex1 = 9
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 9
                Me.m_CurrentMuraIndex = Me.m_BlobBlackIndex
            Case Me.m_BlobRecWhiteIndex  '��tBlob �v���B�z(�G-Reconstruct)
                Me.m_Form.CurrentIndex1 = 16
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 16
                Me.m_CurrentMuraIndex = Me.m_BlobRecWhiteIndex
            Case Me.m_BlobRecBlackIndex  '��tBlob �v���B�z(�t-Reconstruct)
                Me.m_Form.CurrentIndex1 = 17
                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 17
                Me.m_CurrentMuraIndex = Me.m_BlobRecBlackIndex
        End Select

        If Me.ComboBox_Select.Items.Count > 0 Then
            Me.GroupBox_Modify.Enabled = True
        Else
            Me.GroupBox_Modify.Enabled = False
        End If

        Me.m_Form.ImageUpdate()
        'Me.m_Form.ImageZoomAll()
        If CheckBox_Show.Checked Then Me.ReDraw()
    End Sub

#Region "--- UpdateSelectdImage ---"
    Private Sub UpdateSelectdImage()
        Dim Image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Select Case Me.ComboBox_Select.SelectedIndex
            Case Me.m_BlobSmoothIndex    'Blob ���ƳB�z�v��
                Image = Me.m_MuraProcess.Img_BlobMura_SmoothChild
            Case Me.m_BlobWhiteIndex     'Blob �۴�v��(�G)
                Image = Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild
            Case Me.m_BlobBlackIndex     'Blob �۴�v��(�t)
                Image = Me.m_MuraProcess.Img_BlobMuraArea_BlackChild
            Case Me.m_BlobRecWhiteIndex  '��tBlob �v���B�z(�G-Reconstruct)
                Image = Me.m_MuraProcess.Img_WhiteReconstructRImChild
            Case Me.m_BlobRecBlackIndex  '��tBlob �v���B�z(�t-Reconstruct)
                Image = Me.m_MuraProcess.Img_BlackReconstructRimChild
        End Select

        If Image <> M_NULL Then
            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
            SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
            Type = MbufInquire(Image, M_TYPE, M_NULL)

            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                MbufFree(imageBuffer)
                imageBuffer = M_NULL
                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
            End If
            MbufCopy(Image, imageBuffer)

            MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
            MbufControl(Image, M_MODIFIED, M_DEFAULT)
            MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

            Me.m_Form.ResetScrollBar()
        End If
    End Sub
#End Region

#End Region

#Region "--- RadioButton Event ---"

#Region "--- RadioButton_Finish ---"
    Private Sub RadioButton_Finish_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Finish.CheckedChanged
        Dim boundary As ClsParameterBoundary
        Dim str As String
        Dim dirPath As String
        Dim Parameter_Lists As String

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Button Control ---   
        Button_Enable(False)
        Me.BtnPre_BlobMuraRound.Enabled = True

        If Me.RadioButton_Finish.Checked Then
            Me.GroupBox_Round.Enabled = False
            Me.ComboBox_Select.Enabled = True
            Me.GroupBox_Load.Enabled = True

            If Me.ComboBox_Select.Items.Count >= 2 Then
                Me.Button_CalculateBlob.Enabled = True
                If Me.ComboBox_Select.Items.Count >= 4 Then
                    Me.GroupBox_Parameter.Enabled = True
                End If
            End If

            boundary = Me.m_MuraProcess.CurrentMuraPatternRecipe.Rim
            boundary.TopY = Me.NumericUpDown_RimTop.Value
            boundary.BottomY = Me.NumericUpDown_RimBottom.Value
            boundary.LeftX = Me.NumericUpDown_RimLeft.Value
            boundary.RightX = Me.NumericUpDown_RimRight.Value

            '----------------------------------------------------------------------------------------------
            ' Dialog_BlobMuraRound Setting   ==> Request_Command = "DIALOG_BLOBMURAROUND_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_BLOBMURAROUND_SETTING"
                TimeOut = 100000 '100 secs
                Parameter_Lists = "RimTop," & Me.NumericUpDown_RimTop.Value & ";" & "RimBottom," & Me.NumericUpDown_RimBottom.Value & ";" & "RimLeft," & Me.NumericUpDown_RimLeft.Value & ";" & "RimRight," & Me.NumericUpDown_RimRight.Value & ";" & _
                                  "WhiteMura_ReconstructHeight," & Me.NumericUpDown_WhiteMura_ReconstructHeight.Value & ";" & "WhiteMura_ReconstructLow," & Me.NumericUpDown_WhiteMura_ReconstructLow.Value & ";" & _
                                  "BlackMura_ReconstructHeight," & Me.NumericUpDown_BlackMura_ReconstructHeight.Value & ";" & "BlackMura_ReconstructLow," & Me.NumericUpDown_BlackMura_ReconstructLow.Value

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraRound Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraRound.RadioButton_Finish]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.RadioButton_Finish]Dialog_BlobMuraRound Setting Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.RadioButton_Finish]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
            '-----------------------------------------------------------------------------------------------------

            dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraSmooth.Button_Ok]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Ok]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_MuraSmooth.Button_Ok]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            Me.UpdateUserLevel()
        End If
    End Sub
#End Region

#Region "--- RadioButton_Manual ---"
    Private Sub RadioButton_Manual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Manual.CheckedChanged
        If Me.RadioButton_Manual.Checked Then
            Me.GroupBox_Round.Enabled = True
            Me.ComboBox_Select.Enabled = False
            Me.GroupBox_Load.Enabled = False
            Me.GroupBox_Parameter.Enabled = False
        End If
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_Show ---"
    Private Sub CheckBox_Show_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show.CheckedChanged
        Me.CheckBox_Show_Other_RimRegion.Checked = False
        Me.ReDraw()
    End Sub
#End Region

#Region "--- CheckBox_Rim ---"
    Private Sub CheckBox_Rim_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Rim.CheckedChanged
        Me.GroupBox_Modify.Enabled = Me.CheckBox_Rim.Checked
        Me.GroupBox_Parameter.Enabled = Me.CheckBox_Rim.Checked
        Me.Button_CalculateBlob.Enabled = Me.CheckBox_Rim.Checked

        Me.GroupBox_Other_RimRegion_Setting.Enabled = Me.CheckBox_Rim.Checked
        Me.GroupBox_AutoAddORR.Enabled = Me.CheckBox_Rim.Checked
        Me.GroupBox_MannualAddORR.Enabled = Me.CheckBox_Rim.Checked
    End Sub
#End Region

#Region "--- CheckBox_Show_Other_RimRegion_CheckedChanged ---"
    Private Sub CheckBox_Show_Other_RimRegion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show_Other_RimRegion.CheckedChanged
        If Me.CheckBox_Show_Other_RimRegion.Checked Then
            Me.CheckBox_Show.Checked = False
            Me.CheckBox_ORR_Mannual.Checked = False

            Me.Button_ORR_CLearAll.Enabled = True
            Me.Button_ORR_DeleteOne.Enabled = True
            Me.Button_ORR_AddOne.Enabled = True

            Me.DrawMark()
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_CalculateBlob ---"
    Private Sub Button_CalculateBlob_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_CalculateBlob.Click
        Dim mp As ClsMuraProcess
        Dim RefX As Integer
        Dim RefY As Integer
        Dim errMsg As String = ""
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Button Control ---   
        Button_Enable(False)

        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdHeight.Value = Me.NumericUpDown_WhiteMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdLow.Value = Me.NumericUpDown_WhiteMura_ReconstructLow.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdHeight.Value = Me.NumericUpDown_BlackMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdLow.Value = Me.NumericUpDown_BlackMura_ReconstructLow.Value

        '----------------------------------------------------------------------------------------------
        ' Dialog_BlobMuraRound Setting   ==> Request_Command = "DIALOG_BLOBMURAROUND_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BLOBMURAROUND_SETTING"
            TimeOut = 100000 '100 secs
            Parameter_Lists = "RimTop," & Me.NumericUpDown_RimTop.Value & ";" & "RimBottom," & Me.NumericUpDown_RimBottom.Value & ";" & "RimLeft," & Me.NumericUpDown_RimLeft.Value & ";" & "RimRight," & Me.NumericUpDown_RimRight.Value & ";" & _
                              "WhiteMura_ReconstructHeight," & Me.NumericUpDown_WhiteMura_ReconstructHeight.Value & ";" & "WhiteMura_ReconstructLow," & Me.NumericUpDown_WhiteMura_ReconstructLow.Value & ";" & _
                              "BlackMura_ReconstructHeight," & Me.NumericUpDown_BlackMura_ReconstructHeight.Value & ";" & "BlackMura_ReconstructLow," & Me.NumericUpDown_BlackMura_ReconstructLow.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraRound Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Dialog_BlobMuraRound Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


        '�v���B�z ------------------------------------------------------------------------------------------------------------------
        mp = Me.m_MuraProcess

        '�p��Smooth �v�� ---  (BlobMuraLocal �w���p��A�G������)

        '----------------------------------------------------------------------------------------------
        ' Calculate Smooth Image  ==> Request_Command = "CALCULATE_SMOOTH" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        'Try
        '    '--- Prepare Command ---
        '    Request_Command = "CALCULATE_SMOOTH"
        '    TimeOut = 100000 '100 secs
        '    SaveImage = False

        '    Response_OK = False
        '    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
        '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

        '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
        '        Response_OK = True
        '    Else
        '        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '        MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        Button_Enable(True)
        '        Exit Sub
        '    End If

        'Catch ex As Exception
        '    Button_Enable(True)
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Smooth Image Error ! (" & ex.Message & ")")
        '    MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try


        '�p��GoldenSample �v�� ---  (BlobMuraLocal �w���p��A�G������)

        '----------------------------------------------------------------------------------------------
        ' Calculate Area Golden Sample Image  ==> Request_Command = "CALCULATE_AREA_GOLDENSAMPLE" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_AREA_GOLDENSAMPLE"
            TimeOut = 100000 '100 secs
            SaveImage = False

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Area Golden Sample Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Area Golden Sample Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '�p��Blob White \Black �v�� ---  (BlobMuraLocal �w���p��A�G������)

        '----------------------------------------------------------------------------------------------
        ' Calculate White Area Image  ==> Request_Command = "CALCULATE_WHITE_AREA" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_WHITE_AREA"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, Me.CheckBox_WhiteRimBlobValue.Checked, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

            If Response_OK Then
                '[1] Update Processed Image (Img_16U_BlobMura_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
              
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = M_NULL
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_BlobMuraArea_WhiteChild) ---
                If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild <> M_NULL Then
                    MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild)
                    Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = M_NULL
                End If

                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                Else
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                End If

                Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate White Area Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Black Area Image  ==> Request_Command = "CALCULATE_BLACK_AREA" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLACK_AREA"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, Me.CheckBox_BlackRimBlobValue.Checked, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

            If Response_OK Then
                '[1] Update Processed Image (Img_16U_BlobMura_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
              
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = M_NULL
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    '[2] Update Processed Image (Img_BlobMuraArea_BlackChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild)
                        Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)
                End If

            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Black Area Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


        '�p��Reconstuct White \Black �v�� for Round ---
        '----------------------------------------------------------------------------------------------
        ' Calculate Reconstruct Rim Image  ==> Request_Command = "CALCULATE_RECONSTRUCT_RIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_RECONSTRUCT_RIM"
            TimeOut = 500000 '500 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Reconstruct Rim Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- White Reconstruct Rim ---

                '[1] Update Processed Image (Img_1U_WhiteReconstructRim_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
             
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)
                            Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    '[2] Update Processed Image (Img_WhiteReconstructRImChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild)
                        Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                End If

                'Black Reconstruct Rim ---

                '[1] Update Processed Image (Img_1U_BlackReconstructRim_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If
              
                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage)
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage = M_NULL
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    '[2] Update Processed Image (Img_BlackReconstructRimChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild)
                        Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                End If

            End If
        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Reconstruct Rim Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '-------------------------------------------------------------------------------------------------------------------------------
        '�v����ƳB�z ---

        RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
        RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

        ''�p����tBlob Mura --- 
        '----------------------------------------------------------------------------------------------
        ' Calculate Black Rim Mura  ==> Request_Command = "CALCULATE_BLACKBLOB_RIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLACKBLOB_RIM"
            TimeOut = 500000 '500 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Black Rim Mura Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate White Rim Mura  ==> Request_Command = "CALCULATE_WHITEBLOB_RIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_WHITEBLOB_RIM"
            TimeOut = 500000 '500 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate White Rim Mura Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Position shift in Mura_Rim  ==> Request_Command = "POSITIONSHIFT_MURARIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "POSITIONSHIFT_MURARIM"
            TimeOut = 200000 '200 secs

            RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
            RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RefX, RefY, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Position shift in Mura_Rim  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Position shift in Mura_Rim  Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------------------------------------------

        Me.CheckBox_Show.Checked = True
        Me.m_Blob = True
        Me.Button_Enable(True)

        Me.ComboBox_Select.SelectedIndex = Me.m_CurrentMuraIndex
        Me.UpdateSelectdImage()
        Me.m_Form.ImageZoomAll()
        Me.UpdateUserLevel()
        If CheckBox_Show.Checked Then Me.ReDraw()

        '----------------------------------------------------------------------------------------------------------------------------------
    End Sub
#End Region

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim str As String
        Dim dir As String = ""
        Dim dirPath As String
        Dim Parameter_Lists As String = ""

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Button Control ---   
        Button_Enable(False)   '2010/07/12 Rick add

        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseRound.Value = Me.CheckBox_Rim.Checked
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdHeight.Value = Me.NumericUpDown_WhiteMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdLow.Value = Me.NumericUpDown_WhiteMura_ReconstructLow.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdHeight.Value = Me.NumericUpDown_BlackMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdLow.Value = Me.NumericUpDown_BlackMura_ReconstructLow.Value
        '----------------------------------------------------------------------------------------------
        ' Dialog_BlobMuraRound Setting   ==> Request_Command = "DIALOG_BLOBMURAROUND_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BLOBMURAROUND_SETTING"
            TimeOut = 10000 '10 secs
            Parameter_Lists = "UseRound," & Me.CheckBox_Rim.Checked & ";" & _
                              "RimTop," & Me.NumericUpDown_RimTop.Value & ";" & "RimBottom," & Me.NumericUpDown_RimBottom.Value & ";" & "RimLeft," & Me.NumericUpDown_RimLeft.Value & ";" & "RimRight," & Me.NumericUpDown_RimRight.Value & ";" & _
                              "WhiteMura_ReconstructHeight," & Me.NumericUpDown_WhiteMura_ReconstructHeight.Value & ";" & "WhiteMura_ReconstructLow," & Me.NumericUpDown_WhiteMura_ReconstructLow.Value & ";" & _
                              "BlackMura_ReconstructHeight," & Me.NumericUpDown_BlackMura_ReconstructHeight.Value & ";" & "BlackMura_ReconstructLow," & Me.NumericUpDown_BlackMura_ReconstructLow.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraRound Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_Save]Dialog_BlobMuraRound Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'Save Current Mura Pattern Recipe ---

        dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        If Not Directory.Exists(dirPath) Then
            Directory.CreateDirectory(dirPath)
        End If
        str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
        Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

        Button_Enable(True)

    End Sub
#End Region

#Region "--- Button_Cancel ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.Close()
    End Sub
#End Region

#Region "--- BtnPre_BlobMuraRound ---"
    Private Sub BtnPre_BlobMuraRound_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnPre_BlobMuraRound.Click
        Me.Close()
    End Sub
#End Region

#Region "--- MuraBlob Other Rim Region Recipe ---"

#Region "--- Button_ORR_AddOne_Click ---"
    Private Sub Button_ORR_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ORR_AddOne.Click
        If NumericUpDown_BlackMura_ORR_ReconstructHeight.Text = "0" Or NumericUpDown_BlackMura_ORR_ReconstructLow.Text = "0" Then Exit Sub
        If NumericUpDown_WhiteMura_ORR_ReconstructHeight.Text = "0" Or NumericUpDown_WhiteMura_ORR_ReconstructLow.Text = "0" Then Exit Sub
        If TextBox_ORR_MaxX.Text = "0" Or TextBox_ORR_MaxY.Text = "0" Then Exit Sub

        Dim mbrr As New ClsMuraBlobRimRegionRecipe
        Dim str As String
        Dim dirPath As String = ""
        Dim lvi As ListViewItem
        Dim ORR As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable(False)

            If Me.TextBox_ORR_MinX.Text <> "" AndAlso Me.TextBox_ORR_MaxX.Text <> "" AndAlso Me.TextBox_ORR_MinY.Text <> "" AndAlso Me.TextBox_ORR_MaxY.Text <> "" Then
                If Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then   'ROI
                    mbrr.LeftX = CInt(Me.TextBox_ORR_MinX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mbrr.TopY = CInt(Me.TextBox_ORR_MinY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                    mbrr.RightX = CInt(Me.TextBox_ORR_MaxX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                    mbrr.BottomY = CInt(Me.TextBox_ORR_MaxY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                Else   '���v��
                    mbrr.LeftX = CInt(Me.TextBox_ORR_MinX.Text)
                    mbrr.TopY = CInt(Me.TextBox_ORR_MinY.Text)
                    mbrr.RightX = CInt(Me.TextBox_ORR_MaxX.Text)
                    mbrr.BottomY = CInt(Me.TextBox_ORR_MaxY.Text)
                End If

                mbrr.White_TH = Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Value
                mbrr.White_TL = Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Value
                mbrr.Black_TH = Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Value
                mbrr.Black_TL = Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Value

                Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.Add(mbrr)

                lvi = Me.ListView_Other_RimRegion.Items.Add(Me.TextBox_ORR_MinX.Text)
                lvi.SubItems.Add(Me.TextBox_ORR_MinY.Text)
                lvi.SubItems.Add(Me.TextBox_ORR_MaxX.Text)
                lvi.SubItems.Add(Me.TextBox_ORR_MaxY.Text)
                lvi.SubItems.Add(mbrr.White_TH)
                lvi.SubItems.Add(mbrr.White_TL)
                lvi.SubItems.Add(mbrr.Black_TH)
                lvi.SubItems.Add(mbrr.Black_TL)

                'Update Mura Blob Rim Region Recipe ---
                ORR = ORR & "LeftX," & mbrr.LeftX & ",TopY," & mbrr.TopY & ",RightX," & mbrr.RightX & ",BottomY," & mbrr.BottomY & ",White_TH," & mbrr.White_TH & ",White_TL," & mbrr.White_TL & ",Black_TH," & mbrr.Black_TH & ",Black_TL," & mbrr.Black_TL & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Mura Blob Rim Region Recipe   ==> Request_Command = "MURABLOB_RIMREGION_RECIPE_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "MURABLOB_RIMREGION_RECIPE_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, ORR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Mura Blob Rim Region Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_BlobMuraRound.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_AddRegion]Add One Mura Blob Rim Region Recipe Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            Me.TextBox_ORR_MinX.Text = ""
            Me.TextBox_ORR_MinY.Text = ""
            Me.TextBox_ORR_MaxX.Text = ""
            Me.TextBox_ORR_MaxY.Text = ""

            'Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Value = 0
            'Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Value = 0
            'Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Value = 0
            'Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Value = 0

            '2009/09/24 ��s���| ---
            Me.Label_ORRCount.Text = "�ƶq = " & Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.Count

            If (Response_OK = False) Then
                Me.Button_Enable(True)
                Exit Sub
            End If

            '--- Save Current Mura Pattern Recipe ---
            dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_AddOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            'Enable Button ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_BlobMuraRound.Button_ORR_AddOne]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_AddOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_ORR_DeleteOne_Click ---"
    Private Sub Button_ORR_DeleteOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ORR_DeleteOne.Click
        If Me.ListView_Other_RimRegion.SelectedItems.Count <= 0 Then Exit Sub

        Dim Str As String
        Dim offX As Integer
        Dim offY As Integer
        Dim Delete_Index As Integer
        Dim dirPath As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable(False)

            offX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
            offY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

            Delete_Index = Me.ListView_Other_RimRegion.SelectedIndices(0)
            If Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.Count > 0 AndAlso Me.ListView_Other_RimRegion.SelectedIndices.Count <> 0 Then
                Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.RemoveAt(Delete_Index)
                Me.TextBox_ORR_MinX.Text = "0"
                Me.TextBox_ORR_MinY.Text = "0"
                Me.TextBox_ORR_MaxX.Text = "0"
                Me.TextBox_ORR_MaxY.Text = "0"

                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.DrawMuraBlob_OtherRimRegion(0, 0)
                Me.MuraBlob_OtherRimRegionReflash()
            End If
            Me.Button_ORR_DeleteOne.Enabled = False

            '----------------------------------------------------------------------------------------------
            ' Delete One Mura Blob Rim Region Recipe   ==> Request_Command = "MURABLOB_RIMREGION_RECIPE_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "MURABLOB_RIMREGION_RECIPE_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Mura Blob Rim Region Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_ORR_DeleteOne_Click]Delete One Mura Blob Rim Region Recipe Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Save Current Mura Pattern Recipe ---
            dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            Str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(Str, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_ORR_DeleteOne_Click]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_DeleteOne_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            'Enable Button ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_BlobMuraRound.Button_ORR_DeleteOne_Click]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_DeleteOne_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_ORR_ClearAll_Click ---"
    Private Sub Button_ORR_ClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ORR_CLearAll.Click
        Dim FilePath As String = ""
        Dim dirPath As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.Clear()
            Call MuraBlob_OtherRimRegionReflash()

            '----------------------------------------------------------------------------------------------
            ' Clear all Mura Blob Rim Region Recipe   ==> Request_Command = "MURABLOB_RIMREGION_RECIPE_CLEAR " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "MURABLOB_RIMREGION_RECIPE_CLEAR"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Mura Blob Rim Region Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_ClearAll_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_ORR_ClearAll_Click]Clear all Mura Blob Rim Region Recipe Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Save Current Mura Pattern Recipe ---
            dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            FilePath = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(FilePath, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, FilePath, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_ClearAll_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_ORR_ClearAll_Click]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_ORR_ClearAll_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            'Enable Button ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_BlobMuraRound.Button_FR_CLearAll]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraRound.Button_FR_CLearAll]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#End Region

#Region "--- Draw Event ---"

#Region "--- DrawMark ---"
    Private Sub DrawMark()
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        'Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
        offY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                Me.DrawMuraBlob_OtherRimRegion(0, 0)
            Case 1
                Me.DrawMuraBlob_OtherRimRegion(offX, offY)
        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = True
    End Sub
#End Region

#Region "--- DrawMuraBlob_OtherRimRegion ---"
    Private Sub DrawMuraBlob_OtherRimRegion(ByVal offX As Integer, ByVal offY As Integer)
        Dim image As MIL_ID = M_NULL
        Dim rect As Rectangle
        Dim s As Double
        Dim i As Integer
        Dim v As Integer
        Dim h As Integer
        Dim SizeX, SizeY As Integer
        Dim mbrra As ClsMuraBlobRimRegionRecipeArray
        Dim mbrr As ClsMuraBlobRimRegionRecipe
        Dim ZoomX, ZoomY As Double

        Try
            If Me.CheckBox_Show_Other_RimRegion.Checked Then
                '--- Initial ---
                rect = New Rectangle
                's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
                'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)
                '--- Initial ---
                mbrra = Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray

                Me.m_Pen.Color = Color.Yellow
                Me.m_Pen.Width = s

                '--- [1] Drawing all Region ---
                For i = 0 To mbrra.RRRG.Count - 1
                    mbrr = mbrra.RRRG.Item(i)

                    If Not (mbrr.LeftX = 0 And mbrr.TopY = 0 And mbrr.RightX = 0 And mbrr.BottomY = 0) Then
                        rect.X = (mbrr.LeftX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                        rect.Y = (mbrr.TopY - Me.m_Form.VScrollBar.Value - offY) * ZoomX
                        rect.Width = (mbrr.RightX - mbrr.LeftX) * ZoomX + 1
                        rect.Height = (mbrr.BottomY - mbrr.TopY) * ZoomX + 1
                        Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                    End If

                Next

                '--- [2] Draw Current Region ---
                If Not (TextBox_ORR_MinX.Text = "" And TextBox_ORR_MinY.Text = "" And TextBox_ORR_MaxX.Text = "" And TextBox_ORR_MaxY.Text = "") Then
                    rect.X = (CInt(TextBox_ORR_MinX.Text) - Me.m_Form.HScrollBar.Value) * ZoomX
                    rect.Y = (CInt(TextBox_ORR_MinY.Text) - Me.m_Form.VScrollBar.Value) * ZoomX
                    rect.Width = (CInt(TextBox_ORR_MaxX.Text) - CInt(TextBox_ORR_MinX.Text)) * ZoomX + 1
                    rect.Height = (CInt(TextBox_ORR_MaxY.Text) - CInt(TextBox_ORR_MinY.Text)) * ZoomX + 1
                    Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                End If

                '--- [3] Draw Center\Rim Region ---
                '--- Initial ---
                s = Math.Ceiling(ZoomX)
                Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                '--- Initial ---

                '--- �e��t�ϰ� ---
                Me.m_SolidBrush.Color = Color.Green

                '[1] ����u ---
                v = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 1) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                '[2] �k��u ---
                v = SizeX - Me.NumericUpDown_RimRight.Value
                v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If

                '[3] �W��u ---
                v = (Me.NumericUpDown_RimTop.Value - Me.m_Form.VScrollBar.Value - 1) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                '[4] �U��u ---
                v = SizeY - Me.NumericUpDown_RimBottom.Value
                v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If

                '--- �e���߰ϰ� ---

                Me.m_SolidBrush.Color = Color.Red
                '[1] ����u ---
                v = (Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.LeftX - Me.m_Form.HScrollBar.Value - 1) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                '[2] �k��u ---
                v = SizeX - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.RightX
                v = (v - Me.m_Form.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                '[3] �W��u ---
                v = (Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.TopY - Me.m_Form.VScrollBar.Value - 1) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                '[4] �U��u ---
                v = SizeY - Me.m_MuraProcess.MuraModelRecipe.BoundaryRound.BottomY
                v = (v - Me.m_Form.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If

            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = True
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.DrawMuraBlob_OtherRimRegion]Draw Mura Blob Other Rim Region Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- ListView Event ---"

#Region "--- MuraBlob Other Rim Region ---"

#Region "--- ListView_Other_RimRegion_Click ---"
    Private Sub ListView_Other_RimRegion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Other_RimRegion.Click
        Dim SelectIndex As Integer
        If Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.Count > 0 Then
            SelectIndex = ListView_Other_RimRegion.SelectedIndices(0)
            Me.TextBox_ORR_MinX.Text = ListView_Other_RimRegion.Items(SelectIndex).SubItems(0).Text
            Me.TextBox_ORR_MinY.Text = ListView_Other_RimRegion.Items(SelectIndex).SubItems(1).Text
            Me.TextBox_ORR_MaxX.Text = ListView_Other_RimRegion.Items(SelectIndex).SubItems(2).Text
            Me.TextBox_ORR_MaxY.Text = ListView_Other_RimRegion.Items(SelectIndex).SubItems(3).Text

            Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Value = ListView_Other_RimRegion.Items(SelectIndex).SubItems(4).Text
            Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Value = ListView_Other_RimRegion.Items(SelectIndex).SubItems(5).Text
            Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Value = ListView_Other_RimRegion.Items(SelectIndex).SubItems(6).Text
            Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Value = ListView_Other_RimRegion.Items(SelectIndex).SubItems(7).Text

            Me.Button_ORR_DeleteOne.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ListView_Other_RimRegion_KeyUp ---"
    Private Sub ListView_Other_RimRegion_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_Other_RimRegion.KeyUp
        Try
            If e.KeyCode = Keys.Delete AndAlso ListView_Other_RimRegion.SelectedIndices.Count <> 0 Then
                Me.Button_ORR_DeleteOne_Click(sender, e)
            End If

        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_BlobMuraRound.ListView_Other_RimRegion_KeyUp]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraRound.ListView_Other_RimRegion_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#End Region

#Region "--- AxMDisplay Operation ---"

#Region "--- m_AxMDisplay_PaintEvent ---"
    Private Sub m_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            Me.ReDraw()
        End If

        If Not Me.m_Form.PaintStop And Me.CheckBox_Show_Other_RimRegion.Checked Then
            Me.DrawMark()
        End If
    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseDownEvent ---"
    Private Sub m_AxMDisplay_MouseDownEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim image As MIL_ID = M_NULL
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        If e.Button = Windows.Forms.MouseButtons.Left Then

            image = MbufInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked And M_NULL <> M_NULL Then
                '--- Initial ---
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                '--- Initial ---

                p = (Me.NumericUpDown_RimLeft.Value - Me.m_Form.HScrollBar.Value - 0.5) * ZoomX
                dis1 = Math.Abs(e.X - p)
                p = SizeX - Me.NumericUpDown_RimRight.Value
                p = (p - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
                dis2 = Math.Abs(e.X - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomX * 0.5 + 3 Then
                        Me.m_Left = True
                    End If
                Else
                    If dis2 < ZoomX * 0.5 + 3 Then
                        Me.m_Right = True
                    End If
                End If
                p = (Me.NumericUpDown_RimTop.Value - 1 - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                dis1 = Math.Abs(e.Y - p)
                p = SizeY - Me.NumericUpDown_RimBottom.Value
                p = (p - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
                dis2 = Math.Abs(e.Y - p)
                If dis1 < dis2 Then
                    If dis1 < ZoomY * 0.5 + 3 Then
                        Me.m_Top = True
                    End If
                Else
                    If dis2 < ZoomY * 0.5 + 3 Then
                        Me.m_Bottom = True
                    End If
                End If
            End If

            '--- Other RimRegion ---
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_ORR_Mannual.Checked And Me.CheckBox_Show_Other_RimRegion.Checked Then   '�ƹ�����
                Me.m_Panel_AxMDisplay.Refresh()   '02/01 Rick add
                Me.TextBox_ORR_MinX.Text = CStr(Me.m_Form.MouseX)
                Me.TextBox_ORR_MinY.Text = CStr(Me.m_Form.MouseY)
            End If
        End If
    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseMoveEvent ---"
    Private Sub m_AxMDisplay_MouseMoveEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.RadioButton_Manual.Checked And Me.CheckBox_Show.Checked And image <> M_NULL Then
            If Me.m_Left Then
                Me.NumericUpDown_RimLeft.Value = Me.m_Form.MouseX + 1
            End If
            If Me.m_Right Then
                Me.NumericUpDown_RimRight.Value = MbufInquire(image, M_SIZE_X, M_NULL) - Me.m_Form.MouseX
            End If
            If Me.m_Top Then
                Me.NumericUpDown_RimTop.Value = Me.m_Form.MouseY + 1
            End If
            If Me.m_Bottom Then
                Me.NumericUpDown_RimBottom.Value = MbufInquire(image, M_SIZE_Y, M_NULL) - Me.m_Form.MouseY
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If

        '--- Other Rim Region ---
        If Me.CheckBox_Show_Other_RimRegion.Checked And Me.CheckBox_ORR_Mannual.Checked Then
            Me.m_Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
            If e.Button = Windows.Forms.MouseButtons.Left Then
                Me.TextBox_ORR_MaxX.Text = CStr(Me.m_Form.MouseX)
                Me.TextBox_ORR_MaxY.Text = CStr(Me.m_Form.MouseY)
            End If
            Me.DrawMark()
        End If
    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseUpEvent ---"
    Private Sub m_AxMDisplay_MouseUpEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_Left = False
            Me.m_Right = False
            Me.m_Top = False
            Me.m_Bottom = False
        End If
        If NumericUpDown_BlackMura_ORR_ReconstructHeight.Text = "0" Or NumericUpDown_BlackMura_ORR_ReconstructLow.Text = "0" Then Exit Sub
        If NumericUpDown_WhiteMura_ORR_ReconstructHeight.Text = "0" Or NumericUpDown_WhiteMura_ORR_ReconstructLow.Text = "0" Then Exit Sub

        If Me.CheckBox_Show.Checked AndAlso Me.CheckBox_ORR_Mannual.Checked Then
            Try
                '�إ߳s�u ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                '--- Disable Button ---
                Me.Button_Enable(False)

                '--- Other Rim Region ---
                If e.Button = Windows.Forms.MouseButtons.Left Then
                    Dim mbrr As New ClsMuraBlobRimRegionRecipe
                    Dim str As String
                    Dim lvi As ListViewItem
                    Dim ORR As String = ""
                    Dim dirPath As String = ""

                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                        mbrr.LeftX = CInt(Me.TextBox_ORR_MinX.Text)
                        mbrr.TopY = CInt(Me.TextBox_ORR_MinY.Text)
                        mbrr.RightX = CInt(Me.TextBox_ORR_MaxX.Text)
                        mbrr.BottomY = CInt(Me.TextBox_ORR_MaxY.Text)
                    ElseIf Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                        mbrr.LeftX = CInt(Me.TextBox_ORR_MinX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                        mbrr.TopY = CInt(Me.TextBox_ORR_MinY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                        mbrr.RightX = CInt(Me.TextBox_ORR_MaxX.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                        mbrr.BottomY = CInt(Me.TextBox_ORR_MaxY.Text) + Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY
                    End If

                    mbrr.White_TH = CInt(Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Value)
                    mbrr.White_TL = CInt(Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Value)
                    mbrr.Black_TH = CInt(Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Value)
                    mbrr.Black_TL = CInt(Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Value)

                    Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.Add(mbrr)

                    lvi = Me.ListView_Other_RimRegion.Items.Add(Me.TextBox_ORR_MinX.Text)
                    lvi.SubItems.Add(Me.TextBox_ORR_MinY.Text)
                    lvi.SubItems.Add(Me.TextBox_ORR_MaxX.Text)
                    lvi.SubItems.Add(Me.TextBox_ORR_MaxY.Text)
                    lvi.SubItems.Add(mbrr.White_TH)
                    lvi.SubItems.Add(mbrr.White_TL)
                    lvi.SubItems.Add(mbrr.Black_TH)
                    lvi.SubItems.Add(mbrr.Black_TL)

                    '---------------------------------------
                    'Update Mura Blob Rim Region Recipe ---
                    ORR = ORR & "LeftX," & mbrr.LeftX & ",TopY," & mbrr.TopY & ",RightX," & mbrr.RightX & ",BottomY," & mbrr.BottomY & ",White_TH," & mbrr.White_TH & ",White_TL," & mbrr.White_TL & ",Black_TH," & mbrr.Black_TH & ",Black_TL," & mbrr.Black_TL & ";"

                    '----------------------------------------------------------------------------------------------
                    ' Add One Mura Blob Rim Region Recipe   ==> Request_Command = "MURABLOB_RIMREGION_RECIPE_ADDONE " (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        'Prepare Command ---
                        Request_Command = "MURABLOB_RIMREGION_RECIPE_ADDONE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, ORR, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Mura Blob Rim Region Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_BlobMuraRound.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.m_AxMDisplay_MouseUpEvent]Add One Mura Blob Rim Region Recipe Error ! (" & ex.Message & ")")
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    Me.TextBox_ORR_MinX.Text = "0"
                    Me.TextBox_ORR_MinY.Text = "0"
                    Me.TextBox_ORR_MaxX.Text = "0"
                    Me.TextBox_ORR_MaxY.Text = "0"

                    '2009/09/24 ��s���| ---
                    Me.Label_ORRCount.Text = "�ƶq = " & Me.m_MuraProcess.CurrentMuraPatternRecipe.MuraBlobRimRegionRecipeArray.RRRG.Count

                    If (Response_OK = False) Then
                        Me.Button_Enable(True)
                        Exit Sub
                    End If

                    '--- Save Current Mura Pattern Recipe ---
                    dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
                    If Not Directory.Exists(dirPath) Then
                        Directory.CreateDirectory(dirPath)
                    End If
                    str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
                    Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

                    '----------------------------------------------------------------------------------------------
                    ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_BlobMuraRound.m_AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Button_Enable(True)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        Button_Enable(True)
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.m_AxMDisplay_MouseUpEvent]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_BlobMuraRound.m_AxMDisplay_MouseUpEvent]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try

                    Me.DrawMark()
                End If

                'Enable Button ---
                Me.Button_Enable(True)
            Catch ex As Exception
                Me.Button_Enable(True)
                Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & ex.Message)
                MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown Event ---"
    Private Sub NumericUpDown_Top_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimTop.ValueChanged
        If Me.m_AxMDisplay <> M_NULL AndAlso MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL) <> M_NULL Then
            Me.ReDraw()
        End If
    End Sub
    Private Sub NumericUpDown_Bottom_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimBottom.ValueChanged
        If Me.m_AxMDisplay <> M_NULL AndAlso MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL) <> M_NULL Then
            Me.ReDraw()
        End If
    End Sub
    Private Sub NumericUpDown_Left_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimLeft.ValueChanged
        If Me.m_AxMDisplay <> M_NULL AndAlso MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL) <> M_NULL Then
            Me.ReDraw()
        End If
    End Sub
    Private Sub NumericUpDown_Right_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_RimRight.ValueChanged
        If Me.m_AxMDisplay <> M_NULL AndAlso MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL) <> M_NULL Then
            Me.ReDraw()
        End If
    End Sub

    Private Sub NumericUpDown_ReconstructHeight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_WhiteMura_ReconstructHeight.ValueChanged
        Me.NumericUpDown_WhiteMura_ReconstructLow.Maximum = Me.NumericUpDown_WhiteMura_ReconstructHeight.Value - 1
    End Sub

    Private Sub NumericUpDown_ReconstructLow_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_WhiteMura_ReconstructLow.ValueChanged
        Me.NumericUpDown_WhiteMura_ReconstructHeight.Minimum = Me.NumericUpDown_WhiteMura_ReconstructLow.Value + 1
    End Sub

    Private Sub NumericUpDown_BlackMura_ReconstructHeight_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BlackMura_ReconstructHeight.ValueChanged
        Me.NumericUpDown_BlackMura_ReconstructLow.Maximum = Me.NumericUpDown_BlackMura_ReconstructHeight.Value - 1
    End Sub

    Private Sub NumericUpDown_BlackMura_ReconstructLow_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BlackMura_ReconstructLow.ValueChanged
        Me.NumericUpDown_BlackMura_ReconstructHeight.Minimum = Me.NumericUpDown_BlackMura_ReconstructLow.Value + 1
    End Sub

    Private Sub NumericUpDown_WhiteMura_ORR_ReconstructHeight_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_WhiteMura_ORR_ReconstructHeight.ValueChanged
        Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Maximum = Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Value - 1
    End Sub

    Private Sub NumericUpDown_WhiteMura_ORR_ReconstructLow_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_WhiteMura_ORR_ReconstructLow.ValueChanged
        Me.NumericUpDown_WhiteMura_ORR_ReconstructHeight.Minimum = Me.NumericUpDown_WhiteMura_ORR_ReconstructLow.Value + 1
    End Sub
    Private Sub NumericUpDown_BlackMura_ORR_ReconstructHeight_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_BlackMura_ORR_ReconstructHeight.ValueChanged
        Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Maximum = Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Value - 1
    End Sub

    Private Sub NumericUpDown_BlackMura_ORR_ReconstructLow_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_BlackMura_ORR_ReconstructLow.ValueChanged
        Me.NumericUpDown_BlackMura_ORR_ReconstructHeight.Minimum = Me.NumericUpDown_BlackMura_ORR_ReconstructLow.Value + 1
    End Sub

#End Region

#Region "--- UI Event ---"

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If Me.Focused AndAlso CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If Me.Focused AndAlso CheckBox_Show.Checked Then
            Me.ReDraw()
        End If
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_Show.Checked Then Me.ReDraw()
        End If
    End Sub
#End Region

#End Region



End Class