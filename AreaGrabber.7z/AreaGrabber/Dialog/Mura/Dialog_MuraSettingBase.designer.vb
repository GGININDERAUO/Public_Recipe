<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MuraSettingBase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_MuraSettingBase))
        Me.ListView_Pattern = New System.Windows.Forms.ListView()
        Me.ColumnHeader_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_Pattern = New System.Windows.Forms.TabPage()
        Me.CheckBox_UseAutoFFC = New System.Windows.Forms.CheckBox()
        Me.Label_AreaMisalliance = New System.Windows.Forms.Label()
        Me.NumericUpDown_AreaMisalliance = New System.Windows.Forms.NumericUpDown()
        Me.Label_Distance = New System.Windows.Forms.Label()
        Me.NumericUpDown_Distance = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_FalseCount = New System.Windows.Forms.NumericUpDown()
        Me.Label_FalseCount = New System.Windows.Forms.Label()
        Me.CheckBox_AutoAdd = New System.Windows.Forms.CheckBox()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.TextBox_DataRootPath = New System.Windows.Forms.TextBox()
        Me.Label_DeleteDay = New System.Windows.Forms.Label()
        Me.Label_ImagePath = New System.Windows.Forms.Label()
        Me.TabPage_Other = New System.Windows.Forms.TabPage()
        Me.CheckBox_UseSemu = New System.Windows.Forms.CheckBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ComboBox_RemoveHVSaveType = New System.Windows.Forms.ComboBox()
        Me.GroupBox_ResizeFullImage = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_ResizeCount = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button_ImagePath = New System.Windows.Forms.Button()
        Me.NumericUpDown_DeleteDay = New System.Windows.Forms.NumericUpDown()
        Me.Label_DeleteScale = New System.Windows.Forms.Label()
        Me.NumericUpDown_DeleteScale = New System.Windows.Forms.NumericUpDown()
        Me.ToolStripMenuItem_AddPattern = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_RemovePattern = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip_Pattern = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.TabControl_Setting = New System.Windows.Forms.TabControl()
        Me.TabPage_False = New System.Windows.Forms.TabPage()
        Me.GroupBox_MuraFalseDefect = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_CountToChangeFFC = New System.Windows.Forms.NumericUpDown()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.NumericUpDown_FilterBandDistance = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage_Pattern.SuspendLayout()
        CType(Me.NumericUpDown_AreaMisalliance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Distance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_FalseCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Other.SuspendLayout()
        Me.GroupBox_ResizeFullImage.SuspendLayout()
        CType(Me.NumericUpDown_ResizeCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DeleteDay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DeleteScale, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip_Pattern.SuspendLayout()
        Me.TabControl_Setting.SuspendLayout()
        Me.TabPage_False.SuspendLayout()
        Me.GroupBox_MuraFalseDefect.SuspendLayout()
        CType(Me.NumericUpDown_CountToChangeFFC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_FilterBandDistance, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ListView_Pattern
        '
        resources.ApplyResources(Me.ListView_Pattern, "ListView_Pattern")
        Me.ListView_Pattern.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.ListView_Pattern.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_Pattern})
        Me.ListView_Pattern.FullRowSelect = True
        Me.ListView_Pattern.MultiSelect = False
        Me.ListView_Pattern.Name = "ListView_Pattern"
        Me.ListView_Pattern.UseCompatibleStateImageBehavior = False
        Me.ListView_Pattern.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_Pattern
        '
        resources.ApplyResources(Me.ColumnHeader_Pattern, "ColumnHeader_Pattern")
        '
        'TabPage_Pattern
        '
        resources.ApplyResources(Me.TabPage_Pattern, "TabPage_Pattern")
        Me.TabPage_Pattern.Controls.Add(Me.ListView_Pattern)
        Me.TabPage_Pattern.Name = "TabPage_Pattern"
        Me.TabPage_Pattern.UseVisualStyleBackColor = True
        '
        'CheckBox_UseAutoFFC
        '
        resources.ApplyResources(Me.CheckBox_UseAutoFFC, "CheckBox_UseAutoFFC")
        Me.CheckBox_UseAutoFFC.Name = "CheckBox_UseAutoFFC"
        '
        'Label_AreaMisalliance
        '
        resources.ApplyResources(Me.Label_AreaMisalliance, "Label_AreaMisalliance")
        Me.Label_AreaMisalliance.Name = "Label_AreaMisalliance"
        '
        'NumericUpDown_AreaMisalliance
        '
        resources.ApplyResources(Me.NumericUpDown_AreaMisalliance, "NumericUpDown_AreaMisalliance")
        Me.NumericUpDown_AreaMisalliance.DecimalPlaces = 2
        Me.NumericUpDown_AreaMisalliance.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.NumericUpDown_AreaMisalliance.Maximum = New Decimal(New Integer() {60000, 0, 0, 0})
        Me.NumericUpDown_AreaMisalliance.Name = "NumericUpDown_AreaMisalliance"
        '
        'Label_Distance
        '
        resources.ApplyResources(Me.Label_Distance, "Label_Distance")
        Me.Label_Distance.Name = "Label_Distance"
        '
        'NumericUpDown_Distance
        '
        resources.ApplyResources(Me.NumericUpDown_Distance, "NumericUpDown_Distance")
        Me.NumericUpDown_Distance.DecimalPlaces = 1
        Me.NumericUpDown_Distance.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_Distance.Name = "NumericUpDown_Distance"
        '
        'NumericUpDown_FalseCount
        '
        resources.ApplyResources(Me.NumericUpDown_FalseCount, "NumericUpDown_FalseCount")
        Me.NumericUpDown_FalseCount.Name = "NumericUpDown_FalseCount"
        '
        'Label_FalseCount
        '
        resources.ApplyResources(Me.Label_FalseCount, "Label_FalseCount")
        Me.Label_FalseCount.Name = "Label_FalseCount"
        '
        'CheckBox_AutoAdd
        '
        resources.ApplyResources(Me.CheckBox_AutoAdd, "CheckBox_AutoAdd")
        Me.CheckBox_AutoAdd.Name = "CheckBox_AutoAdd"
        '
        'Button_Close
        '
        resources.ApplyResources(Me.Button_Close, "Button_Close")
        Me.Button_Close.Name = "Button_Close"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        '
        'FolderBrowserDialog
        '
        resources.ApplyResources(Me.FolderBrowserDialog, "FolderBrowserDialog")
        '
        'TextBox_DataRootPath
        '
        resources.ApplyResources(Me.TextBox_DataRootPath, "TextBox_DataRootPath")
        Me.TextBox_DataRootPath.Name = "TextBox_DataRootPath"
        '
        'Label_DeleteDay
        '
        resources.ApplyResources(Me.Label_DeleteDay, "Label_DeleteDay")
        Me.Label_DeleteDay.Name = "Label_DeleteDay"
        '
        'Label_ImagePath
        '
        resources.ApplyResources(Me.Label_ImagePath, "Label_ImagePath")
        Me.Label_ImagePath.Name = "Label_ImagePath"
        '
        'TabPage_Other
        '
        resources.ApplyResources(Me.TabPage_Other, "TabPage_Other")
        Me.TabPage_Other.Controls.Add(Me.CheckBox_UseSemu)
        Me.TabPage_Other.Controls.Add(Me.Label5)
        Me.TabPage_Other.Controls.Add(Me.ComboBox_RemoveHVSaveType)
        Me.TabPage_Other.Controls.Add(Me.GroupBox_ResizeFullImage)
        Me.TabPage_Other.Controls.Add(Me.Label4)
        Me.TabPage_Other.Controls.Add(Me.Button_ImagePath)
        Me.TabPage_Other.Controls.Add(Me.Label_ImagePath)
        Me.TabPage_Other.Controls.Add(Me.TextBox_DataRootPath)
        Me.TabPage_Other.Controls.Add(Me.Label_DeleteDay)
        Me.TabPage_Other.Controls.Add(Me.NumericUpDown_DeleteDay)
        Me.TabPage_Other.Controls.Add(Me.Label_DeleteScale)
        Me.TabPage_Other.Controls.Add(Me.NumericUpDown_DeleteScale)
        Me.TabPage_Other.Name = "TabPage_Other"
        Me.TabPage_Other.UseVisualStyleBackColor = True
        '
        'CheckBox_UseSemu
        '
        resources.ApplyResources(Me.CheckBox_UseSemu, "CheckBox_UseSemu")
        Me.CheckBox_UseSemu.Name = "CheckBox_UseSemu"
        Me.CheckBox_UseSemu.UseVisualStyleBackColor = True
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'ComboBox_RemoveHVSaveType
        '
        resources.ApplyResources(Me.ComboBox_RemoveHVSaveType, "ComboBox_RemoveHVSaveType")
        Me.ComboBox_RemoveHVSaveType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_RemoveHVSaveType.FormattingEnabled = True
        Me.ComboBox_RemoveHVSaveType.Items.AddRange(New Object() {resources.GetString("ComboBox_RemoveHVSaveType.Items"), resources.GetString("ComboBox_RemoveHVSaveType.Items1"), resources.GetString("ComboBox_RemoveHVSaveType.Items2"), resources.GetString("ComboBox_RemoveHVSaveType.Items3")})
        Me.ComboBox_RemoveHVSaveType.Name = "ComboBox_RemoveHVSaveType"
        '
        'GroupBox_ResizeFullImage
        '
        resources.ApplyResources(Me.GroupBox_ResizeFullImage, "GroupBox_ResizeFullImage")
        Me.GroupBox_ResizeFullImage.Controls.Add(Me.NumericUpDown_ResizeCount)
        Me.GroupBox_ResizeFullImage.Controls.Add(Me.Label1)
        Me.GroupBox_ResizeFullImage.Name = "GroupBox_ResizeFullImage"
        Me.GroupBox_ResizeFullImage.TabStop = False
        '
        'NumericUpDown_ResizeCount
        '
        resources.ApplyResources(Me.NumericUpDown_ResizeCount, "NumericUpDown_ResizeCount")
        Me.NumericUpDown_ResizeCount.Name = "NumericUpDown_ResizeCount"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'Button_ImagePath
        '
        resources.ApplyResources(Me.Button_ImagePath, "Button_ImagePath")
        Me.Button_ImagePath.Name = "Button_ImagePath"
        '
        'NumericUpDown_DeleteDay
        '
        resources.ApplyResources(Me.NumericUpDown_DeleteDay, "NumericUpDown_DeleteDay")
        Me.NumericUpDown_DeleteDay.Name = "NumericUpDown_DeleteDay"
        '
        'Label_DeleteScale
        '
        resources.ApplyResources(Me.Label_DeleteScale, "Label_DeleteScale")
        Me.Label_DeleteScale.Name = "Label_DeleteScale"
        '
        'NumericUpDown_DeleteScale
        '
        resources.ApplyResources(Me.NumericUpDown_DeleteScale, "NumericUpDown_DeleteScale")
        Me.NumericUpDown_DeleteScale.DecimalPlaces = 1
        Me.NumericUpDown_DeleteScale.Name = "NumericUpDown_DeleteScale"
        '
        'ToolStripMenuItem_AddPattern
        '
        resources.ApplyResources(Me.ToolStripMenuItem_AddPattern, "ToolStripMenuItem_AddPattern")
        Me.ToolStripMenuItem_AddPattern.Name = "ToolStripMenuItem_AddPattern"
        Me.ToolStripMenuItem_AddPattern.Tag = "ADD"
        '
        'ToolStripMenuItem_RemovePattern
        '
        resources.ApplyResources(Me.ToolStripMenuItem_RemovePattern, "ToolStripMenuItem_RemovePattern")
        Me.ToolStripMenuItem_RemovePattern.Name = "ToolStripMenuItem_RemovePattern"
        Me.ToolStripMenuItem_RemovePattern.Tag = "REMOVE"
        '
        'ContextMenuStrip_Pattern
        '
        resources.ApplyResources(Me.ContextMenuStrip_Pattern, "ContextMenuStrip_Pattern")
        Me.ContextMenuStrip_Pattern.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem_AddPattern, Me.ToolStripMenuItem_RemovePattern})
        Me.ContextMenuStrip_Pattern.Name = "ContextMenuStrip"
        '
        'TabControl_Setting
        '
        resources.ApplyResources(Me.TabControl_Setting, "TabControl_Setting")
        Me.TabControl_Setting.Controls.Add(Me.TabPage_False)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Pattern)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Other)
        Me.TabControl_Setting.Name = "TabControl_Setting"
        Me.TabControl_Setting.SelectedIndex = 0
        '
        'TabPage_False
        '
        resources.ApplyResources(Me.TabPage_False, "TabPage_False")
        Me.TabPage_False.Controls.Add(Me.GroupBox_MuraFalseDefect)
        Me.TabPage_False.Name = "TabPage_False"
        Me.TabPage_False.UseVisualStyleBackColor = True
        '
        'GroupBox_MuraFalseDefect
        '
        resources.ApplyResources(Me.GroupBox_MuraFalseDefect, "GroupBox_MuraFalseDefect")
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.NumericUpDown_CountToChangeFFC)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.Label29)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.NumericUpDown_FilterBandDistance)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.Label3)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.Label2)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.Label_FalseCount)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.CheckBox_AutoAdd)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.NumericUpDown_FalseCount)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.NumericUpDown_Distance)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.Label_Distance)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.NumericUpDown_AreaMisalliance)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.CheckBox_UseAutoFFC)
        Me.GroupBox_MuraFalseDefect.Controls.Add(Me.Label_AreaMisalliance)
        Me.GroupBox_MuraFalseDefect.Name = "GroupBox_MuraFalseDefect"
        Me.GroupBox_MuraFalseDefect.TabStop = False
        '
        'NumericUpDown_CountToChangeFFC
        '
        resources.ApplyResources(Me.NumericUpDown_CountToChangeFFC, "NumericUpDown_CountToChangeFFC")
        Me.NumericUpDown_CountToChangeFFC.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_CountToChangeFFC.Name = "NumericUpDown_CountToChangeFFC"
        '
        'Label29
        '
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Name = "Label29"
        '
        'NumericUpDown_FilterBandDistance
        '
        resources.ApplyResources(Me.NumericUpDown_FilterBandDistance, "NumericUpDown_FilterBandDistance")
        Me.NumericUpDown_FilterBandDistance.DecimalPlaces = 1
        Me.NumericUpDown_FilterBandDistance.Name = "NumericUpDown_FilterBandDistance"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'Dialog_MuraSettingBase
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.TabControl_Setting)
        Me.Controls.Add(Me.Button_Close)
        Me.Controls.Add(Me.Button_Save)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_MuraSettingBase"
        Me.ShowInTaskbar = False
        Me.TabPage_Pattern.ResumeLayout(False)
        CType(Me.NumericUpDown_AreaMisalliance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Distance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_FalseCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Other.ResumeLayout(False)
        Me.TabPage_Other.PerformLayout()
        Me.GroupBox_ResizeFullImage.ResumeLayout(False)
        Me.GroupBox_ResizeFullImage.PerformLayout()
        CType(Me.NumericUpDown_ResizeCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DeleteDay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DeleteScale, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip_Pattern.ResumeLayout(False)
        Me.TabControl_Setting.ResumeLayout(False)
        Me.TabPage_False.ResumeLayout(False)
        Me.GroupBox_MuraFalseDefect.ResumeLayout(False)
        Me.GroupBox_MuraFalseDefect.PerformLayout()
        CType(Me.NumericUpDown_CountToChangeFFC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_FilterBandDistance, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ListView_Pattern As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents TabPage_Pattern As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox_UseAutoFFC As System.Windows.Forms.CheckBox
    Friend WithEvents Label_AreaMisalliance As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AreaMisalliance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Distance As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Distance As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_FalseCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_FalseCount As System.Windows.Forms.Label
    Friend WithEvents CheckBox_AutoAdd As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents FolderBrowserDialog As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents TextBox_DataRootPath As System.Windows.Forms.TextBox
    Friend WithEvents Label_DeleteDay As System.Windows.Forms.Label
    Friend WithEvents Label_ImagePath As System.Windows.Forms.Label
    Friend WithEvents TabPage_Other As System.Windows.Forms.TabPage
    Friend WithEvents Button_ImagePath As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_DeleteDay As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_DeleteScale As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_DeleteScale As System.Windows.Forms.NumericUpDown
    Friend WithEvents ToolStripMenuItem_AddPattern As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_RemovePattern As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip_Pattern As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents TabControl_Setting As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_False As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_MuraFalseDefect As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_FilterBandDistance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_CountToChangeFFC As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_ResizeFullImage As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_ResizeCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_RemoveHVSaveType As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_UseSemu As System.Windows.Forms.CheckBox
End Class
