﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_Align
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_Align))
        Me.TabControl_AlignSetting = New System.Windows.Forms.TabControl()
        Me.TabPage_ROI = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label_LeftDown = New System.Windows.Forms.Label()
        Me.Label_RightDown = New System.Windows.Forms.Label()
        Me.Label_RightUp = New System.Windows.Forms.Label()
        Me.Label_LeftUp = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CheckBox_SideViewAlign = New System.Windows.Forms.CheckBox()
        Me.Button_Set_SideView_Position = New System.Windows.Forms.Button()
        Me.GroupBox_BoundaryModify = New System.Windows.Forms.GroupBox()
        Me.Button_Quick_Edge = New System.Windows.Forms.Button()
        Me.RadioButton_BoundaryManual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BoundaryFinish = New System.Windows.Forms.RadioButton()
        Me.CheckBox_ShowBoundary = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Boundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BoundaryRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryTop = New System.Windows.Forms.Label()
        Me.TabPage_Alignment = New System.Windows.Forms.TabPage()
        Me.RadioButton_AlignType_Dot = New System.Windows.Forms.RadioButton()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_ShiftOffset_Top = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_ShiftOffset_Left = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Func_RightAnalysis = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Func_TopAnalysis = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Func_BottomAnalysis = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_ShiftOffset_Bottom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_ShiftOffset_Right = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Func_LeftAnalysis = New System.Windows.Forms.CheckBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.RadioButton_AlignType_Circle = New System.Windows.Forms.RadioButton()
        Me.RadioButton_AlignType_Rectangle = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Alignment = New System.Windows.Forms.GroupBox()
        Me.CheckBox_EnhanceEdge = New System.Windows.Forms.CheckBox()
        Me.ComboBox_RotateTheta = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button_Alignment = New System.Windows.Forms.Button()
        Me.NumericUpDown_AlignTolerance = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_RotateCal = New System.Windows.Forms.CheckBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AlignmentShift = New System.Windows.Forms.NumericUpDown()
        Me.Label_Alignment = New System.Windows.Forms.Label()
        Me.GroupBox_PanelRotate = New System.Windows.Forms.GroupBox()
        Me.CheckBox_PanelMirror = New System.Windows.Forms.CheckBox()
        Me.CheckBox_PanelRotate = New System.Windows.Forms.CheckBox()
        Me.Label_Standard = New System.Windows.Forms.Label()
        Me.TabPage_ImageCalibration = New System.Windows.Forms.TabPage()
        Me.CheckBox_UseAlignPattern = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Calibration_Grid_Setting = New System.Windows.Forms.GroupBox()
        Me.CheckBox_MultiAngle = New System.Windows.Forms.CheckBox()
        Me.ComboBox_MultiAngle = New System.Windows.Forms.ComboBox()
        Me.NumericUpDown_CalibrationGrid_Y_Tolerance = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumericUpDown_CalibrationGrid_X_Tolerance = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Button_Correct_Distortion = New System.Windows.Forms.Button()
        Me.Button_Calculate_Grid_Angle = New System.Windows.Forms.Button()
        Me.Label_Grid_Calibration_Info = New System.Windows.Forms.Label()
        Me.Button_Calculate_Grid_Calibration = New System.Windows.Forms.Button()
        Me.NumericUpDown_CalibrationGrid_Row_Num = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_CalibrationGrid_Column_Num = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabPage_PositionTransfer = New System.Windows.Forms.TabPage()
        Me.GroupBox_MT = New System.Windows.Forms.GroupBox()
        Me.Rdb_ScabType_MT = New System.Windows.Forms.RadioButton()
        Me.Rdb_ScabType_Linear = New System.Windows.Forms.RadioButton()
        Me.GroupBox_TableModify = New System.Windows.Forms.GroupBox()
        Me.GroupBox_Local = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_LocalRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_LocalLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_LocalTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_LocalBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_LocalTop = New System.Windows.Forms.Label()
        Me.CheckBox_ShowTable = New System.Windows.Forms.CheckBox()
        Me.RadioButton_TableManual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_TableFinish = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Table = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_TableRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_TableRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_TableLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_TableLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_TableTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_TableBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_TableBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_TableTop = New System.Windows.Forms.Label()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.Button_LoadImage = New System.Windows.Forms.Button()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.TabControl_AlignSetting.SuspendLayout()
        Me.TabPage_ROI.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox_BoundaryModify.SuspendLayout()
        Me.GroupBox_Boundary.SuspendLayout()
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Alignment.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NumericUpDown_ShiftOffset_Top, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ShiftOffset_Left, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ShiftOffset_Bottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ShiftOffset_Right, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Alignment.SuspendLayout()
        CType(Me.NumericUpDown_AlignTolerance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AlignmentShift, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PanelRotate.SuspendLayout()
        Me.TabPage_ImageCalibration.SuspendLayout()
        Me.GroupBox_Calibration_Grid_Setting.SuspendLayout()
        CType(Me.NumericUpDown_CalibrationGrid_Y_Tolerance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_CalibrationGrid_X_Tolerance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_CalibrationGrid_Row_Num, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_CalibrationGrid_Column_Num, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_PositionTransfer.SuspendLayout()
        Me.GroupBox_MT.SuspendLayout()
        Me.GroupBox_TableModify.SuspendLayout()
        Me.GroupBox_Local.SuspendLayout()
        CType(Me.NumericUpDown_LocalRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LocalLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LocalTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LocalBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Table.SuspendLayout()
        CType(Me.NumericUpDown_TableRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_TableLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_TableTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_TableBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl_AlignSetting
        '
        resources.ApplyResources(Me.TabControl_AlignSetting, "TabControl_AlignSetting")
        Me.TabControl_AlignSetting.Controls.Add(Me.TabPage_ROI)
        Me.TabControl_AlignSetting.Controls.Add(Me.TabPage_Alignment)
        Me.TabControl_AlignSetting.Controls.Add(Me.TabPage_ImageCalibration)
        Me.TabControl_AlignSetting.Controls.Add(Me.TabPage_PositionTransfer)
        Me.TabControl_AlignSetting.Name = "TabControl_AlignSetting"
        Me.TabControl_AlignSetting.SelectedIndex = 0
        '
        'TabPage_ROI
        '
        resources.ApplyResources(Me.TabPage_ROI, "TabPage_ROI")
        Me.TabPage_ROI.Controls.Add(Me.GroupBox1)
        Me.TabPage_ROI.Controls.Add(Me.GroupBox_BoundaryModify)
        Me.TabPage_ROI.Name = "TabPage_ROI"
        Me.TabPage_ROI.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.Label_LeftDown)
        Me.GroupBox1.Controls.Add(Me.Label_RightDown)
        Me.GroupBox1.Controls.Add(Me.Label_RightUp)
        Me.GroupBox1.Controls.Add(Me.Label_LeftUp)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Controls.Add(Me.CheckBox_SideViewAlign)
        Me.GroupBox1.Controls.Add(Me.Button_Set_SideView_Position)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'Label_LeftDown
        '
        resources.ApplyResources(Me.Label_LeftDown, "Label_LeftDown")
        Me.Label_LeftDown.Name = "Label_LeftDown"
        '
        'Label_RightDown
        '
        resources.ApplyResources(Me.Label_RightDown, "Label_RightDown")
        Me.Label_RightDown.Name = "Label_RightDown"
        '
        'Label_RightUp
        '
        resources.ApplyResources(Me.Label_RightUp, "Label_RightUp")
        Me.Label_RightUp.Name = "Label_RightUp"
        '
        'Label_LeftUp
        '
        resources.ApplyResources(Me.Label_LeftUp, "Label_LeftUp")
        Me.Label_LeftUp.Name = "Label_LeftUp"
        '
        'Panel1
        '
        resources.ApplyResources(Me.Panel1, "Panel1")
        Me.Panel1.BackColor = System.Drawing.Color.Gray
        Me.Panel1.Name = "Panel1"
        '
        'CheckBox_SideViewAlign
        '
        resources.ApplyResources(Me.CheckBox_SideViewAlign, "CheckBox_SideViewAlign")
        Me.CheckBox_SideViewAlign.Checked = True
        Me.CheckBox_SideViewAlign.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_SideViewAlign.Name = "CheckBox_SideViewAlign"
        Me.CheckBox_SideViewAlign.UseVisualStyleBackColor = True
        '
        'Button_Set_SideView_Position
        '
        resources.ApplyResources(Me.Button_Set_SideView_Position, "Button_Set_SideView_Position")
        Me.Button_Set_SideView_Position.Name = "Button_Set_SideView_Position"
        Me.Button_Set_SideView_Position.UseVisualStyleBackColor = True
        '
        'GroupBox_BoundaryModify
        '
        resources.ApplyResources(Me.GroupBox_BoundaryModify, "GroupBox_BoundaryModify")
        Me.GroupBox_BoundaryModify.Controls.Add(Me.Button_Quick_Edge)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryManual)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryFinish)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.CheckBox_ShowBoundary)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.GroupBox_Boundary)
        Me.GroupBox_BoundaryModify.Name = "GroupBox_BoundaryModify"
        Me.GroupBox_BoundaryModify.TabStop = False
        '
        'Button_Quick_Edge
        '
        resources.ApplyResources(Me.Button_Quick_Edge, "Button_Quick_Edge")
        Me.Button_Quick_Edge.Name = "Button_Quick_Edge"
        Me.Button_Quick_Edge.UseVisualStyleBackColor = True
        '
        'RadioButton_BoundaryManual
        '
        resources.ApplyResources(Me.RadioButton_BoundaryManual, "RadioButton_BoundaryManual")
        Me.RadioButton_BoundaryManual.Name = "RadioButton_BoundaryManual"
        '
        'RadioButton_BoundaryFinish
        '
        resources.ApplyResources(Me.RadioButton_BoundaryFinish, "RadioButton_BoundaryFinish")
        Me.RadioButton_BoundaryFinish.Name = "RadioButton_BoundaryFinish"
        '
        'CheckBox_ShowBoundary
        '
        resources.ApplyResources(Me.CheckBox_ShowBoundary, "CheckBox_ShowBoundary")
        Me.CheckBox_ShowBoundary.Name = "CheckBox_ShowBoundary"
        '
        'GroupBox_Boundary
        '
        resources.ApplyResources(Me.GroupBox_Boundary, "GroupBox_Boundary")
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryTop)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryTop)
        Me.GroupBox_Boundary.Name = "GroupBox_Boundary"
        Me.GroupBox_Boundary.TabStop = False
        '
        'NumericUpDown_BoundaryRight
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryRight, "NumericUpDown_BoundaryRight")
        Me.NumericUpDown_BoundaryRight.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryRight.Name = "NumericUpDown_BoundaryRight"
        '
        'Label_BoundaryRight
        '
        resources.ApplyResources(Me.Label_BoundaryRight, "Label_BoundaryRight")
        Me.Label_BoundaryRight.Name = "Label_BoundaryRight"
        '
        'NumericUpDown_BoundaryLeft
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryLeft, "NumericUpDown_BoundaryLeft")
        Me.NumericUpDown_BoundaryLeft.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BoundaryLeft.Name = "NumericUpDown_BoundaryLeft"
        '
        'Label_BoundaryLeft
        '
        resources.ApplyResources(Me.Label_BoundaryLeft, "Label_BoundaryLeft")
        Me.Label_BoundaryLeft.Name = "Label_BoundaryLeft"
        '
        'NumericUpDown_BoundaryTop
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryTop, "NumericUpDown_BoundaryTop")
        Me.NumericUpDown_BoundaryTop.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BoundaryTop.Name = "NumericUpDown_BoundaryTop"
        '
        'Label_BoundaryBottom
        '
        resources.ApplyResources(Me.Label_BoundaryBottom, "Label_BoundaryBottom")
        Me.Label_BoundaryBottom.Name = "Label_BoundaryBottom"
        '
        'NumericUpDown_BoundaryBottom
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryBottom, "NumericUpDown_BoundaryBottom")
        Me.NumericUpDown_BoundaryBottom.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown_BoundaryBottom.Name = "NumericUpDown_BoundaryBottom"
        '
        'Label_BoundaryTop
        '
        resources.ApplyResources(Me.Label_BoundaryTop, "Label_BoundaryTop")
        Me.Label_BoundaryTop.Name = "Label_BoundaryTop"
        '
        'TabPage_Alignment
        '
        resources.ApplyResources(Me.TabPage_Alignment, "TabPage_Alignment")
        Me.TabPage_Alignment.Controls.Add(Me.RadioButton_AlignType_Dot)
        Me.TabPage_Alignment.Controls.Add(Me.GroupBox2)
        Me.TabPage_Alignment.Controls.Add(Me.Label6)
        Me.TabPage_Alignment.Controls.Add(Me.RadioButton_AlignType_Circle)
        Me.TabPage_Alignment.Controls.Add(Me.RadioButton_AlignType_Rectangle)
        Me.TabPage_Alignment.Controls.Add(Me.GroupBox_Alignment)
        Me.TabPage_Alignment.Controls.Add(Me.Label_Alignment)
        Me.TabPage_Alignment.Controls.Add(Me.GroupBox_PanelRotate)
        Me.TabPage_Alignment.Controls.Add(Me.Label_Standard)
        Me.TabPage_Alignment.Name = "TabPage_Alignment"
        Me.TabPage_Alignment.UseVisualStyleBackColor = True
        '
        'RadioButton_AlignType_Dot
        '
        resources.ApplyResources(Me.RadioButton_AlignType_Dot, "RadioButton_AlignType_Dot")
        Me.RadioButton_AlignType_Dot.Name = "RadioButton_AlignType_Dot"
        Me.RadioButton_AlignType_Dot.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_ShiftOffset_Top)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_ShiftOffset_Left)
        Me.GroupBox2.Controls.Add(Me.CheckBox_Func_RightAnalysis)
        Me.GroupBox2.Controls.Add(Me.CheckBox_Func_TopAnalysis)
        Me.GroupBox2.Controls.Add(Me.CheckBox_Func_BottomAnalysis)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_ShiftOffset_Bottom)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_ShiftOffset_Right)
        Me.GroupBox2.Controls.Add(Me.CheckBox_Func_LeftAnalysis)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'NumericUpDown_ShiftOffset_Top
        '
        resources.ApplyResources(Me.NumericUpDown_ShiftOffset_Top, "NumericUpDown_ShiftOffset_Top")
        Me.NumericUpDown_ShiftOffset_Top.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Top.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Top.Name = "NumericUpDown_ShiftOffset_Top"
        '
        'NumericUpDown_ShiftOffset_Left
        '
        resources.ApplyResources(Me.NumericUpDown_ShiftOffset_Left, "NumericUpDown_ShiftOffset_Left")
        Me.NumericUpDown_ShiftOffset_Left.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Left.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Left.Name = "NumericUpDown_ShiftOffset_Left"
        '
        'CheckBox_Func_RightAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_RightAnalysis, "CheckBox_Func_RightAnalysis")
        Me.CheckBox_Func_RightAnalysis.Name = "CheckBox_Func_RightAnalysis"
        Me.CheckBox_Func_RightAnalysis.UseVisualStyleBackColor = True
        '
        'CheckBox_Func_TopAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_TopAnalysis, "CheckBox_Func_TopAnalysis")
        Me.CheckBox_Func_TopAnalysis.Name = "CheckBox_Func_TopAnalysis"
        Me.CheckBox_Func_TopAnalysis.UseVisualStyleBackColor = True
        '
        'CheckBox_Func_BottomAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_BottomAnalysis, "CheckBox_Func_BottomAnalysis")
        Me.CheckBox_Func_BottomAnalysis.Name = "CheckBox_Func_BottomAnalysis"
        Me.CheckBox_Func_BottomAnalysis.UseVisualStyleBackColor = True
        '
        'NumericUpDown_ShiftOffset_Bottom
        '
        resources.ApplyResources(Me.NumericUpDown_ShiftOffset_Bottom, "NumericUpDown_ShiftOffset_Bottom")
        Me.NumericUpDown_ShiftOffset_Bottom.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Bottom.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Bottom.Name = "NumericUpDown_ShiftOffset_Bottom"
        '
        'NumericUpDown_ShiftOffset_Right
        '
        resources.ApplyResources(Me.NumericUpDown_ShiftOffset_Right, "NumericUpDown_ShiftOffset_Right")
        Me.NumericUpDown_ShiftOffset_Right.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_ShiftOffset_Right.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_ShiftOffset_Right.Name = "NumericUpDown_ShiftOffset_Right"
        '
        'CheckBox_Func_LeftAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_LeftAnalysis, "CheckBox_Func_LeftAnalysis")
        Me.CheckBox_Func_LeftAnalysis.Name = "CheckBox_Func_LeftAnalysis"
        Me.CheckBox_Func_LeftAnalysis.UseVisualStyleBackColor = True
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'RadioButton_AlignType_Circle
        '
        resources.ApplyResources(Me.RadioButton_AlignType_Circle, "RadioButton_AlignType_Circle")
        Me.RadioButton_AlignType_Circle.Name = "RadioButton_AlignType_Circle"
        Me.RadioButton_AlignType_Circle.UseVisualStyleBackColor = True
        '
        'RadioButton_AlignType_Rectangle
        '
        resources.ApplyResources(Me.RadioButton_AlignType_Rectangle, "RadioButton_AlignType_Rectangle")
        Me.RadioButton_AlignType_Rectangle.Checked = True
        Me.RadioButton_AlignType_Rectangle.Name = "RadioButton_AlignType_Rectangle"
        Me.RadioButton_AlignType_Rectangle.TabStop = True
        Me.RadioButton_AlignType_Rectangle.UseVisualStyleBackColor = True
        '
        'GroupBox_Alignment
        '
        resources.ApplyResources(Me.GroupBox_Alignment, "GroupBox_Alignment")
        Me.GroupBox_Alignment.Controls.Add(Me.CheckBox_EnhanceEdge)
        Me.GroupBox_Alignment.Controls.Add(Me.ComboBox_RotateTheta)
        Me.GroupBox_Alignment.Controls.Add(Me.Label1)
        Me.GroupBox_Alignment.Controls.Add(Me.Button_Alignment)
        Me.GroupBox_Alignment.Controls.Add(Me.NumericUpDown_AlignTolerance)
        Me.GroupBox_Alignment.Controls.Add(Me.CheckBox_RotateCal)
        Me.GroupBox_Alignment.Controls.Add(Me.Label12)
        Me.GroupBox_Alignment.Controls.Add(Me.NumericUpDown_AlignmentShift)
        Me.GroupBox_Alignment.Name = "GroupBox_Alignment"
        Me.GroupBox_Alignment.TabStop = False
        '
        'CheckBox_EnhanceEdge
        '
        resources.ApplyResources(Me.CheckBox_EnhanceEdge, "CheckBox_EnhanceEdge")
        Me.CheckBox_EnhanceEdge.Name = "CheckBox_EnhanceEdge"
        Me.CheckBox_EnhanceEdge.UseVisualStyleBackColor = True
        '
        'ComboBox_RotateTheta
        '
        resources.ApplyResources(Me.ComboBox_RotateTheta, "ComboBox_RotateTheta")
        Me.ComboBox_RotateTheta.FormattingEnabled = True
        Me.ComboBox_RotateTheta.Items.AddRange(New Object() {resources.GetString("ComboBox_RotateTheta.Items"), resources.GetString("ComboBox_RotateTheta.Items1"), resources.GetString("ComboBox_RotateTheta.Items2"), resources.GetString("ComboBox_RotateTheta.Items3"), resources.GetString("ComboBox_RotateTheta.Items4")})
        Me.ComboBox_RotateTheta.Name = "ComboBox_RotateTheta"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Button_Alignment
        '
        resources.ApplyResources(Me.Button_Alignment, "Button_Alignment")
        Me.Button_Alignment.Name = "Button_Alignment"
        Me.Button_Alignment.UseVisualStyleBackColor = True
        '
        'NumericUpDown_AlignTolerance
        '
        resources.ApplyResources(Me.NumericUpDown_AlignTolerance, "NumericUpDown_AlignTolerance")
        Me.NumericUpDown_AlignTolerance.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_AlignTolerance.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_AlignTolerance.Name = "NumericUpDown_AlignTolerance"
        Me.NumericUpDown_AlignTolerance.Value = New Decimal(New Integer() {40, 0, 0, 0})
        '
        'CheckBox_RotateCal
        '
        resources.ApplyResources(Me.CheckBox_RotateCal, "CheckBox_RotateCal")
        Me.CheckBox_RotateCal.Name = "CheckBox_RotateCal"
        Me.CheckBox_RotateCal.UseVisualStyleBackColor = True
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'NumericUpDown_AlignmentShift
        '
        resources.ApplyResources(Me.NumericUpDown_AlignmentShift, "NumericUpDown_AlignmentShift")
        Me.NumericUpDown_AlignmentShift.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_AlignmentShift.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_AlignmentShift.Name = "NumericUpDown_AlignmentShift"
        '
        'Label_Alignment
        '
        resources.ApplyResources(Me.Label_Alignment, "Label_Alignment")
        Me.Label_Alignment.Name = "Label_Alignment"
        '
        'GroupBox_PanelRotate
        '
        resources.ApplyResources(Me.GroupBox_PanelRotate, "GroupBox_PanelRotate")
        Me.GroupBox_PanelRotate.Controls.Add(Me.CheckBox_PanelMirror)
        Me.GroupBox_PanelRotate.Controls.Add(Me.CheckBox_PanelRotate)
        Me.GroupBox_PanelRotate.Name = "GroupBox_PanelRotate"
        Me.GroupBox_PanelRotate.TabStop = False
        '
        'CheckBox_PanelMirror
        '
        resources.ApplyResources(Me.CheckBox_PanelMirror, "CheckBox_PanelMirror")
        Me.CheckBox_PanelMirror.Name = "CheckBox_PanelMirror"
        Me.CheckBox_PanelMirror.UseVisualStyleBackColor = True
        '
        'CheckBox_PanelRotate
        '
        resources.ApplyResources(Me.CheckBox_PanelRotate, "CheckBox_PanelRotate")
        Me.CheckBox_PanelRotate.Name = "CheckBox_PanelRotate"
        Me.CheckBox_PanelRotate.UseVisualStyleBackColor = True
        '
        'Label_Standard
        '
        resources.ApplyResources(Me.Label_Standard, "Label_Standard")
        Me.Label_Standard.Name = "Label_Standard"
        '
        'TabPage_ImageCalibration
        '
        resources.ApplyResources(Me.TabPage_ImageCalibration, "TabPage_ImageCalibration")
        Me.TabPage_ImageCalibration.Controls.Add(Me.CheckBox_UseAlignPattern)
        Me.TabPage_ImageCalibration.Controls.Add(Me.GroupBox_Calibration_Grid_Setting)
        Me.TabPage_ImageCalibration.Name = "TabPage_ImageCalibration"
        Me.TabPage_ImageCalibration.UseVisualStyleBackColor = True
        '
        'CheckBox_UseAlignPattern
        '
        resources.ApplyResources(Me.CheckBox_UseAlignPattern, "CheckBox_UseAlignPattern")
        Me.CheckBox_UseAlignPattern.Name = "CheckBox_UseAlignPattern"
        Me.CheckBox_UseAlignPattern.UseVisualStyleBackColor = True
        '
        'GroupBox_Calibration_Grid_Setting
        '
        resources.ApplyResources(Me.GroupBox_Calibration_Grid_Setting, "GroupBox_Calibration_Grid_Setting")
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.CheckBox_MultiAngle)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.ComboBox_MultiAngle)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.NumericUpDown_CalibrationGrid_Y_Tolerance)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Label5)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.NumericUpDown_CalibrationGrid_X_Tolerance)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Label4)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Button_Correct_Distortion)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Button_Calculate_Grid_Angle)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Label_Grid_Calibration_Info)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Button_Calculate_Grid_Calibration)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.NumericUpDown_CalibrationGrid_Row_Num)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.NumericUpDown_CalibrationGrid_Column_Num)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Label3)
        Me.GroupBox_Calibration_Grid_Setting.Controls.Add(Me.Label2)
        Me.GroupBox_Calibration_Grid_Setting.Name = "GroupBox_Calibration_Grid_Setting"
        Me.GroupBox_Calibration_Grid_Setting.TabStop = False
        '
        'CheckBox_MultiAngle
        '
        resources.ApplyResources(Me.CheckBox_MultiAngle, "CheckBox_MultiAngle")
        Me.CheckBox_MultiAngle.Name = "CheckBox_MultiAngle"
        Me.CheckBox_MultiAngle.UseVisualStyleBackColor = True
        '
        'ComboBox_MultiAngle
        '
        resources.ApplyResources(Me.ComboBox_MultiAngle, "ComboBox_MultiAngle")
        Me.ComboBox_MultiAngle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_MultiAngle.FormattingEnabled = True
        Me.ComboBox_MultiAngle.Items.AddRange(New Object() {resources.GetString("ComboBox_MultiAngle.Items"), resources.GetString("ComboBox_MultiAngle.Items1"), resources.GetString("ComboBox_MultiAngle.Items2"), resources.GetString("ComboBox_MultiAngle.Items3"), resources.GetString("ComboBox_MultiAngle.Items4")})
        Me.ComboBox_MultiAngle.Name = "ComboBox_MultiAngle"
        '
        'NumericUpDown_CalibrationGrid_Y_Tolerance
        '
        resources.ApplyResources(Me.NumericUpDown_CalibrationGrid_Y_Tolerance, "NumericUpDown_CalibrationGrid_Y_Tolerance")
        Me.NumericUpDown_CalibrationGrid_Y_Tolerance.Maximum = New Decimal(New Integer() {9999, 0, 0, 0})
        Me.NumericUpDown_CalibrationGrid_Y_Tolerance.Name = "NumericUpDown_CalibrationGrid_Y_Tolerance"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'NumericUpDown_CalibrationGrid_X_Tolerance
        '
        resources.ApplyResources(Me.NumericUpDown_CalibrationGrid_X_Tolerance, "NumericUpDown_CalibrationGrid_X_Tolerance")
        Me.NumericUpDown_CalibrationGrid_X_Tolerance.Maximum = New Decimal(New Integer() {9999, 0, 0, 0})
        Me.NumericUpDown_CalibrationGrid_X_Tolerance.Name = "NumericUpDown_CalibrationGrid_X_Tolerance"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'Button_Correct_Distortion
        '
        resources.ApplyResources(Me.Button_Correct_Distortion, "Button_Correct_Distortion")
        Me.Button_Correct_Distortion.Name = "Button_Correct_Distortion"
        Me.Button_Correct_Distortion.UseVisualStyleBackColor = True
        '
        'Button_Calculate_Grid_Angle
        '
        resources.ApplyResources(Me.Button_Calculate_Grid_Angle, "Button_Calculate_Grid_Angle")
        Me.Button_Calculate_Grid_Angle.Name = "Button_Calculate_Grid_Angle"
        Me.Button_Calculate_Grid_Angle.UseVisualStyleBackColor = True
        '
        'Label_Grid_Calibration_Info
        '
        resources.ApplyResources(Me.Label_Grid_Calibration_Info, "Label_Grid_Calibration_Info")
        Me.Label_Grid_Calibration_Info.Name = "Label_Grid_Calibration_Info"
        '
        'Button_Calculate_Grid_Calibration
        '
        resources.ApplyResources(Me.Button_Calculate_Grid_Calibration, "Button_Calculate_Grid_Calibration")
        Me.Button_Calculate_Grid_Calibration.Name = "Button_Calculate_Grid_Calibration"
        Me.Button_Calculate_Grid_Calibration.UseVisualStyleBackColor = True
        '
        'NumericUpDown_CalibrationGrid_Row_Num
        '
        resources.ApplyResources(Me.NumericUpDown_CalibrationGrid_Row_Num, "NumericUpDown_CalibrationGrid_Row_Num")
        Me.NumericUpDown_CalibrationGrid_Row_Num.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_CalibrationGrid_Row_Num.Name = "NumericUpDown_CalibrationGrid_Row_Num"
        '
        'NumericUpDown_CalibrationGrid_Column_Num
        '
        resources.ApplyResources(Me.NumericUpDown_CalibrationGrid_Column_Num, "NumericUpDown_CalibrationGrid_Column_Num")
        Me.NumericUpDown_CalibrationGrid_Column_Num.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_CalibrationGrid_Column_Num.Name = "NumericUpDown_CalibrationGrid_Column_Num"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'TabPage_PositionTransfer
        '
        resources.ApplyResources(Me.TabPage_PositionTransfer, "TabPage_PositionTransfer")
        Me.TabPage_PositionTransfer.Controls.Add(Me.GroupBox_MT)
        Me.TabPage_PositionTransfer.Controls.Add(Me.GroupBox_TableModify)
        Me.TabPage_PositionTransfer.Name = "TabPage_PositionTransfer"
        Me.TabPage_PositionTransfer.UseVisualStyleBackColor = True
        '
        'GroupBox_MT
        '
        resources.ApplyResources(Me.GroupBox_MT, "GroupBox_MT")
        Me.GroupBox_MT.Controls.Add(Me.Rdb_ScabType_MT)
        Me.GroupBox_MT.Controls.Add(Me.Rdb_ScabType_Linear)
        Me.GroupBox_MT.Name = "GroupBox_MT"
        Me.GroupBox_MT.TabStop = False
        '
        'Rdb_ScabType_MT
        '
        resources.ApplyResources(Me.Rdb_ScabType_MT, "Rdb_ScabType_MT")
        Me.Rdb_ScabType_MT.Checked = True
        Me.Rdb_ScabType_MT.Name = "Rdb_ScabType_MT"
        Me.Rdb_ScabType_MT.TabStop = True
        Me.Rdb_ScabType_MT.UseVisualStyleBackColor = True
        '
        'Rdb_ScabType_Linear
        '
        resources.ApplyResources(Me.Rdb_ScabType_Linear, "Rdb_ScabType_Linear")
        Me.Rdb_ScabType_Linear.Name = "Rdb_ScabType_Linear"
        Me.Rdb_ScabType_Linear.TabStop = True
        Me.Rdb_ScabType_Linear.UseVisualStyleBackColor = True
        '
        'GroupBox_TableModify
        '
        resources.ApplyResources(Me.GroupBox_TableModify, "GroupBox_TableModify")
        Me.GroupBox_TableModify.Controls.Add(Me.GroupBox_Local)
        Me.GroupBox_TableModify.Controls.Add(Me.CheckBox_ShowTable)
        Me.GroupBox_TableModify.Controls.Add(Me.RadioButton_TableManual)
        Me.GroupBox_TableModify.Controls.Add(Me.RadioButton_TableFinish)
        Me.GroupBox_TableModify.Controls.Add(Me.GroupBox_Table)
        Me.GroupBox_TableModify.Name = "GroupBox_TableModify"
        Me.GroupBox_TableModify.TabStop = False
        '
        'GroupBox_Local
        '
        resources.ApplyResources(Me.GroupBox_Local, "GroupBox_Local")
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalRight)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalRight)
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalLeft)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalLeft)
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalTop)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalBottom)
        Me.GroupBox_Local.Controls.Add(Me.NumericUpDown_LocalBottom)
        Me.GroupBox_Local.Controls.Add(Me.Label_LocalTop)
        Me.GroupBox_Local.Name = "GroupBox_Local"
        Me.GroupBox_Local.TabStop = False
        '
        'NumericUpDown_LocalRight
        '
        resources.ApplyResources(Me.NumericUpDown_LocalRight, "NumericUpDown_LocalRight")
        Me.NumericUpDown_LocalRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalRight.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalRight.Name = "NumericUpDown_LocalRight"
        Me.NumericUpDown_LocalRight.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalRight
        '
        resources.ApplyResources(Me.Label_LocalRight, "Label_LocalRight")
        Me.Label_LocalRight.Name = "Label_LocalRight"
        '
        'NumericUpDown_LocalLeft
        '
        resources.ApplyResources(Me.NumericUpDown_LocalLeft, "NumericUpDown_LocalLeft")
        Me.NumericUpDown_LocalLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalLeft.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalLeft.Name = "NumericUpDown_LocalLeft"
        Me.NumericUpDown_LocalLeft.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalLeft
        '
        resources.ApplyResources(Me.Label_LocalLeft, "Label_LocalLeft")
        Me.Label_LocalLeft.Name = "Label_LocalLeft"
        '
        'NumericUpDown_LocalTop
        '
        resources.ApplyResources(Me.NumericUpDown_LocalTop, "NumericUpDown_LocalTop")
        Me.NumericUpDown_LocalTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalTop.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalTop.Name = "NumericUpDown_LocalTop"
        Me.NumericUpDown_LocalTop.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalBottom
        '
        resources.ApplyResources(Me.Label_LocalBottom, "Label_LocalBottom")
        Me.Label_LocalBottom.Name = "Label_LocalBottom"
        '
        'NumericUpDown_LocalBottom
        '
        resources.ApplyResources(Me.NumericUpDown_LocalBottom, "NumericUpDown_LocalBottom")
        Me.NumericUpDown_LocalBottom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_LocalBottom.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LocalBottom.Name = "NumericUpDown_LocalBottom"
        Me.NumericUpDown_LocalBottom.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_LocalTop
        '
        resources.ApplyResources(Me.Label_LocalTop, "Label_LocalTop")
        Me.Label_LocalTop.Name = "Label_LocalTop"
        '
        'CheckBox_ShowTable
        '
        resources.ApplyResources(Me.CheckBox_ShowTable, "CheckBox_ShowTable")
        Me.CheckBox_ShowTable.Name = "CheckBox_ShowTable"
        '
        'RadioButton_TableManual
        '
        resources.ApplyResources(Me.RadioButton_TableManual, "RadioButton_TableManual")
        Me.RadioButton_TableManual.Name = "RadioButton_TableManual"
        '
        'RadioButton_TableFinish
        '
        resources.ApplyResources(Me.RadioButton_TableFinish, "RadioButton_TableFinish")
        Me.RadioButton_TableFinish.Name = "RadioButton_TableFinish"
        '
        'GroupBox_Table
        '
        resources.ApplyResources(Me.GroupBox_Table, "GroupBox_Table")
        Me.GroupBox_Table.Controls.Add(Me.NumericUpDown_TableRight)
        Me.GroupBox_Table.Controls.Add(Me.Label_TableRight)
        Me.GroupBox_Table.Controls.Add(Me.NumericUpDown_TableLeft)
        Me.GroupBox_Table.Controls.Add(Me.Label_TableLeft)
        Me.GroupBox_Table.Controls.Add(Me.NumericUpDown_TableTop)
        Me.GroupBox_Table.Controls.Add(Me.Label_TableBottom)
        Me.GroupBox_Table.Controls.Add(Me.NumericUpDown_TableBottom)
        Me.GroupBox_Table.Controls.Add(Me.Label_TableTop)
        Me.GroupBox_Table.Name = "GroupBox_Table"
        Me.GroupBox_Table.TabStop = False
        '
        'NumericUpDown_TableRight
        '
        resources.ApplyResources(Me.NumericUpDown_TableRight, "NumericUpDown_TableRight")
        Me.NumericUpDown_TableRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TableRight.Name = "NumericUpDown_TableRight"
        '
        'Label_TableRight
        '
        resources.ApplyResources(Me.Label_TableRight, "Label_TableRight")
        Me.Label_TableRight.Name = "Label_TableRight"
        '
        'NumericUpDown_TableLeft
        '
        resources.ApplyResources(Me.NumericUpDown_TableLeft, "NumericUpDown_TableLeft")
        Me.NumericUpDown_TableLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TableLeft.Name = "NumericUpDown_TableLeft"
        '
        'Label_TableLeft
        '
        resources.ApplyResources(Me.Label_TableLeft, "Label_TableLeft")
        Me.Label_TableLeft.Name = "Label_TableLeft"
        '
        'NumericUpDown_TableTop
        '
        resources.ApplyResources(Me.NumericUpDown_TableTop, "NumericUpDown_TableTop")
        Me.NumericUpDown_TableTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TableTop.Name = "NumericUpDown_TableTop"
        '
        'Label_TableBottom
        '
        resources.ApplyResources(Me.Label_TableBottom, "Label_TableBottom")
        Me.Label_TableBottom.Name = "Label_TableBottom"
        '
        'NumericUpDown_TableBottom
        '
        resources.ApplyResources(Me.NumericUpDown_TableBottom, "NumericUpDown_TableBottom")
        Me.NumericUpDown_TableBottom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TableBottom.Name = "NumericUpDown_TableBottom"
        '
        'Label_TableTop
        '
        resources.ApplyResources(Me.Label_TableTop, "Label_TableTop")
        Me.Label_TableTop.Name = "Label_TableTop"
        '
        'Button_Close
        '
        resources.ApplyResources(Me.Button_Close, "Button_Close")
        Me.Button_Close.Name = "Button_Close"
        Me.Button_Close.UseVisualStyleBackColor = True
        '
        'Button_LoadImage
        '
        resources.ApplyResources(Me.Button_LoadImage, "Button_LoadImage")
        Me.Button_LoadImage.Name = "Button_LoadImage"
        Me.Button_LoadImage.UseVisualStyleBackColor = True
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        '
        'Dialog_Align
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Button_Close)
        Me.Controls.Add(Me.Button_LoadImage)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.TabControl_AlignSetting)
        Me.Name = "Dialog_Align"
        Me.TabControl_AlignSetting.ResumeLayout(False)
        Me.TabPage_ROI.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox_BoundaryModify.ResumeLayout(False)
        Me.GroupBox_Boundary.ResumeLayout(False)
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Alignment.ResumeLayout(False)
        Me.TabPage_Alignment.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NumericUpDown_ShiftOffset_Top, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ShiftOffset_Left, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ShiftOffset_Bottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ShiftOffset_Right, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Alignment.ResumeLayout(False)
        Me.GroupBox_Alignment.PerformLayout()
        CType(Me.NumericUpDown_AlignTolerance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AlignmentShift, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PanelRotate.ResumeLayout(False)
        Me.GroupBox_PanelRotate.PerformLayout()
        Me.TabPage_ImageCalibration.ResumeLayout(False)
        Me.TabPage_ImageCalibration.PerformLayout()
        Me.GroupBox_Calibration_Grid_Setting.ResumeLayout(False)
        Me.GroupBox_Calibration_Grid_Setting.PerformLayout()
        CType(Me.NumericUpDown_CalibrationGrid_Y_Tolerance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_CalibrationGrid_X_Tolerance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_CalibrationGrid_Row_Num, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_CalibrationGrid_Column_Num, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_PositionTransfer.ResumeLayout(False)
        Me.GroupBox_MT.ResumeLayout(False)
        Me.GroupBox_MT.PerformLayout()
        Me.GroupBox_TableModify.ResumeLayout(False)
        Me.GroupBox_Local.ResumeLayout(False)
        CType(Me.NumericUpDown_LocalRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LocalLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LocalTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LocalBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Table.ResumeLayout(False)
        CType(Me.NumericUpDown_TableRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_TableLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_TableTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_TableBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl_AlignSetting As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_ROI As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_BoundaryModify As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BoundaryManual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BoundaryFinish As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_ShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Boundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BoundaryRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryTop As System.Windows.Forms.Label
    Friend WithEvents TabPage_Alignment As System.Windows.Forms.TabPage
    Friend WithEvents RadioButton_AlignType_Circle As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_AlignType_Rectangle As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_ShiftOffset_Top As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_ShiftOffset_Left As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_ShiftOffset_Bottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_ShiftOffset_Right As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Func_RightAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_BottomAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_LeftAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_TopAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Alignment As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_RotateTheta As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_RotateCal As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_EnhanceEdge As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button_Alignment As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_AlignTolerance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AlignmentShift As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Alignment As System.Windows.Forms.Label
    Friend WithEvents GroupBox_PanelRotate As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_PanelRotate As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Standard As System.Windows.Forms.Label
    Friend WithEvents TabPage_PositionTransfer As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_TableModify As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Local As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_LocalRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LocalLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LocalTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LocalBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_LocalTop As System.Windows.Forms.Label
    Friend WithEvents CheckBox_ShowTable As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_TableManual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_TableFinish As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_Table As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_TableRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_TableRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_TableLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_TableLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_TableTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_TableBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_TableBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_TableTop As System.Windows.Forms.Label
    Friend WithEvents GroupBox_MT As System.Windows.Forms.GroupBox
    Friend WithEvents Rdb_ScabType_MT As System.Windows.Forms.RadioButton
    Friend WithEvents Rdb_ScabType_Linear As System.Windows.Forms.RadioButton
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents Button_LoadImage As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label_LeftDown As System.Windows.Forms.Label
    Friend WithEvents Label_RightDown As System.Windows.Forms.Label
    Friend WithEvents Label_RightUp As System.Windows.Forms.Label
    Friend WithEvents Label_LeftUp As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents CheckBox_SideViewAlign As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Set_SideView_Position As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Calibration_Grid_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_CalibrationGrid_Row_Num As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_CalibrationGrid_Column_Num As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TabPage_ImageCalibration As System.Windows.Forms.TabPage
    Friend WithEvents Button_Calculate_Grid_Calibration As System.Windows.Forms.Button
    Friend WithEvents Label_Grid_Calibration_Info As System.Windows.Forms.Label
    Friend WithEvents Button_Calculate_Grid_Angle As System.Windows.Forms.Button
    Friend WithEvents Button_Correct_Distortion As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_CalibrationGrid_X_Tolerance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_CalibrationGrid_Y_Tolerance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_PanelMirror As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_UseAlignPattern As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_AlignType_Dot As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_MultiAngle As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Quick_Edge As System.Windows.Forms.Button
    Friend WithEvents ComboBox_MultiAngle As System.Windows.Forms.ComboBox
End Class
