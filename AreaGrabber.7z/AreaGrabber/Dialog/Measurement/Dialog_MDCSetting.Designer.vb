<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_MDCSetting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox_CombineImage_MeanWidth_X = New System.Windows.Forms.TextBox
        Me.Button_Close = New System.Windows.Forms.Button
        Me.Button_Save = New System.Windows.Forms.Button
        Me.GroupBox_GridSetting = New System.Windows.Forms.GroupBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.TextBox_MDC_GridMean_Width = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.NumericUpDown_MDC_CCDResolution = New System.Windows.Forms.NumericUpDown
        Me.Label3 = New System.Windows.Forms.Label
        Me.GroupBox_Combine_Setting = New System.Windows.Forms.GroupBox
        Me.GroupBox_GridSetting.SuspendLayout()
        CType(Me.NumericUpDown_MDC_CCDResolution, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Combine_Setting.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "MDC Mean �ȭp�� , X�e��"
        '
        'TextBox_CombineImage_MeanWidth_X
        '
        Me.TextBox_CombineImage_MeanWidth_X.Location = New System.Drawing.Point(154, 18)
        Me.TextBox_CombineImage_MeanWidth_X.Name = "TextBox_CombineImage_MeanWidth_X"
        Me.TextBox_CombineImage_MeanWidth_X.Size = New System.Drawing.Size(47, 22)
        Me.TextBox_CombineImage_MeanWidth_X.TabIndex = 1
        Me.TextBox_CombineImage_MeanWidth_X.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button_Close
        '
        Me.Button_Close.Location = New System.Drawing.Point(187, 152)
        Me.Button_Close.Name = "Button_Close"
        Me.Button_Close.Size = New System.Drawing.Size(65, 23)
        Me.Button_Close.TabIndex = 54
        Me.Button_Close.Text = "����"
        Me.Button_Close.UseVisualStyleBackColor = True
        '
        'Button_Save
        '
        Me.Button_Save.Location = New System.Drawing.Point(100, 152)
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.Size = New System.Drawing.Size(64, 23)
        Me.Button_Save.TabIndex = 53
        Me.Button_Save.Text = "�x�s"
        '
        'GroupBox_GridSetting
        '
        Me.GroupBox_GridSetting.Controls.Add(Me.Label6)
        Me.GroupBox_GridSetting.Controls.Add(Me.Label7)
        Me.GroupBox_GridSetting.Controls.Add(Me.TextBox_MDC_GridMean_Width)
        Me.GroupBox_GridSetting.Controls.Add(Me.Label2)
        Me.GroupBox_GridSetting.Controls.Add(Me.NumericUpDown_MDC_CCDResolution)
        Me.GroupBox_GridSetting.Controls.Add(Me.Label3)
        Me.GroupBox_GridSetting.Location = New System.Drawing.Point(12, 70)
        Me.GroupBox_GridSetting.Name = "GroupBox_GridSetting"
        Me.GroupBox_GridSetting.Size = New System.Drawing.Size(242, 76)
        Me.GroupBox_GridSetting.TabIndex = 55
        Me.GroupBox_GridSetting.TabStop = False
        Me.GroupBox_GridSetting.Text = "Grid Setting"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(172, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 12)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "um / pixel"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(217, 49)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(23, 12)
        Me.Label7.TabIndex = 58
        Me.Label7.Text = "mm"
        '
        'TextBox_MDC_GridMean_Width
        '
        Me.TextBox_MDC_GridMean_Width.Location = New System.Drawing.Point(166, 44)
        Me.TextBox_MDC_GridMean_Width.Name = "TextBox_MDC_GridMean_Width"
        Me.TextBox_MDC_GridMean_Width.Size = New System.Drawing.Size(47, 22)
        Me.TextBox_MDC_GridMean_Width.TabIndex = 2
        Me.TextBox_MDC_GridMean_Width.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 50)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(158, 12)
        Me.Label2.TabIndex = 57
        Me.Label2.Text = "�E�c�� Mean�ȭp�� , X/Y�e��"
        '
        'NumericUpDown_MDC_CCDResolution
        '
        Me.NumericUpDown_MDC_CCDResolution.Location = New System.Drawing.Point(100, 15)
        Me.NumericUpDown_MDC_CCDResolution.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_MDC_CCDResolution.Name = "NumericUpDown_MDC_CCDResolution"
        Me.NumericUpDown_MDC_CCDResolution.Size = New System.Drawing.Size(70, 22)
        Me.NumericUpDown_MDC_CCDResolution.TabIndex = 1
        Me.NumericUpDown_MDC_CCDResolution.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(14, 20)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(82, 12)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "CCD Resolution"
        '
        'GroupBox_Combine_Setting
        '
        Me.GroupBox_Combine_Setting.Controls.Add(Me.Label1)
        Me.GroupBox_Combine_Setting.Controls.Add(Me.TextBox_CombineImage_MeanWidth_X)
        Me.GroupBox_Combine_Setting.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox_Combine_Setting.Name = "GroupBox_Combine_Setting"
        Me.GroupBox_Combine_Setting.Size = New System.Drawing.Size(242, 52)
        Me.GroupBox_Combine_Setting.TabIndex = 56
        Me.GroupBox_Combine_Setting.TabStop = False
        Me.GroupBox_Combine_Setting.Text = "Combine_Setting"
        '
        'Dialog_MDCSetting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(267, 183)
        Me.Controls.Add(Me.GroupBox_Combine_Setting)
        Me.Controls.Add(Me.GroupBox_GridSetting)
        Me.Controls.Add(Me.Button_Close)
        Me.Controls.Add(Me.Button_Save)
        Me.Name = "Dialog_MDCSetting"
        Me.Text = "Dialog_MDCSetting"
        Me.GroupBox_GridSetting.ResumeLayout(False)
        Me.GroupBox_GridSetting.PerformLayout()
        CType(Me.NumericUpDown_MDC_CCDResolution, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Combine_Setting.ResumeLayout(False)
        Me.GroupBox_Combine_Setting.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CombineImage_MeanWidth_X As System.Windows.Forms.TextBox
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents GroupBox_GridSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Combine_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_MDC_GridMean_Width As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MDC_CCDResolution As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
End Class
