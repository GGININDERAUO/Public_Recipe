Imports MILOperationLib
Imports System.IO

<CLSCompliant(False)> _
Public Class Dialog_MDCSetting
    Private m_MeasProcess As ClsMeasProcess
    Private m_MainProcess As ClsMainProcess


#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form)
        Try
            Me.m_MeasProcess = form.MainProcess.MeasProcess
            Me.m_MainProcess = form.MainProcess

            Me.UpdateData()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MDCSetting.SetMainForm]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Try
            Me.TextBox_CombineImage_MeanWidth_X.Text = Me.m_MeasProcess.MDCModelRecipe.MDC_CombineImage_MeanWidth_X.Value
            Me.NumericUpDown_MDC_CCDResolution.Value = Me.m_MeasProcess.MDCModelRecipe.MDC_CCD_Resolution.Value
            Me.TextBox_MDC_GridMean_Width.Text = Me.m_MeasProcess.MDCModelRecipe.MDC_GridMean_Width.Value
        Catch ex As Exception
            MsgBox("[Dialog_MDCSetting.UpdataData] �ѼƸ��JForm�X���G" & vbCrLf & ex.Message & "�A�нT�{�C", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try
    End Sub
#End Region

#Region "--- Setting ---"
    Public Sub Setting()
        Try
            Me.m_MeasProcess.MDCModelRecipe.MDC_CombineImage_MeanWidth_X.Value = Me.TextBox_CombineImage_MeanWidth_X.Text
            Me.m_MeasProcess.MDCModelRecipe.MDC_CCD_Resolution.Value = Me.NumericUpDown_MDC_CCDResolution.Value
            Me.m_MeasProcess.MDCModelRecipe.MDC_GridMean_Width.Value = Me.TextBox_MDC_GridMean_Width.Text
        Catch ex As Exception
            MsgBox("[Dialog_MDCSetting.Setting] �Ѽ��x�s�X���G" & vbCrLf & ex.Message & "�A�нT�{�C", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try
    End Sub
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_Save.Enabled = En
        Me.Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- Button Event ---"

#Region "--- Button_Save_Click ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Try
            Dim rootPath As String

            rootPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\MDC\"
            If Not Directory.Exists(rootPath) Then
                Directory.CreateDirectory(rootPath)
            End If
            Button_Enable(False)
            Me.Setting()
            Me.m_MeasProcess.SaveMDCModelRecipe(rootPath, Me.m_MainProcess.ErrorCode)
            Button_Enable(True)
        Catch ex As Exception
            MessageBox.Show("[Dialog_MDCSetting.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Close_Click ---"
    Private Sub Button_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.Close()
    End Sub
#End Region

#End Region



End Class