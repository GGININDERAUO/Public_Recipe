<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_CalculateMeasurement
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.Button_Save = New System.Windows.Forms.Button
        Me.Button_Close = New System.Windows.Forms.Button
        Me.TabControl_Measurement = New System.Windows.Forms.TabControl
        Me.TabPage_Gamma = New System.Windows.Forms.TabPage
        Me.GroupBox_Gamma_Mannual = New System.Windows.Forms.GroupBox
        Me.TextBox_Gamma_Level = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Button_Gamma_AddOne = New System.Windows.Forms.Button
        Me.Button_Gamma_DeleteOne = New System.Windows.Forms.Button
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Label8 = New System.Windows.Forms.Label
        Me.TextBox_R_Square = New System.Windows.Forms.TextBox
        Me.TextBox_Gamma = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label_Gamma_Status = New System.Windows.Forms.Label
        Me.Button_CalculateGamma = New System.Windows.Forms.Button
        Me.GroupBox_Gamma_Setting = New System.Windows.Forms.GroupBox
        Me.TextBox_Gamma_Counts = New System.Windows.Forms.TextBox
        Me.ComboBox_Gamma_Pattern = New System.Windows.Forms.ComboBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.TextBox_Gamma_Max = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.TextBox_Gamma_Min = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.ListView_Gamma = New System.Windows.Forms.ListView
        Me.ColumnHeader_Gamma_Level = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader_Gamma_Mean = New System.Windows.Forms.ColumnHeader
        Me.GroupBox_Gamma_ExposureTime = New System.Windows.Forms.GroupBox
        Me.Button_Gamma_CalculateMean = New System.Windows.Forms.Button
        Me.Label_ExposureTime = New System.Windows.Forms.Label
        Me.TextBox_Gamma_Mean = New System.Windows.Forms.TextBox
        Me.NUD_Gamma_ExposureTime = New System.Windows.Forms.NumericUpDown
        Me.Label_MeanCount = New System.Windows.Forms.Label
        Me.TrackBar_Gamma_ExposureTime = New System.Windows.Forms.TrackBar
        Me.TabPage_VCom = New System.Windows.Forms.TabPage
        Me.GroupBox_VCom_ExposureTime = New System.Windows.Forms.GroupBox
        Me.Button_VCom_CalculateMean = New System.Windows.Forms.Button
        Me.Label24 = New System.Windows.Forms.Label
        Me.TextBox_VCom_Mean = New System.Windows.Forms.TextBox
        Me.NUD_VCom_ExposureTime = New System.Windows.Forms.NumericUpDown
        Me.Label25 = New System.Windows.Forms.Label
        Me.TrackBar_VCom_ExposureTime = New System.Windows.Forms.TrackBar
        Me.Label_VCom_Status = New System.Windows.Forms.Label
        Me.Button_CalculateVCom = New System.Windows.Forms.Button
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel
        Me.Label14 = New System.Windows.Forms.Label
        Me.TextBox_VCom_Result = New System.Windows.Forms.TextBox
        Me.GroupBox_VCom_Manual = New System.Windows.Forms.GroupBox
        Me.TextBox_VCom = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Button_VCom_AddOne = New System.Windows.Forms.Button
        Me.Button_VCom_DeleteOne = New System.Windows.Forms.Button
        Me.ListView_VCom = New System.Windows.Forms.ListView
        Me.ColumnHeader_VCom_Level = New System.Windows.Forms.ColumnHeader
        Me.ColumnHeader_VCom_Mean = New System.Windows.Forms.ColumnHeader
        Me.GroupBox_VCom_Setting = New System.Windows.Forms.GroupBox
        Me.TextBox_VCom_Max = New System.Windows.Forms.TextBox
        Me.ComboBox_VCom_P2 = New System.Windows.Forms.ComboBox
        Me.ComboBox_VCom_P1 = New System.Windows.Forms.ComboBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.TextBox_VCom_Min = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.TabPage_BackLight = New System.Windows.Forms.TabPage
        Me.GroupBox_BL_Setting = New System.Windows.Forms.GroupBox
        Me.TextBox_BL_Max = New System.Windows.Forms.TextBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.TextBox_BL_Min = New System.Windows.Forms.TextBox
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label23 = New System.Windows.Forms.Label
        Me.GroupBox_BL_ExposureTime = New System.Windows.Forms.GroupBox
        Me.Label_BL_Status = New System.Windows.Forms.Label
        Me.Button_BL_CalculateMean = New System.Windows.Forms.Button
        Me.Label16 = New System.Windows.Forms.Label
        Me.TextBox_BL_Mean = New System.Windows.Forms.TextBox
        Me.NUD_BL_ExposureTime = New System.Windows.Forms.NumericUpDown
        Me.Label17 = New System.Windows.Forms.Label
        Me.TrackBar_BL_ExposureTime = New System.Windows.Forms.TrackBar
        Me.ComboBox_PatGen_Model = New System.Windows.Forms.ComboBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.GroupBox_PatGen_CommSetting = New System.Windows.Forms.GroupBox
        Me.Button_SignalOn = New System.Windows.Forms.Button
        Me.Button_PatGen_Connect = New System.Windows.Forms.Button
        Me.TextBox_PatGen_Port = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.TextBox_PatGen_IPAddress = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.TextBox_VCom_Standard = New System.Windows.Forms.TextBox
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TabControl_Measurement.SuspendLayout()
        Me.TabPage_Gamma.SuspendLayout()
        Me.GroupBox_Gamma_Mannual.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.GroupBox_Gamma_Setting.SuspendLayout()
        Me.GroupBox_Gamma_ExposureTime.SuspendLayout()
        CType(Me.NUD_Gamma_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_Gamma_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_VCom.SuspendLayout()
        Me.GroupBox_VCom_ExposureTime.SuspendLayout()
        CType(Me.NUD_VCom_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_VCom_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.GroupBox_VCom_Manual.SuspendLayout()
        Me.GroupBox_VCom_Setting.SuspendLayout()
        Me.TabPage_BackLight.SuspendLayout()
        Me.GroupBox_BL_Setting.SuspendLayout()
        Me.GroupBox_BL_ExposureTime.SuspendLayout()
        CType(Me.NUD_BL_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_BL_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PatGen_CommSetting.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Save, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Close, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(316, 473)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 34)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'Button_Save
        '
        Me.Button_Save.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button_Save.Location = New System.Drawing.Point(3, 5)
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.Size = New System.Drawing.Size(67, 24)
        Me.Button_Save.TabIndex = 0
        Me.Button_Save.Text = "Save"
        '
        'Button_Close
        '
        Me.Button_Close.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_Close.Location = New System.Drawing.Point(76, 5)
        Me.Button_Close.Name = "Button_Close"
        Me.Button_Close.Size = New System.Drawing.Size(67, 24)
        Me.Button_Close.TabIndex = 1
        Me.Button_Close.Text = "Close"
        '
        'TabControl_Measurement
        '
        Me.TabControl_Measurement.Controls.Add(Me.TabPage_Gamma)
        Me.TabControl_Measurement.Controls.Add(Me.TabPage_VCom)
        Me.TabControl_Measurement.Controls.Add(Me.TabPage_BackLight)
        Me.TabControl_Measurement.Location = New System.Drawing.Point(4, 88)
        Me.TabControl_Measurement.Name = "TabControl_Measurement"
        Me.TabControl_Measurement.SelectedIndex = 0
        Me.TabControl_Measurement.Size = New System.Drawing.Size(459, 384)
        Me.TabControl_Measurement.TabIndex = 1
        '
        'TabPage_Gamma
        '
        Me.TabPage_Gamma.Controls.Add(Me.GroupBox_Gamma_Mannual)
        Me.TabPage_Gamma.Controls.Add(Me.TableLayoutPanel2)
        Me.TabPage_Gamma.Controls.Add(Me.Label_Gamma_Status)
        Me.TabPage_Gamma.Controls.Add(Me.Button_CalculateGamma)
        Me.TabPage_Gamma.Controls.Add(Me.GroupBox_Gamma_Setting)
        Me.TabPage_Gamma.Controls.Add(Me.ListView_Gamma)
        Me.TabPage_Gamma.Controls.Add(Me.GroupBox_Gamma_ExposureTime)
        Me.TabPage_Gamma.Location = New System.Drawing.Point(4, 21)
        Me.TabPage_Gamma.Name = "TabPage_Gamma"
        Me.TabPage_Gamma.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_Gamma.Size = New System.Drawing.Size(451, 359)
        Me.TabPage_Gamma.TabIndex = 2
        Me.TabPage_Gamma.Text = "Gamma"
        Me.TabPage_Gamma.ToolTipText = "Measurement Gamma Value"
        Me.TabPage_Gamma.UseVisualStyleBackColor = True
        '
        'GroupBox_Gamma_Mannual
        '
        Me.GroupBox_Gamma_Mannual.Controls.Add(Me.TextBox_Gamma_Level)
        Me.GroupBox_Gamma_Mannual.Controls.Add(Me.Label15)
        Me.GroupBox_Gamma_Mannual.Controls.Add(Me.Button_Gamma_AddOne)
        Me.GroupBox_Gamma_Mannual.Controls.Add(Me.Button_Gamma_DeleteOne)
        Me.GroupBox_Gamma_Mannual.Location = New System.Drawing.Point(194, 237)
        Me.GroupBox_Gamma_Mannual.Name = "GroupBox_Gamma_Mannual"
        Me.GroupBox_Gamma_Mannual.Size = New System.Drawing.Size(253, 82)
        Me.GroupBox_Gamma_Mannual.TabIndex = 65
        Me.GroupBox_Gamma_Mannual.TabStop = False
        Me.GroupBox_Gamma_Mannual.Text = "��ʾާ@"
        '
        'TextBox_Gamma_Level
        '
        Me.TextBox_Gamma_Level.Location = New System.Drawing.Point(57, 20)
        Me.TextBox_Gamma_Level.Name = "TextBox_Gamma_Level"
        Me.TextBox_Gamma_Level.Size = New System.Drawing.Size(53, 22)
        Me.TextBox_Gamma_Level.TabIndex = 5
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(10, 24)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(37, 12)
        Me.Label15.TabIndex = 4
        Me.Label15.Text = "Level :"
        '
        'Button_Gamma_AddOne
        '
        Me.Button_Gamma_AddOne.Location = New System.Drawing.Point(6, 50)
        Me.Button_Gamma_AddOne.Name = "Button_Gamma_AddOne"
        Me.Button_Gamma_AddOne.Size = New System.Drawing.Size(91, 24)
        Me.Button_Gamma_AddOne.TabIndex = 2
        Me.Button_Gamma_AddOne.Text = "Add One"
        Me.Button_Gamma_AddOne.UseVisualStyleBackColor = True
        '
        'Button_Gamma_DeleteOne
        '
        Me.Button_Gamma_DeleteOne.Enabled = False
        Me.Button_Gamma_DeleteOne.Location = New System.Drawing.Point(152, 50)
        Me.Button_Gamma_DeleteOne.Name = "Button_Gamma_DeleteOne"
        Me.Button_Gamma_DeleteOne.Size = New System.Drawing.Size(91, 24)
        Me.Button_Gamma_DeleteOne.TabIndex = 3
        Me.Button_Gamma_DeleteOne.Text = "Delete One"
        Me.Button_Gamma_DeleteOne.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 2
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 44.0!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 76.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Label8, 0, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox_R_Square, 1, 1)
        Me.TableLayoutPanel2.Controls.Add(Me.TextBox_Gamma, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Label1, 0, 0)
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(4, 254)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 2
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(135, 60)
        Me.TableLayoutPanel2.TabIndex = 63
        '
        'Label8
        '
        Me.Label8.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(3, 38)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(57, 12)
        Me.Label8.TabIndex = 59
        Me.Label8.Text = "R Square : "
        '
        'TextBox_R_Square
        '
        Me.TextBox_R_Square.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox_R_Square.Enabled = False
        Me.TextBox_R_Square.Location = New System.Drawing.Point(66, 33)
        Me.TextBox_R_Square.Name = "TextBox_R_Square"
        Me.TextBox_R_Square.Size = New System.Drawing.Size(66, 22)
        Me.TextBox_R_Square.TabIndex = 60
        Me.TextBox_R_Square.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_Gamma
        '
        Me.TextBox_Gamma.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TextBox_Gamma.Enabled = False
        Me.TextBox_Gamma.Location = New System.Drawing.Point(66, 3)
        Me.TextBox_Gamma.Name = "TextBox_Gamma"
        Me.TextBox_Gamma.Size = New System.Drawing.Size(66, 22)
        Me.TextBox_Gamma.TabIndex = 56
        Me.TextBox_Gamma.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(47, 12)
        Me.Label1.TabIndex = 55
        Me.Label1.Text = "Gamma :"
        '
        'Label_Gamma_Status
        '
        Me.Label_Gamma_Status.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label_Gamma_Status.Location = New System.Drawing.Point(146, 262)
        Me.Label_Gamma_Status.Name = "Label_Gamma_Status"
        Me.Label_Gamma_Status.Size = New System.Drawing.Size(37, 12)
        Me.Label_Gamma_Status.TabIndex = 58
        Me.Label_Gamma_Status.Text = "NULL"
        '
        'Button_CalculateGamma
        '
        Me.Button_CalculateGamma.Enabled = False
        Me.Button_CalculateGamma.Location = New System.Drawing.Point(197, 324)
        Me.Button_CalculateGamma.Name = "Button_CalculateGamma"
        Me.Button_CalculateGamma.Size = New System.Drawing.Size(83, 25)
        Me.Button_CalculateGamma.TabIndex = 1
        Me.Button_CalculateGamma.Text = "�p��Gamma"
        Me.Button_CalculateGamma.UseVisualStyleBackColor = True
        '
        'GroupBox_Gamma_Setting
        '
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.TextBox_Gamma_Counts)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.ComboBox_Gamma_Pattern)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.Label11)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.TextBox_Gamma_Max)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.Label5)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.TextBox_Gamma_Min)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.Label4)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.Label3)
        Me.GroupBox_Gamma_Setting.Controls.Add(Me.Label2)
        Me.GroupBox_Gamma_Setting.Enabled = False
        Me.GroupBox_Gamma_Setting.Location = New System.Drawing.Point(194, 124)
        Me.GroupBox_Gamma_Setting.Name = "GroupBox_Gamma_Setting"
        Me.GroupBox_Gamma_Setting.Size = New System.Drawing.Size(253, 107)
        Me.GroupBox_Gamma_Setting.TabIndex = 57
        Me.GroupBox_Gamma_Setting.TabStop = False
        Me.GroupBox_Gamma_Setting.Text = "Setting"
        '
        'TextBox_Gamma_Counts
        '
        Me.TextBox_Gamma_Counts.Location = New System.Drawing.Point(53, 48)
        Me.TextBox_Gamma_Counts.Name = "TextBox_Gamma_Counts"
        Me.TextBox_Gamma_Counts.ReadOnly = True
        Me.TextBox_Gamma_Counts.Size = New System.Drawing.Size(56, 22)
        Me.TextBox_Gamma_Counts.TabIndex = 19
        Me.TextBox_Gamma_Counts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ComboBox_Gamma_Pattern
        '
        Me.ComboBox_Gamma_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Gamma_Pattern.FormattingEnabled = True
        Me.ComboBox_Gamma_Pattern.Location = New System.Drawing.Point(53, 19)
        Me.ComboBox_Gamma_Pattern.Name = "ComboBox_Gamma_Pattern"
        Me.ComboBox_Gamma_Pattern.Size = New System.Drawing.Size(116, 20)
        Me.ComboBox_Gamma_Pattern.TabIndex = 18
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(10, 22)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 12)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Pattern : "
        '
        'TextBox_Gamma_Max
        '
        Me.TextBox_Gamma_Max.Location = New System.Drawing.Point(204, 74)
        Me.TextBox_Gamma_Max.Name = "TextBox_Gamma_Max"
        Me.TextBox_Gamma_Max.Size = New System.Drawing.Size(42, 22)
        Me.TextBox_Gamma_Max.TabIndex = 8
        Me.TextBox_Gamma_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(165, 79)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 12)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "~ Max"
        '
        'TextBox_Gamma_Min
        '
        Me.TextBox_Gamma_Min.Location = New System.Drawing.Point(116, 74)
        Me.TextBox_Gamma_Min.Name = "TextBox_Gamma_Min"
        Me.TextBox_Gamma_Min.Size = New System.Drawing.Size(43, 22)
        Me.TextBox_Gamma_Min.TabIndex = 6
        Me.TextBox_Gamma_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(88, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(24, 12)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Min"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Gamma Range :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(8, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Counts :"
        '
        'ListView_Gamma
        '
        Me.ListView_Gamma.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_Gamma_Level, Me.ColumnHeader_Gamma_Mean})
        Me.ListView_Gamma.FullRowSelect = True
        Me.ListView_Gamma.GridLines = True
        Me.ListView_Gamma.HideSelection = False
        Me.ListView_Gamma.Location = New System.Drawing.Point(6, 9)
        Me.ListView_Gamma.Name = "ListView_Gamma"
        Me.ListView_Gamma.Size = New System.Drawing.Size(180, 242)
        Me.ListView_Gamma.TabIndex = 53
        Me.ListView_Gamma.UseCompatibleStateImageBehavior = False
        Me.ListView_Gamma.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_Gamma_Level
        '
        Me.ColumnHeader_Gamma_Level.Text = "Level"
        Me.ColumnHeader_Gamma_Level.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ColumnHeader_Gamma_Level.Width = 50
        '
        'ColumnHeader_Gamma_Mean
        '
        Me.ColumnHeader_Gamma_Mean.Text = "Mean"
        Me.ColumnHeader_Gamma_Mean.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ColumnHeader_Gamma_Mean.Width = 50
        '
        'GroupBox_Gamma_ExposureTime
        '
        Me.GroupBox_Gamma_ExposureTime.Controls.Add(Me.Button_Gamma_CalculateMean)
        Me.GroupBox_Gamma_ExposureTime.Controls.Add(Me.Label_ExposureTime)
        Me.GroupBox_Gamma_ExposureTime.Controls.Add(Me.TextBox_Gamma_Mean)
        Me.GroupBox_Gamma_ExposureTime.Controls.Add(Me.NUD_Gamma_ExposureTime)
        Me.GroupBox_Gamma_ExposureTime.Controls.Add(Me.Label_MeanCount)
        Me.GroupBox_Gamma_ExposureTime.Controls.Add(Me.TrackBar_Gamma_ExposureTime)
        Me.GroupBox_Gamma_ExposureTime.Enabled = False
        Me.GroupBox_Gamma_ExposureTime.Location = New System.Drawing.Point(194, 6)
        Me.GroupBox_Gamma_ExposureTime.Name = "GroupBox_Gamma_ExposureTime"
        Me.GroupBox_Gamma_ExposureTime.Size = New System.Drawing.Size(253, 112)
        Me.GroupBox_Gamma_ExposureTime.TabIndex = 52
        Me.GroupBox_Gamma_ExposureTime.TabStop = False
        Me.GroupBox_Gamma_ExposureTime.Text = "�n���ɶ�"
        '
        'Button_Gamma_CalculateMean
        '
        Me.Button_Gamma_CalculateMean.Location = New System.Drawing.Point(6, 79)
        Me.Button_Gamma_CalculateMean.Name = "Button_Gamma_CalculateMean"
        Me.Button_Gamma_CalculateMean.Size = New System.Drawing.Size(88, 24)
        Me.Button_Gamma_CalculateMean.TabIndex = 44
        Me.Button_Gamma_CalculateMean.Text = "�p��Mean��"
        '
        'Label_ExposureTime
        '
        Me.Label_ExposureTime.Location = New System.Drawing.Point(101, 52)
        Me.Label_ExposureTime.Name = "Label_ExposureTime"
        Me.Label_ExposureTime.Size = New System.Drawing.Size(42, 22)
        Me.Label_ExposureTime.TabIndex = 45
        Me.Label_ExposureTime.Text = "�L�@��"
        Me.Label_ExposureTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_Gamma_Mean
        '
        Me.TextBox_Gamma_Mean.Location = New System.Drawing.Point(169, 81)
        Me.TextBox_Gamma_Mean.Name = "TextBox_Gamma_Mean"
        Me.TextBox_Gamma_Mean.Size = New System.Drawing.Size(60, 22)
        Me.TextBox_Gamma_Mean.TabIndex = 1
        '
        'NUD_Gamma_ExposureTime
        '
        Me.NUD_Gamma_ExposureTime.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NUD_Gamma_ExposureTime.Location = New System.Drawing.Point(7, 51)
        Me.NUD_Gamma_ExposureTime.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_Gamma_ExposureTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NUD_Gamma_ExposureTime.Name = "NUD_Gamma_ExposureTime"
        Me.NUD_Gamma_ExposureTime.Size = New System.Drawing.Size(88, 22)
        Me.NUD_Gamma_ExposureTime.TabIndex = 44
        Me.NUD_Gamma_ExposureTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NUD_Gamma_ExposureTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_MeanCount
        '
        Me.Label_MeanCount.AutoSize = True
        Me.Label_MeanCount.Location = New System.Drawing.Point(117, 85)
        Me.Label_MeanCount.Name = "Label_MeanCount"
        Me.Label_MeanCount.Size = New System.Drawing.Size(49, 12)
        Me.Label_MeanCount.TabIndex = 0
        Me.Label_MeanCount.Text = "Mean ��:"
        '
        'TrackBar_Gamma_ExposureTime
        '
        Me.TrackBar_Gamma_ExposureTime.LargeChange = 10000
        Me.TrackBar_Gamma_ExposureTime.Location = New System.Drawing.Point(8, 12)
        Me.TrackBar_Gamma_ExposureTime.Maximum = 1000000
        Me.TrackBar_Gamma_ExposureTime.Minimum = 1
        Me.TrackBar_Gamma_ExposureTime.Name = "TrackBar_Gamma_ExposureTime"
        Me.TrackBar_Gamma_ExposureTime.Size = New System.Drawing.Size(216, 45)
        Me.TrackBar_Gamma_ExposureTime.TabIndex = 44
        Me.TrackBar_Gamma_ExposureTime.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_Gamma_ExposureTime.Value = 1
        '
        'TabPage_VCom
        '
        Me.TabPage_VCom.Controls.Add(Me.GroupBox_VCom_ExposureTime)
        Me.TabPage_VCom.Controls.Add(Me.Label_VCom_Status)
        Me.TabPage_VCom.Controls.Add(Me.Button_CalculateVCom)
        Me.TabPage_VCom.Controls.Add(Me.TableLayoutPanel3)
        Me.TabPage_VCom.Controls.Add(Me.GroupBox_VCom_Manual)
        Me.TabPage_VCom.Controls.Add(Me.ListView_VCom)
        Me.TabPage_VCom.Controls.Add(Me.GroupBox_VCom_Setting)
        Me.TabPage_VCom.Location = New System.Drawing.Point(4, 21)
        Me.TabPage_VCom.Name = "TabPage_VCom"
        Me.TabPage_VCom.Size = New System.Drawing.Size(451, 359)
        Me.TabPage_VCom.TabIndex = 3
        Me.TabPage_VCom.Text = "Flicker"
        Me.TabPage_VCom.UseVisualStyleBackColor = True
        '
        'GroupBox_VCom_ExposureTime
        '
        Me.GroupBox_VCom_ExposureTime.Controls.Add(Me.Button_VCom_CalculateMean)
        Me.GroupBox_VCom_ExposureTime.Controls.Add(Me.Label24)
        Me.GroupBox_VCom_ExposureTime.Controls.Add(Me.TextBox_VCom_Mean)
        Me.GroupBox_VCom_ExposureTime.Controls.Add(Me.NUD_VCom_ExposureTime)
        Me.GroupBox_VCom_ExposureTime.Controls.Add(Me.Label25)
        Me.GroupBox_VCom_ExposureTime.Controls.Add(Me.TrackBar_VCom_ExposureTime)
        Me.GroupBox_VCom_ExposureTime.Enabled = False
        Me.GroupBox_VCom_ExposureTime.Location = New System.Drawing.Point(198, 3)
        Me.GroupBox_VCom_ExposureTime.Name = "GroupBox_VCom_ExposureTime"
        Me.GroupBox_VCom_ExposureTime.Size = New System.Drawing.Size(247, 112)
        Me.GroupBox_VCom_ExposureTime.TabIndex = 60
        Me.GroupBox_VCom_ExposureTime.TabStop = False
        Me.GroupBox_VCom_ExposureTime.Text = "�n���ɶ�"
        '
        'Button_VCom_CalculateMean
        '
        Me.Button_VCom_CalculateMean.Location = New System.Drawing.Point(6, 79)
        Me.Button_VCom_CalculateMean.Name = "Button_VCom_CalculateMean"
        Me.Button_VCom_CalculateMean.Size = New System.Drawing.Size(88, 24)
        Me.Button_VCom_CalculateMean.TabIndex = 44
        Me.Button_VCom_CalculateMean.Text = "�p��Mean��"
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(101, 52)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(42, 22)
        Me.Label24.TabIndex = 45
        Me.Label24.Text = "�L�@��"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_VCom_Mean
        '
        Me.TextBox_VCom_Mean.Location = New System.Drawing.Point(169, 81)
        Me.TextBox_VCom_Mean.Name = "TextBox_VCom_Mean"
        Me.TextBox_VCom_Mean.Size = New System.Drawing.Size(60, 22)
        Me.TextBox_VCom_Mean.TabIndex = 1
        '
        'NUD_VCom_ExposureTime
        '
        Me.NUD_VCom_ExposureTime.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NUD_VCom_ExposureTime.Location = New System.Drawing.Point(7, 51)
        Me.NUD_VCom_ExposureTime.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_VCom_ExposureTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NUD_VCom_ExposureTime.Name = "NUD_VCom_ExposureTime"
        Me.NUD_VCom_ExposureTime.Size = New System.Drawing.Size(88, 22)
        Me.NUD_VCom_ExposureTime.TabIndex = 44
        Me.NUD_VCom_ExposureTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NUD_VCom_ExposureTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(117, 85)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(49, 12)
        Me.Label25.TabIndex = 0
        Me.Label25.Text = "Mean ��:"
        '
        'TrackBar_VCom_ExposureTime
        '
        Me.TrackBar_VCom_ExposureTime.LargeChange = 10000
        Me.TrackBar_VCom_ExposureTime.Location = New System.Drawing.Point(8, 12)
        Me.TrackBar_VCom_ExposureTime.Maximum = 1000000
        Me.TrackBar_VCom_ExposureTime.Minimum = 1
        Me.TrackBar_VCom_ExposureTime.Name = "TrackBar_VCom_ExposureTime"
        Me.TrackBar_VCom_ExposureTime.Size = New System.Drawing.Size(216, 45)
        Me.TrackBar_VCom_ExposureTime.TabIndex = 44
        Me.TrackBar_VCom_ExposureTime.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_VCom_ExposureTime.Value = 1
        '
        'Label_VCom_Status
        '
        Me.Label_VCom_Status.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label_VCom_Status.Location = New System.Drawing.Point(153, 265)
        Me.Label_VCom_Status.Name = "Label_VCom_Status"
        Me.Label_VCom_Status.Size = New System.Drawing.Size(37, 12)
        Me.Label_VCom_Status.TabIndex = 59
        Me.Label_VCom_Status.Text = "NULL"
        '
        'Button_CalculateVCom
        '
        Me.Button_CalculateVCom.Enabled = False
        Me.Button_CalculateVCom.Location = New System.Drawing.Point(6, 292)
        Me.Button_CalculateVCom.Name = "Button_CalculateVCom"
        Me.Button_CalculateVCom.Size = New System.Drawing.Size(80, 24)
        Me.Button_CalculateVCom.TabIndex = 8
        Me.Button_CalculateVCom.Text = "�p�� VCom"
        Me.Button_CalculateVCom.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 38.70968!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 61.29032!))
        Me.TableLayoutPanel3.Controls.Add(Me.Label14, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.TextBox_VCom_Result, 1, 0)
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(8, 258)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(124, 28)
        Me.TableLayoutPanel3.TabIndex = 5
        '
        'Label14
        '
        Me.Label14.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(3, 8)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(42, 12)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "VCom :"
        '
        'TextBox_VCom_Result
        '
        Me.TextBox_VCom_Result.Enabled = False
        Me.TextBox_VCom_Result.Location = New System.Drawing.Point(51, 3)
        Me.TextBox_VCom_Result.Name = "TextBox_VCom_Result"
        Me.TextBox_VCom_Result.Size = New System.Drawing.Size(64, 22)
        Me.TextBox_VCom_Result.TabIndex = 6
        '
        'GroupBox_VCom_Manual
        '
        Me.GroupBox_VCom_Manual.Controls.Add(Me.TextBox_VCom)
        Me.GroupBox_VCom_Manual.Controls.Add(Me.Label13)
        Me.GroupBox_VCom_Manual.Controls.Add(Me.Button_VCom_AddOne)
        Me.GroupBox_VCom_Manual.Controls.Add(Me.Button_VCom_DeleteOne)
        Me.GroupBox_VCom_Manual.Location = New System.Drawing.Point(198, 257)
        Me.GroupBox_VCom_Manual.Name = "GroupBox_VCom_Manual"
        Me.GroupBox_VCom_Manual.Size = New System.Drawing.Size(250, 86)
        Me.GroupBox_VCom_Manual.TabIndex = 4
        Me.GroupBox_VCom_Manual.TabStop = False
        Me.GroupBox_VCom_Manual.Text = "��ʾާ@"
        '
        'TextBox_VCom
        '
        Me.TextBox_VCom.Location = New System.Drawing.Point(57, 20)
        Me.TextBox_VCom.Name = "TextBox_VCom"
        Me.TextBox_VCom.Size = New System.Drawing.Size(53, 22)
        Me.TextBox_VCom.TabIndex = 5
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(10, 24)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(42, 12)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "VCom :"
        '
        'Button_VCom_AddOne
        '
        Me.Button_VCom_AddOne.Location = New System.Drawing.Point(6, 50)
        Me.Button_VCom_AddOne.Name = "Button_VCom_AddOne"
        Me.Button_VCom_AddOne.Size = New System.Drawing.Size(91, 24)
        Me.Button_VCom_AddOne.TabIndex = 2
        Me.Button_VCom_AddOne.Text = "Add One"
        Me.Button_VCom_AddOne.UseVisualStyleBackColor = True
        '
        'Button_VCom_DeleteOne
        '
        Me.Button_VCom_DeleteOne.Enabled = False
        Me.Button_VCom_DeleteOne.Location = New System.Drawing.Point(152, 50)
        Me.Button_VCom_DeleteOne.Name = "Button_VCom_DeleteOne"
        Me.Button_VCom_DeleteOne.Size = New System.Drawing.Size(91, 24)
        Me.Button_VCom_DeleteOne.TabIndex = 3
        Me.Button_VCom_DeleteOne.Text = "Delete One"
        Me.Button_VCom_DeleteOne.UseVisualStyleBackColor = True
        '
        'ListView_VCom
        '
        Me.ListView_VCom.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_VCom_Level, Me.ColumnHeader_VCom_Mean})
        Me.ListView_VCom.FullRowSelect = True
        Me.ListView_VCom.GridLines = True
        Me.ListView_VCom.HideSelection = False
        Me.ListView_VCom.Location = New System.Drawing.Point(6, 9)
        Me.ListView_VCom.Name = "ListView_VCom"
        Me.ListView_VCom.Size = New System.Drawing.Size(178, 242)
        Me.ListView_VCom.TabIndex = 1
        Me.ListView_VCom.UseCompatibleStateImageBehavior = False
        Me.ListView_VCom.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_VCom_Level
        '
        Me.ColumnHeader_VCom_Level.Text = "VCom"
        Me.ColumnHeader_VCom_Level.Width = 50
        '
        'ColumnHeader_VCom_Mean
        '
        Me.ColumnHeader_VCom_Mean.Text = "��Mean"
        Me.ColumnHeader_VCom_Mean.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_VCom_Setting
        '
        Me.GroupBox_VCom_Setting.Controls.Add(Me.TextBox_VCom_Standard)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.Label26)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.TextBox_VCom_Max)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.ComboBox_VCom_P2)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.ComboBox_VCom_P1)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.Label18)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.Label9)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.Label12)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.TextBox_VCom_Min)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.Label19)
        Me.GroupBox_VCom_Setting.Controls.Add(Me.Label20)
        Me.GroupBox_VCom_Setting.Enabled = False
        Me.GroupBox_VCom_Setting.Location = New System.Drawing.Point(198, 121)
        Me.GroupBox_VCom_Setting.Name = "GroupBox_VCom_Setting"
        Me.GroupBox_VCom_Setting.Size = New System.Drawing.Size(250, 130)
        Me.GroupBox_VCom_Setting.TabIndex = 1
        Me.GroupBox_VCom_Setting.TabStop = False
        Me.GroupBox_VCom_Setting.Text = "Setting"
        '
        'TextBox_VCom_Max
        '
        Me.TextBox_VCom_Max.Location = New System.Drawing.Point(201, 73)
        Me.TextBox_VCom_Max.Name = "TextBox_VCom_Max"
        Me.TextBox_VCom_Max.Size = New System.Drawing.Size(42, 22)
        Me.TextBox_VCom_Max.TabIndex = 13
        Me.TextBox_VCom_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ComboBox_VCom_P2
        '
        Me.ComboBox_VCom_P2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VCom_P2.FormattingEnabled = True
        Me.ComboBox_VCom_P2.Location = New System.Drawing.Point(60, 45)
        Me.ComboBox_VCom_P2.Name = "ComboBox_VCom_P2"
        Me.ComboBox_VCom_P2.Size = New System.Drawing.Size(124, 20)
        Me.ComboBox_VCom_P2.TabIndex = 4
        '
        'ComboBox_VCom_P1
        '
        Me.ComboBox_VCom_P1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_VCom_P1.FormattingEnabled = True
        Me.ComboBox_VCom_P1.Location = New System.Drawing.Point(60, 21)
        Me.ComboBox_VCom_P1.Name = "ComboBox_VCom_P1"
        Me.ComboBox_VCom_P1.Size = New System.Drawing.Size(124, 20)
        Me.ComboBox_VCom_P1.TabIndex = 1
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(162, 78)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(35, 12)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "~ Max"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 24)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 12)
        Me.Label9.TabIndex = 1
        Me.Label9.Text = "Pattern 1:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 48)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(49, 12)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Pattern 2:"
        '
        'TextBox_VCom_Min
        '
        Me.TextBox_VCom_Min.Location = New System.Drawing.Point(113, 73)
        Me.TextBox_VCom_Min.Name = "TextBox_VCom_Min"
        Me.TextBox_VCom_Min.Size = New System.Drawing.Size(43, 22)
        Me.TextBox_VCom_Min.TabIndex = 11
        Me.TextBox_VCom_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(85, 78)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(24, 12)
        Me.Label19.TabIndex = 10
        Me.Label19.Text = "Min"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(3, 77)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(82, 12)
        Me.Label20.TabIndex = 9
        Me.Label20.Text = "��Mean Range :"
        '
        'TabPage_BackLight
        '
        Me.TabPage_BackLight.Controls.Add(Me.GroupBox_BL_Setting)
        Me.TabPage_BackLight.Controls.Add(Me.GroupBox_BL_ExposureTime)
        Me.TabPage_BackLight.Location = New System.Drawing.Point(4, 21)
        Me.TabPage_BackLight.Name = "TabPage_BackLight"
        Me.TabPage_BackLight.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage_BackLight.Size = New System.Drawing.Size(451, 359)
        Me.TabPage_BackLight.TabIndex = 4
        Me.TabPage_BackLight.Text = "BL"
        Me.TabPage_BackLight.UseVisualStyleBackColor = True
        '
        'GroupBox_BL_Setting
        '
        Me.GroupBox_BL_Setting.Controls.Add(Me.TextBox_BL_Max)
        Me.GroupBox_BL_Setting.Controls.Add(Me.Label21)
        Me.GroupBox_BL_Setting.Controls.Add(Me.TextBox_BL_Min)
        Me.GroupBox_BL_Setting.Controls.Add(Me.Label22)
        Me.GroupBox_BL_Setting.Controls.Add(Me.Label23)
        Me.GroupBox_BL_Setting.Enabled = False
        Me.GroupBox_BL_Setting.Location = New System.Drawing.Point(6, 135)
        Me.GroupBox_BL_Setting.Name = "GroupBox_BL_Setting"
        Me.GroupBox_BL_Setting.Size = New System.Drawing.Size(285, 52)
        Me.GroupBox_BL_Setting.TabIndex = 55
        Me.GroupBox_BL_Setting.TabStop = False
        Me.GroupBox_BL_Setting.Text = "Setting"
        '
        'TextBox_BL_Max
        '
        Me.TextBox_BL_Max.Location = New System.Drawing.Point(187, 21)
        Me.TextBox_BL_Max.Name = "TextBox_BL_Max"
        Me.TextBox_BL_Max.Size = New System.Drawing.Size(42, 22)
        Me.TextBox_BL_Max.TabIndex = 18
        Me.TextBox_BL_Max.Text = "1000"
        Me.TextBox_BL_Max.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(148, 26)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(35, 12)
        Me.Label21.TabIndex = 17
        Me.Label21.Text = "~ Max"
        '
        'TextBox_BL_Min
        '
        Me.TextBox_BL_Min.Location = New System.Drawing.Point(99, 21)
        Me.TextBox_BL_Min.Name = "TextBox_BL_Min"
        Me.TextBox_BL_Min.Size = New System.Drawing.Size(43, 22)
        Me.TextBox_BL_Min.TabIndex = 16
        Me.TextBox_BL_Min.Text = "500"
        Me.TextBox_BL_Min.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(71, 26)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(24, 12)
        Me.Label22.TabIndex = 15
        Me.Label22.Text = "Min"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(10, 25)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(59, 12)
        Me.Label23.TabIndex = 14
        Me.Label23.Text = "BL Range :"
        '
        'GroupBox_BL_ExposureTime
        '
        Me.GroupBox_BL_ExposureTime.Controls.Add(Me.Label_BL_Status)
        Me.GroupBox_BL_ExposureTime.Controls.Add(Me.Button_BL_CalculateMean)
        Me.GroupBox_BL_ExposureTime.Controls.Add(Me.Label16)
        Me.GroupBox_BL_ExposureTime.Controls.Add(Me.TextBox_BL_Mean)
        Me.GroupBox_BL_ExposureTime.Controls.Add(Me.NUD_BL_ExposureTime)
        Me.GroupBox_BL_ExposureTime.Controls.Add(Me.Label17)
        Me.GroupBox_BL_ExposureTime.Controls.Add(Me.TrackBar_BL_ExposureTime)
        Me.GroupBox_BL_ExposureTime.Enabled = False
        Me.GroupBox_BL_ExposureTime.Location = New System.Drawing.Point(6, 6)
        Me.GroupBox_BL_ExposureTime.Name = "GroupBox_BL_ExposureTime"
        Me.GroupBox_BL_ExposureTime.Size = New System.Drawing.Size(285, 123)
        Me.GroupBox_BL_ExposureTime.TabIndex = 53
        Me.GroupBox_BL_ExposureTime.TabStop = False
        Me.GroupBox_BL_ExposureTime.Text = "�n���ɶ�"
        '
        'Label_BL_Status
        '
        Me.Label_BL_Status.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label_BL_Status.Location = New System.Drawing.Point(235, 98)
        Me.Label_BL_Status.Name = "Label_BL_Status"
        Me.Label_BL_Status.Size = New System.Drawing.Size(37, 12)
        Me.Label_BL_Status.TabIndex = 59
        Me.Label_BL_Status.Text = "NULL"
        '
        'Button_BL_CalculateMean
        '
        Me.Button_BL_CalculateMean.Location = New System.Drawing.Point(6, 92)
        Me.Button_BL_CalculateMean.Name = "Button_BL_CalculateMean"
        Me.Button_BL_CalculateMean.Size = New System.Drawing.Size(88, 24)
        Me.Button_BL_CalculateMean.TabIndex = 44
        Me.Button_BL_CalculateMean.Text = "�p��Mean��"
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(101, 60)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(42, 22)
        Me.Label16.TabIndex = 45
        Me.Label16.Text = "�L�@��"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox_BL_Mean
        '
        Me.TextBox_BL_Mean.Location = New System.Drawing.Point(169, 94)
        Me.TextBox_BL_Mean.Name = "TextBox_BL_Mean"
        Me.TextBox_BL_Mean.ReadOnly = True
        Me.TextBox_BL_Mean.Size = New System.Drawing.Size(60, 22)
        Me.TextBox_BL_Mean.TabIndex = 1
        '
        'NUD_BL_ExposureTime
        '
        Me.NUD_BL_ExposureTime.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NUD_BL_ExposureTime.Location = New System.Drawing.Point(7, 59)
        Me.NUD_BL_ExposureTime.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NUD_BL_ExposureTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NUD_BL_ExposureTime.Name = "NUD_BL_ExposureTime"
        Me.NUD_BL_ExposureTime.Size = New System.Drawing.Size(88, 22)
        Me.NUD_BL_ExposureTime.TabIndex = 44
        Me.NUD_BL_ExposureTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NUD_BL_ExposureTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(117, 98)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(49, 12)
        Me.Label17.TabIndex = 0
        Me.Label17.Text = "Mean ��:"
        '
        'TrackBar_BL_ExposureTime
        '
        Me.TrackBar_BL_ExposureTime.LargeChange = 10000
        Me.TrackBar_BL_ExposureTime.Location = New System.Drawing.Point(8, 12)
        Me.TrackBar_BL_ExposureTime.Maximum = 1000000
        Me.TrackBar_BL_ExposureTime.Minimum = 1
        Me.TrackBar_BL_ExposureTime.Name = "TrackBar_BL_ExposureTime"
        Me.TrackBar_BL_ExposureTime.Size = New System.Drawing.Size(216, 45)
        Me.TrackBar_BL_ExposureTime.TabIndex = 44
        Me.TrackBar_BL_ExposureTime.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_BL_ExposureTime.Value = 1
        '
        'ComboBox_PatGen_Model
        '
        Me.ComboBox_PatGen_Model.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PatGen_Model.FormattingEnabled = True
        Me.ComboBox_PatGen_Model.Location = New System.Drawing.Point(46, 50)
        Me.ComboBox_PatGen_Model.Name = "ComboBox_PatGen_Model"
        Me.ComboBox_PatGen_Model.Size = New System.Drawing.Size(116, 20)
        Me.ComboBox_PatGen_Model.TabIndex = 17
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(5, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(44, 12)
        Me.Label10.TabIndex = 11
        Me.Label10.Text = "Model : "
        '
        'GroupBox_PatGen_CommSetting
        '
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.Button_SignalOn)
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.ComboBox_PatGen_Model)
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.Button_PatGen_Connect)
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.Label10)
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.TextBox_PatGen_Port)
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.Label7)
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.TextBox_PatGen_IPAddress)
        Me.GroupBox_PatGen_CommSetting.Controls.Add(Me.Label6)
        Me.GroupBox_PatGen_CommSetting.Location = New System.Drawing.Point(4, 2)
        Me.GroupBox_PatGen_CommSetting.Name = "GroupBox_PatGen_CommSetting"
        Me.GroupBox_PatGen_CommSetting.Size = New System.Drawing.Size(459, 80)
        Me.GroupBox_PatGen_CommSetting.TabIndex = 59
        Me.GroupBox_PatGen_CommSetting.TabStop = False
        Me.GroupBox_PatGen_CommSetting.Text = "�q�T�]�w"
        '
        'Button_SignalOn
        '
        Me.Button_SignalOn.Enabled = False
        Me.Button_SignalOn.Location = New System.Drawing.Point(370, 22)
        Me.Button_SignalOn.Name = "Button_SignalOn"
        Me.Button_SignalOn.Size = New System.Drawing.Size(73, 23)
        Me.Button_SignalOn.TabIndex = 61
        Me.Button_SignalOn.Text = "Signal Off"
        Me.Button_SignalOn.UseVisualStyleBackColor = True
        '
        'Button_PatGen_Connect
        '
        Me.Button_PatGen_Connect.Location = New System.Drawing.Point(269, 22)
        Me.Button_PatGen_Connect.Name = "Button_PatGen_Connect"
        Me.Button_PatGen_Connect.Size = New System.Drawing.Size(76, 23)
        Me.Button_PatGen_Connect.TabIndex = 60
        Me.Button_PatGen_Connect.Text = "Connect"
        Me.Button_PatGen_Connect.UseVisualStyleBackColor = True
        '
        'TextBox_PatGen_Port
        '
        Me.TextBox_PatGen_Port.Location = New System.Drawing.Point(191, 22)
        Me.TextBox_PatGen_Port.Name = "TextBox_PatGen_Port"
        Me.TextBox_PatGen_Port.Size = New System.Drawing.Size(57, 22)
        Me.TextBox_PatGen_Port.TabIndex = 3
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(157, 28)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(33, 12)
        Me.Label7.TabIndex = 2
        Me.Label7.Text = "Port : "
        '
        'TextBox_PatGen_IPAddress
        '
        Me.TextBox_PatGen_IPAddress.Location = New System.Drawing.Point(47, 22)
        Me.TextBox_PatGen_IPAddress.Name = "TextBox_PatGen_IPAddress"
        Me.TextBox_PatGen_IPAddress.Size = New System.Drawing.Size(104, 22)
        Me.TextBox_PatGen_IPAddress.TabIndex = 1
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(24, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(21, 12)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "IP :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(8, 106)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(86, 12)
        Me.Label26.TabIndex = 14
        Me.Label26.Text = "Standard VCom :"
        '
        'TextBox_VCom_Standard
        '
        Me.TextBox_VCom_Standard.Location = New System.Drawing.Point(98, 101)
        Me.TextBox_VCom_Standard.Name = "TextBox_VCom_Standard"
        Me.TextBox_VCom_Standard.Size = New System.Drawing.Size(58, 22)
        Me.TextBox_VCom_Standard.TabIndex = 15
        '
        'Dialog_CalculateMeasurement
        '
        Me.AcceptButton = Me.Button_Save
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Button_Close
        Me.ClientSize = New System.Drawing.Size(470, 506)
        Me.Controls.Add(Me.GroupBox_PatGen_CommSetting)
        Me.Controls.Add(Me.TabControl_Measurement)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_CalculateMeasurement"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "OMS"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TabControl_Measurement.ResumeLayout(False)
        Me.TabPage_Gamma.ResumeLayout(False)
        Me.GroupBox_Gamma_Mannual.ResumeLayout(False)
        Me.GroupBox_Gamma_Mannual.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.TableLayoutPanel2.PerformLayout()
        Me.GroupBox_Gamma_Setting.ResumeLayout(False)
        Me.GroupBox_Gamma_Setting.PerformLayout()
        Me.GroupBox_Gamma_ExposureTime.ResumeLayout(False)
        Me.GroupBox_Gamma_ExposureTime.PerformLayout()
        CType(Me.NUD_Gamma_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_Gamma_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_VCom.ResumeLayout(False)
        Me.GroupBox_VCom_ExposureTime.ResumeLayout(False)
        Me.GroupBox_VCom_ExposureTime.PerformLayout()
        CType(Me.NUD_VCom_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_VCom_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.GroupBox_VCom_Manual.ResumeLayout(False)
        Me.GroupBox_VCom_Manual.PerformLayout()
        Me.GroupBox_VCom_Setting.ResumeLayout(False)
        Me.GroupBox_VCom_Setting.PerformLayout()
        Me.TabPage_BackLight.ResumeLayout(False)
        Me.GroupBox_BL_Setting.ResumeLayout(False)
        Me.GroupBox_BL_Setting.PerformLayout()
        Me.GroupBox_BL_ExposureTime.ResumeLayout(False)
        Me.GroupBox_BL_ExposureTime.PerformLayout()
        CType(Me.NUD_BL_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_BL_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PatGen_CommSetting.ResumeLayout(False)
        Me.GroupBox_PatGen_CommSetting.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents TabControl_Measurement As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Gamma As System.Windows.Forms.TabPage
    Friend WithEvents Button_Gamma_CalculateMean As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Gamma_ExposureTime As System.Windows.Forms.GroupBox
    Friend WithEvents Label_ExposureTime As System.Windows.Forms.Label
    Friend WithEvents NUD_Gamma_ExposureTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents TrackBar_Gamma_ExposureTime As System.Windows.Forms.TrackBar
    Friend WithEvents ListView_Gamma As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Gamma_Level As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Gamma As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_Gamma_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Label_MeanCount As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader_Gamma_Mean As System.Windows.Forms.ColumnHeader
    Friend WithEvents TextBox_Gamma_Mean As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button_CalculateGamma As System.Windows.Forms.Button
    Friend WithEvents TextBox_Gamma_Min As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Gamma_Max As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label_Gamma_Status As System.Windows.Forms.Label
    Friend WithEvents GroupBox_PatGen_CommSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox_PatGen_IPAddress As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_PatGen_Port As System.Windows.Forms.TextBox
    Friend WithEvents Button_PatGen_Connect As System.Windows.Forms.Button
    Friend WithEvents Button_SignalOn As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox_R_Square As System.Windows.Forms.TextBox
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Gamma_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_PatGen_Model As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage_VCom As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_BackLight As System.Windows.Forms.TabPage
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_VCom_P1 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_VCom_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_VCom_P2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Button_VCom_AddOne As System.Windows.Forms.Button
    Friend WithEvents ListView_VCom As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_VCom_Level As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_VCom_Mean As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button_VCom_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents GroupBox_VCom_Manual As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_VCom As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBox_VCom_Result As System.Windows.Forms.TextBox
    Friend WithEvents Button_CalculateVCom As System.Windows.Forms.Button
    Friend WithEvents GroupBox_BL_ExposureTime As System.Windows.Forms.GroupBox
    Friend WithEvents Button_BL_CalculateMean As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox_BL_Mean As System.Windows.Forms.TextBox
    Friend WithEvents NUD_BL_ExposureTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TrackBar_BL_ExposureTime As System.Windows.Forms.TrackBar
    Friend WithEvents TextBox_VCom_Max As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox_VCom_Min As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_BL_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_BL_Max As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox_BL_Min As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label_VCom_Status As System.Windows.Forms.Label
    Friend WithEvents Label_BL_Status As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Gamma_Mannual As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_Gamma_Level As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Button_Gamma_AddOne As System.Windows.Forms.Button
    Friend WithEvents Button_Gamma_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents TextBox_Gamma_Counts As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_VCom_ExposureTime As System.Windows.Forms.GroupBox
    Friend WithEvents Button_VCom_CalculateMean As System.Windows.Forms.Button
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox_VCom_Mean As System.Windows.Forms.TextBox
    Friend WithEvents NUD_VCom_ExposureTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TrackBar_VCom_ExposureTime As System.Windows.Forms.TrackBar
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TextBox_VCom_Standard As System.Windows.Forms.TextBox

End Class
