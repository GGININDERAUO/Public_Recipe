Imports MILOperationLib
Imports AUO.SubSystemControl
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL

Imports System.IO
Imports ClassLibrary
Imports AUO.Cell.PatGenIOIF

<CLSCompliant(False)> _
Public Class Dialog_CalculateMeasurement
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_MeasProcess As ClsMeasProcess
    Private m_Have_MDigitizer As Boolean
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_Grab_OK As Boolean
    Private m_ReadWriteLock As New System.Threading.ReaderWriterLock()
    Private m_ReadyToUpdateImage As Boolean

    '--- PatGen ---
    Private m_PatGen_SignalOn As Boolean
    Private m_PatGen_Connected As Boolean

    '--- �s�u�Ѽ� ---PatGen_SignalOn
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form)
        Dim image As MIL_ID = M_NULL
        Dim PatternName As String

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_FuncProcess = form.MainProcess.FuncProcess
        Me.m_MuraProcess = form.MainProcess.MuraProcess
        Me.m_MeasProcess = form.MainProcess.MeasProcess
        Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig


        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- ���� Func �Ĥ@�� Pattern ---
        Me.m_Form.SetPatternIndex(Me.m_MuraProcess.MuraPatternRecipeArray.Count + 1)
        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.m_Form.GetPatternNameInfo

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_CalculateMeasurement.SetMainForm]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.SetMainForm]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_CalculateMeasurement.SetMainForm]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Check Digitizer  ==> Request_Command = "CHECK_DIGITIZER" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CHECK_DIGITIZER"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                If SubSystemResult.Responses(0).Param1.ToUpper = "TRUE" Then
                    Me.m_Have_MDigitizer = True
                Else
                    Me.m_Have_MDigitizer = False
                End If
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Check Digitizer Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_CalculateMeasurement.SetMainForm]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.SetMainForm]Check Digitizer Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_CalculateMeasurement.SetMainForm]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Try
            If Me.m_IPBootConfig.MuraUI.Value AndAlso Me.m_IPBootConfig.FuncUI.Value Then
                If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                    image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                Else
                    image = Me.m_FuncProcess.Img_Original_NonPage
                End If
            ElseIf Me.m_IPBootConfig.FuncUI.Value And Not Me.m_IPBootConfig.MuraUI.Value Then
                image = Me.m_FuncProcess.Img_Original_NonPage
            ElseIf Me.m_IPBootConfig.MuraUI.Value And Not Me.m_IPBootConfig.FuncUI.Value Then
                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
            End If

            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If

            Me.m_Form.ImageZoomAll()
            Me.UpdateUserLevel()

            If Me.m_Have_MDigitizer Then
                Me.GroupBox_Gamma_ExposureTime.Enabled = True
                Me.GroupBox_VCom_ExposureTime.Enabled = True
                Me.GroupBox_BL_ExposureTime.Enabled = True
            Else
                Me.GroupBox_Gamma_ExposureTime.Enabled = False
                Me.GroupBox_VCom_ExposureTime.Enabled = False
                Me.GroupBox_BL_ExposureTime.Enabled = False
            End If

            If Me.m_MeasProcess.PatGen Is Nothing Then Me.m_MeasProcess.PatGen = New ClsPatGenIOIF(Me.m_MeasProcess.CheckCommType(Me.m_MeasProcess.MeasBootConfig.PatGen_CommType.Value)) '209/09/16 Rick add

            If Not Me.m_MeasProcess.PatGen Is Nothing Then
                GroupBox_PatGen_CommSetting.Enabled = True
            Else
                GroupBox_PatGen_CommSetting.Enabled = False
            End If

            '--- UpdateDate --- '2010/08/16 Rick add (������̫�)
            Me.m_ReadyToUpdateImage = False
            Me.UpdateData()

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.SetMainForm]" & ex.Message)
        End Try
    End Sub

    Private Sub Dialog_CalculateMeasurement_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing

        If Not Me.m_MeasProcess.PatGen Is Nothing And Me.m_PatGen_Connected Then
            Me.PatGen_SignalOn(False)
            Me.PatGen_Disconnect()
        End If

        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.m_Form.Focus()
        Me.Finalize()
    End Sub
#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        'Select Case Me.m_MainProcess.UserLevel
        '    Case 0 'OP
        '        Me.GroupBox_Analysis.Enabled = False
        '        Me.GroupBox_ExposureTime.Enabled = False
        '        Me.GroupBox_Mode.Enabled = False
        '    Case 1 'PM
        '        Me.GroupBox_Analysis.Enabled = True
        '        Me.GroupBox_ExposureTime.Enabled = True
        '        Me.GroupBox_Mode.Enabled = True
        '    Case 2 'ENG
        '        Me.GroupBox_Analysis.Enabled = True
        '        Me.GroupBox_ExposureTime.Enabled = True
        '        Me.GroupBox_Mode.Enabled = True
        '    Case 3 'ALL
        '        Me.GroupBox_Analysis.Enabled = True
        '        Me.GroupBox_ExposureTime.Enabled = True
        '        Me.GroupBox_Mode.Enabled = True
        'End Select
    End Sub
#End Region

#Region "--- Gamma_UpdateExposureTime ---"
    Public Sub Gamma_UpdateExposureTime()
        If Me.m_Have_MDigitizer Then

            '--- �n���ɶ��̤p�ݨD 16000 ---
            'If Me.m_MainProcess.MeasProcess.MeasModelRecipe.Gamma_ExposureTime.Value < 16000 Then Me.m_MainProcess.MeasProcess.MeasModelRecipe.Gamma_ExposureTime.Value = 16000 '2010/11/23 Rick add
            Me.TrackBar_Gamma_ExposureTime.Value = Me.m_MainProcess.MeasProcess.MeasModelRecipe.Gamma_ExposureTime.Value
        End If
    End Sub
#End Region

#Region "--- VCom_UpdateExposureTime ---"
    Public Sub VCom_UpdateExposureTime()
        If Me.m_Have_MDigitizer Then

            '--- �n���ɶ��̤p�ݨD 16000 ---
            'If Me.m_MainProcess.MeasProcess.MeasModelRecipe.VCom_ExposureTime.Value < 16000 Then Me.m_MainProcess.MeasProcess.MeasModelRecipe.VCom_ExposureTime.Value = 16000 '2010/11/23 Rick add
            Me.TrackBar_VCom_ExposureTime.Value = Me.m_MainProcess.MeasProcess.MeasModelRecipe.VCom_ExposureTime.Value
        End If
    End Sub
#End Region

#Region "--- BL_UpdateExposureTime ---"
    Public Sub BL_UpdateExposureTime()
        If Me.m_Have_MDigitizer Then

            '--- �n���ɶ��̤p�ݨD 16000 ---
            'If Me.m_MainProcess.MeasProcess.MeasModelRecipe.BL_ExposureTime.Value < 16000 Then Me.m_MainProcess.MeasProcess.MeasModelRecipe.BL_ExposureTime.Value = 16000 '2010/11/23 Rick add
            Me.TrackBar_BL_ExposureTime.Value = Me.m_MainProcess.MeasProcess.MeasModelRecipe.BL_ExposureTime.Value
        End If
    End Sub
#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Try

            '--- �q�T�]�w ---
            Me.TextBox_PatGen_IPAddress.Text = Me.m_MeasProcess.MeasBootConfig.PatGen_IP.Value
            Me.TextBox_PatGen_Port.Text = Me.m_MeasProcess.MeasBootConfig.PatGen_Port.Value
            Me.ComboBox_PatGen_Model.Text = Me.m_MeasProcess.MeasBootConfig.PatGen_Model.Value
            Me.Button_PatGen_Connect.Text = "Connect"

            Me.Button_SignalOn.Text = "Signal Off"
            Me.Button_SignalOn.BackColor = Color.Red
            Me.m_PatGen_SignalOn = False

            '--- �Ĥ@�� ---(Measurement Gamma) ---
            Me.TrackBar_Gamma_ExposureTime.Maximum = Me.NUD_Gamma_ExposureTime.Maximum
            Me.NUD_Gamma_ExposureTime.Value = Me.m_MeasProcess.MeasModelRecipe.Gamma_ExposureTime.Value
            Me.TrackBar_Gamma_ExposureTime.Value = Me.NUD_Gamma_ExposureTime.Value
            Me.ComboBox_Gamma_Pattern.Text = Me.m_MeasProcess.MeasModelRecipe.Gamma_Pattern.Value
            Me.TextBox_Gamma_Counts.Text = Me.m_MeasProcess.MeasGammaArray.Count
            Me.TextBox_Gamma_Min.Text = Me.m_MeasProcess.MeasPatternRecipe.Gamma_Min.Value
            Me.TextBox_Gamma_Max.Text = Me.m_MeasProcess.MeasPatternRecipe.Gamma_Max.Value

            Me.Button_CalculateGamma.Enabled = False
            Me.MeasGammaListReflash()

            '�ĤG��(Measurement VCom) ---
            Me.TrackBar_VCom_ExposureTime.Maximum = Me.NUD_VCom_ExposureTime.Maximum
            Me.NUD_VCom_ExposureTime.Value = Me.m_MeasProcess.MeasModelRecipe.VCom_ExposureTime.Value
            Me.TrackBar_VCom_ExposureTime.Value = Me.NUD_VCom_ExposureTime.Value
            Me.ComboBox_VCom_P1.Text = CStr(Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_1.Value)
            Me.ComboBox_VCom_P2.Text = CStr(Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_2.Value)
            Me.TextBox_VCom_Standard.Text = CStr(Me.m_MeasProcess.MeasModelRecipe.VCom_Standard.Value)
            Me.TextBox_VCom_Min.Text = CStr(Me.m_MeasProcess.MeasPatternRecipe.VCom_Min.Value)
            Me.TextBox_VCom_Max.Text = CStr(Me.m_MeasProcess.MeasPatternRecipe.VCom_Max.Value)

            Me.Button_CalculateVCom.Enabled = False
            Me.MeasVComListReflash()

            '�ĤT��(Measurement Back Light) ---
            Me.TrackBar_BL_ExposureTime.Maximum = Me.NUD_BL_ExposureTime.Maximum
            Me.NUD_BL_ExposureTime.Value = Me.m_MeasProcess.MeasModelRecipe.BL_ExposureTime.Value
            Me.TrackBar_BL_ExposureTime.Value = Me.NUD_BL_ExposureTime.Value
            Me.TextBox_BL_Min.Text = CStr(Me.m_MeasProcess.MeasPatternRecipe.BL_Min.Value)
            Me.TextBox_BL_Max.Text = CStr(Me.m_MeasProcess.MeasPatternRecipe.BL_Max.Value)

            '--- ReadyToGrab ---
            Me.m_ReadyToUpdateImage = True

        Catch ex As Exception
            MsgBox("[Dialog_CalculateMeasureMent.UpdataData] �ѼƸ��JForm�X���G" & vbCrLf & ex.Message & "�A�нT�{�C", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)   '2010/12/24 Rick add
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Setting ---"
    Public Sub Setting()
        Try
            '--- �q�T�]�w ---
            If Me.TextBox_PatGen_IPAddress.Text <> "" Then Me.m_MeasProcess.MeasBootConfig.PatGen_IP.Value = Me.TextBox_PatGen_IPAddress.Text
            If Me.TextBox_PatGen_Port.Text = 0 Or Me.TextBox_PatGen_Port.Text = "" Then Me.TextBox_PatGen_Port.Text = "8001"
            If Me.TextBox_PatGen_Port.Text <> "" Then Me.m_MeasProcess.MeasBootConfig.PatGen_Port.Value = Me.TextBox_PatGen_Port.Text
            If Me.ComboBox_PatGen_Model.Text <> "" Then Me.m_MeasProcess.MeasBootConfig.PatGen_Model.Value = Me.ComboBox_PatGen_Model.Text

            '--- �Ĥ@�� ---(Measurement Gamma) ---
            'If Me.NUD_Gamma_ExposureTime.Value < 16000 Then Me.NUD_Gamma_ExposureTime.Value = 16000
            Me.m_MeasProcess.MeasModelRecipe.Gamma_ExposureTime.Value = Me.NUD_Gamma_ExposureTime.Value
            If Me.ComboBox_Gamma_Pattern.Text <> "" Then Me.m_MeasProcess.MeasModelRecipe.Gamma_Pattern.Value = Me.ComboBox_Gamma_Pattern.Text
            If Me.TextBox_Gamma_Min.Text <> "" Then Me.m_MeasProcess.MeasPatternRecipe.Gamma_Min.Value = Me.TextBox_Gamma_Min.Text
            If Me.TextBox_Gamma_Max.Text <> "" Then Me.m_MeasProcess.MeasPatternRecipe.Gamma_Max.Value = Me.TextBox_Gamma_Max.Text

            '�ĤG��(Measurement VCom) ---
            'If Me.NUD_VCom_ExposureTime.Value < 16000 Then Me.NUD_VCom_ExposureTime.Value = 16000
            Me.m_MeasProcess.MeasModelRecipe.VCom_ExposureTime.Value = Me.NUD_VCom_ExposureTime.Value
            If Me.ComboBox_VCom_P1.Text <> "" Then Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_1.Value = Me.ComboBox_VCom_P1.Text
            If Me.ComboBox_VCom_P2.Text <> "" Then Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_2.Value = Me.ComboBox_VCom_P2.Text
            If Me.TextBox_VCom_Standard.Text <> "" Then Me.m_MeasProcess.MeasModelRecipe.VCom_Standard.Value = Me.TextBox_VCom_Standard.Text
            If Me.TextBox_VCom_Min.Text <> "" Then Me.m_MeasProcess.MeasPatternRecipe.VCom_Min.Value = Me.TextBox_VCom_Min.Text
            If Me.TextBox_VCom_Max.Text <> "" Then Me.m_MeasProcess.MeasPatternRecipe.VCom_Max.Value = Me.TextBox_VCom_Max.Text

            '�ĤT��(Measurement Back Light) ---
            'If Me.NUD_BL_ExposureTime.Value < 16000 Then Me.NUD_BL_ExposureTime.Value = 16000
            Me.m_MeasProcess.MeasModelRecipe.BL_ExposureTime.Value = Me.NUD_BL_ExposureTime.Value
            If Me.TextBox_BL_Min.Text <> "" Then Me.m_MeasProcess.MeasPatternRecipe.BL_Min.Value = Me.TextBox_BL_Min.Text
            If Me.TextBox_BL_Max.Text <> "" Then Me.m_MeasProcess.MeasPatternRecipe.BL_Max.Value = Me.TextBox_BL_Max.Text

        Catch ex As Exception
            MsgBox("[Dialog_CalculateMeasureMent.Setting] �Ѽ��x�s�X���G" & vbCrLf & ex.Message & "�A�нT�{�C", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try
    End Sub
#End Region

#Region "--- UpdateGrabImage ---"
    Public Sub UpdateGrabImage(ByVal ShowImage As Boolean)
        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
            End If

            If System.IO.File.Exists(strPath) Then
                Directory.CreateDirectory(strPath)
            End If

            Me.m_ReadWriteLock.AcquireReaderLock(Me.m_Grab_OK)
            Me.m_Grab_OK = False
            '----------------------------------------------------------------------------------------------
            ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                SyncLock Me.m_MainProcess.IP_Dispatcher1

                    '--- Prepare Command ---
                    Request_Command = "GRAB_ONESHOT"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                End SyncLock

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_CalculateMeasurement.UpdateGrabImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                If ShowImage AndAlso Response_OK Then
                    '--- Update Processed Image ---
                    Image = Me.m_MainProcess.Img_16U_Grab_1
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Image <> M_NULL Then
                            If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Image)
                                Image = M_NULL
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Image)
                        MbufCopy(Image, Me.m_MainProcess.Img_Mapping_NonPage)

                        Me.m_Form.ImageUpdate()
                    End If
                End If

                Me.m_Grab_OK = True
            Catch ex As Exception
                Response_OK = False
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_CalculateMeasurement.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_CalculateMeasurement.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        Finally
            Me.m_ReadWriteLock.ReleaseReaderLock()
        End Try

    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Button_Enable (Gamma)---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Gamma_CalculateMean.Enabled = En
        Button_Gamma_AddOne.Enabled = En
        Button_VCom_CalculateMean.Enabled = En
        Button_VCom_AddOne.Enabled = En
        Button_Save.Enabled = En
        Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_2 (VCom)---"
    Private Sub Button_Enable_2(ByVal En As Boolean)
        Button_VCom_CalculateMean.Enabled = En
        Button_VCom_AddOne.Enabled = En
        Button_Save.Enabled = En
        Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_3 (BL)---"
    Private Sub Button_Enable_3(ByVal En As Boolean)
        Button_BL_CalculateMean.Enabled = En
        Button_Save.Enabled = En
        Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- PatGen_Connect ---"
    Function PatGen_Connect() As Boolean
        Dim Rtn As Boolean

        Try
            Rtn = Me.m_MeasProcess.InitPatGen(Me.m_MeasProcess.MeasBootConfig.PatGen_CommType.Value, Me.TextBox_PatGen_IPAddress.Text, CInt(Me.TextBox_PatGen_Port.Text))

            If Rtn Then
                Me.Button_PatGen_Connect.Text = "Disconnect"
                Return True
            Else
                Me.Button_PatGen_Connect.Text = "Connect"
                Return False
            End If

        Catch ex As Exception
            MessageBox.Show("[PatGen_Connect]Connect error: " & ex.Message, "Measurement", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            Return False
        End Try
    End Function
#End Region

#Region "--- PatGen_Disconnect ---"
    Public Sub PatGen_Disconnect()

        Try
            Me.m_MeasProcess.DisconnectPatGen()

            Me.Button_PatGen_Connect.Text = "Connect"
            Me.Button_CalculateGamma.Enabled = False
            Me.Button_CalculateVCom.Enabled = False

        Catch ex As Exception
            MessageBox.Show("[PatGen_Disconnect]DisConnect error: " & ex.Message, "Measurement", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

#End Region

#Region "--- PatGen_SignalOn ---"
    Public Sub PatGen_SignalOn(ByVal Signal_Switch As Boolean)
        Dim Message As String = ""
        Dim Rtn As Boolean

        Try
            Rtn = Me.m_MeasProcess.PatGen_SetSignal(Signal_Switch, Message)
            Me.m_Form.OutputInfo(Message)

            If Rtn Then
                If Signal_Switch Then
                    Me.Button_SignalOn.Text = "Signal On"
                    Me.Button_SignalOn.BackColor = Color.LimeGreen
                    Me.m_PatGen_SignalOn = Rtn
                    Me.Button_CalculateGamma.Enabled = Rtn
                    Me.Button_CalculateVCom.Enabled = Rtn
                Else
                    Me.Button_SignalOn.Text = "Signal Off"
                    Me.Button_SignalOn.BackColor = Color.Red
                    Me.m_PatGen_SignalOn = Not Rtn
                    Me.Button_CalculateGamma.Enabled = Not Rtn
                    Me.Button_CalculateVCom.Enabled = Not Rtn
                End If
            Else
                MsgBox("[PatGen_SignalOn]" & Message, MsgBoxStyle.Critical, "OMS")
            End If

        Catch ex As Exception
            Throw New Exception("[PatGen_SignalOn]PatGen Signal On\Off Error: " & ex.Message)
        End Try

    End Sub
#End Region

#Region "--- PatGen_SetPattern ---"
    Public Sub PatGen_SetPattern(ByVal Pattern As String)
        Dim ModelResult As New ArrayList
        Dim PatternName As String
        Dim Signal_Status As String = ""
        Dim Message As String = ""

        Try
            '--- Set Current Pattern 1 ---
            '[Step 1] Check PatGen Signal On ---
            Signal_Status = Me.m_MeasProcess.PatGen_GetSignal(Message)
            If UCase(Signal_Status) = "TURNOFF" Then
                Me.PatGen_SignalOn(True)
            End If

            '[Step 2] Check Current Pattern 1 ---
            Message = ""
            PatternName = Me.m_MeasProcess.PatGen_GetPattern(Message)

            If UCase(PatternName) <> UCase(Pattern) Then
                '[Step 3] Set Current Pattern 1 ---
                Message = ""
                Me.m_MeasProcess.PatGen_SetPattern(Pattern, Message)
                Me.m_Form.OutputInfo(Message)
            Else
                Message &= ("[PatGen] <Pattern Name> = " & PatternName)
                Me.m_Form.OutputInfo(Message)
            End If
        Catch ex As Exception
            Throw New Exception("[PatGen_SetPattern]PatGen Set Pattern Error ! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- MeasGammaListReflash ---"
    Public Sub MeasGammaListReflash()
        Dim ff As ClsMeasGamma
        Dim lvi As ListViewItem
        Dim i As Integer

        ListView_Gamma.Items.Clear()
        Try
            If Me.m_MeasProcess.MeasGammaArray.Count > 0 Then
                For i = 0 To Me.m_MeasProcess.MeasGammaArray.Count - 1
                    ff = Me.m_MeasProcess.MeasGammaArray.GetMeasGamma(i)

                    lvi = Me.ListView_Gamma.Items.Add(ff.Level)
                Next
            End If

        Catch ex As Exception
            Throw New Exception("[Dialog_CalculateMeasurement.MeasGammaListReflash]Reflash Gamma List Error! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- MeasVComListReflash ---"
    Public Sub MeasVComListReflash()
        Dim ff As ClsMeasVCom
        Dim lvi As ListViewItem
        Dim i As Integer

        ListView_VCom.Items.Clear()
        Try
            If Me.m_MeasProcess.MeasVComArray.Count > 0 Then
                For i = 0 To Me.m_MeasProcess.MeasVComArray.Count - 1
                    ff = Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i)

                    lvi = Me.ListView_VCom.Items.Add(ff.VCom)
                Next
            End If

        Catch ex As Exception
            Throw New Exception("[Dialog_CalculateMeasurement.MeasVComListReflash]Reflash VCom List Error! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- get_GrayMean ---"
    Private Sub get_GrayMean(ByVal ExposureTime As Long, ByRef mean As Integer, ByRef Max_GrayMean As Integer, ByRef Total_Blobs As Integer)
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim strs() As String
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If
        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress


        If Me.m_IPBootConfig.CardSystem.Value <> "" AndAlso Me.m_Have_MDigitizer Then

            '----------------------------------------------------------------------------------------------
            ' Update Current Exposure Time  ==> Request_Command = "OMS_UPDATE_EXPOSURETIME" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "OMS_UPDATE_EXPOSURETIME"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ExposureTime, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Digitizer Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_CalculateMeasurement.get_GrayMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.TrackBar_Gamma_ExposureTime.Enabled = True
                    Me.Button_Enable(True)
                    Exit Sub
                End If

                If Response_OK Then
                    Me.UpdateGrabImage(True)
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.get_GrayMean]Update Digitizer Exposure Time Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_CalculateMeasurement.get_GrayMean]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try

        End If

        '----------------------------------------------------------------------------------------------
        ' IP LOAD GRAB IMAGE  ==> Request_Command = "LOAD_GRABIMAGE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "LOAD_GRABIMAGE"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Grab Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_CalculateMeasurement.get_GrayMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Response_OK Then
                '[1] Update Processed Image ---
                image = Me.m_FuncProcess.Img_Original_NonPage   'Func
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If image <> M_NULL Then
                        If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image)
                            image = M_NULL
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, image)
                    MbufCopy(image, Me.m_MainProcess.Img_Mapping_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.get_GrayMean]Func Load Grab Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_CalculateMeasurement.get_GrayMean]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
            image = Me.m_MainProcess.Img_16U_Grab_1
            If image <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                Type = MbufInquire(image, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(image, imageBuffer)

                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                MbufControl(image, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                Me.m_Form.ResetScrollBar()
            End If
        Else
            Me.m_Form.CurrentIndex0 = 0
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 0
        End If

        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        Else
            Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        End If

        '----------------------------------------------------------------------------------------------
        ' Get Gray Mean  ==> Request_Command = "GET_GRAYMEAN" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "GET_GRAYMEAN"
            TimeOut = 500000 '500 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                strs = SubSystemResult.Responses(0).Param2.Split(",")
                mean = strs(1)
                Max_GrayMean = SubSystemResult.Responses(0).Param3
                Total_Blobs = SubSystemResult.Responses(0).Param4
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Gray Mean Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_CalculateMeasurement.get_GrayMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.get_GrayMean]Get Gray Mean Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_CalculateMeasurement.get_GrayMean]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim Parameter_Lists As String
        Dim str As String
        Dim dir As String = ""
        Dim dirPath As String

        Try
            If Me.NUD_Gamma_ExposureTime.Text = "" Then Exit Sub

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable(False)
            Me.Button_CalculateGamma.Enabled = False
            Me.Button_CalculateVCom.Enabled = False

            Me.Setting()

            '----------------------------------------------------------------------------------------------
            ' Dialog_FuncSettingBase Setting   ==> Request_Command = "DIALOG_CALCULATEMEASUREMENT_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_CALCULATEMEASUREMENT_SETTING"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------

                '--- �Ĥ@�� ---
                Parameter_Lists = "PatGen_IPAddress," & Me.TextBox_PatGen_IPAddress.Text & ";" & "PatGen_Port," & Me.TextBox_PatGen_Port.Text & ";" & "PatGen_Model," & Me.ComboBox_PatGen_Model.Text & ";" & _
                                  "Gamma_Pattern," & Me.ComboBox_Gamma_Pattern.Text & ";" & "Gamma_ExposureTime," & Me.NUD_Gamma_ExposureTime.Value & ";" & "Gamma_Min," & Me.TextBox_Gamma_Min.Text & ";" & "Gamma_Max," & Me.TextBox_Gamma_Max.Text & ";"

                '--- �ĤG�� ---
                Parameter_Lists &= "VCom_Pattern_1," & Me.ComboBox_VCom_P1.Text & ";" & "VCom_Pattern_2," & Me.ComboBox_VCom_P2.Text & ";" & "VCom_Standard," & Me.TextBox_VCom_Standard.Text & ";" & "VCom_ExposureTime," & Me.NUD_VCom_ExposureTime.Value & ";" & "VCom_DeltaMean_Min," & Me.TextBox_VCom_Min.Text & ";" & "VCom_DeltaMean_Max," & Me.TextBox_VCom_Max.Text & ";"

                '�ĤT�� ---
                Parameter_Lists &= "BL_ExposureTime," & Me.NUD_BL_ExposureTime.Value & ";" & "BL_Min," & Me.TextBox_BL_Min.Text & ";" & "BL_Max," & Me.TextBox_BL_Max.Text & ";"

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_CalculateMeasurement Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_Dialog_CalculateMeasurement.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)

                    Me.Button_CalculateGamma.Enabled = Me.m_PatGen_Connected
                    Me.Button_CalculateVCom.Enabled = Me.m_PatGen_Connected
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Measurement"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            str = dirPath & "\MeasPatternRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"

            '--- Save Meas Boot Config ---
            Me.m_MainProcess.MeasProcess.SaveMeasBootConfig(Me.m_MainProcess.BootRecipePath)
            Me.m_MeasProcess.SaveAllMeasRecipe(Me.m_MainProcess.IPBootConfig.RecipePath.Value, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
            '----------------------------------------------------------------------------------------------
            ' Save All Meas Recipe  ==> Request_Command = "SAVE_ALL_MEAS_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_ALL_MEAS_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Meas Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_Dialog_CalculateMeasurement.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)

                    Me.Button_CalculateGamma.Enabled = Me.m_PatGen_Connected
                    Me.Button_CalculateVCom.Enabled = Me.m_PatGen_Connected
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Button_Enable(True)
            Me.Button_CalculateGamma.Enabled = Me.m_PatGen_Connected
            Me.Button_CalculateVCom.Enabled = Me.m_PatGen_Connected

            '--- Meas Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_MeasProcess.SaveToMeasRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo)

        Catch ex As Exception
            Button_Enable(True)
            Me.Button_CalculateGamma.Enabled = Me.m_PatGen_Connected
            Me.Button_CalculateVCom.Enabled = Me.m_PatGen_Connected
            Me.m_Form.OutputInfo("[Dialog_Dialog_CalculateMeasurement.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_Dialog_CalculateMeasurement.Button_Save]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Close ---"
    Private Sub Button_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel

        Try
            If Not Me.m_MeasProcess.MeasModelRecipe Is Nothing Then
                If Me.m_PatGen_SignalOn Then
                    Me.PatGen_SignalOn(False)
                End If

                If Me.m_PatGen_Connected Then
                    Me.PatGen_Disconnect()
                    Me.m_PatGen_Connected = False
                    Me.m_Form.OutputInfo("[PatGen] Disconnect PatGen !")
                End If
            End If

            Me.Close()
        Catch ex As Exception
            MsgBox("Close Dialog_CalculateMeasurement Error !( " & ex.Message & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.Close()
        End Try
    End Sub
#End Region

#Region "--- Button_Gamma_CalculateMean ---"
    Private Sub Button_Gamma_CalculateMean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Gamma_CalculateMean.Click
        Dim mean As Integer
        Dim Gray_max As Integer
        Dim blobnum As Integer

        Me.Button_Gamma_CalculateMean.Enabled = False
        Me.TextBox_Gamma_Mean.Text = ""

        Try
            Me.get_GrayMean(Me.NUD_Gamma_ExposureTime.Value, mean, Gray_max, blobnum)

            Me.TextBox_Gamma_Mean.Text = CStr(mean)

            Me.Button_Gamma_CalculateMean.Enabled = True
        Catch ex As Exception
            Me.Button_Gamma_CalculateMean.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.Button_Gamma_CalculateMean]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Button_VCom_CalculateMean ---"
    Private Sub Button_VCom_CalculateMean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_VCom_CalculateMean.Click
        Dim mean As Integer
        Dim Gray_max As Integer
        Dim blobnum As Integer

        Me.Button_VCom_CalculateMean.Enabled = False
        Me.TextBox_VCom_Mean.Text = ""

        Try
            Me.get_GrayMean(Me.NUD_VCom_ExposureTime.Value, mean, Gray_max, blobnum)

            Me.TextBox_VCom_Mean.Text = CStr(mean)

            Me.Button_VCom_CalculateMean.Enabled = True
        Catch ex As Exception
            Me.Button_VCom_CalculateMean.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.Button_VCom_CalculateMean]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Button_BL_CalculateMean ---"
    Private Sub Button_BL_CalculateMean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_BL_CalculateMean.Click
        Dim mean As Integer
        Dim Gray_max As Integer
        Dim blobnum As Integer

        Me.Button_BL_CalculateMean.Enabled = False
        Me.TextBox_BL_Mean.Text = ""

        Try
            Me.get_GrayMean(Me.NUD_BL_ExposureTime.Value, mean, Gray_max, blobnum)

            Me.TextBox_BL_Mean.Text = CStr(mean)

            Me.Button_BL_CalculateMean.Enabled = True

            If (Val(TextBox_BL_Min.Text) < Val(Me.TextBox_BL_Mean.Text)) And (Val(TextBox_BL_Max.Text) > Val(Me.TextBox_BL_Mean.Text)) Then
                Me.Label_BL_Status.Text = "OK"
            Else
                Me.Label_BL_Status.Text = "NG"
            End If

        Catch ex As Exception
            Me.Button_BL_CalculateMean.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.Button_BL_CalculateMean]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Button_CalculateGamma ---"
    Private Sub Button_CalculateGamma_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_CalculateGamma.Click
        Dim GrayLevel As Integer
        Dim Mean_List() As Integer
        Dim MeanLists As String = ""
        Dim lvi As ListViewItem
        Dim i As Integer
        Dim Gamma_Counts As Integer
        Dim Message As String = ""
        Dim strs() As String


        If Me.m_MeasProcess.MeasGammaArray.Count < 9 Then
            MsgBox("�ثe�`���� " & Me.m_MeasProcess.MeasGammaArray.Count & ", �ܤֻݭn 8+1 ����� !", MsgBoxStyle.Critical, "[OMS]")
            Exit Sub
        End If

        ReDim Mean_List(Me.m_MeasProcess.MeasGammaArray.Count)

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable(False)
            Me.Button_CalculateGamma.Enabled = False

            '--- Initial Meas Array ---
            Me.ListView_Gamma.Items.Clear()

            If Me.m_IPBootConfig.CardSystem.Value <> "" Then

                If Me.m_Have_MDigitizer Then

                    '----------------------------------------------------------------------------------------------
                    ' Update Current Exposure Time  ==> Request_Command = "OMS_UPDATE_EXPOSURETIME" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "OMS_UPDATE_EXPOSURETIME"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NUD_Gamma_ExposureTime.Value, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Response_OK = False
                            Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Digitizer Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateGamma]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.TrackBar_Gamma_ExposureTime.Enabled = True
                            Me.Button_Enable(True)
                            Me.Button_CalculateGamma.Enabled = True
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If
            Else
                Throw New Exception("IPBootConfig �ɮפ�, ���]�w CardSystem, �ΨS�������d")
            End If


            If Not Response_OK Then
                MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateGamma]Update Digitizer Exposure Time Error !", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Me.Button_Enable(True)
                Me.Button_CalculateGamma.Enabled = True
                Exit Sub
            End If

            '--- Set Current Pattern 1 ---

            Me.PatGen_SetPattern(Me.ComboBox_Gamma_Pattern.Text)

            '--- �s��p�� Gamma_Counts �� Mean ---
            Gamma_Counts = Me.m_MeasProcess.MeasGammaArray.Count - 1
            For i = 0 To Gamma_Counts

                GrayLevel = Me.m_MeasProcess.MeasGammaArray.GetMeasGamma(i).Level

                If GrayLevel > 255 Then
                    GrayLevel = 255
                End If

                Me.m_MeasProcess.PatGen_SetColor("W", GrayLevel, Message)
                Me.m_Form.OutputInfo(Message)
                System.Threading.Thread.Sleep(200)

                '--- ���� ---    
                Me.UpdateGrabImage(False)

                '�p�� Mean �� ---
                '----------------------------------------------------------------------------------------------
                ' Get Gray Mean  ==> Request_Command = "GET_GRAYMEAN" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "GET_GRAYMEAN"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        strs = SubSystemResult.Responses(0).Param2.Split(",")
                        Mean_List(i) = strs(1)
                        MeanLists = MeanLists & CStr(GrayLevel) & "," & CStr(Mean_List(i)) & ";"

                        '--- Add to ListVew ---
                        lvi = Me.ListView_Gamma.Items.Add(CStr(GrayLevel))
                        lvi.SubItems.Add(Mean_List(i))
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Gray Mean Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable(True)
                        Me.Button_CalculateGamma.Enabled = True
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                If i = 1 AndAlso Mean_List(i) <= 0 Then
                    MessageBox.Show("[Calculate Gamma]The 2nd Gray Mean can't lower than 1,and increase the exposure time. (==> �հ��n���ɶ�, ���ˬd���O�O�_ Contact !)", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Me.Button_CalculateGamma.Enabled = True
                    Exit Sub
                End If

                Application.DoEvents()
            Next

            MeanLists = MeanLists & "$"

            '--- �p�� Gamma �� ---
            '----------------------------------------------------------------------------------------------
            ' Get Gamma Value  ==> Request_Command = "CALCULATE_GAMMA_OFFLINE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_GAMMA_OFFLINE"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, MeanLists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                    strs = SubSystemResult.Responses(0).Param1.Split(",")
                    Me.TextBox_Gamma.Text = Format(CDbl(strs(0)), "0.####")    'Gamma
                    Me.TextBox_R_Square.Text = Format(Val(SubSystemResult.Responses(0).Param2), "0.####")  'R-square

                    If (Val(Me.TextBox_Gamma.Text) >= Val(Me.TextBox_Gamma_Min.Text)) And (Val(Me.TextBox_Gamma.Text) < Val(Me.TextBox_Gamma_Max.Text)) Then
                        Me.Label_Gamma_Status.Text = "OK"
                    Else
                        Me.Label_Gamma_Status.Text = "NG"
                    End If
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Gray Mean Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateGamma]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Me.Button_CalculateGamma.Enabled = True
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If (TextBox_Gamma_Min.Text < Me.TextBox_Gamma.Text) And (TextBox_Gamma_Max.Text > Me.TextBox_Gamma.Text) Then
                Me.Label_Gamma_Status.Text = "OK"
            Else
                Me.Label_Gamma_Status.Text = "NG"
            End If

            Me.Button_Enable(True)
            Me.Button_CalculateGamma.Enabled = True
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.Button_CalculateGamma.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.Button_CalculateGamma]Calculate Gamma Error!(" & ex.Message & ")")
        End Try

    End Sub
#End Region

#Region "--- Button_PatGen_Connect ---"
    Private Sub Button_PatGen_Connect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_PatGen_Connect.Click
        Dim ModelResult As New ArrayList
        Dim CurrentModelIndex As Integer = 0
        Dim PatternResult As New ArrayList
        Dim CurrentPatternIndex As Integer = 0
        Dim i As Integer
        Dim Message As String = ""
        Dim Signal_Status As String = ""

        If Me.m_MeasProcess.PatGen Is Nothing Then Me.m_MeasProcess.PatGen = New ClsPatGenIOIF(Me.m_MeasProcess.CheckCommType(Me.m_MeasProcess.MeasBootConfig.PatGen_CommType.Value)) '209/09/16 Rick add

        If Me.m_MeasProcess.PatGen.IsConnect Then

            '[Step 1]Signal Off PatGen  ---
            Signal_Status = Me.m_MeasProcess.PatGen_GetSignal(Message)
            If UCase(Signal_Status) = "TURNON" Then
                Me.PatGen_SignalOn(False)
            End If
            Me.m_PatGen_SignalOn = False
            Me.m_Form.OutputInfo("[PatGen] PatGen Signal Off !")

            '[Step 2]Disconnect PatGen  ---
            Me.PatGen_Disconnect()
            Me.m_PatGen_Connected = False
            Me.m_Form.OutputInfo("[PatGen] Disconnect PatGen !")
        Else
            Me.m_PatGen_Connected = Me.PatGen_Connect()

            If Me.m_PatGen_Connected Then


                'Step 1:[PatGen][Get All Model] ---
                Try
                    Me.m_MeasProcess.PatGen_GetAllModel(ModelResult, Message)
                    'Me.m_Form.OutputInfo(Message)   ��ܩҦ�Pattern �� OutputInfo

                    For i = Me.ComboBox_PatGen_Model.Items.Count - 1 To 0 Step -1
                        Me.ComboBox_PatGen_Model.Items.RemoveAt(i)
                    Next
                    For i = 0 To ModelResult.Count() - 1
                        Me.ComboBox_PatGen_Model.Items.Insert(i, ModelResult(i))

                        If ModelResult(i) = Me.m_MeasProcess.MeasBootConfig.PatGen_Model.Value Then
                            CurrentModelIndex = i
                        End If
                    Next

                    Me.ComboBox_PatGen_Model.SelectedIndex = CurrentModelIndex
                Catch ex As Exception
                    MessageBox.Show("[PatGen] PatGen Get All Model Fail ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End Try

                'Step 2:[PatGen][Get All Pattern] ---
                Try
                    Message = ""
                    Me.m_MeasProcess.PatGen_GetAllPattern(PatternResult, Message)
                    'Me.m_Form.OutputInfo(Message)  '��ܩҦ�Pattern �� OutputInfo

                    '--- Gamma ---
                    For i = Me.ComboBox_Gamma_Pattern.Items.Count - 1 To 0 Step -1
                        Me.ComboBox_Gamma_Pattern.Items.RemoveAt(i)
                    Next
                    For i = 0 To PatternResult.Count() - 1
                        Me.ComboBox_Gamma_Pattern.Items.Insert(i, PatternResult(i))

                        If PatternResult(i) = Me.m_MeasProcess.MeasModelRecipe.Gamma_Pattern.Value Then
                            CurrentPatternIndex = i
                        End If
                    Next

                    Me.ComboBox_Gamma_Pattern.SelectedIndex = CurrentPatternIndex

                    '--- VCom ----------------------------------------------
                    '--- P1 ---
                    For i = Me.ComboBox_VCom_P1.Items.Count - 1 To 0 Step -1
                        Me.ComboBox_VCom_P1.Items.RemoveAt(i)
                    Next
                    For i = 0 To PatternResult.Count() - 1
                        Me.ComboBox_VCom_P1.Items.Insert(i, PatternResult(i))

                        If PatternResult(i) = Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_1.Value Then
                            CurrentPatternIndex = i
                        End If
                    Next

                    Me.ComboBox_VCom_P1.SelectedIndex = CurrentPatternIndex

                    '--- P2 ---
                    For i = Me.ComboBox_VCom_P2.Items.Count - 1 To 0 Step -1
                        Me.ComboBox_VCom_P2.Items.RemoveAt(i)
                    Next
                    For i = 0 To PatternResult.Count() - 1
                        Me.ComboBox_VCom_P2.Items.Insert(i, PatternResult(i))

                        If PatternResult(i) = Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_2.Value Then
                            CurrentPatternIndex = i
                        End If
                    Next

                    Me.ComboBox_VCom_P2.SelectedIndex = CurrentPatternIndex

                Catch ex As Exception
                    MessageBox.Show("[PatGen] PatGen Get All Pattern Fail ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End Try

                '--- Gamma ---
                Me.GroupBox_Gamma_Setting.Enabled = Me.m_PatGen_SignalOn
                Me.Button_CalculateGamma.Enabled = Me.m_PatGen_SignalOn

                '--- VCom ---
                Me.GroupBox_VCom_Setting.Enabled = Me.m_PatGen_SignalOn
                Me.Button_CalculateVCom.Enabled = Me.m_PatGen_SignalOn

                Me.m_Form.OutputInfo("[PatGen] Connect PatGen Success !(IP:" & Me.TextBox_PatGen_IPAddress.Text & "\Port:" & Me.TextBox_PatGen_Port.Text & ")")
            Else

                Me.m_Form.OutputInfo("[PatGen] Connect PatGen Fail !(IP:" & Me.TextBox_PatGen_IPAddress.Text & "\Port:" & Me.TextBox_PatGen_Port.Text & ")")
            End If


        End If

    End Sub
#End Region

#Region "--- Button_SignalOn ---"

    Private Sub Button_SignalOn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SignalOn.Click
        Try
            Me.PatGen_SignalOn(Not Me.m_PatGen_SignalOn)
            If Me.m_MeasProcess.MeasBootConfig.PatGen_Model.Value = "" Then MsgBox("���]�w PatGen's Model, �Х�����U�� Get All Model ���s ,�ð��� Set Model���s", MsgBoxStyle.Critical, "[OMS]")
        Catch ex As Exception
            MessageBox.Show("[Dialog_CalculateMeasurement.Button_SignalOn]PatGen Signal Switch Error ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

#End Region

#Region "--- Button_PatGen_SetModel ---"

    Private Sub Button_PatGen_SetModel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim ModelResult As New ArrayList
        Dim Message As String = ""

        Try
            If Me.ComboBox_PatGen_Model.Text <> "" Then

                Me.m_MeasProcess.PatGen_SetModel(Me.ComboBox_PatGen_Model.Text, Message)
                Me.m_Form.OutputInfo(Message)
                Me.PatGen_SignalOn(True)

            Else
                MsgBox("�Х���� PatGen's Model ,�Υ����� Get All Model ���s !", MsgBoxStyle.Critical, "[AreaGrabber]")
            End If
        Catch ex As Exception
            MessageBox.Show("[Dialog_CalculateMeasurement.Button_PatGen_SetModel]Set PatGen Model Error ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

#End Region

#Region "--- Button_Gamma_AddOne ---"

    Private Sub Button_Gamma_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Gamma_AddOne.Click
        Dim pb As New ClsMeasGamma
        Dim strPath As String
        Dim lvi As ListViewItem
        Dim Level_Count As Integer

        Try
            If Me.TextBox_Gamma_Level.Text = "" Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable(False)

            If Me.TextBox_Gamma_Level.Text <> "" Then

                '--- �T�{��e�@������٤j ---
                Level_Count = Me.m_MeasProcess.MeasGammaArray.Count
                If Level_Count > 1 Then
                    If Val(Me.TextBox_Gamma_Level.Text) < Me.m_MeasProcess.MeasGammaArray.GetMeasGamma(Level_Count - 1).Level Then
                        MsgBox("�̷s�@����ƥ�����e�@������٤j,�_�h�����\�[�J !", MsgBoxStyle.Critical, "[OMS]")
                        Me.Button_Enable(True)
                        Exit Sub
                    End If

                    If Val(Me.TextBox_Gamma_Level.Text) > 255 Then
                        MsgBox("Level��,�����\�[�J�W�L 255 �Ƕ� !", MsgBoxStyle.Critical, "[OMS]")
                        Me.Button_Enable(True)
                        Exit Sub
                    End If
                End If

                pb.Level = Val(Me.TextBox_Gamma_Level.Text)
                Me.m_MeasProcess.MeasGammaArray.Add(pb)
                lvi = Me.ListView_Gamma.Items.Add(Me.TextBox_Gamma_Level.Text)
                lvi.SubItems.Add("")

                Me.TextBox_Gamma_Counts.Text = Me.m_MeasProcess.MeasGammaArray.Count
                Me.TextBox_Gamma_Level.Text = ""
            End If

            '--- Save Meas Gamma datum ---
            strPath = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Measurement\MeasGamma_C" & Me.m_MainProcess.GrabNo & ".txt"
            Me.m_MeasProcess.SaveMeasGamma(strPath)

            '--- Enable Button ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_CalculateMeasurement.Button_Gamma_AddOne]" & ex.Message)
            MessageBox.Show("[Dialog_CalculateMeasurement.Button_Gamma_AddOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- Button_VCom_AddOne ---"
    Private Sub Button_VCom_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_VCom_AddOne.Click
        Dim pb As New ClsMeasVCom
        Dim strPath As String
        Dim lvi As ListViewItem
        Dim VCom_Count As Integer

        Try
            If Me.TextBox_VCom.Text = "" Then
                Exit Sub
            End If

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_2(False)

            If Me.TextBox_VCom.Text <> "" Then

                '--- �T�{��e�@������٤j ---
                VCom_Count = Me.m_MeasProcess.MeasVComArray.Count
                If VCom_Count > 1 Then
                    If Val(Me.TextBox_VCom.Text) < Me.m_MeasProcess.MeasVComArray.GetMeasVCom(VCom_Count - 1).VCom Then
                        MsgBox("�̷s�@����ƥ�����e�@������٤j,�_�h�����\�[�J !", MsgBoxStyle.Critical, "[OMS]")
                        Me.Button_Enable(True)
                        Exit Sub
                    End If
                End If

                pb.VCom = Val(Me.TextBox_VCom.Text)
                Me.m_MeasProcess.MeasVComArray.Add(pb)
                lvi = Me.ListView_VCom.Items.Add(Me.TextBox_VCom.Text)
                lvi.SubItems.Add("")

                Me.TextBox_VCom.Text = ""

            End If

            '--- Save Meas VCom datum ---
            strPath = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Measurement\MeasVCom_C" & Me.m_MainProcess.GrabNo & ".txt"
            Me.m_MeasProcess.SaveMeasVCom(strPath)

            '--- Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_CalculateMeasurement.Button_VCom_AddOne]" & ex.Message)
            MessageBox.Show("[Dialog_CalculateMeasurement.Button_VCom_AddOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_VCom_DeleteOne ---"
    Private Sub Button_VCom_DeleteOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_VCom_DeleteOne.Click
        Dim pb As New ClsMeasVCom
        Dim strPath As String

        Try
            If Me.TextBox_VCom.Text = "" Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable_2(False)

            If Me.TextBox_VCom.Text <> "" Then
                Me.m_MeasProcess.MeasVComArray.RemoveAt(Me.ListView_VCom.SelectedIndices(0))
                Me.ListView_VCom.Items.RemoveAt(Me.ListView_VCom.SelectedIndices(0))

                Me.TextBox_VCom.Text = ""
            End If

            'Save Meas VCom datum ---
            strPath = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Measurement\MeasVCom_C" & Me.m_MainProcess.GrabNo & ".txt"
            Me.m_MeasProcess.SaveMeasVCom(strPath)

            '--- Enable Button ---
            Me.Button_Enable_2(True)
            Me.Button_Gamma_DeleteOne.Enabled = False
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.Button_Gamma_DeleteOne.Enabled = False
            Me.m_Form.OutputInfo("[Dialog_CalculateMeasurement.Button_VCom_DeleteOne]" & ex.Message)
            MessageBox.Show("[Dialog_CalculateMeasurement.Button_VCom_DeleteOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Gamma_DeleteOne ---"
    Private Sub Button_Gamma_DeleteOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Gamma_DeleteOne.Click
        Dim pb As New ClsMeasGamma
        Dim strPath As String

        Try
            If Me.TextBox_Gamma_Level.Text = "" Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable(False)

            If Me.TextBox_Gamma_Level.Text <> "" Then
                Me.m_MeasProcess.MeasGammaArray.RemoveAt(Me.ListView_Gamma.SelectedIndices(0))
                Me.ListView_Gamma.Items.RemoveAt(Me.ListView_Gamma.SelectedIndices(0))

                Me.TextBox_Gamma_Counts.Text = Me.m_MeasProcess.MeasGammaArray.Count
                Me.TextBox_Gamma_Level.Text = ""
            End If

            '--- Save Meas Gamma datum ---
            strPath = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Measurement\MeasGamma_C" & Me.m_MainProcess.GrabNo & ".txt"
            Me.m_MeasProcess.SaveMeasGamma(strPath)

            '--- Enable Button ---
            Me.Button_Enable(True)
            Me.Button_Gamma_DeleteOne.Enabled = False
        Catch ex As Exception
            Me.Button_Enable(True)
            Me.Button_Gamma_DeleteOne.Enabled = False
            Me.m_Form.OutputInfo("[Dialog_CalculateMeasurement.Button_Gamma_DeleteOne]" & ex.Message)
            MessageBox.Show("[Dialog_CalculateMeasurement.Button_Gamma_DeleteOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_CalculateVCom ---"
    Private Sub Button_CalculateVCom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_CalculateVCom.Click
        Dim VCom As Double
        Dim lvi As ListViewItem
        Dim i As Integer
        Dim MinVCom_Index As Integer
        Dim Min_Delta_Mean As Integer
        Dim VCom_Counts As Integer
        Dim Message As String = ""
        Dim strs() As String

        If Me.m_MeasProcess.MeasVComArray.Count < 2 Then
            MsgBox("�ثe�`���� " & Me.m_MeasProcess.MeasGammaArray.Count & ", �ܤֻݭn 2+1 ����� !", MsgBoxStyle.Critical, "[OMS]")
            Exit Sub
        End If

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---
            Me.Button_Enable(False)
            Me.Button_CalculateVCom.Enabled = False

            '--- Initial Meas Array ---
            Me.ListView_VCom.Items.Clear()

            If Me.m_IPBootConfig.CardSystem.Value <> "" Then

                If Me.m_Have_MDigitizer Then

                    '----------------------------------------------------------------------------------------------
                    ' Update Current Exposure Time  ==> Request_Command = "OMS_UPDATE_EXPOSURETIME" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "OMS_UPDATE_EXPOSURETIME"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NUD_VCom_ExposureTime.Value, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Response_OK = False
                            Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Digitizer Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateVCom]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.TrackBar_Gamma_ExposureTime.Enabled = True
                            Me.Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If

                If Not Response_OK Then
                    MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateVCom]Update Digitizer Exposure Time Error !", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    Exit Sub
                End If
            Else
                Throw New Exception("IPBootConfig �ɮפ�, ���]�w CardSystem, �ΨS�������d")
            End If


            '[ Set Current Pattern 1 ] ---
            Me.PatGen_SetPattern(Me.ComboBox_VCom_P1.Text)

            '--- �s��p�� N �� Mean ---
            VCom_Counts = Me.m_MeasProcess.MeasVComArray.Count - 1
            For i = 0 To VCom_Counts
                Message = ""
                VCom = Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).VCom
                Me.m_MeasProcess.PatGen_SetDCVCom(VCom, Message)
                Me.m_Form.OutputInfo(Message)
                System.Threading.Thread.Sleep(200)

                '--- ����---  
                Me.UpdateGrabImage(False)

                '--- �p�� Mean �� ---
                '----------------------------------------------------------------------------------------------
                ' Get Gray Mean  ==> Request_Command = "GET_GRAYMEAN" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "GET_GRAYMEAN"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                        strs = SubSystemResult.Responses(0).Param2.Split(",")
                        Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Mean_1 = Val(strs(1))

                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Gray Mean Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Application.DoEvents()
            Next


            '[ Set Current Pattern 2 ] ---
            Me.PatGen_SetPattern(Me.ComboBox_VCom_P2.Text)

            '--- �s��p�� N �� Mean ---
            VCom_Counts = Me.m_MeasProcess.MeasVComArray.Count - 1
            For i = 0 To VCom_Counts
                Message = ""
                VCom = Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).VCom
                Me.m_MeasProcess.PatGen_SetDCVCom(VCom, Message)
                Me.m_Form.OutputInfo(Message)
                System.Threading.Thread.Sleep(200)

                '--- ����--- 
                Me.UpdateGrabImage(False)

                '�p�� Mean �� ---
                '----------------------------------------------------------------------------------------------
                ' Get Gray Mean  ==> Request_Command = "GET_GRAYMEAN" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "GET_GRAYMEAN"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                        strs = SubSystemResult.Responses(0).Param2.Split(",")
                        Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Mean_2 = Val(strs(1))

                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Gray Mean Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_CalculateMeasurement.Button_CalculateMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            Next

            '--- Add to ListVew ---
            For i = 0 To VCom_Counts
                lvi = Me.ListView_VCom.Items.Add(CStr(Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).VCom))
                Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Delta_Mean = Math.Abs(Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Mean_1 - Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Mean_2)
                lvi.SubItems.Add(Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Delta_Mean)
            Next

            '--- Calculate Vcom ---   
            MinVCom_Index = 0
            Min_Delta_Mean = Me.m_MeasProcess.MeasVComArray.GetMeasVCom(0).Delta_Mean
            For i = 1 To VCom_Counts - 1
                If Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Delta_Mean < Min_Delta_Mean Then
                    MinVCom_Index = i
                    Min_Delta_Mean = Me.m_MeasProcess.MeasVComArray.GetMeasVCom(i).Delta_Mean
                End If
            Next
            Me.TextBox_VCom_Result.Text = Me.m_MeasProcess.MeasVComArray.GetMeasVCom(MinVCom_Index).VCom


            If (Me.TextBox_VCom_Min.Text < Me.m_MeasProcess.MeasVComArray.GetMeasVCom(MinVCom_Index).Delta_Mean) And (Me.TextBox_VCom_Max.Text > Me.m_MeasProcess.MeasVComArray.GetMeasVCom(MinVCom_Index).Delta_Mean) Then
                Me.Label_VCom_Status.Text = "OK"
            Else
                Me.Label_VCom_Status.Text = "NG"
            End If

            '--- Return to Standard VCom ---    
            Message = ""
            Me.m_MeasProcess.PatGen_SetDCVCom(Me.m_MeasProcess.MeasModelRecipe.VCom_Standard.Value, Message)
            Me.m_Form.OutputInfo(Message)
            System.Threading.Thread.Sleep(200)

            Me.Button_Enable(True)
            Me.Button_CalculateVCom.Enabled = True
        Catch ex As Exception
            '--- Return to Standard VCom ---  
            Message = ""
            Me.m_MeasProcess.PatGen_SetDCVCom(Me.m_MeasProcess.MeasModelRecipe.VCom_Standard.Value, Message)
            Me.m_Form.OutputInfo(Message)
            System.Threading.Thread.Sleep(200)

            Me.Button_Enable(True)
            Me.Button_CalculateVCom.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.Button_CalculateVCom]Calculate VCom Error!(" & ex.Message & ")")
        End Try

    End Sub
#End Region


#End Region

#Region "--- TrackBar Event ---"
    Private Sub TrackBar_Gamma_ExposureTime_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_Gamma_ExposureTime.MouseUp
        '--- ��s�n���ɶ� ---
        '--- �������̤p�n���ɶ� 16000 --- 
        'If Me.TrackBar_Gamma_ExposureTime.Value < 16000 Then Me.TrackBar_Gamma_ExposureTime.Value = 16000
        If Me.m_Have_MDigitizer Then Me.NUD_Gamma_ExposureTime.Value = Me.TrackBar_Gamma_ExposureTime.Value
    End Sub
    Private Sub TrackBar_VCom_ExposureTime_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_VCom_ExposureTime.MouseUp
        '--- ��s�n���ɶ� ---
        '--- �������̤p�n���ɶ� 16000 --- 
        'If Me.TrackBar_VCom_ExposureTime.Value < 16000 Then Me.TrackBar_VCom_ExposureTime.Value = 16000
        If Me.m_Have_MDigitizer Then Me.NUD_VCom_ExposureTime.Value = Me.TrackBar_VCom_ExposureTime.Value
    End Sub
    Private Sub TrackBar_BL_ExposureTime_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_BL_ExposureTime.MouseUp
        '--- ��s�n���ɶ� ---
        '--- �������̤p�n���ɶ� 16000 --- 
        'If Me.TrackBar_BL_ExposureTime.Value < 16000 Then Me.TrackBar_BL_ExposureTime.Value = 16000
        If Me.m_Have_MDigitizer Then Me.NUD_BL_ExposureTime.Value = Me.TrackBar_BL_ExposureTime.Value
    End Sub
#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- NUD_Gamma_ExposureTime ---"
    Private Sub NUD_Gamma_ExposureTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_Gamma_ExposureTime.ValueChanged

        If Not Me.m_ReadyToUpdateImage Then Exit Sub
        If Me.NUD_Gamma_ExposureTime.Value <= 1 Then Exit Sub

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        Me.Button_Enable(False)
        Me.TrackBar_Gamma_ExposureTime.Enabled = False
        Me.TrackBar_Gamma_ExposureTime.Value = Me.NUD_Gamma_ExposureTime.Value

        If Not Me.m_MainProcess Is Nothing Then

            Try
                If Not Me.m_Form Is Nothing Then

                    If Me.m_IPBootConfig.CardSystem.Value <> "" AndAlso Me.m_Have_MDigitizer Then

                        '----------------------------------------------------------------------------------------------
                        ' Update Current Exposure Time  ==> Request_Command = "OMS_UPDATE_EXPOSURETIME" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "OMS_UPDATE_EXPOSURETIME"
                            TimeOut = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NUD_Gamma_ExposureTime.Value, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Response_OK = False
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Digitizer Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_CalculateMeasurement.NUD_Gamma_ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.TrackBar_Gamma_ExposureTime.Enabled = True   '2010/06/14 Rick add
                                Me.Button_Enable(True)
                                Exit Sub
                            End If
                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try

                        If Response_OK Then
                            Me.UpdateGrabImage(True)
                        End If
                    End If
                End If
            Catch ex As Exception
                Me.TrackBar_Gamma_ExposureTime.Enabled = True
                Me.Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.NUD_Gamma_ExposureTime_ValueChanged]" & ex.Message)
            End Try
        End If

        System.Threading.Thread.Sleep(500)
        Me.Button_Enable(True)
        Me.TrackBar_Gamma_ExposureTime.Enabled = True

    End Sub
#End Region

#Region "--- NUD_VCom_ExposureTime ---"
    Private Sub NUD_VCom_ExposureTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_VCom_ExposureTime.ValueChanged

        If Not Me.m_ReadyToUpdateImage Then Exit Sub
        If Me.NUD_VCom_ExposureTime.Value <= 1 Then Exit Sub

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        Me.Button_Enable_2(False)
        Me.TrackBar_VCom_ExposureTime.Enabled = False
        Me.TrackBar_VCom_ExposureTime.Value = Me.NUD_VCom_ExposureTime.Value

        If Not Me.m_MainProcess Is Nothing Then

            Try
                If Not Me.m_Form Is Nothing Then

                    If Me.m_IPBootConfig.CardSystem.Value <> "" AndAlso Me.m_Have_MDigitizer Then

                        '----------------------------------------------------------------------------------------------
                        ' Update Current Exposure Time  ==> Request_Command = "OMS_UPDATE_EXPOSURETIME" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "OMS_UPDATE_EXPOSURETIME"
                            TimeOut = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NUD_VCom_ExposureTime.Value, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Response_OK = False
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_CalculateMeasurement.NUD_VCom_ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.TrackBar_VCom_ExposureTime.Enabled = True
                                Me.Button_Enable_2(True)
                                Exit Sub
                            End If
                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try

                        If Response_OK Then
                            Me.UpdateGrabImage(True)
                        End If
                    End If
                End If
            Catch ex As Exception
                Me.TrackBar_VCom_ExposureTime.Enabled = True
                Me.Button_Enable_2(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.NUD_VCom_ExposureTime_ValueChanged]" & ex.Message)
            End Try
        End If

        System.Threading.Thread.Sleep(500)
        Me.Button_Enable_2(True)
        Me.TrackBar_VCom_ExposureTime.Enabled = True

    End Sub
#End Region

#Region "--- NUD_BL_ExposureTime ---"
    Private Sub NUD_BL_ExposureTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NUD_BL_ExposureTime.ValueChanged

        If Not Me.m_ReadyToUpdateImage Then Exit Sub
        If Me.NUD_BL_ExposureTime.Value <= 1 Then Exit Sub

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        Me.Button_Enable(False)
        Me.TrackBar_BL_ExposureTime.Enabled = False
        Me.TrackBar_BL_ExposureTime.Value = Me.NUD_BL_ExposureTime.Value

        If Not Me.m_MainProcess Is Nothing Then

            Try
                If Not Me.m_Form Is Nothing Then

                    If Me.m_IPBootConfig.CardSystem.Value <> "" AndAlso Me.m_Have_MDigitizer Then

                        '----------------------------------------------------------------------------------------------
                        ' Update Current Exposure Time (For Back Light)  ==> Request_Command = "OMS_UPDATE_EXPOSURETIME" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "OMS_UPDATE_EXPOSURETIME"
                            TimeOut = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NUD_BL_ExposureTime.Value, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Response_OK = False
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_CalculateMeasurement.NUD_BL_ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.TrackBar_BL_ExposureTime.Enabled = True
                                Me.Button_Enable(True)
                                Exit Sub
                            End If
                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try

                        If Response_OK Then
                            Me.UpdateGrabImage(True)
                        End If
                    End If
                End If
            Catch ex As Exception
                Me.TrackBar_BL_ExposureTime.Enabled = True
                Me.Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CalculateMeasurement.NUD_BL_ExposureTime_ValueChanged]" & ex.Message)
            End Try
        End If

        System.Threading.Thread.Sleep(500)
        Me.Button_Enable(True)
        Me.TrackBar_BL_ExposureTime.Enabled = True

    End Sub
#End Region

#End Region

#Region "--- ComboBox Event ---"

#Region "--- ComboBox_PatGen_Model ---"
    Private Sub ComboBox_PatGen_Model_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_PatGen_Model.SelectedIndexChanged
        Dim ModelResult As New ArrayList
        Dim Message As String = ""
        Dim PatternResult As New ArrayList
        Dim CurrentPatternIndex As Integer = 0
        Dim i As Integer

        Try
            'Step 1:[PatGen][Set Model] ---
            Me.m_MeasProcess.PatGen_SetModel(Me.ComboBox_PatGen_Model.Text, Message)
            Me.m_Form.OutputInfo(Message)

            'Step 2:[PatGen][Get All Pattern] ---
            Try
                Message = ""
                Me.m_MeasProcess.PatGen_GetAllPattern(PatternResult, Message)

                For i = Me.ComboBox_Gamma_Pattern.Items.Count - 1 To 0 Step -1
                    Me.ComboBox_Gamma_Pattern.Items.RemoveAt(i)
                Next
                For i = 0 To PatternResult.Count() - 1
                    Me.ComboBox_Gamma_Pattern.Items.Insert(i, PatternResult(i))

                    If PatternResult(i) = Me.m_MeasProcess.MeasModelRecipe.Gamma_Pattern.Value Then
                        CurrentPatternIndex = i
                    End If
                Next

                Me.ComboBox_Gamma_Pattern.SelectedIndex = CurrentPatternIndex
            Catch ex As Exception
                MessageBox.Show("[PatGen] PatGen Get All Pattern Fail ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End Try

        Catch ex As Exception
            MessageBox.Show("[Dialog_CalculateMeasurement.ComboBox_PatGen_Model]Set PatGen Model Error ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
#End Region

#Region "--- ComboBox_Gamma_Pattern ---"
    Private Sub ComboBox_Gamma_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Gamma_Pattern.SelectedIndexChanged
        Me.PatGen_SetPattern(Me.ComboBox_Gamma_Pattern.Text)
    End Sub
#End Region

#Region "--- ComboBox_VCom_P1_SelectedIndex ---"
    Private Sub ComboBox_VCom_P1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_VCom_P1.SelectedIndexChanged
        Dim ModelResult As New ArrayList
        Dim Message As String = ""
        Dim Signal_Status As String = ""

        Try
            '[Step 1] Check PatGen Signal On ---
            Signal_Status = Me.m_MeasProcess.PatGen_GetSignal(Message)
            If UCase(Signal_Status) = "TURNOFF" Then
                Me.PatGen_SignalOn(True)
            End If

            Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_1.Value = Me.ComboBox_VCom_P1.Text
        Catch ex As Exception
            MessageBox.Show("[Dialog_CalculateMeasurement.ComboBox_VCom_P1_SelectedIndex]Set PatGen's VCom Pattern 1 Error ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
#End Region

#Region "--- ComboBox_VCom_P2_SelectedIndex ---"
    Private Sub ComboBox_VCom_P2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_VCom_P2.SelectedIndexChanged
        Dim ModelResult As New ArrayList
        Dim Message As String = ""
        Dim Signal_Status As String = ""

        Try
            '[Step 1] Check PatGen Signal On ---
            Signal_Status = Me.m_MeasProcess.PatGen_GetSignal(Message)
            If UCase(Signal_Status) = "TURNOFF" Then
                Me.PatGen_SignalOn(True)
            End If

            Me.m_MeasProcess.MeasModelRecipe.VCom_Pattern_2.Value = Me.ComboBox_VCom_P2.Text
        Catch ex As Exception
            MessageBox.Show("[Dialog_CalculateMeasurement.ComboBox_VCom_P1_SelectedIndex]Set PatGen's VCom Pattern 2 Error ! (" & ex.Message & ")", "OMS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
#End Region


#End Region

#Region "--- ListView Event ---"

#Region "--- ListView_Gamma_Click ---"
    Private Sub ListView_Gamma_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Gamma.Click
        Dim SelectIndex As Integer
        If Me.m_MeasProcess.MeasGammaArray.Count > 0 Then
            Button_Gamma_DeleteOne.Enabled = False
            SelectIndex = Me.ListView_Gamma.SelectedIndices(0)
            Me.TextBox_Gamma_Level.Text = ListView_Gamma.Items(SelectIndex).SubItems(0).Text

            Button_Gamma_DeleteOne.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ListView_VCom_Click ---"
    Private Sub ListView_VCom_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_VCom.Click
        Dim SelectIndex As Integer
        If Me.m_MeasProcess.MeasVComArray.Count > 0 Then
            Button_VCom_DeleteOne.Enabled = False
            SelectIndex = Me.ListView_VCom.SelectedIndices(0)
            Me.TextBox_VCom.Text = ListView_VCom.Items(SelectIndex).SubItems(0).Text

            Button_VCom_DeleteOne.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ListView_Gamma_KeyUp ---"
    Private Sub ListView_Gamma_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_Gamma.KeyUp
        Dim Delete_Index As Integer

        If e.KeyCode = Keys.Delete AndAlso ListView_Gamma.SelectedIndices.Count <> 0 Then

            Try

                '--- Disable Button ---
                Me.Button_Enable(False)

                Delete_Index = ListView_Gamma.SelectedIndices(0)
                If Me.m_MeasProcess.MeasGammaArray.Count > 0 Then
                    Me.m_MeasProcess.MeasGammaArray.RemoveAt(Delete_Index)
                End If

                Call MeasGammaListReflash()

                '--- Enable Button ---
                Me.Button_Enable(True)
            Catch ex As Exception
                Me.Button_Enable(True)
                Me.m_Form.OutputInfo("[Dialog_CalculateMeasurement.ListView_Gamma_KeyUp]" & ex.Message)
                MessageBox.Show("[Dialog_CalculateMeasurement.ListView_Gamma_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#Region "--- ListView_VCom_KeyUp ---"
    Private Sub ListView_VCom_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_VCom.KeyUp
        Dim Delete_Index As Integer

        If e.KeyCode = Keys.Delete AndAlso ListView_VCom.SelectedIndices.Count <> 0 Then

            Try

                '--- Disable Button ---
                Me.Button_Enable_2(False)

                Delete_Index = ListView_VCom.SelectedIndices(0)
                If Me.m_MeasProcess.MeasVComArray.Count > 0 Then
                    Me.m_MeasProcess.MeasVComArray.RemoveAt(Delete_Index)
                End If

                Call MeasVComListReflash()

                '--- Enable Button ---
                Me.Button_Enable_2(True)
            Catch ex As Exception
                Me.Button_Enable_2(True)
                Me.m_Form.OutputInfo("[Dialog_CalculateMeasurement.ListView_VCom_KeyUp]" & ex.Message)
                MessageBox.Show("[Dialog_CalculateMeasurement.ListView_VCom_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region


#End Region


End Class
