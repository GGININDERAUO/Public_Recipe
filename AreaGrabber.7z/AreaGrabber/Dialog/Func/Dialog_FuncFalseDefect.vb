Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports ClassLibrary
Imports System.IO
Imports AUO.SubSystemControl
Imports System.Threading
Imports System.Globalization

<CLSCompliant(False)> _
Public Class Dialog_FuncFalseDefect
    Inherits System.Windows.Forms.Form

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private ff_TableDeleteEnable, ff_TempDeleteEnable As Boolean   'ff�G��Func False
    Private ff_DeleteIndex As Integer
    Private fuf_TableDeleteEnable, fuf_TempDeleteEnable As Boolean  'fuf�G��Func Un Filter
    Private fuf_DeleteIndex As Integer
    Private m_Size As Integer

    '�s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_FuncFalseDefect", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------
        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_FuncProcess = form.MainProcess.FuncProcess

        If Not Me.m_MainProcess.CheckIP() Then   '2010/04/24 Rick add
            Me.m_MainProcess.IsIPConnected = False
            MessageBox.Show("Can't connect to IP-" & Me.m_MainProcess.CCDNo & "�APLZ restart IP !", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Me.m_MainProcess.IsIPConnected = True
        End If

        Me.m_IPBootConfig = form.MainProcess.IPBootConfig
        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_Pen = New Pen(Color.White)
        Me.m_SolidBrush = New SolidBrush(Color.White)
        Me.m_Size = 15
        Me.Button_FR_DeleteOne.Enabled = False
        Me.Button_UFR_DeleteOne.Enabled = False

        Me.UpdateData()
        '�v������
        Me.UpdateUserLevel() '5/14 add
    End Sub

#Region "--- Dialog Event ---"

#Region "--- Dialog_FuncFalseDefect_Load ---"
    Private Sub Dialog_FuncFalseDefect_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then   '2010/04/24 Rick add
            Exit Sub
        End If

        'Update UI ---
        Me.ComboBox_FalseType.Items.Clear()
        Me.ComboBox_FalseType.Items.Add("DARK_POINT")  'No = 1
        Me.ComboBox_FalseType.Items.Add("BRIGHT_POINT")  'No = 3
        Me.ComboBox_FalseType.Items.Add("R_DARK_POINT")  'No = 41
        Me.ComboBox_FalseType.Items.Add("R_BRIGHT_POINT")  'No = 42
        Me.ComboBox_FalseType.Items.Add("G_DARK_POINT")  'No = 43
        Me.ComboBox_FalseType.Items.Add("G_BRIGHT_POINT")  'No = 44
        Me.ComboBox_FalseType.Items.Add("B_DARK_POINT")  'No = 45
        Me.ComboBox_FalseType.Items.Add("B_BRIGHT_POINT")  'No = 46
        Me.ComboBox_FalseType.Items.Add("W_DARK_POINT")  'No = 47
        Me.ComboBox_FalseType.Items.Add("W_BRIGHT_POINT")  'No = 48

        Me.ComboBox_FalseType.Items.Add("DARK_VLINE")  'No = 10
        Me.ComboBox_FalseType.Items.Add("BRIGHT_VLINE")  'No = 11
        Me.ComboBox_FalseType.Items.Add("DARK_HLINE")  'No = 12
        Me.ComboBox_FalseType.Items.Add("BRIGHT_HLINE")  'No = 13
        Me.ComboBox_FalseType.Items.Add("VBITLINE")  'No = 14
        Me.ComboBox_FalseType.Items.Add("HBITLINE")  'No = 15

        'False Defect Table Refresh ---
        Call Me.FalseDefectTableListReflash()
        Call Me.FalseDefectTempListReflash()
        Call Me.FilterRegionReflash()
        Call Me.BackParticleListReflash()
        Call Me.MaskMarkRegionReflash()

        'Un Filter Region Refresh ---   '07/22 Rick add
        Call Me.UnFilterRegionReflash()
        Me.Update()  '2011/03/08 Rick add
    End Sub
#End Region

#Region "--- Dialog_FuncFalseDefect_Closing ---"
    Private Sub Dialog_FuncFalseDefect_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Try
            Me.m_Form.PaintStop = True
            Me.CheckBox_ShowFilterRegion.Checked = False
            Me.CheckBox_FR_Mannual.Checked = False

            Me.CheckBox_ShowUnFilterRegion.Checked = False
            Me.CheckBox_UFR_Mannual.Checked = False

            Me.CheckBox_ShowMaskMarkRegion.Checked = False
            Me.CheckBox_MMR_Mannual.Checked = False

            If Me.m_AxMDisplay <> M_NULL Then Me.m_Panel_AxMDisplay.Refresh()
            Me.Finalize()
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Dialog_FuncFalseDefect_Closing]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Dialog_FuncFalseDefect_Closing]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_Judge.Enabled = False
                Me.Button_FalseAdd.Enabled = False
                Me.Button_FalseRemove.Enabled = False
                Me.GroupBox_Manual.Enabled = False
                Me.GroupBox_FilterRegion.Enabled = False
                Me.ComboBox_GenSample.Enabled = False
                Me.Button_Save.Enabled = False
                Me.Button_Close.Enabled = False
                Me.GroupBox_UnFilterRegion.Enabled = False
                Me.GroupBox_MaskMarkRegion.Enabled = False

            Case 1 'PM
                'FuncFalseTable -----
                Me.GroupBox_Judge.Enabled = False
                Me.Button_FalseAdd.Enabled = True
                Me.Button_FalseRemove.Enabled = True
                Me.GroupBox_Manual.Enabled = True
                Me.ComboBox_GenSample.Enabled = True
                Me.Button_Save.Enabled = True
                Me.Button_Close.Enabled = True

                'FilterRegion -----
                Me.GroupBox_FilterRegion.Enabled = True
                Me.GroupBox_AutoAddFR.Enabled = True
                Me.GroupBox_Display_FR.Enabled = True
                Me.GroupBox_MannualAddFR.Enabled = True
                Me.ComboBox_FR_Pattern.Enabled = True
                Me.ComboBox_FR_Blacking.Enabled = True
                Me.Button_FR_Save.Enabled = True
                Me.Button_FR_Close.Enabled = True

                'UnFilterRegion -----
                Me.GroupBox_UnFilterRegion.Enabled = True
                Me.GroupBox_AutoAddUFR.Enabled = True
                Me.GroupBox_Display_UFR.Enabled = True
                Me.GroupBox_MannualAddUFR.Enabled = True
                Me.ComboBox_UFR_Pattern.Enabled = True
                Me.Button_UFR_Save.Enabled = True
                Me.Button_UFR_Close.Enabled = True

                'MaskMarkRegion -----
                Me.GroupBox_MaskMarkRegion.Enabled = True
                Me.GroupBox_AutoAddMMR.Enabled = True
                Me.GroupBox_Display_MMR.Enabled = True
                Me.GroupBox_MannualAddMMR.Enabled = True
                Me.ComboBox_MMR_Pattern.Enabled = True
                Me.Button_MMR_Save.Enabled = True
                Me.Button_MMR_Close.Enabled = True

            Case 2 'ENG
                Me.GroupBox_Judge.Enabled = True
                Me.Button_FalseAdd.Enabled = True
                Me.Button_FalseRemove.Enabled = True
                Me.GroupBox_Manual.Enabled = True
                Me.GroupBox_FilterRegion.Enabled = True
                Me.ComboBox_GenSample.Enabled = True
                Me.Button_Save.Enabled = True
                Me.Button_Close.Enabled = True
                Me.GroupBox_UnFilterRegion.Enabled = True
                Me.GroupBox_MaskMarkRegion.Enabled = True

            Case 3 'ALL
                Me.GroupBox_Judge.Enabled = True
                Me.Button_FalseAdd.Enabled = True
                Me.Button_FalseRemove.Enabled = True
                Me.GroupBox_Manual.Enabled = True
                Me.GroupBox_FilterRegion.Enabled = True
                Me.ComboBox_GenSample.Enabled = True
                Me.Button_Save.Enabled = True
                Me.Button_Close.Enabled = True
                Me.GroupBox_UnFilterRegion.Enabled = True
                Me.GroupBox_MaskMarkRegion.Enabled = True

        End Select
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '�_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '�إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)   '2010/12/24 Rick add
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim Parameter_Lists As String = ""
        Dim rootPath As String = ""

        Try
            Me.m_FuncProcess.FuncModelRecipe.FalseCount.Value = Me.NumericUpDown_Check.Value
            Me.m_FuncProcess.FuncModelRecipe.FalseMatchCount.Value = Me.NumericUpDown_CompareOK.Value
            Me.m_FuncProcess.FuncModelRecipe.Distance.Value = Me.NumericUpDown_Dist.Value
            Me.m_FuncProcess.FuncModelRecipe.MMR_DilateCount.Value = Me.NumericUpDown_MMR_DilateCount.Value
            Me.m_FuncProcess.FuncModelRecipe.MMR_ByPass_AreaMax.Value = Me.NumericUpDown_MMR_ByPass_AreaMax.Value
            Me.m_FuncProcess.FuncModelRecipe.LineNotAddToFDTable.Value = Me.CheckBox_LineNotAddToFDTable.Checked   '08/01 Rick add
            Me.m_FuncProcess.FuncModelRecipe.FalseArea.Value = Me.NumericUpDown_FalseArea.Value
            Me.m_FuncProcess.FuncModelRecipe.MaxFalseDefectTableCount.Value = CInt(Me.TextBox_MaxFalseDefectTable.Text)
            Me.m_FuncProcess.FuncModelRecipe.DeleteTableCount.Value = CInt(Me.TextBox_DeleteTableCount.Text)
            Me.m_FuncProcess.FuncModelRecipe.AutoAddFuncFalseDefect.Value = Me.CheckBox_AutoAddFuncFalseDefect.Checked

            '2009/09/24 ��s���| ---
            rootPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
            Me.m_FuncProcess.SaveFuncModelRecipe(rootPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
            Me.m_FuncProcess.SaveFuncFalseDefec(rootPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)   '2012/11/01 Rick add

            '�_�u�M�� ---
            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

            '�إ� IP �s�u ---
            If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
            ip = New ClsIPInfo
            ip.CCDNo = Me.m_MainProcess.CCDNo
            ip.GrabNo = Me.m_MainProcess.GrabNo
            Me.m_MainProcess.IPInfo.Add(ip)
            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Dialog_FuncFalseDefect Setting   ==> Request_Command = "DIALOG_FUNCFALSEDEFECT_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "DIALOG_FUNCFALSEDEFECT_SETTING"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------

                '�Ĥ@�� ---
                Parameter_Lists = "FalseCount," & Me.NumericUpDown_Check.Value & ";" & "FalseMatchCount," & Me.NumericUpDown_CompareOK.Value & ";" & "Distance," & Me.NumericUpDown_Dist.Value & ";" & _
                                  "MMR_DilateCount," & Me.NumericUpDown_MMR_DilateCount.Value & ";" & "MMR_ByPass_AreaMax," & Me.NumericUpDown_MMR_ByPass_AreaMax.Value & ";" & _
                                  "LineNotAddToFDTable," & Me.CheckBox_LineNotAddToFDTable.Checked & ";" & _
                                  "FalseArea," & Me.NumericUpDown_FalseArea.Value & ";" & "MaxFalseDefectTableCount," & Me.TextBox_MaxFalseDefectTable.Text & ";" & "DeleteTableCount," & Me.TextBox_DeleteTableCount.Text & ";" & "AutoAddFuncFalseDefect," & Me.CheckBox_AutoAddFuncFalseDefect.Checked

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncFalseDefect Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Setting]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Setting]Dialog_FuncFalseDefect Setting Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "SAVE_FUNC_MODEL_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Setting]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Setting]Save Func Model Recipe Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Setting]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Setting]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

#End Region

#Region "--- UpdateData ---"
    Private Sub UpdateData()
        Dim i As Integer

        Try
            If Me.m_FuncProcess.FuncModelRecipe.FalseMatchCount.Value >= Me.m_FuncProcess.FuncModelRecipe.FalseCount.Value Then
                Me.m_FuncProcess.FuncModelRecipe.FalseCount.Value = Me.m_FuncProcess.FuncModelRecipe.FalseMatchCount.Value
            End If
            NumericUpDown_Check.Value = Me.m_FuncProcess.FuncModelRecipe.FalseCount.Value
            NumericUpDown_CompareOK.Value = Me.m_FuncProcess.FuncModelRecipe.FalseMatchCount.Value
            NumericUpDown_Dist.Value = Me.m_FuncProcess.FuncModelRecipe.Distance.Value
            NumericUpDown_MMR_DilateCount.Value = Me.m_FuncProcess.FuncModelRecipe.MMR_DilateCount.Value
            NumericUpDown_MMR_ByPass_AreaMax.Value = Me.m_FuncProcess.FuncModelRecipe.MMR_ByPass_AreaMax.Value
            NumericUpDown_FalseArea.Value = Me.m_FuncProcess.FuncModelRecipe.FalseArea.Value
            TextBox_MaxFalseDefectTable.Text = CStr(Me.m_FuncProcess.FuncModelRecipe.MaxFalseDefectTableCount.Value)
            TextBox_DeleteTableCount.Text = CStr(Me.m_FuncProcess.FuncModelRecipe.DeleteTableCount.Value)
            Me.CheckBox_AutoAddFuncFalseDefect.Checked = Me.m_FuncProcess.FuncModelRecipe.AutoAddFuncFalseDefect.Value

            Me.Label_FalseTableCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count
            Me.Label_FalseTempCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Count

            Me.CheckBox_LineNotAddToFDTable.Checked = Me.m_FuncProcess.FuncModelRecipe.LineNotAddToFDTable.Value   '08/01 Rick add

            '--- [Filter Region]Pattern Update ---   
            '[1] Add Filter Region  ---
            Me.ComboBox_FR_Pattern.Items.Clear()
            Me.ComboBox_FR_Pattern.Items.Add("ALL")
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_FR_Pattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            '[2] Show Filter Region By Pattern ---   //2012/09/27 Rick add
            Me.ComboBox_Show_FR_Single.Items.Clear()
            Me.ComboBox_Show_FR_Single.Items.Add("ALL")
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_Show_FR_Single.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_Show_FR_Single.Text = "ALL"
            Me.ComboBox_FalseLineDirection.Text = "V"

            '--- [Un-Filter Region]Pattern Update ---
            '[0] Add FuncFalseTable
            Me.ComboBox_FalsePattern.Items.Clear()
            Me.ComboBox_FalsePattern.Items.Add("ALL")
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_FalsePattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_FalsePattern.Text = "ALL"
            '[1] Add Un-Filter Region ---
            Me.ComboBox_UFR_Pattern.Items.Clear()
            Me.ComboBox_UFR_Pattern.Items.Add("ALL")
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_UFR_Pattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_UFR_Pattern.Text = "ALL"
            '[2] Show Un-Filter Region By Pattern ---   //2012/09/27 Rick add
            Me.ComboBox_Show_UFR_Single.Items.Clear()
            Me.ComboBox_Show_UFR_Single.Items.Add("ALL")
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_Show_UFR_Single.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_Show_UFR_Single.Text = "ALL"

            '--- [Mask Mark Region]Pattern Update ---   
            '[1] Add Mask Mark Region ---
            Me.ComboBox_MMR_Pattern.Items.Clear()
            Me.ComboBox_MMR_Pattern.Items.Add("ALL")
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_MMR_Pattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_Show_MMR_Single.Text = "ALL"
            '[2] Show Mask Mark Region By Pattern ---  
            Me.ComboBox_Show_MMR_Single.Items.Clear()
            Me.ComboBox_Show_MMR_Single.Items.Add("ALL")
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_Show_MMR_Single.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_Show_MMR_Single.Text = "ALL"

            'Blacking Update ---  '2012/09/04 Rick add
            Me.ComboBox_FR_Blacking.Items.Clear()
            Me.ComboBox_FR_Blacking.Items.Add("False")
            Me.ComboBox_FR_Blacking.Items.Add("True")

            'UnFilterRegion Mask Update --- 2015/07/21 Addis add
            Me.ComboBox_UFR_Mask.Items.Clear()
            Me.ComboBox_UFR_Mask.Items.Add("False")
            Me.ComboBox_UFR_Mask.Items.Add("True")
        Catch ex As Exception
            Throw New Exception("[Dialog_FuncFalseDefect.UpdateData]Update Data Error! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- Button_Enable_1 ---"
    Private Sub Button_Enable_1(ByVal En As Boolean)
        Me.Button_FalseAdd.Enabled = En
        Me.Button_FalseRemove.Enabled = En

        Me.Button_AddOne.Enabled = En
        Me.Button_DeleteOne.Enabled = En
        Me.Button_Clear.Enabled = En

        Me.Button_Save.Enabled = En
        Me.Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_2 ---"
    Private Sub Button_Enable_2(ByVal En As Boolean)
        Me.Button_FR_AddOne.Enabled = En

        Me.Button_FR_ClearAll.Enabled = En
        Me.Button_FR_DeleteOne.Enabled = En

        Me.Button_FR_Close.Enabled = En
        Me.Button_FR_Save.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_3 ---"
    Private Sub Button_Enable_3(ByVal En As Boolean)
        Me.Button_UFR_AddOne.Enabled = En
        Me.Button_UFR_DeleteOne.Enabled = En

        Me.Button_UFR_Save.Enabled = En
        Me.Button_UFR_Close.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_4 ---"
    Private Sub Button_Enable_4(ByVal En As Boolean)
        Me.Button_BackParticle_CLearAll.Enabled = En
        Me.Button_BackParticle_DeleteOne.Enabled = En

        Me.Button_BackParticle_Save.Enabled = En
        Me.Button_BackParticle_Close.Enabled = En
    End Sub
#End Region

#Region "--- Button_Enable_5 ---"
    Private Sub Button_Enable_5(ByVal En As Boolean)
        Me.Button_MMR_AddOne.Enabled = En
        Me.Button_MMR_DeleteOne.Enabled = En

        Me.Button_MMR_Save.Enabled = En
        Me.Button_MMR_Close.Enabled = En

        Me.Button_Calculate_MaskImage.Enabled = En
    End Sub
#End Region

#Region "--- Show Event ---"

#Region "--- ShowListView ---"
    Public Sub ShowListView()
        Me.ShowFalse()
    End Sub
#End Region

#Region "--- ShowFalse ---"
    Public Sub ShowFalse()
        Select Case Me.ComboBox_FalseType.SelectedIndex
            Case 0
                Me.ShowBPFalse()
        End Select
    End Sub
#End Region

#Region "--- ShowBPFalse ---"
    Private Sub ShowBPFalse()
        Dim p As ClsFuncFalse
        Dim i As Integer
        Dim j As Integer
        Dim str As String

        Try
            Me.ListView_False.Items.Clear()
            Try
                If Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count > 0 Then
                    For i = 0 To Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count - 1
                        p = Me.m_FuncProcess.FuncFalseFilter.FuncFalse.GetFuncFalse(i)
                        If p.Type = PointTypeDefine.BRIGHT_POINT Then
                            ListView_False.Items.Add(p.CreateTime)
                            ListView_False.Items(j).SubItems.Add(p.Type)
                            ListView_False.Items(j).SubItems.Add(p.PositionX)
                            ListView_False.Items(j).SubItems.Add(p.PositionY)
                            ListView_False.Items(j).SubItems.Add(p.Area)
                            ListView_False.Items(j).SubItems.Add(p.Count)
                            ListView_False.Items(j).SubItems.Add(p.Count_Match)
                            ListView_False.Items(j).SubItems.Add(p.Flag)
                            ListView_False.Items(j).SubItems.Add(p.History)
                            j = j + 1
                        End If
                    Next
                    j = 0
                    Me.Show()
                End If
            Catch ex As Exception
                MsgBox("[Dialog_FuncFalseDefect.ShowBPFalse]" & ex.Message, MsgBoxStyle.Critical, "[AreaGrabber]")
            End Try

            '�_�u�M�� ---
            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

            '�إ� IP �s�u ---
            If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
            ip = New ClsIPInfo
            ip.CCDNo = Me.m_MainProcess.CCDNo
            ip.GrabNo = Me.m_MainProcess.GrabNo
            Me.m_MainProcess.IPInfo.Add(ip)
            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Func False Defect Table File ==> Request_Command = "SAVE_FUNC_FALSEDEFECTTABLE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_FALSEDEFECTTABLE"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func False Defect Table ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.Save(str)
                str = str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func False Defect Table File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.ShowBPFalse]Save Func False Defect Table File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.ShowBPFalse]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.ShowBPFalse]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Button_AddOne.Text = res.GetString("Button_AddOne.Text")
                Button_BackParticle_CLearAll.Text = res.GetString("Button_BackParticle_CLearAll.Text")
                Button_BackParticle_DeleteOne.Text = res.GetString("Button_BackParticle_DeleteOne.Text")
                Button_DeleteOne.Text = res.GetString("Button_DeleteOne.Text")
                Button_FR_AddOne.Text = res.GetString("Button_FR_AddOne.Text")
                Button_FR_ClearAll.Text = res.GetString("Button_FR_ClearAll.Text")
                Button_FR_DeleteOne.Text = res.GetString("Button_FR_DeleteOne.Text")
                Button_MMR_AddOne.Text = res.GetString("Button_MMR_AddOne.Text")
                Button_MMR_CLearAll.Text = res.GetString("Button_MMR_CLearAll.Text")
                Button_MMR_DeleteOne.Text = res.GetString("Button_MMR_DeleteOne.Text")
                Button_UFR_AddOne.Text = res.GetString("Button_UFR_AddOne.Text")
                Button_UFR_CLearAll.Text = res.GetString("Button_UFR_CLearAll.Text")
                Button_UFR_DeleteOne.Text = res.GetString("Button_UFR_DeleteOne.Text")
                Ch_Blacking.Text = res.GetString("Ch_Blacking.Text")
                Ch_BottomY.Text = res.GetString("Ch_BottomY.Text")
                Ch_LeftX.Text = res.GetString("Ch_LeftX.Text")
                Ch_RightX.Text = res.GetString("Ch_RightX.Text")
                Ch_TopY.Text = res.GetString("Ch_TopY.Text")
                CheckBox_AutoAddFuncFalseDefect.Text = res.GetString("CheckBox_AutoAddFuncFalseDefect.Text")
                CheckBox_EnableFalseLine.Text = res.GetString("CheckBox_EnableFalseLine.Text")
                CheckBox_FR_Mannual.Text = res.GetString("CheckBox_FR_Mannual.Text")
                CheckBox_MMR_Mannual.Text = res.GetString("CheckBox_MMR_Mannual.Text")
                CheckBox_Show_FR_Single.Text = res.GetString("CheckBox_Show_FR_Single.Text")
                CheckBox_Show_MMR_Single.Text = res.GetString("CheckBox_Show_MMR_Single.Text")
                CheckBox_Show_UFR_Single.Text = res.GetString("CheckBox_Show_UFR_Single.Text")
                CheckBox_ShowFilterRegion.Text = res.GetString("CheckBox_ShowFilterRegion.Text")
                CheckBox_ShowMaskMarkRegion.Text = res.GetString("CheckBox_ShowMaskMarkRegion.Text")
                CheckBox_ShowUnFilterRegion.Text = res.GetString("CheckBox_ShowUnFilterRegion.Text")
                CheckBox_UFR_Mannual.Text = res.GetString("CheckBox_UFR_Mannual.Text")
                ColumnHeader10.Text = res.GetString("ColumnHeader10.Text")
                ColumnHeader11.Text = res.GetString("ColumnHeader11.Text")
                ColumnHeader12.Text = res.GetString("ColumnHeader12.Text")
                ColumnHeader13.Text = res.GetString("ColumnHeader13.Text")
                ColumnHeader15.Text = res.GetString("ColumnHeader15.Text")
                ColumnHeader19.Text = res.GetString("ColumnHeader19.Text")
                ColumnHeader20.Text = res.GetString("ColumnHeader20.Text")
                ColumnHeader21.Text = res.GetString("ColumnHeader21.Text")
                GroupBox_Judge.Text = res.GetString("GroupBox_Judge.Text")
                GroupBox_Manual.Text = res.GetString("GroupBox_Manual.Text")
                Label_Area.Text = res.GetString("Label_Area.Text")
                Label_BackParticleCount.Text = res.GetString("Label_BackParticleCount.Text")
                Label_FalsePosition.Text = res.GetString("Label_FalsePosition.Text")
                Label_FalseTableCount.Text = res.GetString("Label_FalseTableCount.Text")
                Label_FalseTempCount.Text = res.GetString("Label_FalseTempCount.Text")
                Label_FalseType.Text = res.GetString("Label_FalseType.Text")
                Label_NewPosition.Text = res.GetString("Label_NewPosition.Text")
                Label1.Text = res.GetString("Label1.Text")
                Label10.Text = res.GetString("Label10.Text")
                Label11.Text = res.GetString("Label11.Text")
                Label12.Text = res.GetString("Label12.Text")
                Label13.Text = res.GetString("Label13.Text")
                Label17.Text = res.GetString("Label17.Text")
                Label19.Text = res.GetString("Label19.Text")
                Label2.Text = res.GetString("Label2.Text")
                Label29.Text = res.GetString("Label29.Text")
                Label3.Text = res.GetString("Label3.Text")
                Label30.Text = res.GetString("Label30.Text")
                Label31.Text = res.GetString("Label31.Text")
                Label36.Text = res.GetString("Label36.Text")
                Label4.Text = res.GetString("Label4.Text")
                Label6.Text = res.GetString("Label6.Text")
                Label7.Text = res.GetString("Label7.Text")
                Label8.Text = res.GetString("Label8.Text")
                Label9.Text = res.GetString("Label9.Text")
                lbData.Text = res.GetString("lbData.Text")
                lbGate.Text = res.GetString("lbGate.Text")
        End Select
    End Sub
#End Region
#End Region

#Region "--- Button Event ---"

#Region "--- Func False Defect ---"

#Region "--- Button_FalseAdd_Click ---"
    Private Sub Button_FalseAdd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FalseAdd.Click
        Dim i As Integer
        Dim j As Integer
        Dim ff As ClsFuncFalse
        Dim ffa As ClsFuncFalseArray
        Dim ffah As ClsFuncFalseArray
        Dim FuncFalse As String = ""

        '�إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        'Disable Button ---
        Me.Button_Enable_1(False)

        Try
            ffa = Me.m_FuncProcess.FuncFalseFilter.FuncFalse
            ffah = Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory

            If Me.ListView_New.SelectedItems.Count <> 1 Then
                MessageBox.Show("�п�ܤ@��Defect", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable_1(True)
                Exit Sub
            End If

            For i = Me.ListView_New.SelectedItems.Count - 1 To 0 Step -1
                j = Me.ListView_New.SelectedItems.Item(i).Index
                ff = ffah.GetFuncFalse(j)
                ff.Count = 0
                ff.Count_Match = 0
                ff.History = "0000000000"
                ff.History_All = "0000000000"
                ffa.Add(ff)
                ffah.RemoveAt(j)
                'Prepare Func False Data ---
                FuncFalse = FuncFalse & "CreateTime," & ff.CreateTime & ",Type," & ff.Type & ",PositionX," & ff.PositionX & ",PositionY," & ff.PositionY & ",Area," & ff.Area & ",Pattern," & ff.FalsePattern & ";"
            Next

            Me.ListView_New.Items(j).Remove()

            '----------------------------------------------------------------------------------------------
            ' Move Func False From Temp To Table  ==> Request_Command = "FUNC_FALSE_TEMPTOTABLE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_FALSE_TEMPTOTABLE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FuncFalse, j, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Move Func False From Temp To Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_FalseAdd]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.Button_Enable_1(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_FalseAdd]Move Func False From Temp To Table Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Refresh False Defect ---
            FalseDefectTableListReflash()
            FalseDefectTempListReflash()

            'Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_FalseAdd]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_FalseAdd]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_FalseRemove_Click ---"
    Private Sub Button_FalseRemove_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FalseRemove.Click
        Dim i As Integer
        Dim j As Integer
        Dim ff As ClsFuncFalse
        Dim ffa As ClsFuncFalseArray
        Dim ffah As ClsFuncFalseArray
        Dim FuncFalse As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_1(False)

            If Me.ListView_False.SelectedItems.Count <> 1 Then
                MessageBox.Show("�п�ܤ@��Defect", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable_1(True)
                Exit Sub
            End If


            ffa = Me.m_FuncProcess.FuncFalseFilter.FuncFalse
            ffah = Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory
            For i = Me.ListView_False.SelectedItems.Count - 1 To 0 Step -1
                j = Me.ListView_False.SelectedItems.Item(i).Index
                ff = ffa.GetFuncFalse(j)
                ff.Count = 0
                ff.Count_Match = 0
                ff.History = "0000000000"
                ff.History_All = "0000000000"
                ffah.Add(ff)
                ffa.RemoveAt(j)
                'Prepare Func False Data ---
                FuncFalse = FuncFalse & "CreateTime," & ff.CreateTime & ",Type," & ff.Type & ",PositionX," & ff.PositionX & ",PositionY," & ff.PositionY & ",Area," & ff.Area & ",Pattern," & ff.FalsePattern & ";"
            Next

            Me.ListView_False.Items(j).Remove()

            '----------------------------------------------------------------------------------------------
            ' Move Func False From Table To Temp  ==> Request_Command = "FUNC_FALSE_TABLETOTEMP " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_FALSE_TABLETOTEMP"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FuncFalse, j, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Move Func False From Table To Temp Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_FalseRemove]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_FalseRemove]Move Func False From Table To Temp Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Refresh False Defect ---
            FalseDefectTableListReflash()
            FalseDefectTempListReflash()

            'Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_FalseRemove]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_FalseRemove]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_AddOne_Click ---"
    Private Sub Button_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_AddOne.Click
        Dim fd As New ClsFuncFalse
        Dim FuncFalse As String = ""
        Dim Destination As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_1(False)

            fd.CreateTime = Format(Now(), "yyMMdd_HHmmss")
            fd.PositionX = NumericUpDown_X.Value
            fd.PositionY = NumericUpDown_Y.Value
            fd.Area = NumericUpDown_Area.Value
            fd.Count = 1
            fd.Count_Match = 0
            fd.Flag = 0
            fd.FalsePattern = ComboBox_FalsePattern.Text

            Select Case ComboBox_FalseType.Text
                Case "DARK_POINT"
                    fd.Type = PointTypeDefine.DARK_POINT
                Case "BRIGHT_POINT"
                    fd.Type = PointTypeDefine.BRIGHT_POINT
                Case "DARK_VLINE"
                    fd.Type = PointTypeDefine.DARK_VLINE
                Case "BRIGHT_VLINE"
                    fd.Type = PointTypeDefine.BRIGHT_VLINE
                Case "DARK_HLINE"
                    fd.Type = PointTypeDefine.DARK_HLINE
                Case "BRIGHT_HLINE"
                    fd.Type = PointTypeDefine.BRIGHT_HLINE
                Case "VBITLINE"
                    fd.Type = PointTypeDefine.VBITLINE
                Case "HBITLINE"
                    fd.Type = PointTypeDefine.HBITLINE
            End Select

            fd.History = "1000000000"
            fd.History_All = "1000000000"

            'Prepare Func False Data ---
            FuncFalse = FuncFalse & "CreateTime," & fd.CreateTime & ",PositionX," & fd.PositionX & ",PositionY," & fd.PositionY & ",Area," & fd.Area & ",Type," & fd.Type & ",FalsePattern," & fd.FalsePattern & ";"
            Select Case ComboBox_GenSample.SelectedIndex
                Case 0
                    Destination = "TABLE"
                Case 1
                    Destination = "TEMP"
            End Select

            '----------------------------------------------------------------------------------------------
            ' Add One Func False   ==> Request_Command = "FUNC_FALSE_ADDONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_FALSE_ADDONE"
                TimeOut = 300000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FuncFalse, Destination, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Func False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_FalseRemove]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_FalseRemove]Add One Func False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Select Case ComboBox_GenSample.SelectedIndex
                Case 0
                    Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Add(fd)
                    Call FalseDefectTableListReflash()
                Case 1
                    Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Add(fd)
                    Call FalseDefectTempListReflash()
            End Select

            'Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_AddOne]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_DeleteOne_Click ---"
    Private Sub Button_DeleteOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_DeleteOne.Click
        Dim Destination As String = ""
        Dim Delete_Index As Integer

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_1(False)

            If Me.ListView_False.SelectedItems.Count = 1 Then
                Delete_Index = ListView_False.SelectedIndices(0)
                Destination = "TABLE"
                Me.m_FuncProcess.FuncFalseFilter.FuncFalse.RemoveAt(Delete_Index)
                Me.ListView_False.Items(Delete_Index).Remove()
            ElseIf Me.ListView_New.SelectedIndices.Count = 1 Then
                Delete_Index = ListView_New.SelectedIndices(0)
                Destination = "TEMP"
                Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.RemoveAt(ListView_New.SelectedIndices(0))
                Me.ListView_New.Items(Delete_Index).Remove()
            Else
                MessageBox.Show("�п�ܳ�@Defect�R��", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable_1(True)
                Exit Sub
            End If

            Button_DeleteOne.Enabled = False
            ff_TableDeleteEnable = False
            ff_TempDeleteEnable = False

            '----------------------------------------------------------------------------------------------
            ' Delete One Func False   ==> Request_Command = "FUNC_FALSE_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_FALSE_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, Destination, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Func False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_DeleteOne]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_DeleteOne]Delete One Func False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Select Case ComboBox_GenSample.SelectedIndex
                Case 0
                    Call FalseDefectTableListReflash()
                Case 1
                    Call FalseDefectTempListReflash()
            End Select

            'Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_DeleteOne]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_DeleteOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Clear_Click ---"
    Private Sub Button_Clear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Clear.Click
        Dim Destination As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_1(False)

            Select Case ComboBox_GenSample.SelectedIndex
                Case 0
                    Me.ListView_False.Items.Clear()
                    Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Clear()
                    Destination = "TABLE"
                Case 1
                    Me.ListView_New.Items.Clear()
                    Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Clear()
                    Destination = "TEMP"
            End Select

            '----------------------------------------------------------------------------------------------
            ' Clear all Func False   ==> Request_Command = "FUNC_FALSE_CLEAR " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_FALSE_CLEAR"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Destination, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_Clear]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_1(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_Clear]Clear all Func False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Select Case ComboBox_GenSample.SelectedIndex
                Case 0
                    Call FalseDefectTableListReflash()
                Case 1
                    Call FalseDefectTempListReflash()
            End Select

            'Enable Button ---
            Me.Button_Enable_1(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_Clear]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_Clear]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_Save_Click ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click

        'Disable Button ---
        Me.Button_Enable_1(False)

        Me.Setting()

        'Enable Button ---
        Me.Button_Enable_1(True)
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Cancel_Click ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.Close()
    End Sub
#End Region

#End Region

#Region "--- Func Filter Region ---"

#Region "--- Button_FR_AddOne_Click ---"
    Private Sub Button_FR_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FR_AddOne.Click
        Dim pb As New ClsParameterBoundary
        Dim str As String
        Dim lvi As ListViewItem
        Dim FilterRegion As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_2(False)

            If Me.TextBox_MinX.Text <> "" AndAlso Me.TextBox_MaxX.Text <> "" AndAlso Me.TextBox_MinY.Text <> "" AndAlso Me.TextBox_MaxY.Text <> "" Then
                If Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then   'ROI
                    pb.LeftX = CInt(Me.TextBox_MinX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.TopY = CInt(Me.TextBox_MinY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                    pb.RightX = CInt(Me.TextBox_MaxX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.BottomY = CInt(Me.TextBox_MaxY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

                    If Me.ComboBox_FR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_FR_Pattern.Text
                    End If
                    If Me.ComboBox_FR_Blacking.Text = "" Then    '2012/09/04 Rick add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_FR_Blacking.Text)
                    End If

                    pb.PType = NumericUpDown_PType.Value
                Else   '���v��
                    pb.LeftX = CInt(Me.TextBox_MinX.Text)
                    pb.TopY = CInt(Me.TextBox_MinY.Text)
                    pb.RightX = CInt(Me.TextBox_MaxX.Text)
                    pb.BottomY = CInt(Me.TextBox_MaxY.Text)

                    If Me.ComboBox_FR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_FR_Pattern.Text
                    End If
                    If Me.ComboBox_FR_Blacking.Text = "" Then    '2012/09/04 Rick add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_FR_Blacking.Text)
                    End If

                    pb.PType = NumericUpDown_PType.Value
                End If

                Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.Add(pb)
                lvi = Me.ListView_FilterRegion.Items.Add(Me.TextBox_MinX.Text)
                lvi.SubItems.Add(Me.TextBox_MinY.Text)
                lvi.SubItems.Add(Me.TextBox_MaxX.Text)
                lvi.SubItems.Add(Me.TextBox_MaxY.Text)
                If Me.ComboBox_FR_Pattern.Text = "" Then
                    lvi.SubItems.Add("ALL")
                Else
                    lvi.SubItems.Add(Me.ComboBox_FR_Pattern.Text)   '09/28 Rick add
                End If

                If Me.ComboBox_FR_Blacking.Text = "" Then
                    lvi.SubItems.Add("False")
                Else
                    lvi.SubItems.Add(Me.ComboBox_FR_Blacking.Text)   '2012/09/04 Rick add
                End If

                lvi.SubItems.Add(NumericUpDown_PType.Value)

                'Update Filter Region ---
                FilterRegion = FilterRegion & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ",Blacking," & pb.Blacking & ",PType," & pb.PType & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Filter Region   ==> Request_Command = "FUNC_FILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "FUNC_FILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FilterRegion, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_2(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_AddRegion]Add One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            Me.TextBox_MinX.Text = ""
            Me.TextBox_MinY.Text = ""
            Me.TextBox_MaxX.Text = ""
            Me.TextBox_MaxY.Text = ""
            Me.NumericUpDown_PType.Value = 999

            '2009/09/24 ��s���| ---
            Me.Label_FRCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.Count   '04/16 Rick add

            If (Response_OK = False) Then
                Me.Button_Enable_2(True)
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Func Filter Region File ==> Request_Command = "SAVE_FUNC_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_FILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncFilterRegion(str)
                str = str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddRegion]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_AddRegion]Save Func Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_AddRegion]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddRegion]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_FR_DeleteOne_Click ---"
    Private Sub Button_FR_DeleteOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FR_DeleteOne.Click
        If Me.ListView_FilterRegion.SelectedItems.Count <= 0 Then Exit Sub

        Dim Str As String
        Dim offX As Integer
        Dim offY As Integer
        Dim Delete_Index As Integer

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_2(False)

            offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

            Delete_Index = Me.ListView_FilterRegion.SelectedIndices(0)
            If Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.Count > 0 AndAlso Me.ListView_FilterRegion.SelectedIndices.Count <> 0 Then
                Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.RemoveAt(Delete_Index)
                Me.TextBox_MinX.Text = ""
                Me.TextBox_MinY.Text = ""
                Me.TextBox_MaxX.Text = ""
                Me.TextBox_MaxY.Text = ""
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.DrawFuncFilterRegion(0, 0, Me.CheckBox_Show_FR_Single.Checked)    '2012/10/01 Rick modify
                Me.FilterRegionReflash()
            End If
            Me.Button_FR_DeleteOne.Enabled = False

            '----------------------------------------------------------------------------------------------
            ' Delete One Func Filter Region   ==> Request_Command = "FUNC_FILTERREGION_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_FILTERREGION_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Func Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_FR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_FR_DeleteOne_Click]Delete One Func Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Filter Region File ==> Request_Command = "SAVE_FUNC_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_FILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_FR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_FR_DeleteOne_Click]Save Func Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_FR_DeleteOne_Click]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_FR_DeleteOne_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_FR_CLearAll_Click ---"
    Private Sub Button_FR_ClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FR_ClearAll.Click
        Dim Str As String

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_2(False)

            Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.Clear()
            Call FilterRegionReflash()

            '----------------------------------------------------------------------------------------------
            ' Clear all Func Filter Region   ==> Request_Command = "FUNC_FILTERREGION_CLEAR " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_FILTERREGION_CLEAR"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_FR_CLearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_FR_ClearAll_Click]Clear all Func Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Filter Region File ==> Request_Command = "SAVE_FUNC_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_FILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.btnOK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_FR_ClearAll_Click]Clear all Func Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_2(True)
        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_FR_ClearAll_Click]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_FR_ClearAll_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_FR_Save_Click ---"
    Private Sub Button_FR_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FR_Save.Click
        Dim i As Integer
        Dim Str As String
        Dim FR_Lists As String = ""
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary

        pba = Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion


        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_2(False)

            Me.m_Panel_AxMDisplay.Refresh()   '02/01 Rick add

            '----------------------------------------------------------------------------------------------
            ' Update Func Filter Region ==> Request_Command = "UPDATE_FUNC_FILTERREGION" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "UPDATE_FUNC_FILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                For i = 0 To pba.Count() - 1
                    pb = pba.Item(i)
                    FR_Lists = FR_Lists & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ",Blacking," & pb.Blacking & ",PType," & pb.PType & ";"
                Next

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FR_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Func Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.btnOK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.btnOK]Update Func Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Filter Region File ==> Request_Command = "SAVE_FUNC_FILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_FILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.btnOK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.btnOK]Save Func Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_2(True)

        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.btnOK]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.btnOK]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_FR_Close_Click ---"
    Private Sub Button_FR_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FR_Close.Click
        Me.Close()
    End Sub
#End Region

#End Region

#Region "--- Un-Filter Region ---"

#Region "--- Button_UFR_AddOne_Click ---"
    Private Sub Button_UFR_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_UFR_AddOne.Click   '07/22 Rick add
        Dim pb As New ClsParameterBoundary
        Dim str As String
        Dim lvi As ListViewItem
        Dim UFR As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_3(False)

            If Me.TextBox_UFR_MinX.Text <> "" AndAlso Me.TextBox_UFR_MaxX.Text <> "" AndAlso Me.TextBox_UFR_MinY.Text <> "" AndAlso Me.TextBox_UFR_MaxY.Text <> "" Then
                If Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then   'ROI
                    pb.LeftX = CInt(Me.TextBox_UFR_MinX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.TopY = CInt(Me.TextBox_UFR_MinY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                    pb.RightX = CInt(Me.TextBox_UFR_MaxX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.BottomY = CInt(Me.TextBox_UFR_MaxY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

                    If Me.ComboBox_UFR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_UFR_Pattern.Text
                    End If

                    If Me.ComboBox_UFR_Mask.Text = "" Then    '2015/07/21 Addis add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_UFR_Mask.Text)
                    End If

                Else   '���v��
                    pb.LeftX = CInt(Me.TextBox_UFR_MinX.Text)
                    pb.TopY = CInt(Me.TextBox_UFR_MinY.Text)
                    pb.RightX = CInt(Me.TextBox_UFR_MaxX.Text)
                    pb.BottomY = CInt(Me.TextBox_UFR_MaxY.Text)

                    If Me.ComboBox_UFR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_UFR_Pattern.Text
                    End If

                    If Me.ComboBox_UFR_Mask.Text = "" Then    '2015/07/21 Addis add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_UFR_Mask.Text)
                    End If

                End If

                Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.Add(pb)
                lvi = Me.ListView_UnFilterRegion.Items.Add(Me.TextBox_UFR_MinX.Text)
                lvi.SubItems.Add(Me.TextBox_UFR_MinY.Text)
                lvi.SubItems.Add(Me.TextBox_UFR_MaxX.Text)
                lvi.SubItems.Add(Me.TextBox_UFR_MaxY.Text)
                If Me.ComboBox_UFR_Pattern.Text = "" Then
                    lvi.SubItems.Add("ALL")
                Else
                    lvi.SubItems.Add(Me.ComboBox_UFR_Pattern.Text)   '09/28 Rick add
                End If

                If Me.ComboBox_UFR_Mask.Text = "" Then    '2015/07/21 Addis add
                    lvi.SubItems.Add("False")
                Else
                    lvi.SubItems.Add(Me.ComboBox_UFR_Mask.Text)
                End If

                'Update Un-Filter Region ---
                UFR = UFR & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ",Mask," & pb.Blacking & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Un-Filter Region   ==> Request_Command = "FUNC_UNFILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "FUNC_UNFILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, UFR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddUFR]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_3(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_AddUFR]Add One Un-Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            Me.TextBox_UFR_MinX.Text = ""
            Me.TextBox_UFR_MinY.Text = ""
            Me.TextBox_UFR_MaxX.Text = ""
            Me.TextBox_UFR_MaxY.Text = ""

            '2009/09/24 ��s���| ---
            Me.Label_UFRCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.Count   '04/16 Rick add

            If (Response_OK = False) Then
                Me.Button_Enable_3(True)
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_UNFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_UNFILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncUnFilterRegion(str)
                str = str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddUFR]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_AddUFR]Save Func Un-Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_3(True)
        Catch ex As Exception
            Me.Button_Enable_3(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_AddUFR]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddUFR]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_UFR_DeleteOne_Click ---"
    Private Sub Button_UFR_DeleteOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_UFR_DeleteOne.Click   '07/22 Rick add
        If Me.ListView_UnFilterRegion.SelectedItems.Count <= 0 Then Exit Sub

        Dim Str As String
        Dim offX As Integer
        Dim offY As Integer
        Dim Delete_Index As Integer

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_3(False)

            offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

            Delete_Index = Me.ListView_UnFilterRegion.SelectedIndices(0)
            If Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.Count > 0 AndAlso Me.ListView_UnFilterRegion.SelectedIndices.Count <> 0 Then
                Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.RemoveAt(Delete_Index)
                Me.TextBox_UFR_MinX.Text = 0
                Me.TextBox_UFR_MinY.Text = 0
                Me.TextBox_UFR_MaxX.Text = 0
                Me.TextBox_UFR_MaxY.Text = 0
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.DrawFuncUnFilterRegion(0, 0, Me.CheckBox_Show_UFR_Single.Checked)    '11/17 Rick add
                Me.UnFilterRegionReflash()
            End If
            Me.Button_UFR_DeleteOne.Enabled = False

            '----------------------------------------------------------------------------------------------
            ' Delete One Func Un-Filter Region   ==> Request_Command = "FUNC_UNFILTERREGION_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_UNFILTERREGION_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Func Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_UFR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_UFR_DeleteOne_Click]Delete One Un-Func False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If (Response_OK = False) Then Exit Sub
            '----------------------------------------------------------------------------------------------
            ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_UNFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_UNFILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Un-Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncUnFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_UFR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_UFR_DeleteOne_Click]Save Func Un-Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_3(True)
        Catch ex As Exception
            Me.Button_Enable_3(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_UFR_Delete]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_UFR_Delete]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_UFR_CLearAll_Click ---"
    Private Sub Button_UFR_CLearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_UFR_CLearAll.Click
        Dim Str As String

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_3(False)

            Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.Clear()
            Call UnFilterRegionReflash()

            '----------------------------------------------------------------------------------------------
            ' Clear all Func Un-Filter Region   ==> Request_Command = "FUNC_UNFILTERREGION_CLEAR " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_UNFILTERREGION_CLEAR"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_UFR_CLearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_UFR_CLearAll]Clear all Func Un-Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_UNFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_UNFILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncUnFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_UFR_CLearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_UFR_CLearAll]Clear all Func Un-Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_3(True)
        Catch ex As Exception
            Me.Button_Enable_3(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_UFR_CLearAll]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_UFR_CLearAll]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_UFR_Save_Click ---"
    Private Sub Button_UFR_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_UFR_Save.Click    '07/22 Rick add
        Dim i As Integer
        Dim Str As String
        Dim FR_Lists As String = ""
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary

        pba = Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion


        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_3(False)

            Me.m_Panel_AxMDisplay.Refresh()   '02/01 Rick add

            '----------------------------------------------------------------------------------------------
            ' Update Func Un-Filter Region ==> Request_Command = "UPDATE_FUNC_UNFILTERREGION" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "UPDATE_FUNC_UNFILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                For i = 0 To pba.Count() - 1
                    pb = pba.Item(i)
                    FR_Lists = FR_Lists & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ",Mask," & pb.Blacking & ";"
                Next

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FR_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Func Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_UFR_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_UFR_Save]Update Func Un-Filter Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_UNFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_UNFILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Un-Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncUnFilterRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.btn_UFR_OK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_3(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.btn_UFR_OK]Save Func Un-Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_3(True)

        Catch ex As Exception
            Me.Button_Enable_3(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.btn_UFR_OK]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.btn_UFR_OK]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_UFR_Close_Click ---"
    Private Sub Button_UFR_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_UFR_Close.Click   '07/22 Rick add
        Me.Close()
    End Sub
#End Region

#End Region

#Region "--- Func Back Particle ---"

#Region "--- Button_BackParticle_CLearAll ---"
    Private Sub Button_BackParticle_CLearAll_Click(sender As System.Object, e As System.EventArgs) Handles Button_BackParticle_CLearAll.Click
        Dim Str As String

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_4(False)

            Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Clear()

            '----------------------------------------------------------------------------------------------
            ' Clear all Func Back Particle   ==> Request_Command = "FUNC_BACKPARTICLE_CLEAR " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_BACKPARTICLE_CLEAR"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func Back Particle Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_CLearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_BackParticle_CLearAll]Clear all Func Back Particle Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Count > 0 Then
                'Save Func False Defect Table ---
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncBackParticleTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveBackParticleTable(Str)

                '----------------------------------------------------------------------------------------------
                ' Save Func Back Particle Defect Table File ==> Request_Command = "SAVE_FUNC_BACKPARTICLETABLE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_FUNC_BACKPARTICLETABLE"

                    'Prepare Command ---
                    TimeOut = 300000 '300 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Back Particle Defect Table File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_CLearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_4(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_BackParticle_CLearAll]Save Func Back Particle Defect Table File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            Call BackParticleListReflash()

            'Enable Button ---
            Me.Button_Enable_4(True)
        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_BackParticle_CLearAll]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_CLearAll]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_BackParticle_DeleteOne ---"
    Private Sub Button_BackParticle_DeleteOne_Click(sender As System.Object, e As System.EventArgs) Handles Button_BackParticle_DeleteOne.Click
        Dim Delete_Index As Integer

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_4(False)

            Delete_Index = ListView_ParticleTable.SelectedIndices(0)
            Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.RemoveAt(Delete_Index)

            '----------------------------------------------------------------------------------------------
            ' Delete One Back Particle False   ==> Request_Command = "FUNC_BACKPARTICLE_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_BACKPARTICLE_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Back Particle False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_DeleteOne]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_BackParticle_DeleteOne]Delete One Back Particle False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Call BackParticleListReflash()

            'Enable Button ---
            Me.Button_Enable_4(True)
        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_BackParticle_DeleteOne]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_DeleteOne]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_BackParticle_Save_Click ---"
    Private Sub Button_BackParticle_Save_Click(sender As System.Object, e As System.EventArgs) Handles Button_BackParticle_Save.Click
        Dim i As Integer
        Dim Str As String
        Dim BackParticle_Lists As String = ""
        Dim ffa As PositionArray
        Dim ff As Position

        ffa = Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_4(False)

            Me.m_Panel_AxMDisplay.Refresh()   '02/01 Rick add

            '----------------------------------------------------------------------------------------------
            ' Update Func Back Particle ==> Request_Command = "UPDATE_FUNC_BACKPARTICLE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "UPDATE_FUNC_BACKPARTICLE"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                For i = 0 To ffa.Count() - 1
                    ff = ffa.GetPosition(i)
                    BackParticle_Lists = BackParticle_Lists & "Type," & ff.Type & ",BlobX," & ff.BlobX & ",BlobY," & ff.BlobY & ";"
                Next

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, BackParticle_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Func Back Particle Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_Save_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.btnOK]Update Func Back Particle Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Back Particle Table File ==> Request_Command = "SAVE_FUNC_BACKPARTICLETABLE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_BACKPARTICLETABLE"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncBackParticleTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveBackParticleTable(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Back Particle Table File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_Save_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_4(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_BackParticle_Save_Click]Save Func Back Particle Table File Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_4(True)

        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_BackParticle_Save_Click]" & ex.Message & ")(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_BackParticle_Save_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- Button_BackParticle_Close_Click ---"
    Private Sub Button_BackParticle_Close_Click(sender As System.Object, e As System.EventArgs) Handles Button_BackParticle_Close.Click
        Me.Close()
    End Sub
#End Region

#End Region

#Region "--- Mask Mark Region ---"

#Region "--- Button_MMR_AddOne_Click ---"
    Private Sub Button_MMR_AddOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MMR_AddOne.Click
        Dim pb As New ClsParameterBoundary
        Dim str As String
        Dim lvi As ListViewItem
        Dim MMR As String = ""

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_5(False)

            If Me.TextBox_MMR_MinX.Text <> "" AndAlso Me.TextBox_MMR_MaxX.Text <> "" AndAlso Me.TextBox_MMR_MinY.Text <> "" AndAlso Me.TextBox_MMR_MaxY.Text <> "" Then
                If Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then   'ROI
                    pb.LeftX = CInt(Me.TextBox_MMR_MinX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.TopY = CInt(Me.TextBox_MMR_MinY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                    pb.RightX = CInt(Me.TextBox_MMR_MaxX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.BottomY = CInt(Me.TextBox_MMR_MaxY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

                    If Me.ComboBox_MMR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_MMR_Pattern.Text
                    End If
                Else   '���v��
                    pb.LeftX = CInt(Me.TextBox_MMR_MinX.Text)
                    pb.TopY = CInt(Me.TextBox_MMR_MinY.Text)
                    pb.RightX = CInt(Me.TextBox_MMR_MaxX.Text)
                    pb.BottomY = CInt(Me.TextBox_MMR_MaxY.Text)

                    If Me.ComboBox_MMR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_MMR_Pattern.Text
                    End If
                End If

                Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.Add(pb)
                lvi = Me.ListView_MaskMarkRegion.Items.Add(Me.TextBox_MMR_MinX.Text)
                lvi.SubItems.Add(Me.TextBox_MMR_MinY.Text)
                lvi.SubItems.Add(Me.TextBox_MMR_MaxX.Text)
                lvi.SubItems.Add(Me.TextBox_MMR_MaxY.Text)
                If Me.ComboBox_MMR_Pattern.Text = "" Then
                    lvi.SubItems.Add("ALL")
                Else
                    lvi.SubItems.Add(Me.ComboBox_MMR_Pattern.Text)   '09/28 Rick add
                End If

                'Update Un-Filter Region ---
                MMR = MMR & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Mask Mark Region   ==> Request_Command = "FUNC_MASKMARKREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "FUNC_MASKMARKREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, MMR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Mask Mark Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddMMR]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_5(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_AddMMR]Add One Mask Mark Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            Me.TextBox_MMR_MinX.Text = ""
            Me.TextBox_MMR_MinY.Text = ""
            Me.TextBox_MMR_MaxX.Text = ""
            Me.TextBox_MMR_MaxY.Text = ""

            '2009/09/24 ��s���| ---
            Me.Label_MMRCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.Count   '04/16 Rick add

            If (Response_OK = False) Then
                Me.Button_Enable_5(True)
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_MASKMARKREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_MASKMARKREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncMaskMarkRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncMaskMarkRegion(str)
                str = str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Mask Mark Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddMMR]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_AddMMR]Save Func Mask Mark Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_5(True)
        Catch ex As Exception
            Me.Button_Enable_5(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_AddMMR]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_AddMMR]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_MMR_DeleteOne_Click ---"
    Private Sub Button_MMR_DeleteOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MMR_DeleteOne.Click   '07/22 Rick add
        If Me.ListView_MaskMarkRegion.SelectedItems.Count <= 0 Then Exit Sub

        Dim Str As String
        Dim offX As Integer
        Dim offY As Integer
        Dim Delete_Index As Integer

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_5(False)

            offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

            Delete_Index = Me.ListView_MaskMarkRegion.SelectedIndices(0)
            If Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.Count > 0 AndAlso Me.ListView_MaskMarkRegion.SelectedIndices.Count <> 0 Then
                Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.RemoveAt(Delete_Index)
                Me.TextBox_MMR_MinX.Text = 0
                Me.TextBox_MMR_MinY.Text = 0
                Me.TextBox_MMR_MaxX.Text = 0
                Me.TextBox_MMR_MaxY.Text = 0
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                Me.DrawFuncMaskMarkRegion(0, 0, Me.CheckBox_Show_MMR_Single.Checked)    '11/17 Rick add
                Me.MaskMarkRegionReflash()
            End If
            Me.Button_MMR_DeleteOne.Enabled = False

            '----------------------------------------------------------------------------------------------
            ' Delete One Func Mask Mark Region   ==> Request_Command = "FUNC_MASKMARKREGION_DELETEONE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_MASKMARKREGION_DELETEONE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Func Mask Mark Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_MMR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_MMR_DeleteOne_Click]Delete One Mask Mark False Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If (Response_OK = False) Then Exit Sub
            '----------------------------------------------------------------------------------------------
            ' Save Func Mask Mark Region File ==> Request_Command = "SAVE_FUNC_MASKMARKREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_MASKMARKREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Mask Mark Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncMaskMarkRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncMaskMarkRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Mask Mark Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_MMR_DeleteOne_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_MMR_DeleteOne_Click]Save Func Mask Mark Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_5(True)
        Catch ex As Exception
            Me.Button_Enable_5(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_MMR_Delete]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_MMR_Delete]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_MMR_CLearAll_Click ---"
    Private Sub Button_MMR_CLearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MMR_CLearAll.Click
        Dim Str As String

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_5(False)

            Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.Clear()
            Call MaskMarkRegionReflash()

            '----------------------------------------------------------------------------------------------
            ' Clear all Func Mask Mark Region   ==> Request_Command = "FUNC_MASKMARKREGION_CLEAR " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FUNC_MASKMARKREGION_CLEAR"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func Mask Mark Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_MMR_CLearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_MMR_CLearAll]Clear all Func Mask Mark Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Mask Mark Region File ==> Request_Command = "SAVE_FUNC_MASKMARKREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_MASKMARKREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncMaskMarkRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncMaskMarkRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Clear all Func Mask Mark Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_MMR_CLearAll]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_MMR_CLearAll]Clear all Func Mask Mark Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_5(True)
        Catch ex As Exception
            Me.Button_Enable_5(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_MMR_CLearAll]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_MMR_CLearAll]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_MMR_Save_Click ---"
    Private Sub Button_MMR_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MMR_Save.Click
        Dim i As Integer
        Dim Str As String
        Dim MMR_Lists As String = ""
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary

        pba = Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion


        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_5(False)

            Me.Setting()
            Me.m_Panel_AxMDisplay.Refresh()   '02/01 Rick add

            '----------------------------------------------------------------------------------------------
            ' Update Func Mask Mark Region ==> Request_Command = "UPDATE_FUNC_MASKMARKREGION" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "UPDATE_FUNC_MASKMARKREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                For i = 0 To pba.Count() - 1
                    pb = pba.Item(i)
                    MMR_Lists = MMR_Lists & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ";"
                Next

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, MMR_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Func Mask Mark Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.Button_MMR_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_2(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.Button_MMR_Save]Update Func Mask Mark Region Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Mask Mark Region File ==> Request_Command = "SAVE_FUNC_MASKMARKREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_MASKMARKREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Mask Mark Region
                Str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncMaskMarkRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncMaskMarkRegion(Str)
                Str = Str.Replace("\", "\\")

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Mask Mark Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.btn_MMR_OK]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.btn_MMR_OK]Save Func Mask Mark Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Enable Button ---
            Me.Button_Enable_5(True)

        Catch ex As Exception
            Me.Button_Enable_5(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.btn_MMR_OK]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.btn_MMR_OK]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_MMR_Close_Click ---"
    Private Sub Button_MMR_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MMR_Close.Click   '07/22 Rick add
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Calculate_MaskImage_Click ---"
    Private Sub Button_Calculate_MaskImage_Click(sender As System.Object, e As System.EventArgs) Handles Button_Calculate_MaskImage.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '�إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Disable Button ---
        Me.Button_Enable_5(False)

        '----------------------------------------------------------------------------------------------
        ' Calculate Mask Mark Image  ==> Request_Command = "CALCULATE_MASKMARK_IMAGE"  (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_MASKMARK_IMAGE"
            TimeOut = 300000 '300 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mask Mark Image Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

            If Response_OK Then
                '--- Update Processed Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_MaskMark.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_MaskMark.tif"
                    RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image)
                            Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask = M_NULL
                            Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(strPath, Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask)
                End If

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 3 Then
                    If Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask <> M_NULL Then
                        image = Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask
                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)

                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                            MbufFree(imageBuffer)
                            imageBuffer = M_NULL
                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        '--- Load Remote Image ---
                        MbufCopy(image, imageBuffer)

                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                        Me.m_Form.ResetScrollBar()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                Else
                    Me.m_Form.CurrentIndex0 = 3
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 3
                End If

            End If

            '--- Enable Button ---
            Me.Button_Enable_5(True)
        Catch ex As Exception
            Me.Button_Enable_5(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.Button_Calculate_MaskImage_Click]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncFalseDefect.Button_Calculate_MaskImage_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#End Region

#Region "--- ListView Event ---"

#Region "--- Func False Defect ---"

#Region "--- ListView_False_DoubleClick ---"
    Private Sub ListView_False_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_False.DoubleClick
        Dim indexes As ListView.SelectedIndexCollection = Me.ListView_False.SelectedIndices
        Dim index As Integer
        Dim picsize As Integer
        Dim offset_X, offset_Y As Integer
        Dim p As New Position
        Dim ZoomX As Double

        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)

        Me.m_Form.SetStatusBarPanel_Scale("�Y�� = " & ZoomX)
        Me.m_Form.SetButton_ZoomIn(True)
        Me.m_Form.SetButton_ZoomOut(True)
        Me.m_Form.ResetScrollBar()

        For Each index In indexes
            p.BlobX = CInt(ListView_False.Items(index).SubItems(2).Text)
            p.BlobY = CInt(ListView_False.Items(index).SubItems(3).Text)
            p.BlobArea = CInt(ListView_False.Items(index).SubItems(4).Text)

            If p.BlobX <> -1 And p.BlobY <> -1 Then
                picsize = Math.Max(CInt(((p.BlobArea) ^ 0.5) * 2), 100)
                Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                    Case 0
                        offset_X = Math.Max(CInt(p.BlobX) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(p.BlobY) - CInt(picsize / 2), 0)
                    Case 1
                        offset_X = Math.Max(CInt(p.BlobX - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - CInt(picsize / 2) - 10, 0)
                        offset_Y = Math.Max(CInt(p.BlobY - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - CInt(picsize / 2) - 10, 0)
                End Select
                offset_X = Math.Min(offset_X, Me.m_Form.HScrollBar.Maximum)
                offset_Y = Math.Min(offset_Y, Me.m_Form.VScrollBar.Maximum)
                Me.m_Form.HScrollBar.Value = offset_X
                Me.m_Form.VScrollBar.Value = offset_Y
                Me.m_Form.ResetScrollBar()
                'Me.DrawMark()
            End If
        Next

        ff_TableDeleteEnable = True
        ff_TempDeleteEnable = False
        ff_DeleteIndex = ListView_False.SelectedIndices(0)
        NumericUpDown_X.Value = CInt(ListView_False.Items(ff_DeleteIndex).SubItems(2).Text)
        NumericUpDown_Y.Value = CInt(ListView_False.Items(ff_DeleteIndex).SubItems(3).Text)
        NumericUpDown_Area.Value = CInt(ListView_False.Items(ff_DeleteIndex).SubItems(4).Text)
        Button_DeleteOne.Enabled = True
    End Sub
#End Region

#Region "--- ListView_New_DoubleClick ---"
    Private Sub ListView_New_DoubleClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListView_New.DoubleClick
        ff_TableDeleteEnable = False
        ff_TempDeleteEnable = True
        ff_DeleteIndex = ListView_New.SelectedIndices(0)
        NumericUpDown_X.Value = CInt(ListView_New.Items(ff_DeleteIndex).SubItems(2).Text)
        NumericUpDown_Y.Value = CInt(ListView_New.Items(ff_DeleteIndex).SubItems(3).Text)
        NumericUpDown_Area.Value = CInt(ListView_New.Items(ff_DeleteIndex).SubItems(4).Text)
        Button_DeleteOne.Enabled = True
    End Sub
#End Region

#Region "--- ListView_False_KeyUp ---"
    Private Sub ListView_False_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_False.KeyUp
        Dim Destination As String = ""
        Dim Delete_Index As Integer

        If e.KeyCode = Keys.Delete AndAlso ListView_False.SelectedIndices.Count <> 0 Then

            If (Me.ComboBox_GenSample.SelectedIndex = 0) Then

                '�إ߳s�u ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                'Disable Button ---
                Me.Button_Enable_1(False)

                Try
                    Delete_Index = ListView_False.SelectedIndices(0)
                    If Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count > 0 Then
                        Destination = "TABLE"
                        Me.m_FuncProcess.FuncFalseFilter.FuncFalse.RemoveAt(Delete_Index)
                    End If

                    Button_DeleteOne.Enabled = False
                    ff_TableDeleteEnable = False

                    '----------------------------------------------------------------------------------------------
                    ' Delete One Func False   ==> Request_Command = "FUNC_FALSE_DELETEONE " (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        'Prepare Command ---
                        Request_Command = "FUNC_FALSE_DELETEONE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, Destination, , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Func False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncFalseDefect.ListView_False_KeyUp]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Enable_1(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.ListView_False_KeyUp]Delete One Func False Error ! (" & ex.Message & ")")
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    Call FalseDefectTableListReflash()

                    'Enable Button ---
                    Me.Button_Enable_1(True)
                Catch ex As Exception
                    Me.Button_Enable_1(True)
                    Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.ListView_False_KeyUp]" & ex.Message)
                    MessageBox.Show("[Dialog_FuncFalseDefect.ListView_False_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If
        End If
    End Sub
#End Region

#Region "--- ListView_New_KeyUp ---"
    Private Sub ListView_New_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        Dim Destination As String = ""
        Dim Delete_Index As Integer

        If e.KeyCode = Keys.Delete AndAlso ListView_New.SelectedIndices.Count <> 0 Then

            Try
                '�إ߳s�u ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                'Disable Button ---
                Me.Button_Enable_1(False)

                Delete_Index = ListView_New.SelectedIndices(0)
                If Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Count > 0 Then
                    Destination = "TEMP"
                    Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.RemoveAt(Delete_Index)
                End If

                Button_DeleteOne.Enabled = False
                ff_TempDeleteEnable = False

                '----------------------------------------------------------------------------------------------
                ' Delete One Func False   ==> Request_Command = "FUNC_FALSE_DELETEONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "FUNC_FALSE_DELETEONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Delete_Index, Destination, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Func False Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.ListView_New_KeyUp]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.ListView_New_KeyUp]Delete One Func False Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Call FalseDefectTempListReflash()

                'Enable Button ---
                Me.Button_Enable_1(True)
            Catch ex As Exception
                Me.Button_Enable_1(True)
                Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.ListView_New_KeyUp]" & ex.Message)
                MessageBox.Show("[Dialog_FuncFalseDefect.ListView_New_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#Region "--- ListView_False_SelectedIndexChanged ---"
    Private Sub ListView_False_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_False.SelectedIndexChanged
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark(False)
        End If
    End Sub
#End Region

#Region "--- ListView_New_SelectedIndexChanged ---"
    Private Sub ListView_New_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_New.SelectedIndexChanged
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark(False)
        End If
    End Sub
#End Region

#End Region

#Region "--- Func Filter Region ---"

#Region "--- ListView_FilterRegion_Click ---"
    Private Sub ListView_FilterRegion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_FilterRegion.Click
        Dim SelectIndex As Integer
        If Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.Count > 0 Then
            SelectIndex = ListView_FilterRegion.SelectedIndices(0)
            Me.TextBox_MinX.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(0).Text
            Me.TextBox_MinY.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(1).Text
            Me.TextBox_MaxX.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(2).Text
            Me.TextBox_MaxY.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(3).Text
            If ListView_FilterRegion.Items(SelectIndex).SubItems(4).Text = "" Then    '09/28 Rick add
                Me.ComboBox_FR_Pattern.Text = "ALL"
            Else
                Me.ComboBox_FR_Pattern.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(4).Text
            End If

            If ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = "" Then    '2012/09/04 Rick add
                Me.ComboBox_FR_Blacking.Text = "False"
            Else
                Me.ComboBox_FR_Blacking.Text = ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text
            End If

            Button_FR_DeleteOne.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ListView_FilterRegion_KeyUp ---"
    Private Sub ListView_FilterRegion_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_FilterRegion.KeyUp
        Try
            If e.KeyCode = Keys.Delete AndAlso ListView_FilterRegion.SelectedIndices.Count <> 0 Then
                Button_FR_DeleteOne_Click(sender, e)   '02/24 Rick modify
            End If

        Catch ex As Exception
            Me.Button_Enable_2(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.ListView_FilterRegion_KeyUp]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.ListView_FilterRegion_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- Func Un-Filter Region ---"

#Region "--- ListView_UnFilterRegion_Click ---"
    Private Sub ListView_UnFilterRegion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_UnFilterRegion.Click
        Dim SelectIndex As Integer
        If Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.Count > 0 Then
            SelectIndex = ListView_UnFilterRegion.SelectedIndices(0)
            Me.TextBox_UFR_MinX.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(0).Text
            Me.TextBox_UFR_MinY.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(1).Text
            Me.TextBox_UFR_MaxX.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(2).Text
            Me.TextBox_UFR_MaxY.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(3).Text
            If ListView_UnFilterRegion.Items(SelectIndex).SubItems(4).Text = "" Then    '09/28 Rick add
                Me.ComboBox_UFR_Pattern.Text = "ALL"
            Else
                Me.ComboBox_UFR_Pattern.Text = ListView_UnFilterRegion.Items(SelectIndex).SubItems(4).Text
            End If

            Me.Button_UFR_DeleteOne.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ListView_UnFilterRegion_KeyUp ---"
    Private Sub ListView_UnFilterRegion_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_UnFilterRegion.KeyUp
        Dim offX As Integer
        Dim offY As Integer
        Dim str As String

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
            If e.KeyCode = Keys.Delete AndAlso Me.ListView_UnFilterRegion.SelectedIndices.Count <> 0 Then
                Me.Button_UFR_DeleteOne_Click(sender, e)   '02/24 Rick modify
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_UNFILTERREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_UNFILTERREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Filter Region
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncUnFilterRegion(str)

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.ListView_UnFilterRegion_KeyUp]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.ListView_UnFilterRegion_KeyUp]Save Func Un-Filter Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.ListView_UnFilterRegion_KeyUp]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.ListView_UnFilterRegion_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- Func Back Particle ---"

#Region "--- ListView_ParticleTable_KeyUp ---"
    Private Sub ListView_ParticleTable_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_ParticleTable.KeyUp
        Try
            If e.KeyCode = Keys.Delete AndAlso ListView_ParticleTable.SelectedIndices.Count <> 0 Then
                Button_BackParticle_DeleteOne_Click(sender, e)
            End If

        Catch ex As Exception
            Me.Button_Enable_4(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.ListView_ParticleTable_KeyUp]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.ListView_ParticleTable_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- Func Mask Mark Region ---"

#Region "--- ListView_Mask MarkRegion_Click ---"
    Private Sub ListView_MaskMarkRegion_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_MaskMarkRegion.Click
        Dim SelectIndex As Integer
        If Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.Count > 0 Then
            SelectIndex = ListView_MaskMarkRegion.SelectedIndices(0)
            Me.TextBox_MMR_MinX.Text = ListView_MaskMarkRegion.Items(SelectIndex).SubItems(0).Text
            Me.TextBox_MMR_MinY.Text = ListView_MaskMarkRegion.Items(SelectIndex).SubItems(1).Text
            Me.TextBox_MMR_MaxX.Text = ListView_MaskMarkRegion.Items(SelectIndex).SubItems(2).Text
            Me.TextBox_MMR_MaxY.Text = ListView_MaskMarkRegion.Items(SelectIndex).SubItems(3).Text
            If ListView_MaskMarkRegion.Items(SelectIndex).SubItems(4).Text = "" Then
                Me.ComboBox_MMR_Pattern.Text = "ALL"
            Else
                Me.ComboBox_MMR_Pattern.Text = ListView_MaskMarkRegion.Items(SelectIndex).SubItems(4).Text
            End If

            Me.Button_MMR_DeleteOne.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ListView_MaskMarkRegion_KeyUp ---"
    Private Sub ListView_MaskMarkRegion_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles ListView_MaskMarkRegion.KeyUp
        Dim offX As Integer
        Dim offY As Integer
        Dim str As String

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
            If e.KeyCode = Keys.Delete AndAlso Me.ListView_MaskMarkRegion.SelectedIndices.Count <> 0 Then
                Me.Button_MMR_DeleteOne_Click(sender, e)
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_MASKMARKREGION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                Request_Command = "SAVE_FUNC_MASKMARKREGION"

                'Prepare Command ---
                TimeOut = 100000 '100 secs

                'Save Func Mask Mark Region
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncMaskMarkRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveFuncMaskMarkRegion(str)

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Mask Mark Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.ListView_MaskMarkRegion_KeyUp]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.ListView_MaskMarkRegion_KeyUp]Save Func Mask Mark Region File Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.ListView_MaskMarkRegion_KeyUp]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.ListView_MaskMarkRegion_KeyUp]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#End Region

#Region "--- ComboBox Event ---"

#Region "--- Filtr Region ---"

#Region "--- ComboBox_FR_Pattern_SelectedIndexChanged ---"
    Private Sub ComboBox_FR_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_FR_Pattern.SelectedIndexChanged   '09/28 Rick add
        Dim SelectIndex As Integer
        Dim pb As ClsParameterBoundary
        Dim pba As ClsParameterBoundaryArray
        If ListView_FilterRegion.SelectedIndices.Count <> 0 Then
            pba = Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion
            SelectIndex = ListView_FilterRegion.SelectedIndices(0)
            pb = pba.Item(SelectIndex)

            If Me.ComboBox_FR_Pattern.Text = "" Then
                ListView_FilterRegion.Items(SelectIndex).SubItems(4).Text = "ALL"
                pb.Pattern = "ALL"
            Else
                ListView_FilterRegion.Items(SelectIndex).SubItems(4).Text = Me.ComboBox_FR_Pattern.Text
                pb.Pattern = Me.ComboBox_FR_Pattern.Text
            End If

        End If
    End Sub
#End Region

#Region "--- ComboBox_FR_Blacking_SelectedIndexChanged ---"
    Private Sub ComboBox_FR_Blacking_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_FR_Blacking.SelectedIndexChanged
        Dim SelectIndex As Integer
        Dim pb As ClsParameterBoundary
        Dim pba As ClsParameterBoundaryArray
        If ListView_FilterRegion.SelectedIndices.Count <> 0 Then
            pba = Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion
            SelectIndex = ListView_FilterRegion.SelectedIndices(0)
            pb = pba.Item(SelectIndex)

            If Me.ComboBox_FR_Blacking.Text = "" Then
                ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = "False"
                pb.Blacking = False
            Else
                ListView_FilterRegion.Items(SelectIndex).SubItems(5).Text = Me.ComboBox_FR_Blacking.Text
                pb.Blacking = Me.ComboBox_FR_Blacking.Text
            End If

        End If
    End Sub
#End Region

#Region "--- ComboBox_Show_FR_Single_SelectedIndexChanged ---"
    Private Sub ComboBox_Show_FR_Single_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Show_FR_Single.SelectedIndexChanged
        If Me.CheckBox_Show_FR_Single.Checked Then
            DrawMark(Me.CheckBox_Show_FR_Single.Checked)
        End If
    End Sub
#End Region

#End Region

#Region "--- Un-Filtr Region ---"

#Region "--- ComboBox_UFR_Pattern_SelectedIndexChanged ---"
    Private Sub ComboBox_UFR_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_UFR_Pattern.SelectedIndexChanged
        Dim SelectIndex As Integer
        Dim pb As ClsParameterBoundary
        Dim pba As ClsParameterBoundaryArray
        If ListView_UnFilterRegion.SelectedIndices.Count <> 0 Then
            pba = Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion
            SelectIndex = ListView_UnFilterRegion.SelectedIndices(0)
            pb = pba.Item(SelectIndex)

            If Me.ComboBox_UFR_Pattern.Text = "" Then
                ListView_UnFilterRegion.Items(SelectIndex).SubItems(4).Text = "ALL"
                pb.Pattern = "ALL"
            Else
                ListView_UnFilterRegion.Items(SelectIndex).SubItems(4).Text = Me.ComboBox_UFR_Pattern.Text
                pb.Pattern = Me.ComboBox_UFR_Pattern.Text
            End If

        End If
    End Sub
#End Region

#Region "--- ComboBox_Show_UFR_Single_SelectedIndexChanged ---"
    Private Sub ComboBox_Show_UFR_Single_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Show_UFR_Single.SelectedIndexChanged
        If Me.CheckBox_Show_UFR_Single.Checked Then
            DrawMark2(Me.CheckBox_Show_UFR_Single.Checked)
        End If
    End Sub
#End Region


#End Region

#Region "--- Mask Mark Region ---"

#Region "--- ComboBox_MMR_Pattern_SelectedIndexChanged ---"
    Private Sub ComboBox_MMR_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_MMR_Pattern.SelectedIndexChanged
        Dim SelectIndex As Integer
        Dim pb As ClsParameterBoundary
        Dim pba As ClsParameterBoundaryArray
        If ListView_MaskMarkRegion.SelectedIndices.Count <> 0 Then
            pba = Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion
            SelectIndex = ListView_MaskMarkRegion.SelectedIndices(0)
            pb = pba.Item(SelectIndex)

            If Me.ComboBox_MMR_Pattern.Text = "" Then
                ListView_MaskMarkRegion.Items(SelectIndex).SubItems(4).Text = "ALL"
                pb.Pattern = "ALL"
            Else
                ListView_MaskMarkRegion.Items(SelectIndex).SubItems(4).Text = Me.ComboBox_MMR_Pattern.Text
                pb.Pattern = Me.ComboBox_MMR_Pattern.Text
            End If

        End If
    End Sub
#End Region

#Region "--- ComboBox_Show_MMR_Single_SelectedIndexChanged ---"
    Private Sub ComboBox_Show_MMR_Single_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Show_MMR_Single.SelectedIndexChanged
        If Me.CheckBox_Show_MMR_Single.Checked Then
            DrawMark3(Me.CheckBox_Show_MMR_Single.Checked)
        End If
    End Sub
#End Region

#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_ShowFilterRegion_CheckedChanged ---"
    Private Sub CheckBox_ShowFilterRegion_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowFilterRegion.CheckedChanged
        If Me.CheckBox_ShowFilterRegion.Checked Then
            Me.CheckBox_Show_FR_Single.Checked = False   '2012/09/27 Rick add
            Me.ComboBox_Show_FR_Single.Enabled = False   '2012/09/27 Rick add

            Me.Button_FR_ClearAll.Enabled = True
            Me.Button_FR_DeleteOne.Enabled = True
            Me.Button_FR_AddOne.Enabled = True

            Me.CheckBox_EnableFalseLine.Enabled =False

            Me.DrawMark(Me.CheckBox_Show_FR_Single.Checked)
        Else
            Me.CheckBox_EnableFalseLine.Enabled =True
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_Show_FR_Single_CheckedChanged ---"
    Private Sub CheckBox_Show_FR_Single_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show_FR_Single.CheckedChanged
        If Me.CheckBox_Show_FR_Single.Checked Then
            Me.CheckBox_ShowFilterRegion.Checked = False   '2012/09/27 Rick add
            Me.CheckBox_FR_Mannual.Checked = False
            Me.ComboBox_Show_FR_Single.Enabled = True

            Me.Button_FR_ClearAll.Enabled = False
            Me.Button_FR_DeleteOne.Enabled = False
            Me.Button_FR_AddOne.Enabled = False

            Me.DrawMark(Me.CheckBox_Show_FR_Single.Checked)
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_ShowUnFilterRegion_CheckedChanged ---"
    Private Sub CheckBox_ShowUnFilterRegion_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_ShowUnFilterRegion.CheckedChanged
        If Me.CheckBox_ShowUnFilterRegion.Checked Then
            Me.CheckBox_Show_UFR_Single.Checked = False   '2012/09/27 Rick add
            Me.ComboBox_Show_UFR_Single.Enabled = False   '2012/09/27 Rick add

            Me.Button_UFR_CLearAll.Enabled = True
            Me.Button_UFR_DeleteOne.Enabled = True
            Me.Button_UFR_AddOne.Enabled = True

            Me.DrawMark2(Me.CheckBox_Show_UFR_Single.Checked)
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_Show_UFR_Single_CheckedChanged ---"
    Private Sub CheckBox_Show_UFR_Single_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show_UFR_Single.CheckedChanged
        If Me.CheckBox_Show_UFR_Single.Checked Then
            Me.CheckBox_ShowUnFilterRegion.Checked = False   '2012/09/27 Rick add
            Me.CheckBox_UFR_Mannual.Checked = False
            Me.ComboBox_Show_UFR_Single.Enabled = True

            Me.Button_UFR_CLearAll.Enabled = False
            Me.Button_UFR_DeleteOne.Enabled = False
            Me.Button_UFR_AddOne.Enabled = False

            Me.DrawMark2(Me.CheckBox_Show_FR_Single.Checked)
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_ShowMaskMarkRegion_CheckedChanged ---"
    Private Sub CheckBox_ShowMaskMarkRegion_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_ShowMaskMarkRegion.CheckedChanged
        If Me.CheckBox_ShowMaskMarkRegion.Checked Then
            Me.CheckBox_Show_MMR_Single.Checked = False
            Me.ComboBox_Show_MMR_Single.Enabled = False

            Me.Button_MMR_CLearAll.Enabled = True
            Me.Button_MMR_DeleteOne.Enabled = True
            Me.Button_MMR_AddOne.Enabled = True

            Me.DrawMark3(Me.CheckBox_Show_MMR_Single.Checked)
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_Show_MMR_Single_CheckedChanged ---"
    Private Sub CheckBox_Show_MMR_Single_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Show_MMR_Single.CheckedChanged
        If Not Me.m_Form.PaintStop And Me.CheckBox_Show_MMR_Single.Checked Then
            Me.CheckBox_ShowMaskMarkRegion.Checked = False
            Me.CheckBox_MMR_Mannual.Checked = False
            Me.ComboBox_Show_MMR_Single.Enabled = True

            Me.Button_MMR_CLearAll.Enabled = False
            Me.Button_MMR_DeleteOne.Enabled = False
            Me.Button_MMR_AddOne.Enabled = False

            Me.DrawMark3(Me.CheckBox_Show_MMR_Single.Checked)
        Else
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_EnableFalseLine_CheckedChanged ---"
    Private Sub CheckBox_EnableFalseLine_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_EnableFalseLine.CheckedChanged
        If CheckBox_EnableFalseLine.Checked = True Then
            Me.CheckBox_ShowFilterRegion.Enabled = False
            Me.CheckBox_FR_Mannual.Enabled = False
            Me.ComboBox_FR_Pattern.Text = "ALL"
            Me.ComboBox_FR_Blacking.Text = "True"
            Me.ComboBox_FR_Blacking.Enabled = False
        Else
            Me.CheckBox_ShowFilterRegion.Enabled = True
            Me.CheckBox_FR_Mannual.Enabled = True
            Me.ComboBox_FR_Blacking.Enabled = True
        End If
    End Sub
#End Region



#End Region

#Region "--- List View Refresh ---"

#Region "--- FalseDefectTableListReflash ---"
    Public Sub FalseDefectTableListReflash()
        Dim ff As New ClsFuncFalse
        Dim lvi As ListViewItem
        Dim i As Integer
        Dim j As Integer
        Dim str As String
        Dim FuncFalse As String = ""
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim strs2() As String
        Dim Defect_Count As Integer

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Load Func False Defect Table   ==> Request_Command = "LOAD_FUNC_FALSEDEFECT_TABLE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "LOAD_FUNC_FALSEDEFECT_TABLE"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Func False Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]Load Func False Defect Table Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Response_OK Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2

                '�ѪR Func False ----
                OutputString = SubSystemResult.Responses(0).Param1
                strs1 = OutputString.Split(";")
                Defect_Count = strs1.Length

                If OutputString <> "" Then
                    If Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count > 0 Then Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Clear()

                    For i = 0 To Defect_Count - 1
                        If strs1(i) <> "" Then
                            strs2 = strs1(i).Split(",")
                            ff = New ClsFuncFalse()

                            For j = 0 To strs2.Length / 2 - 1
                                Select Case strs2(j * 2)

                                    Case "CreateTime"
                                        ff.CreateTime = strs2(j + 1)
                                    Case "Type"
                                        ff.Type = Val(strs2(j * 2 + 1))
                                    Case "PositionX"
                                        ff.PositionX = CDbl(strs2(j * 2 + 1))
                                    Case "PositionY"
                                        ff.PositionY = CDbl(strs2(j * 2 + 1))
                                    Case "Area"
                                        ff.Area = CDbl(strs2(j * 2 + 1))
                                    Case "Count"
                                        ff.Count = CInt(strs2(j * 2 + 1))
                                    Case "Count_Match"
                                        ff.Count_Match = CInt(strs2(j * 2 + 1))
                                    Case "History"
                                        ff.History = strs2(j * 2 + 1)
                                    Case "FalsePattern"
                                        ff.FalsePattern = strs2(j * 2 + 1)
                                End Select

                            Next
                            Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Add(ff)
                        End If
                    Next
                End If
            End If

            Me.ListView_False.Items.Clear()
            ComboBox_GenSample.SelectedIndex = 0

            If Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count > 0 Then
                For i = 0 To Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count - 1   '10/17 Rick modify
                    ff = Me.m_FuncProcess.FuncFalseFilter.FuncFalse.GetFuncFalse(i)
                    lvi = Me.ListView_False.Items.Add(ff.CreateTime)
                    lvi.SubItems.Add(ff.Type)
                    lvi.SubItems.Add(ff.PositionX)
                    lvi.SubItems.Add(ff.PositionY)
                    lvi.SubItems.Add(ff.Area)
                    lvi.SubItems.Add(ff.Count)
                    lvi.SubItems.Add(ff.Count_Match)
                    lvi.SubItems.Add(ff.Flag)
                    lvi.SubItems.Add(ff.History)
                    lvi.SubItems.Add(ff.FalsePattern)
                Next
            End If
            Me.Label_FalseTableCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count
            Me.Label_FalseTempCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Count
            If Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count > Me.m_FuncProcess.FuncModelRecipe.MaxFalseDefectTableCount.Value Then   '10/10 Rick add
                MessageBox.Show("GrabNo = " & Me.m_MainProcess.GrabNo & "�A�ثe False Table Defects = " & Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count, "[�W�L Max False False Defects]", MessageBoxButtons.OK, MessageBoxIcon.Information)   '10/10 Rick add
            End If

            If Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count > 0 Then
                'Save Func False Defect Table ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncFalseDefectTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.Save(str)

                '----------------------------------------------------------------------------------------------
                ' Save Func False Defect Table File ==> Request_Command = "SAVE_FUNC_FALSEDEFECTTABLE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_FUNC_FALSEDEFECTTABLE"

                    'Prepare Command ---
                    TimeOut = 300000 '300 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func False Defect Table File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]Save Func False Defect Table File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- FalseDefectTempListReflash ---"
    Public Sub FalseDefectTempListReflash()
        Dim ff As ClsFuncFalse
        Dim lvi As ListViewItem
        Dim i As Integer
        Dim j As Integer
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim strs2() As String
        Dim Defect_Count As Integer

        '�إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Load Func False Defect Temp    ==> Request_Command = "LOAD_FUNC_FALSEDEFECT_TEMP " (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            'Prepare Command ---
            Request_Command = "LOAD_FUNC_FALSEDEFECT_TEMP"
            TimeOut = 300000 '300 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Func False Defect Temp Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncFalseDefect.FalseDefectTempListReflash]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.FalseDefectTableListReflash]Load Func False Defect Temp Error ! (" & ex.Message & ")")
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        If Response_OK Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2

            '�ѪR Func False ----
            OutputString = SubSystemResult.Responses(0).Param1
            strs1 = OutputString.Split(";")
            Defect_Count = strs1.Length

            If OutputString <> "" Then
                If Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Count > 0 Then Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Clear()

                For i = 0 To Defect_Count - 1
                    If strs1(i) <> "" Then
                        strs2 = strs1(i).Split(",")
                        ff = New ClsFuncFalse()

                        For j = 0 To strs2.Length / 2 - 1
                            Select Case strs2(j * 2)

                                Case "CreateTime"
                                    ff.CreateTime = strs2(j + 1)
                                Case "Type"
                                    ff.Type = Val(strs2(j * 2 + 1))
                                Case "PositionX"
                                    ff.PositionX = CDbl(strs2(j * 2 + 1))
                                Case "PositionY"
                                    ff.PositionY = CDbl(strs2(j * 2 + 1))
                                Case "Area"
                                    ff.Area = CDbl(strs2(j * 2 + 1))
                                Case "Count"
                                    ff.Count = CInt(strs2(j * 2 + 1))
                                Case "Count_Match"
                                    ff.Count_Match = CInt(strs2(j * 2 + 1))
                                Case "History"
                                    ff.History = strs2(j * 2 + 1)
                                Case "FalsePattern"
                                    ff.FalsePattern = strs2(j * 2 + 1)
                            End Select

                        Next
                        Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Add(ff)
                    End If
                Next
            Else
                Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Clear()
            End If
        End If

        ListView_New.Items.Clear()
        Try
            If Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Count > 0 Then
                For i = 0 To Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Count - 1    '10/17 Ric modify
                    ff = Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.GetFuncFalse(i)

                    lvi = Me.ListView_New.Items.Add(ff.CreateTime)
                    lvi.SubItems.Add(ff.Type)
                    lvi.SubItems.Add(ff.PositionX)
                    lvi.SubItems.Add(ff.PositionY)
                    lvi.SubItems.Add(ff.Area)
                    lvi.SubItems.Add(ff.Count)
                    lvi.SubItems.Add(ff.Count_Match)
                    lvi.SubItems.Add(ff.Flag)
                    lvi.SubItems.Add(ff.History)
                    lvi.SubItems.Add(ff.FalsePattern)
                Next
            End If
            Me.Label_FalseTableCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFalse.Count
            Me.Label_FalseTempCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFalseHistory.Count
        Catch ex As Exception
            Throw New Exception("[Dialog_FuncFalseDefect.FalseDefectTempListReflash]Reflash False Defect Temp List Error! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- FilterRegionReflash ---"
    Public Sub FilterRegionReflash()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary

        Me.ListView_FilterRegion.Items.Clear()

        pba = Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion
        For i = 0 To pba.Count - 1
            pb = pba.Item(i)
            lvi = Me.ListView_FilterRegion.Items.Add(pb.LeftX)
            lvi.SubItems.Add(pb.TopY)
            lvi.SubItems.Add(pb.RightX)
            lvi.SubItems.Add(pb.BottomY)
            lvi.SubItems.Add(pb.Pattern)   '09/28 Rick add
            lvi.SubItems.Add(pb.Blacking)   '2012/09/04 Rick add
            lvi.SubItems.Add(pb.PType)
        Next
        Me.Label_FRCount.Text = "�ƶq = " & pba.Count
        Me.DrawMark(Me.CheckBox_Show_FR_Single.Checked)   '02/04 Rick add
    End Sub
#End Region

#Region "--- UnFilterRegionReflash ---"
    Public Sub UnFilterRegionReflash()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary

        Me.ListView_UnFilterRegion.Items.Clear()

        pba = Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion
        For i = 0 To pba.Count - 1
            pb = pba.Item(i)
            lvi = Me.ListView_UnFilterRegion.Items.Add(pb.LeftX)
            lvi.SubItems.Add(pb.TopY)
            lvi.SubItems.Add(pb.RightX)
            lvi.SubItems.Add(pb.BottomY)
            lvi.SubItems.Add(pb.Pattern)   '09/28 Rick add
            lvi.SubItems.Add(pb.Blacking)   '2015/07/21 Addis add
        Next
        Me.Label_UFRCount.Text = "�ƶq = " & pba.Count
        Me.DrawMark2(Me.CheckBox_Show_UFR_Single.Checked)   '02/04 Rick add
    End Sub
#End Region

#Region "--- BackParticleListReflash ---"
    Public Sub BackParticleListReflash()
        Dim ff As New Position
        Dim lvi As ListViewItem
        Dim i As Integer
        Dim j As Integer
        Dim str As String
        Dim FuncFalse As String = ""
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim strs2() As String
        Dim Defect_Count As Integer

        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Load Func Back Particle Defect Table   ==> Request_Command = "LOAD_FUNC_BACKPARTICLE_TABLE " (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "LOAD_FUNC_BACKPARTICLE_TABLE"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Func Back Particle Defect Table Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncFalseDefect.BackParticleListReflash]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.BackParticleListReflash]Load Func Back Particle Defect Table Error ! (" & ex.Message & ")")
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Response_OK Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2

                '�ѪR Func False ----
                OutputString = SubSystemResult.Responses(0).Param1
                strs1 = OutputString.Split(";")
                Defect_Count = strs1.Length

                If OutputString <> "" Then
                    If Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Count > 0 Then Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Clear()

                    For i = 0 To Defect_Count - 1
                        If strs1(i) <> "" Then
                            strs2 = strs1(i).Split(",")
                            ff = New Position()

                            For j = 0 To strs2.Length / 2 - 1
                                Select Case strs2(j * 2)
                                    Case "Type"
                                        ff.Type = Val(strs2(j * 2 + 1))
                                    Case "BlobX"
                                        ff.BlobX = CDbl(strs2(j * 2 + 1))
                                    Case "BlobY"
                                        ff.BlobY = CDbl(strs2(j * 2 + 1))

                                End Select

                            Next
                            Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Add(ff)
                        End If
                    Next
                End If
            End If

            Me.ListView_ParticleTable.Items.Clear()

            If Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Count > 0 Then
                For i = 0 To Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Count - 1   '10/17 Rick modify
                    ff = Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.GetPosition(i)
                    lvi = Me.ListView_ParticleTable.Items.Add(ff.Type)
                    lvi.SubItems.Add(ff.BlobX)
                    lvi.SubItems.Add(ff.BlobY)
                Next
            End If
            Me.Label_BackParticleCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Count

            If Me.m_FuncProcess.FuncFalseFilter.FuncBackParticleFalse.Count > 0 Then
                'Save Func False Defect Table ---
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncBackParticleTable_C" & Me.m_MainProcess.GrabNo & ".txt"
                Me.m_FuncProcess.FuncFalseFilter.SaveBackParticleTable(str)

                '----------------------------------------------------------------------------------------------
                ' Save Func Back Particle Defect Table File ==> Request_Command = "SAVE_FUNC_BACKPARTICLETABLE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_FUNC_BACKPARTICLETABLE"

                    'Prepare Command ---
                    TimeOut = 300000 '300 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Back Particle Defect Table File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.BackParticleListReflash]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.BackParticleListReflash]Save Func Back Particle Defect Table File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.BackParticleListReflash]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.BackParticleListReflash]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- MaskMarkRegionReflash ---"
    Public Sub MaskMarkRegionReflash()
        Dim i As Integer
        Dim lvi As ListViewItem
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary

        Me.ListView_MaskMarkRegion.Items.Clear()

        pba = Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion
        For i = 0 To pba.Count - 1
            pb = pba.Item(i)
            lvi = Me.ListView_MaskMarkRegion.Items.Add(pb.LeftX)
            lvi.SubItems.Add(pb.TopY)
            lvi.SubItems.Add(pb.RightX)
            lvi.SubItems.Add(pb.BottomY)
            lvi.SubItems.Add(pb.Pattern)
        Next
        Me.Label_MMRCount.Text = "�ƶq = " & pba.Count
        Me.DrawMark3(Me.CheckBox_Show_MMR_Single.Checked)
    End Sub
#End Region

#End Region

#Region "--- AxMDisplay Paint Event ---"

#Region "--- m_AxMDisplay_PaintEvent ---"
    Private Sub m_AxMDisplay_PaintEvent(ByVal sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop And Me.CheckBox_ShowFilterRegion.Checked Then
            Me.DrawMark(Me.CheckBox_Show_FR_Single.Checked)
        End If

        If Not Me.m_Form.PaintStop And Me.CheckBox_ShowUnFilterRegion.Checked Then
            Me.DrawMark2(Me.CheckBox_Show_UFR_Single.Checked)
        End If

        If Not Me.m_Form.PaintStop And Me.CheckBox_ShowMaskMarkRegion.Checked Then
            Me.DrawMark3(Me.CheckBox_Show_MMR_Single.Checked)
        End If
    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseDownEvent ---"
    Private Sub m_AxMDisplay_MouseDownEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown

        'Filter Region ---
        If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_FR_Mannual.Checked And Me.CheckBox_ShowFilterRegion.Checked Then   '�ƹ�����
            Me.CheckBox_UFR_Mannual.Checked = False   '07/21 Rick add
            Me.CheckBox_MMR_Mannual.Checked = False
            Me.m_Panel_AxMDisplay.Refresh()   '02/01 Rick add
            Me.TextBox_MinX.Text = CStr(Me.m_Form.MouseX)
            Me.TextBox_MinY.Text = CStr(Me.m_Form.MouseY)
        End If

        'Un-Filter Region ---
        If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_UFR_Mannual.Checked And Me.CheckBox_ShowUnFilterRegion.Checked Then   '�ƹ�����
            Me.m_Panel_AxMDisplay.Refresh()   '07/21 Rick add
            Me.TextBox_UFR_MinX.Text = CStr(Me.m_Form.MouseX)
            Me.TextBox_UFR_MinY.Text = CStr(Me.m_Form.MouseY)
        End If

        'Mask Mark Region ---
        If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_MMR_Mannual.Checked And Me.CheckBox_ShowMaskMarkRegion.Checked Then   '�ƹ�����
            Me.m_Panel_AxMDisplay.Refresh()
            Me.TextBox_MMR_MinX.Text = CStr(Me.m_Form.MouseX)
            Me.TextBox_MMR_MinY.Text = CStr(Me.m_Form.MouseY)
        End If
    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseMoveEvent ---"
    Private Sub m_AxMDisplay_MouseMoveEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        If Me.TabControl_FalseDefect.SelectedTab Is Nothing Then Exit Sub

        'Filter Region ---
        If TabControl_FalseDefect.SelectedTab.Text = "FilterRegion" Then
            If Me.CheckBox_ShowFilterRegion.Checked And Me.CheckBox_FR_Mannual.Checked Then
                Me.CheckBox_UFR_Mannual.Checked = False
                Me.CheckBox_MMR_Mannual.Checked = False
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                If e.Button = Windows.Forms.MouseButtons.Left Then
                    Me.TextBox_MaxX.Text = CStr(Me.m_Form.MouseX)
                    Me.TextBox_MaxY.Text = CStr(Me.m_Form.MouseY)
                End If
                Me.DrawMark(Me.CheckBox_Show_FR_Single.Checked)
            End If
        End If

        'Un-Filter Region ---
        If TabControl_FalseDefect.SelectedTab.Text = "UnFilterRegion" Then
            If Me.CheckBox_ShowUnFilterRegion.Checked And Me.CheckBox_UFR_Mannual.Checked Then
                Me.CheckBox_FR_Mannual.Checked = False
                Me.CheckBox_MMR_Mannual.Checked = False
                Me.m_Panel_AxMDisplay.Refresh()
                Me.m_GraphicsImage.Clear(Color.Transparent)
                If e.Button = Windows.Forms.MouseButtons.Left Then
                    Me.TextBox_UFR_MaxX.Text = CStr(Me.m_Form.MouseX)
                    Me.TextBox_UFR_MaxY.Text = CStr(Me.m_Form.MouseY)
                End If
                Me.DrawMark2(Me.CheckBox_Show_UFR_Single.Checked)
            End If
        End If

        'Mask Mark Region ---
        If TabControl_FalseDefect.SelectedTab.Text = "MaskMarkRegion" Then
            If Me.CheckBox_ShowMaskMarkRegion.Checked And Me.CheckBox_MMR_Mannual.Checked Then
                Me.CheckBox_UFR_Mannual.Checked = False
                Me.CheckBox_FR_Mannual.Checked = False
                'Me.m_Panel_AxMDisplay.Refresh()
                'Me.m_GraphicsImage.Clear(Color.Transparent)
                If e.Button = Windows.Forms.MouseButtons.Left Then
                    Me.TextBox_MMR_MaxX.Text = CStr(Me.m_Form.MouseX)
                    Me.TextBox_MMR_MaxY.Text = CStr(Me.m_Form.MouseY)
                End If
                Me.DrawMark3(Me.CheckBox_Show_MMR_Single.Checked)
            End If
        End If

    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseUpEvent ---"
    Private Sub m_AxMDisplay_MouseUpEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        Try
            '�إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---
            Me.Button_Enable_1(False)
            Me.Button_Enable_2(False)
            Me.Button_Enable_3(False)
            Me.Button_Enable_4(False)
            Me.Button_Enable_5(False)

            'Filter Region ---
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_FR_Mannual.Checked Then
                Dim pb As New ClsParameterBoundary
                Dim str As String
                Dim lvi As ListViewItem
                Dim FilterRegion As String = ""

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    pb.LeftX = CInt(Me.TextBox_MinX.Text)
                    pb.TopY = CInt(Me.TextBox_MinY.Text)
                    pb.RightX = CInt(Me.TextBox_MaxX.Text)
                    pb.BottomY = CInt(Me.TextBox_MaxY.Text)

                    If Me.ComboBox_FR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_FR_Pattern.Text
                    End If
                    If Me.ComboBox_FR_Blacking.Text = "" Then    '2012/09/04 Rick add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_FR_Blacking.Text)
                    End If
                    pb.PType = NumericUpDown_PType.Value
                ElseIf Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                    pb.LeftX = CInt(Me.TextBox_MinX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.TopY = CInt(Me.TextBox_MinY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                    pb.RightX = CInt(Me.TextBox_MaxX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.BottomY = CInt(Me.TextBox_MaxY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

                    If Me.ComboBox_FR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_FR_Pattern.Text
                    End If
                    If Me.ComboBox_FR_Blacking.Text = "" Then    '2012/09/04 Rick add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_FR_Blacking.Text)
                    End If
                    pb.PType = NumericUpDown_PType.Value
                End If

                Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.Add(pb)

                lvi = Me.ListView_FilterRegion.Items.Add(Me.TextBox_MinX.Text)
                lvi.SubItems.Add(Me.TextBox_MinY.Text)
                lvi.SubItems.Add(Me.TextBox_MaxX.Text)
                lvi.SubItems.Add(Me.TextBox_MaxY.Text)
                If Me.ComboBox_FR_Pattern.Text = "" Then
                    lvi.SubItems.Add("ALL")
                Else
                    lvi.SubItems.Add(Me.ComboBox_FR_Pattern.Text)   '09/28 Rick add
                End If
                If Me.ComboBox_FR_Blacking.Text = "" Then
                    lvi.SubItems.Add("False")
                Else
                    lvi.SubItems.Add(Me.ComboBox_FR_Blacking.Text)   '2012/09/04 Rick add
                End If

                lvi.SubItems.Add(NumericUpDown_PType.Value)
                '---------------------------------------
                'Update Filter Region ---
                FilterRegion = FilterRegion & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ",Blacking," & pb.Blacking & ",PType," & pb.PType & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Filter Region   ==> Request_Command = "FUNC_FILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "FUNC_FILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, FilterRegion, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Me.Button_Enable_5(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]Add One Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.TextBox_MinX.Text = ""
                Me.TextBox_MinY.Text = ""
                Me.TextBox_MaxX.Text = ""
                Me.TextBox_MaxY.Text = ""
                Me.NumericUpDown_PType.Value = 999

                '2009/09/24 ��s���| ---
                Me.Label_FRCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion.Count   '04/16 Rick add

                If (Response_OK = False) Then
                    Me.Button_Enable_1(True)
                    Me.Button_Enable_2(True)
                    Me.Button_Enable_3(True)
                    Me.Button_Enable_4(True)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If

                '----------------------------------------------------------------------------------------------
                ' Save Func Filter Region File ==> Request_Command = "SAVE_FUNC_FILTERREGION" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_FUNC_FILTERREGION"

                    'Prepare Command ---
                    TimeOut = 100000 '100 secs

                    'Save Func Filter Region
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_FuncProcess.FuncFalseFilter.SaveFuncFilterRegion(str)
                    str = str.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Me.Button_Enable_5(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]Save Func Filter Region File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.DrawMark(Me.CheckBox_Show_FR_Single.Checked)
            End If

            'Un-Filter Region ---
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_UFR_Mannual.Checked Then
                Dim pb As New ClsParameterBoundary
                Dim str As String
                Dim lvi As ListViewItem
                Dim UFR As String = ""

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    pb.LeftX = CInt(Me.TextBox_UFR_MinX.Text)
                    pb.TopY = CInt(Me.TextBox_UFR_MinY.Text)
                    pb.RightX = CInt(Me.TextBox_UFR_MaxX.Text)
                    pb.BottomY = CInt(Me.TextBox_UFR_MaxY.Text)

                    If Me.ComboBox_UFR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_UFR_Pattern.Text
                    End If

                    If Me.ComboBox_UFR_Mask.Text = "" Then    '2015/07/21 Addis add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_UFR_Mask.Text)
                    End If

                ElseIf Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                    pb.LeftX = CInt(Me.TextBox_UFR_MinX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.TopY = CInt(Me.TextBox_UFR_MinY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                    pb.RightX = CInt(Me.TextBox_UFR_MaxX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.BottomY = CInt(Me.TextBox_UFR_MaxY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

                    If Me.ComboBox_UFR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_UFR_Pattern.Text
                    End If

                    If Me.ComboBox_UFR_Mask.Text = "" Then    '2015/07/21 Addis add
                        pb.Blacking = False
                    Else
                        pb.Blacking = CBool(Me.ComboBox_UFR_Mask.Text)
                    End If

                End If
                Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.Add(pb)

                lvi = Me.ListView_UnFilterRegion.Items.Add(Me.TextBox_UFR_MinX.Text)
                lvi.SubItems.Add(Me.TextBox_UFR_MinY.Text)
                lvi.SubItems.Add(Me.TextBox_UFR_MaxX.Text)
                lvi.SubItems.Add(Me.TextBox_UFR_MaxY.Text)
                If Me.ComboBox_UFR_Pattern.Text = "" Then
                    lvi.SubItems.Add("ALL")
                Else
                    lvi.SubItems.Add(Me.ComboBox_UFR_Pattern.Text)   '09/28 Rick add
                End If

                If Me.ComboBox_UFR_Mask.Text = "" Then    '2015/07/21 Addis add
                    lvi.SubItems.Add("False")
                Else
                    lvi.SubItems.Add(Me.ComboBox_UFR_Mask.Text)
                End If

                '---------------------------------------------------------------------------------------------------------------
                'Update Un-Filter Region ---
                UFR = UFR & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ",Mask," & pb.Blacking & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Un-Filter Region   ==> Request_Command = "FUNC_UNFILTERREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "FUNC_UNFILTERREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, UFR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Un-Filter Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Me.Button_Enable_5(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]Add One Un-Filter Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.TextBox_UFR_MinX.Text = ""
                Me.TextBox_UFR_MinY.Text = ""
                Me.TextBox_UFR_MaxX.Text = ""
                Me.TextBox_UFR_MaxY.Text = ""

                '2009/09/24 ��s���| ---
                Me.Label_UFRCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion.Count   '04/16 Rick add

                If (Response_OK = False) Then
                    Me.Button_Enable_1(True)
                    Me.Button_Enable_2(True)
                    Me.Button_Enable_3(True)
                    Me.Button_Enable_4(True)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If

                '----------------------------------------------------------------------------------------------
                ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_UNFILTERREGION" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_FUNC_UNFILTERREGION"

                    'Prepare Command ---
                    TimeOut = 100000 '100 secs

                    'Save Func Filter Region
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncUnFilterRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_FuncProcess.FuncFalseFilter.SaveFuncUnFilterRegion(str)
                    str = str.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Me.Button_Enable_5(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]Save Func Un-Filter Region File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.DrawMark2(Me.CheckBox_Show_UFR_Single.Checked)
            End If

            'Mask Mark Region ---
            If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_MMR_Mannual.Checked Then
                Dim pb As New ClsParameterBoundary
                Dim str As String
                Dim lvi As ListViewItem
                Dim MMR As String = ""

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                    pb.LeftX = CInt(Me.TextBox_MMR_MinX.Text)
                    pb.TopY = CInt(Me.TextBox_MMR_MinY.Text)
                    pb.RightX = CInt(Me.TextBox_MMR_MaxX.Text)
                    pb.BottomY = CInt(Me.TextBox_MMR_MaxY.Text)

                    If Me.ComboBox_MMR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_MMR_Pattern.Text
                    End If
                ElseIf Me.m_Form.ComboBox_Type.SelectedIndex = 1 Then
                    pb.LeftX = CInt(Me.TextBox_MMR_MinX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.TopY = CInt(Me.TextBox_MMR_MinY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                    pb.RightX = CInt(Me.TextBox_MMR_MaxX.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                    pb.BottomY = CInt(Me.TextBox_MMR_MaxY.Text) + Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

                    If Me.ComboBox_MMR_Pattern.Text = "" Then    '09/30 Rick add
                        pb.Pattern = "ALL"
                    Else
                        pb.Pattern = Me.ComboBox_MMR_Pattern.Text
                    End If
                End If
                Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.Add(pb)

                lvi = Me.ListView_MaskMarkRegion.Items.Add(Me.TextBox_MMR_MinX.Text)
                lvi.SubItems.Add(Me.TextBox_MMR_MinY.Text)
                lvi.SubItems.Add(Me.TextBox_MMR_MaxX.Text)
                lvi.SubItems.Add(Me.TextBox_MMR_MaxY.Text)
                If Me.ComboBox_MMR_Pattern.Text = "" Then
                    lvi.SubItems.Add("ALL")
                Else
                    lvi.SubItems.Add(Me.ComboBox_MMR_Pattern.Text)   '09/28 Rick add
                End If

                '---------------------------------------------------------------------------------------------------------------
                'Update Un-Filter Region ---
                MMR = MMR & "LeftX," & pb.LeftX & ",TopY," & pb.TopY & ",RightX," & pb.RightX & ",BottomY," & pb.BottomY & ",Pattern," & pb.Pattern & ";"

                '----------------------------------------------------------------------------------------------
                ' Add One Mask Mark Region   ==> Request_Command = "FUNC_MASKMARKREGION_ADDONE " (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "FUNC_MASKMARKREGION_ADDONE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, MMR, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Mask Mark Region Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Me.Button_Enable_5(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]Add One Mask Mark Region Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.TextBox_MMR_MinX.Text = ""
                Me.TextBox_MMR_MinY.Text = ""
                Me.TextBox_MMR_MaxX.Text = ""
                Me.TextBox_MMR_MaxY.Text = ""

                '2009/09/24 ��s���| ---
                Me.Label_MMRCount.Text = "�ƶq = " & Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion.Count   '04/16 Rick add

                If (Response_OK = False) Then
                    Me.Button_Enable_1(True)
                    Me.Button_Enable_2(True)
                    Me.Button_Enable_3(True)
                    Me.Button_Enable_4(True)
                    Me.Button_Enable_5(True)
                    Exit Sub
                End If

                '----------------------------------------------------------------------------------------------
                ' Save Func Un-Filter Region File ==> Request_Command = "SAVE_FUNC_MASKMARKREGION" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    Request_Command = "SAVE_FUNC_MASKMARKREGION"

                    'Prepare Command ---
                    TimeOut = 100000 '100 secs

                    'Save Func Filter Region
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncMaskMarkRegion_C" & Me.m_MainProcess.GrabNo & ".txt"
                    Me.m_FuncProcess.FuncFalseFilter.SaveFuncMaskMarkRegion(str)
                    str = str.Replace("\", "\\")

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Un-Filter Region File Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable_1(True)
                        Me.Button_Enable_2(True)
                        Me.Button_Enable_3(True)
                        Me.Button_Enable_4(True)
                        Me.Button_Enable_5(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]Save Func Mask Mark Region File Error ! (" & ex.Message & ")")
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.DrawMark3(Me.CheckBox_Show_MMR_Single.Checked)
            End If

            'Enable Button ---
            Me.Button_Enable_1(True)
            Me.Button_Enable_2(True)
            Me.Button_Enable_3(True)
            Me.Button_Enable_4(True)
            Me.Button_Enable_5(True)
        Catch ex As Exception
            Me.Button_Enable_1(True)
            Me.Button_Enable_2(True)
            Me.Button_Enable_3(True)
            Me.Button_Enable_4(True)
            Me.Button_Enable_5(True)
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.AxMDisplay_MouseUpEvent]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseDoubleClick ---"
    Private Sub m_AxMDisplay_MouseDoubleClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.DoubleClick
        Dim image As MIL_ID = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        Dim SizeX As Integer
        Dim SizeY As Integer

        If Me.CheckBox_EnableFalseLine.Checked Then
            If Me.ComboBox_FalseLineDirection.Text = "V" Then
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                Me.TextBox_MinX.Text = CStr(Me.m_Form.MouseX - Me.NumericUpDown_FalseLineWidth.Value / 2)
                Me.TextBox_MaxX.Text = CStr(Me.m_Form.MouseX + Me.NumericUpDown_FalseLineWidth.Value / 2)
                Me.TextBox_MinY.Text = CStr(0)
                Me.TextBox_MaxY.Text = CStr(SizeY - 1)
            Else
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                Me.TextBox_MinX.Text = CStr(0)
                Me.TextBox_MaxX.Text = CStr(SizeX)
                Me.TextBox_MinY.Text = CStr(Me.m_Form.MouseY - Me.NumericUpDown_FalseLineWidth.Value / 2)
                Me.TextBox_MaxY.Text = CStr(Me.m_Form.MouseY + Me.NumericUpDown_FalseLineWidth.Value / 2)
            End If
            Me.Button_FR_AddOne.PerformClick
        End If
    End Sub
#End Region

#End Region

#Region "--- Draw Event ---"

#Region "--- Draw False Defect ---"

#Region "--- DrawFalse ---"
    Private Sub DrawFalse(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red
        For i = 0 To Me.ListView_False.SelectedItems.Count - 1
            If Not Me.ListView_False.SelectedItems.Item(i) Is Nothing Then
                lvi = Me.ListView_False.SelectedItems.Item(i)
                x = lvi.SubItems(2).Text
                y = lvi.SubItems(3).Text
                x = (x - ox + 0.5) * s - hr
                y = (y - oy + 0.5) * s - hr
                If x < bx And y < by Then
                    Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
                End If
            End If
        Next
        'Me.m_Form.PaintStop = True
    End Sub
#End Region

#Region "--- DrawNew ---"
    Private Sub DrawNew(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Green
        For i = 0 To Me.ListView_New.SelectedItems.Count - 1
            If Not Me.ListView_New.SelectedItems.Item(i) Is Nothing Then
                lvi = Me.ListView_New.SelectedItems.Item(i)
                x = lvi.SubItems(2).Text
                y = lvi.SubItems(3).Text
                x = (x - ox + 0.5) * s - hr
                y = (y - oy + 0.5) * s - hr
                If x < bx And y < by Then
                    Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
                End If
            End If
        Next
        'Me.m_Form.PaintStop = True
    End Sub
#End Region

#End Region

#Region "--- Draw Filter Region ---"

#Region "--- DrawMark ---"
    Private Sub DrawMark(ByVal ShowSingle As Boolean)
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        'Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    Me.DrawFalse(0, 0)
                    Me.DrawNew(0, 0)
                End If
                Me.DrawFuncFilterRegion(0, 0, ShowSingle)    '11/17 Rick add
            Case 1
                If Me.ComboBox_FalseType.SelectedIndex < 12 Then
                    Me.DrawFalse(-offX, -offY)
                    Me.DrawNew(-offX, -offY)
                End If
                Me.DrawFuncFilterRegion(offX, offY, ShowSingle) '07/21  Rick modify
        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = True
    End Sub
#End Region

#Region "--- DrawFuncFilterRegion ---"
    Private Sub DrawFuncFilterRegion(ByVal offX As Integer, ByVal offY As Integer, ByVal ShowSingle As Boolean)
        Dim rect As Rectangle
        Dim s As Double
        Dim i As Integer
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary
        Dim ZoomX, ZoomY As Double
        Dim PatternName As String = ""

        Try
            If Me.CheckBox_ShowFilterRegion.Checked Or Me.CheckBox_Show_FR_Single.Checked Then   '2012/09/27 Rick modify
                '--- Initial ---
                rect = New Rectangle
                's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
                'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)
                '--- Initial ---

                pba = Me.m_FuncProcess.FuncFalseFilter.FuncFilterRegion
                PatternName = ComboBox_Show_FR_Single.Text  '2012/09/27 Rick add

                Me.m_Pen.Color = Color.Yellow
                Me.m_Pen.Width = s

                For i = 0 To pba.Count - 1
                    pb = pba.Item(i)
                    If (ShowSingle = True AndAlso (PatternName = pb.Pattern Or PatternName = "ALL")) Or ShowSingle = False Then  '2012/09/27 Rick add

                        For j As Integer = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1   '2012/09/06 Rick add
                            If pb.Pattern = Me.m_FuncProcess.FuncPatternRecipeArray.Item(j).PatternName.Value Then
                                Me.m_Pen.Color = Color.FromArgb(255, 255 / Me.m_FuncProcess.FuncPatternRecipeArray.Count * (j + 1), 255 / Me.m_FuncProcess.FuncPatternRecipeArray.Count * (Me.m_FuncProcess.FuncPatternRecipeArray.Count - j), 255)

                                Exit For
                            ElseIf pb.Pattern = "ALL" Then
                                Me.m_Pen.Color = Color.FromArgb(255, 255, 255, 255)
                                Exit For
                            End If
                        Next

                        Me.ListView_FilterRegion.Items.Item(i).BackColor = Me.m_Pen.Color
                        If Not (pb.LeftX = 0 And pb.TopY = 0 And pb.RightX = 0 And pb.BottomY = 0) Then
                            rect.X = (pb.LeftX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                            rect.Y = (pb.TopY - Me.m_Form.VScrollBar.Value - offY) * ZoomX
                            rect.Width = (pb.RightX - pb.LeftX) * ZoomX + 1
                            rect.Height = (pb.BottomY - pb.TopY) * ZoomX + 1
                            Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                        End If

                    End If
                Next

            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = True
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.DrawFuncFilterRegion]Draw Func Filter Region Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- Draw Un-Filter Region---"

#Region "--- DrawMark2 ---"
    Private Sub DrawMark2(ByVal ShowSingle As Boolean)   '07/22 Rick add
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        'Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                Me.DrawFuncUnFilterRegion(0, 0, ShowSingle)    '11/17 Rick add
            Case 1
                Me.DrawFuncUnFilterRegion(offX, offY, ShowSingle) '07/21  Rick modify
        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = True
    End Sub
#End Region

#Region "--- DrawFuncUnFilterRegion ---"
    Private Sub DrawFuncUnFilterRegion(ByVal offX As Integer, ByVal offY As Integer, ByVal ShowSingle As Boolean)   '07/21 Rick add
        Dim rect As Rectangle
        Dim s As Double
        Dim i As Integer
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary
        Dim ZoomX, ZoomY As Double
        Dim PatternName As String = ""

        Try
            If Me.CheckBox_ShowUnFilterRegion.Checked Or Me.CheckBox_Show_UFR_Single.Checked Then   '2012/09/27 Rick modify
                '--- Initial ---
                rect = New Rectangle
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
                'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)
                '--- Initial ---

                pba = Me.m_FuncProcess.FuncFalseFilter.FuncUnFilterRegion
                PatternName = ComboBox_Show_UFR_Single.Text  '2012/09/27 Rick add

                Me.m_Pen.Color = Color.GreenYellow
                Me.m_Pen.Width = s

                For i = 0 To pba.Count - 1
                    pb = pba.Item(i)
                    If (ShowSingle = True AndAlso (PatternName = pb.Pattern Or PatternName = "ALL")) Or ShowSingle = False Then  '2012/09/27 Rick add

                        For j As Integer = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1   '2012/09/06 Rick add
                            If pb.Pattern = Me.m_FuncProcess.FuncPatternRecipeArray.Item(j).PatternName.Value Then
                                Me.m_Pen.Color = Color.FromArgb(255, 255 / Me.m_FuncProcess.FuncPatternRecipeArray.Count * (j + 1), 255 / Me.m_FuncProcess.FuncPatternRecipeArray.Count * (Me.m_FuncProcess.FuncPatternRecipeArray.Count - j), 255)

                                Exit For
                            ElseIf pb.Pattern = "ALL" Then
                                Me.m_Pen.Color = Color.FromArgb(255, 255, 255, 255)
                                Exit For
                            End If
                        Next

                        Me.ListView_UnFilterRegion.Items.Item(i).BackColor = Me.m_Pen.Color
                        If Not (pb.LeftX = 0 And pb.TopY = 0 And pb.RightX = 0 And pb.BottomY = 0) Then
                            rect.X = (pb.LeftX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                            rect.Y = (pb.TopY - Me.m_Form.VScrollBar.Value - offY) * ZoomX
                            rect.Width = (pb.RightX - pb.LeftX) * ZoomX + 1
                            rect.Height = (pb.BottomY - pb.TopY) * ZoomX + 1
                            Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                        End If

                    End If
                Next

            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = True
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.DrawUnFuncFilterRegion]Draw Func Un-Filter Region Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- Draw Mask Mark Region---"

#Region "--- DrawMark3 ---"
    Private Sub DrawMark3(ByVal ShowSingle As Boolean)   '07/22 Rick add
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        'Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                Me.DrawFuncMaskMarkRegion(0, 0, ShowSingle)
            Case 1
                Me.DrawFuncMaskMarkRegion(offX, offY, ShowSingle)
        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = True
    End Sub
#End Region

#Region "--- DrawFuncMaskMarkRegion ---"
    Private Sub DrawFuncMaskMarkRegion(ByVal offX As Integer, ByVal offY As Integer, ByVal ShowSingle As Boolean)   '07/21 Rick add
        Dim rect As Rectangle
        Dim s As Double
        Dim i As Integer
        Dim pba As ClsParameterBoundaryArray
        Dim pb As ClsParameterBoundary
        Dim ZoomX, ZoomY As Double
        Dim PatternName As String = ""

        Try
            If Me.CheckBox_ShowMaskMarkRegion.Checked Or Me.CheckBox_Show_MMR_Single.Checked Then
                '--- Initial ---
                rect = New Rectangle
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
                'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)
                '--- Initial ---

                pba = Me.m_FuncProcess.FuncFalseFilter.FuncMaskMarkRegion
                PatternName = ComboBox_Show_MMR_Single.Text

                Me.m_Pen.Color = Color.GreenYellow
                Me.m_Pen.Width = s

                For i = 0 To pba.Count - 1
                    pb = pba.Item(i)
                    If (ShowSingle = True AndAlso (PatternName = pb.Pattern Or PatternName = "ALL")) Or ShowSingle = False Then  '2012/09/27 Rick add

                        For j As Integer = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1   '2012/09/06 Rick add
                            If pb.Pattern = Me.m_FuncProcess.FuncPatternRecipeArray.Item(j).PatternName.Value Then
                                Me.m_Pen.Color = Color.FromArgb(255, 255 / Me.m_FuncProcess.FuncPatternRecipeArray.Count * (j + 1), 255 / Me.m_FuncProcess.FuncPatternRecipeArray.Count * (Me.m_FuncProcess.FuncPatternRecipeArray.Count - j), 255)

                                Exit For
                            ElseIf pb.Pattern = "ALL" Then
                                Me.m_Pen.Color = Color.FromArgb(255, 255, 255, 255)
                                Exit For
                            End If
                        Next

                        Me.ListView_MaskMarkRegion.Items.Item(i).BackColor = Me.m_Pen.Color
                        If Not (pb.LeftX = 0 And pb.TopY = 0 And pb.RightX = 0 And pb.BottomY = 0) Then
                            rect.X = (pb.LeftX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                            rect.Y = (pb.TopY - Me.m_Form.VScrollBar.Value - offY) * ZoomX
                            rect.Width = (pb.RightX - pb.LeftX) * ZoomX + 1
                            rect.Height = (pb.BottomY - pb.TopY) * ZoomX + 1
                            Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                        End If

                    End If
                Next

            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = True
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncFalseDefect.DrawMaskMarkRegion]Draw Func Mask Mark Region Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#End Region

#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- NumericUpDown_Check_ValueChanged ---"
    Private Sub NumericUpDown_Check_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_Check.ValueChanged
        If NumericUpDown_CompareOK.Value > NumericUpDown_Check.Value Then NumericUpDown_CompareOK.Value = NumericUpDown_Check.Value
        NumericUpDown_CompareOK.Maximum = NumericUpDown_Check.Value
    End Sub
#End Region

#End Region

#Region "--- TabControl Event ---"

#Region "--- TabControl_FalseDefect_Click ---"
    Private Sub TabControl_FalseDefect_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl_FalseDefect.Click
        Try
            Me.CheckBox_ShowFilterRegion.Checked = False
            Me.CheckBox_FR_Mannual.Checked = False
            Me.CheckBox_ShowUnFilterRegion.Checked = False
            Me.CheckBox_UFR_Mannual.Checked = False
            Me.CheckBox_ShowMaskMarkRegion.Checked = False
            Me.CheckBox_MMR_Mannual.Checked = False
            If Me.m_AxMDisplay <> M_NULL Then Me.m_Panel_AxMDisplay.Refresh()
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncFalseDefect.TabControl_FalseDefect]" & ex.Message)
            MessageBox.Show("[Dialog_FuncFalseDefect.TabControl_FalseDefect]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region


End Class
