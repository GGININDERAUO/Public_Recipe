<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_FuncFalseDefect
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ColumnHeader_Flag As System.Windows.Forms.ColumnHeader
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_FuncFalseDefect))
        Dim ColumnHeader39 As System.Windows.Forms.ColumnHeader
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.Label_NewPosition = New System.Windows.Forms.Label()
        Me.Label_FalsePosition = New System.Windows.Forms.Label()
        Me.Label_FalseType = New System.Windows.Forms.Label()
        Me.ListView_False = New System.Windows.Forms.ListView()
        Me.ColumnHeader_CreatTime = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Type = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_X = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Y = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Area = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Count = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_CountMatch = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_History = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox_Manual = New System.Windows.Forms.GroupBox()
        Me.ComboBox_FalsePattern = New System.Windows.Forms.ComboBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.CheckBox_LineNotAddToFDTable = New System.Windows.Forms.CheckBox()
        Me.Button_DeleteOne = New System.Windows.Forms.Button()
        Me.ComboBox_FalseType = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button_AddOne = New System.Windows.Forms.Button()
        Me.Button_Clear = New System.Windows.Forms.Button()
        Me.Label_Y = New System.Windows.Forms.Label()
        Me.Label_X = New System.Windows.Forms.Label()
        Me.Label_Area = New System.Windows.Forms.Label()
        Me.NumericUpDown_Y = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_X = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Area = New System.Windows.Forms.NumericUpDown()
        Me.Button_FalseAdd = New System.Windows.Forms.Button()
        Me.Button_FalseRemove = New System.Windows.Forms.Button()
        Me.ListView_New = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader23 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox_Judge = New System.Windows.Forms.GroupBox()
        Me.TextBox_DeleteTableCount = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox_MaxFalseDefectTable = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Dist = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NumericUpDown_FalseArea = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NumericUpDown_CompareOK = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Check = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox_GenSample = New System.Windows.Forms.ComboBox()
        Me.Label_FalseTableCount = New System.Windows.Forms.Label()
        Me.Label_FalseTempCount = New System.Windows.Forms.Label()
        Me.TabControl_FalseDefect = New System.Windows.Forms.TabControl()
        Me.TabPage_FalseDefectTable = New System.Windows.Forms.TabPage()
        Me.CheckBox_AutoAddFuncFalseDefect = New System.Windows.Forms.CheckBox()
        Me.TabPage_FilterRegion = New System.Windows.Forms.TabPage()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.ComboBox_FalseLineDirection = New System.Windows.Forms.ComboBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.NumericUpDown_FalseLineWidth = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_EnableFalseLine = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Display_FR = New System.Windows.Forms.GroupBox()
        Me.ComboBox_Show_FR_Single = New System.Windows.Forms.ComboBox()
        Me.CheckBox_Show_FR_Single = New System.Windows.Forms.CheckBox()
        Me.ComboBox_FR_Blacking = New System.Windows.Forms.ComboBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.ComboBox_FR_Pattern = New System.Windows.Forms.ComboBox()
        Me.GroupBox_MannualAddFR = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_PType = New System.Windows.Forms.NumericUpDown()
        Me.Button_FR_AddOne = New System.Windows.Forms.Button()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TextBox_MaxY = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox_MaxX = New System.Windows.Forms.TextBox()
        Me.lbData = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox_MinX = New System.Windows.Forms.TextBox()
        Me.TextBox_MinY = New System.Windows.Forms.TextBox()
        Me.lbGate = New System.Windows.Forms.Label()
        Me.Button_FR_Close = New System.Windows.Forms.Button()
        Me.Button_FR_Save = New System.Windows.Forms.Button()
        Me.GroupBox_AutoAddFR = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowFilterRegion = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FR_Mannual = New System.Windows.Forms.CheckBox()
        Me.GroupBox_FilterRegion = New System.Windows.Forms.GroupBox()
        Me.Button_FR_ClearAll = New System.Windows.Forms.Button()
        Me.Button_FR_DeleteOne = New System.Windows.Forms.Button()
        Me.Label_FRCount = New System.Windows.Forms.Label()
        Me.ListView_FilterRegion = New System.Windows.Forms.ListView()
        Me.Ch_LeftX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_TopY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_RightX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_BottomY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_Blacking = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_PType = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_UnFilterRegion = New System.Windows.Forms.TabPage()
        Me.ComboBox_UFR_Mask = New System.Windows.Forms.ComboBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.GroupBox_Display_UFR = New System.Windows.Forms.GroupBox()
        Me.ComboBox_Show_UFR_Single = New System.Windows.Forms.ComboBox()
        Me.CheckBox_Show_UFR_Single = New System.Windows.Forms.CheckBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.ComboBox_UFR_Pattern = New System.Windows.Forms.ComboBox()
        Me.GroupBox_MannualAddUFR = New System.Windows.Forms.GroupBox()
        Me.Button_UFR_AddOne = New System.Windows.Forms.Button()
        Me.TextBox_UFR_MaxY = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox_UFR_MaxX = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox_UFR_MinX = New System.Windows.Forms.TextBox()
        Me.TextBox_UFR_MinY = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Button_UFR_Close = New System.Windows.Forms.Button()
        Me.Button_UFR_Save = New System.Windows.Forms.Button()
        Me.GroupBox_AutoAddUFR = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowUnFilterRegion = New System.Windows.Forms.CheckBox()
        Me.CheckBox_UFR_Mannual = New System.Windows.Forms.CheckBox()
        Me.GroupBox_UnFilterRegion = New System.Windows.Forms.GroupBox()
        Me.Button_UFR_CLearAll = New System.Windows.Forms.Button()
        Me.Button_UFR_DeleteOne = New System.Windows.Forms.Button()
        Me.Label_UFRCount = New System.Windows.Forms.Label()
        Me.ListView_UnFilterRegion = New System.Windows.Forms.ListView()
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader13 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader14 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader24 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_ParticleTable = New System.Windows.Forms.TabPage()
        Me.Button_BackParticle_Close = New System.Windows.Forms.Button()
        Me.Button_BackParticle_Save = New System.Windows.Forms.Button()
        Me.Button_BackParticle_CLearAll = New System.Windows.Forms.Button()
        Me.Button_BackParticle_DeleteOne = New System.Windows.Forms.Button()
        Me.Label_BackParticleCount = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.ListView_ParticleTable = New System.Windows.Forms.ListView()
        Me.ColumnHeader16 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader17 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader18 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_MaskMarkRegion = New System.Windows.Forms.TabPage()
        Me.NumericUpDown_MMR_ByPass_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.NumericUpDown_MMR_DilateCount = New System.Windows.Forms.NumericUpDown()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Button_Calculate_MaskImage = New System.Windows.Forms.Button()
        Me.GroupBox_Display_MMR = New System.Windows.Forms.GroupBox()
        Me.ComboBox_Show_MMR_Single = New System.Windows.Forms.ComboBox()
        Me.CheckBox_Show_MMR_Single = New System.Windows.Forms.CheckBox()
        Me.GroupBox_MannualAddMMR = New System.Windows.Forms.GroupBox()
        Me.Button_MMR_AddOne = New System.Windows.Forms.Button()
        Me.TextBox_MMR_MaxY = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox_MMR_MaxX = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TextBox_MMR_MinX = New System.Windows.Forms.TextBox()
        Me.TextBox_MMR_MinY = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Button_MMR_Close = New System.Windows.Forms.Button()
        Me.Button_MMR_Save = New System.Windows.Forms.Button()
        Me.GroupBox_AutoAddMMR = New System.Windows.Forms.GroupBox()
        Me.CheckBox_ShowMaskMarkRegion = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MMR_Mannual = New System.Windows.Forms.CheckBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.ComboBox_MMR_Pattern = New System.Windows.Forms.ComboBox()
        Me.GroupBox_MaskMarkRegion = New System.Windows.Forms.GroupBox()
        Me.Button_MMR_CLearAll = New System.Windows.Forms.Button()
        Me.Button_MMR_DeleteOne = New System.Windows.Forms.Button()
        Me.Label_MMRCount = New System.Windows.Forms.Label()
        Me.ListView_MaskMarkRegion = New System.Windows.Forms.ListView()
        Me.ColumnHeader15 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader19 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader20 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader21 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader22 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader32 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader33 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader34 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader35 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader36 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader37 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader38 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader40 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.NumericUpDown4 = New System.Windows.Forms.NumericUpDown()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.ColumnHeader41 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader42 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader43 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader44 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader45 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader46 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader47 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader48 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader49 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        ColumnHeader_Flag = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        ColumnHeader39 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox_Manual.SuspendLayout()
        CType(Me.NumericUpDown_Y, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_X, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Area, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Judge.SuspendLayout()
        CType(Me.NumericUpDown_Dist, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_FalseArea, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_CompareOK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Check, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl_FalseDefect.SuspendLayout()
        Me.TabPage_FalseDefectTable.SuspendLayout()
        Me.TabPage_FilterRegion.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NumericUpDown_FalseLineWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Display_FR.SuspendLayout()
        Me.GroupBox_MannualAddFR.SuspendLayout()
        CType(Me.NumericUpDown_PType, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_AutoAddFR.SuspendLayout()
        Me.GroupBox_FilterRegion.SuspendLayout()
        Me.TabPage_UnFilterRegion.SuspendLayout()
        Me.GroupBox_Display_UFR.SuspendLayout()
        Me.GroupBox_MannualAddUFR.SuspendLayout()
        Me.GroupBox_AutoAddUFR.SuspendLayout()
        Me.GroupBox_UnFilterRegion.SuspendLayout()
        Me.TabPage_ParticleTable.SuspendLayout()
        Me.TabPage_MaskMarkRegion.SuspendLayout()
        CType(Me.NumericUpDown_MMR_ByPass_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MMR_DilateCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Display_MMR.SuspendLayout()
        Me.GroupBox_MannualAddMMR.SuspendLayout()
        Me.GroupBox_AutoAddMMR.SuspendLayout()
        Me.GroupBox_MaskMarkRegion.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ColumnHeader_Flag
        '
        resources.ApplyResources(ColumnHeader_Flag, "ColumnHeader_Flag")
        '
        'ColumnHeader39
        '
        resources.ApplyResources(ColumnHeader39, "ColumnHeader39")
        '
        'TableLayoutPanel1
        '
        resources.ApplyResources(Me.TableLayoutPanel1, "TableLayoutPanel1")
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Save, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Close, 1, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        '
        'Button_Close
        '
        resources.ApplyResources(Me.Button_Close, "Button_Close")
        Me.Button_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_Close.Name = "Button_Close"
        '
        'Label_NewPosition
        '
        resources.ApplyResources(Me.Label_NewPosition, "Label_NewPosition")
        Me.Label_NewPosition.Name = "Label_NewPosition"
        '
        'Label_FalsePosition
        '
        resources.ApplyResources(Me.Label_FalsePosition, "Label_FalsePosition")
        Me.Label_FalsePosition.Name = "Label_FalsePosition"
        '
        'Label_FalseType
        '
        resources.ApplyResources(Me.Label_FalseType, "Label_FalseType")
        Me.Label_FalseType.Name = "Label_FalseType"
        '
        'ListView_False
        '
        resources.ApplyResources(Me.ListView_False, "ListView_False")
        Me.ListView_False.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_CreatTime, Me.ColumnHeader_Type, Me.ColumnHeader_X, Me.ColumnHeader_Y, Me.ColumnHeader_Area, Me.ColumnHeader_Count, Me.ColumnHeader_CountMatch, ColumnHeader_Flag, Me.ColumnHeader_History, Me.ColumnHeader_Pattern})
        Me.ListView_False.FullRowSelect = True
        Me.ListView_False.GridLines = True
        Me.ListView_False.HideSelection = False
        Me.ListView_False.Name = "ListView_False"
        Me.ListView_False.UseCompatibleStateImageBehavior = False
        Me.ListView_False.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_CreatTime
        '
        resources.ApplyResources(Me.ColumnHeader_CreatTime, "ColumnHeader_CreatTime")
        '
        'ColumnHeader_Type
        '
        resources.ApplyResources(Me.ColumnHeader_Type, "ColumnHeader_Type")
        '
        'ColumnHeader_X
        '
        resources.ApplyResources(Me.ColumnHeader_X, "ColumnHeader_X")
        '
        'ColumnHeader_Y
        '
        resources.ApplyResources(Me.ColumnHeader_Y, "ColumnHeader_Y")
        '
        'ColumnHeader_Area
        '
        resources.ApplyResources(Me.ColumnHeader_Area, "ColumnHeader_Area")
        '
        'ColumnHeader_Count
        '
        resources.ApplyResources(Me.ColumnHeader_Count, "ColumnHeader_Count")
        '
        'ColumnHeader_CountMatch
        '
        resources.ApplyResources(Me.ColumnHeader_CountMatch, "ColumnHeader_CountMatch")
        '
        'ColumnHeader_History
        '
        resources.ApplyResources(Me.ColumnHeader_History, "ColumnHeader_History")
        '
        'ColumnHeader_Pattern
        '
        resources.ApplyResources(Me.ColumnHeader_Pattern, "ColumnHeader_Pattern")
        '
        'GroupBox_Manual
        '
        resources.ApplyResources(Me.GroupBox_Manual, "GroupBox_Manual")
        Me.GroupBox_Manual.Controls.Add(Me.ComboBox_FalsePattern)
        Me.GroupBox_Manual.Controls.Add(Me.Label14)
        Me.GroupBox_Manual.Controls.Add(Me.CheckBox_LineNotAddToFDTable)
        Me.GroupBox_Manual.Controls.Add(Me.Button_DeleteOne)
        Me.GroupBox_Manual.Controls.Add(Me.ComboBox_FalseType)
        Me.GroupBox_Manual.Controls.Add(Me.Label5)
        Me.GroupBox_Manual.Controls.Add(Me.Button_AddOne)
        Me.GroupBox_Manual.Controls.Add(Me.Button_Clear)
        Me.GroupBox_Manual.Controls.Add(Me.Label_Y)
        Me.GroupBox_Manual.Controls.Add(Me.Label_X)
        Me.GroupBox_Manual.Controls.Add(Me.Label_Area)
        Me.GroupBox_Manual.Controls.Add(Me.NumericUpDown_Y)
        Me.GroupBox_Manual.Controls.Add(Me.NumericUpDown_X)
        Me.GroupBox_Manual.Controls.Add(Me.NumericUpDown_Area)
        Me.GroupBox_Manual.Name = "GroupBox_Manual"
        Me.GroupBox_Manual.TabStop = False
        '
        'ComboBox_FalsePattern
        '
        resources.ApplyResources(Me.ComboBox_FalsePattern, "ComboBox_FalsePattern")
        Me.ComboBox_FalsePattern.FormattingEnabled = True
        Me.ComboBox_FalsePattern.Name = "ComboBox_FalsePattern"
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'CheckBox_LineNotAddToFDTable
        '
        resources.ApplyResources(Me.CheckBox_LineNotAddToFDTable, "CheckBox_LineNotAddToFDTable")
        Me.CheckBox_LineNotAddToFDTable.Name = "CheckBox_LineNotAddToFDTable"
        Me.CheckBox_LineNotAddToFDTable.UseVisualStyleBackColor = True
        '
        'Button_DeleteOne
        '
        resources.ApplyResources(Me.Button_DeleteOne, "Button_DeleteOne")
        Me.Button_DeleteOne.Name = "Button_DeleteOne"
        Me.Button_DeleteOne.UseVisualStyleBackColor = True
        '
        'ComboBox_FalseType
        '
        resources.ApplyResources(Me.ComboBox_FalseType, "ComboBox_FalseType")
        Me.ComboBox_FalseType.FormattingEnabled = True
        Me.ComboBox_FalseType.Name = "ComboBox_FalseType"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Button_AddOne
        '
        resources.ApplyResources(Me.Button_AddOne, "Button_AddOne")
        Me.Button_AddOne.Name = "Button_AddOne"
        Me.Button_AddOne.UseVisualStyleBackColor = True
        '
        'Button_Clear
        '
        resources.ApplyResources(Me.Button_Clear, "Button_Clear")
        Me.Button_Clear.Name = "Button_Clear"
        '
        'Label_Y
        '
        resources.ApplyResources(Me.Label_Y, "Label_Y")
        Me.Label_Y.Name = "Label_Y"
        '
        'Label_X
        '
        resources.ApplyResources(Me.Label_X, "Label_X")
        Me.Label_X.Name = "Label_X"
        '
        'Label_Area
        '
        resources.ApplyResources(Me.Label_Area, "Label_Area")
        Me.Label_Area.Name = "Label_Area"
        '
        'NumericUpDown_Y
        '
        resources.ApplyResources(Me.NumericUpDown_Y, "NumericUpDown_Y")
        Me.NumericUpDown_Y.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_Y.Minimum = New Decimal(New Integer() {1000000, 0, 0, -2147483648})
        Me.NumericUpDown_Y.Name = "NumericUpDown_Y"
        Me.NumericUpDown_Y.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_X
        '
        resources.ApplyResources(Me.NumericUpDown_X, "NumericUpDown_X")
        Me.NumericUpDown_X.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_X.Minimum = New Decimal(New Integer() {100000, 0, 0, -2147483648})
        Me.NumericUpDown_X.Name = "NumericUpDown_X"
        Me.NumericUpDown_X.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_Area
        '
        resources.ApplyResources(Me.NumericUpDown_Area, "NumericUpDown_Area")
        Me.NumericUpDown_Area.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_Area.Minimum = New Decimal(New Integer() {100000, 0, 0, -2147483648})
        Me.NumericUpDown_Area.Name = "NumericUpDown_Area"
        Me.NumericUpDown_Area.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Button_FalseAdd
        '
        resources.ApplyResources(Me.Button_FalseAdd, "Button_FalseAdd")
        Me.Button_FalseAdd.Name = "Button_FalseAdd"
        '
        'Button_FalseRemove
        '
        resources.ApplyResources(Me.Button_FalseRemove, "Button_FalseRemove")
        Me.Button_FalseRemove.Name = "Button_FalseRemove"
        '
        'ListView_New
        '
        resources.ApplyResources(Me.ListView_New, "ListView_New")
        Me.ListView_New.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader9, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7, Me.ColumnHeader8, Me.ColumnHeader23})
        Me.ListView_New.FullRowSelect = True
        Me.ListView_New.GridLines = True
        Me.ListView_New.HideSelection = False
        Me.ListView_New.Name = "ListView_New"
        Me.ListView_New.UseCompatibleStateImageBehavior = False
        Me.ListView_New.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        resources.ApplyResources(Me.ColumnHeader1, "ColumnHeader1")
        '
        'ColumnHeader9
        '
        resources.ApplyResources(Me.ColumnHeader9, "ColumnHeader9")
        '
        'ColumnHeader2
        '
        resources.ApplyResources(Me.ColumnHeader2, "ColumnHeader2")
        '
        'ColumnHeader3
        '
        resources.ApplyResources(Me.ColumnHeader3, "ColumnHeader3")
        '
        'ColumnHeader4
        '
        resources.ApplyResources(Me.ColumnHeader4, "ColumnHeader4")
        '
        'ColumnHeader5
        '
        resources.ApplyResources(Me.ColumnHeader5, "ColumnHeader5")
        '
        'ColumnHeader6
        '
        resources.ApplyResources(Me.ColumnHeader6, "ColumnHeader6")
        '
        'ColumnHeader7
        '
        resources.ApplyResources(Me.ColumnHeader7, "ColumnHeader7")
        '
        'ColumnHeader8
        '
        resources.ApplyResources(Me.ColumnHeader8, "ColumnHeader8")
        '
        'ColumnHeader23
        '
        resources.ApplyResources(Me.ColumnHeader23, "ColumnHeader23")
        '
        'GroupBox_Judge
        '
        resources.ApplyResources(Me.GroupBox_Judge, "GroupBox_Judge")
        Me.GroupBox_Judge.Controls.Add(Me.TextBox_DeleteTableCount)
        Me.GroupBox_Judge.Controls.Add(Me.Label7)
        Me.GroupBox_Judge.Controls.Add(Me.TextBox_MaxFalseDefectTable)
        Me.GroupBox_Judge.Controls.Add(Me.Label6)
        Me.GroupBox_Judge.Controls.Add(Me.NumericUpDown_Dist)
        Me.GroupBox_Judge.Controls.Add(Me.Label4)
        Me.GroupBox_Judge.Controls.Add(Me.NumericUpDown_FalseArea)
        Me.GroupBox_Judge.Controls.Add(Me.Label3)
        Me.GroupBox_Judge.Controls.Add(Me.NumericUpDown_CompareOK)
        Me.GroupBox_Judge.Controls.Add(Me.Label2)
        Me.GroupBox_Judge.Controls.Add(Me.NumericUpDown_Check)
        Me.GroupBox_Judge.Controls.Add(Me.Label1)
        Me.GroupBox_Judge.Name = "GroupBox_Judge"
        Me.GroupBox_Judge.TabStop = False
        '
        'TextBox_DeleteTableCount
        '
        resources.ApplyResources(Me.TextBox_DeleteTableCount, "TextBox_DeleteTableCount")
        Me.TextBox_DeleteTableCount.Name = "TextBox_DeleteTableCount"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'TextBox_MaxFalseDefectTable
        '
        resources.ApplyResources(Me.TextBox_MaxFalseDefectTable, "TextBox_MaxFalseDefectTable")
        Me.TextBox_MaxFalseDefectTable.Name = "TextBox_MaxFalseDefectTable"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'NumericUpDown_Dist
        '
        resources.ApplyResources(Me.NumericUpDown_Dist, "NumericUpDown_Dist")
        Me.NumericUpDown_Dist.Name = "NumericUpDown_Dist"
        Me.NumericUpDown_Dist.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'NumericUpDown_FalseArea
        '
        resources.ApplyResources(Me.NumericUpDown_FalseArea, "NumericUpDown_FalseArea")
        Me.NumericUpDown_FalseArea.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_FalseArea.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.NumericUpDown_FalseArea.Name = "NumericUpDown_FalseArea"
        Me.NumericUpDown_FalseArea.Value = New Decimal(New Integer() {1, 0, 0, -2147483648})
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'NumericUpDown_CompareOK
        '
        resources.ApplyResources(Me.NumericUpDown_CompareOK, "NumericUpDown_CompareOK")
        Me.NumericUpDown_CompareOK.Maximum = New Decimal(New Integer() {99, 0, 0, 0})
        Me.NumericUpDown_CompareOK.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_CompareOK.Name = "NumericUpDown_CompareOK"
        Me.NumericUpDown_CompareOK.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'NumericUpDown_Check
        '
        resources.ApplyResources(Me.NumericUpDown_Check, "NumericUpDown_Check")
        Me.NumericUpDown_Check.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Check.Name = "NumericUpDown_Check"
        Me.NumericUpDown_Check.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'ComboBox_GenSample
        '
        resources.ApplyResources(Me.ComboBox_GenSample, "ComboBox_GenSample")
        Me.ComboBox_GenSample.FormattingEnabled = True
        Me.ComboBox_GenSample.Items.AddRange(New Object() {resources.GetString("ComboBox_GenSample.Items"), resources.GetString("ComboBox_GenSample.Items1")})
        Me.ComboBox_GenSample.Name = "ComboBox_GenSample"
        '
        'Label_FalseTableCount
        '
        resources.ApplyResources(Me.Label_FalseTableCount, "Label_FalseTableCount")
        Me.Label_FalseTableCount.Name = "Label_FalseTableCount"
        '
        'Label_FalseTempCount
        '
        resources.ApplyResources(Me.Label_FalseTempCount, "Label_FalseTempCount")
        Me.Label_FalseTempCount.Name = "Label_FalseTempCount"
        '
        'TabControl_FalseDefect
        '
        resources.ApplyResources(Me.TabControl_FalseDefect, "TabControl_FalseDefect")
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_FalseDefectTable)
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_FilterRegion)
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_UnFilterRegion)
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_ParticleTable)
        Me.TabControl_FalseDefect.Controls.Add(Me.TabPage_MaskMarkRegion)
        Me.TabControl_FalseDefect.Name = "TabControl_FalseDefect"
        Me.TabControl_FalseDefect.SelectedIndex = 0
        '
        'TabPage_FalseDefectTable
        '
        resources.ApplyResources(Me.TabPage_FalseDefectTable, "TabPage_FalseDefectTable")
        Me.TabPage_FalseDefectTable.Controls.Add(Me.CheckBox_AutoAddFuncFalseDefect)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.ListView_False)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Label_FalseTempCount)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.TableLayoutPanel1)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Button_FalseRemove)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Label_FalseTableCount)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Button_FalseAdd)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.ComboBox_GenSample)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.GroupBox_Manual)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Label_FalseType)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Label_FalsePosition)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.Label_NewPosition)
        Me.TabPage_FalseDefectTable.Controls.Add(Me.ListView_New)
        Me.TabPage_FalseDefectTable.Name = "TabPage_FalseDefectTable"
        Me.TabPage_FalseDefectTable.UseVisualStyleBackColor = True
        '
        'CheckBox_AutoAddFuncFalseDefect
        '
        resources.ApplyResources(Me.CheckBox_AutoAddFuncFalseDefect, "CheckBox_AutoAddFuncFalseDefect")
        Me.CheckBox_AutoAddFuncFalseDefect.Name = "CheckBox_AutoAddFuncFalseDefect"
        '
        'TabPage_FilterRegion
        '
        resources.ApplyResources(Me.TabPage_FilterRegion, "TabPage_FilterRegion")
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox1)
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox_Display_FR)
        Me.TabPage_FilterRegion.Controls.Add(Me.ComboBox_FR_Blacking)
        Me.TabPage_FilterRegion.Controls.Add(Me.Label15)
        Me.TabPage_FilterRegion.Controls.Add(Me.Label_Pattern)
        Me.TabPage_FilterRegion.Controls.Add(Me.ComboBox_FR_Pattern)
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox_MannualAddFR)
        Me.TabPage_FilterRegion.Controls.Add(Me.Button_FR_Close)
        Me.TabPage_FilterRegion.Controls.Add(Me.Button_FR_Save)
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox_AutoAddFR)
        Me.TabPage_FilterRegion.Controls.Add(Me.GroupBox_FilterRegion)
        Me.TabPage_FilterRegion.Name = "TabPage_FilterRegion"
        Me.TabPage_FilterRegion.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.ComboBox_FalseLineDirection)
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_FalseLineWidth)
        Me.GroupBox1.Controls.Add(Me.CheckBox_EnableFalseLine)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'ComboBox_FalseLineDirection
        '
        resources.ApplyResources(Me.ComboBox_FalseLineDirection, "ComboBox_FalseLineDirection")
        Me.ComboBox_FalseLineDirection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FalseLineDirection.FormattingEnabled = True
        Me.ComboBox_FalseLineDirection.Items.AddRange(New Object() {resources.GetString("ComboBox_FalseLineDirection.Items"), resources.GetString("ComboBox_FalseLineDirection.Items1")})
        Me.ComboBox_FalseLineDirection.Name = "ComboBox_FalseLineDirection"
        '
        'Label36
        '
        resources.ApplyResources(Me.Label36, "Label36")
        Me.Label36.Name = "Label36"
        '
        'NumericUpDown_FalseLineWidth
        '
        resources.ApplyResources(Me.NumericUpDown_FalseLineWidth, "NumericUpDown_FalseLineWidth")
        Me.NumericUpDown_FalseLineWidth.Increment = New Decimal(New Integer() {2, 0, 0, 0})
        Me.NumericUpDown_FalseLineWidth.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_FalseLineWidth.Minimum = New Decimal(New Integer() {2, 0, 0, 0})
        Me.NumericUpDown_FalseLineWidth.Name = "NumericUpDown_FalseLineWidth"
        Me.NumericUpDown_FalseLineWidth.Value = New Decimal(New Integer() {6, 0, 0, 0})
        '
        'CheckBox_EnableFalseLine
        '
        resources.ApplyResources(Me.CheckBox_EnableFalseLine, "CheckBox_EnableFalseLine")
        Me.CheckBox_EnableFalseLine.Name = "CheckBox_EnableFalseLine"
        Me.CheckBox_EnableFalseLine.UseVisualStyleBackColor = True
        '
        'GroupBox_Display_FR
        '
        resources.ApplyResources(Me.GroupBox_Display_FR, "GroupBox_Display_FR")
        Me.GroupBox_Display_FR.Controls.Add(Me.ComboBox_Show_FR_Single)
        Me.GroupBox_Display_FR.Controls.Add(Me.CheckBox_Show_FR_Single)
        Me.GroupBox_Display_FR.Name = "GroupBox_Display_FR"
        Me.GroupBox_Display_FR.TabStop = False
        '
        'ComboBox_Show_FR_Single
        '
        resources.ApplyResources(Me.ComboBox_Show_FR_Single, "ComboBox_Show_FR_Single")
        Me.ComboBox_Show_FR_Single.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Show_FR_Single.Name = "ComboBox_Show_FR_Single"
        '
        'CheckBox_Show_FR_Single
        '
        resources.ApplyResources(Me.CheckBox_Show_FR_Single, "CheckBox_Show_FR_Single")
        Me.CheckBox_Show_FR_Single.Name = "CheckBox_Show_FR_Single"
        Me.CheckBox_Show_FR_Single.UseVisualStyleBackColor = True
        '
        'ComboBox_FR_Blacking
        '
        resources.ApplyResources(Me.ComboBox_FR_Blacking, "ComboBox_FR_Blacking")
        Me.ComboBox_FR_Blacking.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FR_Blacking.FormattingEnabled = True
        Me.ComboBox_FR_Blacking.Name = "ComboBox_FR_Blacking"
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'Label_Pattern
        '
        resources.ApplyResources(Me.Label_Pattern, "Label_Pattern")
        Me.Label_Pattern.Name = "Label_Pattern"
        '
        'ComboBox_FR_Pattern
        '
        resources.ApplyResources(Me.ComboBox_FR_Pattern, "ComboBox_FR_Pattern")
        Me.ComboBox_FR_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_FR_Pattern.Name = "ComboBox_FR_Pattern"
        '
        'GroupBox_MannualAddFR
        '
        resources.ApplyResources(Me.GroupBox_MannualAddFR, "GroupBox_MannualAddFR")
        Me.GroupBox_MannualAddFR.Controls.Add(Me.NumericUpDown_PType)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Button_FR_AddOne)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Label35)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MaxY)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Label8)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MaxX)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.lbData)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.Label9)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MinX)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.TextBox_MinY)
        Me.GroupBox_MannualAddFR.Controls.Add(Me.lbGate)
        Me.GroupBox_MannualAddFR.Name = "GroupBox_MannualAddFR"
        Me.GroupBox_MannualAddFR.TabStop = False
        '
        'NumericUpDown_PType
        '
        resources.ApplyResources(Me.NumericUpDown_PType, "NumericUpDown_PType")
        Me.NumericUpDown_PType.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_PType.Name = "NumericUpDown_PType"
        Me.NumericUpDown_PType.Value = New Decimal(New Integer() {999, 0, 0, 0})
        '
        'Button_FR_AddOne
        '
        resources.ApplyResources(Me.Button_FR_AddOne, "Button_FR_AddOne")
        Me.Button_FR_AddOne.Name = "Button_FR_AddOne"
        Me.Button_FR_AddOne.UseVisualStyleBackColor = True
        '
        'Label35
        '
        resources.ApplyResources(Me.Label35, "Label35")
        Me.Label35.Name = "Label35"
        '
        'TextBox_MaxY
        '
        resources.ApplyResources(Me.TextBox_MaxY, "TextBox_MaxY")
        Me.TextBox_MaxY.Name = "TextBox_MaxY"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'TextBox_MaxX
        '
        resources.ApplyResources(Me.TextBox_MaxX, "TextBox_MaxX")
        Me.TextBox_MaxX.Name = "TextBox_MaxX"
        '
        'lbData
        '
        resources.ApplyResources(Me.lbData, "lbData")
        Me.lbData.Name = "lbData"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'TextBox_MinX
        '
        resources.ApplyResources(Me.TextBox_MinX, "TextBox_MinX")
        Me.TextBox_MinX.Name = "TextBox_MinX"
        '
        'TextBox_MinY
        '
        resources.ApplyResources(Me.TextBox_MinY, "TextBox_MinY")
        Me.TextBox_MinY.Name = "TextBox_MinY"
        '
        'lbGate
        '
        resources.ApplyResources(Me.lbGate, "lbGate")
        Me.lbGate.Name = "lbGate"
        '
        'Button_FR_Close
        '
        resources.ApplyResources(Me.Button_FR_Close, "Button_FR_Close")
        Me.Button_FR_Close.Name = "Button_FR_Close"
        '
        'Button_FR_Save
        '
        resources.ApplyResources(Me.Button_FR_Save, "Button_FR_Save")
        Me.Button_FR_Save.Name = "Button_FR_Save"
        Me.Button_FR_Save.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoAddFR
        '
        resources.ApplyResources(Me.GroupBox_AutoAddFR, "GroupBox_AutoAddFR")
        Me.GroupBox_AutoAddFR.Controls.Add(Me.CheckBox_ShowFilterRegion)
        Me.GroupBox_AutoAddFR.Controls.Add(Me.CheckBox_FR_Mannual)
        Me.GroupBox_AutoAddFR.Name = "GroupBox_AutoAddFR"
        Me.GroupBox_AutoAddFR.TabStop = False
        '
        'CheckBox_ShowFilterRegion
        '
        resources.ApplyResources(Me.CheckBox_ShowFilterRegion, "CheckBox_ShowFilterRegion")
        Me.CheckBox_ShowFilterRegion.Name = "CheckBox_ShowFilterRegion"
        Me.CheckBox_ShowFilterRegion.UseVisualStyleBackColor = True
        '
        'CheckBox_FR_Mannual
        '
        resources.ApplyResources(Me.CheckBox_FR_Mannual, "CheckBox_FR_Mannual")
        Me.CheckBox_FR_Mannual.Name = "CheckBox_FR_Mannual"
        Me.CheckBox_FR_Mannual.UseVisualStyleBackColor = True
        '
        'GroupBox_FilterRegion
        '
        resources.ApplyResources(Me.GroupBox_FilterRegion, "GroupBox_FilterRegion")
        Me.GroupBox_FilterRegion.Controls.Add(Me.Button_FR_ClearAll)
        Me.GroupBox_FilterRegion.Controls.Add(Me.Button_FR_DeleteOne)
        Me.GroupBox_FilterRegion.Controls.Add(Me.Label_FRCount)
        Me.GroupBox_FilterRegion.Controls.Add(Me.ListView_FilterRegion)
        Me.GroupBox_FilterRegion.Name = "GroupBox_FilterRegion"
        Me.GroupBox_FilterRegion.TabStop = False
        '
        'Button_FR_ClearAll
        '
        resources.ApplyResources(Me.Button_FR_ClearAll, "Button_FR_ClearAll")
        Me.Button_FR_ClearAll.Name = "Button_FR_ClearAll"
        Me.Button_FR_ClearAll.UseVisualStyleBackColor = True
        '
        'Button_FR_DeleteOne
        '
        resources.ApplyResources(Me.Button_FR_DeleteOne, "Button_FR_DeleteOne")
        Me.Button_FR_DeleteOne.Name = "Button_FR_DeleteOne"
        Me.Button_FR_DeleteOne.UseVisualStyleBackColor = True
        '
        'Label_FRCount
        '
        resources.ApplyResources(Me.Label_FRCount, "Label_FRCount")
        Me.Label_FRCount.Name = "Label_FRCount"
        '
        'ListView_FilterRegion
        '
        resources.ApplyResources(Me.ListView_FilterRegion, "ListView_FilterRegion")
        Me.ListView_FilterRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Ch_LeftX, Me.Ch_TopY, Me.Ch_RightX, Me.Ch_BottomY, Me.Ch_Pattern, Me.Ch_Blacking, Me.Ch_PType})
        Me.ListView_FilterRegion.FullRowSelect = True
        Me.ListView_FilterRegion.GridLines = True
        Me.ListView_FilterRegion.Name = "ListView_FilterRegion"
        Me.ListView_FilterRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_FilterRegion.View = System.Windows.Forms.View.Details
        '
        'Ch_LeftX
        '
        resources.ApplyResources(Me.Ch_LeftX, "Ch_LeftX")
        '
        'Ch_TopY
        '
        resources.ApplyResources(Me.Ch_TopY, "Ch_TopY")
        '
        'Ch_RightX
        '
        resources.ApplyResources(Me.Ch_RightX, "Ch_RightX")
        '
        'Ch_BottomY
        '
        resources.ApplyResources(Me.Ch_BottomY, "Ch_BottomY")
        '
        'Ch_Pattern
        '
        resources.ApplyResources(Me.Ch_Pattern, "Ch_Pattern")
        '
        'Ch_Blacking
        '
        resources.ApplyResources(Me.Ch_Blacking, "Ch_Blacking")
        '
        'Ch_PType
        '
        resources.ApplyResources(Me.Ch_PType, "Ch_PType")
        '
        'TabPage_UnFilterRegion
        '
        resources.ApplyResources(Me.TabPage_UnFilterRegion, "TabPage_UnFilterRegion")
        Me.TabPage_UnFilterRegion.Controls.Add(Me.ComboBox_UFR_Mask)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.Label33)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.GroupBox_Display_UFR)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.Label16)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.ComboBox_UFR_Pattern)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.GroupBox_MannualAddUFR)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.Button_UFR_Close)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.Button_UFR_Save)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.GroupBox_AutoAddUFR)
        Me.TabPage_UnFilterRegion.Controls.Add(Me.GroupBox_UnFilterRegion)
        Me.TabPage_UnFilterRegion.Name = "TabPage_UnFilterRegion"
        Me.TabPage_UnFilterRegion.UseVisualStyleBackColor = True
        '
        'ComboBox_UFR_Mask
        '
        resources.ApplyResources(Me.ComboBox_UFR_Mask, "ComboBox_UFR_Mask")
        Me.ComboBox_UFR_Mask.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_UFR_Mask.FormattingEnabled = True
        Me.ComboBox_UFR_Mask.Name = "ComboBox_UFR_Mask"
        '
        'Label33
        '
        resources.ApplyResources(Me.Label33, "Label33")
        Me.Label33.Name = "Label33"
        '
        'GroupBox_Display_UFR
        '
        resources.ApplyResources(Me.GroupBox_Display_UFR, "GroupBox_Display_UFR")
        Me.GroupBox_Display_UFR.Controls.Add(Me.ComboBox_Show_UFR_Single)
        Me.GroupBox_Display_UFR.Controls.Add(Me.CheckBox_Show_UFR_Single)
        Me.GroupBox_Display_UFR.Name = "GroupBox_Display_UFR"
        Me.GroupBox_Display_UFR.TabStop = False
        '
        'ComboBox_Show_UFR_Single
        '
        resources.ApplyResources(Me.ComboBox_Show_UFR_Single, "ComboBox_Show_UFR_Single")
        Me.ComboBox_Show_UFR_Single.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Show_UFR_Single.Name = "ComboBox_Show_UFR_Single"
        '
        'CheckBox_Show_UFR_Single
        '
        resources.ApplyResources(Me.CheckBox_Show_UFR_Single, "CheckBox_Show_UFR_Single")
        Me.CheckBox_Show_UFR_Single.Name = "CheckBox_Show_UFR_Single"
        Me.CheckBox_Show_UFR_Single.UseVisualStyleBackColor = True
        '
        'Label16
        '
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        '
        'ComboBox_UFR_Pattern
        '
        resources.ApplyResources(Me.ComboBox_UFR_Pattern, "ComboBox_UFR_Pattern")
        Me.ComboBox_UFR_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_UFR_Pattern.Name = "ComboBox_UFR_Pattern"
        '
        'GroupBox_MannualAddUFR
        '
        resources.ApplyResources(Me.GroupBox_MannualAddUFR, "GroupBox_MannualAddUFR")
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Button_UFR_AddOne)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MaxY)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label10)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MaxX)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label11)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label12)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MinX)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.TextBox_UFR_MinY)
        Me.GroupBox_MannualAddUFR.Controls.Add(Me.Label13)
        Me.GroupBox_MannualAddUFR.Name = "GroupBox_MannualAddUFR"
        Me.GroupBox_MannualAddUFR.TabStop = False
        '
        'Button_UFR_AddOne
        '
        resources.ApplyResources(Me.Button_UFR_AddOne, "Button_UFR_AddOne")
        Me.Button_UFR_AddOne.Name = "Button_UFR_AddOne"
        Me.Button_UFR_AddOne.UseVisualStyleBackColor = True
        '
        'TextBox_UFR_MaxY
        '
        resources.ApplyResources(Me.TextBox_UFR_MaxY, "TextBox_UFR_MaxY")
        Me.TextBox_UFR_MaxY.Name = "TextBox_UFR_MaxY"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'TextBox_UFR_MaxX
        '
        resources.ApplyResources(Me.TextBox_UFR_MaxX, "TextBox_UFR_MaxX")
        Me.TextBox_UFR_MaxX.Name = "TextBox_UFR_MaxX"
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'TextBox_UFR_MinX
        '
        resources.ApplyResources(Me.TextBox_UFR_MinX, "TextBox_UFR_MinX")
        Me.TextBox_UFR_MinX.Name = "TextBox_UFR_MinX"
        '
        'TextBox_UFR_MinY
        '
        resources.ApplyResources(Me.TextBox_UFR_MinY, "TextBox_UFR_MinY")
        Me.TextBox_UFR_MinY.Name = "TextBox_UFR_MinY"
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'Button_UFR_Close
        '
        resources.ApplyResources(Me.Button_UFR_Close, "Button_UFR_Close")
        Me.Button_UFR_Close.Name = "Button_UFR_Close"
        '
        'Button_UFR_Save
        '
        resources.ApplyResources(Me.Button_UFR_Save, "Button_UFR_Save")
        Me.Button_UFR_Save.Name = "Button_UFR_Save"
        Me.Button_UFR_Save.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoAddUFR
        '
        resources.ApplyResources(Me.GroupBox_AutoAddUFR, "GroupBox_AutoAddUFR")
        Me.GroupBox_AutoAddUFR.Controls.Add(Me.CheckBox_ShowUnFilterRegion)
        Me.GroupBox_AutoAddUFR.Controls.Add(Me.CheckBox_UFR_Mannual)
        Me.GroupBox_AutoAddUFR.Name = "GroupBox_AutoAddUFR"
        Me.GroupBox_AutoAddUFR.TabStop = False
        '
        'CheckBox_ShowUnFilterRegion
        '
        resources.ApplyResources(Me.CheckBox_ShowUnFilterRegion, "CheckBox_ShowUnFilterRegion")
        Me.CheckBox_ShowUnFilterRegion.Name = "CheckBox_ShowUnFilterRegion"
        Me.CheckBox_ShowUnFilterRegion.UseVisualStyleBackColor = True
        '
        'CheckBox_UFR_Mannual
        '
        resources.ApplyResources(Me.CheckBox_UFR_Mannual, "CheckBox_UFR_Mannual")
        Me.CheckBox_UFR_Mannual.Name = "CheckBox_UFR_Mannual"
        Me.CheckBox_UFR_Mannual.UseVisualStyleBackColor = True
        '
        'GroupBox_UnFilterRegion
        '
        resources.ApplyResources(Me.GroupBox_UnFilterRegion, "GroupBox_UnFilterRegion")
        Me.GroupBox_UnFilterRegion.Controls.Add(Me.Button_UFR_CLearAll)
        Me.GroupBox_UnFilterRegion.Controls.Add(Me.Button_UFR_DeleteOne)
        Me.GroupBox_UnFilterRegion.Controls.Add(Me.Label_UFRCount)
        Me.GroupBox_UnFilterRegion.Controls.Add(Me.ListView_UnFilterRegion)
        Me.GroupBox_UnFilterRegion.Name = "GroupBox_UnFilterRegion"
        Me.GroupBox_UnFilterRegion.TabStop = False
        '
        'Button_UFR_CLearAll
        '
        resources.ApplyResources(Me.Button_UFR_CLearAll, "Button_UFR_CLearAll")
        Me.Button_UFR_CLearAll.Name = "Button_UFR_CLearAll"
        Me.Button_UFR_CLearAll.UseVisualStyleBackColor = True
        '
        'Button_UFR_DeleteOne
        '
        resources.ApplyResources(Me.Button_UFR_DeleteOne, "Button_UFR_DeleteOne")
        Me.Button_UFR_DeleteOne.Name = "Button_UFR_DeleteOne"
        Me.Button_UFR_DeleteOne.UseVisualStyleBackColor = True
        '
        'Label_UFRCount
        '
        resources.ApplyResources(Me.Label_UFRCount, "Label_UFRCount")
        Me.Label_UFRCount.Name = "Label_UFRCount"
        '
        'ListView_UnFilterRegion
        '
        resources.ApplyResources(Me.ListView_UnFilterRegion, "ListView_UnFilterRegion")
        Me.ListView_UnFilterRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader10, Me.ColumnHeader11, Me.ColumnHeader12, Me.ColumnHeader13, Me.ColumnHeader14, Me.ColumnHeader24})
        Me.ListView_UnFilterRegion.FullRowSelect = True
        Me.ListView_UnFilterRegion.GridLines = True
        Me.ListView_UnFilterRegion.Name = "ListView_UnFilterRegion"
        Me.ListView_UnFilterRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_UnFilterRegion.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader10
        '
        resources.ApplyResources(Me.ColumnHeader10, "ColumnHeader10")
        '
        'ColumnHeader11
        '
        resources.ApplyResources(Me.ColumnHeader11, "ColumnHeader11")
        '
        'ColumnHeader12
        '
        resources.ApplyResources(Me.ColumnHeader12, "ColumnHeader12")
        '
        'ColumnHeader13
        '
        resources.ApplyResources(Me.ColumnHeader13, "ColumnHeader13")
        '
        'ColumnHeader14
        '
        resources.ApplyResources(Me.ColumnHeader14, "ColumnHeader14")
        '
        'ColumnHeader24
        '
        resources.ApplyResources(Me.ColumnHeader24, "ColumnHeader24")
        '
        'TabPage_ParticleTable
        '
        resources.ApplyResources(Me.TabPage_ParticleTable, "TabPage_ParticleTable")
        Me.TabPage_ParticleTable.Controls.Add(Me.Button_BackParticle_Close)
        Me.TabPage_ParticleTable.Controls.Add(Me.Button_BackParticle_Save)
        Me.TabPage_ParticleTable.Controls.Add(Me.Button_BackParticle_CLearAll)
        Me.TabPage_ParticleTable.Controls.Add(Me.Button_BackParticle_DeleteOne)
        Me.TabPage_ParticleTable.Controls.Add(Me.Label_BackParticleCount)
        Me.TabPage_ParticleTable.Controls.Add(Me.Label17)
        Me.TabPage_ParticleTable.Controls.Add(Me.ListView_ParticleTable)
        Me.TabPage_ParticleTable.Name = "TabPage_ParticleTable"
        Me.TabPage_ParticleTable.UseVisualStyleBackColor = True
        '
        'Button_BackParticle_Close
        '
        resources.ApplyResources(Me.Button_BackParticle_Close, "Button_BackParticle_Close")
        Me.Button_BackParticle_Close.Name = "Button_BackParticle_Close"
        '
        'Button_BackParticle_Save
        '
        resources.ApplyResources(Me.Button_BackParticle_Save, "Button_BackParticle_Save")
        Me.Button_BackParticle_Save.Name = "Button_BackParticle_Save"
        Me.Button_BackParticle_Save.UseVisualStyleBackColor = True
        '
        'Button_BackParticle_CLearAll
        '
        resources.ApplyResources(Me.Button_BackParticle_CLearAll, "Button_BackParticle_CLearAll")
        Me.Button_BackParticle_CLearAll.Name = "Button_BackParticle_CLearAll"
        Me.Button_BackParticle_CLearAll.UseVisualStyleBackColor = True
        '
        'Button_BackParticle_DeleteOne
        '
        resources.ApplyResources(Me.Button_BackParticle_DeleteOne, "Button_BackParticle_DeleteOne")
        Me.Button_BackParticle_DeleteOne.Name = "Button_BackParticle_DeleteOne"
        Me.Button_BackParticle_DeleteOne.UseVisualStyleBackColor = True
        '
        'Label_BackParticleCount
        '
        resources.ApplyResources(Me.Label_BackParticleCount, "Label_BackParticleCount")
        Me.Label_BackParticleCount.Name = "Label_BackParticleCount"
        '
        'Label17
        '
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        '
        'ListView_ParticleTable
        '
        resources.ApplyResources(Me.ListView_ParticleTable, "ListView_ParticleTable")
        Me.ListView_ParticleTable.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader16, Me.ColumnHeader17, Me.ColumnHeader18})
        Me.ListView_ParticleTable.FullRowSelect = True
        Me.ListView_ParticleTable.GridLines = True
        Me.ListView_ParticleTable.HideSelection = False
        Me.ListView_ParticleTable.Name = "ListView_ParticleTable"
        Me.ListView_ParticleTable.UseCompatibleStateImageBehavior = False
        Me.ListView_ParticleTable.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader16
        '
        resources.ApplyResources(Me.ColumnHeader16, "ColumnHeader16")
        '
        'ColumnHeader17
        '
        resources.ApplyResources(Me.ColumnHeader17, "ColumnHeader17")
        '
        'ColumnHeader18
        '
        resources.ApplyResources(Me.ColumnHeader18, "ColumnHeader18")
        '
        'TabPage_MaskMarkRegion
        '
        resources.ApplyResources(Me.TabPage_MaskMarkRegion, "TabPage_MaskMarkRegion")
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.NumericUpDown_MMR_ByPass_AreaMax)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.Label34)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.NumericUpDown_MMR_DilateCount)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.Label32)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.Button_Calculate_MaskImage)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.GroupBox_Display_MMR)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.GroupBox_MannualAddMMR)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.Button_MMR_Close)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.Button_MMR_Save)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.GroupBox_AutoAddMMR)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.Label18)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.ComboBox_MMR_Pattern)
        Me.TabPage_MaskMarkRegion.Controls.Add(Me.GroupBox_MaskMarkRegion)
        Me.TabPage_MaskMarkRegion.Name = "TabPage_MaskMarkRegion"
        Me.TabPage_MaskMarkRegion.UseVisualStyleBackColor = True
        '
        'NumericUpDown_MMR_ByPass_AreaMax
        '
        resources.ApplyResources(Me.NumericUpDown_MMR_ByPass_AreaMax, "NumericUpDown_MMR_ByPass_AreaMax")
        Me.NumericUpDown_MMR_ByPass_AreaMax.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_MMR_ByPass_AreaMax.Name = "NumericUpDown_MMR_ByPass_AreaMax"
        Me.NumericUpDown_MMR_ByPass_AreaMax.Value = New Decimal(New Integer() {150, 0, 0, 0})
        '
        'Label34
        '
        resources.ApplyResources(Me.Label34, "Label34")
        Me.Label34.Name = "Label34"
        '
        'NumericUpDown_MMR_DilateCount
        '
        resources.ApplyResources(Me.NumericUpDown_MMR_DilateCount, "NumericUpDown_MMR_DilateCount")
        Me.NumericUpDown_MMR_DilateCount.Name = "NumericUpDown_MMR_DilateCount"
        Me.NumericUpDown_MMR_DilateCount.Value = New Decimal(New Integer() {4, 0, 0, 0})
        '
        'Label32
        '
        resources.ApplyResources(Me.Label32, "Label32")
        Me.Label32.Name = "Label32"
        '
        'Button_Calculate_MaskImage
        '
        resources.ApplyResources(Me.Button_Calculate_MaskImage, "Button_Calculate_MaskImage")
        Me.Button_Calculate_MaskImage.Name = "Button_Calculate_MaskImage"
        Me.Button_Calculate_MaskImage.UseVisualStyleBackColor = True
        '
        'GroupBox_Display_MMR
        '
        resources.ApplyResources(Me.GroupBox_Display_MMR, "GroupBox_Display_MMR")
        Me.GroupBox_Display_MMR.Controls.Add(Me.ComboBox_Show_MMR_Single)
        Me.GroupBox_Display_MMR.Controls.Add(Me.CheckBox_Show_MMR_Single)
        Me.GroupBox_Display_MMR.Name = "GroupBox_Display_MMR"
        Me.GroupBox_Display_MMR.TabStop = False
        '
        'ComboBox_Show_MMR_Single
        '
        resources.ApplyResources(Me.ComboBox_Show_MMR_Single, "ComboBox_Show_MMR_Single")
        Me.ComboBox_Show_MMR_Single.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Show_MMR_Single.Name = "ComboBox_Show_MMR_Single"
        '
        'CheckBox_Show_MMR_Single
        '
        resources.ApplyResources(Me.CheckBox_Show_MMR_Single, "CheckBox_Show_MMR_Single")
        Me.CheckBox_Show_MMR_Single.Name = "CheckBox_Show_MMR_Single"
        Me.CheckBox_Show_MMR_Single.UseVisualStyleBackColor = True
        '
        'GroupBox_MannualAddMMR
        '
        resources.ApplyResources(Me.GroupBox_MannualAddMMR, "GroupBox_MannualAddMMR")
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.Button_MMR_AddOne)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.TextBox_MMR_MaxY)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.Label19)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.TextBox_MMR_MaxX)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.Label29)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.Label30)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.TextBox_MMR_MinX)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.TextBox_MMR_MinY)
        Me.GroupBox_MannualAddMMR.Controls.Add(Me.Label31)
        Me.GroupBox_MannualAddMMR.Name = "GroupBox_MannualAddMMR"
        Me.GroupBox_MannualAddMMR.TabStop = False
        '
        'Button_MMR_AddOne
        '
        resources.ApplyResources(Me.Button_MMR_AddOne, "Button_MMR_AddOne")
        Me.Button_MMR_AddOne.Name = "Button_MMR_AddOne"
        Me.Button_MMR_AddOne.UseVisualStyleBackColor = True
        '
        'TextBox_MMR_MaxY
        '
        resources.ApplyResources(Me.TextBox_MMR_MaxY, "TextBox_MMR_MaxY")
        Me.TextBox_MMR_MaxY.Name = "TextBox_MMR_MaxY"
        '
        'Label19
        '
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.Name = "Label19"
        '
        'TextBox_MMR_MaxX
        '
        resources.ApplyResources(Me.TextBox_MMR_MaxX, "TextBox_MMR_MaxX")
        Me.TextBox_MMR_MaxX.Name = "TextBox_MMR_MaxX"
        '
        'Label29
        '
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Name = "Label29"
        '
        'Label30
        '
        resources.ApplyResources(Me.Label30, "Label30")
        Me.Label30.Name = "Label30"
        '
        'TextBox_MMR_MinX
        '
        resources.ApplyResources(Me.TextBox_MMR_MinX, "TextBox_MMR_MinX")
        Me.TextBox_MMR_MinX.Name = "TextBox_MMR_MinX"
        '
        'TextBox_MMR_MinY
        '
        resources.ApplyResources(Me.TextBox_MMR_MinY, "TextBox_MMR_MinY")
        Me.TextBox_MMR_MinY.Name = "TextBox_MMR_MinY"
        '
        'Label31
        '
        resources.ApplyResources(Me.Label31, "Label31")
        Me.Label31.Name = "Label31"
        '
        'Button_MMR_Close
        '
        resources.ApplyResources(Me.Button_MMR_Close, "Button_MMR_Close")
        Me.Button_MMR_Close.Name = "Button_MMR_Close"
        '
        'Button_MMR_Save
        '
        resources.ApplyResources(Me.Button_MMR_Save, "Button_MMR_Save")
        Me.Button_MMR_Save.Name = "Button_MMR_Save"
        Me.Button_MMR_Save.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoAddMMR
        '
        resources.ApplyResources(Me.GroupBox_AutoAddMMR, "GroupBox_AutoAddMMR")
        Me.GroupBox_AutoAddMMR.Controls.Add(Me.CheckBox_ShowMaskMarkRegion)
        Me.GroupBox_AutoAddMMR.Controls.Add(Me.CheckBox_MMR_Mannual)
        Me.GroupBox_AutoAddMMR.Name = "GroupBox_AutoAddMMR"
        Me.GroupBox_AutoAddMMR.TabStop = False
        '
        'CheckBox_ShowMaskMarkRegion
        '
        resources.ApplyResources(Me.CheckBox_ShowMaskMarkRegion, "CheckBox_ShowMaskMarkRegion")
        Me.CheckBox_ShowMaskMarkRegion.Name = "CheckBox_ShowMaskMarkRegion"
        Me.CheckBox_ShowMaskMarkRegion.UseVisualStyleBackColor = True
        '
        'CheckBox_MMR_Mannual
        '
        resources.ApplyResources(Me.CheckBox_MMR_Mannual, "CheckBox_MMR_Mannual")
        Me.CheckBox_MMR_Mannual.Name = "CheckBox_MMR_Mannual"
        Me.CheckBox_MMR_Mannual.UseVisualStyleBackColor = True
        '
        'Label18
        '
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        '
        'ComboBox_MMR_Pattern
        '
        resources.ApplyResources(Me.ComboBox_MMR_Pattern, "ComboBox_MMR_Pattern")
        Me.ComboBox_MMR_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_MMR_Pattern.Name = "ComboBox_MMR_Pattern"
        '
        'GroupBox_MaskMarkRegion
        '
        resources.ApplyResources(Me.GroupBox_MaskMarkRegion, "GroupBox_MaskMarkRegion")
        Me.GroupBox_MaskMarkRegion.Controls.Add(Me.Button_MMR_CLearAll)
        Me.GroupBox_MaskMarkRegion.Controls.Add(Me.Button_MMR_DeleteOne)
        Me.GroupBox_MaskMarkRegion.Controls.Add(Me.Label_MMRCount)
        Me.GroupBox_MaskMarkRegion.Controls.Add(Me.ListView_MaskMarkRegion)
        Me.GroupBox_MaskMarkRegion.Name = "GroupBox_MaskMarkRegion"
        Me.GroupBox_MaskMarkRegion.TabStop = False
        '
        'Button_MMR_CLearAll
        '
        resources.ApplyResources(Me.Button_MMR_CLearAll, "Button_MMR_CLearAll")
        Me.Button_MMR_CLearAll.Name = "Button_MMR_CLearAll"
        Me.Button_MMR_CLearAll.UseVisualStyleBackColor = True
        '
        'Button_MMR_DeleteOne
        '
        resources.ApplyResources(Me.Button_MMR_DeleteOne, "Button_MMR_DeleteOne")
        Me.Button_MMR_DeleteOne.Name = "Button_MMR_DeleteOne"
        Me.Button_MMR_DeleteOne.UseVisualStyleBackColor = True
        '
        'Label_MMRCount
        '
        resources.ApplyResources(Me.Label_MMRCount, "Label_MMRCount")
        Me.Label_MMRCount.Name = "Label_MMRCount"
        '
        'ListView_MaskMarkRegion
        '
        resources.ApplyResources(Me.ListView_MaskMarkRegion, "ListView_MaskMarkRegion")
        Me.ListView_MaskMarkRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader15, Me.ColumnHeader19, Me.ColumnHeader20, Me.ColumnHeader21, Me.ColumnHeader22})
        Me.ListView_MaskMarkRegion.FullRowSelect = True
        Me.ListView_MaskMarkRegion.GridLines = True
        Me.ListView_MaskMarkRegion.Name = "ListView_MaskMarkRegion"
        Me.ListView_MaskMarkRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_MaskMarkRegion.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader15
        '
        resources.ApplyResources(Me.ColumnHeader15, "ColumnHeader15")
        '
        'ColumnHeader19
        '
        resources.ApplyResources(Me.ColumnHeader19, "ColumnHeader19")
        '
        'ColumnHeader20
        '
        resources.ApplyResources(Me.ColumnHeader20, "ColumnHeader20")
        '
        'ColumnHeader21
        '
        resources.ApplyResources(Me.ColumnHeader21, "ColumnHeader21")
        '
        'ColumnHeader22
        '
        resources.ApplyResources(Me.ColumnHeader22, "ColumnHeader22")
        '
        'ListView1
        '
        resources.ApplyResources(Me.ListView1, "ListView1")
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader32, Me.ColumnHeader33, Me.ColumnHeader34, Me.ColumnHeader35, Me.ColumnHeader36, Me.ColumnHeader37, Me.ColumnHeader38, ColumnHeader39, Me.ColumnHeader40})
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.HideSelection = False
        Me.ListView1.Name = "ListView1"
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader32
        '
        resources.ApplyResources(Me.ColumnHeader32, "ColumnHeader32")
        '
        'ColumnHeader33
        '
        resources.ApplyResources(Me.ColumnHeader33, "ColumnHeader33")
        '
        'ColumnHeader34
        '
        resources.ApplyResources(Me.ColumnHeader34, "ColumnHeader34")
        '
        'ColumnHeader35
        '
        resources.ApplyResources(Me.ColumnHeader35, "ColumnHeader35")
        '
        'ColumnHeader36
        '
        resources.ApplyResources(Me.ColumnHeader36, "ColumnHeader36")
        '
        'ColumnHeader37
        '
        resources.ApplyResources(Me.ColumnHeader37, "ColumnHeader37")
        '
        'ColumnHeader38
        '
        resources.ApplyResources(Me.ColumnHeader38, "ColumnHeader38")
        '
        'ColumnHeader40
        '
        resources.ApplyResources(Me.ColumnHeader40, "ColumnHeader40")
        '
        'Label20
        '
        resources.ApplyResources(Me.Label20, "Label20")
        Me.Label20.Name = "Label20"
        '
        'TableLayoutPanel2
        '
        resources.ApplyResources(Me.TableLayoutPanel2, "TableLayoutPanel2")
        Me.TableLayoutPanel2.Controls.Add(Me.Button1, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Button2, 1, 0)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        '
        'Button1
        '
        resources.ApplyResources(Me.Button1, "Button1")
        Me.Button1.Name = "Button1"
        '
        'Button2
        '
        resources.ApplyResources(Me.Button2, "Button2")
        Me.Button2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button2.Name = "Button2"
        '
        'Button3
        '
        resources.ApplyResources(Me.Button3, "Button3")
        Me.Button3.Name = "Button3"
        '
        'Label21
        '
        resources.ApplyResources(Me.Label21, "Label21")
        Me.Label21.Name = "Label21"
        '
        'Button4
        '
        resources.ApplyResources(Me.Button4, "Button4")
        Me.Button4.Name = "Button4"
        '
        'ComboBox1
        '
        resources.ApplyResources(Me.ComboBox1, "ComboBox1")
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {resources.GetString("ComboBox1.Items"), resources.GetString("ComboBox1.Items1"), resources.GetString("ComboBox1.Items2"), resources.GetString("ComboBox1.Items3")})
        Me.ComboBox1.Name = "ComboBox1"
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.Button5)
        Me.GroupBox2.Controls.Add(Me.ComboBox2)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.Button6)
        Me.GroupBox2.Controls.Add(Me.Button7)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.Label24)
        Me.GroupBox2.Controls.Add(Me.Label25)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown1)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown2)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown3)
        Me.GroupBox2.Controls.Add(Me.Button8)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'Button5
        '
        resources.ApplyResources(Me.Button5, "Button5")
        Me.Button5.Name = "Button5"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'ComboBox2
        '
        resources.ApplyResources(Me.ComboBox2, "ComboBox2")
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Name = "ComboBox2"
        '
        'Label22
        '
        resources.ApplyResources(Me.Label22, "Label22")
        Me.Label22.Name = "Label22"
        '
        'Button6
        '
        resources.ApplyResources(Me.Button6, "Button6")
        Me.Button6.Name = "Button6"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        resources.ApplyResources(Me.Button7, "Button7")
        Me.Button7.Name = "Button7"
        '
        'Label23
        '
        resources.ApplyResources(Me.Label23, "Label23")
        Me.Label23.Name = "Label23"
        '
        'Label24
        '
        resources.ApplyResources(Me.Label24, "Label24")
        Me.Label24.Name = "Label24"
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        '
        'NumericUpDown1
        '
        resources.ApplyResources(Me.NumericUpDown1, "NumericUpDown1")
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {2671, 0, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown2
        '
        resources.ApplyResources(Me.NumericUpDown2, "NumericUpDown2")
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {3999, 0, 0, 0})
        Me.NumericUpDown2.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown3
        '
        resources.ApplyResources(Me.NumericUpDown3, "NumericUpDown3")
        Me.NumericUpDown3.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Value = New Decimal(New Integer() {5, 0, 0, 0})
        '
        'Button8
        '
        resources.ApplyResources(Me.Button8, "Button8")
        Me.Button8.Name = "Button8"
        '
        'NumericUpDown4
        '
        resources.ApplyResources(Me.NumericUpDown4, "NumericUpDown4")
        Me.NumericUpDown4.Maximum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDown4.Name = "NumericUpDown4"
        Me.NumericUpDown4.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label26
        '
        resources.ApplyResources(Me.Label26, "Label26")
        Me.Label26.Name = "Label26"
        '
        'Button9
        '
        resources.ApplyResources(Me.Button9, "Button9")
        Me.Button9.Name = "Button9"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label27
        '
        resources.ApplyResources(Me.Label27, "Label27")
        Me.Label27.Name = "Label27"
        '
        'Label28
        '
        resources.ApplyResources(Me.Label28, "Label28")
        Me.Label28.Name = "Label28"
        '
        'ListView2
        '
        resources.ApplyResources(Me.ListView2, "ListView2")
        Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader41, Me.ColumnHeader42, Me.ColumnHeader43, Me.ColumnHeader44, Me.ColumnHeader45, Me.ColumnHeader46, Me.ColumnHeader47, Me.ColumnHeader48, Me.ColumnHeader49})
        Me.ListView2.FullRowSelect = True
        Me.ListView2.GridLines = True
        Me.ListView2.HideSelection = False
        Me.ListView2.Name = "ListView2"
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader41
        '
        resources.ApplyResources(Me.ColumnHeader41, "ColumnHeader41")
        '
        'ColumnHeader42
        '
        resources.ApplyResources(Me.ColumnHeader42, "ColumnHeader42")
        '
        'ColumnHeader43
        '
        resources.ApplyResources(Me.ColumnHeader43, "ColumnHeader43")
        '
        'ColumnHeader44
        '
        resources.ApplyResources(Me.ColumnHeader44, "ColumnHeader44")
        '
        'ColumnHeader45
        '
        resources.ApplyResources(Me.ColumnHeader45, "ColumnHeader45")
        '
        'ColumnHeader46
        '
        resources.ApplyResources(Me.ColumnHeader46, "ColumnHeader46")
        '
        'ColumnHeader47
        '
        resources.ApplyResources(Me.ColumnHeader47, "ColumnHeader47")
        '
        'ColumnHeader48
        '
        resources.ApplyResources(Me.ColumnHeader48, "ColumnHeader48")
        '
        'ColumnHeader49
        '
        resources.ApplyResources(Me.ColumnHeader49, "ColumnHeader49")
        '
        'Dialog_FuncFalseDefect
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.TabControl_FalseDefect)
        Me.Controls.Add(Me.GroupBox_Judge)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_FuncFalseDefect"
        Me.ShowInTaskbar = False
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox_Manual.ResumeLayout(False)
        Me.GroupBox_Manual.PerformLayout()
        CType(Me.NumericUpDown_Y, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_X, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Area, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Judge.ResumeLayout(False)
        Me.GroupBox_Judge.PerformLayout()
        CType(Me.NumericUpDown_Dist, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_FalseArea, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_CompareOK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Check, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl_FalseDefect.ResumeLayout(False)
        Me.TabPage_FalseDefectTable.ResumeLayout(False)
        Me.TabPage_FalseDefectTable.PerformLayout()
        Me.TabPage_FilterRegion.ResumeLayout(False)
        Me.TabPage_FilterRegion.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.NumericUpDown_FalseLineWidth, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Display_FR.ResumeLayout(False)
        Me.GroupBox_Display_FR.PerformLayout()
        Me.GroupBox_MannualAddFR.ResumeLayout(False)
        Me.GroupBox_MannualAddFR.PerformLayout()
        CType(Me.NumericUpDown_PType, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_AutoAddFR.ResumeLayout(False)
        Me.GroupBox_AutoAddFR.PerformLayout()
        Me.GroupBox_FilterRegion.ResumeLayout(False)
        Me.GroupBox_FilterRegion.PerformLayout()
        Me.TabPage_UnFilterRegion.ResumeLayout(False)
        Me.TabPage_UnFilterRegion.PerformLayout()
        Me.GroupBox_Display_UFR.ResumeLayout(False)
        Me.GroupBox_Display_UFR.PerformLayout()
        Me.GroupBox_MannualAddUFR.ResumeLayout(False)
        Me.GroupBox_MannualAddUFR.PerformLayout()
        Me.GroupBox_AutoAddUFR.ResumeLayout(False)
        Me.GroupBox_AutoAddUFR.PerformLayout()
        Me.GroupBox_UnFilterRegion.ResumeLayout(False)
        Me.GroupBox_UnFilterRegion.PerformLayout()
        Me.TabPage_ParticleTable.ResumeLayout(False)
        Me.TabPage_ParticleTable.PerformLayout()
        Me.TabPage_MaskMarkRegion.ResumeLayout(False)
        Me.TabPage_MaskMarkRegion.PerformLayout()
        CType(Me.NumericUpDown_MMR_ByPass_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MMR_DilateCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Display_MMR.ResumeLayout(False)
        Me.GroupBox_Display_MMR.PerformLayout()
        Me.GroupBox_MannualAddMMR.ResumeLayout(False)
        Me.GroupBox_MannualAddMMR.PerformLayout()
        Me.GroupBox_AutoAddMMR.ResumeLayout(False)
        Me.GroupBox_AutoAddMMR.PerformLayout()
        Me.GroupBox_MaskMarkRegion.ResumeLayout(False)
        Me.GroupBox_MaskMarkRegion.PerformLayout()
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents Label_NewPosition As System.Windows.Forms.Label
    Friend WithEvents Label_FalsePosition As System.Windows.Forms.Label
    Friend WithEvents Label_FalseType As System.Windows.Forms.Label
    Friend WithEvents ListView_False As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Area As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_X As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Y As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_CreatTime As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Count As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_CountMatch As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox_Manual As System.Windows.Forms.GroupBox
    Friend WithEvents Label_Y As System.Windows.Forms.Label
    Friend WithEvents Label_X As System.Windows.Forms.Label
    Friend WithEvents Label_Area As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Y As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_X As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Area As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_FalseAdd As System.Windows.Forms.Button
    Friend WithEvents Button_FalseRemove As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader_History As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView_New As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox_Judge As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Check As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_CompareOK As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_FalseArea As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Dist As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_GenSample As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Clear As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader_Type As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button_AddOne As System.Windows.Forms.Button
    Friend WithEvents ComboBox_FalseType As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MaxFalseDefectTable As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox_DeleteTableCount As System.Windows.Forms.TextBox
    Friend WithEvents Label_FalseTableCount As System.Windows.Forms.Label
    Friend WithEvents Label_FalseTempCount As System.Windows.Forms.Label
    Friend WithEvents TabControl_FalseDefect As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_FalseDefectTable As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_FilterRegion As System.Windows.Forms.TabPage
    Friend WithEvents ListView_FilterRegion As System.Windows.Forms.ListView
    Friend WithEvents Ch_LeftX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_TopY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_RightX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_BottomY As System.Windows.Forms.ColumnHeader
    Friend WithEvents GroupBox_FilterRegion As System.Windows.Forms.GroupBox
    Friend WithEvents Button_FR_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents Label_FRCount As System.Windows.Forms.Label
    Friend WithEvents GroupBox_AutoAddFR As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowFilterRegion As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FR_Mannual As System.Windows.Forms.CheckBox
    Friend WithEvents Button_FR_Close As System.Windows.Forms.Button
    Friend WithEvents Button_FR_Save As System.Windows.Forms.Button
    Friend WithEvents GroupBox_MannualAddFR As System.Windows.Forms.GroupBox
    Friend WithEvents Button_FR_AddOne As System.Windows.Forms.Button
    Friend WithEvents TextBox_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents lbData As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MinX As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_MinY As System.Windows.Forms.TextBox
    Friend WithEvents lbGate As System.Windows.Forms.Label
    Friend WithEvents TabPage_UnFilterRegion As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_MannualAddUFR As System.Windows.Forms.GroupBox
    Friend WithEvents Button_UFR_AddOne As System.Windows.Forms.Button
    Friend WithEvents TextBox_UFR_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox_UFR_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox_UFR_MinX As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_UFR_MinY As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button_UFR_Close As System.Windows.Forms.Button
    Friend WithEvents Button_UFR_Save As System.Windows.Forms.Button
    Friend WithEvents GroupBox_AutoAddUFR As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowUnFilterRegion As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_UFR_Mannual As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_UnFilterRegion As System.Windows.Forms.GroupBox
    Friend WithEvents Button_UFR_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents Label_UFRCount As System.Windows.Forms.Label
    Friend WithEvents ListView_UnFilterRegion As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader13 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader32 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader33 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader34 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader35 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader36 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader37 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader38 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader40 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents ListView2 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader41 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader42 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader43 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader44 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader45 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader46 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader47 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader48 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader49 As System.Windows.Forms.ColumnHeader
    Friend WithEvents CheckBox_LineNotAddToFDTable As System.Windows.Forms.CheckBox
    Friend WithEvents Ch_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_FR_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents Button_FR_ClearAll As System.Windows.Forms.Button
    Friend WithEvents Ch_Blacking As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_FR_Blacking As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_Display_FR As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_Show_FR_Single As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_Show_FR_Single As System.Windows.Forms.CheckBox
    Friend WithEvents ColumnHeader14 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_UFR_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents Button_UFR_CLearAll As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Display_UFR As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_Show_UFR_Single As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_Show_UFR_Single As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage_ParticleTable As System.Windows.Forms.TabPage
    Friend WithEvents Button_BackParticle_CLearAll As System.Windows.Forms.Button
    Friend WithEvents Button_BackParticle_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents Label_BackParticleCount As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents ListView_ParticleTable As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader16 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader17 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader18 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button_BackParticle_Close As System.Windows.Forms.Button
    Friend WithEvents Button_BackParticle_Save As System.Windows.Forms.Button
    Friend WithEvents TabPage_MaskMarkRegion As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_Display_MMR As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_Show_MMR_Single As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_Show_MMR_Single As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_MannualAddMMR As System.Windows.Forms.GroupBox
    Friend WithEvents Button_MMR_AddOne As System.Windows.Forms.Button
    Friend WithEvents TextBox_MMR_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MMR_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox_MMR_MinX As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_MMR_MinY As System.Windows.Forms.TextBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Button_MMR_Close As System.Windows.Forms.Button
    Friend WithEvents Button_MMR_Save As System.Windows.Forms.Button
    Friend WithEvents GroupBox_AutoAddMMR As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowMaskMarkRegion As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_MMR_Mannual As System.Windows.Forms.CheckBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_MMR_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_MaskMarkRegion As System.Windows.Forms.GroupBox
    Friend WithEvents Button_MMR_CLearAll As System.Windows.Forms.Button
    Friend WithEvents Button_MMR_DeleteOne As System.Windows.Forms.Button
    Friend WithEvents Label_MMRCount As System.Windows.Forms.Label
    Friend WithEvents ListView_MaskMarkRegion As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader15 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader19 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader20 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader21 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader22 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents ComboBox_FalsePattern As System.Windows.Forms.ComboBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents ColumnHeader23 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button_Calculate_MaskImage As System.Windows.Forms.Button
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MMR_DilateCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents ColumnHeader24 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ComboBox_UFR_Mask As System.Windows.Forms.ComboBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MMR_ByPass_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Ch_PType As System.Windows.Forms.ColumnHeader
    Friend WithEvents NumericUpDown_PType As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_AutoAddFuncFalseDefect As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_FalseLineWidth As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_EnableFalseLine As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox_FalseLineDirection As System.Windows.Forms.ComboBox

End Class
