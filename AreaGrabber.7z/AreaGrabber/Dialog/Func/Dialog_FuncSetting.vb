﻿Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl

Imports System.IO
Imports System.Text
Imports System.Threading
Imports System.Globalization

<CLSCompliant(False)> _
Public Class Dialog_FuncSetting

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_Inverse As Boolean
    Private m_UpdatePLMark As Boolean
    Private m_UpdatePLTH As Boolean

    '--- 連線參數 ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '--- 繪圖 ---
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_Size As Integer

    '--- PL Mark ---
    Private m_CurrentPLMark As New ClsPLMark
    Private m_CurrentPLMarkIndex As Integer = 0   '目前所選擇的 Mark
    Private m_AxMDisplay_PLMark As MIL_ID         '顯示 PLMark

    '--- TP Mark ---
    Private m_CurrentTPMark As New ClsTPMark
    Private m_CurrentTPMarkIndex As Integer = 0   '目前所選擇的 Mark
    Private m_AddMode_TPMark As Boolean = False
    Private m_AxMDisplay_TPMark As MIL_ID         '顯示 TPMark

    '--- Temp ---
    Private m_offX As Integer
    Private m_offY As Integer

    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim i As Integer
        Dim Image As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- Change Language ---
            res = New Resources.ResourceManager("AreaGrabber.Dialog_FuncSetting", Me.GetType().Assembly)
            Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
            Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
            Me.changeLanguage(language)
            '------------
            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess
            Me.m_FuncProcess = form.MainProcess.FuncProcess
            Me.m_MuraProcess = form.MainProcess.MuraProcess
            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig

            Me.m_offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            Me.m_offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

            Me.m_UpdatePLMark = False
            Me.m_UpdatePLTH = False

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Set Pattern (已含 UpdateData()) ---
            Me.ComboBox_Pattern.Items.Clear()
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ComboBox_Pattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.ComboBox_Pattern.SelectedIndex = 0
            Else
                Me.ComboBox_Pattern.SelectedIndex = Me.m_Form.GetPatternIndexInfo - Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            End If

            If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            End If

            '--- 繪圖 ---
            '---[1] 繪製搜尋到的Mark ---
            Me.m_AxMDisplay = Me.m_Form.AxMDisplay
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_Pen = New Pen(Color.White)
            Me.m_SolidBrush = New SolidBrush(Color.White)
            Me.m_Size = 15
            Me.m_Form.PaintStop = True

            '---[2] 建立顯示 PLMark 元件 ---
            If Me.m_AxMDisplay_PLMark <> M_NULL Then
                MdispFree(Me.m_AxMDisplay_PLMark)
                Me.m_AxMDisplay_PLMark = M_NULL
            End If
            MdispAlloc(Me.m_MainProcess.System_Host, M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay_PLMark)

            '---[3] 建立顯示 TPMark 元件 ---
            If Me.m_AxMDisplay_TPMark <> M_NULL Then
                MdispFree(Me.m_AxMDisplay_TPMark)
                Me.m_AxMDisplay_TPMark = M_NULL
            End If
            MdispAlloc(Me.m_MainProcess.System_Host, M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay_TPMark)

            '--- Img_FixRecipe_NonPage ---
            SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
            Type = MbufInquire(Me.m_MainProcess.Img_FixRecipe_NonPage, M_TYPE, M_NULL)

            If Me.m_MainProcess.Img_FixRecipe_NonPage <> M_NULL Then
                MbufFree(Me.m_MainProcess.Img_FixRecipe_NonPage)
                Me.m_MainProcess.Img_FixRecipe_NonPage = M_NULL
            End If

            Me.m_MainProcess.Img_FixRecipe_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)

            Image = Me.m_FuncProcess.Img_Original_NonPage
            If Image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If

            '--- 權限控管 ---
            Me.UpdateUserLevel()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

    End Sub

#Region "--- Dialog Event ---"

#Region "--- Dialog_FuncSetting_Load ---"
    Private Sub Dialog_FuncSetting_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Try
            Me.m_Form.ImageUpdate()
            Me.m_Form.ComboBox_Pattern_MainFrm.Enabled = False
            Me.Update()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.Dialog_FuncSetting_Load]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Dialog_FuncSetting_Closing ---"
    Private Sub Dialog_FuncSetting_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.m_Form.Focus()
        Me.m_Form.PaintStop = True

        '--- Free PLMark Display ---
        If Me.m_AxMDisplay_PLMark <> M_NULL Then
            MdispFree(Me.m_AxMDisplay_PLMark)
            Me.m_AxMDisplay_PLMark = M_NULL
        End If

        '--- Free TPMark Display ---
        If Me.m_AxMDisplay_TPMark <> M_NULL Then
            MdispFree(Me.m_AxMDisplay_TPMark)
            Me.m_AxMDisplay_TPMark = M_NULL
        End If

        Me.Finalize()
    End Sub
#End Region

#End Region

#Region "--- 方法函式 ---"

#Region "--- UpdateUserLevel ---"

    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.TabControl_Setting.Enabled = False
            Case 1 'PM
                Me.TabControl_Setting.Enabled = False
                Me.CheckBox_Point_Enable.Enabled = False
                Me.CheckBox_Align_Enable.Enabled = False
                Me.CheckBox_GSBP_Enable.Enabled = False
                Me.CheckBox_BLDP_Enable.Enabled = False
                Me.CheckBox_Line_Enable.Enabled = False
                Me.CheckBox_GrayAbnormal_Enable.Enabled = False

                Me.Button_LoadImage.Enabled = False
                'Point ----
                Me.GroupBox_BPoint.Enabled = False
                Me.GroupBox_DPoint.Enabled = False
                Me.GroupBox_PointMode.Enabled = False
                Me.GroupBox_PointCommonSetting.Enabled = False
                'Point Characteristics ---
                Me.GroupBox_BP_Characteristics.Enabled = False
                'Line ----    
                Me.GroupBox_BLine.Enabled = False
                Me.GroupBox_LineCommonSetting.Enabled = False
                Me.GroupBox_MeanDiff.Enabled = False
                'Gray Abnormal ----
                Me.GroupBox_GrayAbnormal.Enabled = False
                'Auto ----
                Me.GroupBox_AutoExposure.Enabled = False
                'Other ----
                Me.GroupBox_PointPitchSetting.Enabled = False
                Me.GroupBox_LinePitchSetting.Enabled = False
                Me.GroupBox_LineAverageFilter.Enabled = False
                Me.GroupBox_Point_Algorithm.Enabled = False

                Me.ComboBox_Pattern.Enabled = False

            Case 2 'ENG
                Me.TabControl_Setting.Enabled = True
                Me.Button_LoadImage.Enabled = True
                Me.Button_Save.Enabled = True
                Me.ComboBox_Pattern.Enabled = True

            Case 3 'ALL
                Me.TabControl_Setting.Enabled = True
                Me.Button_LoadImage.Enabled = True
                Me.Button_Save.Enabled = True
                Me.ComboBox_Pattern.Enabled = True

        End Select
    End Sub

#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Compare ---"

    Private Sub Compare(ByVal fprOld As ClsFuncPatternRecipe, ByVal fprNew As ClsFuncPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[FuncPatternRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        '--- 第一頁 ---
        If fprOld.BDPointRecipe.Threshold_BP.Value <> fprNew.BDPointRecipe.Threshold_BP.Value Then
            dlm.WriteLog("< Threshold_BP >: " & fprOld.BDPointRecipe.Threshold_BP.Value & " --> " & fprNew.BDPointRecipe.Threshold_BP.Value)
            fprOld.BDPointRecipe.Threshold_BP.Value = fprNew.BDPointRecipe.Threshold_BP.Value
        End If
        If fprOld.BDPointRecipe.Threshold_DP.Value <> fprNew.BDPointRecipe.Threshold_DP.Value Then
            dlm.WriteLog("< Threshold_DP >: " & fprOld.BDPointRecipe.Threshold_DP.Value & " --> " & fprNew.BDPointRecipe.Threshold_DP.Value)
            fprOld.BDPointRecipe.Threshold_DP.Value = fprNew.BDPointRecipe.Threshold_DP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_BP.Value <> fprNew.BDPointRecipe.ThresholdRim_BP.Value Then
            dlm.WriteLog("< ThresholdRim_BP >: " & fprOld.BDPointRecipe.ThresholdRim_BP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_BP.Value)
            fprOld.BDPointRecipe.ThresholdRim_BP.Value = fprNew.BDPointRecipe.ThresholdRim_BP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_DP.Value <> fprNew.BDPointRecipe.ThresholdRim_DP.Value Then
            dlm.WriteLog("< ThresholRimd_DP >: " & fprOld.BDPointRecipe.ThresholdRim_DP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_DP.Value)
            fprOld.BDPointRecipe.ThresholdRim_DP.Value = fprNew.BDPointRecipe.ThresholdRim_DP.Value
        End If
        If fprOld.AnalysisBP.Value <> fprNew.AnalysisBP.Value Then
            dlm.WriteLog("< AnalysisBP >: " & fprOld.AnalysisBP.Value & " --> " & fprNew.AnalysisBP.Value)
            fprOld.AnalysisBP.Value = fprNew.AnalysisBP.Value
        End If
        If fprOld.AnalysisDP.Value <> fprNew.AnalysisDP.Value Then
            dlm.WriteLog("< AnalysisDP >: " & fprOld.AnalysisDP.Value & " --> " & fprNew.AnalysisDP.Value)
            fprOld.AnalysisDP.Value = fprNew.AnalysisDP.Value
        End If

        If fprOld.BDPointRecipe.AreaMax_BP.Value <> fprNew.BDPointRecipe.AreaMax_BP.Value Then
            dlm.WriteLog("< AreaMax_BP >: " & fprOld.BDPointRecipe.AreaMax_BP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_BP.Value)
            fprOld.BDPointRecipe.AreaMax_BP.Value = fprNew.BDPointRecipe.AreaMax_BP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_BP.Value <> fprNew.BDPointRecipe.AreaMin_BP.Value Then
            dlm.WriteLog("< AreaMin_BP >: " & fprOld.BDPointRecipe.AreaMin_BP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_BP.Value)
            fprOld.BDPointRecipe.AreaMin_BP.Value = fprNew.BDPointRecipe.AreaMin_BP.Value
        End If

        If fprOld.BDPointRecipe.AreaMax_DP.Value <> fprNew.BDPointRecipe.AreaMax_DP.Value Then
            dlm.WriteLog("< AreaMax_DP >: " & fprOld.BDPointRecipe.AreaMax_DP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_DP.Value)
            fprOld.BDPointRecipe.AreaMax_DP.Value = fprNew.BDPointRecipe.AreaMax_DP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_DP.Value <> fprNew.BDPointRecipe.AreaMin_DP.Value Then
            dlm.WriteLog("< AreaMin_DP >: " & fprOld.BDPointRecipe.AreaMin_DP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_DP.Value)
            fprOld.BDPointRecipe.AreaMin_DP.Value = fprNew.BDPointRecipe.AreaMin_DP.Value
        End If

        If fprOld.BDPointRecipe.BypassX.Value <> fprNew.BDPointRecipe.BypassX.Value Then
            dlm.WriteLog("< BypassX >: " & fprOld.BDPointRecipe.BypassX.Value & " --> " & fprNew.BDPointRecipe.BypassX.Value)
            fprOld.BDPointRecipe.BypassX.Value = fprNew.BDPointRecipe.BypassX.Value
        End If
        If fprOld.BDPointRecipe.BypassY.Value <> fprNew.BDPointRecipe.BypassY.Value Then
            dlm.WriteLog("< BypassY >: " & fprOld.BDPointRecipe.BypassY.Value & " --> " & fprNew.BDPointRecipe.BypassY.Value)
            fprOld.BDPointRecipe.BypassY.Value = fprNew.BDPointRecipe.BypassY.Value
        End If
        If fprOld.BDPointRecipe.OverNum.Value <> fprNew.BDPointRecipe.OverNum.Value Then
            dlm.WriteLog("< OverNum >: " & fprOld.BDPointRecipe.OverNum.Value & " --> " & fprNew.BDPointRecipe.OverNum.Value)
            fprOld.BDPointRecipe.OverNum.Value = fprNew.BDPointRecipe.OverNum.Value
        End If
        If fprOld.PointEnable.Value <> fprNew.PointEnable.Value Then
            dlm.WriteLog("< PointEnable >: " & fprOld.PointEnable.Value & " --> " & fprNew.PointEnable.Value)
            fprOld.PointEnable.Value = fprNew.PointEnable.Value
        End If
        If fprOld.CPDEnable.Value <> fprNew.CPDEnable.Value Then
            dlm.WriteLog("< CPDEnable >: " & fprOld.CPDEnable.Value & " --> " & fprNew.CPDEnable.Value)
            fprOld.CPDEnable.Value = fprNew.CPDEnable.Value
        End If

        '--- 第二頁 ---
        If fprOld.LineFinderRecipe.ByPassUpH.Value <> fprNew.LineFinderRecipe.ByPassUpH.Value Then
            dlm.WriteLog("< ByPassUpH >: " & fprOld.LineFinderRecipe.ByPassUpH.Value & " --> " & fprNew.LineFinderRecipe.ByPassUpH.Value)
            fprOld.LineFinderRecipe.ByPassUpH.Value = fprNew.LineFinderRecipe.ByPassUpH.Value
        End If
        If fprOld.LineFinderRecipe.ByPassDownH.Value <> fprNew.LineFinderRecipe.ByPassDownH.Value Then
            dlm.WriteLog("< ByPassDownH >: " & fprOld.LineFinderRecipe.ByPassDownH.Value & " --> " & fprNew.LineFinderRecipe.ByPassDownH.Value)
            fprOld.LineFinderRecipe.ByPassDownH.Value = fprNew.LineFinderRecipe.ByPassDownH.Value
        End If
        If fprOld.LineFinderRecipe.ByPassLeftV.Value <> fprNew.LineFinderRecipe.ByPassLeftV.Value Then
            dlm.WriteLog("< ByPassLeftV >: " & fprOld.LineFinderRecipe.ByPassLeftV.Value & " --> " & fprNew.LineFinderRecipe.ByPassLeftV.Value)
            fprOld.LineFinderRecipe.ByPassLeftV.Value = fprNew.LineFinderRecipe.ByPassLeftV.Value
        End If
        If fprOld.LineFinderRecipe.ByPassRightV.Value <> fprNew.LineFinderRecipe.ByPassRightV.Value Then
            dlm.WriteLog("< ByPassRightV >: " & fprOld.LineFinderRecipe.ByPassRightV.Value & " --> " & fprNew.LineFinderRecipe.ByPassRightV.Value)
            fprOld.LineFinderRecipe.ByPassRightV.Value = fprNew.LineFinderRecipe.ByPassRightV.Value
        End If
        If fprOld.LineFinderRecipe.Line_Cut.Value <> fprNew.LineFinderRecipe.Line_Cut.Value Then
            dlm.WriteLog("< Line_Cut >: " & fprOld.LineFinderRecipe.Line_Cut.Value & " --> " & fprNew.LineFinderRecipe.Line_Cut.Value)
            fprOld.LineFinderRecipe.Line_Cut.Value = fprNew.LineFinderRecipe.Line_Cut.Value
        End If
        If fprOld.LineFinderRecipe.Line_Short_Cut.Value <> fprNew.LineFinderRecipe.Line_Short_Cut.Value Then
            dlm.WriteLog("< Line_Short_Cut >: " & fprOld.LineFinderRecipe.Line_Short_Cut.Value & " --> " & fprNew.LineFinderRecipe.Line_Short_Cut.Value)
            fprOld.LineFinderRecipe.Line_Short_Cut.Value = fprNew.LineFinderRecipe.Line_Short_Cut.Value
        End If
        If fprOld.LineFinderRecipe.LineOverNum.Value <> fprNew.LineFinderRecipe.LineOverNum.Value Then
            dlm.WriteLog("< LineOverNum >: " & fprOld.LineFinderRecipe.LineOverNum.Value & " --> " & fprNew.LineFinderRecipe.LineOverNum.Value)
            fprOld.LineFinderRecipe.LineOverNum.Value = fprNew.LineFinderRecipe.LineOverNum.Value
        End If
        If fprOld.LineFinderRecipe.BlockOverNum.Value <> fprNew.LineFinderRecipe.BlockOverNum.Value Then
            dlm.WriteLog("< BlockOverNum >: " & fprOld.LineFinderRecipe.BlockOverNum.Value & " --> " & fprNew.LineFinderRecipe.BlockOverNum.Value)
            fprOld.LineFinderRecipe.BlockOverNum.Value = fprNew.LineFinderRecipe.BlockOverNum.Value
        End If
        If fprOld.LineFinderRecipe.Mean_Difference.Value <> fprNew.LineFinderRecipe.Mean_Difference.Value Then
            dlm.WriteLog("< Mean_Difference >: " & fprOld.LineFinderRecipe.Mean_Difference.Value & " --> " & fprNew.LineFinderRecipe.Mean_Difference.Value)
            fprOld.LineFinderRecipe.Mean_Difference.Value = fprNew.LineFinderRecipe.Mean_Difference.Value
        End If
        If fprOld.LineEnable.Value <> fprNew.LineEnable.Value Then
            dlm.WriteLog("< LineEnable >: " & fprOld.LineEnable.Value & " --> " & fprNew.LineEnable.Value)
            fprOld.LineEnable.Value = fprNew.LineEnable.Value
        End If
        If fprOld.HLine_NotAddToOutput.Value <> fprNew.HLine_NotAddToOutput.Value Then
            dlm.WriteLog("< HLine_NotAddToOutput >: " & fprOld.HLine_NotAddToOutput.Value & " --> " & fprNew.HLine_NotAddToOutput.Value)
            fprOld.HLine_NotAddToOutput.Value = fprNew.HLine_NotAddToOutput.Value
        End If
        If fprOld.VLine_NotAddToOutput.Value <> fprNew.VLine_NotAddToOutput.Value Then
            dlm.WriteLog("< VLine_NotAddToOutput >: " & fprOld.VLine_NotAddToOutput.Value & " --> " & fprNew.VLine_NotAddToOutput.Value)
            fprOld.VLine_NotAddToOutput.Value = fprNew.VLine_NotAddToOutput.Value
        End If
        If fprOld.HalfScreenEnable.Value <> fprNew.HalfScreenEnable.Value Then
            dlm.WriteLog("< HalfScreenEnable >: " & fprOld.HalfScreenEnable.Value & " --> " & fprNew.HalfScreenEnable.Value)
            fprOld.HalfScreenEnable.Value = fprNew.HalfScreenEnable.Value
        End If

        '--- 第三頁(GSBDP) ---
        '--- GSBP ---
        If fprOld.BDPointRecipe.Threshold_GSBP.Value <> fprNew.BDPointRecipe.Threshold_GSBP.Value Then
            dlm.WriteLog("< Threshold_GSBP >: " & fprOld.BDPointRecipe.Threshold_GSBP.Value & " --> " & fprNew.BDPointRecipe.Threshold_GSBP.Value)
            fprOld.BDPointRecipe.Threshold_GSBP.Value = fprNew.BDPointRecipe.Threshold_GSBP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_GSBP.Value <> fprNew.BDPointRecipe.ThresholdRim_GSBP.Value Then
            dlm.WriteLog("< ThresholdRim_GSBP >: " & fprOld.BDPointRecipe.ThresholdRim_GSBP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_GSBP.Value)
            fprOld.BDPointRecipe.ThresholdRim_GSBP.Value = fprNew.BDPointRecipe.ThresholdRim_GSBP.Value
        End If

        If fprOld.AnalysisGSBP.Value <> fprNew.AnalysisGSBP.Value Then
            dlm.WriteLog("< AnalysisGSBP >: " & fprOld.AnalysisGSBP.Value & " --> " & fprNew.AnalysisGSBP.Value)
            fprOld.AnalysisGSBP.Value = fprNew.AnalysisGSBP.Value
        End If
        If fprOld.BDPointRecipe.AreaMax_GSBP.Value <> fprNew.BDPointRecipe.AreaMax_GSBP.Value Then
            dlm.WriteLog("< AreaMax_GSBP >: " & fprOld.BDPointRecipe.AreaMax_GSBP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_GSBP.Value)
            fprOld.BDPointRecipe.AreaMax_GSBP.Value = fprNew.BDPointRecipe.AreaMax_GSBP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_GSBP.Value <> fprNew.BDPointRecipe.AreaMin_GSBP.Value Then
            dlm.WriteLog("< AreaMin_GSBP >: " & fprOld.BDPointRecipe.AreaMin_GSBP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_GSBP.Value)
            fprOld.BDPointRecipe.AreaMin_GSBP.Value = fprNew.BDPointRecipe.AreaMin_GSBP.Value
        End If
        If fprOld.BDPointRecipe.GSBP_Count_Min.Value <> fprNew.BDPointRecipe.GSBP_Count_Min.Value Then
            dlm.WriteLog("< GSBP_Count_Min >: " & fprOld.BDPointRecipe.GSBP_Count_Min.Value & " --> " & fprNew.BDPointRecipe.GSBP_Count_Min.Value)
            fprOld.BDPointRecipe.GSBP_Count_Min.Value = fprNew.BDPointRecipe.GSBP_Count_Min.Value
        End If
        If fprOld.BDPointRecipe.GSBP_RangeX.Value <> fprNew.BDPointRecipe.GSBP_RangeX.Value Then
            dlm.WriteLog("< GSBP_RangeX >: " & fprOld.BDPointRecipe.GSBP_RangeX.Value & " --> " & fprNew.BDPointRecipe.GSBP_RangeX.Value)
            fprOld.BDPointRecipe.GSBP_RangeX.Value = fprNew.BDPointRecipe.GSBP_RangeX.Value
        End If
        If fprOld.BDPointRecipe.GSBP_RangeY.Value <> fprNew.BDPointRecipe.GSBP_RangeY.Value Then
            dlm.WriteLog("< GSBP_RangeY >: " & fprOld.BDPointRecipe.GSBP_RangeY.Value & " --> " & fprNew.BDPointRecipe.GSBP_RangeY.Value)
            fprOld.BDPointRecipe.GSBP_RangeY.Value = fprNew.BDPointRecipe.GSBP_RangeY.Value
        End If
        If fprOld.BDPointRecipe.GSBP_Scratch_Length.Value <> fprNew.BDPointRecipe.GSBP_Scratch_Length.Value Then
            dlm.WriteLog("< GSBP_Scratch_Length >: " & fprOld.BDPointRecipe.GSBP_Scratch_Length.Value & " --> " & fprNew.BDPointRecipe.GSBP_Scratch_Length.Value)
            fprOld.BDPointRecipe.GSBP_Scratch_Length.Value = fprNew.BDPointRecipe.GSBP_Scratch_Length.Value
        End If

        '--- BLDP ---
        If fprOld.BDPointRecipe.Threshold_BLDP.Value <> fprNew.BDPointRecipe.Threshold_BLDP.Value Then
            dlm.WriteLog("< Threshold_BLDP >: " & fprOld.BDPointRecipe.Threshold_BLDP.Value & " --> " & fprNew.BDPointRecipe.Threshold_BLDP.Value)
            fprOld.BDPointRecipe.Threshold_BLDP.Value = fprNew.BDPointRecipe.Threshold_BLDP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_BLDP.Value <> fprNew.BDPointRecipe.ThresholdRim_BLDP.Value Then
            dlm.WriteLog("< ThresholdRim_BLDP >: " & fprOld.BDPointRecipe.ThresholdRim_BLDP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_BLDP.Value)
            fprOld.BDPointRecipe.ThresholdRim_BLDP.Value = fprNew.BDPointRecipe.ThresholdRim_BLDP.Value
        End If

        If fprOld.AnalysisBLDP.Value <> fprNew.AnalysisBLDP.Value Then
            dlm.WriteLog("< AnalysisBLDP >: " & fprOld.AnalysisBLDP.Value & " --> " & fprNew.AnalysisBLDP.Value)
            fprOld.AnalysisBLDP.Value = fprNew.AnalysisBLDP.Value
        End If
        If fprOld.BDPointRecipe.AreaMax_BLDP.Value <> fprNew.BDPointRecipe.AreaMax_BLDP.Value Then
            dlm.WriteLog("< AreaMax_BLDP >: " & fprOld.BDPointRecipe.AreaMax_BLDP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_BLDP.Value)
            fprOld.BDPointRecipe.AreaMax_BLDP.Value = fprNew.BDPointRecipe.AreaMax_BLDP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_BLDP.Value <> fprNew.BDPointRecipe.AreaMin_BLDP.Value Then
            dlm.WriteLog("< AreaMin_BLDP >: " & fprOld.BDPointRecipe.AreaMin_BLDP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_BLDP.Value)
            fprOld.BDPointRecipe.AreaMin_BLDP.Value = fprNew.BDPointRecipe.AreaMin_BLDP.Value
        End If
        If fprOld.BDPointRecipe.BLDP_Count_Min.Value <> fprNew.BDPointRecipe.BLDP_Count_Min.Value Then
            dlm.WriteLog("< BLDP_Count_Min >: " & fprOld.BDPointRecipe.BLDP_Count_Min.Value & " --> " & fprNew.BDPointRecipe.BLDP_Count_Min.Value)
            fprOld.BDPointRecipe.BLDP_Count_Min.Value = fprNew.BDPointRecipe.BLDP_Count_Min.Value
        End If
        If fprOld.BDPointRecipe.BLDP_RangeX.Value <> fprNew.BDPointRecipe.BLDP_RangeX.Value Then
            dlm.WriteLog("< BLDP_RangeX >: " & fprOld.BDPointRecipe.BLDP_RangeX.Value & " --> " & fprNew.BDPointRecipe.BLDP_RangeX.Value)
            fprOld.BDPointRecipe.BLDP_RangeX.Value = fprNew.BDPointRecipe.BLDP_RangeX.Value
        End If
        If fprOld.BDPointRecipe.BLDP_RangeY.Value <> fprNew.BDPointRecipe.BLDP_RangeY.Value Then
            dlm.WriteLog("< BLDP_RangeY >: " & fprOld.BDPointRecipe.BLDP_RangeY.Value & " --> " & fprNew.BDPointRecipe.BLDP_RangeY.Value)
            fprOld.BDPointRecipe.BLDP_RangeY.Value = fprNew.BDPointRecipe.BLDP_RangeY.Value
        End If
        If fprOld.BDPointRecipe.BLDP_Scratch_Length.Value <> fprNew.BDPointRecipe.BLDP_Scratch_Length.Value Then
            dlm.WriteLog("< BLDP_Scratch_Length >: " & fprOld.BDPointRecipe.BLDP_Scratch_Length.Value & " --> " & fprNew.BDPointRecipe.BLDP_Scratch_Length.Value)
            fprOld.BDPointRecipe.BLDP_Scratch_Length.Value = fprNew.BDPointRecipe.BLDP_Scratch_Length.Value
        End If
        If fprOld.BDPointRecipe.BLDP_Fatness_Min.Value <> fprNew.BDPointRecipe.BLDP_Fatness_Min.Value Then
            dlm.WriteLog("< BLDP_Fatness_Min >: " & fprOld.BDPointRecipe.BLDP_Fatness_Min.Value & " --> " & fprNew.BDPointRecipe.BLDP_Fatness_Min.Value)
            fprOld.BDPointRecipe.BLDP_Fatness_Min.Value = fprNew.BDPointRecipe.BLDP_Fatness_Min.Value
        End If

        '--- 第四頁 ---
        If fprOld.GrayAbnormalEnable.Value <> fprNew.GrayAbnormalEnable.Value Then
            dlm.WriteLog("< GrayAbnormalEnable >: " & fprOld.GrayAbnormalEnable.Value & " --> " & fprNew.GrayAbnormalEnable.Value)
            fprOld.GrayAbnormalEnable.Value = fprNew.GrayAbnormalEnable.Value
        End If
        If fprOld.DisplayMeanOffsetRecipe.PosLimit.Value <> fprNew.DisplayMeanOffsetRecipe.PosLimit.Value Then
            dlm.WriteLog("< GrayAbnormal PosLimit >: " & fprOld.DisplayMeanOffsetRecipe.PosLimit.Value & " --> " & fprNew.DisplayMeanOffsetRecipe.PosLimit.Value)
            fprOld.DisplayMeanOffsetRecipe.PosLimit = fprNew.DisplayMeanOffsetRecipe.PosLimit
        End If
        If fprOld.DisplayMeanOffsetRecipe.NegLimit.Value <> fprNew.DisplayMeanOffsetRecipe.NegLimit.Value Then   '2009/09/21 Rick add
            dlm.WriteLog("< GrayAbnormal NegLimit >: " & fprOld.DisplayMeanOffsetRecipe.NegLimit.Value & " --> " & fprNew.DisplayMeanOffsetRecipe.NegLimit.Value)
            fprOld.DisplayMeanOffsetRecipe.NegLimit = fprNew.DisplayMeanOffsetRecipe.NegLimit
        End If
        If fprOld.DisplayMeanOffsetRecipe.StandardGray.Value <> fprNew.DisplayMeanOffsetRecipe.StandardGray.Value Then
            dlm.WriteLog("< GrayAbnormal StandardGray >: " & fprOld.DisplayMeanOffsetRecipe.StandardGray.Value & " --> " & fprNew.DisplayMeanOffsetRecipe.StandardGray.Value)
            fprOld.DisplayMeanOffsetRecipe.StandardGray = fprNew.DisplayMeanOffsetRecipe.StandardGray
        End If

        '--- 第五頁 ---
        If fprOld.AutoExposure_Kp.Value <> fprNew.AutoExposure_Kp.Value Then
            dlm.WriteLog("< AutoExposure_Kp >: " & fprOld.AutoExposure_Kp.Value & " --> " & fprNew.AutoExposure_Kp.Value)
            fprOld.AutoExposure_Kp.Value = fprNew.AutoExposure_Kp.Value
        End If
        If fprOld.AutoExposure_LargeErrorRange_UL.Value <> fprNew.AutoExposure_LargeErrorRange_UL.Value Then
            dlm.WriteLog("< AutoExposure_LargeErrorRange_UL >: " & fprOld.AutoExposure_LargeErrorRange_UL.Value & " --> " & fprNew.AutoExposure_LargeErrorRange_UL.Value)
            fprOld.AutoExposure_LargeErrorRange_UL.Value = fprNew.AutoExposure_LargeErrorRange_UL.Value
        End If
        If fprOld.AutoExposure_LargeErrorRange_DL.Value <> fprNew.AutoExposure_LargeErrorRange_DL.Value Then
            dlm.WriteLog("< AutoExposure_LargeErrorRange_DL >: " & fprOld.AutoExposure_LargeErrorRange_DL.Value & " --> " & fprNew.AutoExposure_LargeErrorRange_DL.Value)
            fprOld.AutoExposure_LargeErrorRange_DL.Value = fprNew.AutoExposure_LargeErrorRange_DL.Value
        End If
        If fprOld.AutoExposure_SmallErrorRange.Value <> fprNew.AutoExposure_SmallErrorRange.Value Then
            dlm.WriteLog("< AutoExposure_SmallErrorRange >: " & fprOld.AutoExposure_SmallErrorRange.Value & " --> " & fprNew.AutoExposure_SmallErrorRange.Value)
            fprOld.AutoExposure_SmallErrorRange.Value = fprNew.AutoExposure_SmallErrorRange.Value
        End If
        If fprOld.AutoExposure_TargetMean.Value <> fprNew.AutoExposure_TargetMean.Value Then
            dlm.WriteLog("< AutoExposure_TargetMean >: " & fprOld.AutoExposure_TargetMean.Value & " --> " & fprNew.AutoExposure_TargetMean.Value)
            fprOld.AutoExposure_TargetMean.Value = fprNew.AutoExposure_TargetMean.Value
        End If

        '--- 第六頁 ---
        If fprOld.PointAlgorithm.Value <> fprOld.PointAlgorithm.Value Then
            dlm.WriteLog("< Point Algorithm >: " & fprOld.PointAlgorithm.Value & " --> " & fprOld.PointAlgorithm.Value)
            fprOld.PointAlgorithm.Value = fprOld.PointAlgorithm.Value
        End If

    End Sub

    Private Sub Compare(ByVal fmrOld As ClsFuncModelRecipe, ByVal fmrNew As ClsFuncModelRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[FuncModelRecipe]************************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        '--- 第五頁 ---
        If fmrOld.Point_PitchX.Value <> fmrNew.Point_PitchX.Value Then
            dlm.WriteLog("< Point Pitch X >: " & fmrOld.Point_PitchX.Value & " --> " & fmrNew.Point_PitchX.Value)
            fmrOld.Point_PitchX.Value = fmrNew.Point_PitchX.Value
        End If
        If fmrOld.Point_PitchY.Value <> fmrNew.Point_PitchY.Value Then
            dlm.WriteLog("< Point Pitch Y >: " & fmrOld.Point_PitchY.Value & " --> " & fmrNew.Point_PitchY.Value)
            fmrOld.Point_PitchY.Value = fmrNew.Point_PitchY.Value
        End If
        If fmrOld.Line_PitchX.Value <> fmrNew.Line_PitchX.Value Then
            dlm.WriteLog("< Line Pitch X >: " & fmrOld.Line_PitchX.Value & " --> " & fmrNew.Line_PitchX.Value)
            fmrOld.Line_PitchX.Value = fmrNew.Line_PitchX.Value
        End If
        If fmrOld.Line_PitchY.Value <> fmrNew.Line_PitchY.Value Then
            dlm.WriteLog("< Line Pitch Y >: " & fmrOld.Line_PitchY.Value & " --> " & fmrNew.Line_PitchY.Value)
            fmrOld.Line_PitchY.Value = fmrNew.Line_PitchY.Value
        End If
        If fmrOld.Average_Filter.Value <> fmrNew.Average_Filter.Value Then
            dlm.WriteLog("< Average_Filter >: " & fmrOld.Average_Filter.Value & " --> " & fmrNew.Average_Filter.Value)
            fmrOld.Average_Filter.Value = fmrNew.Average_Filter.Value
        End If

        If fmrOld.FuncRawDataFilterMura_Enable.Value <> fmrNew.FuncRawDataFilterMura_Enable.Value Then
            dlm.WriteLog("< FuncRawDataFilterMura_Enable >: " & fmrOld.FuncRawDataFilterMura_Enable.Value & " --> " & fmrNew.FuncRawDataFilterMura_Enable.Value)
            fmrOld.FuncRawDataFilterMura_Enable.Value = fmrNew.FuncRawDataFilterMura_Enable.Value
        End If
    End Sub

#End Region

#Region "--- Button_Enable ---"

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_LoadImage.Enabled = En
        Me.Button_Save.Enabled = En
        Me.ComboBox_Pattern.Enabled = En
    End Sub
#End Region

#Region "--- Button_PLMark_Enable ---"
    Private Sub Button_PLMark_Enable(ByVal En As Boolean)
        Button_Enable(En)
        Me.Button_PLMark_PatTest.Enabled = En
        Me.Button_Save_PLMark.Enabled = En
    End Sub
#End Region

#Region "--- Button_TPMark_Enable ---"
    Private Sub Button_TPMark_Enable(ByVal En As Boolean)
        Button_Enable(En)
        Me.Button_TPMark_PatTest.Enabled = En
        Me.Button_Save_TPMark.Enabled = En
    End Sub
#End Region

#End Region

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim fpr As ClsFuncPatternRecipe
        Dim fmr As ClsFuncModelRecipe
        Dim PL_mmr As ClsPLMarkModelRecipe
        Dim TP_mmr As ClsTPMarkModelRecipe
        Dim GrayLevel_Maximum As Double
        Dim FuncUpdateDataLog As String

        Try
            FuncUpdateDataLog = ""

            fmr = Me.m_FuncProcess.FuncModelRecipe
            fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
            PL_mmr = Me.m_FuncProcess.PLMarkModelRecipe
            TP_mmr = Me.m_FuncProcess.TPMarkModelRecipe

            If fmr.PointAlgorithm.Value = 2 Then
                GrayLevel_Maximum = 20000  '原1000 ,改20000 For Test , 2012/11/26 Rick modify
            Else
                GrayLevel_Maximum = (2 ^ Me.m_IPBootConfig.Digitizer_Datadepth.Value - 1) * 10
            End If

            If Not fpr Is Nothing Then
                Me.Text = "[Func]影像处理参数调整 [ Pattern：" & Me.m_Form.ComboBox_Pattern_MainFrm.Text & " ]"

                '--- BDPoint Setting (第一頁) ---------------------
                If (fpr.AnalysisBP.Value = True And fpr.AnalysisDP.Value = False) Then
                    Me.RadioButton_BP.Checked = True
                    Me.RadioButton_DP.Checked = False
                    Me.GroupBox_DPoint.Enabled = False
                ElseIf (fpr.AnalysisDP.Value = True And fpr.AnalysisBP.Value = False) Then
                    Me.RadioButton_DP.Checked = True
                    Me.RadioButton_BP.Checked = False
                    Me.GroupBox_BPoint.Enabled = False
                ElseIf (fpr.AnalysisBP.Value = True And fpr.AnalysisDP.Value = True) Then
                    Me.RadioButton_BPDP.Checked = True
                Else
                    Me.RadioButton_BP.Checked = False
                    Me.RadioButton_DP.Checked = False
                End If

                '--- Tool ---
                '[1] Inverse Point Type & Fix Area ---
                Me.CheckBox_Inverse_Point_DefectType.Checked = fpr.BDPointRecipe.Inverse_PointDefectType.Value
                Me.CheckBox_Inverse_Point_EnableFixArea.Checked = fpr.BDPointRecipe.Inverse_Point_EnableFixArea.Value
                Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value = fpr.BDPointRecipe.Inverse_PointFixArea.Value
                Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Enabled = Me.CheckBox_Inverse_Point_EnableFixArea.Checked

                '--- DP Recipe ---
                If Me.NumericUpDown_DP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_DP.Value Then Me.NumericUpDown_DP_Threshold.Value = fpr.BDPointRecipe.Threshold_DP.Value Else FuncUpdateDataLog &= "[Point] DPoint Threshold High 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_DP_Threshold_Low.Maximum >= fpr.BDPointRecipe.Threshold_DP_Low.Value Then Me.NumericUpDown_DP_Threshold_Low.Value = fpr.BDPointRecipe.Threshold_DP_Low.Value Else FuncUpdateDataLog &= "[Point] DPoint Threshold Low 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_DP_RimThreshold.Maximum >= fpr.BDPointRecipe.ThresholdRim_DP.Value Then Me.NumericUpDown_DP_RimThreshold.Value = fpr.BDPointRecipe.ThresholdRim_DP.Value Else FuncUpdateDataLog &= "[Point] DPoint Boundary Threshold High 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_DP_RimThreshold_Low.Maximum >= fpr.BDPointRecipe.ThresholdRim_DP_Low.Value Then Me.NumericUpDown_DP_RimThreshold_Low.Value = fpr.BDPointRecipe.ThresholdRim_DP_Low.Value Else FuncUpdateDataLog &= "[Point] DPoint Boundary Threshold Low 設定超出範圍" & vbCrLf

                Me.NumericUpDown_DP_Threshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_DP_Threshold_Low.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_DP_RimThreshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_DP_RimThreshold_Low.Maximum = GrayLevel_Maximum

                '--- Waku Recipe ---
                Me.NumericUpDown_WakuSplitNum.Value = fpr.WakuSplitNum.Value
                Me.NumericUpDown_WakuEdgeWidth.Value = fpr.WakuEdgeWidth.Value
                Me.NumericUpDown_WakuEdgeOffset.Value = fpr.WakuEdgeOffset.Value

                '--- BP Recipe ---
                If Me.NumericUpDown_BP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_BP.Value Then Me.NumericUpDown_BP_Threshold.Value = fpr.BDPointRecipe.Threshold_BP.Value Else FuncUpdateDataLog &= "[Point] BPoint Threshold 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_BP_Threshold_Low.Maximum >= fpr.BDPointRecipe.Threshold_BP_Low.Value Then Me.NumericUpDown_BP_Threshold_Low.Value = fpr.BDPointRecipe.Threshold_BP_Low.Value Else FuncUpdateDataLog &= "[Point] BPoint Threshold Low 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_BP_RimThreshold.Maximum >= fpr.BDPointRecipe.ThresholdRim_BP.Value Then NumericUpDown_BP_RimThreshold.Value = fpr.BDPointRecipe.ThresholdRim_BP.Value Else FuncUpdateDataLog &= "[Point] BPoint Boundary Threshold 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_BP_RimThreshold_Low.Maximum >= fpr.BDPointRecipe.ThresholdRim_BP_Low.Value Then Me.NumericUpDown_BP_RimThreshold_Low.Value = fpr.BDPointRecipe.ThresholdRim_BP_Low.Value Else FuncUpdateDataLog &= "[Point] BPoint Boundary Threshold Low 設定超出範圍" & vbCrLf

                Me.NumericUpDown_BP_Threshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_BP_RimThreshold.Maximum = GrayLevel_Maximum

                '---Separate BP---
                Me.CheckBox_SeparateBPEnable.Checked = fpr.SeparateBPEnable.Value
                Me.NumericUpDown_SeparateBPArea.Value = fpr.SeparateBPArea.Value
                Me.NumericUpDown_SeparateBPBlob.Value = fpr.SeparateBPBlob.Value

                '--- BDPoint - Common setting ---
                If NumericUpDown_BP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_BP.Value Then NumericUpDown_BP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_BP.Value Else FuncUpdateDataLog &= "[Common] BP AreaMax 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_BP.Value Then NumericUpDown_BP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_BP.Value Else FuncUpdateDataLog &= "[Common] BP AreaMin 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_DP.Value Then NumericUpDown_DP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_DP.Value Else FuncUpdateDataLog &= "[Common] DP AreaMax 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_DP.Value Then NumericUpDown_DP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_DP.Value Else FuncUpdateDataLog &= "[Common] DP AreaMin 設定超出範圍" & vbCrLf

                If NumericUpDown_Point_ByPassX.Maximum >= fpr.BDPointRecipe.BypassX.Value Then NumericUpDown_Point_ByPassX.Value = fpr.BDPointRecipe.BypassX.Value Else FuncUpdateDataLog &= "[Common] BypassX設定超出範圍" & vbCrLf
                If NumericUpDown_Point_ByPassY.Maximum >= fpr.BDPointRecipe.BypassY.Value Then NumericUpDown_Point_ByPassY.Value = fpr.BDPointRecipe.BypassY.Value Else FuncUpdateDataLog &= "[Common] BypassY設定超出範圍" & vbCrLf
                If NumericUpDown_Point_OverNum.Maximum >= fpr.BDPointRecipe.OverNum.Value Then NumericUpDown_Point_OverNum.Value = fpr.BDPointRecipe.OverNum.Value Else FuncUpdateDataLog &= "[Common] OverNum設定超出範圍" & vbCrLf

                CheckBox_EnableLeakPoint.Checked = fpr.BDPointRecipe.EnableLeakPoint.Value

                '--- Point Characteristics (第二頁) -------------------------
                '--- BP ---
                If NumericUpDown_BP_Elongation_Min.Maximum >= fpr.BDPointRecipe.Elongation_Min.Value Then NumericUpDown_BP_Elongation_Min.Value = fpr.BDPointRecipe.Elongation_Min.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Elongation Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_Elongation_Max.Maximum >= fpr.BDPointRecipe.Elongation_Max.Value Then NumericUpDown_BP_Elongation_Max.Value = fpr.BDPointRecipe.Elongation_Max.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Elongation Max 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_Fullness_Min.Maximum >= fpr.BDPointRecipe.Fullness_Min.Value Then NumericUpDown_BP_Fullness_Min.Value = fpr.BDPointRecipe.Fullness_Min.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Fullness Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_Fullness_Max.Maximum >= fpr.BDPointRecipe.Fullness_Max.Value Then NumericUpDown_BP_Fullness_Max.Value = fpr.BDPointRecipe.Fullness_Max.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Fullness Max 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_MaxGray_Fullness_Min.Maximum >= fpr.BDPointRecipe.MaxGray_Fullness_Min.Value Then NumericUpDown_BP_MaxGray_Fullness_Min.Value = fpr.BDPointRecipe.MaxGray_Fullness_Min.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP MaxGray_Fullness Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_GrayMean_Min.Maximum >= fpr.BDPointRecipe.GrayMean_Min_BP.Value Then NumericUpDown_BP_GrayMean_Min.Value = fpr.BDPointRecipe.GrayMean_Min_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP GrayMean Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_MaxGray_Min.Maximum >= fpr.BDPointRecipe.MaxGray_Min_BP.Value Then NumericUpDown_BP_MaxGray_Min.Value = fpr.BDPointRecipe.MaxGray_Min_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP MaxGray Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_MaxGray_Max.Maximum >= fpr.BDPointRecipe.MaxGray_Max_BP.Value Then NumericUpDown_BP_MaxGray_Max.Value = fpr.BDPointRecipe.MaxGray_Max_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP MaxGray Max 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_Compactness_Max.Maximum >= fpr.BDPointRecipe.Compactness_Max_BP.Value Then NumericUpDown_BP_Compactness_Max.Value = fpr.BDPointRecipe.Compactness_Max_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Compactness Max 設定超出範圍" & vbCrLf
                If NumericUpDown_BP_StdDev_Max.Maximum >= fpr.BDPointRecipe.StdDev_Max_BP.Value Then NumericUpDown_BP_StdDev_Max.Value = fpr.BDPointRecipe.StdDev_Max_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP StdDev Max 設定超出範圍" & vbCrLf

                '--- DP ---
                If NumericUpDown_DP_Elongation_Min.Maximum >= fpr.BDPointRecipe.Elongation_Min_DP.Value Then NumericUpDown_DP_Elongation_Min.Value = fpr.BDPointRecipe.Elongation_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Elongation Min 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_Elongation_Max.Maximum >= fpr.BDPointRecipe.Elongation_Max_DP.Value Then NumericUpDown_DP_Elongation_Max.Value = fpr.BDPointRecipe.Elongation_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Elongation Max 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_Fullness_Min.Maximum >= fpr.BDPointRecipe.Fullness_Min_DP.Value Then NumericUpDown_DP_Fullness_Min.Value = fpr.BDPointRecipe.Fullness_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Fullness Min 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_Fullness_Max.Maximum >= fpr.BDPointRecipe.Fullness_Max_DP.Value Then NumericUpDown_DP_Fullness_Max.Value = fpr.BDPointRecipe.Fullness_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Fullness Max 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_MaxGray_Fullness_Min.Maximum >= fpr.BDPointRecipe.MaxGray_Fullness_Min_DP.Value Then NumericUpDown_DP_MaxGray_Fullness_Min.Value = fpr.BDPointRecipe.MaxGray_Fullness_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP MaxGray_Fullness Min 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_GrayMean_Max.Maximum >= fpr.BDPointRecipe.GrayMean_Max_DP.Value Then NumericUpDown_DP_GrayMean_Max.Value = fpr.BDPointRecipe.GrayMean_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP GrayMean Max 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_MinGray_Min.Maximum >= fpr.BDPointRecipe.MinGray_Min_DP.Value Then NumericUpDown_DP_MinGray_Min.Value = fpr.BDPointRecipe.MinGray_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP MinGray Min 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_MinGray_Max.Maximum >= fpr.BDPointRecipe.MinGray_Max_DP.Value Then NumericUpDown_DP_MinGray_Max.Value = fpr.BDPointRecipe.MinGray_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP MinGray Max 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_Compactness_Max.Maximum >= fpr.BDPointRecipe.Compactness_Max_DP.Value Then NumericUpDown_DP_Compactness_Max.Value = fpr.BDPointRecipe.Compactness_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Compactness Max 設定超出範圍" & vbCrLf
                If NumericUpDown_DP_StdDev_Max.Maximum >= fpr.BDPointRecipe.StdDev_Max_DP.Value Then NumericUpDown_DP_StdDev_Max.Value = fpr.BDPointRecipe.StdDev_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP StdDev Max 設定超出範圍" & vbCrLf

                '--- GSBDP Recipe (第三頁) -------------------------
                '--- GSBP ---
                If Me.NumericUpDown_GSBP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_GSBP.Value Then Me.NumericUpDown_GSBP_Threshold.Value = fpr.BDPointRecipe.Threshold_GSBP.Value Else FuncUpdateDataLog &= "[GSBP] GSBP Threshold 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_GSBP_ThresholdRim.Maximum >= fpr.BDPointRecipe.ThresholdRim_GSBP.Value Then Me.NumericUpDown_GSBP_ThresholdRim.Value = fpr.BDPointRecipe.ThresholdRim_GSBP.Value Else FuncUpdateDataLog &= "[GSBP] GSBP Threshold Rim 設定超出範圍" & vbCrLf

                Me.NumericUpDown_GSBP_Threshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_GSBP_ThresholdRim.Maximum = GrayLevel_Maximum

                '--- GSBP - Common setting ---
                If NumericUpDown_GSBP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_GSBP.Value Then NumericUpDown_GSBP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_GSBP.Value Else FuncUpdateDataLog &= "[Common] GSBP AreaMax 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_GSBP.Value Then NumericUpDown_GSBP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_GSBP.Value Else FuncUpdateDataLog &= "[Common] GSBP AreaMin 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_Count_Min.Maximum >= fpr.BDPointRecipe.GSBP_Count_Min.Value Then NumericUpDown_GSBP_Count_Min.Value = fpr.BDPointRecipe.GSBP_Count_Min.Value Else FuncUpdateDataLog &= "[Common] GSBP_Count_Min 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_RangeX.Maximum >= fpr.BDPointRecipe.GSBP_RangeX.Value Then NumericUpDown_GSBP_RangeX.Value = fpr.BDPointRecipe.GSBP_RangeX.Value Else FuncUpdateDataLog &= "[Common] GSBP_RangeX 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_RangeY.Maximum >= fpr.BDPointRecipe.GSBP_RangeY.Value Then NumericUpDown_GSBP_RangeY.Value = fpr.BDPointRecipe.GSBP_RangeY.Value Else FuncUpdateDataLog &= "[Common] GSBP_RangeY 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_Scratch_Length.Maximum >= fpr.BDPointRecipe.GSBP_Scratch_Length.Value Then NumericUpDown_GSBP_Scratch_Length.Value = fpr.BDPointRecipe.GSBP_Scratch_Length.Value Else FuncUpdateDataLog &= "[Common] GSBP_Scratch_Length 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_OverNum.Maximum >= fpr.BDPointRecipe.GSBP_OverNum.Value Then NumericUpDown_GSBP_OverNum.Value = fpr.BDPointRecipe.GSBP_OverNum.Value Else FuncUpdateDataLog &= "[Common] GSBP_OverNum 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_NumOfHoles.Maximum >= fpr.BDPointRecipe.GSBP_NumOfHoles.Value Then NumericUpDown_GSBP_NumOfHoles.Value = fpr.BDPointRecipe.GSBP_NumOfHoles.Value Else FuncUpdateDataLog &= "[Common] GSBP_NumOfHoles 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_GrayMax_High.Maximum >= fpr.BDPointRecipe.GSBP_GrayMax_High.Value Then NumericUpDown_GSBP_GrayMax_High.Value = fpr.BDPointRecipe.GSBP_GrayMax_High.Value Else FuncUpdateDataLog &= "[Common] GSBP_GrayMax_High 設定超出範圍" & vbCrLf
                If NumericUpDown_GSBP_GrayMax_Low.Maximum >= fpr.BDPointRecipe.GSBP_GrayMax_Low.Value Then NumericUpDown_GSBP_GrayMax_Low.Value = fpr.BDPointRecipe.GSBP_GrayMax_Low.Value Else FuncUpdateDataLog &= "[Common] GSBP_GrayMax_Low 設定超出範圍" & vbCrLf

                '--- BLDP ---
                If Me.NumericUpDown_BLDP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_BLDP.Value Then Me.NumericUpDown_BLDP_Threshold.Value = fpr.BDPointRecipe.Threshold_BLDP.Value Else FuncUpdateDataLog &= "[BLDP] BLDP Threshold 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_BLDP_ThresholdRim.Maximum >= fpr.BDPointRecipe.ThresholdRim_BLDP.Value Then Me.NumericUpDown_BLDP_ThresholdRim.Value = fpr.BDPointRecipe.ThresholdRim_BLDP.Value Else FuncUpdateDataLog &= "[BLDP] BLDP Threshold Rim 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_BLDP_EnhanceCount.Maximum >= fpr.BDPointRecipe.EnhanceCount_BLDP.Value Then Me.NumericUpDown_BLDP_EnhanceCount.Value = fpr.BDPointRecipe.EnhanceCount_BLDP.Value Else FuncUpdateDataLog &= "[BLDP] BLDP Enhance Count 設定超出範圍" & vbCrLf

                Me.NumericUpDown_BLDP_Threshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_BLDP_ThresholdRim.Maximum = GrayLevel_Maximum

                '--- BLDP - Common setting ---
                If NumericUpDown_BLDP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_BLDP.Value Then NumericUpDown_BLDP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP AreaMax 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_BLDP.Value Then NumericUpDown_BLDP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP AreaMin 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_Count_Min.Maximum >= fpr.BDPointRecipe.BLDP_Count_Min.Value Then NumericUpDown_BLDP_Count_Min.Value = fpr.BDPointRecipe.BLDP_Count_Min.Value Else FuncUpdateDataLog &= "[Common] BLDP_Count_Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_RangeX.Maximum >= fpr.BDPointRecipe.BLDP_RangeX.Value Then NumericUpDown_BLDP_RangeX.Value = fpr.BDPointRecipe.BLDP_RangeX.Value Else FuncUpdateDataLog &= "[Common] BLDP_RangeX 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_RangeY.Maximum >= fpr.BDPointRecipe.BLDP_RangeY.Value Then NumericUpDown_BLDP_RangeY.Value = fpr.BDPointRecipe.BLDP_RangeY.Value Else FuncUpdateDataLog &= "[Common] BLDP_RangeY 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_Scratch_Length.Maximum >= fpr.BDPointRecipe.BLDP_Scratch_Length.Value Then NumericUpDown_BLDP_Scratch_Length.Value = fpr.BDPointRecipe.BLDP_Scratch_Length.Value Else FuncUpdateDataLog &= "[Common] BLDP_Scratch_Length 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_OverNum.Maximum >= fpr.BDPointRecipe.BLDP_OverNum.Value Then NumericUpDown_BLDP_OverNum.Value = fpr.BDPointRecipe.BLDP_OverNum.Value Else FuncUpdateDataLog &= "[Common] BLDP_OverNum 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_Fatness_Min.Maximum >= fpr.BDPointRecipe.BLDP_Fatness_Min.Value Then NumericUpDown_BLDP_Fatness_Min.Value = fpr.BDPointRecipe.BLDP_Fatness_Min.Value Else FuncUpdateDataLog &= "[Common] BLDP_Fatness_Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_Elongation_Min.Maximum >= fpr.BDPointRecipe.Elongation_Min_BLDP.Value Then NumericUpDown_BLDP_Elongation_Min.Value = fpr.BDPointRecipe.Elongation_Min_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP_Elongation_Min 設定超出範圍" & vbCrLf
                If NumericUpDown_BLDP_Elongation_Max.Maximum >= fpr.BDPointRecipe.Elongation_Max_BLDP.Value Then NumericUpDown_BLDP_Elongation_Max.Value = fpr.BDPointRecipe.Elongation_Max_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP_Elongation_Max 設定超出範圍" & vbCrLf

                '--- Line Recipe (第四頁) -------------------------
                Me.CheckBox_BLine_Enable.Checked = fpr.LineFinderRecipe.AnalysisBL.Value
                Me.CheckBox_DLine_Enable.Checked = fpr.LineFinderRecipe.AnalysisDL.Value
                If Me.NumericUpDown_BL_Threshold.Maximum >= fpr.LineFinderRecipe.Threshold_BL.Value Then NumericUpDown_BL_Threshold.Value = fpr.LineFinderRecipe.Threshold_BL.Value Else FuncUpdateDataLog &= "[Line] Bright Line Threshold 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_BL_RimThreshold.Maximum >= fpr.LineFinderRecipe.ThresholdRim_BL.Value Then NumericUpDown_BL_RimThreshold.Value = fpr.LineFinderRecipe.ThresholdRim_BL.Value Else FuncUpdateDataLog &= "[Line] Bright Line Rim Threshold 設定超出範圍" & vbCrLf
                If Me.TrackBar_BL_Threshold.Maximum >= fpr.LineFinderRecipe.Threshold_BL.Value Then TrackBar_BL_Threshold.Value = fpr.LineFinderRecipe.Threshold_BL.Value Else FuncUpdateDataLog &= "[Line] Bright Line Threshold 設定超出範圍" & vbCrLf

                If Me.NumericUpDown_DL_Threshold.Maximum >= fpr.LineFinderRecipe.Threshold_DL.Value Then NumericUpDown_DL_Threshold.Value = fpr.LineFinderRecipe.Threshold_DL.Value Else FuncUpdateDataLog &= "[Line] Dark Line Threshold 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_DL_RimThreshold.Maximum >= fpr.LineFinderRecipe.ThresholdRim_DL.Value Then NumericUpDown_DL_RimThreshold.Value = fpr.LineFinderRecipe.ThresholdRim_DL.Value Else FuncUpdateDataLog &= "[Line] Dark Line Rim Threshold 設定超出範圍" & vbCrLf
                If Me.TrackBar_DL_Threshold.Maximum >= fpr.LineFinderRecipe.Threshold_DL.Value Then TrackBar_DL_Threshold.Value = fpr.LineFinderRecipe.Threshold_DL.Value Else FuncUpdateDataLog &= "[Line] Bright Line Threshold 設定超出範圍" & vbCrLf

                Me.NumericUpDown_DL_Threshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_BL_Threshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_DL_RimThreshold.Maximum = GrayLevel_Maximum
                Me.NumericUpDown_BL_RimThreshold.Maximum = GrayLevel_Maximum
                Me.TrackBar_DL_Threshold.Maximum = GrayLevel_Maximum
                Me.TrackBar_BL_Threshold.Maximum = GrayLevel_Maximum
                Me.TrackBar_DL_RimThreshold.Maximum = GrayLevel_Maximum
                Me.TrackBar_BL_RimThreshold.Maximum = GrayLevel_Maximum

                If NumericUpDown_Line_ByPassUpH.Maximum >= fpr.LineFinderRecipe.ByPassUpH.Value Then NumericUpDown_Line_ByPassUpH.Value = fpr.LineFinderRecipe.ByPassUpH.Value Else FuncUpdateDataLog &= "[Line] Line ByPassUpH設定超出範圍" & vbCrLf
                If NumericUpDown_Line_ByPassDownH.Maximum >= fpr.LineFinderRecipe.ByPassDownH.Value Then NumericUpDown_Line_ByPassDownH.Value = fpr.LineFinderRecipe.ByPassDownH.Value Else FuncUpdateDataLog &= "[Line] Line ByPassDownH設定超出範圍" & vbCrLf
                If NumericUpDown_Line_ByPassLeftV.Maximum >= fpr.LineFinderRecipe.ByPassLeftV.Value Then NumericUpDown_Line_ByPassLeftV.Value = fpr.LineFinderRecipe.ByPassLeftV.Value Else FuncUpdateDataLog &= "[Line] Line ByPassLeftV設定超出範圍" & vbCrLf
                If NumericUpDown_Line_ByPassRightV.Maximum >= fpr.LineFinderRecipe.ByPassRightV.Value Then NumericUpDown_Line_ByPassRightV.Value = fpr.LineFinderRecipe.ByPassRightV.Value Else FuncUpdateDataLog &= "[Line] Line ByPassRightV設定超出範圍" & vbCrLf
                If NumericUpDown_Line_Cut.Maximum >= fpr.LineFinderRecipe.Line_Cut.Value Then NumericUpDown_Line_Cut.Value = fpr.LineFinderRecipe.Line_Cut.Value Else FuncUpdateDataLog &= "[Line] Line Cut 設定超出範圍" & vbCrLf
                If fpr.LineFinderRecipe.Line_Cut_H.Value = 1 Then
                    fpr.LineFinderRecipe.Line_Cut_H.Value = fpr.LineFinderRecipe.Line_Cut.Value
                    NumericUpDown_Line_Cut_H.Value = fpr.LineFinderRecipe.Line_Cut.Value
                Else
                    NumericUpDown_Line_Cut_H.Value = fpr.LineFinderRecipe.Line_Cut_H.Value
                End If
                If fpr.LineFinderRecipe.Line_Short_Cut_H.Value = 0 Then
                    fpr.LineFinderRecipe.Line_Short_Cut_H.Value = fpr.LineFinderRecipe.Line_Short_Cut_H.Value
                    NumericUpDown_Line_Short_Cut_H.Value = fpr.LineFinderRecipe.Line_Short_Cut_H.Value
                Else
                    NumericUpDown_Line_Short_Cut_H.Value = fpr.LineFinderRecipe.Line_Short_Cut_H.Value
                End If
                If NumericUpDown_Line_Short_Cut.Maximum >= fpr.LineFinderRecipe.Line_Short_Cut.Value Then NumericUpDown_Line_Short_Cut.Value = fpr.LineFinderRecipe.Line_Short_Cut.Value Else FuncUpdateDataLog &= "[Line] Line Short Cut設定超出範圍" & vbCrLf
                If NumericUpDown_Line_OverNumber.Maximum >= fpr.LineFinderRecipe.LineOverNum.Value Then NumericUpDown_Line_OverNumber.Value = fpr.LineFinderRecipe.LineOverNum.Value Else FuncUpdateDataLog &= "[Line] Line Over Number設定超出範圍" & vbCrLf
                If NumericUpDown_Block_OverNumber.Maximum >= fpr.LineFinderRecipe.BlockOverNum.Value Then NumericUpDown_Block_OverNumber.Value = fpr.LineFinderRecipe.BlockOverNum.Value Else FuncUpdateDataLog &= "[Line] Block Over Number設定超出範圍" & vbCrLf
                If NumericUpDown_MeanDifference.Maximum >= fpr.LineFinderRecipe.Mean_Difference.Value Then NumericUpDown_MeanDifference.Value = fpr.LineFinderRecipe.Mean_Difference.Value Else FuncUpdateDataLog &= "[Line] Line Mean_Difference設定超出範圍" & vbCrLf
                If NumericUpDown_Line_Elongation_Min.Maximum >= fpr.LineFinderRecipe.Elongation_Min.Value Then NumericUpDown_Line_Elongation_Min.Value = fpr.LineFinderRecipe.Mean_Difference.Value Else FuncUpdateDataLog &= "[Line] Line Mean_Difference設定超出範圍" & vbCrLf

                Me.NumericUpDown_LeakPointRadius.Value = fpr.LineFinderRecipe.LeakPointRadius.Value

                '--- Gray Abnormal (第五頁) -----------------------
                Me.NumericUpDown_GrayAbnormal_PosLimit.Value = fpr.DisplayMeanOffsetRecipe.PosLimit.Value
                Me.NumericUpDown_GrayAbnormal_NegLimit.Value = fpr.DisplayMeanOffsetRecipe.NegLimit.Value
                Me.NumericUpDown_GrayAbnormalStandardGray.Value = fpr.DisplayMeanOffsetRecipe.StandardGray.Value
                Me.NumericUpDown_GrayAbnormal_NoDisplay.Value = fpr.DisplayMeanOffsetRecipe.NoDisplay.Value
                Me.Lbl_GrayAbnormal_PosLimit.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit.Value) / 100), "#"))
                Me.Lbl_GrayAbnormal_NegLimit.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit.Value) / 100), "#"))

                '--- Auto (第六頁) --------------------------------
                Me.NumericUpDown_AutoExposure_TargetMean.Maximum = GrayLevel_Maximum
                If Me.NumericUpDown_AutoExposure_Kp.Maximum >= fpr.AutoExposure_Kp.Value Then Me.NumericUpDown_AutoExposure_Kp.Value = fpr.AutoExposure_Kp.Value Else FuncUpdateDataLog &= "[Auto] Kp設定超出範圍： " & Me.NumericUpDown_AutoExposure_Kp.Maximum & vbCrLf
                If Me.NumericUpDown_AutoExposure_TargetMean.Maximum >= fpr.AutoExposure_TargetMean.Value Then Me.NumericUpDown_AutoExposure_TargetMean.Value = fpr.AutoExposure_TargetMean.Value Else FuncUpdateDataLog &= "[Auto] TargetMean設定超出範圍： " & Me.NumericUpDown_AutoExposure_TargetMean.Maximum & vbCrLf
                If Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum >= fpr.AutoExposure_LargeErrorRange_UL.Value Then Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value = fpr.AutoExposure_LargeErrorRange_UL.Value Else FuncUpdateDataLog &= "[Auto] LargeErrorRange_UL設定超出範圍： " & Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum & vbCrLf
                If Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum >= fpr.AutoExposure_LargeErrorRange_DL.Value Then Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value = fpr.AutoExposure_LargeErrorRange_DL.Value Else FuncUpdateDataLog &= "[Auto] LargeErrorRange_DL設定超出範圍： " & Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum & vbCrLf
                If Me.NumericUpDown_AutoExposure_SmallErrorRange.Maximum >= fpr.AutoExposure_SmallErrorRange.Value Then Me.NumericUpDown_AutoExposure_SmallErrorRange.Value = fpr.AutoExposure_SmallErrorRange.Value Else FuncUpdateDataLog &= "[Auto] SmallErrorRange設定超出範圍： " & Me.NumericUpDown_AutoExposure_SmallErrorRange.Maximum & vbCrLf
                If Me.NumericUpDown_AutoExposure_GrabDelayTime.Maximum >= fpr.AutoExposure_GrabDelayTime.Value Then Me.NumericUpDown_AutoExposure_GrabDelayTime.Value = fpr.AutoExposure_GrabDelayTime.Value Else FuncUpdateDataLog &= "[Auto] GrabDelayTime設定超出範圍： " & Me.NumericUpDown_AutoExposure_GrabDelayTime.Maximum & vbCrLf

                '-- Other (第七頁) --------------------------------
                '--- Point Pitch Setting ---
                If Me.NumericUpDown_Point_PitchX.Maximum >= fpr.Point_PitchX.Value Then Me.NumericUpDown_Point_PitchX.Value = fpr.Point_PitchX.Value Else FuncUpdateDataLog &= "Point PitchX 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_Point_PitchY.Maximum >= fpr.Point_PitchY.Value Then Me.NumericUpDown_Point_PitchY.Value = fpr.Point_PitchY.Value Else FuncUpdateDataLog &= "Point PitchY 設定超出範圍" & vbCrLf
                '--- Line Pitch Setting ---
                If Me.NumericUpDown_Line_PitchX.Maximum >= fpr.Line_PitchX.Value Then Me.NumericUpDown_Line_PitchX.Value = fpr.Line_PitchX.Value Else FuncUpdateDataLog &= "Line PitchX 設定超出範圍" & vbCrLf
                If Me.NumericUpDown_Line_PitchY.Maximum >= fpr.Line_PitchY.Value Then Me.NumericUpDown_Line_PitchY.Value = fpr.Line_PitchY.Value Else FuncUpdateDataLog &= "Line PitchY 設定超出範圍" & vbCrLf

                '--- Point\Line Average FIlter ---
                If Me.NumericUpDown_AverageFilter.Maximum >= fpr.Average_Filter.Value Then Me.NumericUpDown_AverageFilter.Value = fpr.Average_Filter.Value Else FuncUpdateDataLog &= "Average Pitch 設定超出範圍" & vbCrLf

                '--- Point Algorithm ---
                'Point Algorithm ---
                If fpr.PointAlgorithm.Value = 0 Then
                    Me.RadioButton_PointAlgorithm_0.Checked = True
                ElseIf fpr.PointAlgorithm.Value = 1 Then
                    Me.RadioButton_PointAlgorithm_1.Checked = True
                ElseIf fpr.PointAlgorithm.Value = 2 Then
                    Me.RadioButton_PointAlgorithm_2.Checked = True
                ElseIf fpr.PointAlgorithm.Value = 3 Then
                    Me.RadioButton_PointAlgorithm_3.Checked = True
                ElseIf fpr.PointAlgorithm.Value = 4 Then  'Circle ROI Image
                    Me.RadioButton_PointAlgorithm_4.Checked = True
                ElseIf fpr.PointAlgorithm.Value = 5 Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
                    Me.RadioButton_PointAlgorithm_5.Checked = True
                ElseIf fpr.PointAlgorithm.Value = 6 Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
                    Me.RadioButton_PointAlgorithm_6.Checked = True
                End If

                If fmr.AlignType.Value = AlignType.Rectangle Then
                    Me.RadioButton_PointAlgorithm_0.Enabled = True
                    Me.RadioButton_PointAlgorithm_1.Enabled = True
                    Me.RadioButton_PointAlgorithm_2.Enabled = True
                    Me.RadioButton_PointAlgorithm_3.Enabled = True
                    Me.RadioButton_PointAlgorithm_4.Enabled = False
                    Me.RadioButton_PointAlgorithm_5.Enabled = True
                    Me.RadioButton_PointAlgorithm_6.Enabled = False
                ElseIf fmr.AlignType.Value = AlignType.Circle Then
                    Me.RadioButton_PointAlgorithm_0.Enabled = False
                    Me.RadioButton_PointAlgorithm_1.Enabled = False
                    Me.RadioButton_PointAlgorithm_2.Enabled = False
                    Me.RadioButton_PointAlgorithm_3.Enabled = False
                    Me.RadioButton_PointAlgorithm_4.Enabled = True   'Circle Image
                    Me.RadioButton_PointAlgorithm_5.Enabled = False
                    Me.RadioButton_PointAlgorithm_6.Enabled = True   'Circle Image
                End If

                '--- Func Raw Data Filter Mura Setting ---
                Me.CheckBox_FuncRawDataFilterMura_Enable.Checked = fmr.FuncRawDataFilterMura_Enable.Value

                '--- Boundary Width ---
                Me.NumericUpDown_Boundary_MulWidth_LX.Value = fpr.Boundary_MulWidth_LX.Value
                Me.NumericUpDown_Boundary_MulWidth_RX.Value = fpr.Boundary_MulWidth_RX.Value
                Me.NumericUpDown_Boundary_MulWidth_TY.Value = fpr.Boundary_MulWidth_TY.Value
                Me.NumericUpDown_Boundary_MulWidth_BY.Value = fpr.Boundary_MulWidth_BY.Value

                '--- AI Setting ---
                Me.NumericUpDown_AiResizeX.Value = fmr.AiResizeX.Value
                Me.NumericUpDown_AiResizeY.Value = fmr.AiResizeY.Value
                Me.ComboBox_IsAISaveROI.Text = fmr.IsAISaveROI.Value

                '--- 第八頁(PL Mark) ---
                If Me.m_IPBootConfig.PLMarkUI.Value Then
                    If Not PL_mmr Is Nothing Then
                        Me.CheckBox_FillOfHole.Checked = PL_mmr.FillofHole
                        Me.NumericUpDown_SearchRange_PLMark_Multiple.Value = PL_mmr.SearchRange_PLMark_Multiple
                        Me.NumericUpDown_BlobArea.Value = PL_mmr.BlobArea
                        Me.NumericUpDown_SearchMarkCount.Value = PL_mmr.SearchMarkCount
                        Me.m_CurrentPLMarkIndex = 0
                        '--- Load Current Pattern ---
                        Me.Update_PLMark_Pattern(Me.m_CurrentPLMarkIndex, Me.m_FuncProcess.PLMarkModelRecipe)
                    Else
                        Me.m_FuncProcess.PLMarkModelRecipe = New ClsPLMarkModelRecipe
                    End If
                End If

                '--- 第九頁(HotPixel) ---
                Me.GroupBox_HotPixel.Enabled = False
                Me.CheckBox_HotPixelEnable.Checked = fpr.HotPixelEnable.Value
                Me.NumericUpDown_HotPixelRecipe.Value = fpr.HotPixelRecipe.Value
                Me.NumericUpDown_HotPixelFilterDistance.Value = fpr.HotPixelFilterDistance.Value
                Me.NumericUpDown_HotPixelMaxMean.Value = fpr.HotPixelMaxMean.Value
                Me.TrackBar_HotPixel_Threshold.Value = NumericUpDown_HotPixelRecipe.Value
                Me.CheckBox_Filter_HotPixel_With_Characteristics.Checked = fpr.Filter_HotPixel_With_Characteristics_Enable.Value

                '--- 第十頁(TP Mark) ---
                If Me.m_IPBootConfig.TPMarkUI.Value Then
                    If Not TP_mmr Is Nothing Then
                        Me.m_CurrentTPMarkIndex = 0
                        '--- Load Current Pattern ---
                        Me.Update_TPMark_Pattern(Me.m_CurrentTPMarkIndex, Me.m_FuncProcess.TPMarkModelRecipe)
                    Else
                        Me.m_FuncProcess.TPMarkModelRecipe = New ClsTPMarkModelRecipe
                    End If
                End If

                '--- Enable Setting ---
                Me.CheckBox_Report_Multi_Pixel.Checked = fpr.Report_Multi_Pixel.Value   '2013/06/18 Rick add
                Me.CheckBox_Align_Enable.Checked = fpr.AlignEnable.Value
                Me.CheckBox_Point_Enable.Checked = fpr.PointEnable.Value
                Me.CheckBox_GSBP_Enable.Checked = fpr.AnalysisGSBP.Value
                Me.CheckBox_BLDP_Enable.Checked = fpr.AnalysisBLDP.Value
                Me.CheckBox_Line_Enable.Checked = fpr.LineEnable.Value
                Me.CheckBox_HLine_NotAddToOutput.Checked = fpr.HLine_NotAddToOutput.Value
                Me.CheckBox_VLine_NotAddToOutput.Checked = fpr.VLine_NotAddToOutput.Value
                Me.CheckBox_Filter_VH_Scratch.Checked = fpr.Filter_VH_Scratch.Value
                Me.CheckBox_HalfScreen_Enable.Checked = fpr.HalfScreenEnable.Value
                Me.CheckBox_GrayAbnormal_Enable.Checked = fpr.GrayAbnormalEnable.Value
                Me.CheckBox_PLMark_Enable.Checked = fpr.PLMarkEnable.Value
                Me.CheckBox_CurrentPLMark_Enable.Enabled = Me.CheckBox_PLMark_Enable.Checked
                Me.CheckBox_TPMark_Enable.Checked = fpr.TPMarkEnable.Value
                Me.CheckBox_CPD_Enable.Checked = fpr.CPDEnable.Value
                Me.CheckBox_TPMark_Enable.Checked = fpr.TPMarkEnable.Value
                Me.CheckBox_Waku_Inspect_Enable.Checked = fpr.WakuInspectEnable.Value

                If fpr.WakuInspectEnable.Value Then
                    ComboBox_WakuEdge.SelectedIndex = 1
                End If

                Me.UpdateNumberUpDown()

                If FuncUpdateDataLog.Length > 0 Then Throw New Exception(FuncUpdateDataLog)
            End If
        Catch ex As Exception
            MsgBox("[Dialog_FuncSetting] 參數載入Form出錯：" & vbCrLf & ex.Message & "，請確認。", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try

    End Sub
#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim fpr As ClsFuncPatternRecipe
        Dim fmr As ClsFuncModelRecipe
        Dim pmmr As ClsPLMarkModelRecipe

        Try
            Me.CheckPattern()

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count Then
                fpr = Me.m_FuncProcess.FuncPatternRecipeArray.Item(0)
            Else
                fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
            End If
            fmr = Me.m_FuncProcess.FuncModelRecipe
            pmmr = Me.m_FuncProcess.PLMarkModelRecipe

            '--- 第一頁 ---
            '--- BP ---
            fpr.BDPointRecipe.Threshold_BP.Value = Me.NumericUpDown_BP_Threshold.Value
            fpr.BDPointRecipe.Threshold_BP_Low.Value = Me.NumericUpDown_BP_Threshold_Low.Value
            fpr.BDPointRecipe.ThresholdRim_BP.Value = Me.NumericUpDown_BP_RimThreshold.Value
            fpr.BDPointRecipe.ThresholdRim_BP_Low.Value = Me.NumericUpDown_BP_RimThreshold_Low.Value
            '--- DP ---
            fpr.BDPointRecipe.Threshold_DP.Value = Me.NumericUpDown_DP_Threshold.Value
            fpr.BDPointRecipe.Threshold_DP_Low.Value = Me.NumericUpDown_DP_Threshold_Low.Value
            fpr.BDPointRecipe.ThresholdRim_DP.Value = Me.NumericUpDown_DP_RimThreshold.Value
            fpr.BDPointRecipe.ThresholdRim_DP_Low.Value = Me.NumericUpDown_DP_RimThreshold_Low.Value

            fpr.AnalysisBP.Value = Me.RadioButton_BP.Checked
            fpr.AnalysisDP.Value = Me.RadioButton_DP.Checked
            If Me.RadioButton_BPDP.Checked Then
                fpr.AnalysisBP.Value = True
                fpr.AnalysisDP.Value = True
            End If

            '--- Tool ---
            '[1] Inverse Point Type & Fix Area ---
            fpr.BDPointRecipe.Inverse_PointDefectType.Value = Me.CheckBox_Inverse_Point_DefectType.Checked
            fpr.BDPointRecipe.Inverse_Point_EnableFixArea.Value = Me.CheckBox_Inverse_Point_EnableFixArea.Checked
            fpr.BDPointRecipe.Inverse_PointFixArea.Value = Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value

            fpr.BDPointRecipe.AreaMax_BP.Value = Me.NumericUpDown_BP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_BP.Value = Me.NumericUpDown_BP_AreaMin.Value
            fpr.BDPointRecipe.AreaMax_DP.Value = Me.NumericUpDown_DP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_DP.Value = Me.NumericUpDown_DP_AreaMin.Value
            fpr.BDPointRecipe.BypassX.Value = Me.NumericUpDown_Point_ByPassX.Value
            fpr.BDPointRecipe.BypassY.Value = Me.NumericUpDown_Point_ByPassY.Value
            fpr.BDPointRecipe.OverNum.Value = Me.NumericUpDown_Point_OverNum.Value
            '
            fpr.Report_Multi_Pixel.Value = Me.CheckBox_Report_Multi_Pixel.Checked   '2013/06/18 Rick add
            fpr.AlignEnable.Value = Me.CheckBox_Align_Enable.Checked
            fpr.PointEnable.Value = Me.CheckBox_Point_Enable.Checked
            fpr.AnalysisGSBP.Value = Me.CheckBox_GSBP_Enable.Checked
            fpr.AnalysisBLDP.Value = Me.CheckBox_BLDP_Enable.Checked
            fpr.CPDEnable.Value = Me.CheckBox_CPD_Enable.Checked
            fpr.WakuInspectEnable.Value = Me.CheckBox_Waku_Inspect_Enable.Checked

            '---SeparateBP---
            fpr.SeparateBPEnable.Value = CheckBox_SeparateBPEnable.Checked
            fpr.SeparateBPArea.Value = NumericUpDown_SeparateBPArea.Value
            fpr.SeparateBPBlob.Value = NumericUpDown_SeparateBPBlob.Value

            fpr.BDPointRecipe.EnableLeakPoint.Value = CheckBox_EnableLeakPoint.Checked

            '--- 第二頁 ---
            '--- BP Characteristics ---
            fpr.BDPointRecipe.Elongation_Min.Value = NumericUpDown_BP_Elongation_Min.Value
            fpr.BDPointRecipe.Elongation_Max.Value = NumericUpDown_BP_Elongation_Max.Value
            fpr.BDPointRecipe.Fullness_Min.Value = NumericUpDown_BP_Fullness_Min.Value
            fpr.BDPointRecipe.Fullness_Max.Value = NumericUpDown_BP_Fullness_Max.Value
            fpr.BDPointRecipe.MaxGray_Fullness_Min.Value = NumericUpDown_BP_MaxGray_Fullness_Min.Value
            fpr.BDPointRecipe.GrayMean_Min_BP.Value = NumericUpDown_BP_GrayMean_Min.Value
            fpr.BDPointRecipe.MaxGray_Min_BP.Value = NumericUpDown_BP_MaxGray_Min.Value
            fpr.BDPointRecipe.MaxGray_Max_BP.Value = NumericUpDown_BP_MaxGray_Max.Value
            fpr.BDPointRecipe.Compactness_Max_BP.Value = NumericUpDown_BP_Compactness_Max.Value
            fpr.BDPointRecipe.StdDev_Max_BP.Value = NumericUpDown_BP_StdDev_Max.Value

            '--- DP Characteristics ---
            fpr.BDPointRecipe.Elongation_Min_DP.Value = NumericUpDown_DP_Elongation_Min.Value
            fpr.BDPointRecipe.Elongation_Max_DP.Value = NumericUpDown_DP_Elongation_Max.Value
            fpr.BDPointRecipe.Fullness_Min_DP.Value = NumericUpDown_DP_Fullness_Min.Value
            fpr.BDPointRecipe.Fullness_Max_DP.Value = NumericUpDown_DP_Fullness_Max.Value
            fpr.BDPointRecipe.MaxGray_Fullness_Min_DP.Value = NumericUpDown_DP_MaxGray_Fullness_Min.Value
            fpr.BDPointRecipe.GrayMean_Max_DP.Value = NumericUpDown_DP_GrayMean_Max.Value
            fpr.BDPointRecipe.MinGray_Min_DP.Value = NumericUpDown_DP_MinGray_Min.Value
            fpr.BDPointRecipe.MinGray_Max_DP.Value = NumericUpDown_DP_MinGray_Max.Value
            fpr.BDPointRecipe.Compactness_Max_DP.Value = NumericUpDown_DP_Compactness_Max.Value
            fpr.BDPointRecipe.StdDev_Max_DP.Value = NumericUpDown_DP_StdDev_Max.Value

            '--- 第三頁 ---
            '--- GSBP ---
            fpr.BDPointRecipe.Threshold_GSBP.Value = Me.NumericUpDown_GSBP_Threshold.Value
            fpr.BDPointRecipe.ThresholdRim_GSBP.Value = Me.NumericUpDown_GSBP_ThresholdRim.Value

            '--- GSBP - Common setting ---
            fpr.BDPointRecipe.AreaMax_GSBP.Value = NumericUpDown_GSBP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_GSBP.Value = NumericUpDown_GSBP_AreaMin.Value
            fpr.BDPointRecipe.GSBP_Count_Min.Value = NumericUpDown_GSBP_Count_Min.Value
            fpr.BDPointRecipe.GSBP_RangeX.Value = NumericUpDown_GSBP_RangeX.Value
            fpr.BDPointRecipe.GSBP_RangeY.Value = NumericUpDown_GSBP_RangeY.Value
            fpr.BDPointRecipe.GSBP_Scratch_Length.Value = NumericUpDown_GSBP_Scratch_Length.Value
            fpr.BDPointRecipe.GSBP_OverNum.Value = NumericUpDown_GSBP_OverNum.Value
            fpr.BDPointRecipe.GSBP_NumOfHoles.Value = NumericUpDown_GSBP_NumOfHoles.Value
            fpr.BDPointRecipe.GSBP_GrayMax_High.Value = NumericUpDown_GSBP_GrayMax_High.Value
            fpr.BDPointRecipe.GSBP_GrayMax_Low.Value = NumericUpDown_GSBP_GrayMax_Low.Value

            fpr.AnalysisGSBP.Value = Me.CheckBox_GSBP_Enable.Checked

            '--- BLDP ---
            fpr.BDPointRecipe.Threshold_BLDP.Value = Me.NumericUpDown_BLDP_Threshold.Value
            fpr.BDPointRecipe.ThresholdRim_BLDP.Value = Me.NumericUpDown_BLDP_ThresholdRim.Value
            fpr.BDPointRecipe.EnhanceCount_BLDP.Value = Me.NumericUpDown_BLDP_EnhanceCount.Value

            '--- BLDP - Common setting ---
            fpr.BDPointRecipe.AreaMax_BLDP.Value = NumericUpDown_BLDP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_BLDP.Value = NumericUpDown_BLDP_AreaMin.Value
            fpr.BDPointRecipe.BLDP_Count_Min.Value = NumericUpDown_BLDP_Count_Min.Value
            fpr.BDPointRecipe.BLDP_RangeX.Value = NumericUpDown_BLDP_RangeX.Value
            fpr.BDPointRecipe.BLDP_RangeY.Value = NumericUpDown_BLDP_RangeY.Value
            fpr.BDPointRecipe.BLDP_Scratch_Length.Value = NumericUpDown_BLDP_Scratch_Length.Value
            fpr.BDPointRecipe.BLDP_OverNum.Value = NumericUpDown_BLDP_OverNum.Value
            fpr.BDPointRecipe.BLDP_Fatness_Min.Value = NumericUpDown_BLDP_Fatness_Min.Value
            fpr.BDPointRecipe.Elongation_Min_BLDP.Value = NumericUpDown_BLDP_Elongation_Min.Value
            fpr.BDPointRecipe.Elongation_Max_BLDP.Value = NumericUpDown_BLDP_Elongation_Max.Value

            fpr.AnalysisBLDP.Value = Me.CheckBox_BLDP_Enable.Checked

            '--- 第四頁 ---
            fpr.LineFinderRecipe.AnalysisBL.Value = Me.CheckBox_BLine_Enable.Checked
            fpr.LineFinderRecipe.AnalysisDL.Value = Me.CheckBox_DLine_Enable.Checked
            fpr.LineFinderRecipe.Threshold_DL.Value = Me.NumericUpDown_DL_Threshold.Value
            fpr.LineFinderRecipe.Threshold_BL.Value = Me.NumericUpDown_BL_Threshold.Value
            fpr.LineFinderRecipe.ThresholdRim_DL.Value = Me.NumericUpDown_DL_RimThreshold.Value
            fpr.LineFinderRecipe.ThresholdRim_BL.Value = Me.NumericUpDown_BL_RimThreshold.Value
            fpr.LineFinderRecipe.ByPassUpH.Value = Me.NumericUpDown_Line_ByPassUpH.Value
            fpr.LineFinderRecipe.ByPassDownH.Value = Me.NumericUpDown_Line_ByPassDownH.Value
            fpr.LineFinderRecipe.ByPassLeftV.Value = Me.NumericUpDown_Line_ByPassLeftV.Value
            fpr.LineFinderRecipe.ByPassRightV.Value = Me.NumericUpDown_Line_ByPassRightV.Value
            fpr.LineFinderRecipe.Line_Cut.Value = Me.NumericUpDown_Line_Cut.Value
            fpr.LineFinderRecipe.Line_Short_Cut.Value = Me.NumericUpDown_Line_Short_Cut.Value
            fpr.LineFinderRecipe.Line_Cut_H.Value = Me.NumericUpDown_Line_Cut_H.Value
            fpr.LineFinderRecipe.Line_Short_Cut_H.Value = Me.NumericUpDown_Line_Short_Cut_H.Value
            fpr.LineFinderRecipe.LineOverNum.Value = Me.NumericUpDown_Line_OverNumber.Value
            fpr.LineFinderRecipe.BlockOverNum.Value = Me.NumericUpDown_Block_OverNumber.Value
            fpr.LineFinderRecipe.Elongation_Min.Value = Me.NumericUpDown_Line_Elongation_Min.Value
            fpr.LineFinderRecipe.Mean_Difference.Value = Me.NumericUpDown_MeanDifference.Value
            fpr.LineEnable.Value = Me.CheckBox_Line_Enable.Checked
            fpr.HLine_NotAddToOutput.Value = Me.CheckBox_HLine_NotAddToOutput.Checked
            fpr.VLine_NotAddToOutput.Value = Me.CheckBox_VLine_NotAddToOutput.Checked
            fpr.Filter_VH_Scratch.Value = Me.CheckBox_Filter_VH_Scratch.Checked
            fpr.HalfScreenEnable.Value = Me.CheckBox_HalfScreen_Enable.Checked

            fpr.LineFinderRecipe.LeakPointRadius.Value = Me.NumericUpDown_LeakPointRadius.Value
            '--- 第五頁 ---
            fpr.DisplayMeanOffsetRecipe.PosLimit.Value = Me.NumericUpDown_GrayAbnormal_PosLimit.Value
            fpr.DisplayMeanOffsetRecipe.NegLimit.Value = Me.NumericUpDown_GrayAbnormal_NegLimit.Value
            fpr.DisplayMeanOffsetRecipe.StandardGray.Value = Me.NumericUpDown_GrayAbnormalStandardGray.Value
            fpr.DisplayMeanOffsetRecipe.NoDisplay.Value = Me.NumericUpDown_GrayAbnormal_NoDisplay.Value
            fpr.GrayAbnormalEnable.Value = Me.CheckBox_GrayAbnormal_Enable.Checked

            '--- 第六頁 ---
            fpr.AutoExposure_Kp.Value = Me.NumericUpDown_AutoExposure_Kp.Value
            fpr.AutoExposure_TargetMean.Value = Me.NumericUpDown_AutoExposure_TargetMean.Value
            fpr.AutoExposure_LargeErrorRange_UL.Value = Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value
            fpr.AutoExposure_LargeErrorRange_DL.Value = Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value
            fpr.AutoExposure_SmallErrorRange.Value = Me.NumericUpDown_AutoExposure_SmallErrorRange.Value
            fpr.AutoExposure_GrabDelayTime.Value = Me.NumericUpDown_AutoExposure_GrabDelayTime.Value

            '--- 第七頁 ---
            fpr.Point_PitchX.Value = Me.NumericUpDown_Point_PitchX.Value
            fpr.Point_PitchY.Value = Me.NumericUpDown_Point_PitchY.Value
            fpr.Line_PitchX.Value = Me.NumericUpDown_Line_PitchX.Value
            fpr.Line_PitchY.Value = Me.NumericUpDown_Line_PitchY.Value

            '--- Point\Line Average FIlter ---
            fpr.Average_Filter.Value = Me.NumericUpDown_AverageFilter.Value

            '--- Point Algorithm ---
            If Me.RadioButton_PointAlgorithm_0.Checked Then
                fpr.PointAlgorithm.Value = 0
            ElseIf Me.RadioButton_PointAlgorithm_1.Checked Then
                fpr.PointAlgorithm.Value = 1
            ElseIf Me.RadioButton_PointAlgorithm_2.Checked Then
                fpr.PointAlgorithm.Value = 2
            ElseIf Me.RadioButton_PointAlgorithm_3.Checked Then
                fpr.PointAlgorithm.Value = 3
            ElseIf Me.RadioButton_PointAlgorithm_4.Checked Then  'Circle ROI Image
                fpr.PointAlgorithm.Value = 4
            ElseIf Me.RadioButton_PointAlgorithm_5.Checked Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
                fpr.PointAlgorithm.Value = 5
            ElseIf Me.RadioButton_PointAlgorithm_6.Checked Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
                fpr.PointAlgorithm.Value = 6
            End If

            '--- Func Raw Data Filter Mura Setting ---
            fmr.FuncRawDataFilterMura_Enable.Value = Me.CheckBox_FuncRawDataFilterMura_Enable.Checked

            '--- Boundary Width ---
            fpr.Boundary_MulWidth_LX.Value = Me.NumericUpDown_Boundary_MulWidth_LX.Value
            fpr.Boundary_MulWidth_RX.Value = Me.NumericUpDown_Boundary_MulWidth_RX.Value
            fpr.Boundary_MulWidth_TY.Value = Me.NumericUpDown_Boundary_MulWidth_TY.Value
            fpr.Boundary_MulWidth_BY.Value = Me.NumericUpDown_Boundary_MulWidth_BY.Value

            '--- AI Setting ---
            fmr.AiResizeX.Value = Me.NumericUpDown_AiResizeX.Value
            fmr.AiResizeY.Value = Me.NumericUpDown_AiResizeY.Value
            fmr.IsAISaveROI.Value = Me.ComboBox_IsAISaveROI.Text.ToLower()

            '--- 第八頁(PL Mark) ---
            If Me.m_IPBootConfig.PLMarkUI.Value Then
                pmmr.FillofHole = Me.CheckBox_FillOfHole.Checked
                pmmr.SearchRange_PLMark_Multiple = Me.NumericUpDown_SearchRange_PLMark_Multiple.Value
                fpr.PLMarkEnable.Value = Me.CheckBox_PLMark_Enable.Checked
                pmmr.BlobArea = Me.NumericUpDown_BlobArea.Value
                pmmr.SearchMarkCount = Me.NumericUpDown_SearchMarkCount.Value
            End If

            '--- 第九頁(Hot Pixel) ---
            fpr.HotPixelEnable.Value = Me.CheckBox_HotPixelEnable.Checked
            fpr.HotPixelRecipe.Value = Me.NumericUpDown_HotPixelRecipe.Value
            fpr.HotPixelFilterDistance.Value = Me.NumericUpDown_HotPixelFilterDistance.Value
            fpr.HotPixelMaxMean.Value = Me.NumericUpDown_HotPixelMaxMean.Value
            fpr.Filter_HotPixel_With_Characteristics_Enable.Value = Me.CheckBox_Filter_HotPixel_With_Characteristics.Checked

            '---第十頁(TP Mark) ---
            If Me.m_IPBootConfig.TPMarkUI.Value Then
                fpr.TPMarkEnable.Value = Me.CheckBox_TPMark_Enable.Checked
            End If
        Catch ex As Exception
            MsgBox("[Dialog_FuncSetting.Setting] Setting 參數出錯：" & vbCrLf & ex.Message & "，請確認。", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try
    End Sub
#End Region

#Region "--- UpdateNumberUpDown ---"
    Private Sub UpdateNumberUpDown()

        Me.CheckPattern()
        '--- GroupBox ---
        '--- Point ---
        Me.GroupBox_PointCommonSetting.Enabled = Me.CheckBox_Point_Enable.Checked
        If Me.RadioButton_BPDP.Checked Then
            Me.GroupBox_BPoint.Enabled = True
            Me.GroupBox_DPoint.Enabled = True

            If (RadioButton_BP_Threshold.Checked And RadioButton_DP_Threshold.Checked) Or (RadioButton_BP_Threshold.Checked And RadioButton_DP_Threshold_Low.Checked) Then
                RadioButton_BP_Threshold.Checked = False
                RadioButton_DP_Threshold.Checked = False
                RadioButton_DP_Threshold_Low.Checked = False
            End If

            If (RadioButton_BP_RimThreshold.Checked And RadioButton_DP_RimThreshold.Checked) Or (RadioButton_BP_RimThreshold.Checked And RadioButton_DP_RimThreshold_Low.Checked) Then
                RadioButton_BP_RimThreshold.Checked = False
                RadioButton_DP_RimThreshold.Checked = False
                RadioButton_DP_RimThreshold_Low.Checked = False
            End If

            If (RadioButton_BP_Threshold_Low.Checked And RadioButton_DP_Threshold.Checked) Or (RadioButton_BP_Threshold_Low.Checked And RadioButton_DP_Threshold_Low.Checked) Then
                RadioButton_BP_Threshold_Low.Checked = False
                RadioButton_DP_Threshold.Checked = False
                RadioButton_DP_Threshold_Low.Checked = False
            End If

            If (RadioButton_BP_RimThreshold_Low.Checked And RadioButton_DP_RimThreshold.Checked) Or (RadioButton_BP_RimThreshold_Low.Checked And RadioButton_DP_RimThreshold_Low.Checked) Then
                RadioButton_BP_RimThreshold_Low.Checked = False
                RadioButton_DP_RimThreshold.Checked = False
                RadioButton_DP_RimThreshold_Low.Checked = False
            End If
        Else
            Me.GroupBox_BPoint.Enabled = Me.RadioButton_BP.Checked
            Me.GroupBox_DPoint.Enabled = Me.RadioButton_DP.Checked
        End If
        Me.GroupBox_PointPitchSetting.Enabled = Me.CheckBox_Point_Enable.Checked

        '--- GSBP ---
        Me.GroupBox_GSBP.Enabled = Me.CheckBox_GSBP_Enable.Checked
        Me.GroupBox_GSBPCommonSetting.Enabled = Me.CheckBox_GSBP_Enable.Checked

        '--- BLDP ---
        Me.GroupBox_BLDP.Enabled = Me.CheckBox_BLDP_Enable.Checked
        Me.GroupBox_BLDPCommonSetting.Enabled = Me.CheckBox_BLDP_Enable.Checked

        '--- Line ---
        Me.GroupBox_LineAverageFilter.Enabled = Me.CheckBox_Line_Enable.Checked
        Me.GroupBox_LineCommonSetting.Enabled = Me.CheckBox_Line_Enable.Checked
        Me.CheckBox_BLine_Enable.Enabled = Me.CheckBox_Line_Enable.Checked
        Me.CheckBox_DLine_Enable.Enabled = Me.CheckBox_Line_Enable.Checked
        Me.GroupBox_BLine.Enabled = Me.CheckBox_BLine_Enable.Checked
        Me.GroupBox_DLine.Enabled = Me.CheckBox_DLine_Enable.Checked
        Me.GroupBox_MeanDiff.Enabled = Me.CheckBox_HalfScreen_Enable.Checked

        '--- Abnormal ---
        Me.GroupBox_GrayAbnormal.Enabled = Me.CheckBox_GrayAbnormal_Enable.Checked

        '--- DPoint ----
        If GroupBox_DPoint.Enabled Then
            Me.NumericUpDown_DP_Threshold.Enabled = Me.RadioButton_DP_Threshold.Checked
            Me.NumericUpDown_DP_Threshold_Low.Enabled = Me.RadioButton_DP_Threshold_Low.Checked
            Me.NumericUpDown_DP_RimThreshold.Enabled = Me.RadioButton_DP_RimThreshold.Checked
            Me.NumericUpDown_DP_RimThreshold_Low.Enabled = Me.RadioButton_DP_RimThreshold_Low.Checked
        End If
        '--- BPoint ---
        If GroupBox_BPoint.Enabled Then
            Me.NumericUpDown_BP_Threshold.Enabled = Me.RadioButton_BP_Threshold.Checked
            Me.NumericUpDown_BP_Threshold_Low.Enabled = Me.RadioButton_BP_Threshold_Low.Checked
            Me.NumericUpDown_BP_RimThreshold.Enabled = Me.RadioButton_BP_RimThreshold.Checked
            Me.NumericUpDown_BP_RimThreshold_Low.Enabled = Me.RadioButton_BP_RimThreshold_Low.Checked
        End If

        '--- GSBP ---
        If Me.GroupBox_GSBP.Enabled Then
            Me.NumericUpDown_GSBP_Threshold.Enabled = Me.RadioButton_GSBP_Threshold.Checked
            Me.NumericUpDown_GSBP_ThresholdRim.Enabled = Me.RadioButton_GSBP_RimThreshold.Checked
        End If

        '--- BLDP ---
        If Me.GroupBox_BLDP.Enabled Then
            Me.NumericUpDown_BLDP_Threshold.Enabled = Me.RadioButton_BLDP_Threshold.Checked
            Me.NumericUpDown_BLDP_ThresholdRim.Enabled = Me.RadioButton_BLDP_RimThreshold.Checked
            Me.NumericUpDown_BLDP_EnhanceCount.Enabled = Me.RadioButton_BLDP_EnhanceCount.Checked
        End If

        '--- Point Common Setting ----
        Me.NumericUpDown_BP_AreaMax.Enabled = RadioButton_BP_AreaMax.Checked
        Me.NumericUpDown_BP_AreaMin.Enabled = RadioButton_BP_AreaMin.Checked
        Me.NumericUpDown_DP_AreaMax.Enabled = RadioButton_DP_AreaMax.Checked
        Me.NumericUpDown_DP_AreaMin.Enabled = RadioButton_DP_AreaMin.Checked
        Me.NumericUpDown_Point_ByPassX.Enabled = RadioButton_Point_ByPassX.Checked
        Me.NumericUpDown_Point_ByPassY.Enabled = RadioButton_Point_ByPassY.Checked
        Me.NumericUpDown_Point_OverNum.Enabled = RadioButton_Point_OverNum.Checked

        '--- GSBP Common Setting ----
        Me.NumericUpDown_GSBP_AreaMax.Enabled = RadioButton_GSBP_AreaMax.Checked
        Me.NumericUpDown_GSBP_AreaMin.Enabled = RadioButton_GSBP_AreaMin.Checked
        Me.NumericUpDown_GSBP_Count_Min.Enabled = RadioButton_GSBP_Count_Min.Checked
        Me.NumericUpDown_GSBP_RangeX.Enabled = RadioButton_GSBP_RangeX.Checked
        Me.NumericUpDown_GSBP_RangeY.Enabled = RadioButton_GSBP_RangeY.Checked
        Me.NumericUpDown_GSBP_Scratch_Length.Enabled = RadioButton_GSBP_Scratch_Length.Checked
        Me.NumericUpDown_GSBP_OverNum.Enabled = RadioButton_GSBP_OverNum.Checked
        Me.NumericUpDown_GSBP_NumOfHoles.Enabled = RadioButton_GSBP_NumOfHoles.Checked
        Me.NumericUpDown_GSBP_GrayMax_High.Enabled = RadioButton_GSBP_GrayMax_High.Checked
        Me.NumericUpDown_GSBP_GrayMax_Low.Enabled = RadioButton_GSBP_GrayMax_Low.Checked

        '--- BLDP Common Setting ----
        Me.NumericUpDown_BLDP_AreaMax.Enabled = RadioButton_BLDP_AreaMax.Checked
        Me.NumericUpDown_BLDP_AreaMin.Enabled = RadioButton_BLDP_AreaMin.Checked
        Me.NumericUpDown_BLDP_Count_Min.Enabled = RadioButton_BLDP_Count_Min.Checked
        Me.NumericUpDown_BLDP_RangeX.Enabled = RadioButton_BLDP_RangeX.Checked
        Me.NumericUpDown_BLDP_RangeY.Enabled = RadioButton_BLDP_RangeY.Checked
        Me.NumericUpDown_BLDP_Scratch_Length.Enabled = RadioButton_BLDP_Scratch_Length.Checked
        Me.NumericUpDown_BLDP_OverNum.Enabled = RadioButton_BLDP_OverNum.Checked
        Me.NumericUpDown_BLDP_Fatness_Min.Enabled = RadioButton_BLDP_Fatness_Min.Checked
        Me.NumericUpDown_BLDP_Elongation_Min.Enabled = RadioButton_BLDP_Elongation_Min.Checked
        Me.NumericUpDown_BLDP_Elongation_Max.Enabled = RadioButton_BLDP_Elongation_Max.Checked

        '--- BP Characteristics ---
        Me.NumericUpDown_BP_Elongation_Min.Enabled = RadioButton_BP_Elongation_Min.Checked
        Me.NumericUpDown_BP_Elongation_Max.Enabled = RadioButton_BP_Elongation_Max.Checked
        Me.NumericUpDown_BP_Fullness_Min.Enabled = RadioButton_BP_Fullness_Min.Checked
        Me.NumericUpDown_BP_Fullness_Max.Enabled = RadioButton_BP_Fullness_Max.Checked
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Enabled = RadioButton_BP_MaxGray_Fullness_Min.Checked
        Me.NumericUpDown_BP_GrayMean_Min.Enabled = RadioButton_BP_GrayMean_Min.Checked
        Me.NumericUpDown_BP_MaxGray_Min.Enabled = RadioButton_BP_MaxGray_Min.Checked
        Me.NumericUpDown_BP_StdDev_Max.Enabled = RadioButton_BP_StdDev_Max.Checked
        Me.NumericUpDown_BP_Compactness_Max.Enabled = RadioButton_BP_Compactness_Max.Checked

        '--- DP Characteristics ---
        Me.NumericUpDown_DP_Elongation_Min.Enabled = RadioButton_DP_Elongation_Min.Checked
        Me.NumericUpDown_DP_Elongation_Max.Enabled = RadioButton_DP_Elongation_Max.Checked
        Me.NumericUpDown_DP_Fullness_Min.Enabled = RadioButton_DP_Fullness_Min.Checked
        Me.NumericUpDown_DP_Fullness_Max.Enabled = RadioButton_DP_Fullness_Max.Checked
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Enabled = RadioButton_DP_MaxGray_Fullness_Min.Checked
        Me.NumericUpDown_DP_GrayMean_Max.Enabled = RadioButton_DP_GrayMean_Max.Checked
        Me.NumericUpDown_DP_MinGray_Max.Enabled = RadioButton_DP_MinGray_Max.Checked
        Me.NumericUpDown_DP_StdDev_Max.Enabled = RadioButton_DP_StdDev_Max.Checked
        Me.NumericUpDown_DP_Compactness_Max.Enabled = RadioButton_DP_Compactness_Max.Checked

        '--- Line ----
        If Me.CheckBox_DLine_Enable.Enabled Then
            Me.NumericUpDown_DL_Threshold.Enabled = RadioButton_DL_Threshold.Checked
            Me.TrackBar_DL_Threshold.Enabled = RadioButton_DL_Threshold.Checked
            Me.NumericUpDown_DL_RimThreshold.Enabled = RadioButton_DL_Threshold.Checked
        End If
        If Me.CheckBox_BLine_Enable.Enabled Then
            Me.NumericUpDown_BL_Threshold.Enabled = RadioButton_BL_Threshold.Checked
            Me.TrackBar_BL_Threshold.Enabled = RadioButton_BL_Threshold.Checked
            Me.NumericUpDown_BL_RimThreshold.Enabled = RadioButton_BL_Threshold.Checked
        End If

        If GroupBox_LineCommonSetting.Enabled Then
            Me.NumericUpDown_Line_ByPassUpH.Enabled = RadioButton_Line_ByPassUpH.Checked
            Me.NumericUpDown_Line_ByPassDownH.Enabled = RadioButton_Line_ByPassDownH.Checked
            Me.NumericUpDown_Line_ByPassLeftV.Enabled = RadioButton_Line_ByPassLeftV.Checked
            Me.NumericUpDown_Line_ByPassRightV.Enabled = RadioButton_Line_ByPassRightV.Checked
            Me.NumericUpDown_Line_Cut.Enabled = RadioButton_Line_Cut.Checked
            Me.NumericUpDown_Line_Short_Cut.Enabled = RadioButton_Line_ShortCut.Checked
            Me.NumericUpDown_Line_Cut_H.Enabled = RadioButton_Line_Cut_H.Checked
            Me.NumericUpDown_Line_Short_Cut_H.Enabled = RadioButton_Line_ShortCut_H.Checked
            Me.NumericUpDown_Line_OverNumber.Enabled = RadioButton_Line_OverNum.Checked
            Me.NumericUpDown_Block_OverNumber.Enabled = RadioButton_Block_OverNum.Checked
        End If

        '--- TPMark ---
        Me.CheckBox_TPMark_Enable.Enabled = Me.m_IPBootConfig.TPMarkUI.Value

    End Sub
#End Region

#Region "--- CheckPattern ---"

    Private Sub CheckPattern()
        Try
            '--- Pattern 檢查 ----   
            If Me.m_Form.GetPatternNameInfo <> Me.ComboBox_Pattern.Text Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count()
            End If
        Catch ex As Exception
            Throw New Exception("[Dialog_FuncSetting.CheckPattern]Check Pattern Error ! (" & ex.Message & ")")
        End Try
    End Sub

#End Region

#Region "--- PL Mark ---"

#Region "--- Update_PLMark_Pattern ---"
    Private Sub Update_PLMark_Pattern(ByVal CurrentMarkIndex As Integer, ByVal PLMarkModelRecipe As ClsPLMarkModelRecipe)

        Try
            If PLMarkModelRecipe.PMG.PMGroup.Count > 0 Then

                Dim filepath As String
                Dim SizeX, SizeY, Type As Integer

                '建立連線 ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                'Disable Button ---  
                Me.Button_PLMark_Enable(False)

                'Refresh PL Mark Pattern ---
                Try
                    Me.CheckedListBox_PLMark.Items.Clear()
                    For Each PLMark As ClsPLMark In PLMarkModelRecipe.PMG.PMGroup
                        Me.CheckedListBox_PLMark.Items.Add(PLMark.MarkName, PLMark.MarkEnable)
                    Next
                Catch ex As Exception
                    Throw New Exception("[Dialog_FuncSetting.Update_PLMark_Pattern]Refresh PL Mark Pattern Fail !( " & ex.Message & ")(" & ex.StackTrace & ")")
                End Try

                'Get Current PL Mark ---
                If Not PLMarkModelRecipe.PMG.Item(CurrentMarkIndex) Is Nothing Then
                    Me.m_CurrentPLMark = PLMarkModelRecipe.PMG.Item(CurrentMarkIndex)
                    Me.TextBox_PLMark_MarkName.Text = Me.m_CurrentPLMark.MarkName
                    Me.NumericUpDown_MarkTH.Value = Me.m_CurrentPLMark.MarkTH
                    Me.NumericUpDown_PLMark_Acceptance.Value = Me.m_CurrentPLMark.Mark_Acceptance
                    Me.NumericUpDown_MarkGroup.Value = Me.m_CurrentPLMark.Mark_Group
                    Me.NumericUpDown_PLMark_DilateCount.Value = Me.m_CurrentPLMark.Mark_DilateCount
                    Me.CheckBox_BlobFillHole.Checked = Me.m_CurrentPLMark.BlobFillHole

                    If Me.m_CurrentPLMark.MatchImg = "GrayMark" Then
                        Me.ComboBox_MatchImg.SelectedIndex = 1
                    Else
                        Me.ComboBox_MatchImg.SelectedIndex = 0
                    End If

                    Me.CheckBox_PreProcess.Checked = Me.m_CurrentPLMark.PreProcess
                    Me.NumericUpDown_GrayMarkSmoothCount.Value = Me.m_CurrentPLMark.GrayMarkSmoothCount
                    Me.NumericUpDown_GrayMarkErodeCount.Value = Me.m_CurrentPLMark.GrayMarkErodeCount

                    If Me.m_CurrentPLMark.BypassRegion = "MarkBlock" Then
                        Me.ComboBox_BypassRegion.SelectedIndex = 1
                    Else
                        Me.ComboBox_BypassRegion.SelectedIndex = 0
                    End If

                    Me.m_Form.PaintStop = True
                    If Not Me.m_CurrentPLMark.MarkBoundary Is Nothing Then
                        Me.NumericUpDown_PLMark_BoundaryTop.Value = Me.m_CurrentPLMark.MarkBoundary.TopY
                        Me.NumericUpDown_PLMark_BoundaryBottom.Value = Me.m_CurrentPLMark.MarkBoundary.BottomY
                        Me.NumericUpDown_PLMark_BoundaryLeft.Value = Me.m_CurrentPLMark.MarkBoundary.LeftX
                        Me.NumericUpDown_PLMark_BoundaryRight.Value = Me.m_CurrentPLMark.MarkBoundary.RightX
                    End If

                    'Show PL Mark Image ---
                    filepath = PLMarkModelRecipe.PMG.Item(CurrentMarkIndex).MarkImagePath
                    If File.Exists(filepath) Then
                        MbufClear(Me.m_MainProcess.Img_PLMark_NonPage, 0L)  '2012/12/06 Rick add

                        MbufDiskInquire(Me.m_CurrentPLMark.MarkImagePath, M_SIZE_X, SizeX)
                        MbufDiskInquire(Me.m_CurrentPLMark.MarkImagePath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(Me.m_CurrentPLMark.MarkImagePath, M_TYPE, Type)

                        If Me.m_MainProcess.Img_PLMark_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.Img_PLMark_NonPage)
                                Me.m_MainProcess.Img_PLMark_NonPage = M_NULL
                                Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(filepath, Me.m_MainProcess.Img_PLMark_NonPage)

                        '--- Display PLMark Image ---
                        MdispSelectWindow(Me.m_AxMDisplay_PLMark, Me.m_MainProcess.Img_PLMark_NonPage, Me.Panel_AxMDisplay_PLMark.Handle)
                        MbufControl(Me.m_MainProcess.Img_PLMark_NonPage, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_AxMDisplay_PLMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                        Me.PLMark_ImageZoomAll()
                        Me.RadioButton_PLMark_Original.Checked = True

                        '----------------------------------------------------------------------------------------------
                        ' Set Current PL Mark  ==> Request_Command = "PLMARK_SETCURRENT" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            'Prepare Command ---
                            Request_Command = "PLMARK_SETCURRENT"
                            TimeOut = 300000 '300 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, CurrentMarkIndex, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                'Enable Button ---   
                                Me.Button_PLMark_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current PL Mark Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                                MessageBox.Show("[Dialog_FuncSetting.Update_PLMark_Pattern][PLMARK_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            'Enable Button ---  
                            Me.Button_PLMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.Update_PLMark_Pattern]Set Current PL Mark Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_FuncSetting.Update_PLMark_Pattern][PLMARK_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                End If

                'Button Control ---
                Me.Button_PLMark_Enable(True)
                Me.Update()
            End If
        Catch ex As Exception
            Me.Button_PLMark_Enable(True)
            Throw New Exception("[Dialog_GlassEdgeSetting.Update_PLMark_Pattern] Update PL Mark Pattern Error ! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- DrawPLMark ---"
    Private Sub DrawPLMark(ByVal DrawType As String)
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image <> M_NULL Then

            Select Case Me.m_Form.ComboBox_Type.SelectedIndex

                Case 0
                    If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        '[1] PL Mark Region ---
                        If DrawType = "Region" Then Me.DrawPLMarkRegion(0, 0)
                        '[2] PL Mark Result ---
                        If DrawType = "Result" Then Me.DrawPLMarkResult(0, 0)
                        '[3] PL Mark SearchRange ---
                        If DrawType = "SearchRange" Then Me.DrawPLMarkRegionMultiple(0, 0)
                    End If
                Case 1
                    '[1] PL Mark Region ---
                    If DrawType = "Region" Then Me.DrawPLMarkRegion(-m_offX, -m_offY)
                    '[2] PL Mark Result ---
                    If DrawType = "Result" Then Me.DrawPLMarkResult(-m_offX, -m_offY)
                    '[3] PL Mark SearchRange ---
                    If DrawType = "SearchRange" Then Me.DrawPLMarkRegionMultiple(-m_offX, -m_offY)
            End Select
        End If

        Me.Update()
    End Sub
#End Region

#Region "--- DrawPLMarkRegion ---"
    Private Sub DrawPLMarkRegion(ByVal offX As Integer, ByVal offY As Integer)
        Dim rect As Rectangle
        Dim intLabelLeft As Integer
        Dim intLabelRight As Integer
        Dim intLabelTop As Integer
        Dim intLabelBottom As Integer
        Dim pb As ClsParameterBoundary
        Dim ZoomX, ZoomY As Double

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        Try
            If Me.CheckBox_PLMark_ShowBoundary.Checked Then
                '--- Initial ---
                pb = New ClsParameterBoundary
                pb.LeftX = Me.NumericUpDown_PLMark_BoundaryLeft.Value
                pb.RightX = Me.NumericUpDown_PLMark_BoundaryRight.Value
                pb.TopY = Me.NumericUpDown_PLMark_BoundaryTop.Value
                pb.BottomY = Me.NumericUpDown_PLMark_BoundaryBottom.Value

                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

                rect = New Rectangle
                If Not (pb.LeftX = 0 And pb.TopY = 0 And pb.RightX = 0 And pb.BottomY = 0) Then
                    Me.m_Pen.Color = Color.Yellow
                    Me.m_Pen.Width = ZoomX
                    intLabelLeft = (pb.LeftX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                    intLabelRight = (pb.RightX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                    intLabelTop = (pb.TopY - Me.m_Form.VScrollBar.Value - offY) * ZoomX
                    intLabelBottom = (pb.BottomY - Me.m_Form.VScrollBar.Value - offY) * ZoomX

                    rect.X = intLabelLeft
                    rect.Y = intLabelTop
                    rect.Width = intLabelRight - intLabelLeft + 1
                    rect.Height = intLabelBottom - intLabelTop + 1
                    Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                End If
            End If

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.DrawPLMarkRegion]Draw PL Mark Region Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- DrawPLMarkResult ---"
    Private Sub DrawPLMarkResult(ByVal offX As Integer, ByVal offY As Integer)
        If Me.m_FuncProcess.PLMarkResults.Count <= 0 Then Exit Sub

        Dim rect As Rectangle
        Dim ox As Integer
        Dim oy As Integer
        Dim s As Double
        Dim i As Integer
        Dim j As Integer
        Dim mr As ClsMarkResult
        Dim MarkResult_Count As Integer
        Dim P1 As Point
        Dim P2 As Point
        Dim ZoomX As Double

        Try
            '--- Initial --- 
            Me.m_Form.PaintStop = True
            Me.m_Form.Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)

            rect = New Rectangle
            Me.m_Pen.Color = Color.Yellow
            ox = Me.m_Form.HScrollBar.Value - offX
            oy = Me.m_Form.VScrollBar.Value - offY

            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
            s = ZoomX
            MarkResult_Count = Me.m_FuncProcess.PLMarkResults.Count

            i = 0
            For j = 0 To MarkResult_Count - 1
                mr = Me.m_FuncProcess.PLMarkResults.Item(j)

                rect.X = (mr.PosX - ox) * s
                rect.Y = (mr.PosY - oy) * s
                rect.Width = mr.SizeX * s
                rect.Height = mr.SizeY * s
                Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)

                '畫十字線 ---
                Me.m_Pen.Width = 2 * s
                P1.X = (mr.PosX + 0.5 * mr.SizeX - ox - 8) * s
                P1.Y = (mr.PosY + 0.5 * mr.SizeY - oy) * s
                P2.X = (mr.PosX + 0.5 * mr.SizeX - ox + 8) * s
                P2.Y = (mr.PosY + 0.5 * mr.SizeY - oy) * s
                If P1.X > 0 AndAlso P1.Y > 0 Then
                    Me.m_GraphicsImage.DrawLine(Me.m_Pen, P1, P2)
                End If

                P1.X = (mr.PosX + 0.5 * mr.SizeX - ox) * s
                P1.Y = (mr.PosY + 0.5 * mr.SizeY - oy - 8) * s
                P2.X = (mr.PosX + 0.5 * mr.SizeX - ox) * s
                P2.Y = (mr.PosY + 0.5 * mr.SizeY - oy + 8) * s
                If P1.X > 0 AndAlso P1.Y > 0 Then
                    Me.m_GraphicsImage.DrawLine(Me.m_Pen, P1, P2)
                End If

                Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
                'Me.m_Form.PaintStop = False
            Next
        Catch ex As Exception
            Throw New Exception("[Dialog_GlassEdgeSetting.DrawPLMarkResult] Draw PL Mark Result Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- DrawPLMarkRegionMultiple ---"

    Private Sub Label_SearchRange_PLMark_Multiple_Click(sender As System.Object, e As System.EventArgs) Handles Label_SearchRange_PLMark_Multiple.Click
        Me.DrawPLMark("SearchRange")
    End Sub

    Private Sub DrawPLMarkRegionMultiple(ByVal offX As Integer, ByVal offY As Integer)
        Dim rect As Rectangle
        Dim intLabelLeft As Integer
        Dim intLabelRight As Integer
        Dim intLabelTop As Integer
        Dim intLabelBottom As Integer
        Dim pb As ClsParameterBoundary
        Dim ZoomX, ZoomY As Double
        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim SearchRange As Integer

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        Try
            If Me.CheckBox_PLMark_ShowBoundary.Checked Then
                '--- Initial ---
                SizeX = Me.NumericUpDown_PLMark_BoundaryRight.Value - Me.NumericUpDown_PLMark_BoundaryLeft.Value + 1
                SizeY = Me.NumericUpDown_PLMark_BoundaryBottom.Value - Me.NumericUpDown_PLMark_BoundaryTop.Value + 1
                SearchRange = NumericUpDown_SearchRange_PLMark_Multiple.Value

                pb = New ClsParameterBoundary
                pb.LeftX = Me.NumericUpDown_PLMark_BoundaryLeft.Value - SearchRange * SizeX
                pb.RightX = Me.NumericUpDown_PLMark_BoundaryRight.Value + SearchRange * SizeX
                pb.TopY = Me.NumericUpDown_PLMark_BoundaryTop.Value - SearchRange * SizeY
                pb.BottomY = Me.NumericUpDown_PLMark_BoundaryBottom.Value + SearchRange * SizeY

                If pb.LeftX < 0 Then
                    pb.LeftX = 0
                End If
                If pb.RightX > Me.m_IPBootConfig.ImageSizeX.Value Then
                    pb.RightX = Me.m_IPBootConfig.ImageSizeX.Value
                End If
                If pb.TopY < 0 Then
                    pb.TopY = 0
                End If
                If pb.BottomY > Me.m_IPBootConfig.ImageSizeY.Value Then
                    pb.BottomY = Me.m_IPBootConfig.ImageSizeY.Value
                End If

                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

                rect = New Rectangle
                If Not (pb.LeftX = 0 And pb.TopY = 0 And pb.RightX = 0 And pb.BottomY = 0) Then
                    Me.m_Pen.Color = Color.Red
                    Me.m_Pen.Width = ZoomX
                    intLabelLeft = (pb.LeftX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                    intLabelRight = (pb.RightX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                    intLabelTop = (pb.TopY - Me.m_Form.VScrollBar.Value - offY) * ZoomX
                    intLabelBottom = (pb.BottomY - Me.m_Form.VScrollBar.Value - offY) * ZoomX

                    rect.X = intLabelLeft
                    rect.Y = intLabelTop
                    rect.Width = intLabelRight - intLabelLeft + 1
                    rect.Height = intLabelBottom - intLabelTop + 1
                    Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                End If
            End If

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.DrawPLMarkRegion]Draw PL Mark Region Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- PLMark_Setting ---"
    Private Sub PLMark_Setting()
        Dim Img_PLMark = M_NULL
        Dim boundary As New ClsParameterBoundary
        Dim oPatternMarkTemp As New ClsPLMark
        Dim filepath As String = ""
        Dim strPath As String = ""
        Dim pmmr As ClsPLMarkModelRecipe
        Dim Parameter_Lists As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim Update_PLMark_Img As Boolean = True

        Try
            '建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---  
            Me.Button_PLMark_Enable(False)

            pmmr = Me.m_FuncProcess.PLMarkModelRecipe

            '設定目錄 ---
            filepath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\PLMark"
            RepairPath_2(filepath)

            Me.m_UpdatePLMark = False

            '--- Create New ClsPLMark ---  '2012/12/03 Rick add
            If pmmr.PMG.Count < (Me.m_CurrentPLMarkIndex + 1) Then
                MsgBox("PL Mark Recipe Error , Please Delete All PL Mark Recipe")
                Exit Sub
            End If

            Me.m_CurrentPLMark = pmmr.PMG.Item(Me.m_CurrentPLMarkIndex)
            If Me.m_CurrentPLMark.MatchImg <> Me.ComboBox_MatchImg.Text OrElse
                Me.m_CurrentPLMark.PreProcess <> Me.CheckBox_PreProcess.Checked OrElse
                Me.m_CurrentPLMark.Mark_Acceptance <> Me.NumericUpDown_PLMark_Acceptance.Value OrElse
                Me.m_CurrentPLMark.GrayMarkSmoothCount <> Me.NumericUpDown_GrayMarkSmoothCount.Value OrElse
                Me.m_CurrentPLMark.GrayMarkErodeCount <> Me.NumericUpDown_GrayMarkErodeCount.Value Then

                Me.m_UpdatePLMark = True
                Update_PLMark_Img = False
            End If


            'If Me.m_CurrentPLMark.Mark_Acceptance <> Me.NumericUpDown_PLMark_Acceptance.Value Then
            '    Update_PLMark_Acceptance = True
            'End If

            'Mark_Enable
            Me.m_CurrentPLMark.MarkEnable = Me.CheckBox_CurrentPLMark_Enable.Checked
            'Mark Info ---
            Me.m_CurrentPLMark.MarkName = Me.TextBox_PLMark_MarkName.Text
            Me.m_CurrentPLMark.Mark_Acceptance = Me.NumericUpDown_PLMark_Acceptance.Value
            Me.m_CurrentPLMark.Mark_Group = Me.NumericUpDown_MarkGroup.Value
            'Match Setting ---
            Me.m_CurrentPLMark.MatchImg = Me.ComboBox_MatchImg.Text
            Me.m_CurrentPLMark.PreProcess = Me.CheckBox_PreProcess.Checked
            'Bypass Setting ---
            Me.m_CurrentPLMark.BypassRegion = Me.ComboBox_BypassRegion.Text
            Me.m_CurrentPLMark.BlobFillHole = Me.CheckBox_BlobFillHole.Checked
            Me.m_CurrentPLMark.Mark_DilateCount = Me.NumericUpDown_PLMark_DilateCount.Value

            oPatternMarkTemp = pmmr.PMG.PMGroup(m_CurrentPLMarkIndex)
            If Me.m_UpdatePLTH Then
                Me.NumericUpDown_PLMark_BoundaryLeft.Value = oPatternMarkTemp.MarkBoundary.LeftX
                Me.NumericUpDown_PLMark_BoundaryRight.Value = oPatternMarkTemp.MarkBoundary.RightX
                Me.NumericUpDown_PLMark_BoundaryTop.Value = oPatternMarkTemp.MarkBoundary.TopY
                Me.NumericUpDown_PLMark_BoundaryBottom.Value = oPatternMarkTemp.MarkBoundary.BottomY
            End If

            'PL Mark Image Boundary ---
            boundary.LeftX = Me.NumericUpDown_PLMark_BoundaryLeft.Value
            boundary.RightX = Me.NumericUpDown_PLMark_BoundaryRight.Value
            boundary.TopY = Me.NumericUpDown_PLMark_BoundaryTop.Value
            boundary.BottomY = Me.NumericUpDown_PLMark_BoundaryBottom.Value

            'Check If Update Mark
            If oPatternMarkTemp.MarkBoundary.LeftX <> boundary.LeftX Or oPatternMarkTemp.MarkBoundary.RightX <> boundary.RightX Or oPatternMarkTemp.MarkBoundary.TopY <> boundary.TopY Or oPatternMarkTemp.MarkBoundary.BottomY <> boundary.BottomY Then
                Me.m_UpdatePLMark = True
                Update_PLMark_Img = True
            End If

            'Update Recipe ----
            '將參數存到Recipe Array，新圖存到實體 Path 裡面﹝如果是新增，就只管加入；如果是異動，就要更新﹞

            '[新增] ---
            Me.m_CurrentPLMark.MarkImagePath = filepath & "\" & Me.TextBox_PLMark_MarkName.Text & ".tif"
            Me.m_CurrentPLMark.BinImagePath = filepath & "\" & Me.TextBox_PLMark_MarkName.Text & "_bin.tif"
            Me.m_CurrentPLMark.Mark_RefX = boundary.LeftX
            Me.m_CurrentPLMark.Mark_RefY = boundary.TopY
            Me.m_CurrentPLMark.Mark_SizeX = boundary.RightX - boundary.LeftX + 1
            Me.m_CurrentPLMark.Mark_SizeY = boundary.BottomY - boundary.TopY + 1
            Me.m_CurrentPLMark.MarkBoundary = boundary
            Me.m_CurrentPLMark.MarkTH = NumericUpDown_MarkTH.Value
            Me.m_CurrentPLMark.GrayMarkSmoothCount = NumericUpDown_GrayMarkSmoothCount.Value
            Me.m_CurrentPLMark.GrayMarkErodeCount = NumericUpDown_GrayMarkErodeCount.Value

            '----------------------------------------------------------------------------------------------
            ' Set Current PL Mark's Parameters  ==> Request_Command = "PLMARK_SET_PARAMETERS" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "PLMARK_SET_PARAMETERS"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------

                '第一頁  ---
                Parameter_Lists = Parameter_Lists & "PLMark_Acceptance," & Me.NumericUpDown_PLMark_Acceptance.Value & ";" & "PLMark_DilateCount," & Me.NumericUpDown_PLMark_DilateCount.Value & ";" & "PLMark_PatternName," & Me.ComboBox_Pattern.Text & ";" & "Mark_Group," & Me.NumericUpDown_MarkGroup.Value & ";" & _
                                                    "PLMark_Blacking," & ";" & "PLMark_Variation," & ";" & "BlobArea," & Me.NumericUpDown_BlobArea.Value & ";" & "MarkTH," & Me.NumericUpDown_MarkTH.Value & ";" & "CurrentPLMark_Enable," & Me.CheckBox_CurrentPLMark_Enable.Checked & ";" & _
                                                    "PLMark_RefX," & boundary.LeftX & ";" & "PLMark_RefY," & boundary.TopY & ";" & _
                                                    "PLMark_SizeX," & (boundary.RightX - boundary.LeftX + 1) & ";" & "PLMark_SizeY," & (boundary.BottomY - boundary.TopY + 1) & ";" & _
                                                    "PLMark_ImagePath," & (filepath & "\" & Me.TextBox_PLMark_MarkName.Text & ".tif") & ";" & "PLMark_BinImagePath," & (filepath & "\" & Me.TextBox_PLMark_MarkName.Text & "_bin.tif") & ";" & _
                                                    "PLMark_LeftX," & boundary.LeftX & ";" & "PLMark_TopY," & boundary.TopY & ";" & "PLMark_RightX," & boundary.RightX & ";" & "PLMark_BottomY," & boundary.BottomY & ";" & _
                                                    "PLMark_BlobFillHole," & Me.CheckBox_BlobFillHole.Checked & ";" & _
                                                    "PLMark_MatchImg," & Me.ComboBox_MatchImg.Text & ";" & "PLMark_PreProcess," & Me.CheckBox_PreProcess.Checked & ";" & "PLMark_BypassRegion," & Me.ComboBox_BypassRegion.Text & ";" & _
                                                    "PLMark_GrayMarkSmoothCount," & Me.NumericUpDown_GrayMarkSmoothCount.Value & ";" & "PLMark_GrayMarkErodeCount," & Me.NumericUpDown_GrayMarkErodeCount.Value
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.TextBox_PLMark_MarkName.Text, Parameter_Lists, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    'Enable Button ---   
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current PL Mark parameters Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][PLMARK_SET_PARAMETERS]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                'Enable Button ---  
                Me.Button_PLMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.PLMark_Setting]Set Current PL Mark parameters Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][PLMARK_SET_PARAMETERS]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save PL Mark Model Recipe ==> Request_Command = "SAVE_PLMARK_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "SAVE_PLMARK_MODEL_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    'Enable Button ---   
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save PL Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                'Enable Button ---  
                Me.Button_PLMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.PLMark_Setting]Save PL Mark Model Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save PL Mark Image  ==> Request_Command = "SAVE_PLMARK_IMAGE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------


            If Me.m_UpdatePLMark Or Me.m_UpdatePLTH Then
                Try
                    'Prepare Command ---
                    Request_Command = "SAVE_PLMARK_IMAGE"
                    TimeOut = 100000 '100 secs
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentPLMark.MarkImagePath, Me.NumericUpDown_MarkTH.Value.ToString, Me.m_CurrentPLMark.BinImagePath, Me.m_CurrentPLMarkIndex, Update_PLMark_Img, , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        Me.Button_PLMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save PL Mark Image Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_IMAGE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.PLMark_Setting]Savec PL Mark Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_IMAGE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If




            'Show PL Mark Image ---   
            filepath = pmmr.PMG.Item(Me.m_CurrentPLMarkIndex).MarkImagePath
            If File.Exists(filepath) Then

                MbufDiskInquire(filepath, M_SIZE_X, SizeX)
                MbufDiskInquire(filepath, M_SIZE_Y, SizeY)
                MbufDiskInquire(filepath, M_TYPE, Type)
                If Me.m_MainProcess.Img_PLMark_NonPage <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_PLMark_NonPage)
                        Me.m_MainProcess.Img_PLMark_NonPage = M_NULL
                        Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(filepath, Me.m_MainProcess.Img_PLMark_NonPage)

                '--- Display ---
                MdispSelectWindow(Me.m_AxMDisplay_PLMark, Me.m_MainProcess.Img_PLMark_NonPage, Me.Panel_AxMDisplay_PLMark.Handle)
                MbufControl(Me.m_MainProcess.Img_PLMark_NonPage, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_AxMDisplay_PLMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                Me.RadioButton_PLMark_Original.Checked = True

                Me.PLMark_ImageZoomAll()

                Me.m_Form.ResetScrollBar()

            End If


            'Button Control ---
            Me.Button_PLMark_Enable(True)
            Me.Update()
        Catch ex As Exception
            Me.Button_PLMark_Enable(True)
            Throw New Exception("[Dialog_FuncSetting.PLMark_Setting] PL Mark Setting Error ! (" & ex.Message & ")")
        End Try

    End Sub
#End Region

#Region "--- PLMark_ImageZoomAll ---"
    Public Sub PLMark_ImageZoomAll()
        Dim image As MIL_ID = M_NULL
        Dim sx As Double
        Dim sy As Double
        Dim s_Max As Double
        Dim s_Min As Double

        image = MdispInquire(Me.m_AxMDisplay_PLMark, M_SELECTED, M_NULL)
        If image = M_NULL Then Exit Sub

        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim DisplayWidth As Integer = Me.Panel_AxMDisplay_PLMark.Size.Width
        Dim DisplayHeight As Integer = Me.Panel_AxMDisplay_PLMark.Size.Height

        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

        If SizeX > 0 And SizeY > 0 Then
            sx = DisplayWidth / SizeX
            sy = DisplayHeight / SizeY
            s_Max = Math.Max(sx, sy)
            s_Min = Math.Min(sx, sy)

            'If s < 0.1 Then s = 0.1
            MIL.MdispZoom(Me.m_AxMDisplay_PLMark, s_Min, s_Min)
        End If

        'Me.ResetScrollBar()
    End Sub
#End Region


#Region "--- Calculate_PLMark_Bin_Image ---"
    Private Sub Calculate_PLMark_Bin_Image(ByVal CurrentMarkIndex As Integer, ByVal PLMarkModelRecipe As ClsPLMarkModelRecipe)

        Try
            If PLMarkModelRecipe.PMG.PMGroup.Count > 0 Then

                Dim filepath As String
                Dim SizeX, SizeY, Type As Integer

                '建立連線 ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                'Disable Button ---  
                Me.Button_PLMark_Enable(False)

                'Refresh PL Mark Pattern ---
                Try
                    Me.CheckedListBox_PLMark.Items.Clear()
                    For Each PLMark As ClsPLMark In PLMarkModelRecipe.PMG.PMGroup
                        Me.CheckedListBox_PLMark.Items.Add(PLMark.MarkName, PLMark.MarkEnable)
                    Next
                Catch ex As Exception
                    Throw New Exception("[Dialog_FuncSetting.Update_PLMark_Pattern]Refresh PL Mark Pattern Fail !( " & ex.Message & ")(" & ex.StackTrace & ")")
                End Try

                'Get Current PL Mark ---
                If Not PLMarkModelRecipe.PMG.Item(CurrentMarkIndex) Is Nothing Then
                    Me.m_CurrentPLMark = PLMarkModelRecipe.PMG.Item(CurrentMarkIndex)
                    Me.TextBox_PLMark_MarkName.Text = Me.m_CurrentPLMark.MarkName
                    Me.NumericUpDown_PLMark_DilateCount.Value = Me.m_CurrentPLMark.Mark_DilateCount

                    Me.m_Form.PaintStop = True
                    If Not Me.m_CurrentPLMark.MarkBoundary Is Nothing Then
                        Me.NumericUpDown_PLMark_BoundaryTop.Value = Me.m_CurrentPLMark.MarkBoundary.TopY
                        Me.NumericUpDown_PLMark_BoundaryBottom.Value = Me.m_CurrentPLMark.MarkBoundary.BottomY
                        Me.NumericUpDown_PLMark_BoundaryLeft.Value = Me.m_CurrentPLMark.MarkBoundary.LeftX
                        Me.NumericUpDown_PLMark_BoundaryRight.Value = Me.m_CurrentPLMark.MarkBoundary.RightX
                    End If

                    'Show PL Mark Image ---
                    filepath = PLMarkModelRecipe.PMG.Item(CurrentMarkIndex).MarkImagePath
                    If File.Exists(filepath) Then
                        MbufClear(Me.m_MainProcess.Img_PLMark_NonPage, 0L)  '2012/12/06 Rick add

                        MbufDiskInquire(Me.m_CurrentPLMark.MarkImagePath, M_SIZE_X, SizeX)
                        MbufDiskInquire(Me.m_CurrentPLMark.MarkImagePath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(Me.m_CurrentPLMark.MarkImagePath, M_TYPE, Type)

                        If Me.m_MainProcess.Img_PLMark_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.Img_PLMark_NonPage)
                                Me.m_MainProcess.Img_PLMark_NonPage = M_NULL
                                Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(filepath, Me.m_MainProcess.Img_PLMark_NonPage)

                        '--- Display PLMark Image ---
                        MdispSelectWindow(Me.m_AxMDisplay_PLMark, Me.m_MainProcess.Img_PLMark_NonPage, Me.Panel_AxMDisplay_PLMark.Handle)
                        MbufControl(Me.m_MainProcess.Img_PLMark_NonPage, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_AxMDisplay_PLMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                        Me.PLMark_ImageZoomAll()
                        Me.RadioButton_PLMark_Original.Checked = True

                        '----------------------------------------------------------------------------------------------
                        ' Set Current PL Mark  ==> Request_Command = "PLMARK_SETCURRENT" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            'Prepare Command ---
                            Request_Command = "PLMARK_SETCURRENT"
                            TimeOut = 300000 '300 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, CurrentMarkIndex, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                'Enable Button ---   
                                Me.Button_PLMark_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current PL Mark Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                                MessageBox.Show("[Dialog_FuncSetting.Update_PLMark_Pattern][PLMARK_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            'Enable Button ---  
                            Me.Button_PLMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.Update_PLMark_Pattern]Set Current PL Mark Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_FuncSetting.Update_PLMark_Pattern][PLMARK_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                End If

                'Button Control ---
                Me.Button_PLMark_Enable(True)
                Me.Update()
            End If
        Catch ex As Exception
            Me.Button_PLMark_Enable(True)
            Throw New Exception("[Dialog_GlassEdgeSetting.Update_PLMark_Pattern] Update PL Mark Pattern Error ! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- TP Mark ---"

#Region "--- Update_TPMark_Pattern ---"
    Private Sub Update_TPMark_Pattern(ByVal CurrentTPMarkIndex As Integer, ByVal TPMarkModelRecipe As ClsTPMarkModelRecipe)

        Try
            If TPMarkModelRecipe.TPG.TPMGroup.Count > 0 Then

                Dim filepath As String
                Dim SizeX, SizeY, Type As Integer

                '--- 建立連線 ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                '--- Disable Button ---  
                Me.Button_TPMark_Enable(False)

                '--- Refresh TP Mark Pattern ---
                Try
                    Me.CheckedListBox_TPMark.Items.Clear()
                    For Each TPMark As ClsTPMark In TPMarkModelRecipe.TPG.TPMGroup
                        Me.CheckedListBox_TPMark.Items.Add(TPMark.MarkName)
                    Next
                Catch ex As Exception
                    Throw New Exception("[Dialog_FuncSetting.Update_TPMark_Pattern]Refresh TP Mark Pattern Fail !( " & ex.Message & ")(" & ex.StackTrace & ")")
                End Try

                '--- Get Current TP Mark ---
                If Not TPMarkModelRecipe.TPG.Item(CurrentTPMarkIndex) Is Nothing Then
                    Me.m_CurrentTPMark = TPMarkModelRecipe.TPG.Item(CurrentTPMarkIndex)
                    Me.TextBox_TPMark_MarkName.Text = Me.m_CurrentTPMark.MarkName

                    Me.m_Form.PaintStop = True
                    If Not Me.m_CurrentTPMark.MarkBoundary Is Nothing Then
                        Me.NumericUpDown_TPMark_BoundaryTop.Value = Me.m_CurrentTPMark.MarkBoundary.TopY
                        Me.NumericUpDown_TPMark_BoundaryBottom.Value = Me.m_CurrentTPMark.MarkBoundary.BottomY
                        Me.NumericUpDown_TPMark_BoundaryLeft.Value = Me.m_CurrentTPMark.MarkBoundary.LeftX
                        Me.NumericUpDown_TPMark_BoundaryRight.Value = Me.m_CurrentTPMark.MarkBoundary.RightX
                    End If

                    '--- Show TP Mark Image ---
                    filepath = TPMarkModelRecipe.TPG.Item(CurrentTPMarkIndex).MarkImagePath
                    If File.Exists(filepath) Then
                        MbufClear(Me.m_MainProcess.Img_TPMark_NonPage, 0L)

                        MbufDiskInquire(Me.m_CurrentTPMark.MarkImagePath, M_SIZE_X, SizeX)
                        MbufDiskInquire(Me.m_CurrentTPMark.MarkImagePath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(Me.m_CurrentTPMark.MarkImagePath, M_TYPE, Type)

                        If Me.m_MainProcess.Img_TPMark_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.Img_TPMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_TPMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.Img_TPMark_NonPage)
                                Me.m_MainProcess.Img_TPMark_NonPage = M_NULL
                                Me.m_MainProcess.Img_TPMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.Img_TPMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(filepath, Me.m_MainProcess.Img_TPMark_NonPage)

                        '--- Display ---
                        MdispSelectWindow(Me.m_AxMDisplay_TPMark, Me.m_MainProcess.Img_TPMark_NonPage, Me.Panel_AxMDisplay_TPMark.Handle)
                        MbufControl(Me.m_MainProcess.Img_TPMark_NonPage, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_AxMDisplay_TPMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                        Me.TPMark_ImageZoomAll()

                        '----------------------------------------------------------------------------------------------
                        ' Set Current TP Mark  ==> Request_Command = "TPMARK_SETCURRENT" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            'Prepare Command ---
                            Request_Command = "TPMARK_SETCURRENT"
                            TimeOut = 300000 '300 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, CurrentTPMarkIndex, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                'Enable Button ---   
                                Me.Button_TPMark_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current TP Mark Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                                MessageBox.Show("[Dialog_FuncSetting.Update_TPMark_Pattern][TPMark_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            'Enable Button ---  
                            Me.Button_TPMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.Update_TPMark_Pattern]Set Current TP Mark Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_FuncSetting.Update_TPMark_Pattern][TPMark_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                End If

                '--- Button Control ---
                Me.Button_TPMark_Enable(True)
                Me.Update()
            End If
        Catch ex As Exception
            Me.Button_TPMark_Enable(True)
            Throw New Exception("[Dialog_GlassEdgeSetting.Update_TPMark_Pattern] Update TP Mark Pattern Error ! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- DrawTPMark ---"
    Private Sub DrawTPMark()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image <> M_NULL Then

            Select Case Me.m_Form.ComboBox_Type.SelectedIndex

                Case 0
                    If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        '[1] TP Mark Region ---
                        If Me.CheckBox_TPMark_ShowBoundary.Checked Then Me.DrawTPMarkRegion(0, 0)
                        '[2] TP Mark Result ---
                        If Me.CheckBox_TPMark_ShowResult.Checked Then Me.DrawTPMarkResult(0, 0)
                    End If
                Case 1
                    '[1] TP Mark Region ---
                    If Me.CheckBox_TPMark_ShowBoundary.Checked Then Me.DrawTPMarkRegion(-m_offX, -m_offY)
                    '[2] TP Mark Result ---
                    If Me.CheckBox_TPMark_ShowResult.Checked Then Me.DrawTPMarkResult(-m_offX, -m_offY)

            End Select
        End If

        Me.Update()
    End Sub
#End Region

#Region "--- DrawTPMarkRegion ---"
    Private Sub DrawTPMarkRegion(ByVal offX As Integer, ByVal offY As Integer)
        Dim rect As Rectangle
        Dim intLabelLeft As Integer
        Dim intLabelRight As Integer
        Dim intLabelTop As Integer
        Dim intLabelBottom As Integer
        Dim pb As ClsParameterBoundary
        Dim ZoomX, ZoomY As Double

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        Try
            If Me.CheckBox_TPMark_ShowBoundary.Checked Then
                '--- Initial ---
                pb = New ClsParameterBoundary
                pb.LeftX = Me.NumericUpDown_TPMark_BoundaryLeft.Value
                pb.RightX = Me.NumericUpDown_TPMark_BoundaryRight.Value
                pb.TopY = Me.NumericUpDown_TPMark_BoundaryTop.Value
                pb.BottomY = Me.NumericUpDown_TPMark_BoundaryBottom.Value

                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

                rect = New Rectangle
                If Not (pb.LeftX = 0 And pb.TopY = 0 And pb.RightX = 0 And pb.BottomY = 0) Then
                    Me.m_Pen.Color = Color.Yellow
                    Me.m_Pen.Width = ZoomX
                    intLabelLeft = (pb.LeftX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                    intLabelRight = (pb.RightX - Me.m_Form.HScrollBar.Value - offX) * ZoomX
                    intLabelTop = (pb.TopY - Me.m_Form.VScrollBar.Value - offY) * ZoomX
                    intLabelBottom = (pb.BottomY - Me.m_Form.VScrollBar.Value - offY) * ZoomX

                    rect.X = intLabelLeft
                    rect.Y = intLabelTop
                    rect.Width = intLabelRight - intLabelLeft + 1
                    rect.Height = intLabelBottom - intLabelTop + 1
                    Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
                End If
            End If

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.DrawTPMarkRegion]Draw TP Mark Region Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- DrawTPMarkResult ---"
    Private Sub DrawTPMarkResult(ByVal offX As Integer, ByVal offY As Integer)
        If Me.m_FuncProcess.TPMarkResults.Count <= 0 Then Exit Sub

        Dim rect As Rectangle
        Dim ox As Integer
        Dim oy As Integer
        Dim s As Double
        Dim i As Integer
        Dim j As Integer
        Dim mr As ClsTPMarkResult
        Dim MarkResult_Count As Integer
        Dim P1 As Point
        Dim P2 As Point
        Dim ZoomX As Double

        Try

            '--- Initial --- 
            Me.m_Form.PaintStop = True
            Me.m_Form.Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)

            rect = New Rectangle
            Me.m_Pen.Color = Color.Yellow
            ox = Me.m_Form.HScrollBar.Value - offX
            oy = Me.m_Form.VScrollBar.Value - offY

            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
            s = ZoomX
            MarkResult_Count = Me.m_FuncProcess.TPMarkResults.Count

            i = 0
            For j = 0 To MarkResult_Count - 1
                mr = Me.m_FuncProcess.TPMarkResults.Item(j)

                rect.X = (mr.PosX - ox - mr.SizeX / 2) * s
                rect.Y = (mr.PosY - oy - mr.SizeY / 2) * s
                rect.Width = mr.SizeX * s
                rect.Height = mr.SizeY * s
                Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)

                '--- 畫十字線 ---
                Me.m_Pen.Width = 2 * s
                P1.X = (mr.PosX - ox - 8) * s
                P1.Y = (mr.PosY - oy) * s
                P2.X = (mr.PosX - ox + 8) * s
                P2.Y = (mr.PosY - oy) * s
                If P1.X > 0 AndAlso P1.Y > 0 Then
                    Me.m_GraphicsImage.DrawLine(Me.m_Pen, P1, P2)
                End If

                P1.X = (mr.PosX - ox) * s
                P1.Y = (mr.PosY - oy - 8) * s
                P2.X = (mr.PosX - ox) * s
                P2.Y = (mr.PosY - oy + 8) * s
                If P1.X > 0 AndAlso P1.Y > 0 Then
                    Me.m_GraphicsImage.DrawLine(Me.m_Pen, P1, P2)
                End If

                Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
                'Me.m_Form.PaintStop = False
            Next
        Catch ex As Exception
            Throw New Exception("[Dialog_GlassEdgeSetting.DrawTPMarkResult] Draw TP Mark Result Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- TPMark_Setting ---"
    Private Sub TPMark_Setting()
        Dim Img_TPMark = M_NULL
        Dim I As Integer
        Dim boundary As New ClsParameterBoundary
        Dim bIsUpdate As Boolean
        Dim bCanWrite As Boolean
        Dim oPatternMarkTemp As New ClsTPMark
        Dim filepath As String = ""
        Dim filename As String = ""
        Dim strPath As String = ""
        Dim tpmmr As ClsTPMarkModelRecipe
        Dim Parameter_Lists As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---  
            Me.Button_TPMark_Enable(False)

            tpmmr = Me.m_FuncProcess.TPMarkModelRecipe

            '--- 設定與檢查目錄是否存在 ---
            filepath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\TPMark"
            RepairPath_2(filepath)


            '--- TP Mark Image Boundary ---
            If Me.CheckBox_TPMark_RegionMannual.Checked Then
                boundary.LeftX = Me.NumericUpDown_TPMark_BoundaryLeft.Value
                boundary.RightX = Me.NumericUpDown_TPMark_BoundaryRight.Value
                boundary.TopY = Me.NumericUpDown_TPMark_BoundaryTop.Value
                boundary.BottomY = Me.NumericUpDown_TPMark_BoundaryBottom.Value
            End If

            '--- Create New ClsTPMark ---   
            If tpmmr.TPG.Count < (Me.m_CurrentTPMarkIndex + 1) Then
                Dim New_TPMark As New ClsTPMark(Me.TextBox_TPMark_MarkName.Text)
                tpmmr.TPG.Add(New_TPMark)
            End If

            'Mark_Name ---
            tpmmr.TPG.Item(Me.m_CurrentTPMarkIndex).MarkName = Me.TextBox_TPMark_MarkName.Text
            'Mark_Acceptance ---
            tpmmr.TPG.Item(Me.m_CurrentTPMarkIndex).Mark_Acceptance = Me.NumericUpDown_TPMark_Acceptance.Value
            'Mark_Action ---
            tpmmr.TPG.Item(Me.m_CurrentTPMarkIndex).Mark_Action = Me.ComboBox_TPMark_Action.Text

            '--- Update Recipe ----
            '將參數存到Recipe Array，新圖存到實體 Path 裡面﹝如果是新增，就只管加入；如果是異動，就要更新﹞
            bIsUpdate = False
            bCanWrite = True

            If Me.m_CurrentTPMarkIndex >= 0 Then

                Me.m_CurrentTPMark = tpmmr.TPG.Item(Me.m_CurrentTPMarkIndex)

                For I = 0 To tpmmr.TPG.TPMGroup.Count - 1
                    oPatternMarkTemp = CType(tpmmr.TPG.TPMGroup(I), ClsTPMark)
                    If Me.m_CurrentTPMark.MarkName = oPatternMarkTemp.MarkName Then

                        tpmmr.TPG.TPMGroup(I).MarkName = Me.TextBox_TPMark_MarkName.Text
                        If File.Exists(filepath & "\" & Me.TextBox_TPMark_MarkName.Text & ".tif") Then
                            '[更新] ---
                            tpmmr.TPG.TPMGroup(I).MarkImagePath = filepath & "\" & Me.TextBox_TPMark_MarkName.Text & ".tif"
                            If boundary.RightX <> 0 And boundary.LeftX <> 0 And boundary.BottomY <> 0 And boundary.TopY <> 0 Then
                                tpmmr.TPG.Item(I).Mark_RefX = boundary.LeftX
                                tpmmr.TPG.Item(I).Mark_RefY = boundary.TopY
                                tpmmr.TPG.Item(I).Mark_SizeX = boundary.RightX - boundary.LeftX + 1
                                tpmmr.TPG.Item(I).Mark_SizeY = boundary.BottomY - boundary.TopY + 1
                                tpmmr.TPG.Item(I).MarkBoundary = boundary
                            End If

                            bIsUpdate = True

                            If boundary.RightX <> 0 And boundary.LeftX <> 0 And boundary.BottomY <> 0 And boundary.TopY <> 0 Then
                                '----------------------------------------------------------------------------------------------
                                ' Set Current TP Mark's Parameters  ==> Request_Command = "TPMARK_SET_PARAMETERS" (Dispatcher 1)
                                '----------------------------------------------------------------------------------------------
                                Try
                                    'Prepare Command ---
                                    Request_Command = "TPMARK_SET_PARAMETERS"
                                    TimeOut = 300000 '300 secs

                                    '--- UI Recipe Setting ---

                                    '--- 第一頁 ---
                                    Parameter_Lists = Parameter_Lists & "TPMark_MarkName," & Me.TextBox_TPMark_MarkName.Text & ";" & "TPMark_Acceptance," & Me.NumericUpDown_TPMark_Acceptance.Value & ";" & "TPMark_Action," & Me.ComboBox_TPMark_Action.Text & ";"

                                    If boundary.RightX <> 0 And boundary.LeftX <> 0 And boundary.BottomY <> 0 And boundary.TopY <> 0 Then
                                        Parameter_Lists = Parameter_Lists & "TPMark_RefX," & boundary.LeftX & ";" & "TPMark_RefY," & boundary.TopY & ";" & _
                                                                            "TPMark_SizeX," & (boundary.RightX - boundary.LeftX + 1) & ";" & "TPMark_SizeY," & (boundary.BottomY - boundary.TopY + 1) & ";" & _
                                                                            "TPMark_LeftX," & boundary.LeftX & ";" & "TPMark_TopY," & boundary.TopY & ";" & "TPMark_RightX," & boundary.RightX & ";" & "TPMark_BottomY," & boundary.BottomY & ";"
                                    End If

                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.TextBox_TPMark_MarkName.Text, Parameter_Lists, , , , , , , TimeOut)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                        Response_OK = True
                                    Else
                                        '--- Enable Button ---   
                                        Me.Button_TPMark_Enable(True)
                                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current TP Mark parameters Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                                        MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][TPMARK_SET_PARAMETERS]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        Exit Sub
                                    End If

                                Catch ex As Exception
                                    '--- Enable Button ---  
                                    Me.Button_TPMark_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Set Current TP Mark parameters Error ! (" & ex.Message & ")")
                                    MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][TPMARK_SET_PARAMETERS]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            End If
                        Else
                            '[新增] ---
                            tpmmr.TPG.TPMGroup(I).MarkImagePath = filepath & "\" & Me.TextBox_TPMark_MarkName.Text & ".tif"
                            If boundary.RightX <> 0 And boundary.LeftX <> 0 And boundary.BottomY <> 0 And boundary.TopY <> 0 Then

                                Me.CheckedListBox_TPMark.Items.Clear()
                                For Each PatternMark As ClsTPMark In tpmmr.TPG.TPMGroup
                                    Me.CheckedListBox_TPMark.Items.Add(PatternMark.MarkName, True)
                                Next

                                tpmmr.TPG.Item(I).Mark_RefX = boundary.LeftX
                                tpmmr.TPG.Item(I).Mark_RefY = boundary.TopY
                                tpmmr.TPG.Item(I).Mark_SizeX = boundary.RightX - boundary.LeftX + 1
                                tpmmr.TPG.Item(I).Mark_SizeY = boundary.BottomY - boundary.TopY + 1
                                tpmmr.TPG.Item(I).MarkBoundary = boundary

                                ClsTPMarkModelRecipe.WriteXML(tpmmr, filepath & "\TPMarkModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml")

                                '----------------------------------------------------------------------------------------------
                                ' Set Current TP Mark's Parameters  ==> Request_Command = "TPMARK_SET_PARAMETERS" (Dispatcher 1)
                                '----------------------------------------------------------------------------------------------
                                Try
                                    '--- Prepare Command ---
                                    Request_Command = "TPMARK_SET_PARAMETERS"
                                    TimeOut = 100000 '100 secs

                                    '--- UI Recipe Setting ---

                                    '--- 第一頁 ---
                                    Parameter_Lists = Parameter_Lists & "TPMark_Acceptance," & Me.NumericUpDown_TPMark_Acceptance.Value & ";" & "TPMark_Action," & Me.ComboBox_TPMark_Action.Text & ";" & _
                                                                        "TPMark_RefX," & boundary.LeftX & ";" & "TPMark_RefY," & boundary.TopY & ";" & _
                                                                        "TPMark_SizeX," & (boundary.RightX - boundary.LeftX + 1) & ";" & "TPMark_SizeY," & (boundary.BottomY - boundary.TopY + 1) & ";" & _
                                                                        "TPMark_ImagePath," & (filepath & "\" & Me.TextBox_TPMark_MarkName.Text & ".tif") & ";" & _
                                                                        "TPMark_LeftX," & boundary.LeftX & ";" & "TPMark_TopY," & boundary.TopY & ";" & "TPMark_RightX," & boundary.RightX & ";" & "TPMark_BottomY," & boundary.BottomY & ";"
                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.TextBox_TPMark_MarkName.Text, Parameter_Lists, , , , , , , TimeOut)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                        Response_OK = True
                                    Else
                                        '--- Enable Button ---   
                                        Me.Button_TPMark_Enable(True)
                                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current TP Mark parameters Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                                        MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][TPMARK_SET_PARAMETERS]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        Exit Sub
                                    End If

                                Catch ex As Exception
                                    '--- Enable Button ---  
                                    Me.Button_TPMark_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Set Current TP Mark parameters Error ! (" & ex.Message & ")")
                                    MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][TPMARK_SET_PARAMETERS]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            Else
                                bCanWrite = False
                            End If
                        End If
                    End If
                Next

                '--- Update TP Mark Image ----
                If Me.CheckBox_TPMark_RegionMannual.Checked And Me.CheckBox_TPMark_ShowBoundary.Checked Then
                    '--- 先割 TP Mark Image ---
                    If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then

                        'Save New TP Mark Image ---
                        If boundary.RightX > 0 And boundary.LeftX > 0 And boundary.BottomY > 0 And boundary.TopY > 0 Then

                            Img_TPMark = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, boundary.LeftX, boundary.TopY, boundary.RightX - boundary.LeftX + 1, boundary.BottomY - boundary.TopY + 1, M_NULL)
                            filename = filepath & "\" & Me.TextBox_TPMark_MarkName.Text & ".tif"
                            MbufSave(filename, Img_TPMark)
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP] SAVE_TPMark_IMAGE => TPMark 路徑位置" & filename)

                            '----------------------------------------------------------------------------------------------
                            ' Save TP Mark Image  ==> Request_Command = "SAVE_TPMARK_IMAGE" (Dispatcher 1)
                            '----------------------------------------------------------------------------------------------
                            Try
                                'Prepare Command ---
                                Request_Command = "SAVE_TPMARK_IMAGE"
                                TimeOut = 100000 '100 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, filename, , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---   
                                    Me.Button_TPMark_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save TP Mark Image Error !(" & SubSystemResult.ErrMessage & ")")
                                    MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMark_IMAGE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---  
                                Me.Button_TPMark_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Savec TP Mark Image Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMARK_IMAGE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Finally
                                If (Img_TPMark <> M_NULL) Then
                                    MbufFree(Img_TPMark)
                                    Img_TPMark = M_NULL
                                End If
                            End Try
                        End If
                    Else
                        MsgBox("尚未載入圖檔", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Exit Sub
                    End If
                End If

                If Not bCanWrite Then
                    If CheckedListBox_TPMark.Items.Count > 0 Then   '
                        tpmmr.TPG.TPMGroup.RemoveAt(tpmmr.TPG.TPMGroup.Count - 1)
                        Me.CheckedListBox_TPMark.Items.RemoveAt(CheckedListBox_TPMark.Items.Count - 1)
                        MsgBox("Mark Image 尚未選取，請直接刪除新增 Mark")

                        '----------------------------------------------------------------------------------------------
                        ' Delete TP Mark ==> Request_Command = "TPMARK_DELETE" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "TPMARK_DELETE"
                            TimeOut = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.TextBox_TPMark_MarkName.Text, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                '---Enable Button ---   
                                Me.Button_TPMark_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete TP Mark Error !(" & SubSystemResult.ErrMessage & ")")
                                MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][TPMARK_DELETE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            '--- Enable Button ---  
                            Me.Button_TPMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Delete TP Mark Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][TPMARK_DELETE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try

                        Me.m_CurrentTPMarkIndex = 0
                    End If
                End If

                Me.m_AddMode_TPMark = False

                strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
                RepairPath_2(strPath)
                Me.m_FuncProcess.SaveTPMarkModelRecipe(Me.m_IPBootConfig, strPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

                '----------------------------------------------------------------------------------------------
                ' Save TP Mark Model Recipe ==> Request_Command = "SAVE_TPMARK_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_TPMARK_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        '--- Enable Button ---   
                        Me.Button_TPMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save TP Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMARK_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    '--- Enable Button ---  
                    Me.Button_TPMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Save TP Mark Model Recipe Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMARK_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            Else
                MsgBox("請先點選 Mark,再進行下一步!")
            End If

            '--- Update Mura_Form Recipe ---
            strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
            RepairPath_2(strPath)
            Me.m_FuncProcess.LoadTPMarkModelRecipe(Me.m_IPBootConfig, strPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Load TP Mark Model Recipe ==> Request_Command = "LOAD_TPMARK_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "LOAD_TPMARK_MODEL_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    '--- Enable Button ---   
                    Me.Button_TPMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load PL Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][LOAD_TPMark_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                '--- Enable Button ---  
                Me.Button_TPMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Load PL Mark Model Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][LOAD_TPMark_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '--- Show PL Mark Image ---   
            filepath = Me.m_FuncProcess.TPMarkModelRecipe.TPG.Item(Me.m_CurrentTPMarkIndex).MarkImagePath
            If File.Exists(filepath) Then

                MbufDiskInquire(filepath, M_SIZE_X, SizeX)
                MbufDiskInquire(filepath, M_SIZE_Y, SizeY)
                MbufDiskInquire(filepath, M_TYPE, Type)
                If Me.m_MainProcess.Img_TPMark_NonPage <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_TPMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_TPMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_TPMark_NonPage)
                        Me.m_MainProcess.Img_TPMark_NonPage = M_NULL
                        Me.m_MainProcess.Img_TPMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_TPMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(filepath, Me.m_MainProcess.Img_TPMark_NonPage)

                '--- Display ---
                MdispSelectWindow(Me.m_AxMDisplay_TPMark, Me.m_MainProcess.Img_TPMark_NonPage, Me.Panel_AxMDisplay_TPMark.Handle)
                MbufControl(Me.m_MainProcess.Img_TPMark_NonPage, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_AxMDisplay_TPMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                Me.TPMark_ImageZoomAll()

                Me.m_Form.ResetScrollBar()

            End If

            'Button Control ---
            Me.Button_TPMark_Enable(True)
            Me.Update()
        Catch ex As Exception
            Me.Button_TPMark_Enable(True)
            Throw New Exception("[Dialog_FuncSetting.TPMark_Setting] PL Mark Setting Error ! (" & ex.Message & ")")
        End Try

    End Sub
#End Region

#Region "--- TPMark_ImageZoomAll ---"
    Public Sub TPMark_ImageZoomAll()
        Dim image As MIL_ID = M_NULL
        Dim sx As Double
        Dim sy As Double
        Dim s_Max As Double
        Dim s_Min As Double

        image = MdispInquire(Me.m_AxMDisplay_TPMark, M_SELECTED, M_NULL)
        If image = M_NULL Then Exit Sub

        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim DisplayWidth As Integer = Me.Panel_AxMDisplay_TPMark.Size.Width
        Dim DisplayHeight As Integer = Me.Panel_AxMDisplay_TPMark.Size.Height

        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

        If SizeX > 0 And SizeY > 0 Then
            sx = DisplayWidth / SizeX
            sy = DisplayHeight / SizeY
            s_Max = Math.Max(sx, sy)
            s_Min = Math.Min(sx, sy)

            'If s < 0.1 Then s = 0.1
            MIL.MdispZoom(Me.m_AxMDisplay_TPMark, s_Min, s_Min)
        End If

        'Me.ResetScrollBar()
    End Sub
#End Region

#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_Save.Text = res.GetString("Button_Save.Text")
                Button_LoadImage.Text = res.GetString("Button_LoadImage.Text")
                Button_MeanRange.Text = res.GetString("Button_MeanRange.Text")
                Button_PLMark_PatTest.Text = res.GetString("Button_PLMark_PatTest.Text")
                Button_TPMark_PatTest.Text = res.GetString("Button_TPMark_PatTest.Text")
                CheckBox_BLDP_Enable.Text = res.GetString("CheckBox_BLDP_Enable.Text")
                CheckBox_GrayAbnormal_Enable.Text = res.GetString("CheckBox_GrayAbnormal_Enable.Text")
                CheckBox_GSBP_Enable.Text = res.GetString("CheckBox_GSBP_Enable.Text")
                CheckBox_HLine_NotAddToOutput.Text = res.GetString("CheckBox_HLine_NotAddToOutput.Text")
                CheckBox_HotPixelEnable.Text = res.GetString("CheckBox_HotPixelEnable.Text")
                CheckBox_Line_Enable.Text = res.GetString("CheckBox_Line_Enable.Text")
                CheckBox_PLMark_RegionMannual.Text = res.GetString("CheckBox_PLMark_RegionMannual.Text")
                CheckBox_PLMark_ShowBoundary.Text = res.GetString("CheckBox_PLMark_ShowBoundary.Text")
                CheckBox_Point_Enable.Text = res.GetString("CheckBox_Point_Enable.Text")
                CheckBox_TPMark_Enable.Text = res.GetString("CheckBox_TPMark_Enable.Text")
                CheckBox_TPMark_RegionMannual.Text = res.GetString("CheckBox_TPMark_RegionMannual.Text")
                CheckBox_TPMark_ShowBoundary.Text = res.GetString("CheckBox_TPMark_ShowBoundary.Text")
                CheckBox_TPMark_ShowResult.Text = res.GetString("CheckBox_TPMark_ShowResult.Text")
                CheckBox_VLine_NotAddToOutput.Text = res.GetString("CheckBox_VLine_NotAddToOutput.Text")
                CheckBox_Waku_Inspect_Enable.Text = res.GetString("CheckBox_Waku_Inspect_Enable.Text")
                GroupBox_PLMark_Boundary.Text = res.GetString("GroupBox_PLMark_Boundary.Text")
                GroupBox_TPMark_Boundary.Text = res.GetString("GroupBox_TPMark_Boundary.Text")
                Label32.Text = res.GetString("Label32.Text")
                Label33.Text = res.GetString("Label33.Text")
                Label34.Text = res.GetString("Label34.Text")
                Label35.Text = res.GetString("Label35.Text")
                Label36.Text = res.GetString("Label36.Text")
                Label55.Text = res.GetString("Label55.Text")
                Label56.Text = res.GetString("Label56.Text")
                Label57.Text = res.GetString("Label57.Text")
                Label58.Text = res.GetString("Label58.Text")
                RadioButton_BP.Text = res.GetString("RadioButton_BP.Text")
                RadioButton_BPDP.Text = res.GetString("RadioButton_BPDP.Text")
                RadioButton_DP.Text = res.GetString("RadioButton_DP.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- Change ImageProcess Recipe ---"

#Region "--- Point ---"

#Region "--- Point Common Setting ---"

    Private Sub RadioButton_BP_AreaMax_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BP_AreaMax.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BP_AreaMin_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BP_AreaMin.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_AreaMax_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DP_AreaMax.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_AreaMin_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DP_AreaMin.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_Point_ByPassX_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Point_ByPassX.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_Point_ByPassY_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Point_ByPassY.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_Point_OverNum_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Point_OverNum.CheckedChanged
        UpdateNumberUpDown()
    End Sub
#End Region

#Region "--- Point Characteristics Setting ---"

#Region "--- BP Characteristics Setting ---"

    Private Sub RadioButton_BP_Elongation_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP_Elongation_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BP_Elongation_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP_Elongation_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BP_Fullness_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP_Fullness_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BP_Fullness_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP_Fullness_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BP_MaxGray_Fullness_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP_MaxGray_Fullness_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BP_GrayMean_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP_GrayMean_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BP_Compactness_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP_Compactness_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

#End Region

#Region "--- DP Characteristics Setting ---"

    Private Sub RadioButton_DP_Elongation_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_Elongation_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_Elongation_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_Elongation_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_Fullness_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_Fullness_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_Fullness_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_Fullness_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_MaxGray_Fullness_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_MaxGray_Fullness_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_GrayMean_Min_CheckedChanged(sender As System.Object, e As System.EventArgs)
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_GrayMean_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_GrayMean_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_MinGray_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_MinGray_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_StdDev_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_StdDev_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_DP_Compactness_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_DP_Compactness_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

#End Region

#End Region

#Region "--- BPoint ---"

    Private Sub RadioButton_BP_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BP_Threshold.Click
        If RadioButton_BP_Threshold.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BP_Threshold.ValueChanged
        If RadioButton_BP_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BP_Threshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BP_Threshold_Low.Click
        If RadioButton_BP_Threshold_Low.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_Threshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BP_Threshold_Low.ValueChanged
        If RadioButton_BP_Threshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BP_RimThreshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BP_RimThreshold.CheckedChanged
        If RadioButton_BP_RimThreshold.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BP_RimThreshold.ValueChanged
        If RadioButton_BP_RimThreshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BP_RimThreshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BP_RimThreshold_Low.CheckedChanged
        If RadioButton_BP_RimThreshold_Low.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_RimThreshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BP_RimThreshold_Low.ValueChanged
        If RadioButton_BP_RimThreshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

#Region "--- BP_Threshold_CheckedChanged ---"
    Private Sub BP_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        If Me.RadioButton_DP_Threshold.Checked Then Me.RadioButton_DP_Threshold.Checked = False
        If Me.RadioButton_DP_Threshold_Low.Checked Then Me.RadioButton_DP_Threshold_Low.Checked = False
        If Me.RadioButton_DP_RimThreshold.Checked Then Me.RadioButton_DP_RimThreshold.Checked = False
        If Me.RadioButton_DP_RimThreshold_Low.Checked Then Me.RadioButton_DP_RimThreshold_Low.Checked = False

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateNumberUpDown()


        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BP_Threshold_CheckedChange]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChange]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第一頁 ---
            Parameter_Lists = "BP_Threshold," & Me.NumericUpDown_BP_Threshold.Value & ";" & "BP_Threshold_Low," & Me.NumericUpDown_BP_Threshold_Low.Value & ";" & "BP_RimThreshold," & Me.NumericUpDown_BP_RimThreshold.Value & ";" & "BP_RimThreshold_Low," & Me.NumericUpDown_BP_RimThreshold_Low.Value & ";" & _
                              "DP_Threshold," & Me.NumericUpDown_DP_Threshold.Value & ";" & "DP_Threshold_Low," & Me.NumericUpDown_DP_Threshold_Low.Value & ";" & "DP_RimThreshold," & Me.NumericUpDown_DP_RimThreshold.Value & ";" & "DP_RimThreshold_Low," & Me.NumericUpDown_DP_RimThreshold_Low.Value & ";" & _
                              "BP_AreaMax," & Me.NumericUpDown_BP_AreaMax.Value & ";" & "BP_AreaMin," & Me.NumericUpDown_BP_AreaMin.Value & ";" & "DP_AreaMax," & Me.NumericUpDown_DP_AreaMax.Value & ";" & "DP_AreaMin," & Me.NumericUpDown_DP_AreaMin.Value & ";" & _
                              "Point_ByPassX," & Me.NumericUpDown_Point_ByPassX.Value & ";" & "Point_ByPassY," & Me.NumericUpDown_Point_ByPassY.Value & ";" & "Point_OverNum," & Me.NumericUpDown_Point_OverNum.Value & ";" & "Align_Enable," & Me.CheckBox_Align_Enable.Checked & ";" & _
                              "Point_Enable," & Me.CheckBox_Point_Enable.Checked & ";" & "Inverse_Point_DefectType," & Me.CheckBox_Inverse_Point_DefectType.Checked & ";" & "Inverse_Point_EnableFixArea," & Me.CheckBox_Inverse_Point_EnableFixArea.Checked & ";" & _
                              "Inverse_Point_EnableFixArea," & Me.CheckBox_Inverse_Point_EnableFixArea.Checked & ";" & "Inverse_Point_FixArea," & Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value & ";" & "Waku_Inspect_Enable," & Me.CheckBox_Waku_Inspect_Enable.Checked & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.RadioButton_BP_Threshold.Checked Or Me.RadioButton_BP_Threshold_Low.Checked Or Me.RadioButton_BP_RimThreshold.Checked Or Me.RadioButton_BP_RimThreshold_Low.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "WHITE"
                Inspect_Defect_Type = "POINT"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#End Region

#Region "--- DPoint ---"

    Private Sub RadioButton_DP_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DP_Threshold.Click
        If RadioButton_DP_Threshold.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub RadioButton_DP_Threshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DP_Threshold_Low.Click
        If RadioButton_DP_Threshold_Low.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_DP_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_DP_Threshold.ValueChanged
        If RadioButton_DP_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_DP_Threshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_DP_Threshold_Low.ValueChanged
        If RadioButton_DP_Threshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_DP_RimThreshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DP_RimThreshold.Click
        If RadioButton_DP_RimThreshold.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub RadioButton_DP_RimThreshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DP_RimThreshold_Low.Click
        If RadioButton_DP_RimThreshold_Low.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_DP_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_DP_RimThreshold.ValueChanged
        If RadioButton_DP_RimThreshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_DP_RimThreshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_DP_RimThreshold_Low.ValueChanged
        If RadioButton_DP_RimThreshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

#Region "--- DP_Threshold_CheckedChanged ---"
    Private Sub DP_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        If Me.RadioButton_BP_Threshold.Checked Then Me.RadioButton_BP_Threshold.Checked = False
        If Me.RadioButton_BP_Threshold_Low.Checked Then Me.RadioButton_BP_Threshold_Low.Checked = False
        If Me.RadioButton_BP_RimThreshold.Checked Then Me.RadioButton_BP_RimThreshold.Checked = False
        If Me.RadioButton_BP_RimThreshold_Low.Checked Then Me.RadioButton_BP_RimThreshold_Low.Checked = False

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateNumberUpDown()


        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DP_Threshold_CheckedChange]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChange]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第一頁 ---
            Parameter_Lists = "BP_Threshold," & Me.NumericUpDown_BP_Threshold.Value & ";" & "BP_Threshold_Low," & Me.NumericUpDown_BP_Threshold_Low.Value & ";" & "BP_RimThreshold," & Me.NumericUpDown_BP_RimThreshold.Value & ";" & "BP_RimThreshold_Low," & Me.NumericUpDown_BP_RimThreshold_Low.Value & ";" & _
                              "DP_Threshold," & Me.NumericUpDown_DP_Threshold.Value & ";" & "DP_Threshold_Low," & Me.NumericUpDown_DP_Threshold_Low.Value & ";" & "DP_RimThreshold," & Me.NumericUpDown_DP_RimThreshold.Value & ";" & "DP_RimThreshold_Low," & Me.NumericUpDown_DP_RimThreshold_Low.Value & ";" & _
                              "BP_AreaMax," & Me.NumericUpDown_BP_AreaMax.Value & ";" & "BP_AreaMin," & Me.NumericUpDown_BP_AreaMin.Value & ";" & "DP_AreaMax," & Me.NumericUpDown_DP_AreaMax.Value & ";" & "DP_AreaMin," & Me.NumericUpDown_DP_AreaMin.Value & ";" & _
                              "Point_ByPassX," & Me.NumericUpDown_Point_ByPassX.Value & ";" & "Point_ByPassY," & Me.NumericUpDown_Point_ByPassY.Value & ";" & "Point_OverNum," & Me.NumericUpDown_Point_OverNum.Value & ";" & "Align_Enable," & Me.CheckBox_Align_Enable.Checked & ";" & _
                              "Point_Enable," & Me.CheckBox_Point_Enable.Checked & ";" & "Inverse_Point_DefectType," & Me.CheckBox_Inverse_Point_DefectType.Checked & ";" & "Inverse_Point_EnableFixArea," & Me.CheckBox_Inverse_Point_EnableFixArea.Checked & ";" & _
                              "Inverse_Point_FixArea," & Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value & ";" & "Waku_Inspect_Enable," & Me.CheckBox_Waku_Inspect_Enable.Checked & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.RadioButton_DP_Threshold.Checked Or Me.RadioButton_DP_Threshold_Low.Checked Or Me.RadioButton_DP_RimThreshold.Checked Or Me.RadioButton_DP_RimThreshold_Low.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "BLACK"
                Inspect_Defect_Type = "POINT"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        End If
    End Sub
#End Region

#End Region

#Region "--- GSBP Common Setting ---"

    Private Sub RadioButton_GSBP_AreaMax_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_AreaMax.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_AreaMin_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_AreaMin.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_Count_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_Count_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_RangeX_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_RangeX.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_RangeY_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_RangeY.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_Scratch_Length_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_Scratch_Length.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_OverNum_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_OverNum.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_NumOfHoles_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_NumOfHoles.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_GrayMax_High_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_GrayMax_High.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_GSBP_GrayMax_Low_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_GSBP_GrayMax_Low.CheckedChanged
        UpdateNumberUpDown()
    End Sub

#End Region

#Region "--- BLDP Common Setting ---"

    Private Sub RadioButton_BLDP_AreaMax_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_AreaMax.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_AreaMin_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_AreaMin.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_Count_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_Count_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_RangeX_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_RangeX.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_RangeY_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_RangeY.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_Scratch_Length_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_Scratch_Length.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_OverNum_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_OverNum.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_Fatness_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_Fatness_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_Elongation_Min_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_Elongation_Min.CheckedChanged
        UpdateNumberUpDown()
    End Sub

    Private Sub RadioButton_BLDP_Elongation_Max_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BLDP_Elongation_Max.CheckedChanged
        UpdateNumberUpDown()
    End Sub

#End Region

#Region "--- GSBP ---"

    Private Sub RadioButton_GSBP_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_GSBP_Threshold.Click
        If RadioButton_GSBP_Threshold.Checked Then Call GSBP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_GSBP_Threshold_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_GSBP_Threshold.ValueChanged
        If RadioButton_GSBP_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call GSBP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_GSBP_RimThreshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_GSBP_RimThreshold.Click
        If RadioButton_GSBP_RimThreshold.Checked Then Call GSBP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_GSBP_ThresholdRim_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_GSBP_ThresholdRim.ValueChanged
        If RadioButton_GSBP_RimThreshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call GSBP_Threshold_CheckedChanged()
        End If
    End Sub

#Region "--- GSBP_Threshold_CheckedChanged ---"
    Private Sub GSBP_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateNumberUpDown()


        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BP_Threshold_CheckedChange]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChange]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第三頁 ---
            Parameter_Lists = "GSBP_Threshold," & Me.NumericUpDown_GSBP_Threshold.Value & ";" & "GSBP_ThresholdRim," & Me.NumericUpDown_GSBP_ThresholdRim.Value & ";" & "GSBP_Enable," & Me.CheckBox_GSBP_Enable.Checked & ";" & _
                              "GSBP_AreaMax," & Me.NumericUpDown_GSBP_AreaMax.Value & ";" & "GSBP_AreaMin," & Me.NumericUpDown_GSBP_AreaMin.Value & ";" & "GSBP_Count_Min," & Me.NumericUpDown_GSBP_Count_Min.Value & ";" & _
                              "GSBP_RangeX," & Me.NumericUpDown_GSBP_RangeX.Value & ";" & "GSBP_RangeY," & Me.NumericUpDown_GSBP_RangeY.Value & ";" & "GSBP_Scratch_Length," & Me.NumericUpDown_GSBP_Scratch_Length.Value & ";" & "GSBP_OverNum," & Me.NumericUpDown_GSBP_OverNum.Value & ";"
            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.GSBP_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.GSBP_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.GSBP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.RadioButton_GSBP_Threshold.Checked Or Me.RadioButton_GSBP_RimThreshold.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "WHITE"
                Inspect_Defect_Type = "GSBP"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.GSBP_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.GSBP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#End Region

#Region "--- BLDP ---"

    Private Sub RadioButton_BLDP_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BLDP_Threshold.Click
        If RadioButton_BLDP_Threshold.Checked Then Call BLDP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BLDP_Threshold_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_BLDP_Threshold.ValueChanged
        If RadioButton_BLDP_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BLDP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BLDP_RimThreshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BLDP_RimThreshold.Click
        If RadioButton_BLDP_RimThreshold.Checked Then Call BLDP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BLDP_ThresholdRim_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BLDP_ThresholdRim.ValueChanged
        If RadioButton_BLDP_RimThreshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BLDP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BLDP_EnhanceCount_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BLDP_EnhanceCount.Click
        If RadioButton_BLDP_EnhanceCount.Checked Then Call BLDP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub
    Private Sub NumericUpDown_BLDP_EnhanceCount_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BLDP_EnhanceCount.ValueChanged
        If RadioButton_BLDP_EnhanceCount.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BLDP_Threshold_CheckedChanged()
        End If
    End Sub

#Region "--- BLDP_Threshold_CheckedChanged ---"
    Private Sub BLDP_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateNumberUpDown()


        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BP_Threshold_CheckedChange]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChange]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第三頁 ---
            Parameter_Lists = "BLDP_Threshold," & Me.NumericUpDown_BLDP_Threshold.Value & ";" & "BLDP_ThresholdRim," & Me.NumericUpDown_BLDP_ThresholdRim.Value & ";" & "BLDP_Enable," & Me.CheckBox_BLDP_Enable.Checked & ";" & "BLDP_EnhanceCount," & Me.NumericUpDown_BLDP_EnhanceCount.Value & ";" & _
                              "BLDP_AreaMax," & Me.NumericUpDown_BLDP_AreaMax.Value & ";" & "BLDP_AreaMin," & Me.NumericUpDown_BLDP_AreaMin.Value & ";" & "BLDP_Count_Min," & Me.NumericUpDown_BLDP_Count_Min.Value & ";" & _
                              "BLDP_RangeX," & Me.NumericUpDown_BLDP_RangeX.Value & ";" & "BLDP_RangeY," & Me.NumericUpDown_BLDP_RangeY.Value & ";" & "BLDP_Scratch_Length," & Me.NumericUpDown_BLDP_Scratch_Length.Value & ";" & "BLDP_OverNum," & Me.NumericUpDown_BLDP_OverNum.Value & ";" & "BLDP_Fatness_Min," & Me.NumericUpDown_BLDP_Fatness_Min.Value & ";" & _
                              "BLDP_Elongation_Min," & Me.NumericUpDown_BLDP_Elongation_Min.Value & ";" & "BLDP_Elongation_Max," & Me.NumericUpDown_BLDP_Elongation_Max.Value & ";"
            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.BLDP_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BLDP_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.BLDP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.RadioButton_BLDP_Threshold.Checked Or Me.RadioButton_BLDP_RimThreshold.Checked Or Me.RadioButton_BLDP_EnhanceCount.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "BLACK"
                Inspect_Defect_Type = "BLDP"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.BLDP_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.BLDP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#End Region

#Region "--- HotPixel ---"

    Private Sub RadioButton_HotPixel_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_HotPixel_Threshold.Click
        If RadioButton_HotPixel_Threshold.Checked Then Call HotPixel_Threshold_CheckedChanged()
    End Sub

    Private Sub TrackBar_HotPixel_Threshold_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_HotPixel_Threshold.MouseUp
        Me.NumericUpDown_HotPixelRecipe.Value = Me.TrackBar_HotPixel_Threshold.Value
        HotPixel_Threshold_CheckedChanged()
    End Sub

    Private Sub NumericUpDown_HotPixelRecipe_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_HotPixelRecipe.ValueChanged
        Me.TrackBar_HotPixel_Threshold.Value = Me.NumericUpDown_HotPixelRecipe.Value
        HotPixel_Threshold_CheckedChanged()
    End Sub

    Private Sub HotPixel_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateNumberUpDown()


        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DP_Threshold_CheckedChange]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChange]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第七頁 ---
            Parameter_Lists = "HotPixelRecipe," & Me.NumericUpDown_HotPixelRecipe.Value & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.RadioButton_HotPixel_Threshold.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "HotPixel"
                Inspect_Defect_Type = "HotPixel"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        ' Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

                Me.m_Form.ComboBox_Type.SelectedIndex = 1
                Me.m_Form.ComboBox_Select.SelectedIndex = 18

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        End If
    End Sub

#End Region

#End Region

#Region "--- Line ---"

#Region "--- Line Common Setting ---"
    Private Sub RadioButton_Line_ByPassUpH_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_ByPassUpH.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_ByPassDownH_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_ByPassDownH.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_ByPassLeftV_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_ByPassLeftV.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_ByPassrRightV_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_ByPassRightV.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_Cut_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_Cut.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_ShortCut_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_ShortCut.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_Cut_H_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_Cut_H.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_ShortCut_H_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_ShortCut_H.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Line_OverNum_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Line_OverNum.CheckedChanged
        UpdateNumberUpDown()
    End Sub
    Private Sub RadioButton_Block_OverNum_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Block_OverNum.CheckedChanged
        UpdateNumberUpDown()
    End Sub
#End Region

#Region "--- Dark-Line ---"
    Private Sub RadioButton_DL_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_DL_Threshold.CheckedChanged
        If Me.RadioButton_DL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DLine_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_DL_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_DL_Threshold.ValueChanged
        If Me.RadioButton_DL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Me.TrackBar_DL_Threshold.Value = Me.NumericUpDown_DL_Threshold.Value
            Call DLine_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub TrackBar_DL_Threshold_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_DL_Threshold.MouseUp
        NumericUpDown_DL_Threshold.Value = TrackBar_DL_Threshold.Value
    End Sub

    Private Sub RadioButton_DL_Threshold_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton_DL_Threshold.Click
        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub DLine_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String = ""
        Dim SizeX, SizeY, Type As Integer


        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateNumberUpDown()

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 10000 '10 secs

            'UI Recipe Setting -----------------------------------

            '--- 第二頁 ---
            Parameter_Lists = Parameter_Lists & "DL_Threshold," & Me.NumericUpDown_DL_Threshold.Value & ";" & "BL_Threshold," & Me.NumericUpDown_BL_Threshold.Value & ";" & "DL_RimThreshold," & Me.NumericUpDown_DL_RimThreshold.Value & ";" & "BL_RimThreshold," & Me.NumericUpDown_BL_RimThreshold.Value & ";" & _
                                                "Line_ByPassH," & Me.NumericUpDown_Line_ByPassUpH.Value & ";" & "Line_ByPassV," & Me.NumericUpDown_Line_ByPassDownH.Value & ";" & _
                                                "Line_Cut," & Me.NumericUpDown_Line_Cut.Value & ";" & "Line_Short_Cut," & Me.NumericUpDown_Line_Short_Cut.Value & ";" & _
                                                "Line_OverNumber," & Me.NumericUpDown_Line_OverNumber.Value & ";" & "Block_OverNumber," & Me.NumericUpDown_Block_OverNumber.Value & ";" & _
                                                "MeanDifference," & Me.NumericUpDown_MeanDifference.Value & ";" & "Line_Enable," & Me.CheckBox_Line_Enable.Checked & ";" & _
                                                "HLine_NotAddToOutput," & Me.CheckBox_HLine_NotAddToOutput.Checked & ";" & "VLine_NotAddToOutput," & Me.CheckBox_VLine_NotAddToOutput.Checked & ";" & "Filter_VH_Scratch," & Me.CheckBox_Filter_VH_Scratch.Checked & ";" & "Line_Elongation_Min," & Me.NumericUpDown_Line_Elongation_Min.Value & ";" & _
                                                "HalfScreen_Enable," & Me.CheckBox_HalfScreen_Enable.Checked & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.RadioButton_DL_Threshold.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "BLACK"
                Inspect_Defect_Type = "LINE"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        End If
    End Sub
#End Region

#Region "--- Bright-Line ---"
    Private Sub RadioButton_BL_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_BL_Threshold.CheckedChanged
        If Me.RadioButton_BL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BLine_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_BL_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BL_Threshold.ValueChanged
        If Me.RadioButton_BL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Me.TrackBar_BL_Threshold.Value = Me.NumericUpDown_BL_Threshold.Value
            Call BLine_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub TrackBar_BL_Threshold_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_BL_Threshold.MouseUp
        NumericUpDown_BL_Threshold.Value = TrackBar_BL_Threshold.Value
    End Sub

    Private Sub RadioButton_BL_Threshold_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles RadioButton_BL_Threshold.Click
        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub BLine_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateNumberUpDown()

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 10000 '10 secs

            'UI Recipe Setting -----------------------------------

            '--- 第二頁 ---
            Parameter_Lists = Parameter_Lists & "DL_Threshold," & Me.NumericUpDown_DL_Threshold.Value & ";" & "BL_Threshold," & Me.NumericUpDown_BL_Threshold.Value & ";" & "DL_RimThreshold," & Me.NumericUpDown_DL_RimThreshold.Value & ";" & "BL_RimThreshold," & Me.NumericUpDown_BL_RimThreshold.Value & ";" & _
                                                "Line_H_Threshold," & Me.NumericUpDown_Line_ByPassUpH.Value & ";" & "LINE_BYPASSV," & Me.NumericUpDown_Line_ByPassDownH.Value & ";" & _
                                                "LINE_BYPASSH," & Me.NumericUpDown_Line_ByPassUpH.Value & ";" & "LINE_BYPASSV," & Me.NumericUpDown_Line_ByPassDownH.Value & ";" & _
                                                "Line_Cut," & Me.NumericUpDown_Line_Cut.Value & ";" & "Line_Short_Cut," & Me.NumericUpDown_Line_Short_Cut.Value & ";" & _
                                                "Line_OverNumber," & Me.NumericUpDown_Line_OverNumber.Value & ";" & "Block_OverNumber," & Me.NumericUpDown_Block_OverNumber.Value & ";" & _
                                                "MeanDifference," & Me.NumericUpDown_MeanDifference.Value & ";" & "Line_Enable," & Me.CheckBox_Line_Enable.Checked & ";" & _
                                                "HLine_NotAddToOutput," & Me.CheckBox_HLine_NotAddToOutput.Checked & ";" & "VLine_NotAddToOutput," & Me.CheckBox_VLine_NotAddToOutput.Checked & ";" & "Filter_VH_Scratch," & Me.CheckBox_Filter_VH_Scratch.Checked & ";" & "Line_Elongation_Min," & Me.NumericUpDown_Line_Elongation_Min.Value & ";" & _
                                                "HalfScreen_Enable," & Me.CheckBox_HalfScreen_Enable.Checked & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
        End Try


        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.RadioButton_BL_Threshold.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "WHITE"
                Inspect_Defect_Type = "LINE"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        End If

    End Sub
#End Region

#Region "--- Boundary Line Thread ---"

    Private Sub TrackBar_DL_RimThreshold_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_DL_RimThreshold.MouseUp
        NumericUpDown_DL_RimThreshold.Value = TrackBar_DL_RimThreshold.Value
    End Sub
    Private Sub TrackBar_BL_RimThreshold_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_BL_RimThreshold.MouseUp
        NumericUpDown_BL_RimThreshold.Value = TrackBar_BL_RimThreshold.Value
    End Sub

    Private Sub NumericUpDown_DL_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_DL_RimThreshold.ValueChanged
        If Me.RadioButton_DL_Threshold.Checked Then
            TrackBar_DL_RimThreshold.Value = NumericUpDown_DL_RimThreshold.Value
            Call DLine_Threshold_CheckedChanged()
        End If
    End Sub
    Private Sub NumericUpDown_BL_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_BL_RimThreshold.ValueChanged
        If Me.RadioButton_BL_Threshold.Checked Then
            TrackBar_BL_RimThreshold.Value = NumericUpDown_BL_RimThreshold.Value
            Call BLine_Threshold_CheckedChanged()
        End If
    End Sub

#End Region

#Region "--- Block ---"

    Private Sub TrackBar_MeanDifference_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_MeanDifference.MouseUp
        NumericUpDown_MeanDifference.Value = TrackBar_MeanDifference.Value
    End Sub

    Private Sub NumericUpDown_MeanDifference_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_MeanDifference.ValueChanged
        TrackBar_MeanDifference.Value = NumericUpDown_MeanDifference.Value
    End Sub

    Private Sub Button_MeanRange_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MeanRange.Click
        Dim Mean_min As Integer = 0
        Dim Mean_max As Integer = 0
        Dim fpr As ClsFuncPatternRecipe

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count
            '----------------------------------------------------------------------------------------------
            ' [Func]Calculate Half Screen Defect ==> Request_Command = "CALCULATE_HSI" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------

            Me.CheckPattern()
            If Me.m_FuncProcess.Img_Original_NonPage = M_NULL Then
                MsgBox("影像未載入。", , "[AreaGrabber]")
                Exit Sub
            End If

            Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)

            '--- Prepare Command ---
            TimeOut = 200000 '200 secs
            Request_Command = "CALCULATE_HSI"

            fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, fpr.PatternName.Value, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Mean_min = SubSystemResult.Responses(0).Param2
                Mean_max = SubSystemResult.Responses(0).Param3
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Half Screen Defect Error! (" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.Button_MeanRange_Click]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            MsgBox("[計算結果] Mean max - Mean min = " & Mean_max & " - " & Mean_min & " = " & (Mean_max - Mean_min), , "[AreaGrabber]")

        Catch ex As Exception
            MsgBox("計算失敗。(" & ex.Message & ")", MsgBoxStyle.Critical, "[AreaGrabber]")
        End Try
    End Sub

#End Region

#End Region


#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_Point_Enable_CheckedChanged ---"
    Private Sub CheckBox_Point_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Point_Enable.CheckedChanged
        Dim fpr As ClsFuncPatternRecipe

        Me.CheckPattern()
        fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
        fpr.PointEnable.Value = CheckBox_Point_Enable.Checked

        Me.GroupBox_PointMode.Enabled = Me.CheckBox_Point_Enable.Checked
        Me.GroupBox_SeparateBP.Enabled = Me.CheckBox_Point_Enable.Checked
        Me.CheckBox_Report_Multi_Pixel.Enabled = Me.CheckBox_Point_Enable.Checked
        Me.CheckBox_Align_Enable.Enabled = Me.CheckBox_Point_Enable.Checked
        Me.CheckBox_Waku_Inspect_Enable.Enabled = Me.CheckBox_Point_Enable.Checked

        If Me.CheckBox_Point_Enable.Checked Then
            Me.GroupBox_PointCommonSetting.Enabled = True
            If RadioButton_BP.Checked Then
                GroupBox_BPoint.Enabled = True
                GroupBox_DPoint.Enabled = False
                fpr.AnalysisBP.Value = True
                fpr.AnalysisDP.Value = False
            End If
            If RadioButton_DP.Checked Then
                GroupBox_BPoint.Enabled = False
                GroupBox_DPoint.Enabled = True
                fpr.AnalysisDP.Value = True
                fpr.AnalysisBP.Value = False
            End If
            If RadioButton_BPDP.Checked = True Then
                GroupBox_BPoint.Enabled = True
                GroupBox_DPoint.Enabled = True
                fpr.AnalysisBP.Value = True
                fpr.AnalysisDP.Value = True
            End If
            Me.GroupBox_PointPitchSetting.Enabled = True
        Else
            Me.GroupBox_PointCommonSetting.Enabled = False
            Me.GroupBox_BPoint.Enabled = False
            Me.GroupBox_DPoint.Enabled = False
            Me.GroupBox_PointPitchSetting.Enabled = False
        End If

    End Sub
#End Region

#Region "--- CheckBox_GSBP_Enable_CheckedChanged ---"
    Private Sub CheckBox_GSBP_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_GSBP_Enable.CheckedChanged
        Dim fpr As ClsFuncPatternRecipe

        Me.CheckPattern()
        fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
        fpr.AnalysisGSBP.Value = CheckBox_GSBP_Enable.Checked

        Me.GroupBox_GSBP.Enabled = Me.CheckBox_GSBP_Enable.Checked
        Me.GroupBox_GSBPCommonSetting.Enabled = Me.CheckBox_GSBP_Enable.Checked
    End Sub
#End Region

#Region "--- CheckBox_BLDP_Enable_CheckedChanged ---"
    Private Sub CheckBox_BLDP_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_BLDP_Enable.CheckedChanged
        Dim fpr As ClsFuncPatternRecipe

        Me.CheckPattern()
        fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
        fpr.AnalysisBLDP.Value = CheckBox_BLDP_Enable.Checked

        Me.GroupBox_BLDP.Enabled = Me.CheckBox_BLDP_Enable.Checked
        Me.GroupBox_BLDPCommonSetting.Enabled = Me.CheckBox_BLDP_Enable.Checked
    End Sub
#End Region

#Region "--- CheckBox_Line_Enable_CheckedChanged ---"
    Private Sub CheckBox_Line_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Line_Enable.CheckedChanged

        Me.CheckPattern()
        Me.m_FuncProcess.CurrentFuncPatternRecipe.LineEnable.Value = CheckBox_Line_Enable.Checked

        Me.CheckBox_BLine_Enable.Enabled = Me.CheckBox_Line_Enable.Checked
        Me.CheckBox_DLine_Enable.Enabled = Me.CheckBox_Line_Enable.Checked
        Me.CheckBox_HalfScreen_Enable.Enabled = Me.CheckBox_Line_Enable.Checked
        Me.GroupBox_LineCommonSetting.Enabled = Me.CheckBox_Line_Enable.Checked

        Me.CheckBox_HLine_NotAddToOutput.Enabled = CheckBox_Line_Enable.Checked
        Me.CheckBox_VLine_NotAddToOutput.Enabled = CheckBox_Line_Enable.Checked
        Me.CheckBox_Filter_VH_Scratch.Enabled = CheckBox_Line_Enable.Checked
        If Not CheckBox_Line_Enable.Checked Then Me.CheckBox_HLine_NotAddToOutput.Checked = False
    End Sub
#End Region

#Region "--- CheckBox_GrayAbnormal_Enable_CheckedChanged ---"
    Private Sub CheckBox_GrayAbnormal_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_GrayAbnormal_Enable.CheckedChanged
        Me.CheckPattern()
        Me.m_FuncProcess.CurrentFuncPatternRecipe.GrayAbnormalEnable.Value = Me.CheckBox_GrayAbnormal_Enable.Checked
        Me.GroupBox_GrayAbnormal.Enabled = CheckBox_GrayAbnormal_Enable.Checked
    End Sub
#End Region

#Region "--- CheckBox_CurrentPLMark_CheckedChanged ---"
    Private Sub CheckBox_CurrentPLMark_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_CurrentPLMark_Enable.CheckedChanged
        Dim CurrentPLMark As Boolean = False

        CurrentPLMark = Me.CheckBox_CurrentPLMark_Enable.Checked
        Me.CheckBox_PLMark_ShowBoundary.Enabled = CurrentPLMark
        Me.CheckBox_PLMark_RegionMannual.Enabled = CurrentPLMark
        Me.GroupBox_PLMark_Setting.Enabled = CurrentPLMark
        Me.Button_PLMark_PatTest.Enabled = CurrentPLMark
        Me.NumericUpDown_MarkTH.Enabled = CurrentPLMark

    End Sub
#End Region

#Region "--- CheckBox_TPMark_Enable_CheckedChanged ---"
    Private Sub CheckBox_TPMark_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_TPMark_Enable.CheckedChanged
        Dim TPMark_Enable As Boolean = False

        TPMark_Enable = Me.m_IPBootConfig.TPMarkUI.Value And Me.CheckBox_TPMark_Enable.Checked

        Me.CheckedListBox_TPMark.Enabled = TPMark_Enable
        Me.GroupBox_TPMark_Setting.Enabled = TPMark_Enable
        Me.Button_TPMark_PatTest.Enabled = TPMark_Enable
        Me.Button_Save_TPMark.Enabled = TPMark_Enable
        Me.CheckBox_TPMark_ShowResult.Enabled = TPMark_Enable

    End Sub
#End Region

#Region "--- CheckBox_Filter_VH_Scratch_CheckedChanged ---"
    Private Sub CheckBox_Filter_VH_Scratch_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_Filter_VH_Scratch.CheckedChanged
        Me.NumericUpDown_Line_Elongation_Min.Enabled = CheckBox_Filter_VH_Scratch.Checked
    End Sub
#End Region

#Region "--- CheckBox_SeparateBPEnbale_CheckedChanged ---"
    Private Sub CheckBox_SeparateBPEnable_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_SeparateBPEnable.CheckedChanged
        If Me.CheckBox_SeparateBPEnable.Checked = True Then
            Me.NumericUpDown_SeparateBPArea.Enabled = True
            Me.NumericUpDown_SeparateBPBlob.Enabled = True
        Else
            Me.NumericUpDown_SeparateBPArea.Enabled = False
            Me.NumericUpDown_SeparateBPBlob.Enabled = False
        End If

    End Sub
#End Region

#End Region

#Region "--- ComboBox Event ---"

#Region "--- ComboBox_Pattern_SelectedIndexChanged ---"
    Private Sub ComboBox_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Pattern.SelectedIndexChanged
        Dim PatternName As String
        Dim Parameter_Lists As String = ""

        Try
            '--- Button Control ---   
            Button_Enable(False)

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                '--- Button Control ---   
                Button_Enable(True)
                Exit Sub
            End If

            Try
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count
                Me.UpdateData()
                Me.UpdateUserLevel()
            Catch ex As Exception
                Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message)
                MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 300000 '300 secs

                '--- PatternName ---
                PatternName = Me.ComboBox_Pattern.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Button_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                Button_Enable(True)
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_FUNCSETTING_SETTING"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------

                '--- Other ---
                If Me.ComboBox_Pattern.Text <> "" Then
                    Parameter_Lists = Parameter_Lists & "PatternName," & Me.ComboBox_Pattern.Text & ";"
                End If

                '--- 第一頁 ---
                Parameter_Lists = "BPDP," & Me.RadioButton_BPDP.Checked & ";" & "BP," & Me.RadioButton_BP.Checked & ";" & "DP," & Me.RadioButton_DP.Checked & ";"

                If Me.RadioButton_PointAlgorithm_0.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_0," & Me.RadioButton_PointAlgorithm_0.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_1.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_1," & Me.RadioButton_PointAlgorithm_1.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_2.Checked Then 'v2012.09.05
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_2," & Me.RadioButton_PointAlgorithm_2.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_3.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_3," & Me.RadioButton_PointAlgorithm_3.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_4.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_4," & Me.RadioButton_PointAlgorithm_4.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_5.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_5," & Me.RadioButton_PointAlgorithm_5.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_6.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_6," & Me.RadioButton_PointAlgorithm_6.Checked & ";"
                End If

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Button Control ---   
            Button_Enable(True)
            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & ex.Message)
            MessageBox.Show("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- ComboBox_WakuEdge SelectedIndexChanged"
    Private Sub ComboBox_WakuEdge_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_WakuEdge.SelectedIndexChanged
        Dim edgeName As String = Me.ComboBox_WakuEdge.Text
        Dim fpr As ClsFuncPatternRecipe = Me.m_FuncProcess.CurrentFuncPatternRecipe

        Select Case edgeName.ToUpper
            Case "TOP"
                Me.NumericUpDown_WakuMinValue.Value = fpr.TopWakuValueMin.Value
                Me.NumericUpDown_WakuMaxValue.Value = fpr.TopWakuValueMax.Value
            Case "BOTTOM"

                Me.NumericUpDown_WakuMinValue.Value = fpr.BottomWakuValueMin.Value
                Me.NumericUpDown_WakuMaxValue.Value = fpr.BottomWakuValueMax.Value
            Case "LEFT"
                Me.NumericUpDown_WakuMinValue.Value = fpr.LeftWakuValueMin.Value
                Me.NumericUpDown_WakuMaxValue.Value = fpr.LeftWakuValueMax.Value
            Case "RIGHT"
                Me.NumericUpDown_WakuMinValue.Value = fpr.RightWakuValueMin.Value
                Me.NumericUpDown_WakuMaxValue.Value = fpr.RightWakuValueMax.Value
        End Select
    End Sub

#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- OK_Button_Click ---"
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
            Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        End If
    End Sub
#End Region

#Region "--- Cancel_Button_Click ---"
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
#End Region

#Region "--- Button_Save_Click ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        If Me.m_Form.ComboBox_CCD.SelectedIndex = -1 Then
            MessageBox.Show("[Dialog_FuncSetting.Button_Save]請先選擇 IP No , 才能進行儲存", "警告", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Me.m_Form.PaintStop = True

        If MsgBox("是否儲存Recipe參數？", MsgBoxStyle.OkCancel, "[ IP" & Me.m_MainProcess.CCDNo & " ]") = MsgBoxResult.Cancel Then
            Exit Sub
        End If

        Dim i As Integer
        Dim dir As String
        Dim strs() As String = {""}
        Dim str As String
        Dim Parameter_Lists As String = ""

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Me.Setting()
            '----------------------------------------------------------------------------------------------
            ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_FUNCSETTING_SETTING"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------
                '--- Func Pattern Recipe --- 20191126
                Dim fpr As ClsFuncPatternRecipe = Me.m_FuncProcess.CurrentFuncPatternRecipe


                'Other ---
                If Me.ComboBox_Pattern.Text <> "" Then
                    Parameter_Lists = Parameter_Lists & "PatternName," & Me.ComboBox_Pattern.Text & ";"
                End If

                '--- 第一頁(Point) ---
                Parameter_Lists = "BP_Threshold," & Me.NumericUpDown_BP_Threshold.Value & ";" & "BP_Threshold_Low," & Me.NumericUpDown_BP_Threshold_Low.Value & ";" & "BP_RimThreshold," & Me.NumericUpDown_BP_RimThreshold.Value & ";" & "BP_RimThreshold_Low," & Me.NumericUpDown_BP_RimThreshold_Low.Value & ";" & _
                                  "DP_Threshold," & Me.NumericUpDown_DP_Threshold.Value & ";" & "DP_Threshold_Low," & Me.NumericUpDown_DP_Threshold_Low.Value & ";" & "DP_RimThreshold," & Me.NumericUpDown_DP_RimThreshold.Value & ";" & "DP_RimThreshold_Low," & Me.NumericUpDown_DP_RimThreshold_Low.Value & ";" & _
                                  "BPDP," & Me.RadioButton_BPDP.Checked & ";" & "BP," & Me.RadioButton_BP.Checked & ";" & "DP," & Me.RadioButton_DP.Checked & ";" & _
                                  "BP_AreaMax," & Me.NumericUpDown_BP_AreaMax.Value & ";" & "BP_AreaMin," & Me.NumericUpDown_BP_AreaMin.Value & ";" & "DP_AreaMax," & Me.NumericUpDown_DP_AreaMax.Value & ";" & "DP_AreaMin," & Me.NumericUpDown_DP_AreaMin.Value & ";" & _
                                  "Point_ByPassX," & Me.NumericUpDown_Point_ByPassX.Value & ";" & "Point_ByPassY," & Me.NumericUpDown_Point_ByPassY.Value & ";" & "Point_OverNum," & Me.NumericUpDown_Point_OverNum.Value & ";" & "Report_Multi_Pixel," & Me.CheckBox_Report_Multi_Pixel.Checked & ";" & "Align_Enable," & Me.CheckBox_Align_Enable.Checked & ";" & _
                                  "Point_Enable," & Me.CheckBox_Point_Enable.Checked & ";" & "Inverse_Point_DefectType," & Me.CheckBox_Inverse_Point_DefectType.Checked & ";" & "Inverse_Point_EnableFixArea," & Me.CheckBox_Inverse_Point_EnableFixArea.Checked & ";" & _
                                  "Inverse_Point_FixArea," & Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value & ";" & "CPDEnable," & Me.CheckBox_CPD_Enable.Checked & ";" & _
                                  "SeparateBPEnable," & Me.CheckBox_SeparateBPEnable.Checked & ";" & "SeparateBPArea," & Me.NumericUpDown_SeparateBPArea.Value & ";" & "SeparateBPBlob," & Me.NumericUpDown_SeparateBPBlob.Value & ";" & _
                                  "EnableLeakPoint," & Me.CheckBox_EnableLeakPoint.Checked & ";" & "Waku_Inspect_Enable," & Me.CheckBox_Waku_Inspect_Enable.Checked & ";" & "WakuSplitNum," & fpr.WakuSplitNum.Value & ";" & "WakuEdgeWidth," & fpr.WakuEdgeWidth.Value & ";" & "WakuEdgeOffset," & fpr.WakuEdgeOffset.Value & ";" & _
                                  "Top_Waku_Value_Min," & fpr.TopWakuValueMin.Value & ";" & "Top_Waku_Value_Max," & fpr.TopWakuValueMax.Value & ";" & "Bottom_Waku_Value_Min," & fpr.BottomWakuValueMin.Value & ";" & "Bottom_Waku_Value_Max," & fpr.BottomWakuValueMax.Value & ";" & _
                                  "Left_Waku_Value_Min," & fpr.LeftWakuValueMin.Value & ";" & "Left_Waku_Value_Max," & fpr.LeftWakuValueMax.Value & ";" & "Right_Waku_Value_Min," & fpr.RightWakuValueMin.Value & ";" & "Right_Waku_Value_Max," & fpr.RightWakuValueMax.Value & ";"

                '--- 第二頁(Point Char.) ---
                Parameter_Lists = Parameter_Lists & "BP_Elongation_Min," & Me.NumericUpDown_BP_Elongation_Min.Value & ";" & "BP_Elongation_Max," & Me.NumericUpDown_BP_Elongation_Max.Value & ";" & "BP_Fullness_Min," & Me.NumericUpDown_BP_Fullness_Min.Value & ";" & "BP_Fullness_Max," & Me.NumericUpDown_BP_Fullness_Max.Value & ";" & "BP_MaxGray_Fullness_Min," & Me.NumericUpDown_BP_MaxGray_Fullness_Min.Value & ";" & _
                                                    "DP_Elongation_Min," & Me.NumericUpDown_DP_Elongation_Min.Value & ";" & "DP_Elongation_Max," & Me.NumericUpDown_DP_Elongation_Max.Value & ";" & "DP_Fullness_Min," & Me.NumericUpDown_DP_Fullness_Min.Value & ";" & "DP_Fullness_Max," & Me.NumericUpDown_DP_Fullness_Max.Value & ";" & "DP_MaxGray_Fullness_Min," & Me.NumericUpDown_DP_MaxGray_Fullness_Min.Value & ";" & _
                                                    "DP_GrayMean_Max," & Me.NumericUpDown_DP_GrayMean_Max.Value & ";" & "DP_MinGray_Min," & Me.NumericUpDown_DP_MinGray_Min.Value & ";" & "DP_MinGray_Max," & Me.NumericUpDown_DP_MinGray_Max.Value & ";" & "DP_StdDev_Max," & Me.NumericUpDown_DP_StdDev_Max.Value & ";" & _
                                                    "BP_GrayMean_Min," & Me.NumericUpDown_BP_GrayMean_Min.Value & ";" & "BP_MaxGray_Min," & Me.NumericUpDown_BP_MaxGray_Min.Value & ";" & "BP_MaxGray_Max," & Me.NumericUpDown_BP_MaxGray_Max.Value & ";" & "BP_StdDev_Max," & Me.NumericUpDown_BP_StdDev_Max.Value & ";" & "BP_Compactness_Max," & Me.NumericUpDown_BP_Compactness_Max.Value & ";" & "DP_Compactness_Max," & Me.NumericUpDown_DP_Compactness_Max.Value & ";"

                '--- 第三頁(GSBDP) ---
                Parameter_Lists = Parameter_Lists & "GSBP_Enable," & Me.CheckBox_GSBP_Enable.Checked & ";" & "GSBP_Threshold," & Me.NumericUpDown_GSBP_Threshold.Value & ";" & "GSBP_ThresholdRim," & Me.NumericUpDown_GSBP_ThresholdRim.Value & ";" & _
                                                    "GSBP_AreaMax," & Me.NumericUpDown_GSBP_AreaMax.Value & ";" & "GSBP_AreaMin," & Me.NumericUpDown_GSBP_AreaMin.Value & ";" & "GSBP_Count_Min," & Me.NumericUpDown_GSBP_Count_Min.Value & ";" & _
                                                    "GSBP_RangeX," & Me.NumericUpDown_GSBP_RangeX.Value & ";" & "GSBP_RangeY," & Me.NumericUpDown_GSBP_RangeY.Value & ";" & "GSBP_Scratch_Length," & Me.NumericUpDown_GSBP_Scratch_Length.Value & ";" & "GSBP_OverNum," & Me.NumericUpDown_GSBP_OverNum.Value & ";" & "GSBP_NumOfHoles," & Me.NumericUpDown_GSBP_NumOfHoles.Value & ";" & "GSBP_GrayMax_High," & Me.NumericUpDown_GSBP_GrayMax_High.Value & ";" & "GSBP_GrayMax_Low," & Me.NumericUpDown_GSBP_GrayMax_Low.Value & ";"

                Parameter_Lists = Parameter_Lists & "BLDP_Enable," & Me.CheckBox_BLDP_Enable.Checked & ";" & "BLDP_Threshold," & Me.NumericUpDown_BLDP_Threshold.Value & ";" & "BLDP_ThresholdRim," & Me.NumericUpDown_BLDP_ThresholdRim.Value & ";" & "BLDP_EnhanceCount," & Me.NumericUpDown_BLDP_EnhanceCount.Value & ";" & _
                                                    "BLDP_AreaMax," & Me.NumericUpDown_BLDP_AreaMax.Value & ";" & "BLDP_AreaMin," & Me.NumericUpDown_BLDP_AreaMin.Value & ";" & "BLDP_Count_Min," & Me.NumericUpDown_BLDP_Count_Min.Value & ";" & _
                                                    "BLDP_RangeX," & Me.NumericUpDown_BLDP_RangeX.Value & ";" & "BLDP_RangeY," & Me.NumericUpDown_BLDP_RangeY.Value & ";" & "BLDP_Scratch_Length," & Me.NumericUpDown_BLDP_Scratch_Length.Value & ";" & "BLDP_OverNum," & Me.NumericUpDown_BLDP_OverNum.Value & ";" & "BLDP_Fatness_Min," & Me.NumericUpDown_BLDP_Fatness_Min.Value & ";" & _
                                                    "BLDP_Elongation_Min," & Me.NumericUpDown_BLDP_Elongation_Min.Value & ";" & "BLDP_Elongation_Max," & Me.NumericUpDown_BLDP_Elongation_Max.Value & ";"

                '--- 第三頁(Line) ---
                Parameter_Lists = Parameter_Lists & "DL_Threshold," & Me.NumericUpDown_DL_Threshold.Value & ";" & "BL_Threshold," & Me.NumericUpDown_BL_Threshold.Value & ";" & "DL_RimThreshold," & Me.NumericUpDown_DL_RimThreshold.Value & ";" & "BL_RimThreshold," & Me.NumericUpDown_BL_RimThreshold.Value & ";" & _
                                                    "Line_ByPassUpH," & Me.NumericUpDown_Line_ByPassUpH.Value & ";" & "Line_ByPassDownH," & Me.NumericUpDown_Line_ByPassDownH.Value & ";" & "Line_ByPassLeftV," & Me.NumericUpDown_Line_ByPassLeftV.Value & ";" & "Line_ByPassRightV," & Me.NumericUpDown_Line_ByPassRightV.Value & ";" & _
                                                    "Line_Cut," & Me.NumericUpDown_Line_Cut.Value & ";" & "Line_Short_Cut," & Me.NumericUpDown_Line_Short_Cut.Value & ";" & "Line_Cut_H," & Me.NumericUpDown_Line_Cut_H.Value & ";" & "Line_Short_Cut_H," & Me.NumericUpDown_Line_Short_Cut_H.Value & ";" & _
                                                    "Line_OverNumber," & Me.NumericUpDown_Line_OverNumber.Value & ";" & "Block_OverNumber," & Me.NumericUpDown_Block_OverNumber.Value & ";" & _
                                                    "MeanDifference," & Me.NumericUpDown_MeanDifference.Value & ";" & "Line_Enable," & Me.CheckBox_Line_Enable.Checked & ";" & _
                                                    "HLine_NotAddToOutput," & Me.CheckBox_HLine_NotAddToOutput.Checked & ";" & "VLine_NotAddToOutput," & Me.CheckBox_VLine_NotAddToOutput.Checked & ";" & "Filter_VH_Scratch," & Me.CheckBox_Filter_VH_Scratch.Checked & ";" & _
                                                    "HalfScreen_Enable," & Me.CheckBox_HalfScreen_Enable.Checked & ";" & "LeakPointRadius," & Me.NumericUpDown_LeakPointRadius.Value & ";"
                Parameter_Lists = Parameter_Lists & "BL," & Me.CheckBox_BLine_Enable.Checked & ";" & "DL," & Me.CheckBox_DLine_Enable.Checked & ";"

                '--- 第四頁(Abnormal) ---
                Parameter_Lists = Parameter_Lists & "GrayAbnormal_PosLimit," & Me.NumericUpDown_GrayAbnormal_PosLimit.Value & ";" & "GrayAbnormal_NegLimit," & Me.NumericUpDown_GrayAbnormal_NegLimit.Value & ";" & _
                                                    "GrayAbnormalStandardGray," & Me.NumericUpDown_GrayAbnormalStandardGray.Value & ";" & "GrayAbnormal_NoDisplay," & Me.NumericUpDown_GrayAbnormal_NoDisplay.Value & ";" & _
                                                    "GrayAbnormal_Enable," & Me.CheckBox_GrayAbnormal_Enable.Checked & ";"

                '--- 第五頁(Auto) ---
                Parameter_Lists = Parameter_Lists & "AutoExposure_Kp," & Me.NumericUpDown_AutoExposure_Kp.Value & ";" & "AutoExposure_TargetMean," & Me.NumericUpDown_AutoExposure_TargetMean.Value & ";" & _
                                                    "AutoExposure_LargeErrorRange_UL," & Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value & ";" & "AutoExposure_LargeErrorRange_DL," & Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value & ";" & _
                                                    "AutoExposure_SmallErrorRange," & Me.NumericUpDown_AutoExposure_SmallErrorRange.Value & ";" & _
                                                    "AutoExposure_GrabDelayTime," & Me.NumericUpDown_AutoExposure_GrabDelayTime.Value & ";"

                '--- 第六頁 ---
                Parameter_Lists = Parameter_Lists & "Point_PitchX," & Me.NumericUpDown_Point_PitchX.Value & ";" & "Point_PitchY," & Me.NumericUpDown_Point_PitchY.Value & ";" & _
                                                    "FuncRawDataFilterMura_Enable," & Me.CheckBox_FuncRawDataFilterMura_Enable.Checked & ";" & _
                                                    "Line_PitchX," & Me.NumericUpDown_Line_PitchX.Value & ";" & "Line_PitchY," & Me.NumericUpDown_Line_PitchY.Value & ";" & "AverageFilter," & NumericUpDown_AverageFilter.Value & ";" & _
                                                    "Boundary_MulWidth_LX," & Me.NumericUpDown_Boundary_MulWidth_LX.Value & ";" & "Boundary_MulWidth_TY," & Me.NumericUpDown_Boundary_MulWidth_TY.Value & ";" & _
                                                    "Boundary_MulWidth_RX," & Me.NumericUpDown_Boundary_MulWidth_RX.Value & ";" & "Boundary_MulWidth_BY," & Me.NumericUpDown_Boundary_MulWidth_BY.Value & ";" & _
                                                    "AiResizeX," & Me.NumericUpDown_AiResizeX.Value & ";" & "AiResizeY," & Me.NumericUpDown_AiResizeY.Value & ";" & "IsAISaveROI," & Me.ComboBox_IsAISaveROI.Text.ToLower() & ";"

                '--- 第七頁 ---
                If Me.m_IPBootConfig.PLMarkUI.Value Then
                    Parameter_Lists = Parameter_Lists & "FillOfHole," & Me.CheckBox_FillOfHole.Checked & ";" & _
                                                        "PLMark_Enable," & Me.CheckBox_PLMark_Enable.Checked & ";" & "SearchRange_PLMark_Multiple," & Me.NumericUpDown_SearchRange_PLMark_Multiple.Value & ";" & _
                                                        "SearchMarkCount," & Me.NumericUpDown_SearchMarkCount.Value & ";" & _
                                                        "PLMark_Blacking," & ";" & "PLMark_Variation," & ";"
                End If

                '--- 第八頁 ---
                Parameter_Lists = Parameter_Lists & "HotPixelEnable," & Me.CheckBox_HotPixelEnable.Checked & ";" & "HotPixelRecipe," & Me.NumericUpDown_HotPixelRecipe.Value & ";" & _
                                                    "HotPixelFilterDistance," & Me.NumericUpDown_HotPixelFilterDistance.Value & ";" & "HotPixelMaxMean," & Me.NumericUpDown_HotPixelMaxMean.Value & ";" & _
                                                    "Filter_HotPixel_With_Characteristics," & Me.CheckBox_Filter_HotPixel_With_Characteristics.Checked & ";"

                '--- 第九頁 ---
                If Me.m_IPBootConfig.TPMarkUI.Value Then
                    Parameter_Lists = Parameter_Lists & "TPMark_Enable," & Me.CheckBox_TPMark_Enable.Checked & ";"
                End If

                If Me.RadioButton_PointAlgorithm_0.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_0," & Me.RadioButton_PointAlgorithm_0.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_1.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_1," & Me.RadioButton_PointAlgorithm_1.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_2.Checked Then 'v2012.09.05
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_2," & Me.RadioButton_PointAlgorithm_2.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_3.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_3," & Me.RadioButton_PointAlgorithm_3.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_4.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_4," & Me.RadioButton_PointAlgorithm_4.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_5.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_5," & Me.RadioButton_PointAlgorithm_5.Checked & ";"
                ElseIf Me.RadioButton_PointAlgorithm_6.Checked Then
                    Parameter_Lists = Parameter_Lists & "PointAlgorithm_6," & Me.RadioButton_PointAlgorithm_6.Checked & ";"
                End If

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            dir = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
            If Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If
            str = dir & "\FuncPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_FuncProcess.Pattern & ".xml"

            If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                i = Me.m_MainProcess.FuncPatternRecipeArrayOrder.IndexOf(Me.m_FuncProcess.CurrentFuncPatternRecipe)
                If i >= 0 Then
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("**************************[FuncSave]******************************")
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[ClsFuncPatternRecipe] 目前 Model：" & Me.m_Form.GetProductNameInfo & " ; 目前 Pattern: " & Me.m_Form.ComboBox_Pattern_MainFrm.Text)
                    Me.Compare(Me.m_MainProcess.FuncPatternRecipeArrayTemp.Item(i), Me.m_FuncProcess.CurrentFuncPatternRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                    Me.m_FuncProcess.SaveCurrentFuncPatternRecipe(str, Me.m_MainProcess.ErrorCode)
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern 存檔]: " & str)
                Else
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("PatternAdd: " & Me.m_FuncProcess.Pattern)
                End If
                Me.Compare(Me.m_MainProcess.FuncModelRecipeTemp, Me.m_FuncProcess.FuncModelRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                Me.m_FuncProcess.SaveFuncModelRecipe(dir, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Model 存檔]: " & dir & "\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml")
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Current Func Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Func Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Save.Enabled = True
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_FUNC_MODEL_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save MappingTable Recipe  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_MAPPINGTABLE_RECIPE"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If (Me.m_IPBootConfig.PLMarkUI.Value) Then
                '----------------------------------------------------------------------------------------------
                ' Save PL Mark Model Recipe ==> Request_Command = "SAVE_PLMARK_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "SAVE_PLMARK_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        Me.Button_PLMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save PL Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.PLMark_Setting]Save PL Mark Model Recipe Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If

            If (Me.m_IPBootConfig.TPMarkUI.Value) Then
                '----------------------------------------------------------------------------------------------
                ' Save TP Mark Model Recipe ==> Request_Command = "SAVE_TPMARK_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_TPMARK_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        '--- Enable Button ---   
                        Me.Button_TPMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save TP Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMark_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    '--- Enable Button ---  
                    Me.Button_TPMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Save TP Mark Model Recipe Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMark_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If

            '--- Func Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_FuncProcess.SaveToFuncRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

            '--- Button Control ---   
            Button_Enable(True)

            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_FuncSetting.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Button_LoadImage_Click ---"
    Private Sub Button_LoadImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LoadImage.Click
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim ResizeRatio As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial --- 
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MainProcess.MuraPatternRecipeArrayOrder.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MainProcess.MuraPatternRecipeArrayOrder.Count
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                FilePath = GetUNCPath(Me.m_Form.OpenFileDialog.FileName)
                If FilePath.Contains("_FFunc") Or FilePath.Contains("_FMura") Then
                    If System.IO.Path.GetFileNameWithoutExtension(FilePath).Split("_")(2) <> Me.m_MainProcess.CCDNo Then
                        If MsgBox("載入影像非所選擇CCD,是否強制載入?", vbOKCancel, "請確認") = MsgBoxResult.Cancel Then
                            Button_Enable(True)
                            Exit Sub
                        End If
                    End If
                End If

                image = Me.m_FuncProcess.Img_Original_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_FuncProcess.Img_Original_NonPage)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    If image <> M_NULL Then
                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)

                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                            MbufFree(imageBuffer)
                            imageBuffer = M_NULL
                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufCopy(image, imageBuffer)

                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                        Me.m_Form.ResetScrollBar()
                    End If
                Else
                    Me.m_Form.CurrentIndex0 = 2
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 2
                End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 100000 '100 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)

                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        If SubSystemResult.Responses(0).Param1 = "1" Then
                            Me.m_Form.CheckBox_IsAligned.Checked = True
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                            strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                            RepairPath_2(strPath)
                            MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                            ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.RightX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.BottomY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY / ResizeRatio)
                        Else
                            Me.m_Form.CheckBox_IsAligned.Checked = False
                        End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                If (Me.m_IPBootConfig.MuraUI.Value) Then

                    '----------------------------------------------------------------------------------------------
                    ' Transfer Mura Boundary  ==> Request_Command = "Transfer_Mura_Boundary" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "Transfer_Mura_Boundary"
                        TimeOut = 10000 '10 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                    '[1] image2 ---
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                    If image2 <> M_NULL Then
                        If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image2)
                            image2 = M_NULL
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                    If Not Me.m_IPBootConfig.FuncUI.Value Then
                        '[2] Img_16U_Grab ---
                        If Me.m_MuraProcess.Img_CurrentOriginal_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                                Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                                Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)
                    End If

                    If Not Response_OK Then
                        Button_Enable(True)
                        Exit Sub
                    End If
                End If
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func 基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                    Me.m_FuncProcess.Func_Set_HWAcc(Me.m_IPBootConfig, Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)

                    '--- 顯示功能 ---
                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Type = MbufInquire(Me.m_MainProcess.Img_FixRecipe_NonPage, M_TYPE, M_NULL)

                    If Me.m_MainProcess.Img_FixRecipe_NonPage <> M_NULL Then
                        MbufFree(Me.m_MainProcess.Img_FixRecipe_NonPage)
                        Me.m_MainProcess.Img_FixRecipe_NonPage = M_NULL
                    End If
                    Me.m_MainProcess.Img_FixRecipe_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                Else
                    If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                        Me.m_FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
            End If
            Me.m_Form.ImageUpdate()
            Me.m_Form.ImageZoomAll()

            For i = 0 To Me.ComboBox_Pattern.Items.Count - 1
                If Me.m_Form.OpenFileDialog.FileName.Contains(Me.ComboBox_Pattern.Items(i)) Then
                    Me.ComboBox_Pattern.SelectedIndex = i
                    Exit For
                End If
            Next

            '--- Button Control ---   
            Button_Enable(True)
            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_FuncSetting.Button_LoadImage_Click]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSetting.Button_LoadImage_Click]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- PLMark ---"

#Region "--- Button_Save_PLMark_Click ---"
    Private Sub Button_Save_PLMark_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save_PLMark.Click

        If (Me.NumericUpDown_PLMark_BoundaryTop.Value = 0 And Me.NumericUpDown_PLMark_BoundaryBottom.Value = 0 And Me.NumericUpDown_PLMark_BoundaryLeft.Value = 0 And Me.NumericUpDown_PLMark_BoundaryRight.Value = 0) Then
            MsgBox("[Mark] 請圈選一影像 !( 請勾選 顯示與手動設定,進行Mark影像圈選 )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Exit Sub
        End If

        If Me.CheckedListBox_PLMark.Items.Count = 0 Then
            Me.ToolStripMenuItem_AddPLMark.PerformClick()
        End If

        Me.m_Form.Panel_AxMDisplay.Refresh()

        Me.PLMark_Setting()

        'Me.Button_Save.PerformClick()

        '--- Close Select & Show Align Mark Image Setting ---
        Me.CheckBox_PLMark_ShowBoundary.Checked = False
        Me.CheckBox_PLMark_RegionMannual.Checked = False

    End Sub
#End Region

#Region "--- Button_PLMark_PatTest_Click ---"
    Private Sub Button_PLMark_PatTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_PLMark_PatTest.Click

        If Me.m_FuncProcess.PLMarkModelRecipe.PMG.Count <= 0 Then Exit Sub

        Dim sOutput As String = ""
        Dim i As Integer
        Dim strs1() As String
        Dim strs2() As String

        Try
            '建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            'Disable Button ---  
            Me.Button_Enable(False)

            Me.m_FuncProcess.PLMarkResults.Clear()
            '----------------------------------------------------------------------------------------------
            ' Find PL Mark  ==> Request_Command = "FIND_PLMARK" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FIND_PLMARK"
                TimeOut = 300000 '300 secs

                'UI Recipe Setting -----------------------------------
                Response_OK = False

                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                    strs1 = SubSystemResult.Responses(0).Param1.Split(";")

                    If strs1.Length > 1 Then
                        '格式：PL Mark名稱 ---
                        For i = 0 To strs1.Length - 1
                            If strs1(i) <> "" Then
                                strs2 = strs1(i).Split(",")

                                Dim MarkResult As New ClsMarkResult
                                MarkResult.MarkName = strs2(0)
                                MarkResult.Score = Val(strs2(1))
                                MarkResult.PosX = Val(strs2(2))
                                MarkResult.PosY = Val(strs2(3))
                                MarkResult.SizeX = Val(strs2(4))
                                MarkResult.SizeY = Val(strs2(5))
                                MarkResult.Mark_Group = Val(strs2(6))
                                Me.m_FuncProcess.PLMarkResults.Add(MarkResult)

                                sOutput &= "[Mark]" & vbTab & vbTab & "[Score]" & vbTab & "[Pos_X]" & vbTab & "[Pos_Y]" & vbTab & "[Group]" & vbCrLf
                                sOutput &= " " & MarkResult.MarkName & vbTab & vbTab & MarkResult.Score & vbTab & MarkResult.PosX & vbTab & MarkResult.PosY & vbTab & MarkResult.Mark_Group & vbCrLf

                            End If
                        Next
                    Else
                        sOutput &= "Pattern Mark not found."
                    End If

                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    'Enable Button ---   
                    Me.Button_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Find PL Mark Position Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show(Me, "[Dialog_FuncSetting.Button_PLMark_PatTest_Click][FIMC_PLMARK]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                'Enable Button ---  
                Me.Button_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.Button_PLMark_PatTest_Click]Find PL Mark Position Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.Button_PLMark_PatTest_Click][FIMC_PLMARK]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            Me.m_Form.PaintStop = False
            Me.DrawPLMark("Result")

            MessageBox.Show(sOutput, "[Pattern Matching Result]", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)

            'Button Control ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            MessageBox.Show("[Dialog_FuncSetting.Button_PLMark_PatTest_Click]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- TPMark ---"

#Region "--- Button_Save_TPMark_Click ---"
    Private Sub Button_Save_TPMark_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save_TPMark.Click
        If (Me.NumericUpDown_TPMark_BoundaryTop.Value = 0 And Me.NumericUpDown_TPMark_BoundaryBottom.Value = 0 And Me.NumericUpDown_TPMark_BoundaryLeft.Value = 0 And Me.NumericUpDown_TPMark_BoundaryRight.Value = 0) Then
            MsgBox("[Mark] 請圈選一影像 !( 請勾選 顯示與手動設定,進行Mark影像圈選 )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Exit Sub
        End If

        Me.m_MainProcess.LogRecipeManager("[Mark Add]" & "增加一組 TP Mark，Mark 名稱：" & TextBox_TPMark_MarkName.Text.ToUpper)
        Me.m_Form.Panel_AxMDisplay.Refresh()

        If TextBox_TPMark_MarkName.Text.Equals("") Then
            MsgBox("識別名稱為必要識別欄位，請務必輸入。")
            Exit Sub
        End If

        Me.TPMark_Setting()

        '--- Close Select & Show Align Mark Image Setting ---
        Me.CheckBox_TPMark_ShowBoundary.Checked = False
        Me.CheckBox_TPMark_RegionMannual.Checked = False

    End Sub
#End Region

#Region "--- Button_TPMark_PatTest_Click ---"
    Private Sub Button_TPMark_PatTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_TPMark_PatTest.Click
        Me.CheckBox_TPMark_ShowResult.Checked = False
        If Me.m_FuncProcess.TPMarkModelRecipe.TPG.Count <= 0 Then Exit Sub

        Dim sOutput As String = ""
        Dim i As Integer
        Dim strs1() As String
        Dim strs2() As String

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Disable Button ---  
            Me.Button_Enable(False)

            Me.m_FuncProcess.TPMarkResults.Clear()
            '----------------------------------------------------------------------------------------------
            ' Find TP Mark  ==> Request_Command = "FIND_TPMARK" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "FIND_TPMARK"
                TimeOut = 300000 '300 secs
                Response_OK = False

                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                    strs1 = SubSystemResult.Responses(0).Param1.Split(";")

                    If strs1.Length > 1 Then
                        '格式：TP Mark名稱 ---
                        For i = 0 To strs1.Length - 1
                            If strs1(i) <> "" Then
                                strs2 = strs1(i).Split(",")

                                Dim MarkResult As New ClsTPMarkResult
                                MarkResult.MarkName = strs2(0)
                                MarkResult.Score = Val(strs2(1))
                                MarkResult.PosX = Val(strs2(2))
                                MarkResult.PosY = Val(strs2(3))
                                MarkResult.Mark_Action = strs2(4)
                                Me.m_FuncProcess.TPMarkResults.Add(MarkResult)

                                sOutput &= "[Mark]" & vbTab & vbTab & "[Score]" & vbTab & "[Pos_X]" & vbTab & "[Pos_Y]" & vbTab & "[Action]" & vbTab & vbCrLf
                                sOutput &= " " & MarkResult.MarkName & vbTab & vbTab & MarkResult.Score & vbTab & MarkResult.PosX & vbTab & MarkResult.PosY & vbTab & MarkResult.Mark_Action & vbCrLf

                            End If
                        Next
                    Else
                        sOutput &= "Pattern Mark not found."
                    End If

                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    '--- Enable Button ---   
                    Me.Button_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Find TP Mark Position Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show(Me, "[Dialog_FuncSetting.Button_TPMark_PatTest_Click][FIMC_TPMark]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                '--- Enable Button ---  
                Me.Button_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.Button_TPMark_PatTest_Click]Find TP Mark Position Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.Button_TPMark_PatTest_Click][FIMC_TPMark]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            Me.CheckBox_TPMark_ShowResult.Checked = True
            Me.m_Form.PaintStop = False
            Me.DrawTPMark()
            MessageBox.Show(sOutput, "[Pattern Matching Result]")
            Me.CheckBox_TPMark_ShowResult.Checked = False

            '--- Button Control ---
            Me.Button_Enable(True)
        Catch ex As Exception
            Me.Button_Enable(True)
            MessageBox.Show("[Dialog_FuncSetting.Button_TPMark_PatTest_Click]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- NumericUpDown_GrayAbnormal_PosLimit_ValueChanged ---"
    Private Sub NumericUpDown_GrayAbnormal_PosLimit_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_GrayAbnormal_PosLimit.ValueChanged
        Me.Lbl_GrayAbnormal_PosLimit.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit.Value) / 100), "#"))
    End Sub
#End Region

#Region "--- NumericUpDown_GrayAbnormal_NegLimit_ValueChanged ---"
    Private Sub NumericUpDown_GrayAbnormal_NegLimit_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_GrayAbnormal_NegLimit.ValueChanged
        Me.Lbl_GrayAbnormal_NegLimit.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit.Value) / 100), "#"))
    End Sub
#End Region

#Region "--- NumericUpDown_GrayAbnormalStandardGray_ValueChanged ---"
    Private Sub NumericUpDown_GrayAbnormalStandardGray_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_GrayAbnormalStandardGray.ValueChanged
        Me.Lbl_GrayAbnormal_PosLimit.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 + Me.NumericUpDown_GrayAbnormal_PosLimit.Value) / 100), "#"))
        Me.Lbl_GrayAbnormal_NegLimit.Text = CStr(Format(Me.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 - Me.NumericUpDown_GrayAbnormal_NegLimit.Value) / 100), "#"))
    End Sub
#End Region

#Region "--- PLMark ---"

#Region "--- NumericUpDown_PLMark_BoundaryTop_ValueChanged ---"
    Private Sub NumericUpDown_PLMark_BoundaryTop_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_PLMark_BoundaryTop.ValueChanged
        Me.DrawPLMark("Region")
    End Sub
#End Region

#Region "--- NumericUpDown_PLMark_BoundaryBottom_ValueChanged ---"
    Private Sub NumericUpDown_PLMark_BoundaryBottom_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_PLMark_BoundaryBottom.ValueChanged
        Me.DrawPLMark("Region")
    End Sub
#End Region

#Region "--- NumericUpDown_PLMark_BoundaryLeft_ValueChanged ---"
    Private Sub NumericUpDown_PLMark_BoundaryLeft_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_PLMark_BoundaryLeft.ValueChanged
        Me.DrawPLMark("Region")
    End Sub
#End Region

#Region "--- NumericUpDown_PLMark_BoundaryRight_ValueChanged ---"
    Private Sub NumericUpDown_PLMark_BoundaryRight_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_PLMark_BoundaryRight.ValueChanged
        Me.DrawPLMark("Region")
    End Sub
#End Region

#End Region

#Region "--- TPMark ---"

#Region "--- NumericUpDown_TPMark_BoundaryTop_ValueChanged ---"
    Private Sub NumericUpDown_TPMark_BoundaryTop_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_TPMark_BoundaryTop.ValueChanged
        Me.DrawTPMark()
    End Sub
#End Region

#Region "--- NumericUpDown_TPMark_BoundaryBottom_ValueChanged ---"
    Private Sub NumericUpDown_TPMark_BoundaryBottom_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_TPMark_BoundaryBottom.ValueChanged
        Me.DrawTPMark()
    End Sub
#End Region

#Region "--- NumericUpDown_TPMark_BoundaryLeft_ValueChanged ---"
    Private Sub NumericUpDown_TPMark_BoundaryLeft_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_TPMark_BoundaryLeft.ValueChanged
        Me.DrawTPMark()
    End Sub
#End Region

#Region "--- NumericUpDown_TPMark_BoundaryRight_ValueChanged ---"
    Private Sub NumericUpDown_TPMark_BoundaryRight_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_TPMark_BoundaryRight.ValueChanged
        Me.DrawTPMark()
    End Sub
#End Region

#End Region

#End Region

#Region "--- AxMDisplay Event ---"

#Region "--- m_Panel_AxMDisplay_MouseDownEvent ---"
    Private Sub m_Panel_AxMDisplay_MouseDownEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        If Not Me.TabControl_Setting.SelectedTab Is Nothing Then
            '--- [PL Mark] ---
            If Me.TabControl_Setting.SelectedTab.Text.ToUpper = "PLMARK" Then  'PL Mark
                If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_PLMark_RegionMannual.Checked And Me.CheckBox_PLMark_ShowBoundary.Checked Then   '滑鼠左鍵
                    Me.m_Form.PaintStop = False
                    Me.m_Form.Panel_AxMDisplay.Refresh()
                    Me.NumericUpDown_PLMark_BoundaryLeft.Value = Me.m_Form.MouseX
                    Me.NumericUpDown_PLMark_BoundaryTop.Value = Me.m_Form.MouseY
                End If
            End If
            '--- [TP Mark] ---
            If Me.TabControl_Setting.SelectedTab.Text.ToUpper = "TPMARK" Then  'TP Mark
                If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_TPMark_RegionMannual.Checked And Me.CheckBox_TPMark_ShowBoundary.Checked Then   '滑鼠左鍵
                    Me.m_Form.PaintStop = False
                    Me.m_Form.Panel_AxMDisplay.Refresh()
                    Me.NumericUpDown_TPMark_BoundaryLeft.Value = Me.m_Form.MouseX
                    Me.NumericUpDown_TPMark_BoundaryTop.Value = Me.m_Form.MouseY
                End If
            End If
        End If
    End Sub
#End Region

#Region "--- m_Panel_AxMDisplay_MouseMoveEvent ---"
    Private Sub m_Panel_AxMDisplay_MouseMoveEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        If Not Me.TabControl_Setting.SelectedTab Is Nothing Then
            '--- [PL Mark] ---
            If Me.TabControl_Setting.SelectedTab.Text.ToUpper = "PLMARK" Then  'PL Mark
                If Me.CheckBox_PLMark_ShowBoundary.Checked And Me.CheckBox_PLMark_RegionMannual.Checked Then
                    If e.Button = Windows.Forms.MouseButtons.Left Then
                        Me.m_Form.PaintStop = True
                        Me.m_Form.Panel_AxMDisplay.Refresh()
                        Me.m_GraphicsImage.Clear(Color.Transparent)

                        Me.NumericUpDown_PLMark_BoundaryRight.Value = Me.m_Form.MouseX
                        Me.NumericUpDown_PLMark_BoundaryBottom.Value = Me.m_Form.MouseY
                        Me.DrawPLMark("Region")
                    End If
                End If
            End If
            '--- [TP Mark] ---
            If Me.TabControl_Setting.SelectedTab.Text.ToUpper = "TPMARK" Then  'TP Mark
                If Me.CheckBox_TPMark_ShowBoundary.Checked And Me.CheckBox_TPMark_RegionMannual.Checked Then
                    If e.Button = Windows.Forms.MouseButtons.Left Then
                        Me.m_Form.PaintStop = True
                        Me.m_Form.Panel_AxMDisplay.Refresh()
                        Me.m_GraphicsImage.Clear(Color.Transparent)

                        Me.NumericUpDown_TPMark_BoundaryRight.Value = Me.m_Form.MouseX
                        Me.NumericUpDown_TPMark_BoundaryBottom.Value = Me.m_Form.MouseY
                        Me.DrawTPMark()
                    End If
                End If
            End If
        End If
    End Sub
#End Region

#Region "--- m_Panel_AxMDisplay_PaintEvent ---"
    Private Sub m_Panel_AxMDisplay_MouseUpEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If Not Me.TabControl_Setting.SelectedTab Is Nothing Then
            '--- [PL Mark] ---
            If Me.TabControl_Setting.SelectedTab.Text.ToUpper = "PLMARK" Then  'PL Mark
                If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_PLMark_RegionMannual.Checked Then
                    Dim pb As New ClsParameterBoundary
                    Me.m_Form.PaintStop = False

                    pb.LeftX = CInt(Me.NumericUpDown_PLMark_BoundaryLeft.Value)
                    pb.TopY = CInt(Me.NumericUpDown_PLMark_BoundaryTop.Value)
                    pb.RightX = Me.m_Form.MouseX
                    pb.BottomY = Me.m_Form.MouseY

                    If Me.NumericUpDown_PLMark_BoundaryRight.Value = Me.NumericUpDown_PLMark_BoundaryLeft.Value Or Me.NumericUpDown_PLMark_BoundaryBottom.Value = Me.NumericUpDown_PLMark_BoundaryTop.Value Then
                        MsgBox("Please re-Circle PL Mark range !")
                    End If

                    Me.DrawPLMark("Region")
                    Me.m_Form.PaintStop = True
                End If
            End If
            '--- [TP Mark] ---
            If Me.TabControl_Setting.SelectedTab.Text.ToUpper = "TPMARK" Then  'PL Mark
                If e.Button = Windows.Forms.MouseButtons.Left AndAlso Me.CheckBox_TPMark_RegionMannual.Checked Then
                    Dim pb As New ClsParameterBoundary
                    Me.m_Form.PaintStop = False

                    pb.LeftX = CInt(Me.NumericUpDown_TPMark_BoundaryLeft.Value)
                    pb.TopY = CInt(Me.NumericUpDown_TPMark_BoundaryTop.Value)
                    pb.RightX = Me.m_Form.MouseX
                    pb.BottomY = Me.m_Form.MouseY

                    If Me.NumericUpDown_TPMark_BoundaryRight.Value = Me.NumericUpDown_TPMark_BoundaryLeft.Value Or Me.NumericUpDown_TPMark_BoundaryBottom.Value = Me.NumericUpDown_TPMark_BoundaryTop.Value Then
                        MsgBox("Please re-Circle TP Mark range !")
                    End If

                    Me.DrawTPMark()
                    Me.m_Form.PaintStop = True
                End If
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_BLine_Enable_CheckedChanged ---"
    Private Sub CheckBox_BLine_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_BLine_Enable.CheckedChanged
        Me.GroupBox_BLine.Enabled = Me.CheckBox_BLine_Enable.Checked
    End Sub
#End Region

#Region "--- CheckBox_DLine_Enable_CheckedChanged ---"
    Private Sub CheckBox_DLine_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_DLine_Enable.CheckedChanged
        Me.GroupBox_DLine.Enabled = Me.CheckBox_DLine_Enable.Checked
    End Sub
#End Region

#Region "--- CheckBox_HalfScreen_Enable_CheckedChanged ---"
    Private Sub CheckBox_HalfScreen_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_HalfScreen_Enable.CheckedChanged
        Me.GroupBox_MeanDiff.Enabled = Me.CheckBox_HalfScreen_Enable.Checked
    End Sub
#End Region

#Region "--- CheckBox_Inverse_Point_EnableFixArea_CheckedChanged ---"
    Private Sub CheckBox_Inverse_Point_EnableFixArea_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Inverse_Point_EnableFixArea.CheckedChanged
        Dim Parameter_Lists As String = ""

        Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Enabled = Me.CheckBox_Inverse_Point_EnableFixArea.Checked

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第二頁 ---
            Parameter_Lists = "Inverse_Point_EnableFixArea," & Me.CheckBox_Inverse_Point_EnableFixArea.Checked & ";" & "Inverse_Point_FixArea," & Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.MbufSave((MIL_TEXT_PTR)(ResizeSourcePathData1),SourceImageResize1);]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.MbufSave((MIL_TEXT_PTR)(ResizeSourcePathData1),SourceImageResize1);]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.MbufSave((MIL_TEXT_PTR)(ResizeSourcePathData1),SourceImageResize1);]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- CheckBox_Inverse_Point_DefectType_CheckedChanged ---"
    Private Sub CheckBox_Inverse_Point_DefectType_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_Inverse_Point_DefectType.CheckedChanged
        Me.CheckBox_Inverse_Point_EnableFixArea.Enabled = Me.CheckBox_Inverse_Point_DefectType.Checked
        Me.CheckBox_Inverse_Point_EnableFixArea.Enabled = Me.CheckBox_Inverse_Point_DefectType.Checked
        Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Enabled = Me.CheckBox_Inverse_Point_EnableFixArea.Checked
    End Sub
#End Region

#Region "--- PLMark ---"

#Region "--- CheckBox_PLMark_RegionMannual ---"
    Private Sub CheckBox_PLMark_RegionMannual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_PLMark_RegionMannual.CheckedChanged
        Me.CheckBox_MarkTH.Checked = False
        Me.GroupBox_PLMark_Boundary.Enabled = Me.CheckBox_PLMark_RegionMannual.Checked
        Me.GroupBox_PLMarkSet.Enabled = Me.CheckBox_PLMark_RegionMannual.Checked
        Me.GroupBox_PLMark_SearchMode.Enabled = Me.CheckBox_PLMark_RegionMannual.Checked
        Me.GroupBox_BypassSetting.Enabled = Me.CheckBox_PLMark_RegionMannual.Checked
        Me.GroupBox_MatchSetting.Enabled = Me.CheckBox_PLMark_RegionMannual.Checked
    End Sub


#End Region

#Region "--- CheckBox_PLMark_ShowBoundary ---"
    Private Sub CheckBox_PLMark_ShowBoundary_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_PLMark_ShowBoundary.CheckedChanged
        Me.m_Form.PaintStop = Me.CheckBox_PLMark_ShowBoundary.Checked

        If Not Me.m_Form.PaintStop Then
            Me.DrawPLMark("Region")
        End If
    End Sub
#End Region

#End Region

#Region "--- TPMark ---"

#Region "--- CheckBox_TPMark_RegionMannual ---"
    Private Sub CheckBox_TPMark_RegionMannual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_TPMark_RegionMannual.CheckedChanged
        Me.GroupBox_TPMark_Boundary.Enabled = Me.CheckBox_TPMark_RegionMannual.Checked
        Me.GroupBox_TPMarkSet.Enabled = Me.CheckBox_TPMark_RegionMannual.Checked
    End Sub
#End Region

#Region "--- CheckBox_TPMark_ShowBoundary ---"
    Private Sub CheckBox_TPMark_ShowBoundary_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_TPMark_ShowBoundary.CheckedChanged
        Me.m_Form.PaintStop = Me.CheckBox_TPMark_ShowBoundary.Checked

        If Not Me.m_Form.PaintStop Then
            Me.DrawTPMark()
        End If
    End Sub
#End Region

#Region "--- CheckBox_TPMark_ShowMarkResult ---"
    Private Sub CheckBox_TPMark_ShowMarkResult_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_TPMark_ShowResult.CheckedChanged
        If Me.CheckBox_TPMark_ShowResult.Checked Then
            Me.DrawTPMark()
        End If
    End Sub
#End Region

#End Region

#Region "--- CheckBox_HotPixelEnable_CheckChanged ---"
    Private Sub CheckBox_HotPixelEnable_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_HotPixelEnable.CheckedChanged
        Me.GroupBox_HotPixel.Enabled = Me.CheckBox_HotPixelEnable.Checked
    End Sub
#End Region

#End Region

#Region "--- RadioButton Event ---"

#Region "--- RadioButton_BP_CheckedChanged ---"
    Private Sub RadioButton_BP_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BP.CheckedChanged
        If Me.CheckBox_Point_Enable.Checked Then

            Me.GroupBox_BPoint.Enabled = Me.RadioButton_BP.Checked
            Me.GroupBox_DPoint.Enabled = Me.RadioButton_DP.Checked

            If Not Me.RadioButton_BP.Checked And Not Me.RadioButton_DP.Checked And Me.RadioButton_BPDP.Checked Then
                Me.GroupBox_BPoint.Enabled = True
                Me.GroupBox_DPoint.Enabled = True
            End If

        End If
    End Sub
#End Region

#Region "--- RadioButton_BPDP_CheckedChanged ---"
    Private Sub RadioButton_BPDP_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BPDP.CheckedChanged
        If Me.CheckBox_Point_Enable.Checked Then
            Me.GroupBox_BPoint.Enabled = Me.RadioButton_BP.Checked
            Me.GroupBox_DPoint.Enabled = Me.RadioButton_DP.Checked

            If Not Me.RadioButton_BP.Checked And Not Me.RadioButton_DP.Checked And Me.RadioButton_BPDP.Checked Then
                Me.GroupBox_BPoint.Enabled = True
                Me.GroupBox_DPoint.Enabled = True
            End If
        End If
    End Sub
#End Region

#Region "--- PLMark ---"

#Region "--- RadioButton_PLMark_Original_CheckedChanged ---"
    Private Sub RadioButton_PLMark_Original_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_PLMark_Original.CheckedChanged
        If Me.RadioButton_PLMark_Original.Checked Then
            Dim filepath As String
            Dim SizeX, SizeY, Type As Integer

            If Me.CheckedListBox_PLMark.Items.Count = 0 Then
                Exit Sub
            End If
            'Show PL Mark Image ---   
            filepath = Me.m_FuncProcess.PLMarkModelRecipe.PMG.Item(Me.m_CurrentPLMarkIndex).MarkImagePath
            If File.Exists(filepath) Then
                MbufClear(Me.m_MainProcess.Img_PLMark_NonPage, 0L)  '2012/12/06 Rick add

                MbufDiskInquire(filepath, M_SIZE_X, SizeX)
                MbufDiskInquire(filepath, M_SIZE_Y, SizeY)
                MbufDiskInquire(filepath, M_TYPE, Type)
                If MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(Me.m_MainProcess.Img_PLMark_NonPage)
                    Me.m_MainProcess.Img_PLMark_NonPage = M_NULL
                    Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(filepath, Me.m_MainProcess.Img_PLMark_NonPage)

                '--- Display ---
                MdispSelectWindow(Me.m_AxMDisplay_PLMark, Me.m_MainProcess.Img_PLMark_NonPage, Me.Panel_AxMDisplay_PLMark.Handle)
                MbufControl(Me.m_MainProcess.Img_PLMark_NonPage, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_AxMDisplay_PLMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                Me.PLMark_ImageZoomAll()
            End If
        End If
    End Sub
#End Region

#Region "--- RadioButton_PLMark_Bin_CheckedChanged ---"
    Private Sub RadioButton_PLMark_Bin_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_PLMark_Bin.CheckedChanged

        If Me.RadioButton_PLMark_Bin.Checked Then
            Dim filepath As String
            Dim SizeX, SizeY, Type As Integer

            'Show PL Mark Image ---   
            filepath = Me.m_FuncProcess.PLMarkModelRecipe.PMG.Item(Me.m_CurrentPLMarkIndex).BinImagePath
            If File.Exists(filepath) Then
                MbufClear(Me.m_MainProcess.Img_PLMark_NonPage, 0L)  '2012/12/06 Rick add

                MbufDiskInquire(filepath, M_SIZE_X, SizeX)
                MbufDiskInquire(filepath, M_SIZE_Y, SizeY)
                MbufDiskInquire(filepath, M_TYPE, Type)
                If MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(Me.m_MainProcess.Img_PLMark_NonPage)
                    Me.m_MainProcess.Img_PLMark_NonPage = M_NULL
                    Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(filepath, Me.m_MainProcess.Img_PLMark_NonPage)

                '--- Display ---
                MdispSelectWindow(Me.m_AxMDisplay_PLMark, Me.m_MainProcess.Img_PLMark_NonPage, Me.Panel_AxMDisplay_PLMark.Handle)
                MbufControl(Me.m_MainProcess.Img_PLMark_NonPage, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_AxMDisplay_PLMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                Me.PLMark_ImageZoomAll()
            End If
        End If
    End Sub
#End Region

#End Region


#End Region

#Region "--- ContextMenuStrip Event ---"

#Region "--- ContextMenuStrip_PLMark_ItemClicked ---"
    Private Sub ContextMenuStrip_PLMark_ItemClicked(sender As Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip_PLMark.ItemClicked
        Dim i As Integer
        Dim j As Integer
        Dim Parameter_Lists As String = ""
        Dim PLMarkName As String
        Dim PLMark As ClsPLMark

        '建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If
        If Me.m_FuncProcess.PLMarkModelRecipe Is Nothing Then  '2015/07/30 
            Me.m_FuncProcess.PLMarkModelRecipe = New ClsPLMarkModelRecipe
        End If

        'Disable Button ---  
        Me.Button_PLMark_Enable(False)
        Me.Focus()
        Me.BringToFront()

        If e.ClickedItem Is Me.ToolStripMenuItem_AddPLMark Then
            PLMarkName = InputBox("請輸入Mark名稱", "Mark名稱")

            If PLMarkName = "" Then
                MsgBox("請輸入Mark名稱!")
                Exit Sub
            End If

            For Each PLMark_temp As ClsPLMark In Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup
                If (PLMark_temp.MarkName = PLMarkName) Then
                    MsgBox("Mark名稱已有,請設定其他Mark名稱 !")
                    Exit Sub
                End If
            Next

            If (Me.NumericUpDown_PLMark_BoundaryTop.Value = 0 And Me.NumericUpDown_PLMark_BoundaryBottom.Value = 0 And Me.NumericUpDown_PLMark_BoundaryLeft.Value = 0 And Me.NumericUpDown_PLMark_BoundaryRight.Value = 0) Then
                MsgBox("[Mark] 請圈選一影像 !( 請勾選 顯示與手動設定,進行Mark影像圈選 )", MsgBoxStyle.Critical, "[AreaGrabber]")
                Exit Sub
            End If

            '[1] Add New PL Mark 
            Me.CheckedListBox_PLMark.Items.Add(PLMarkName)
            Me.m_CurrentPLMarkIndex = Me.CheckedListBox_PLMark.Items.Count - 1
            Me.TextBox_PLMark_MarkName.Text = PLMarkName


            PLMark = New ClsPLMark(Me.NumericUpDown_PLMark_Acceptance.Value, Me.NumericUpDown_PLMark_DilateCount.Value)
            PLMark.MarkName = PLMarkName

            If Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup Is Nothing Then
                Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup = New ArrayList
            End If

            Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup.Add(PLMark)

            '----------------------------------------------------------------------------------------------
            ' Add A New PL Mark ==> Request_Command = "PLMARK_ADD" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "PLMARK_ADD"
                TimeOut = 100000 '100 secs

                Parameter_Lists = Parameter_Lists & "PLMark_MarkName," & Me.TextBox_PLMark_MarkName.Text & ";" & "PLMark_Acceptance," & PLMark.Mark_Acceptance & ";" & ";" & "PLMark_DilateCount," & PLMark.Mark_DilateCount & ";"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    'Enable Button ---   
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add A New PL Mark Error !(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_ADD]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                'Enable Button ---  
                Me.Button_PLMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked]Add an PL Mark Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_ADD]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '[2] Set Current PL Mark ---
            '----------------------------------------------------------------------------------------------
            ' Set Current PL Mark  ==> Request_Command = "PLMARK_SETCURRENT" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "PLMARK_SETCURRENT"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentPLMarkIndex, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    'Enable Button ---   
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current PL Mark Error !(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                Me.m_CurrentPLMark = PLMark

            Catch ex As Exception
                'Enable Button ---  
                Me.Button_PLMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked]Set Current PL Mark Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try


            Me.m_Form.PaintStop = True
            Me.Button_PLMark_Enable(True)
            Me.Button_Save_PLMark.PerformClick()

        ElseIf e.ClickedItem Is Me.ToolStripMenuItem_RemovePLMark Then
            'Remove PL Mark ---
            If Me.CheckedListBox_PLMark.SelectedIndex < 0 Then Exit Sub

            If Me.CheckedListBox_PLMark.Items.Count = 1 Then
                MsgBox("至少保留一個[PL Mark] Mark", MsgBoxStyle.Critical, "[AreaGrabber]")
            Else
                If Not Me.CheckedListBox_PLMark.SelectedIndices(0) >= 0 Then
                    MsgBox("請點選欲刪除的 Mark !", "[AreaGrabber]")
                    Exit Sub
                End If

                Me.m_Form.Label_DisplayMsg.Visible = False

                Me.m_CurrentPLMarkIndex = Me.CheckedListBox_PLMark.SelectedIndices(0)
                i = Me.CheckedListBox_PLMark.SelectedIndices(0)
                j = Me.m_CurrentPLMarkIndex '
                PLMarkName = CType(Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup.Item(i), ClsPLMark).MarkName

                If File.Exists(Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup(i).MarkImagePath) Then
                    File.Delete(Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup(i).MarkImagePath)
                End If
                If File.Exists(Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup(i).BinImagePath) Then
                    File.Delete(Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup(i).BinImagePath)
                End If
                Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup.RemoveAt(i)
                Me.CheckedListBox_PLMark.Items.RemoveAt(i)

                If i = 0 Then
                    If j > i Then
                        Me.m_CurrentPLMarkIndex = j - 1
                    Else
                        Me.m_CurrentPLMarkIndex = i
                    End If
                Else
                    If Me.m_FuncProcess.PLMarkModelRecipe.PMG.PMGroup.Count = i Then
                        If j = i Then
                            Me.m_CurrentPLMarkIndex = j - 1
                        End If
                    Else
                        If j > i Then
                            Me.m_CurrentPLMarkIndex = j - 1
                        End If

                    End If
                End If

                '[1] Delete a PL Mark ---
                '----------------------------------------------------------------------------------------------
                ' Delete PL Mark ==> Request_Command = "PLMARK_DELETE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "PLMARK_DELETE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PLMarkName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        Me.Button_PLMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete PL Mark Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_DELETE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked]Delete PL Mark Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_DELETE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                '[2]Set Current PL Mark ---
                '----------------------------------------------------------------------------------------------
                ' Set Current PL Mark  ==> Request_Command = "PLMARK_SETCURRENT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "PLMARK_SETCURRENT"
                    TimeOut = 300000 '300 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentPLMarkIndex, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        Me.Button_PLMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current PL Mark Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked]Set Current PL Mark Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][PLMARK_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                '[3] Save PL Mark Model Recipe ---
                strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
                Me.m_FuncProcess.SavePLMarkModelRecipe(Me.m_IPBootConfig, strPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
                '----------------------------------------------------------------------------------------------
                ' Save PL Mark Model Recipe ==> Request_Command = "SAVE_PLMARK_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "SAVE_PLMARK_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        Me.Button_PLMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save PL Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][SAVE_PLMARK_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked]Save PL Mark Model Recipe Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][SAVE_PLMARK_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                '[4] Load PL Mark Model Recipe ---
                strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
                Me.m_FuncProcess.LoadPLMarkModelRecipe(Me.m_IPBootConfig, strPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
                Me.m_MainProcess.LogRecipeManager("[Mark Delete]" & "刪除一組PL Mark ，名稱：" & PLMarkName)

                '----------------------------------------------------------------------------------------------
                ' Load PL Mark Model Recipe ==> Request_Command = "LOAD_PLMARK_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "LOAD_PLMARK_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        Me.Button_PLMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load PL Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][LOAD_PLMARK_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked]Load PL Mark Model Recipe Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_PLMark_ItemClicked][LOAD_PLMARK_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                'Update PL Mark Image ---
                Me.Label_PLMark_CurrentMark.Text = "[Current Mark]  " & CheckedListBox_PLMark.Items(Me.m_CurrentPLMarkIndex)
                Me.Update_PLMark_Pattern(Me.m_CurrentPLMarkIndex, Me.m_FuncProcess.PLMarkModelRecipe)
            End If

            ' 上面不就有用Update_PLMark_Pattern了嗎? 還寫這個幹嘛? 前人的智慧喔?? 封印...
            'Me.NumericUpDown_PLMark_BoundaryTop.Value = 0
            'Me.NumericUpDown_PLMark_BoundaryBottom.Value = 0
            'Me.NumericUpDown_PLMark_BoundaryLeft.Value = 0
            'Me.NumericUpDown_PLMark_BoundaryRight.Value = 0
        End If

        'Button Control ---  
        Me.Button_PLMark_Enable(True)
        Me.Update()
    End Sub
#End Region

#Region "--- ContextMenuStrip_TPMark_ItemClicked ---"
    Private Sub ContextMenuStrip_TPMark_ItemClicked(sender As Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip_TPMark.ItemClicked
        Dim i As Integer
        Dim j As Integer
        Dim Parameter_Lists As String = ""
        Dim TPMarkName As String
        Dim TPMark As ClsTPMark

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If
        If Me.m_FuncProcess.TPMarkModelRecipe Is Nothing Then
            Me.m_FuncProcess.TPMarkModelRecipe = New ClsTPMarkModelRecipe
        End If

        '--- Disable Button ---  
        Me.Button_TPMark_Enable(False)
        Me.Focus()
        Me.BringToFront()

        If e.ClickedItem Is Me.ToolStripMenuItem_AddTPMark Then

            For Each TPMark_temp As ClsTPMark In Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup
                If (TPMark_temp.MarkName = Me.TextBox_TPMark_MarkName.Text) Then
                    MsgBox("Mark名稱已有,請設定其他Mark名稱 !")
                    Exit Sub
                End If
            Next

            '--- Add PL Mark ---
            If Me.m_AddMode_TPMark = True Then
                MsgBox("請設定完成 Mark 後，再執行其他動作.(選取Mark原則: 選取非部分影像或模陵兩可之影像Mark)")
                Exit Sub
            End If
            Me.m_AddMode_TPMark = True

            '[1] Add New PL Mark 
            i = Me.CheckedListBox_TPMark.Items.Count + 1
            TPMarkName = Me.TextBox_TPMark_MarkName.Text
            Me.CheckedListBox_TPMark.Items.Add(TPMarkName)
            Me.m_CurrentTPMarkIndex = i - 1

            TPMark = New ClsTPMark
            TPMark.MarkName = TPMarkName
            TPMark.Mark_Acceptance = Me.NumericUpDown_TPMark_Acceptance.Value
            TPMark.Mark_Action = Me.ComboBox_TPMark_Action.Text

            If Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup Is Nothing Then
                Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup = New ArrayList
            End If
            Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup.Add(TPMark)

            '----------------------------------------------------------------------------------------------
            ' Add A New TP Mark ==> Request_Command = "TPMARK_ADD" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "TPMARK_ADD"
                TimeOut = 100000 '100 secs

                Parameter_Lists = Parameter_Lists & "TPMark_MarkName," & Me.TextBox_TPMark_MarkName.Text & ";" & "TPMark_Acceptance," & TPMark.Mark_Acceptance & ";" & "TPMark_Action," & TPMark.Mark_Action & ";"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    '--- Enable Button ---   
                    Me.Button_TPMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add A New TP Mark Error !(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_ADD]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                '--- Enable Button ---  
                Me.Button_TPMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked]Add A TP Mark Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_ADD]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '[2] Set Current TP Mark ---
            '----------------------------------------------------------------------------------------------
            ' Set Current TP Mark  ==> Request_Command = "TPMARK_SETCURRENT" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "TPMARK_SETCURRENT"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentTPMarkIndex, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    '--- Enable Button ---   
                    Me.Button_TPMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current TP Mark Error !(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                '--- Enable Button ---  
                Me.Button_TPMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked]Set Current TP Mark Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            Me.NumericUpDown_TPMark_BoundaryTop.Value = 0
            Me.NumericUpDown_TPMark_BoundaryBottom.Value = 0
            Me.NumericUpDown_TPMark_BoundaryLeft.Value = 0
            Me.NumericUpDown_TPMark_BoundaryRight.Value = 0

            Me.CheckBox_TPMark_ShowBoundary.Checked = True
            Me.CheckBox_TPMark_RegionMannual.Checked = True
            Me.m_Form.PaintStop = False
            Me.Button_TPMark_Enable(True)

        ElseIf e.ClickedItem Is Me.ToolStripMenuItem_EditTPMark Then
            '--- Edit TP Mark ---
            If Me.CheckedListBox_TPMark.SelectedIndex < 0 Then Exit Sub

            Me.m_CurrentTPMarkIndex = Me.CheckedListBox_TPMark.SelectedIndex

            '----------------------------------------------------------------------------------------------
            ' Set Current PL Mark  ==> Request_Command = "TPMARK_SETCURRENT" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                'Prepare Command ---
                Request_Command = "TPMARK_SETCURRENT"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentTPMarkIndex, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    '--- Enable Button ---   
                    Me.Button_TPMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current TP Mark Error !(" & SubSystemResult.ErrMessage & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                '--- Enable Button ---  
                Me.Button_TPMark_Enable(True)
                Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked]Set Current TP Mark Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            Me.m_CurrentTPMark = Me.m_FuncProcess.TPMarkModelRecipe.TPG.Item(m_CurrentTPMarkIndex)
            '--- Update Information ---
            Me.m_CurrentTPMark.Mark_Action = Me.ComboBox_TPMark_Action.Text

            Me.Update_TPMark_Pattern(Me.m_CurrentTPMarkIndex, Me.m_FuncProcess.TPMarkModelRecipe)

        ElseIf e.ClickedItem Is Me.ToolStripMenuItem_RemoveTPMark Then
            '--- Remove PL Mark ---
            If Me.CheckedListBox_TPMark.SelectedIndex < 0 Then Exit Sub

            If Me.CheckedListBox_TPMark.Items.Count = 1 Then
                MsgBox("至少保留一個[TP Mark] Mark", MsgBoxStyle.Critical, "[AreaGrabber]")
            Else
                If Not Me.CheckedListBox_TPMark.SelectedIndices(0) >= 0 Then
                    MsgBox("請點選欲刪除的 Mark !", "[AreaGrabber]")
                    Exit Sub
                End If

                Me.CheckBox_TPMark_ShowResult.Checked = False
                Me.m_Form.Label_DisplayMsg.Visible = False

                If MsgBox("[TP Mark] Mark 名稱: " & Me.m_FuncProcess.TPMarkModelRecipe.TPG.Item(Me.CheckedListBox_TPMark.SelectedIndices(0)).MarkName & " '" & "是否刪除", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    Me.m_CurrentTPMarkIndex = Me.CheckedListBox_TPMark.SelectedIndices(0)
                    i = Me.CheckedListBox_TPMark.SelectedIndices(0)
                    j = Me.m_CurrentTPMarkIndex '
                    TPMarkName = CType(Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup.Item(i), ClsTPMark).MarkName

                    If File.Exists(Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup(i).MarkImagePath) Then
                        File.Delete(Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup(i).MarkImagePath)
                    End If
                    Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup.RemoveAt(i)
                    Me.CheckedListBox_TPMark.Items.RemoveAt(i)

                    If i = 0 Then
                        If j > i Then
                            Me.m_CurrentTPMarkIndex = j - 1
                        Else
                            Me.m_CurrentTPMarkIndex = i
                        End If
                    Else
                        If Me.m_FuncProcess.TPMarkModelRecipe.TPG.TPMGroup.Count = i Then
                            If j = i Then
                                Me.m_CurrentTPMarkIndex = j - 1
                            End If
                        Else
                            If j > i Then
                                Me.m_CurrentTPMarkIndex = j - 1
                            End If

                        End If
                    End If

                    '--- [1] Delete a TP Mark ---
                    '----------------------------------------------------------------------------------------------
                    ' Delete a TP Mark ==> Request_Command = "TPMARK_DELETE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "TPMARK_DELETE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, TPMarkName, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---   
                            Me.Button_TPMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete TP Mark Error !(" & SubSystemResult.ErrMessage & ")")
                            MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_DELETE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---  
                        Me.Button_TPMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked]Delete TP Mark Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_DELETE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try

                    '--- [2]Set Current TP Mark ---
                    '----------------------------------------------------------------------------------------------
                    ' Set Current TP Mark  ==> Request_Command = "TPMARK_SETCURRENT" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "TPMARK_SETCURRENT"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentTPMarkIndex, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---   
                            Me.Button_TPMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current TP Mark Error !(" & SubSystemResult.ErrMessage & ")")
                            MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---  
                        Me.Button_TPMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked]Set Current TP Mark Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][TPMark_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try

                    '--- [3] Save PL Mark Model Recipe ---
                    strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
                    Me.m_FuncProcess.SaveTPMarkModelRecipe(Me.m_IPBootConfig, strPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
                    '----------------------------------------------------------------------------------------------
                    ' Save PL Mark Model Recipe ==> Request_Command = "SAVE_TPMARK_MODEL_RECIPE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SAVE_TPMARK_MODEL_RECIPE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---   
                            Me.Button_TPMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save TP Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                            MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][SAVE_TPMark_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---  
                        Me.Button_TPMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked]Save TP Mark Model Recipe Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][SAVE_TPMark_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try

                    '--- [4] Load TP Mark Model Recipe ---
                    strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
                    Me.m_FuncProcess.LoadTPMarkModelRecipe(Me.m_IPBootConfig, strPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
                    Me.m_MainProcess.LogRecipeManager("[Mark Delete]" & "刪除一組TP Mark ，名稱：" & TPMarkName)

                    '----------------------------------------------------------------------------------------------
                    ' Load TP Mark Model Recipe ==> Request_Command = "LOAD_TPMARK_MODEL_RECIPE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "LOAD_TPMARK_MODEL_RECIPE"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---   
                            Me.Button_TPMark_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load TP Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                            MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][LOAD_TPMark_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---  
                        Me.Button_TPMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked]Load TP Mark Model Recipe Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_FuncSetting.ContextMenuStrip_TPMark_ItemClicked][LOAD_TPMark_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try

                    '--- Update PL Mark Image ---
                    Me.Label_TPMark_CurrentMark.Text = "[Current Mark]  " & CheckedListBox_TPMark.Items(Me.m_CurrentTPMarkIndex)
                    Me.Update_TPMark_Pattern(Me.m_CurrentTPMarkIndex, Me.m_FuncProcess.TPMarkModelRecipe)

                End If
            End If

            Me.NumericUpDown_TPMark_BoundaryTop.Value = 0
            Me.NumericUpDown_TPMark_BoundaryBottom.Value = 0
            Me.NumericUpDown_TPMark_BoundaryLeft.Value = 0
            Me.NumericUpDown_TPMark_BoundaryRight.Value = 0
        End If

        '---Button Control ---  
        Me.Button_TPMark_Enable(True)
        Me.Update()
    End Sub
#End Region

#End Region

#Region "--- CheckedListBox Event ---"

#Region "--- PLMark ---"

#Region "--- CheckedListBox_PLMark_MouseClick ---"
    Private Sub CheckedListBox_PLMark_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles CheckedListBox_PLMark.MouseClick
        Dim filepath As String
        Dim imageBuffer As MIL_ID = M_NULL
        Dim PatternMark As ClsPLMark
        Dim SizeX, SizeY, Type As Integer
        Dim Parameter_Lists As String = ""

        Try
            Me.CheckBox_MarkTH.Checked = False
            Me.m_CurrentPLMarkIndex = Me.CheckedListBox_PLMark.SelectedIndex
            If Me.m_CurrentPLMarkIndex >= 0 Then

                '建立連線 ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                'Disable Button ---  
                Me.Button_Enable(False)

                'Show PL Mark Info ---   
                PatternMark = Me.m_FuncProcess.PLMarkModelRecipe.PMG.Item(Me.m_CurrentPLMarkIndex)
                Me.TextBox_PLMark_MarkName.Text = PatternMark.MarkName
                Me.Label_PLMark_CurrentMark.Text = "[Current Mark]  " & PatternMark.MarkName
                Me.NumericUpDown_PLMark_Acceptance.Value = PatternMark.Mark_Acceptance
                Me.CheckBox_CurrentPLMark_Enable.Checked = PatternMark.MarkEnable
                Me.NumericUpDown_MarkGroup.Value = PatternMark.Mark_Group
                Me.NumericUpDown_MarkTH.Value = PatternMark.MarkTH

                'Mark Boundary ---
                Me.NumericUpDown_PLMark_BoundaryTop.Value = PatternMark.MarkBoundary.TopY
                Me.NumericUpDown_PLMark_BoundaryBottom.Value = PatternMark.MarkBoundary.BottomY
                Me.NumericUpDown_PLMark_BoundaryLeft.Value = PatternMark.MarkBoundary.LeftX
                Me.NumericUpDown_PLMark_BoundaryRight.Value = PatternMark.MarkBoundary.RightX

                'Match Setting ---   
                If PatternMark.MatchImg = "GrayMark" Then
                    Me.ComboBox_MatchImg.SelectedIndex = 1
                Else
                    Me.ComboBox_MatchImg.SelectedIndex = 0
                End If
                Me.CheckBox_PreProcess.Checked = PatternMark.PreProcess
                Me.NumericUpDown_GrayMarkSmoothCount.Value = PatternMark.GrayMarkSmoothCount
                Me.NumericUpDown_GrayMarkErodeCount.Value = PatternMark.GrayMarkErodeCount

                'Bypass Setting ---
                If PatternMark.BypassRegion = "MarkBlock" Then
                    Me.ComboBox_BypassRegion.SelectedIndex = 1
                Else
                    Me.ComboBox_BypassRegion.SelectedIndex = 0
                End If
                Me.CheckBox_BlobFillHole.Checked = PatternMark.BlobFillHole
                Me.NumericUpDown_PLMark_DilateCount.Value = PatternMark.Mark_DilateCount

                'Show PL Mark Image ---   
                filepath = Me.m_FuncProcess.PLMarkModelRecipe.PMG.Item(Me.m_CurrentPLMarkIndex).MarkImagePath
                If File.Exists(filepath) Then
                    MbufClear(Me.m_MainProcess.Img_PLMark_NonPage, 0L)  '2012/12/06 Rick add

                    MbufDiskInquire(filepath, M_SIZE_X, SizeX)
                    MbufDiskInquire(filepath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(filepath, M_TYPE, Type)
                    If MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_PLMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_PLMark_NonPage)
                        Me.m_MainProcess.Img_PLMark_NonPage = M_NULL
                        Me.m_MainProcess.Img_PLMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(filepath, Me.m_MainProcess.Img_PLMark_NonPage)

                    '--- Display ---
                    MdispSelectWindow(Me.m_AxMDisplay_PLMark, Me.m_MainProcess.Img_PLMark_NonPage, Me.Panel_AxMDisplay_PLMark.Handle)
                    MbufControl(Me.m_MainProcess.Img_PLMark_NonPage, M_MODIFIED, M_DEFAULT)
                    MdispControl(Me.m_AxMDisplay_PLMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                    Me.PLMark_ImageZoomAll()
                    Me.RadioButton_PLMark_Original.Checked = True
                End If

                '----------------------------------------------------------------------------------------------
                ' Set Current PL Mark  ==> Request_Command = "PLMARK_SETCURRENT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "PLMARK_SETCURRENT"
                    TimeOut = 300000 '300 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentPLMarkIndex, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        Me.Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current PL Mark Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_GlassEdgeSetting.Update_PLMark_Pattern][PLMARK_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    Me.Button_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_GlassEdgeSetting.Update_PLMark_Pattern]Set Current PL Mark Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_GlassEdgeSetting.Update_PLMark_Pattern][PLMARK_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                Me.CheckBox_CurrentPLMark_Enable.Checked = PatternMark.MarkEnable

                If PatternMark.MarkEnable Then
                    Me.CheckedListBox_PLMark.SetItemCheckState(Me.m_CurrentPLMarkIndex, CheckState.Checked)
                Else
                    Me.CheckedListBox_PLMark.SetItemCheckState(Me.m_CurrentPLMarkIndex, CheckState.Unchecked)
                End If

                'Button Control ---  
                Me.Button_Enable(True)
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            MsgBox("[Dialog_GlassEdgeSetting.CheckedListBox_PLMark_MouseClick] Mouse Click Mark Item Error !：" & vbCrLf & ex.Message & "，請確認。", MsgBoxStyle.Information, "[LineGrabber]")
        End Try
    End Sub
#End Region

#Region "--- CheckedListBox_PLMark_MouseEnter ---"
    Private Sub CheckedListBox_PLMark_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckedListBox_PLMark.MouseEnter
        Me.CheckedListBox_PLMark.ContextMenuStrip = Me.ContextMenuStrip_PLMark
    End Sub
#End Region

#Region "--- CheckedListBox_PLMark_MouseLeave ---"
    Private Sub CheckedListBox_PLMark_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckedListBox_PLMark.MouseLeave
        Me.CheckedListBox_PLMark.ContextMenuStrip = Nothing
    End Sub
#End Region

#End Region

#Region "--- TPMark ---"

#Region "--- CheckedListBox_TPMark_MouseClick ---"
    Private Sub CheckedListBox_TPMark_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles CheckedListBox_TPMark.MouseClick
        Dim filepath As String
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim PatternMark As ClsTPMark
        Dim SizeX, SizeY, Type As Integer

        Try
            Me.m_CurrentTPMarkIndex = Me.CheckedListBox_TPMark.SelectedIndex
            If Me.m_CurrentTPMarkIndex >= 0 Then

                '--- 建立連線 ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                '--- Disable Button ---  
                Me.Button_Enable(False)

                '--- Show TP Mark Info ---   
                PatternMark = Me.m_FuncProcess.TPMarkModelRecipe.TPG.Item(Me.m_CurrentTPMarkIndex)
                Me.TextBox_TPMark_MarkName.Text = PatternMark.MarkName
                Me.Label_TPMark_CurrentMark.Text = "[Current Mark]  " & PatternMark.MarkName
                Me.NumericUpDown_TPMark_Acceptance.Value = PatternMark.Mark_Acceptance
                Me.ComboBox_TPMark_Action.Text = PatternMark.Mark_Action
                If (PatternMark.Mark_Action = "") Then
                    Me.ComboBox_TPMark_Action.Text = "OK"
                End If

                '--- Boundary ---
                Me.NumericUpDown_TPMark_BoundaryTop.Value = PatternMark.MarkBoundary.TopY
                Me.NumericUpDown_TPMark_BoundaryBottom.Value = PatternMark.MarkBoundary.BottomY
                Me.NumericUpDown_TPMark_BoundaryLeft.Value = PatternMark.MarkBoundary.LeftX
                Me.NumericUpDown_TPMark_BoundaryRight.Value = PatternMark.MarkBoundary.RightX

                '--- Show PL Mark Image ---   
                filepath = Me.m_FuncProcess.TPMarkModelRecipe.TPG.Item(Me.m_CurrentTPMarkIndex).MarkImagePath
                If File.Exists(filepath) Then
                    MbufClear(Me.m_MainProcess.Img_TPMark_NonPage, 0L)  '

                    MbufDiskInquire(filepath, M_SIZE_X, SizeX)
                    MbufDiskInquire(filepath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(filepath, M_TYPE, Type)
                    If MbufInquire(Me.m_MainProcess.Img_TPMark_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_TPMark_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_TPMark_NonPage)
                        Me.m_MainProcess.Img_TPMark_NonPage = M_NULL
                        Me.m_MainProcess.Img_TPMark_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(filepath, Me.m_MainProcess.Img_TPMark_NonPage)

                    '--- Display ---
                    image = Me.m_MainProcess.Img_TPMark_NonPage
                    MdispSelectWindow(Me.m_AxMDisplay_TPMark, image, Me.Panel_AxMDisplay_TPMark.Handle)
                    MbufControl(image, M_MODIFIED, M_DEFAULT)
                    MdispControl(Me.m_AxMDisplay_TPMark, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                    Me.TPMark_ImageZoomAll()
                End If

                '----------------------------------------------------------------------------------------------
                ' Set Current TP Mark  ==> Request_Command = "TPMARK_SETCURRENT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "TPMARK_SETCURRENT"
                    TimeOut = 300000 '300 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_CurrentTPMarkIndex, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        '--- Enable Button ---   
                        Me.Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current TP Mark Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_GlassEdgeSetting.Update_TPMark_Pattern][TPMark_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    '--- Enable Button ---  
                    Me.Button_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_GlassEdgeSetting.Update_TPMark_Pattern]Set Current TP Mark Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_GlassEdgeSetting.Update_TPMark_Pattern][TPMark_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                '--- Button Control ---  
                Me.Button_Enable(True)
            End If
        Catch ex As Exception
            Me.Button_Enable(True)
            MsgBox("[Dialog_GlassEdgeSetting.CheckedListBox_TPMark_MouseClick] Mouse Click Mark Item Error !：" & vbCrLf & ex.Message & "，請確認。", MsgBoxStyle.Information, "[LineGrabber]")
        End Try
    End Sub
#End Region

#Region "--- CheckedListBox_TPMark_MouseEnter ---"
    Private Sub CheckedListBox_TPMark_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckedListBox_TPMark.MouseEnter
        Me.CheckedListBox_TPMark.ContextMenuStrip = Me.ContextMenuStrip_TPMark
    End Sub
#End Region

#Region "--- CheckedListBox_TPMark_MouseLeave ---"
    Private Sub CheckedListBox_TPMark_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckedListBox_TPMark.MouseLeave
        Me.CheckedListBox_TPMark.ContextMenuStrip = Nothing
    End Sub
#End Region

#End Region

#End Region

#Region "--- TabPage Event ---"

    Private Sub TabControl_Setting_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles TabControl_Setting.SelectedIndexChanged
        Dim PLMark_Enable As Boolean = False
        Try
            '--- Point -------
            GroupBox_DPoint.Enabled = False
            GroupBox_BPoint.Enabled = False
            GroupBox_PointMode.Enabled = False
            GroupBox_PointCommonSetting.Enabled = False
            '--- Line --------
            CheckBox_BLine_Enable.Enabled = False
            GroupBox_BLine.Enabled = False
            CheckBox_DLine_Enable.Enabled = False
            GroupBox_DLine.Enabled = False
            GroupBox_LineCommonSetting.Enabled = False
            GroupBox_MeanDiff.Enabled = False
            '--- GrayAbnormal -----
            GroupBox_GrayAbnormal.Enabled = False
            '--- Pitch Setting -----
            GroupBox_PointPitchSetting.Enabled = False
            GroupBox_Point_Algorithm.Enabled = False
            GroupBox_LinePitchSetting.Enabled = False
            GroupBox_LineAverageFilter.Enabled = False
            '--- PLMark -----
            Me.CheckedListBox_PLMark.Enabled = False
            Me.GroupBox_PLMark_Setting.Enabled = False
            Me.Button_PLMark_PatTest.Enabled = False
            Me.Button_Save_PLMark.Enabled = False


            Select Case TabControl_Setting.SelectedIndex
                Case 0  'Point
                    If CheckBox_Point_Enable.Checked Then
                        GroupBox_PointMode.Enabled = True
                        GroupBox_PointCommonSetting.Enabled = True
                        GroupBox_BPoint.Enabled = True
                        GroupBox_DPoint.Enabled = True
                    Else
                        GroupBox_PointMode.Enabled = False
                        GroupBox_PointCommonSetting.Enabled = False
                        GroupBox_DPoint.Enabled = False
                        GroupBox_BPoint.Enabled = False
                    End If

                    If RadioButton_BP.Checked = True Then
                        GroupBox_BPoint.Enabled = True
                        GroupBox_DPoint.Enabled = False
                    End If
                    If RadioButton_DP.Checked = True Then
                        GroupBox_DPoint.Enabled = True
                        GroupBox_BPoint.Enabled = False
                    End If
                    If RadioButton_BPDP.Checked = True Then
                        GroupBox_BPoint.Enabled = True
                        GroupBox_DPoint.Enabled = True
                    End If
                Case 1   'Point Characteristics
                    Me.GroupBox_BP_Characteristics.Enabled = CheckBox_Point_Enable.Checked
                    Me.GroupBox_DP_Characteristics.Enabled = CheckBox_Point_Enable.Checked
                Case 2   'GSBDP
                    '--- GSBP ---
                    Me.GroupBox_GSBP.Enabled = CheckBox_GSBP_Enable.Checked
                    Me.GroupBox_GSBPCommonSetting.Enabled = CheckBox_GSBP_Enable.Checked
                    '--- BLDP ---
                    Me.GroupBox_BLDP.Enabled = CheckBox_BLDP_Enable.Checked
                    Me.GroupBox_BLDPCommonSetting.Enabled = CheckBox_BLDP_Enable.Checked
                Case 3   'Line
                    CheckBox_BLine_Enable.Enabled = CheckBox_Line_Enable.Checked
                    CheckBox_DLine_Enable.Enabled = CheckBox_Line_Enable.Checked
                    GroupBox_BLine.Enabled = CheckBox_BLine_Enable.Checked
                    GroupBox_DLine.Enabled = CheckBox_DLine_Enable.Checked
                    GroupBox_MeanDiff.Enabled = CheckBox_Line_Enable.Checked
                    GroupBox_LineCommonSetting.Enabled = CheckBox_Line_Enable.Checked
                Case 4   'Gray Abnormal
                    GroupBox_GrayAbnormal.Enabled = CheckBox_GrayAbnormal_Enable.Checked
                Case 5  'Auto

                Case 6   'Pitch
                    GroupBox_PointPitchSetting.Enabled = True
                    GroupBox_Point_Algorithm.Enabled = True
                    GroupBox_LinePitchSetting.Enabled = True
                    GroupBox_LineAverageFilter.Enabled = True
                Case 7   'PL Mark
                    PLMark_Enable = Me.m_IPBootConfig.PLMarkUI.Value And Me.CheckBox_PLMark_Enable.Checked
                    Me.CheckedListBox_PLMark.Enabled = PLMark_Enable
                    Me.GroupBox_PLMark_Setting.Enabled = PLMark_Enable
                    Me.Button_PLMark_PatTest.Enabled = PLMark_Enable
                    Me.Button_Save_PLMark.Enabled = PLMark_Enable
                Case 8
                    Me.RadioButton_HotPixel_Threshold.Checked = False
                    Me.GroupBox_HotPixel.Enabled = Me.CheckBox_HotPixelEnable.Checked

            End Select
            '--- Initial --- 
            '--- Point ---
            Me.RadioButton_BP_Threshold.Checked = False
            Me.RadioButton_BP_RimThreshold.Checked = False
            Me.RadioButton_DP_Threshold.Checked = False
            Me.RadioButton_DP_Threshold_Low.Checked = False
            Me.RadioButton_DP_RimThreshold.Checked = False
            Me.RadioButton_DP_RimThreshold_Low.Checked = False
            '--- Line ---
            Me.RadioButton_DL_Threshold.Checked = False
            Me.RadioButton_BL_Threshold.Checked = False

            Me.UpdateUserLevel()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.TabControl_Setting]" & ex.Message)
            MessageBox.Show("[Dialog_FuncSetting.TabControl_Setting]" & ex.Message, "~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- NumericUpDown Event ---"

#Region "NumericUpDown_MarkTH_ValueChanged"
    Private Sub NumericUpDown_MarkTH_ValueChanged(sender As Object, e As System.EventArgs) Handles NumericUpDown_MarkTH.ValueChanged
        If Me.CheckBox_MarkTH.Checked Then
            If Me.CheckedListBox_PLMark.Items.Count > 0 Then
                Me.m_UpdatePLTH = True
                Me.Button_Save_PLMark.PerformClick()
                Me.RadioButton_PLMark_Bin.Checked = True
                Me.m_UpdatePLTH = False
            End If
        End If
    End Sub
#End Region

#Region "NumericUpDown_WakuValue_ValueChanged"
    Private Sub NumericUpDown_WakuMinValue_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_WakuMinValue.ValueChanged, NumericUpDown_WakuMaxValue.ValueChanged
        If Me.CheckBox_Waku_Inspect_Enable.Checked Then
            Dim edgeName As String = Me.ComboBox_WakuEdge.Text
            Dim fpr As ClsFuncPatternRecipe = Me.m_FuncProcess.CurrentFuncPatternRecipe
            Select Case edgeName
                Case "TOP"
                    fpr.TopWakuValueMin.Value = Me.NumericUpDown_WakuMinValue.Value
                    fpr.TopWakuValueMax.Value = Me.NumericUpDown_WakuMaxValue.Value
                Case "BOTTOM"
                    fpr.BottomWakuValueMin.Value = Me.NumericUpDown_WakuMinValue.Value
                    fpr.BottomWakuValueMax.Value = Me.NumericUpDown_WakuMaxValue.Value
                Case "LEFT"
                    fpr.LeftWakuValueMin.Value = Me.NumericUpDown_WakuMinValue.Value
                    fpr.LeftWakuValueMax.Value = Me.NumericUpDown_WakuMaxValue.Value
                Case "RIGHT"
                    fpr.RightWakuValueMin.Value = Me.NumericUpDown_WakuMinValue.Value
                    fpr.RightWakuValueMax.Value = Me.NumericUpDown_WakuMaxValue.Value
            End Select
        End If
    End Sub
#End Region

#Region "NumericUpDown_WakuMaxValue_ValueChanged"
    Private Sub NumericUpDown_WakuSize_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_WakuSplitNum.ValueChanged, NumericUpDown_WakuEdgeWidth.ValueChanged, NumericUpDown_WakuEdgeOffset.ValueChanged
        If Me.CheckBox_Waku_Inspect_Enable.Checked Then
            Dim fpr As ClsFuncPatternRecipe = Me.m_FuncProcess.CurrentFuncPatternRecipe
            fpr.WakuSplitNum.Value = Me.NumericUpDown_WakuSplitNum.Value
            fpr.WakuEdgeWidth.Value = Me.NumericUpDown_WakuEdgeWidth.Value
            fpr.WakuEdgeOffset.Value = Me.NumericUpDown_WakuEdgeOffset.Value
        End If

    End Sub
#End Region

#End Region

    Private Sub CheckBox_Waku_Inspect_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_Waku_Inspect_Enable.CheckedChanged
        Me.NumericUpDown_WakuSplitNum.Enabled = Me.CheckBox_Waku_Inspect_Enable.Checked
        Me.NumericUpDown_WakuEdgeWidth.Enabled = Me.CheckBox_Waku_Inspect_Enable.Checked
        Me.NumericUpDown_WakuEdgeOffset.Enabled = Me.CheckBox_Waku_Inspect_Enable.Checked
        Me.NumericUpDown_WakuMaxValue.Enabled = Me.CheckBox_Waku_Inspect_Enable.Checked
        Me.NumericUpDown_WakuMinValue.Enabled = Me.CheckBox_Waku_Inspect_Enable.Checked
    End Sub

    Private Sub CheckBox_PLMark_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_PLMark_Enable.CheckedChanged
        Dim PLMark As Boolean = False
        PLMark = Me.CheckBox_PLMark_Enable.Checked And Me.m_IPBootConfig.PLMarkUI.Value
        Me.GroupBox_PLMark_Setting.Enabled = PLMark
        Me.CheckedListBox_PLMark.Enabled = PLMark
        Me.CheckBox_CurrentPLMark_Enable.Enabled = PLMark
        Me.Button_PLMark_PatTest.Enabled = PLMark
        Me.Button_Save_PLMark.Enabled = PLMark
        Me.NumericUpDown_MarkTH.Enabled = PLMark
        Me.RadioButton_PLMark_Original.Enabled = PLMark
        Me.RadioButton_PLMark_Bin.Enabled = PLMark
        Me.m_FuncProcess.CurrentFuncPatternRecipe.PLMarkEnable.Value = PLMark
    End Sub


    Private Function GetUNCPath(ByVal sFilePath As String) As String

        Dim allDrives() As DriveInfo = DriveInfo.GetDrives()
        Dim d As DriveInfo
        Dim DriveType, Ctr As Integer
        Dim DriveLtr, UNCName As String
        Dim StrBldr As New StringBuilder

        If sFilePath.StartsWith("\\") Then Return sFilePath

        UNCName = Space(160)
        GetUNCPath = ""

        DriveLtr = sFilePath.Substring(0, 3)

        For Each d In allDrives
            If d.Name = DriveLtr Then
                DriveType = d.DriveType
                Exit For
            End If
        Next

        If DriveType = 4 Then

            Ctr = WNetGetConnection(sFilePath.Substring(0, 2), UNCName, UNCName.Length)

            If Ctr = 0 Then
                UNCName = UNCName.Trim
                For Ctr = 0 To UNCName.Length - 1
                    Dim SingleChar As Char = UNCName(Ctr)
                    Dim asciiValue As Integer = Asc(SingleChar)
                    If asciiValue > 0 Then
                        StrBldr.Append(SingleChar)
                    Else
                        Exit For
                    End If
                Next
                StrBldr.Append(sFilePath.Substring(2))
                GetUNCPath = StrBldr.ToString
            Else
                MsgBox("Cannot Retrieve UNC path" & vbCrLf & "Must Use Mapped Drive of SQLServer", MsgBoxStyle.Critical)
            End If
        Else
            GetUNCPath = sFilePath
        End If

    End Function

    Declare Function WNetGetConnection Lib "mpr.dll" Alias "WNetGetConnectionA" (ByVal lpszLocalName As String, _
      ByVal lpszRemoteName As String, ByRef cbRemoteName As Integer) As Integer

End Class
