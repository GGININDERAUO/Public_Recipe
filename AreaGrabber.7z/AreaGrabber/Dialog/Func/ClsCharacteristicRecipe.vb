﻿Imports System.IO
Imports System.Xml.Serialization
Imports ClassLibrary


Public Class ClsCharacteristicRecipe
    Public GrayMin_Min As ClsInteger
    Public GrayMin_Max As ClsInteger
    Public GrayMax_Min As ClsInteger
    Public GrayMax_Max As ClsInteger
    Public Elongation_Min As ClsDouble
    Public Elongation_Max As ClsDouble
    Public Fullness_Min As ClsDouble
    Public Fullness_Max As ClsDouble
    Public Compactness_Max As ClsDouble

    Public Sub New()

        Dim IndexBase As Long = 2100

        IndexBase += 1
        Me.GrayMin_Min = New ClsInteger("GrayMin_Min", 0, IndexBase)
        IndexBase += 1
        Me.GrayMin_Max = New ClsInteger("GrayMin_Max", 0, IndexBase)
        IndexBase += 1
        Me.GrayMax_Min = New ClsInteger("GrayMax_Min", 0, IndexBase)
        IndexBase += 1
        Me.GrayMax_Max = New ClsInteger("GrayMax_Max", 0, IndexBase)
        IndexBase += 1
        Me.Elongation_Min = New ClsDouble("Elongation_Min", 0.0, IndexBase)
        IndexBase += 1
        Me.Elongation_Max = New ClsDouble("Elongation_Max", 0.0, IndexBase)
        IndexBase += 1
        Me.Fullness_Min = New ClsDouble("Fullness_Min", 0.0, IndexBase)
        IndexBase += 1
        Me.Fullness_Max = New ClsDouble("Fullness_Max", 0.0, IndexBase)
        IndexBase += 1
        Me.Compactness_Max = New ClsDouble("Compactness_Max", 0.0, IndexBase)

    End Sub

    Public Sub New(ByVal lfbp As ClsCharacteristicRecipe)   '10/25 Rick add
        Dim IndexBase As Long = 2100

        IndexBase += 1
        Me.GrayMin_Min = New ClsInteger("GrayMin", lfbp.GrayMin_Min.Value, IndexBase)
        IndexBase += 1
        Me.GrayMin_Max = New ClsInteger("GrayMin_Max", lfbp.GrayMin_Max.Value, IndexBase)
        IndexBase += 1
        Me.GrayMax_Min = New ClsInteger("GrayMax_Min", lfbp.GrayMax_Min.Value, IndexBase)
        IndexBase += 1
        Me.GrayMax_Max = New ClsInteger("GrayMax_Max", lfbp.GrayMax_Max.Value, IndexBase)
        IndexBase += 1
        Me.Elongation_Min = New ClsDouble("Elongation_Min", lfbp.Elongation_Min.Value, IndexBase)
        IndexBase += 1
        Me.Elongation_Max = New ClsDouble("Elongation_Max", lfbp.Elongation_Max.Value, IndexBase)
        IndexBase += 1
        Me.Fullness_Min = New ClsDouble("Fullness_Min", lfbp.Fullness_Min.Value, IndexBase)
        IndexBase += 1
        Me.Fullness_Max = New ClsDouble("Fullness_Max", lfbp.Fullness_Max.Value, IndexBase)
        IndexBase += 1
        Me.Compactness_Max = New ClsDouble("Compactness_Max", lfbp.Compactness_Max.Value, IndexBase)

    End Sub

    Public Shared Sub WriteXML(ByVal Characteristic As ClsCharacteristicRecipe, ByVal fileName As String)
        Dim serializer As XmlSerializer
        Dim writer As StreamWriter
        serializer = New XmlSerializer(GetType(ClsCharacteristicRecipe))
        writer = New StreamWriter(fileName)
        serializer.Serialize(writer, Characteristic)
        writer.Close()
    End Sub

    Public Shared Function ReadXML(ByVal fileName As String) As ClsCharacteristicRecipe
        Dim serializer As XmlSerializer
        Dim fs As FileStream
        Dim Characteristic As ClsCharacteristicRecipe
        serializer = New XmlSerializer(GetType(ClsCharacteristicRecipe))
        fs = New FileStream(fileName, FileMode.Open)
        Characteristic = CType(serializer.Deserialize(fs), ClsCharacteristicRecipe)
        fs.Close()
        Return Characteristic
    End Function

End Class
