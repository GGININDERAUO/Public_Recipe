Imports System.Windows.Forms
Imports System.IO
Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl
Imports System.Threading
Imports System.Globalization

<CLSCompliant(False)> _
Public Class Dialog_FuncSettingBase
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig

    Private m_ModelChanged As Boolean
    Private m_PatternChanged As Boolean

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- �h�s�u�Ѽ� ---
    Private m_ConnectedIP As ArrayList
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button

    Private res As System.Resources.ResourceManager '

#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL

        Try
            '--- Change Language ---
            res = New Resources.ResourceManager("AreaGrabber.Dialog_FuncSettingBase", Me.GetType().Assembly)
            Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
            Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
            Me.changeLanguage(language)
            '------------
            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess
            Me.m_FuncProcess = form.MainProcess.FuncProcess
            Me.m_MuraProcess = form.MainProcess.MuraProcess

            Me.m_ModelChanged = False
            Me.m_PatternChanged = False

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            Else
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            End If

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig

            image = Me.m_FuncProcess.Img_Original_NonPage
            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If

            '--- UI ---
            Me.m_VScrollBar = Me.m_Form.VScrollBar
            Me.m_HScrollBar = Me.m_Form.HScrollBar

            Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
            Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
            Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
            Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
            '--- UI ---

            Me.UpdateData()
            Me.UpdateUserLevel()
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncSettingBase.SetMainForm]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Dialog Event ---"

#Region "--- Dialog_FuncSettingBase_Load ---"
    Private Sub Dialog_FuncSettingBase_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim PatternName As String = ""
        Dim Path As String = ""
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Me.Text = "Model�Ѽƽվ� [ " & Me.m_Form.GetProductNameInfo & " ]"

        Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
        RepairPath_2(Path)
        Me.m_FuncProcess.FuncModelRecipe = MILOperationLib.ClsFuncModelRecipe.ReadXML(Path)

        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 200000 '200 secs

                '--- PatternName ---
                PatternName = Me.m_Form.ComboBox_Pattern_MainFrm.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]Set Pattern Index Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

        Me.m_Form.ImageUpdate()
        Me.Update()
    End Sub
#End Region

#Region "--- Dialog_FuncSettingBase_Closing ---"
    Private Sub Dialog_FuncSettingBase_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.m_Form.PaintStop = True
        Me.m_Form.Focus()
        Me.Finalize()
    End Sub
#End Region

#End Region

#Region "--- ��k�禡 ---"

#Region "--- UpdateUserLevel ---"

    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.TabControl_FuncSetting.Enabled = False
            Case 1 'PM
                Me.TabControl_FuncSetting.Enabled = True

                Me.ListView_Pattern.Enabled = False
                Me.ListView_Model.Enabled = False

                Me.Button_Cancel.Enabled = True
            Case 2 'ENG
                Me.TabControl_FuncSetting.Enabled = True

                Me.ListView_Pattern.Enabled = True
                Me.ListView_Model.Enabled = True

                Me.Button_Cancel.Enabled = True
            Case 3 'ALL
                Me.TabControl_FuncSetting.Enabled = True

                Me.ListView_Pattern.Enabled = True
                Me.ListView_Model.Enabled = True

                Me.Button_Cancel.Enabled = True
        End Select
    End Sub

#End Region

#Region "--- UpdateData ---"
    Private Sub UpdateData()
        Dim i As Integer

        Try
            '--- �Ĥ@�� ---
            Me.ListView_Model.Items.Clear()
            For i = 0 To Me.m_IPBootConfig.ProductList.Count - 1
                Me.ListView_Model.Items.Add(Me.m_IPBootConfig.ProductList.Item(i).Value)
            Next
            '--- �ĤG�� ---
            Me.ListView_Pattern.Items.Clear()
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ListView_Pattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next

        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- ConnectToMultiIP ---"
    Public Function ConnectToMultiIP() As Boolean
        Dim ipnwc As ClsIPNetWorkConfig
        Dim i As Integer
        Dim ErrMsg = ""

        Me.m_ConnectedIP = New ArrayList
        ipnwc = Me.m_MainProcess.IPNetworkConfig

        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then
                ip = New ClsIPInfo
                ip.CCDNo = i
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
                System.Threading.Thread.Sleep(200)

                If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                    ErrMsg = ErrMsg + "IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )" & " ; "
                    Me.m_MainProcess.IsIPConnected = False
                Else
                    Me.m_ConnectedIP.Add(ip.CCDNo)
                End If

            End If

        Next

        If ErrMsg <> "" Then
            MsgBox(ErrMsg, MsgBoxStyle.Critical, "[AreaGrabber]")
            Return False
        Else
            Me.m_MainProcess.IsIPConnected = True
            Return True
        End If

    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Cancel.Enabled = En
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Repair_PatternName ---"
    Private Sub Repair_PatternName(ByRef strPatternName As String)
        Dim strFirst As String
        Dim strSecond As String
        strFirst = Mid(strPatternName, 1, 1)
        strSecond = Mid(strPatternName, 2, 1)

        If strFirst <> "F" And strSecond <> "_" Then
            If strFirst <> "_" Then strPatternName = "_" & strPatternName
            If Mid(strPatternName, 1, 1) <> "F" Then strPatternName = "F" & strPatternName
            Exit Sub
        Else
            Exit Sub
        End If

    End Sub
#End Region

#Region "--- Load RotateCalImg ---"
    Private Sub Load_RotateCalImg()
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FileName As String = ""
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---   
            FileName = Me.m_IPBootConfig.RamDiskPath.Value & "\Img_AfterRotate.tif"
            Me.RepairPath_2(FileName)
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            image = Me.m_FuncProcess.Img_Original_NonPage

            '[AreaGrabber] Load Image --- (For Display)
            '[1] image ---
            MbufDiskInquire(FileName, M_SIZE_X, SizeX)
            MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
            MbufDiskInquire(FileName, M_TYPE, Type)
            If image <> M_NULL Then
                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(image)
                    image = M_NULL
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.m_FuncProcess.Img_Original_NonPage)

            '[2] Img_16U_Grab ---
            If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                    Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

            Me.m_Form.StatusBarStatus(Path.GetFileName(FileName))
            'If Me.m_Form.ComboBox_CCD.Text <> "" Then
            '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
            '    If Not (iCheckLoadImage > 0) Then
            '        MsgBox("���ˬd�Ҷ}�Ҫ��v���ɮ׬O�_�ŦX�ثeIP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
            '    End If
            'End If

            '----------------------------------------------------------------------------------------------
            ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_IMAGE"
                TimeOut = 100000 '100 secs

                FilePath = FileName
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Button_Enable(True)
                    Exit Sub
                End If

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    If image <> M_NULL Then
                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)

                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                            MbufFree(imageBuffer)
                            imageBuffer = M_NULL
                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufCopy(image, imageBuffer)

                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                        Me.m_Form.ResetScrollBar()
                    End If
                Else
                    Me.m_Form.CurrentIndex0 = 2
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 2
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If (Me.m_IPBootConfig.MuraUI.Value) Then
                image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image2 ---
                MbufDiskInquire(FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(FileName, M_TYPE, Type)
                If image2 <> M_NULL Then
                    If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image2)
                        image2 = M_NULL
                        image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                '[2] Img_16U_Grab ---
                If image2 <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

                If Not Response_OK Then
                    Button_Enable(True)
                    Exit Sub
                End If

                '--- Resize Original image ---
                If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 100000 '100 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) AndAlso FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                                Else
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                                End If

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            Me.m_Form.ImageUpdate()
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If
            End If


            If FileName <> "" Then
                If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("�Э��s����Align�A[Func�򥻳]�w]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                        Me.m_FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If

            End If
            Call Me.m_Form.ImageZoomAll()
            System.IO.File.Delete(FileName)
            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                TabPage_Pattern.Text = res.GetString("TabPage_Pattern.Text")
        End Select
    End Sub
#End Region

#End Region


#Region "--- Button Event ---"

#Region "--- Button_Cancel_Click ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Cancel.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
#End Region

#End Region

#Region "--- Pattern ---"

#Region "--- ListView_Pattern_AfterLabelEdit ---"
    Private Sub ListView_Pattern_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs) Handles ListView_Pattern.AfterLabelEdit
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim bool_Index As Boolean
        Dim str As String
        Dim strOld As String
        Dim PatternName As String
        Dim Path As String
        Dim Is_Same_PC As Boolean = True

        '--- Disable Button ---   
        Me.Button_Enable(False)

        If Not e.Label Is Nothing Then
            If e.Label = "" Then
                e.CancelEdit = True
                MsgBox("Pattern �W�٤��i�ť�", MsgBoxStyle.Critical, "[AreaGrabber]")
                '--- Enable Button ---  
                Me.Button_Enable(True)
                Exit Sub
            Else

                '--- �إ߳s�u ---
                If Not Me.ConnectToMultiIP Then
                    '--- Enable Button ---   
                    Me.Button_Enable(True)
                    Exit Sub
                End If
                Me.m_PatternChanged = True

                bool_Index = True
                str = e.Label.ToUpper
                For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                    If e.Item <> i Then
                        If str = Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value.ToUpper Then
                            e.CancelEdit = True
                            bool_Index = False
                            MsgBox("Pattern �W�٤��i����", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If
                    End If
                Next

                PatternName = e.Label
                Repair_PatternName(PatternName)

                If bool_Index Then

                    For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                        '--- ���o Grab No ---
                        If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                            MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If

                        '--- Change CCDNo ---
                        Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                        Me.m_FuncProcess.FuncPatternRecipeArray.Item(e.Item).PatternName.Value = PatternName
                        Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncPatternRecipe_C" & GrabNo & "_P" & e.Item + 1 & ".xml"
                        RepairPath_2(Path)
                        ClsFuncPatternRecipe.WriteXML(Me.m_FuncProcess.FuncPatternRecipeArray.Item(e.Item), Path)
                    Next

                    '--- Check Same PC ---
                    For j = 0 To Me.m_MainProcess.IPNetworkConfig.Total_IP - 2
                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(j).IP_IPAddress <> Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(j + 1).IP_IPAddress Then
                            Is_Same_PC = False
                        End If
                    Next

                    '--- Re New Label --- 
                    Me.ListView_Pattern.Items.Clear()
                    For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                        Me.ListView_Pattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
                    Next
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Item(e.Item + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value) = PatternName
                    Me.Update()

                    strOld = Me.m_FuncProcess.FuncPatternRecipeArray.Item(e.Item).PatternName.Value
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern Name Change]" & "Pattern�W�١G" & strOld & " ----> " & PatternName)

                    If Not Is_Same_PC Then
                        '[FUNC_PATTERN_EDIT]
                        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                                '--- �_�u�M�� ---
                                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                                ip = New ClsIPInfo
                                ip.CCDNo = i
                                ip.GrabNo = ""
                                Me.m_MainProcess.IPInfo.Add(ip)

                                Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                                If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                                    MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                    Me.m_MainProcess.IsIPConnected = False
                                End If

                                '----------------------------------------------------------------------------------------------
                                ' Edit Func Pattern  ==> Request_Command = "FUNC_PATTERN_EDIT" (Dispatcher 2)
                                '----------------------------------------------------------------------------------------------
                                Try
                                    '--- Prepare Command ---
                                    Request_Command = "FUNC_PATTERN_EDIT"
                                    TimeOut = 300000 '300 secs

                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, e.Item, PatternName, , , , , , , TimeOut)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                        Response_OK = True
                                    Else
                                        '--- Enable Button ---    
                                        Me.Button_Enable(True)
                                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Edit Func Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                        MessageBox.Show("[Dialog_FuncSettingBase.ListView_Pattern_AfterLabelEdit]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        Exit Sub
                                    End If

                                Catch ex As Exception
                                    '--- Enable Button ---    
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ListView_Pattern_AfterLabelEdit]Edit Func Pattern Error ! (" & ex.Message & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ListView_Pattern_AfterLabelEdit]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            End If
                        Next

                    End If

                    '--- Change CCDNo to 1 ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = 0
                End If
            End If
        End If

        '--- Enable Button ---   
        Me.Button_Enable(True)

        Me.ListView_Pattern.LabelEdit = False
    End Sub
#End Region

#Region "--- ListView_Pattern_MouseDown ---"
    Private Sub ListView_Pattern_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView_Pattern.MouseDown
        Dim lvi As ListViewItem
        If e.Button = Windows.Forms.MouseButtons.Right Then
            lvi = Me.ListView_Pattern.GetItemAt(e.X, e.Y)
            If lvi Is Nothing Then
                Me.ToolStripMenuItem_RemovePattern.Enabled = False
            Else
                Me.ToolStripMenuItem_RemovePattern.Enabled = True
            End If
        End If
    End Sub
#End Region

#Region "--- ListView_Pattern_MouseEnter ---"
    Private Sub ListView_Pattern_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Pattern.MouseEnter
        Me.ListView_Pattern.ContextMenuStrip = Me.ContextMenuStrip_Pattern
    End Sub
#End Region

#Region "--- ListView_Pattern_MouseLeave ---"
    Private Sub ListView_Pattern_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Pattern.MouseLeave
        Me.ListView_Pattern.ContextMenuStrip = Nothing
    End Sub
#End Region

#Region "--- ContextMenuStrip_Pattern_ItemClicked ---"
    Private Sub ContextMenuStrip_Pattern_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip_Pattern.ItemClicked
        Dim i As Integer
        Dim j As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim PatternIndex As Integer
        Dim MuraPatternCount As Integer
        Dim str As String
        Dim RemovePattern As String = ""
        Dim fpr As ClsFuncPatternRecipe
        Dim PatternName As String = ""
        Dim SelectPattern As Integer
        Dim PatternStrs As String()

        '--- Disable Button ---    
        Me.Button_Enable(False)

        '--- �إ߳s�u ---
        If Not Me.ConnectToMultiIP Then
            '--- Enable Button ---    
            Me.Button_Enable(True)
            Exit Sub
        End If

        If e.ClickedItem Is Me.ToolStripMenuItem_AddPattern Then

            Me.m_PatternChanged = True

            i = Me.ListView_Pattern.Items.Count + 1
            str = InputBox("�п�JPatternName", "PatternName")
            If str = "" Then Exit Sub
            Me.ListView_Pattern.Items.Add(str)


            For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                '--- ���o Grab No ---
                If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                    MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count)
                    Exit Sub
                End If

                '--- �_�u�M�� ---
                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                ip = New ClsIPInfo
                ip.CCDNo = CCDNo
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                    MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.m_MainProcess.IsIPConnected = False
                End If

                '----------------------------------------------------------------------------------------------
                'Check Pattern Count & Pattern Name  ==> Request_Command = "GET_ALL_FUNC_PATTERN" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "GET_ALL_FUNC_PATTERN"
                    TimeOut = 300000 '300 secs
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    PatternStrs = SubSystemResult.Responses(0).Param2.Split(";")
                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If CInt(SubSystemResult.Responses(0).Param1) <> Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value Then
                            MessageBox.Show("[GET_ALL_FUNC_PATTERN] Please Check CCD" & CCDNo & " , FuncModelRecipe_C" & GrabNo & ".xml PatternCount  Value Error", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count - 1)
                            'Kill IP ---    
                            Me.m_Form.Button_KillIP.PerformClick()
                            Exit Sub
                        End If
                        For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                            If PatternStrs(i) <> Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value Then
                                MessageBox.Show("[GET_ALL_FUNC_PATTERN] Please Check CCD" & CCDNo & " , FuncPatternRecipe_C" & GrabNo & "_P." & i + 1 & ".xml PatternName Value Error", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count - 1)
                                'Kill IP ---    
                                Me.m_Form.Button_KillIP.PerformClick()
                                Exit Sub
                            End If
                        Next
                    Else
                        Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "GET_ALL_FUNC_PATTERN Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSeting.GET_ALL_FUNC_PATTERN]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count - 1)
                        'Kill IP ---    
                        Me.m_Form.Button_KillIP.PerformClick()
                        Exit Sub
                    End If

                Catch ex As Exception
                    Exit Sub
                End Try
            Next

            '--- PatternName ---
            If Me.ListView_Pattern.SelectedItems.Count = 1 Then
                PatternName = Me.ListView_Pattern.SelectedItems(0).Text
                For j = 0 To Me.ListView_Pattern.Items.Count - 1
                    If Me.ListView_Pattern.SelectedItems(0).Text = Me.ListView_Pattern.Items(j).Text Then
                        SelectPattern = j
                        Exit For
                    End If
                Next
            Else
                PatternName = Me.ListView_Pattern.Items(0).Text
                SelectPattern = 0
            End If

            For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                '--- ���o Grab No ---
                If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                    MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count)
                    Exit Sub
                End If

                'Change CCDNo ---    
                Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = SelectPattern + Me.m_MuraProcess.MuraPatternRecipeArray.Count

                '----------------------------------------------------------------------------------------------
                ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SET_PATTERNINDEX"
                    TimeOut = 300000 '300 secs


                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Button_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.ListView_Pattern.Items.RemoveAt(Me.ListView_Pattern.Items.Count)
                        Exit Sub
                    End If

                    Button_Enable(True)
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value += 1
                fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
                fpr = New ClsFuncPatternRecipe(fpr)
                fpr.PatternName.Value = str
                Me.m_FuncProcess.FuncPatternRecipeArray.Add(fpr)
                Me.m_MainProcess.FuncPatternRecipeArrayTemp.Add(fpr)
                Me.m_MainProcess.FuncPatternRecipeArrayOrder.Add(fpr)
                Me.m_MainProcess.FuncProcess.FuncModelRecipe.PatternCount.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Count()
                Me.RecipeUpdate(CCDNo, GrabNo)
            Next
            Me.m_Form.ComboBox_Pattern_MainFrm.Items.Add(str)
            Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern Add]" & "�W�[�@��Pattern�APattern�W�١G" & str)

            '[FUNC_PATTERN_ADD]
            For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                    '--- �_�u�M�� ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = i
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                    If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                        MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Add Func Pattern  ==> Request_Command = "FUNC_PATTERN_ADD" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "FUNC_PATTERN_ADD"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            '--- Enable Button ---    
                            Me.Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add Func Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        '--- Enable Button ---    
                        Me.Button_Enable(True)
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]Add Func Pattern Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End If
            Next

            '--- �_�u�M�� ---
            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

            ip = New ClsIPInfo
            ip.CCDNo = 1
            ip.GrabNo = ""
            Me.m_MainProcess.IPInfo.Add(ip)

            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.m_MainProcess.IsIPConnected = False
            End If

            'Change CCDNo ---    
            Me.m_Form.ComboBox_CCD.SelectedIndex = 0

        Else
            If Me.ListView_Pattern.Items.Count = 1 Then
                MsgBox("�ܤ֫O�d�@��Pattern", MsgBoxStyle.Critical, "[AreaGrabber]")
            Else
                If MsgBox("�O�_�R��", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    Me.m_PatternChanged = True

                    i = Me.ListView_Pattern.SelectedIndices(0)
                    PatternIndex = i
                    MuraPatternCount = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value

                    If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + MuraPatternCount Then
                        If i = 0 Then
                            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + MuraPatternCount
                        Else
                            If Me.m_Form.ComboBox_Pattern_MainFrm.Items.Count - 1 = i + MuraPatternCount Then
                                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = (i - 1) + MuraPatternCount
                            Else
                                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = (i + 1) + MuraPatternCount
                            End If
                        End If
                    End If

                    Me.ListView_Pattern.Items.RemoveAt(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i + MuraPatternCount)

                    RemovePattern = Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).PatternName.Value
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern Delete]" & "�R���@��Pattern�A�W�١G" & RemovePattern)

                    For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        '--- ���o Grab No ---
                        If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                            MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If

                        '--- Change CCDNo ---   
                        Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                        Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value -= 1
                        Me.m_FuncProcess.FuncPatternRecipeArray.RemoveAt(PatternIndex)
                        Me.m_MainProcess.FuncPatternRecipeArrayTemp.RemoveAt(PatternIndex)
                        Me.m_MainProcess.FuncPatternRecipeArrayOrder.RemoveAt(PatternIndex)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.PatternCount.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Count()

                        '--- ��s���| ---
                        File.Delete(Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & PatternIndex + 1 & ".xml")
                        Me.RecipeUpdate(CCDNo, GrabNo)
                    Next

                    '[FUNC_PATTERN_DELETE]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '--- �_�u�M�� ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                                MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Delete Func Pattern  ==> Request_Command = "FUNC_PATTERN_DELETE" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "FUNC_PATTERN_DELETE"
                                TimeOut = 300000 '300 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RemovePattern, , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---    
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete Func Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---    
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]Delete Func Pattern Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next

                    '--- �_�u�M�� ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = 1
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                    If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                        MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    'Change CCDNo ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = 0

                End If
            End If
        End If

        '--- Enable Button ---    
        Me.Button_Enable(True)
    End Sub
#End Region

#Region "--- RecipeUpdate ---"
    Private Sub RecipeUpdate(ByVal CCDNo As Integer, ByVal GrabNo As String)
        Dim i As Integer
        Dim strOld_Path As String = ""
        Dim strModelPath As String = ""
        Dim strPatternPath As String = ""
        Dim fmr As ClsFuncModelRecipe

        strOld_Path = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
        strModelPath = strOld_Path & "\FuncModelRecipe_C" & GrabNo & ".xml"
        RepairPath_2(strModelPath)
        If System.IO.File.Exists(strModelPath) Then
            fmr = ClsFuncModelRecipe.ReadXML(strModelPath)
            fmr.PatternCount.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Count()
            MILOperationLib.ClsFuncModelRecipe.WriteXML(fmr, strModelPath)

            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count() - 1
                strPatternPath = strOld_Path & "\FuncPatternRecipe_C" & GrabNo & "_P" & i + 1 & ".xml"
                RepairPath_2(strPatternPath)
                ClsFuncPatternRecipe.WriteXML(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i), strPatternPath)
            Next
        End If

    End Sub
#End Region

#End Region

#Region "--- Model ---"

#Region "--- ListView_Model_AfterLabelEdit ---"
    Private Sub ListView_Model_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs) Handles ListView_Model.AfterLabelEdit
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim bool As Boolean
        Dim str As String
        Dim CurrentCCD As Integer
        Dim Is_Same_PC As Boolean = True

        Try
            If Not e.Label Is Nothing Then

                '--- Disable Button ---    
                Me.Button_Enable(False)

                If Not Me.ConnectToMultiIP Then
                    '--- Enable Button ---    
                    Me.Button_Enable(True)
                    Exit Sub
                End If

                If e.Label = "" Then
                    e.CancelEdit = True
                    MsgBox("Model �W�٤��i�ť�", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Exit Sub
                Else
                    '--- Edit Model Name ---
                    Me.m_ModelChanged = True
                    CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex


                    '--- ���o Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then

                        MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Exit Sub
                    End If

                    '--- Change CCDNo ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = 0
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("********************[ModelRecipe]**********************")
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

                    bool = True
                    str = e.Label.ToUpper
                    For i = 0 To Me.m_MainProcess.IPBootConfig.ProductList.Count - 1
                        If e.Item <> i Then
                            If str = Me.m_MainProcess.IPBootConfig.ProductList.Item(i).Value.ToUpper Then
                                e.CancelEdit = True
                                bool = False
                                MsgBox("Model �W�٤��i����", MsgBoxStyle.Critical, "[AreaGrabber]")
                            ElseIf e.Item = i Then
                                If str = Me.m_MainProcess.IPBootConfig.ProductList.Item(i).Value.ToUpper Then
                                    e.CancelEdit = True
                                    bool = False
                                    MsgBox("Model �W�٤��i���ơA�S���j�p�g����", MsgBoxStyle.Critical, "[AreaGrabber]")
                                End If
                            End If
                        End If
                    Next

                    Me.m_MainProcess.IPBootConfig.ProductList.Item(Me.ListView_Model.SelectedIndices(0)).Value = str

                    'Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Model Name Change]" & "Model�W�١G" & str & " ---> " & e.Label)
                    'Me.m_MainProcess.SaveBoot()


                    '[MODEL_EDIT]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '--- �_�u�M�� ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                                MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Edit One Model  ==> Request_Command = "MODEL_EDIT" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "MODEL_EDIT"
                                TimeOut = 300000 '300 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, e.Item, e.Label.ToUpper, , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---  
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Edit One Model Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---   
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Edit One Model Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next

                    '--- Change CCDNo to CurrentCCD ---   
                    Me.m_Form.ComboBox_CCD.SelectedIndex = 0
                End If

                '--- Enable Button ---    
                Me.Button_Enable(True)
            End If

            Me.ListView_Model.LabelEdit = False

        Catch ex As Exception
            '--- Enable Button ---   
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Edit Func Model Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- ListView_Model_MouseDown ---"

    Private Sub ListView_Model_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles ListView_Model.MouseDown
        Dim lvi As ListViewItem
        If e.Button = Windows.Forms.MouseButtons.Right Then
            lvi = Me.ListView_Model.GetItemAt(e.X, e.Y)
            If lvi Is Nothing Then
                Me.ToolStripMenuItem_RemoveModel.Enabled = False
                Me.ToolStripMenuItem_SetCurrentModel.Enabled = False
            Else
                Me.ToolStripMenuItem_RemoveModel.Enabled = True
                Me.ToolStripMenuItem_SetCurrentModel.Enabled = True
            End If
        End If
    End Sub
#End Region

#Region "--- ListView_Model_MouseEnter ---"
    Private Sub ListView_Model_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Model.MouseEnter
        Me.ListView_Model.ContextMenuStrip = Me.ContextMenuStrip_Model
    End Sub
#End Region

#Region "--- ListView_Model_MouseLeave ---"
    Private Sub ListView_Model_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Model.MouseLeave
        Me.ListView_Model.ContextMenuStrip = Nothing
    End Sub
#End Region

#Region "--- ContextMenuStrip_Model_ItemClicked ---"
    Private Sub ContextMenuStrip_Model_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip_Model.ItemClicked
        Dim i As Integer
        Dim IPNo As Integer
        Dim GrabNo As String = ""
        Dim RemoveIndex As Integer
        Dim CurrentModelIndex As Integer
        Dim CurrentModelName As String
        Dim str As String
        Dim str_Remove As String
        Dim mmr As ClsMuraModelRecipe
        Dim fmr As ClsFuncModelRecipe
        Dim mpra As ClsMuraPatternRecipeArray
        Dim fpra As ClsFuncPatternRecipeArray
        Dim mpr As ClsMuraPatternRecipe
        Dim fpr As ClsFuncPatternRecipe
        Dim BootRecipeFilename As String
        Dim ProductName As ClsString = Nothing
        Dim CurrentCCD As Integer

        '--- Disable Button ---   
        Me.Button_Enable(False)

        '--- �إ߳s�u ---
        If Not Me.ConnectToMultiIP Then
            'Enable Button ---    
            Me.Button_Enable(True)
            Exit Sub
        End If

        '[Add New Model] ---
        If e.ClickedItem Is Me.ToolStripMenuItem_AddModel Then
            Me.m_ModelChanged = True   '2011/01/13 Rick add
            CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

            i = Me.ListView_Model.Items.Count + 1
            str = InputBox("�п�JModel Name", "Model Name")
            For i = 0 To Me.ListView_Model.Items.Count - 1
                If str = Me.ListView_Model.Items(i).Text Then
                    MsgBox("Model:" & str & "�w�g�s�b,�бN�䭫�s�R�W", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Exit Sub
                End If
            Next
            Me.ListView_Model.Items.Add(str)


            '--- ���o Grab No ---
            If Not (Me.m_Form.Change_GrabNo(IPNo, GrabNo) And GrabNo <> "") Then
                MsgBox("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            End If

            '--- Change CCDNo --- 
            Me.m_Form.ComboBox_CCD.SelectedIndex = 0

            Me.m_MainProcess.RecipeDailyLogManager.WriteLog("********************[ModelRecipe]**********************")
            Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

            ProductName = New ClsString("ProductName", str, 1000)
            Me.m_MainProcess.IPBootConfig.ProductList.Add(ProductName)
            If Me.m_IPBootConfig.ProductList.Count <> Me.m_MainProcess.IPBootConfig.ProductList.Count Then
                Me.m_IPBootConfig.ProductList.Add(ProductName)
            End If

            'Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Model Add]" & "�W�[�@��Model�AModel�W�١G" & str)
            'Me.m_MainProcess.SaveBoot()



            '--- [MODEL_ADD] ---

            For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                    ''--- Change IP --- 
                    'Me.m_Form.ComboBox_CCD.SelectedIndex = i - 1

                    '--- �_�u�M�� ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = i
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                    If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                        MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Add One Model  ==> Request_Command = "MODEL_ADD" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        'Prepare Command ---
                        Request_Command = "MODEL_ADD"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            'Enable Button ---   '2010/12/18 Rick add
                            Me.Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Model Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_ADD]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        'Enable Button ---   '2010/12/18 Rick add
                        Me.Button_Enable(True)
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Model]Add One Model Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_ADD]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End If
            Next

            'Change CCDNo to Current CCD ---   
            Me.m_Form.ComboBox_CCD.SelectedIndex = CurrentCCD
        ElseIf e.ClickedItem Is Me.ToolStripMenuItem_RemoveModel Then

            '[Remove One Model] ---
            RemoveIndex = Me.ListView_Model.SelectedIndices(0)

            If Not Me.ConnectToMultiIP Then
                'Enable Button ---   
                Me.Button_Enable(True)
                Exit Sub
            End If
            Me.m_ModelChanged = True
            CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

            If Me.ListView_Model.Items.Count = 1 Then
                MsgBox("�ܤ֫O�d�@��Model", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            ElseIf Me.ListView_Model.Items(RemoveIndex).Text = Me.m_MainProcess.ProductName Then
                MsgBox("���R����Model��Current Model,�Х��N��LModel�]�w��Current Model", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            Else
                If MsgBox("�O�_�R�� Model: " & Me.m_MainProcess.IPBootConfig.ProductList.Item(RemoveIndex).Value & " ?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

                    i = Me.ListView_Model.SelectedIndices(0)
                    str_Remove = Me.m_MainProcess.IPBootConfig.ProductList.Item(RemoveIndex).Value

                    '--- ���o Grab No ---
                    IPNo = 1   'Load CCD 1's all Recipe ---
                    If Not (Me.m_Form.Change_GrabNo(IPNo, GrabNo) And GrabNo <> "") Then
                        MsgBox("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.Button_Enable(True)
                        Exit Sub
                    End If

                    Me.ListView_Model.Items.RemoveAt(RemoveIndex)
                    Me.m_MainProcess.IPBootConfig.ProductList.RemoveAt(RemoveIndex)
                    If Me.m_MainProcess.IPBootConfig.ProductList.Count <> Me.m_IPBootConfig.ProductList.Count Then
                        Me.m_IPBootConfig.ProductList.RemoveAt(RemoveIndex)
                    End If

                    If Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value > RemoveIndex Then
                        Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value -= 1
                    End If

                    'Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Model Delete]" & "�R���@��Model�A�W�١G" & str_Remove)
                    'Me.m_MainProcess.SaveBoot()

                    '[MODEL_DELETE]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '�_�u�M�� ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                            If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                                MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Delete One Model  ==> Request_Command = "MODEL_DELETE" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                'Prepare Command ---
                                Request_Command = "MODEL_DELETE"
                                TimeOut = 300000 '300 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str_Remove, , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    'Enable Button ---   '2010/12/18 Rick add
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Model Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_DELETE]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                'Enable Button ---   '2010/12/18 Rick add
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Model]Delete One Model Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next

                End If

                'Change CCDNo to Current CCD --- 
                Me.m_Form.ComboBox_CCD.SelectedIndex = CurrentCCD
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
                Me.UpdateData()
            End If
        Else

            If Not Me.ConnectToMultiIP Then
                'Enable Button ---  
                Me.Button_Enable(True)
                Exit Sub
            End If
            Me.m_ModelChanged = True
            CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

            '[Set Current Model] --- 
            CurrentModelIndex = Me.ListView_Model.SelectedIndices(0)


            '[MODEL_SETCURRENT]
            For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                    '�_�u�M�� ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = i
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)

                    If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
                        MsgBox("IP - " & i & " �s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Set Current Model  ==> Request_Command = "MODEL_SETCURRENT" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        'Prepare Command ---
                        Request_Command = "MODEL_SETCURRENT"
                        TimeOut = 300000 '300 secs

                        Response_OK = False
                        CurrentModelName = Me.m_MainProcess.IPBootConfig.ProductList.Item(CurrentModelIndex).Value
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, CurrentModelName, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            'Enable Button ---   
                            Me.Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current Model Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_SETCURRENT]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                    Catch ex As Exception
                        'Enable Button ---   
                        Me.Button_Enable(True)
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Model]Set Current Model Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_SETCURRENT]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                End If
            Next


            CurrentModelName = Me.m_MainProcess.IPBootConfig.ProductList.Item(CurrentModelIndex).Value
            If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("�ܴ����~: " & Me.m_Form.TextBox_Product.Text & " --> " & CurrentModelName)
            End If
            Me.m_Form.OutputInfo("�ܴ����~: " & Me.m_Form.TextBox_Product.Text & " --> " & CurrentModelName)
            Me.m_Form.TextBox_Product.Text = CurrentModelName

            IPNo = 1

            '���o Grab No ---
            If Not (Me.m_Form.Change_GrabNo(IPNo, GrabNo) And GrabNo <> "") Then
                MsgBox("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            End If

            'Change CCDNo ---   '2010/11/11 Rick add
            Me.m_Form.ComboBox_CCD.SelectedIndex = IPNo - 1

            If Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value <> CurrentModelIndex Then
                CurrentModelName = Me.m_MainProcess.IPBootConfig.ProductList.Item(CurrentModelIndex).Value


                'Ū��IPBootConfig ---  '2012/01/30 Rick add
                BootRecipeFilename = Me.m_MainProcess.BootRecipePath & "\IPBootConfig_IP" & IPNo & "_C" & GrabNo & ".xml"
                If System.IO.File.Exists(BootRecipeFilename) Then     ' �ˬdRecipe�����|�O�_�s�b
                    Me.m_MainProcess.IPBootConfig = MILOperationLib.ClsIPBootConfig.ReadXML(BootRecipeFilename)
                Else
                    Throw New Exception("[Read IPBootConfig] IPBootConfig Recipe ���|���s�b�I(" & BootRecipeFilename & ")")
                End If

                Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value = CurrentModelIndex
                Me.m_MainProcess.CurrentProductIndex = CurrentModelIndex


                Me.m_MainProcess.GrabNo = GrabNo
                Me.m_MainProcess.CCDNo = IPNo
                Me.m_MainProcess.CurrentProductIndex = CurrentModelIndex
                Me.m_MainProcess.ProductName = Me.m_IPBootConfig.ProductList.Item(CurrentModelIndex).Value
                Me.m_MainProcess.UpdateIPBootSetting()

                '�x�sIPBootConfig ---  '2012/01/30 Rick add
                MILOperationLib.ClsIPBootConfig.WriteXML(Me.m_MainProcess.IPBootConfig, BootRecipeFilename)

                'Mura ---
                'If Me.m_MainProcess.IPBootConfig.MuraUI.Value Then    '2010/10/12 Rick cancel,�����O�_���Ұ�MURA
                Me.m_MuraProcess.LoadAllRecipeAndFFCImages(Me.m_MainProcess.RECIPE_PATH, CurrentModelName, IPNo, GrabNo, Me.m_MainProcess.ErrorCode)
                mmr = Me.m_MuraProcess.MuraModelRecipe
                mpra = Me.m_MuraProcess.MuraPatternRecipeArray
                Me.m_MainProcess.MuraModelRecipeTemp.Copy(mmr)

                Me.m_Form.ComboBox_Pattern_MainFrm.Items.Clear()
                Me.m_MainProcess.MuraPatternRecipeArrayTemp.Clear()
                Me.m_MainProcess.MuraPatternRecipeArrayOrder.Clear()
                For i = 0 To mmr.PatternCount.Value - 1
                    mpr = mpra.Item(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Add(mpr.PatternName.Value)
                    Me.m_MainProcess.MuraPatternRecipeArrayTemp.Add(New ClsMuraPatternRecipe(mpr))
                    Me.m_MainProcess.MuraPatternRecipeArrayOrder.Add(mpr)
                Next

                '��s Mura �t��k����Pitch --------------------------- 
                '��sMura Pitch ---
                'Me.m_MuraProcess.IniFilters(mmr.PitchX.Value, mmr.PitchY.Value, Me.m_MainProcess.ErrorCode)   '09/18 Rick modify
                'End If

                'Func --- 
                'If Me.m_MainProcess.IPBootConfig.FuncUI.Value Then    '2010/10/12 Rick cancel,�����O�_���Ұ�MURA
                Me.m_MainProcess.FuncProcess.LoadFuncImageProcessRecipe(Me.m_IPBootConfig, CurrentModelName, IPNo, GrabNo, Me.m_MainProcess.ErrorCode)
                fmr = Me.m_MainProcess.FuncProcess.FuncModelRecipe
                fpra = Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray
                Me.m_MainProcess.FuncModelRecipeTemp.Copy(fmr)

                Me.m_MainProcess.FuncPatternRecipeArrayTemp.Clear()
                Me.m_MainProcess.FuncPatternRecipeArrayOrder.Clear()
                For i = 0 To fmr.PatternCount.Value - 1
                    fpr = fpra.Item(i)
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Add(fpr.PatternName.Value)
                    Me.m_MainProcess.FuncPatternRecipeArrayTemp.Add(New ClsFuncPatternRecipe(fpr))
                    Me.m_MainProcess.FuncPatternRecipeArrayOrder.Add(fpr)
                Next

                'End If

                'Measurement ---
                Me.m_MainProcess.MeasProcess.LoadAllMeasRecipe(Me.m_MainProcess.BootRecipePath, Me.m_MainProcess.RECIPE_PATH, CurrentModelName, IPNo, GrabNo, Me.m_MainProcess.ErrorCode)

                'MappingTable & MappingTableRecipe --- ---
                'If Me.m_MainProcess.IPBootConfig.Panel_TransferMode.Value = "MAPPINGTABLE" Then
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & IPNo & "\" & CurrentModelName & "\Func\MappingTable_C" & GrabNo & ".txt"
                RepairPath_2(str)
                If System.IO.File.Exists(str) Then
                    Try
                        Me.m_MainProcess.TableProcess.MappingTable.LoadTable(str)
                    Catch ex As Exception
                        Throw New Exception("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]MappingTable Load Error! (" & ex.Message & ")")
                    End Try
                    If Not Me.m_MainProcess.TableProcess.MappingTable.HaveData Then
                        Try
                            str = Me.m_MainProcess.RECIPE_PATH & "\" & CurrentModelName & "\Func\Backup\MappingTable_C" & GrabNo & ".txt"
                            RepairPath_2(str)
                            Me.m_MainProcess.TableProcess.MappingTable.LoadTable(str)
                        Catch ex As Exception
                            Throw New Exception("[Dialog_FuncSettingBase]MappingTable Load Error! (" & ex.Message & ")")
                        End Try
                        If Not Me.m_MainProcess.TableProcess.MappingTable.HaveData Then
                            MsgBox("�٨S��MappingTable�ɮסA�нT�{�G" & str, MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_Form.OutputInfo("�٨S��MappingTable�ɮסA�нT�{ !")
                        Else '�^�s
                            str = Me.m_MainProcess.RECIPE_PATH & "\" & CurrentModelName & "\Func\MappingTable_C" & GrabNo & ".txt"
                            RepairPath_2(str)
                            Me.m_MainProcess.TableProcess.MappingTable.Save(str)
                        End If
                    End If
                Else
                    'MsgBox("MappingTable�ɮפ��s�b�A�нT�{�G" & str, MsgBoxStyle.Critical, "[AreaGrabber]")
                    'Me.m_Form.OutputInfo("MappingTable�ɮפ��s�b�A�нT�{ !")
                End If

                'MappingTableRecipe ---   '2010/11/11 Rick add
                str = Me.m_MainProcess.RECIPE_PATH & "\IP" & IPNo & "\" & CurrentModelName & "\Func\MappingTableRecipe_C" & GrabNo & ".txt"
                RepairPath_2(str)
                If System.IO.File.Exists(str) Then
                    Try
                        ClsMappingTableRecipe.ReadXML(str)
                    Catch ex As Exception
                        Throw New Exception("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]MappingTable Load Error! (" & ex.Message & ")")
                    End Try
                Else
                    'MsgBox("MappingTableRecipe �ɮפ��s�b�A�нT�{�G" & str, MsgBoxStyle.Critical, "[AreaGrabber]")
                    'Me.m_Form.OutputInfo("MappingTableRecipe �ɮפ��s�b�A�нT�{ !")
                End If

                Me.Text = "Model�Ѽƽվ� [ " & Me.m_Form.TextBox_Product.Text & " ]"
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Current Model Set]" & "�]�w�ثeModel�A�W�١G" & Me.m_Form.TextBox_Product.Text)
                Me.m_MainProcess.SaveBoot()
            End If



            'Change CCDNo to Current CCD ---    
            Me.m_Form.ComboBox_CCD.SelectedIndex = -1
            Me.m_Form.ComboBox_CCD.SelectedIndex = 0
            Me.m_Form.SetPatternIndex(1)
            Me.UpdateData()
        End If



        'Enable Button ---  
        Me.Button_Enable(True)

    End Sub
#End Region

#End Region

End Class

