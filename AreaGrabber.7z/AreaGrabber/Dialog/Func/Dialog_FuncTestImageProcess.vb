Imports System.Windows.Forms
Imports System.IO
Imports System.Text
Imports ClassLibrary
Imports MILOperationLib
Imports AUO.SubSystemControl
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.Threading
Imports System.Globalization

<CLSCompliant(False)> _
Public Class Dialog_FuncTestImageProcess
    Inherits System.Windows.Forms.Form

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_CharacteristicRecipe As ClsCharacteristicRecipe

    '--- ø�� ---
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_Size As Integer

    Private m_BitMap_2 As Bitmap
    Private m_GraphicsImage_2 As Graphics

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '--- Temp ---
    Private m_CharacterRicepeFile As String = ""
    Private m_Total_Defect_Count As Integer

    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar

    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button

    '--- Multi-Pixel ---
    Private MultiPixelRegion_Boundary As New ClsParameterBoundary

    '---WriteLog---
    Dim m_sw As StreamWriter

    '---Save Img For AI---
    Private m_SaveImgForAI_Path As String
    Private m_DefectFileName() As String
    Private m_DefectFilePath() As String
    Private res As System.Resources.ResourceManager '

    Public WriteOnly Property PanelID As String
        Set(ByVal Value As String)
            Me.TextBox_PanelID.Text = Value
        End Set
    End Property

#Region "--- ��k�禡 ---"

#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_FuncTestImageProcess", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------
        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_FuncProcess = form.MainProcess.FuncProcess
        Me.m_MuraProcess = form.MainProcess.MuraProcess

        'If Not Me.m_MainProcess.CheckIP() Then
        '    Me.m_MainProcess.IsIPConnected = False
        '    'MessageBox.Show("Can't connect to IP-" & Me.m_MainProcess.CCDNo & "�APLZ restart IP !", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '    Exit Sub
        'Else
        '    Me.m_MainProcess.IsIPConnected = True
        'End If

        Me.m_IPBootConfig = form.MainProcess.IPBootConfig
        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_Pen = New Pen(Color.White)
        Me.m_SolidBrush = New SolidBrush(Color.White)
        Me.m_Size = 15
        Me.m_Form.PaintStop = True  '2012/11/05 Rick add

        Me.m_BitMap_2 = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage_2 = Graphics.FromImage(Me.m_BitMap_2)

        '--- Display Image ---
        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
        Else
            image = Me.m_FuncProcess.Img_Original_NonPage
        End If

        If image <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        '--- UI ---
        Me.m_VScrollBar = Me.m_Form.VScrollBar
        Me.m_HScrollBar = Me.m_Form.HScrollBar

        Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
        Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
        Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
        Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
        Me.TextBox_PanelID.Text = Me.m_Form.PanelID
        '---- UI ---

        '--- ���Func�Ĥ@��Patter ---
        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
        End If
        Me.m_Form.ImageUpdate()

        '--- �v������ ---
        Me.UpdateUserLevel()

        '---CharacteristicUse---
        If Not Me.m_IPBootConfig.DetailOutput.Value Then
            Me.GroupBox_CharacteristicAnalysis.Enabled = False
        End If

    End Sub
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Me.Button_LoadImage.Enabled = En
        Me.Button_Execute.Enabled = En
        Me.Cancel_Button.Enabled = En
        Me.ComboBox_Pattern.Enabled = En
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ImgTest.Enabled = True
            Case 1 'PM
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ImgTest.Enabled = True
            Case 2 'ENG
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ImgTest.Enabled = True
            Case 3 'ALL
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ImgTest.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- ClearResult ---"
    Private Sub ClearResult()
        Label_Defects_X.Text = "Offset X�G"
        Label_Defects_Y.Text = "Offset Y�G"
        Label_Defects_Count.Text = "Count�G"
        ListView_Defects.Items.Clear()
        Me.Update()
    End Sub
#End Region

#Region "--- CheckPattern ---"
    Private Sub CheckPattern()
        Try
            '--- Pattern �ˬd ---- 
            If Me.m_Form.GetPatternNameInfo <> Me.ComboBox_Pattern.Text Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If
        Catch ex As Exception
            Throw New Exception("[Dialog_FuncTestImageProcess.CheckPattern]Check Pattern Error ! (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- Darw Event ---"

#Region "--- m_AxMDisplay_PaintEvent ---"
    Private Sub m_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark()
        End If
    End Sub
#End Region

#Region "--- DrawMark ---"
    Private Sub DrawMark()
        If Me.ListView_Defects.SelectedIndices.Count < 1 Or Me.ListView_Defects Is Nothing Then Exit Sub
        Dim image As MIL_ID = M_NULL
        Dim offX As Integer
        Dim offY As Integer
        Dim i As Integer
        Dim lvi_blobx As Integer
        Dim lvi_bloby As Integer

        Dim picsize As Integer
        Dim offset_X, offset_Y As Integer
        Dim DisplayWidth As Integer = Me.m_Form.Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.m_Form.Panel_AxMDisplay.Size.Height
        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim ZoomX As Double
        Dim CenterHScroll As Double
        Dim OffsetHScroll As Double
        Dim CenterVScroll As Double
        Dim OffsetVScroll As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If

        Me.m_Form.PaintStop = True

        '--- Initial ---
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        '--- Initial ---

        If Me.ListView_Defects.SelectedIndices.Count > 0 Then
            For i = 0 To Me.ListView_Defects.SelectedItems.Count - 1
                If Not Me.ListView_Defects.SelectedItems.Item(i) Is Nothing Then
                    lvi_blobx = CInt(Me.ListView_Defects.SelectedItems.Item(i).SubItems(1).Text)
                    lvi_bloby = CInt(Me.ListView_Defects.SelectedItems.Item(i).SubItems(2).Text)
                Else
                    Exit Sub
                End If
            Next

            picsize = Math.Max(CInt(((50) ^ 0.5) * 2), 100)

            Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                Case 0
                    If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        offset_X = Math.Max(CInt(lvi_blobx) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(lvi_bloby) - CInt(picsize / 2), 0)
                    End If
                Case 1
                    offset_X = Math.Max(CInt(lvi_blobx - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - CInt(picsize / 2), 0)
                    offset_Y = Math.Max(CInt(lvi_bloby - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - CInt(picsize / 2), 0)
            End Select

            image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

            CenterHScroll = ((offset_X + CInt(picsize / 2)) * Me.m_Form.HScrollBar.Maximum) / (SizeX - DisplayWidth / ZoomX)
            OffsetHScroll = ((DisplayWidth / ZoomX) / 2) * (Me.m_Form.HScrollBar.Maximum / (SizeX - DisplayWidth / ZoomX))
            CenterVScroll = ((offset_Y + CInt(picsize / 2)) * Me.m_Form.VScrollBar.Maximum) / (SizeY - DisplayHeight / ZoomX)
            OffsetVScroll = ((DisplayHeight / ZoomX) / 2) * (Me.m_Form.VScrollBar.Maximum / (SizeY - DisplayHeight / ZoomX))

            CenterHScroll = CenterHScroll - OffsetHScroll
            CenterVScroll = CenterVScroll - OffsetVScroll

            If CenterHScroll < 0 Then
                If Me.ComboBox_ImageProcess.Text = "Point" Then
                    Me.m_Form.HScrollBar.Value = 0
                End If
            ElseIf CenterHScroll > Me.m_Form.HScrollBar.Maximum Then
                Me.m_Form.HScrollBar.Value = Me.m_Form.HScrollBar.Maximum
            Else
                If CenterHScroll > 0 Then Me.m_Form.HScrollBar.Value = CenterHScroll
            End If

            If CenterVScroll < 0 Then
                If Me.ComboBox_ImageProcess.Text = "Point" Then
                    Me.m_Form.VScrollBar.Value = 0
                End If
            ElseIf CenterVScroll > Me.m_Form.VScrollBar.Maximum Then
                Me.m_Form.VScrollBar.Value = Me.m_Form.VScrollBar.Maximum
            Else
                If CenterVScroll > 0 Then Me.m_Form.VScrollBar.Value = CenterVScroll
            End If

            If CenterHScroll < 0 AndAlso CenterVScroll < 0 Then
                Me.m_Form.HScrollBar.Value = 0
                Me.m_Form.VScrollBar.Value = 0
            End If

        End If

        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then

                    '--- Draw Point\Line Defect ---
                    If Me.ListView_Defects.SelectedIndices.Count > 0 Then
                        If ((Me.ComboBox_ImageProcess.Text = "Point") Or (Me.ComboBox_ImageProcess.Text = "GSBP_BLDP")) Then
                            Me.DrawBlobDefect(0, 0)
                        ElseIf Me.ComboBox_ImageProcess.Text = "Line" Then
                            If lvi_blobx = -1 And lvi_bloby <> 0 Then
                                Me.DrawHBandDefect(0, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX)
                            End If
                            If lvi_blobx <> 0 And lvi_bloby = -1 Then
                                Me.DrawVBandDefect(0, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY)
                            End If
                        End If
                    End If

                End If
            Case 1
                '--- Draw Point\Line Defect ---
                If Me.ListView_Defects.SelectedIndices.Count > 0 Then
                    If ((Me.ComboBox_ImageProcess.Text = "Point") Or (Me.ComboBox_ImageProcess.Text = "GSBP_BLDP")) Then
                        Me.DrawBlobDefect(-offX, -offY)
                    ElseIf Me.ComboBox_ImageProcess.Text = "Line" Then
                        If lvi_blobx = -1 And lvi_bloby <> 0 Then
                            Me.DrawHBandDefect(-offY, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX)
                        End If
                        If lvi_blobx <> 0 And lvi_bloby = -1 Then
                            Me.DrawVBandDefect(-offX, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY)
                        End If
                    End If
                End If

        End Select
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        'Me.m_Form.PaintStop = False
    End Sub
#End Region

#Region "--- DrawBlobDefect ---"
    Private Sub DrawBlobDefect(ByVal offX As Integer, ByVal offY As Integer)
        If Me.ListView_Defects.Items.Count < 1 Or Me.ListView_Defects Is Nothing Then Exit Sub
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem
        bx = MdispInquire(Me.m_AxMDisplay, M_SIZE_X, M_NULL)
        by = MdispInquire(Me.m_AxMDisplay, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, M_ZOOM_X, M_NULL)
        MIL.MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)  'v2012.09.04
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red
        For i = 0 To Me.ListView_Defects.SelectedItems.Count - 1
            If Not Me.ListView_Defects.SelectedItems.Item(i) Is Nothing Then
                lvi = Me.ListView_Defects.SelectedItems.Item(i)
                x = lvi.SubItems(1).Text
                y = lvi.SubItems(2).Text
                x = (x - ox + 0.5) * s - hr   ' -hr , �]���q 0�׶}�l�e��
                y = (y - oy + 0.5) * s - hr
                If x < bx And y < by Then
                    Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
                End If
            End If
        Next
    End Sub
#End Region

#Region "--- DrawBlobDefect ---"
    Private Sub DrawAllBlobDefect(ByVal offX As Integer, ByVal offY As Integer)
        If Me.m_Total_Defect_Count < 1 Or Me.ListView_Defects.Items.Count = 0 Then Exit Sub
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem

        bx = MdispInquire(Me.m_AxMDisplay, M_SIZE_X, M_NULL)
        by = MdispInquire(Me.m_AxMDisplay, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY

        MIL.MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)  'v2012.09.04
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red

        For i = 0 To Me.m_Total_Defect_Count - 1
            If Not Me.ListView_Defects.Items.Item(i) Is Nothing Then
                lvi = Me.ListView_Defects.Items.Item(i)
                x = lvi.SubItems(1).Text
                y = lvi.SubItems(2).Text
                x = (x - ox + 0.5) * s - hr   ' -hr , �]���q 0�׶}�l�e��
                y = (y - oy + 0.5) * s - hr
                If x < bx And y < by Then
                    Me.m_GraphicsImage_2.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
                End If
            End If
        Next
    End Sub
#End Region

#Region "--- DrawHBandDefect ---"
    Private Sub DrawHBandDefect(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim i As Integer
        Dim h As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim size As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem
        rect = New Rectangle
        Me.m_Pen.Color = Color.Red
        ox = Me.m_Form.HScrollBar.Value - s
        oy = Me.m_Form.VScrollBar.Value - offset
        'size = MdispInquire(Me.m_AxMDisplay, M_ZOOM_X, M_NULL)
        MIL.MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, size)  'v2012.09.04
        Me.m_SolidBrush.Color = Color.Red
        For i = 0 To Me.ListView_Defects.SelectedItems.Count - 1
            If Not Me.ListView_Defects.SelectedItems.Item(i) Is Nothing Then
                lvi = Me.ListView_Defects.SelectedItems.Item(i)
                h = (-ox + 0.5) * size
                rect.X = h
                h = (lvi.SubItems(2).Text - oy) * size
                rect.Y = h
                rect.Width = (e - s + 1) * size
                rect.Height = Math.Ceiling(size)
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        Next
    End Sub
#End Region

#Region "--- DrawVBandDefect ---"
    Private Sub DrawVBandDefect(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim i As Integer
        Dim v As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim size As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem
        rect = New Rectangle
        Me.m_Pen.Color = Color.Green
        ox = Me.m_Form.HScrollBar.Value - offset
        oy = Me.m_Form.VScrollBar.Value - s
        'size = MbufInquire(Me.m_AxMDisplay, M_ZOOM_X, M_NULL)
        MIL.MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, size)  'v2012.09.04
        Me.m_SolidBrush.Color = Color.Red
        For i = 0 To Me.ListView_Defects.SelectedItems.Count - 1
            If Not Me.ListView_Defects.SelectedItems.Item(i) Is Nothing Then
                lvi = Me.ListView_Defects.SelectedItems.Item(i)
                v = (lvi.SubItems(1).Text - ox) * size
                rect.X = v
                v = (-oy + 0.5) * size
                rect.Y = v
                'rect.Width = Math.Ceiling((lvi.SubItems(5).Text - lvi.SubItems(3).Text + 1) * size)
                rect.Width = Math.Ceiling(size)
                rect.Height = (e - s + 1) * size
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
        Next
    End Sub
#End Region

#Region "--- DrawAll_PointDefects ---"
    Private Sub DrawAll_PointDefects()
        If Me.m_Total_Defect_Count < 1 And Not (Me.ComboBox_ImageProcess.Text = "Point" Or Me.ComboBox_ImageProcess.Text = "GSBP_BLDP") Then Exit Sub
        Dim image As MIL_ID = M_NULL
        Dim offX As Integer
        Dim offY As Integer

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If

        Me.m_GraphicsImage_2.Clear(Color.Transparent)

        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

        Select Case Me.m_Form.ComboBox_Type.SelectedIndex

            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    Me.DrawAllBlobDefect(0, 0)
                End If
            Case 1
                Me.DrawAllBlobDefect(-offX, -offY)

        End Select

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap_2, New PointF(0, 0))
    End Sub
#End Region

#Region "--- DrawGoTo_Blob ---"
    Private Sub DrawGoTo_Blob(ByVal BlobX As Integer, ByVal BlobY As Integer)

        Dim image As MIL_ID = M_NULL
        Dim offX As Integer
        Dim offY As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim s As Double
        Dim x As Integer
        Dim y As Integer
        Dim r As Integer
        Dim hr As Integer

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        MIL.MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        Me.m_Form.PaintStop = True

        '--- Initial ---
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        '--- Initial ---

        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    ox = Me.m_Form.HScrollBar.Value
                    oy = Me.m_Form.VScrollBar.Value
                End If
            Case 1
                ox = Me.m_Form.HScrollBar.Value + offX
                oy = Me.m_Form.VScrollBar.Value + offY
        End Select

        '--- Draw Image ---
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red

        If BlobX > 0 And BlobY > 0 Then
            x = BlobX
            y = BlobY
            x = (x - ox + 0.5) * s - hr   ' -hr , �]���q 0�׶}�l�e��
            y = (y - oy + 0.5) * s - hr
            If x < MdispInquire(Me.m_AxMDisplay, M_SIZE_X, M_NULL) And y < MdispInquire(Me.m_AxMDisplay, M_SIZE_Y, M_NULL) Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        End If

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
    End Sub

#End Region

#End Region

#Region "--- ReAllocate_FuncImage ---"
    Private Sub ReAllocate_FuncImage(ByVal imgSizeX As Integer, ByVal imgSizeY As Integer)
        '--- ��ܥ\�� ---

        If Me.m_MainProcess.Img_FixRecipe_NonPage <> M_NULL Then
            MbufFree(Me.m_MainProcess.Img_FixRecipe_NonPage)
            Me.m_MainProcess.Img_FixRecipe_NonPage = M_NULL
        End If

        Try
            Me.m_MainProcess.Img_FixRecipe_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, imgSizeX, imgSizeY, 16 + M_UNSIGNED, M_IMAGE + M_DISP + M_NON_PAGED, M_NULL)
            If Me.m_MainProcess.Img_FixRecipe_NonPage = M_NULL Then
                Throw New Exception("Failed to allocate mil Img_FixRecipe_NonPage !")
            End If
        Catch ex As Exception
            Throw New Exception("[ReAllocate_FuncImage] Create FixRecipe Image Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub

#End Region

#Region "--- UpdateData ---"

    Private Sub UpdateData()
        Me.NumericUpDown_GrayMin_Min.Value = Me.m_CharacteristicRecipe.GrayMin_Min.Value
        Me.NumericUpDown_GrayMin_Max.Value = Me.m_CharacteristicRecipe.GrayMin_Max.Value
        Me.NumericUpDown_GrayMax_Min.Value = Me.m_CharacteristicRecipe.GrayMax_Min.Value
        Me.NumericUpDown_GrayMax_Max.Value = Me.m_CharacteristicRecipe.GrayMax_Max.Value
        Me.NumericUpDown_Elongation_Min.Value = Me.m_CharacteristicRecipe.Elongation_Min.Value
        Me.NumericUpDown_Elongation_Max.Value = Me.m_CharacteristicRecipe.Elongation_Max.Value
        Me.NumericUpDown_Fullness_Min.Value = Me.m_CharacteristicRecipe.Fullness_Min.Value
        Me.NumericUpDown_Fullness_Max.Value = Me.m_CharacteristicRecipe.Fullness_Max.Value
        Me.NumericUpDown_Compactness_Max.Value = Me.m_CharacteristicRecipe.Compactness_Max.Value
    End Sub

#End Region

#Region "--- CheckCharacteristicFile ---"

    Private Sub CheckCharacteristicFile()
        If Directory.Exists(Me.m_IPBootConfig.CharacteristicPath.Value) Then
            Me.m_CharacterRicepeFile = Me.m_IPBootConfig.CharacteristicPath.Value & "\" & Me.m_Form.GetProductNameInfo & "_P" & Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value & ".xml"
        Else
            If Not Directory.Exists(Me.m_IPBootConfig.DataRootPath.Value & "\Temp") Then
                Directory.CreateDirectory(Me.m_IPBootConfig.DataRootPath.Value & "\Temp")
            End If
            Me.m_CharacterRicepeFile = Me.m_IPBootConfig.DataRootPath.Value & "\Temp\" & Me.m_Form.GetProductNameInfo & "_P" & Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value & ".xml"
        End If

        If File.Exists(Me.m_CharacterRicepeFile) Then
            Me.m_CharacteristicRecipe = ClsCharacteristicRecipe.ReadXML(Me.m_CharacterRicepeFile)
        Else
            Me.m_CharacteristicRecipe = New ClsCharacteristicRecipe
        End If
    End Sub

#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_Execute.Text = res.GetString("Button_Execute.Text")
                Button_LoadImage.Text = res.GetString("Button_LoadImage.Text")
                Cancel_Button.Text = res.GetString("Cancel_Button.Text")
                CheckBox_DrawDefect.Text = res.GetString("CheckBox_DrawDefect.Text")
                CheckBox_ShowAllDefects.Text = res.GetString("CheckBox_ShowAllDefects.Text")
                GroupBox_CharacteristicAnalysis.Text = res.GetString("GroupBox_CharacteristicAnalysis.Text")
                GroupBox_ImageSource.Text = res.GetString("GroupBox_ImageSource.Text")
                GroupBox_ImgTest.Text = res.GetString("GroupBox_ImgTest.Text")
        End Select
    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_LoadImage ---"
    Private Sub Button_LoadImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LoadImage.Click
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FilePath As String = ""
        Dim FileName As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                FilePath = GetUNCPath(Me.m_Form.OpenFileDialog.FileName)
                FileName = System.IO.Path.GetFileNameWithoutExtension(FilePath)
                If FileName.Split("_")(0) <> "" Then
                    Me.m_Form.PanelID = FileName.Split("_")(0)
                    Me.TextBox_PanelID.Text = Me.m_Form.PanelID
                Else
                    Me.m_Form.PanelID = "AAAAAAAA"
                    Me.TextBox_PanelID.Text = Me.m_Form.PanelID
                End If
                If FilePath.Contains("_FFunc") Or FilePath.Contains("_FMura") Then
                    If System.IO.Path.GetFileNameWithoutExtension(FilePath).Split("_")(2) <> Me.m_MainProcess.CCDNo Then
                        If MsgBox("���J�v���D�ҿ��CCD,�O�_�j����J?", vbOKCancel, "�нT�{") = MsgBoxResult.Cancel Then
                            Button_Enable(True)
                            Exit Sub
                        End If
                    End If
                End If

                image = Me.m_FuncProcess.Img_Original_NonPage
                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(FilePath, M_SIZE_X, SizeX)
                MbufDiskInquire(FilePath, M_SIZE_Y, SizeY)
                MbufDiskInquire(FilePath, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FilePath, Me.m_FuncProcess.Img_Original_NonPage)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FilePath, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(System.IO.Path.GetFileName(FilePath))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("���ˬd�Ҷ}�Ҫ��v���ɮ׬O�_�ŦX�ثeIP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 100000 '100 secs
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        If SubSystemResult.Responses(0).Param1 = "1" Then
                            Me.m_Form.CheckBox_IsAligned.Checked = True
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                            strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                            RepairPath_2(strPath)
                            MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                        Else
                            Me.m_Form.CheckBox_IsAligned.Checked = False
                        End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        Button_Enable(True)
                        Exit Sub
                    End If

                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        If image <> M_NULL Then
                            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                            Type = MbufInquire(image, M_TYPE, M_NULL)

                            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                MbufFree(imageBuffer)
                                imageBuffer = M_NULL
                                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                            MbufCopy(image, imageBuffer)

                            MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                            MbufControl(image, M_MODIFIED, M_DEFAULT)
                            MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                            Me.m_Form.ResetScrollBar()
                        End If
                    Else
                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                If (Me.m_IPBootConfig.MuraUI.Value) Then

                    '----------------------------------------------------------------------------------------------
                    ' Transfer Mura Boundary  ==> Request_Command = "Transfer_Mura_Boundary" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "Transfer_Mura_Boundary"
                        TimeOut = 10000 '10 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                    '[1] image2 ---
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                    If image2 <> M_NULL Then
                        If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image2)
                            image2 = M_NULL
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                    If Not Me.m_IPBootConfig.FuncUI.Value Then
                        '[2] Img_16U_Grab ---
                        If image2 <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                                Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                                Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)
                    End If

                    If Not Response_OK Then
                        Button_Enable(True)
                        Exit Sub
                    End If
                End If
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        'MessageBox.Show("�Э��s����Align�A[Func�򥻳]�w]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                    End Try
                Else
                    If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                        Me.m_FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If

            End If
            Call Me.m_Form.ImageZoomAll()


            For i = 0 To Me.ComboBox_Pattern.Items.Count - 1
                If Me.m_Form.OpenFileDialog.FileName.Contains(Me.ComboBox_Pattern.Items(i)) Then
                    Me.ComboBox_Pattern.SelectedIndex = i
                    Exit For
                End If
            Next

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_FuncTestImageProcess.Button_LoadImage]" & ex.Message & "(" & ex.StackTrace & ")")
            'MessageBox.Show("[Dialog_FuncTestImageProcess.Button_LoadImage]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Execute ---"
    Private Sub Button_Execute_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Execute.Click
        Dim i As Integer
        Dim j As Integer
        Dim p As Position
        Dim strType As String
        Dim Algorithms As String
        Dim timer1, timer2 As Double
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim strs2() As String
        Dim Defect_Count As Integer
        Dim GrabNo As String = ""
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim PatternName As String
        Dim fpr As ClsFuncPatternRecipe
        Dim BPDP_Enable As Boolean = False
        Dim Func_Boundary As ClsParameterBoundary
        Dim SizeX, SizeY As Integer
        Dim LaserPointInfo As String

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Me.CheckPattern()
            Me.ClearResult()

            Me.m_FuncProcess.DefectArray.Clear()
            Me.m_FuncProcess.Func_DefectArray.Clear()

            If Me.m_MainProcess.PanelInputTime Is Nothing Or Me.m_MainProcess.PanelInputTime = "" Then
                Me.m_MainProcess.PanelInputTime = Format(Now, "yyyyMMdd HHmmss")
            End If

            If Me.ComboBox_ImageProcess.SelectedIndex <> -1 Then

                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count

                '----------------------------------------------------------------------------------------------
                ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SET_PATTERNINDEX"
                    TimeOut = 100000 '100 secs

                    '--- PatternName ---
                    PatternName = Me.ComboBox_Pattern.Text

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncTestImageProcess.Button_Execute_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncTestImageProcess.Button_Execute_Click]Set Pattern Index Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncTestImageProcess.Button_Execute_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try

                '----------------------------------------------------------------------------------------------
                ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "DIALOG_FUNCSETTING_SETTING"
                    TimeOut = 100000 '100 secs

                    '--- UI Recipe Setting -----------------------------------

                    '--- Other ---
                    If Me.ComboBox_Pattern.Text <> "" Then
                        Parameter_Lists = Parameter_Lists & "PatternName," & Me.ComboBox_Pattern.Text & ";"
                    End If
                    fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
                    If (fpr.AnalysisBP.Value AndAlso fpr.AnalysisDP.Value) Then
                        BPDP_Enable = True
                    End If

                    '--- �Ĥ@�� ---
                    Parameter_Lists = "BPDP," & BPDP_Enable & ";" & "BP," & fpr.AnalysisBP.Value & ";" & "DP," & fpr.AnalysisDP.Value

                    '--- End UI Recipe Setting -----------------------------------

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        ''MessageBox.Show("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                If Me.m_FuncProcess.CurrentFuncPatternRecipe.AlignEnable.Value And Me.m_Form.CheckBox_IsAligned.Checked = False Then

                    '----------------------------------------------------------------------------------------------------------------------
                    'Calculate Func Original Boundary (Func's ROI)  ==> Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY"
                        TimeOut = 100000 '100 secs

                        Parameter_Lists = "0"      '2010/07/26 grant add mappingtable find 3CCD mark (Not Make MappingTable, emblem=>false)
                        Parameter_Lists1 = "Defect"   '2010/07/28 grant add mappingtable to distinguish "Standard_Theta" or "Defect_Theta"
                        Func_Boundary = Me.m_FuncProcess.FuncModelRecipe.Boundary   '2011/03/03 Rick add

                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Parameter_Lists, Parameter_Lists1, , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK, Align_OK = " & SubSystemResult.Responses(0).Param3 & ", " & SubSystemResult.Responses(0).Param4)
                            '--- �ѪR ROI Boundary ----
                            OutputString = SubSystemResult.Responses(0).Param2
                            strs1 = OutputString.Split(";")

                            If (CInt(strs1(0)) = 0 And CInt(strs1(1)) = 0 And CInt(strs1(2)) = 0 And CInt(strs1(3)) = 0) Then
                                Me.m_FuncProcess.FuncModelRecipe.Boundary = Func_Boundary
                            Else
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(strs1(0))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(strs1(1))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(strs1(2))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(strs1(3))
                                Me.m_MainProcess.DOffsetX = CInt(strs1(4))
                                Me.m_MainProcess.DOffsetY = CInt(strs1(5))
                                Me.m_MainProcess.DTheta = (strs1(6))
                                Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointX.Value = CInt(strs1(4))
                                Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointY.Value = CInt(strs1(5))
                            End If

                            '--- Status Message ---
                            OutputString = SubSystemResult.Responses(0).Param4
                            If OutputString <> "" Then Me.m_Form.OutputInfo(OutputString)
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Func Original Boundary (Func's ROI) Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            'MessageBox.Show("[Dialog_FuncTestImageProcess.Button_Execute_Click]" & "Calculate Func Original Boundary (Func's ROI) Fail ! ( " & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    '--- Calculate ROI Image ---
                    Try
                        If Me.m_Form.OpenFileDialog.FileName <> "" Then
                            If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                                Try
                                    If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                                Catch ex As Exception
                                    'MessageBox.Show("�Э��s����Align�A[Func�򥻳]�w]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            Else
                                If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                                    MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                                    Me.m_FuncProcess.Img_OriginalROI = M_NULL
                                End If

                                SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                                Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                            End If
                        End If
                    Catch ex As Exception
                        Me.m_Form.OutputInfo("[Func Test] Align �o�Ϳ��~ => " & ex.Message)
                    End Try

                End If

                '----------------------------------------------------------------------------------------------
                ' IP DOALGORITHM  ==> Request_Command = "FUNC_INSPECTION"  (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    TimeOut = 5000000 '5000 secs
                    Request_Command = "FUNC_INSPECTION"

                    timer1 = System.Environment.TickCount
                    Algorithms = Me.ComboBox_ImageProcess.Text
                    LaserPointInfo = TextBox_LaserInfo1.Text & "@" & TextBox_LaserInfo2.text
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Algorithms, String.Format("{0}@{1}", Me.CheckBox_CreateFilterImage.Checked, Me.CheckBox_FilterByImageFilter.Checked), Me.CheckBox_FilterHotPixel.Checked, Me.CheckBox_FilterFalseDefect.Checked, Me.CheckBox_EnableFalseRule.Checked, Not Me.CheckBox_Filter_By_Characteristics.Checked, Me.CheckBox_SaveDefectImage.Checked, LaserPointInfo, TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    timer2 = System.Environment.TickCount
                    'MsgBox("�ˬd���G�G�@�p " & Me.m_FuncProcess.DefectArray.Count & " ��Defects�C")
                    Me.m_Form.OutputInfo(ComboBox_ImageProcess.Text & "�v���B�z�@��O�G " & timer2 - timer1 & " ms")

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Func Inspection Fail !( " & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        'MessageBox.Show("[Dialog_FuncTestImageProcess.Button_Execute_Click]" & "IP Func Inspection Fail !( " & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                If Response_OK Then
                    Try
                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2

                        '--- �ѪR Defect ----
                        OutputString = SubSystemResult.Responses(0).Param2
                        strs1 = OutputString.Split(";")
                        If strs1.Length < 4 Then
                            Button_Enable(True)
                            Exit Sub
                        End If

                        Defect_Count = CInt(strs1(4))


                        If (Defect_Count > 0) Then

                            If CInt(strs1(4)) > CInt(strs1(5)) Then Defect_Count = CInt(strs1(5)) Else Defect_Count = CInt(strs1(4))
                            If strs1(strs1.Length - 1) = "" Then
                                If Defect_Count + 4 <> strs1.Length - 1 Then Defect_Count = strs1.Length - 1 - 6
                            Else
                                If Defect_Count + 4 <> strs1.Length Then Defect_Count = strs1.Length - 6
                            End If

                            ReDim Me.m_DefectFileName(Defect_Count - 1)
                            ReDim Me.m_DefectFilePath(Defect_Count - 1)

                            If Me.m_FuncProcess.Func_DefectArray.Count > 0 Then Me.m_FuncProcess.Func_DefectArray.Clear()
                            GrabNo = Me.m_IPBootConfig.GrabNo.Value
                            For i = 6 To 6 + Defect_Count - 1
                                '(1)m_BlobX, (2)m_BlobY, (3)m_BlobArea, (4)m_Data, (5)m_Gate, (6)m_Type, (7)m_Pattern, (8)m_GrayMean, (9)FileName (10)NetDiskPath (11)MinGray (12)MaxGray (13)Elongation (14)Fullness (15)MaxGray_Fullness(16)Standard_Deviation			
                                strs2 = strs1(i).Split(",") '(1)m_BlobX, (2)m_BlobY, (3)m_BlobArea, (4)m_Data, (5)m_Gate, (6)m_Type, (7)m_Pattern, (8)m_GrayMean, (9)FileName, (10)NetDiskPath, (11)GrayMin, (12)GrayMax, (13)Elongation, (14)Fullness, (15)Compactness, (16)MinFeretAngle, (17)MaxGray_Fullness, (18)StdDev, (19)DataMin, (20)GateMin, (21)DataMax, (22)GateMax, (23)Fatness  

                                If m_IPBootConfig.DetailOutput.Value Then
                                    p = New Position(strs2(1), strs2(2), strs2(3), strs2(4), strs2(5), strs2(6), strs2(7), GrabNo, strs2(8), strs2(9), strs2(10), strs2(11), strs2(12), strs2(13), strs2(14), strs2(15), strs2(16), strs2(17), strs2(18), strs2(23))
                                Else
                                    p = New Position(strs2(1), strs2(2), strs2(3), strs2(4), strs2(5), strs2(6), strs2(7), GrabNo, strs2(8), strs2(9), strs2(10), strs2(11), strs2(12), strs2(13), strs2(14), 0, 0, strs2(15), strs2(16), 0)
                                End If
                                Me.m_DefectFileName(i - 6) = p.FileName
                                Me.m_DefectFilePath(i - 6) = p.NetDiskPath
                                Me.m_FuncProcess.Func_DefectArray.Add(p)
                            Next
                        End If

                        '--- ��ܵ��G ---
                        Label_Defects_X.Text = "Offset X�G" & Me.m_MainProcess.DOffsetX
                        Label_Defects_Y.Text = "Offset Y�G" & Me.m_MainProcess.DOffsetY
                        Label_Defects_Count.Text = "Count�G" & Me.m_FuncProcess.Func_DefectArray.Count
                        Me.m_Total_Defect_Count = 0

                        If Me.m_FuncProcess.Func_DefectArray.Count > 0 Then
                            j = -1
                            For i = 0 To Me.m_FuncProcess.Func_DefectArray.Count - 1
                                p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)

                                If Me.CheckBox_NoShowMinusOne.Checked Then

                                    If Not p.Data = -1 Or Not p.Gate = -1 Then
                                        j = j + 1
                                        strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                                        ListView_Defects.Items.Add(i)
                                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobX))
                                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobY))
                                        ListView_Defects.Items(j).SubItems.Add(p.BlobArea)
                                        ListView_Defects.Items(j).SubItems.Add(p.Data)
                                        ListView_Defects.Items(j).SubItems.Add(p.Gate)
                                        ListView_Defects.Items(j).SubItems.Add(strType)
                                        ListView_Defects.Items(j).SubItems.Add(p.Pattern)
                                        ListView_Defects.Items(j).SubItems.Add(p.GrayMean)
                                        ListView_Defects.Items(j).SubItems.Add(p.GrayMin)
                                        ListView_Defects.Items(j).SubItems.Add(p.GrayMax)
                                        ListView_Defects.Items(j).SubItems.Add(p.Elongation)
                                        ListView_Defects.Items(j).SubItems.Add(p.Fullness)
                                        ListView_Defects.Items(j).SubItems.Add(p.Compactness)
                                        ListView_Defects.Items(j).SubItems.Add(p.MinFeretAngle)
                                        ListView_Defects.Items(j).SubItems.Add(p.MaxGray_Fullness)
                                        ListView_Defects.Items(j).SubItems.Add(p.StdDev)
                                        ListView_Defects.Items(j).SubItems.Add(p.Fatness)
                                        Me.m_Total_Defect_Count += 1
                                    End If
                                Else
                                    strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                                    ListView_Defects.Items.Add(i)
                                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobX))
                                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobY))
                                    ListView_Defects.Items(i).SubItems.Add(p.BlobArea)
                                    ListView_Defects.Items(i).SubItems.Add(p.Data)
                                    ListView_Defects.Items(i).SubItems.Add(p.Gate)
                                    ListView_Defects.Items(i).SubItems.Add(strType)
                                    ListView_Defects.Items(i).SubItems.Add(p.Pattern)
                                    ListView_Defects.Items(i).SubItems.Add(p.GrayMean)
                                    ListView_Defects.Items(i).SubItems.Add(p.GrayMin)
                                    ListView_Defects.Items(i).SubItems.Add(p.GrayMax)
                                    ListView_Defects.Items(i).SubItems.Add(p.Elongation)
                                    ListView_Defects.Items(i).SubItems.Add(p.Fullness)
                                    ListView_Defects.Items(i).SubItems.Add(p.Compactness)
                                    ListView_Defects.Items(i).SubItems.Add(p.MinFeretAngle)
                                    ListView_Defects.Items(i).SubItems.Add(p.MaxGray_Fullness)
                                    ListView_Defects.Items(i).SubItems.Add(p.StdDev)
                                    ListView_Defects.Items(i).SubItems.Add(p.Fatness)
                                    Me.m_Total_Defect_Count += 1
                                End If
                            Next
                        Else
                            'MsgBox("�ˬd���G�LDefect�C")
                        End If
                    Catch ex As Exception
                        Throw New Exception(ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If

            Else
                MsgBox("�S��Func�v���˴�����")
            End If

            '[Offline Test] OK\NG Show---------------------------->
            Try
                If Me.m_FuncProcess.Func_DefectArray.Count = 0 Then
                    Me.m_Form.OutputInfo("Func Test Result: OK")
                Else
                    Me.m_Form.OutputInfo("Func Test Result: NG")
                    For i = 0 To Me.m_FuncProcess.Func_DefectArray.Count - 1
                        p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)
                        If p.BlobX = -1 And p.BlobY = -1 And _
                            (p.Type = PointTypeDefine.R_DARK_POINT OrElse p.Type = PointTypeDefine.G_DARK_POINT OrElse p.Type = PointTypeDefine.W_DARK_POINT) Then
                            MsgBox(" Point Defects too Much !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        End If
                    Next

                    If ComboBox_ImageProcess.Text = "Line" Then
                        If Me.m_FuncProcess.Func_DefectArray.Count > Me.m_FuncProcess.CurrentFuncPatternRecipe.LineFinderRecipe.LineOverNum.Value Then
                            MsgBox(" Line Defects too Much !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        End If
                    End If

                End If
            Catch ex As Exception
                Throw New Exception("[Func Offline Test Error]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Button Control ---   
            Button_Enable(True)

            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncTestImageProcess.Button_Execute_Click]" & ex.Message)
            'MessageBox.Show("[Dialog_FuncTestImageProcess.Button_Execute_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Button_Enable(True)
        End Try
    End Sub
#End Region

#Region "--- Cancel_Button ---"
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        'Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
#End Region

#Region "--- Button_AddToLog ---"

    Private Sub Button_AddToLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_AddToLog.Click
        Dim i As Integer
        Dim p As Position

        If RadioButton_AddData_To_Log_Single.Checked Then
            If Me.m_sw Is Nothing Then
                '--- Write Selected Defect Log ---
                Me.m_sw = File.CreateText(Me.m_IPBootConfig.CharacteristicPath.Value & TextBox_AddData_To_Log_FileName.Text & ".txt")
                Me.m_sw.WriteLine("Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness")
            End If


            Try
                If Me.m_FuncProcess.Func_DefectArray.Count > 0 AndAlso Me.ListView_Defects.SelectedIndices.Count <> 0 Then

                    If Not ListView_Defects.SelectedIndices Is Nothing Then
                        i = ListView_Defects.SelectedIndices(0)
                    Else
                        i = 0
                    End If

                    p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)

                    '"Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness"
                    If Not Me.m_sw Is Nothing Then
                        Me.m_sw.WriteLine(i & vbTab & CInt(p.BlobX) & vbTab & CInt(p.BlobY) & vbTab & p.BlobArea & vbTab & p.Data & vbTab & p.Gate & vbTab & p.Type & vbTab & ComboBox_Pattern.Text & vbTab & p.GrayMean & vbTab & p.GrayMin & vbTab & p.GrayMax & vbTab & p.Elongation & vbTab & p.Fullness & vbTab & p.Compactness & vbTab & p.MinFeretAngle & vbTab & p.MaxGray_Fullness & vbTab & p.StdDev & vbTab & p.Fatness)    '2012/12/05 Rick modify
                    End If
                Else
                    MessageBox.Show("Select a Item First !", "����", MessageBoxButtons.OK, MessageBoxIcon.Information)
                End If
            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncTestImageProcess.Button_AddToLog_Click]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        ElseIf RadioButton_AddData_To_Log_All.Checked Then
            If Me.m_FuncProcess.Func_DefectArray.Count > 0 Then
                If Not Me.m_sw Is Nothing Then Me.m_sw.Close()
                Me.m_sw = File.CreateText(Me.m_IPBootConfig.CharacteristicPath.Value & TextBox_AddData_To_Log_FileName.Text & ".txt")
                Me.m_sw.WriteLine("Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness")

                For i = 0 To Me.m_FuncProcess.Func_DefectArray.Count - 1
                    p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)

                    '"Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness"
                    If Not Me.m_sw Is Nothing Then
                        Me.m_sw.WriteLine(i & vbTab & CInt(p.BlobX) & vbTab & CInt(p.BlobY) & vbTab & p.BlobArea & vbTab & p.Data & vbTab & p.Gate & vbTab & p.Type & vbTab & ComboBox_Pattern.Text & vbTab & p.GrayMean & vbTab & p.GrayMin & vbTab & p.GrayMax & vbTab & p.Elongation & vbTab & p.Fullness & vbTab & p.Compactness & vbTab & p.MinFeretAngle & vbTab & p.MaxGray_Fullness & vbTab & p.StdDev & vbTab & p.Fatness)    '2012/12/05 Rick modify
                    End If
                Next
            End If
        End If
    End Sub

#End Region

#Region "--- Button_SaveCharacteristicReicpe ---"
    Private Sub Button_SaveCharacteristicRecipe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SaveCharacteristicRecipe.Click
        Me.m_CharacteristicRecipe.GrayMin_Min.Value = Me.NumericUpDown_GrayMin_Min.Value
        Me.m_CharacteristicRecipe.GrayMin_Max.Value = Me.NumericUpDown_GrayMin_Max.Value
        Me.m_CharacteristicRecipe.GrayMax_Min.Value = Me.NumericUpDown_GrayMax_Min.Value
        Me.m_CharacteristicRecipe.GrayMax_Max.Value = Me.NumericUpDown_GrayMax_Max.Value
        Me.m_CharacteristicRecipe.Elongation_Min.Value = Me.NumericUpDown_Elongation_Min.Value
        Me.m_CharacteristicRecipe.Elongation_Max.Value = Me.NumericUpDown_Elongation_Max.Value
        Me.m_CharacteristicRecipe.Fullness_Min.Value = Me.NumericUpDown_Fullness_Min.Value
        Me.m_CharacteristicRecipe.Fullness_Max.Value = Me.NumericUpDown_Fullness_Max.Value
        Me.m_CharacteristicRecipe.Compactness_Max.Value = Me.NumericUpDown_Compactness_Max.Value
        ClsCharacteristicRecipe.WriteXML(Me.m_CharacteristicRecipe, Me.m_CharacterRicepeFile)
    End Sub
#End Region

#Region "--- Button_GoTo_Position ---"
    Private Sub Button_GoTo_Position_Click(sender As System.Object, e As System.EventArgs) Handles Button_GoTo_Position.Click
        If CInt(TextBox_GoTo_BlobX.Text) > 0 And CInt(TextBox_GoTo_BlobY.Text) > 0 Then
            Try
                Dim picsize As Integer
                Dim offset_X, offset_Y As Integer
                Dim p As New Position
                Dim offX As Integer
                Dim offY As Integer
                Dim DisplayWidth As Integer = Me.m_Form.Panel_AxMDisplay.Size.Width
                Dim DisplayHeight As Integer = Me.m_Form.Panel_AxMDisplay.Size.Height
                Dim Image As MIL_ID = M_NULL
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double
                Dim CenterHScroll As Double
                Dim OffsetHScroll As Double
                Dim CenterVScroll As Double
                Dim OffsetVScroll As Double

                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

                p.BlobX = CInt(TextBox_GoTo_BlobX.Text)
                p.BlobY = CInt(TextBox_GoTo_BlobY.Text)

                offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                picsize = Math.Max(CInt(((50) ^ 0.5) * 2), 100)

                Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                    Case 0
                        If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                            offset_X = Math.Max(CInt(p.BlobX) - CInt(picsize / 2), 0)
                            offset_Y = Math.Max(CInt(p.BlobY) - CInt(picsize / 2), 0)
                        End If
                    Case 1
                        offset_X = Math.Max(CInt(p.BlobX - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(p.BlobY - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - CInt(picsize / 2), 0)
                End Select
                'Me.m_Form.ResetScrollBar()

                Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

                CenterHScroll = ((offset_X + CInt(picsize / 2)) * Me.m_Form.HScrollBar.Maximum) / (SizeX - DisplayWidth / ZoomX)
                OffsetHScroll = ((DisplayWidth / ZoomX) / 2) * (Me.m_Form.HScrollBar.Maximum / (SizeX - DisplayWidth / ZoomX))
                CenterVScroll = ((offset_Y + CInt(picsize / 2)) * Me.m_Form.VScrollBar.Maximum) / (SizeY - DisplayHeight / ZoomX)
                OffsetVScroll = ((DisplayHeight / ZoomX) / 2) * (Me.m_Form.VScrollBar.Maximum / (SizeY - DisplayHeight / ZoomX))

                CenterHScroll = CenterHScroll - OffsetHScroll
                CenterVScroll = CenterVScroll - OffsetVScroll

                If CenterHScroll < 0 Then
                    Me.m_Form.HScrollBar.Value = 0
                ElseIf CenterHScroll > Me.m_Form.HScrollBar.Maximum Then
                    Me.m_Form.HScrollBar.Value = Me.m_Form.HScrollBar.Maximum
                Else
                    If CenterHScroll > 0 Then Me.m_Form.HScrollBar.Value = CenterHScroll
                End If

                If CenterVScroll < 0 Then
                    Me.m_Form.VScrollBar.Value = 0
                ElseIf CenterVScroll > Me.m_Form.VScrollBar.Maximum Then
                    Me.m_Form.VScrollBar.Value = Me.m_Form.VScrollBar.Maximum
                Else
                    If CenterVScroll > 0 Then Me.m_Form.VScrollBar.Value = CenterVScroll
                End If

                Me.DrawGoTo_Blob(p.BlobX, p.BlobY)
            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncTestImageProcess.Button_GoTo_Position_Click]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        Else
            MsgBox("���ˬd��J�ƭȤj�� 0 !", MsgBoxStyle.Exclamation, "[AreaGrabber]")
        End If
    End Sub

    ' For Mura
    Private Sub Button_x2GoTo_Position_Click(sender As System.Object, e As System.EventArgs) Handles Button_x2GoTo_Position.Click
        If CInt(TextBox_GoTo_BlobX.Text) > 0 And CInt(TextBox_GoTo_BlobY.Text) > 0 Then
            Try
                Dim picsize As Integer
                Dim offset_X, offset_Y As Integer
                Dim p As New Position
                Dim offX As Integer
                Dim offY As Integer
                Dim DisplayWidth As Integer = Me.m_Form.Panel_AxMDisplay.Size.Width
                Dim DisplayHeight As Integer = Me.m_Form.Panel_AxMDisplay.Size.Height
                Dim Image As MIL_ID = M_NULL
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double
                Dim CenterHScroll As Double
                Dim OffsetHScroll As Double
                Dim CenterVScroll As Double
                Dim OffsetVScroll As Double

                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

                p.BlobX = CInt(TextBox_GoTo_BlobX.Text) * 2
                p.BlobY = CInt(TextBox_GoTo_BlobY.Text) * 2

                offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                picsize = Math.Max(CInt(((50) ^ 0.5) * 2), 100)

                Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                    Case 0
                        If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                            offset_X = Math.Max(CInt(p.BlobX) - CInt(picsize / 2), 0)
                            offset_Y = Math.Max(CInt(p.BlobY) - CInt(picsize / 2), 0)
                        End If
                    Case 1
                        offset_X = Math.Max(CInt(p.BlobX - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(p.BlobY - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - CInt(picsize / 2), 0)
                End Select
                'Me.m_Form.ResetScrollBar()

                Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

                CenterHScroll = ((offset_X + CInt(picsize / 2)) * Me.m_Form.HScrollBar.Maximum) / (SizeX - DisplayWidth / ZoomX)
                OffsetHScroll = ((DisplayWidth / ZoomX) / 2) * (Me.m_Form.HScrollBar.Maximum / (SizeX - DisplayWidth / ZoomX))
                CenterVScroll = ((offset_Y + CInt(picsize / 2)) * Me.m_Form.VScrollBar.Maximum) / (SizeY - DisplayHeight / ZoomX)
                OffsetVScroll = ((DisplayHeight / ZoomX) / 2) * (Me.m_Form.VScrollBar.Maximum / (SizeY - DisplayHeight / ZoomX))

                CenterHScroll = CenterHScroll - OffsetHScroll
                CenterVScroll = CenterVScroll - OffsetVScroll

                If CenterHScroll < 0 Then
                    Me.m_Form.HScrollBar.Value = 0
                ElseIf CenterHScroll > Me.m_Form.HScrollBar.Maximum Then
                    Me.m_Form.HScrollBar.Value = Me.m_Form.HScrollBar.Maximum
                Else
                    If CenterHScroll > 0 Then Me.m_Form.HScrollBar.Value = CenterHScroll
                End If

                If CenterVScroll < 0 Then
                    Me.m_Form.VScrollBar.Value = 0
                ElseIf CenterVScroll > Me.m_Form.VScrollBar.Maximum Then
                    Me.m_Form.VScrollBar.Value = Me.m_Form.VScrollBar.Maximum
                Else
                    If CenterVScroll > 0 Then Me.m_Form.VScrollBar.Value = CenterVScroll
                End If

                Me.DrawGoTo_Blob(p.BlobX, p.BlobY)
            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncTestImageProcess.Button_GoTo_Position_Click]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        Else
            MsgBox("���ˬd��J�ƭȤj�� 0 !", MsgBoxStyle.Exclamation, "[AreaGrabber]")
        End If
    End Sub
#End Region

#End Region

#Region "--- Dialog Event ---"

#Region "--- Dialog_FuncTestImageProcess_Load ---"
    Private Sub Dialog_FuncTestImageProcess_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer

        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        Try
            Me.ComboBox_Pattern.Items.Clear()
            For i = 0 To Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value - 1
                Me.ComboBox_Pattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex <= Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
                Me.ComboBox_Pattern.SelectedIndex = 0
            Else
                Me.ComboBox_Pattern.SelectedIndex = Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex - Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            End If

            Me.TextBox_SaveImgForAIPath.Text = Me.m_IPBootConfig.DataRootPath.Value
            Me.m_FuncProcess.InitialFilter(Me.m_MainProcess.ErrorCode)
            '----------------------------------------------------------------------------------------------
            ' Initial Func Filters  ==> Request_Command = "INITIAL_FUNC_FILTER" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "INITIAL_FUNC_FILTER"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    'MessageBox.Show("[Dialog_FuncTestImageProcess.FormLoad]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncTestImageProcess.FormLoad]Initial Func Filters Error ! (" & ex.Message & ")")
                'MessageBox.Show("[Dialog_FuncTestImageProcess.FormLoad]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '--- Write Selected Defect Log ---
            Me.m_sw = File.CreateText(Me.m_IPBootConfig.CharacteristicPath.Value & "Defectlog_Select.txt")
            Me.m_sw.WriteLine("Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness")

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncTestImageProcess.FormLoad]" & ex.Message)
        End Try

        Me.KeyPreview = True
        Me.Update()
    End Sub
#End Region

#Region "--- Dialog_FuncTestImageProcess_Closing ---"
    Private Sub Dialog_FuncTestImageProcess_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If Not Me.m_sw Is Nothing Then Me.m_sw.Close()
        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.CheckBox_DrawDefect.Checked = False
        Me.m_Form.PaintStop = True
        Me.m_Form.Focus()
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub
#End Region

#End Region

#Region "--- ListView Event ---"

#Region "--- ListView_Defects_DoubleClick ---"
    Private Sub ListView_Defects_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Defects.DoubleClick
        ' �e�H�����z   Click + DoubleClick�I�X�s����    ��C������F
        Dim i As Integer
        Dim picsize As Integer
        Dim offset_X, offset_Y As Integer
        Dim p As New Position
        Dim offX As Integer
        Dim offY As Integer
        Dim DisplayWidth As Integer = Me.m_Form.Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.m_Form.Panel_AxMDisplay.Size.Height
        Dim Image As MIL_ID = M_NULL
        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim ZoomX As Double
        Dim CenterHScroll As Double
        Dim OffsetHScroll As Double
        Dim CenterVScroll As Double
        Dim OffsetVScroll As Double

        'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

        Me.m_FuncProcess.DefectArray.Clear()
        Me.m_Form.SetStatusBarPanel_Scale("�Y�� = " & ZoomX)
        Me.m_Form.SetButton_ZoomIn(True)
        Me.m_Form.SetButton_ZoomOut(True)
        Me.m_Form.ResetScrollBar()

        i = ListView_Defects.SelectedIndices(0)
        p.BlobX = CInt(ListView_Defects.Items(i).SubItems(1).Text)
        p.BlobY = CInt(ListView_Defects.Items(i).SubItems(2).Text)
        p.BlobArea = CInt(ListView_Defects.Items(i).SubItems(3).Text)
        'grant 2010/5/14 transfer enum to constant
        p.Type = Convert.ToInt32([Enum].Parse(GetType(PointTypeDefine), ListView_Defects.Items(i).SubItems(6).Text))

        'p.Type = ListView_Defects.Items(i).SubItems(6).Text

        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        Select Case p.Type
            'Case ClassLibrary.PointTypeDefine.R_BRIGHT_POINT, ClassLibrary.PointTypeDefine.DARK_POINT, ClassLibrary.PointTypeDefine.GROUP_SMALL_BRIGHT_POINT, PointTypeDefine.WEAK_BRIGHT_POINT, ClassLibrary.PointTypeDefine.DARK_BRIGHT_POINT
            Case ClassLibrary.PointTypeDefine.R_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.G_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.B_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.W_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.R_DARK_POINT, _
                ClassLibrary.PointTypeDefine.G_DARK_POINT, _
                ClassLibrary.PointTypeDefine.B_DARK_POINT, _
                ClassLibrary.PointTypeDefine.W_DARK_POINT, _
                ClassLibrary.PointTypeDefine.BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.DARK_POINT, _
                ClassLibrary.PointTypeDefine.GROUP_SMALL_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.WEAK_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.DARK_BRIGHT_POINT

                picsize = Math.Max(CInt(((p.BlobArea) ^ 0.5) * 2), 100)

                Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                    Case 0
                        If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                            offset_X = Math.Max(CInt(p.BlobX) - CInt(picsize / 2), 0)
                            offset_Y = Math.Max(CInt(p.BlobY) - CInt(picsize / 2), 0)
                        End If
                    Case 1
                        offset_X = Math.Max(CInt(p.BlobX - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(p.BlobY - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - CInt(picsize / 2), 0)
                End Select
            Case ClassLibrary.PointTypeDefine.BRIGHT_HLINE, ClassLibrary.PointTypeDefine.BRIGHT_VLINE, ClassLibrary.PointTypeDefine.DARK_HLINE, ClassLibrary.PointTypeDefine.DARK_VLINE _
                  , ClassLibrary.PointTypeDefine.HBITLINE, ClassLibrary.PointTypeDefine.HBLOCK, ClassLibrary.PointTypeDefine.VBITLINE, ClassLibrary.PointTypeDefine.VBLOCK
                Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                    Case 0
                        If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                            If p.BlobX = -1 Then
                                offset_X = 0
                                offset_Y = Math.Max(CInt(p.BlobY) - 50, 0)
                            End If
                            If p.BlobY = -1 Then
                                offset_X = Math.Max(CInt(p.BlobX) - 50, 0)
                                offset_Y = 0
                            End If
                        End If
                    Case 1
                        If p.BlobX = -1 Then
                            offset_X = Math.Max(CInt(p.BlobX) - 50, 0)
                            offset_Y = Math.Max(CInt(p.BlobY - offY) - 50, 0)
                        End If
                        If p.BlobY = -1 Then
                            offset_X = Math.Max(CInt(p.BlobX - offX) - 50, 0)
                            offset_Y = Math.Max(CInt(p.BlobY) - 50, 0)
                        End If
                End Select
        End Select
        'offset_X = Math.Min(offset_X, Me.m_Form.HScrollBar.Maximum)
        'offset_Y = Math.Min(offset_Y, Me.m_Form.VScrollBar.Maximum)

        'Me.m_Form.HScrollBar.Value = offset_X
        'Me.m_Form.VScrollBar.Value = offset_Y
        Me.m_Form.ResetScrollBar()

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

        CenterHScroll = ((offset_X + CInt(picsize / 2)) * Me.m_Form.HScrollBar.Maximum) / (SizeX - DisplayWidth / ZoomX)
        OffsetHScroll = ((DisplayWidth / ZoomX) / 2) * (Me.m_Form.HScrollBar.Maximum / (SizeX - DisplayWidth / ZoomX))
        CenterVScroll = ((offset_Y + CInt(picsize / 2)) * Me.m_Form.VScrollBar.Maximum) / (SizeY - DisplayHeight / ZoomX)
        OffsetVScroll = ((DisplayHeight / ZoomX) / 2) * (Me.m_Form.VScrollBar.Maximum / (SizeY - DisplayHeight / ZoomX))

        CenterHScroll = CenterHScroll - OffsetHScroll
        CenterVScroll = CenterVScroll - OffsetVScroll

        If CenterHScroll < 0 Then
            If Me.ComboBox_ImageProcess.Text = "Point" Then
                Me.m_Form.HScrollBar.Value = 0
            End If
        ElseIf CenterHScroll > Me.m_Form.HScrollBar.Maximum Then
            Me.m_Form.HScrollBar.Value = Me.m_Form.HScrollBar.Maximum
        Else
            If CenterHScroll > 0 Then Me.m_Form.HScrollBar.Value = CenterHScroll
        End If

        If CenterVScroll < 0 Then
            If Me.ComboBox_ImageProcess.Text = "Point" Then
                Me.m_Form.VScrollBar.Value = 0
            End If
        ElseIf CenterVScroll > Me.m_Form.VScrollBar.Maximum Then
            Me.m_Form.VScrollBar.Value = Me.m_Form.VScrollBar.Maximum
        Else
            If CenterVScroll > 0 Then Me.m_Form.VScrollBar.Value = CenterVScroll
        End If

        If CenterHScroll < 0 AndAlso CenterVScroll < 0 Then
            Me.m_Form.HScrollBar.Value = 0
            Me.m_Form.VScrollBar.Value = 0
        End If

        If CheckBox_DrawDefect.Checked Then
            Me.DrawMark()
        Else
            Me.m_Form.PaintStop = True
        End If

    End Sub
#End Region

#Region "--- ListView_Defects_Click ---"
    Private Sub ListView_Defects_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_Defects.Click
        If CheckBox_DrawDefect.Checked Then Me.DrawMark()
    End Sub
#End Region

#Region "--- ListView_Defects_MouseDown ---"
    Private Sub ListView_Defects_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles ListView_Defects.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            Me.ListView_Defects.ContextMenuStrip = Me.DefectLogContextMenuStrip
        End If
    End Sub
#End Region

#End Region

#Region "--- ComboBox Event ---"

#Region "--- ComboBox_Pattern_SelectedIndexChanged ---"
    Private Sub ComboBox_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Pattern.SelectedIndexChanged
        Dim PatternName As String

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_Pattern.SelectedIndex + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Button Control ---   
        Button_Enable(False)

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 300000 '300 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_Pattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                'MessageBox.Show("[Dialog_FuncTestImageProcess.ComboBox_Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If

            Button_Enable(True)
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncTestImageProcess.ComboBox_Pattern_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            'MessageBox.Show("[Dialog_FuncTestImageProcess.ComboBox_Pattern_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Button_Enable(True)
        End Try

        '---CheckCharacteristic Update---
        If Me.m_IPBootConfig.DetailOutput.Value Then
            Me.CheckCharacteristicFile()
            UpdateData()
        End If

    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_DrawLine_CheckedChanged ---"
    Private Sub CheckBox_DrawLine_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_DrawDefect.CheckedChanged
        If CheckBox_DrawDefect.Checked Then
            Me.DrawMark()
        Else
            Me.m_Form.PaintStop = True
            Me.m_GraphicsImage.Clear(Color.Transparent)
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_NoShowMinusOne_CheckedChanged ---"
    Private Sub CheckBox_NoShowMinusOne_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_NoShowMinusOne.CheckedChanged
        Dim j As Integer
        Dim i As Integer
        Dim p As Position
        Dim strType As String

        ListView_Defects.Items.Clear()
        Me.Update()

        If Me.m_FuncProcess.Func_DefectArray.Count > 0 Then
            j = -1
            For i = 0 To Me.m_FuncProcess.Func_DefectArray.Count - 1
                p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)

                If Me.CheckBox_NoShowMinusOne.Checked Then

                    If Not p.Data = -1 Or Not p.Gate = -1 Then
                        j = j + 1
                        strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                        ListView_Defects.Items.Add(i)
                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobX))
                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobY))
                        ListView_Defects.Items(j).SubItems.Add(p.BlobArea)
                        ListView_Defects.Items(j).SubItems.Add(p.Data)
                        ListView_Defects.Items(j).SubItems.Add(p.Gate)
                        ListView_Defects.Items(j).SubItems.Add(strType)
                        ListView_Defects.Items(j).SubItems.Add(p.Pattern)
                        ListView_Defects.Items(j).SubItems.Add(p.GrayMean)
                    End If
                Else
                    strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                    ListView_Defects.Items.Add(i)
                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobX))
                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobY))
                    ListView_Defects.Items(i).SubItems.Add(p.BlobArea)
                    ListView_Defects.Items(i).SubItems.Add(p.Data)
                    ListView_Defects.Items(i).SubItems.Add(p.Gate)
                    ListView_Defects.Items(i).SubItems.Add(strType)
                    ListView_Defects.Items(i).SubItems.Add(p.Pattern)
                    ListView_Defects.Items(i).SubItems.Add(p.GrayMean)
                End If
            Next
        Else
            'MsgBox("�ˬd���G�LDefect�C")
        End If
    End Sub
#End Region

#Region "--- CheckBox_FilterCharacteristic_CheckedChanged---"
    Private Sub CheckBox_FilterCharacteristic_CheckedChanged(sender As Object, e As System.EventArgs) Handles CheckBox_FilterCharacteristic.CheckedChanged
        Dim j As Integer
        Dim i As Integer
        Dim p As Position
        Dim strType As String

        ListView_Defects.Items.Clear()
        Me.Update()
        j = -1

        If Me.m_FuncProcess.Func_DefectArray.Count > 0 Then
            For i = 0 To Me.m_FuncProcess.Func_DefectArray.Count - 1
                p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)

                If Me.CheckBox_FilterCharacteristic.Checked Then
                    If p.GrayMin < Me.NumericUpDown_GrayMin_Min.Value Or p.GrayMin > Me.NumericUpDown_GrayMin_Max.Value Or _
                        p.GrayMax < Me.NumericUpDown_GrayMax_Min.Value Or p.GrayMax > Me.NumericUpDown_GrayMax_Max.Value Or _
                        p.Elongation < Me.NumericUpDown_Elongation_Min.Value Or p.Elongation > Me.NumericUpDown_Elongation_Max.Value Or _
                        p.Fullness < Me.NumericUpDown_Fullness_Min.Value Or p.Fullness > Me.NumericUpDown_Fullness_Max.Value Or _
                        p.Compactness > Me.NumericUpDown_Compactness_Max.Value _
                    Then
                    Else
                        j = j + 1
                        strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                        ListView_Defects.Items.Add(j)
                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobX))
                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobY))
                        ListView_Defects.Items(j).SubItems.Add(p.BlobArea)
                        ListView_Defects.Items(j).SubItems.Add(p.Data)
                        ListView_Defects.Items(j).SubItems.Add(p.Gate)
                        ListView_Defects.Items(j).SubItems.Add(strType)
                        ListView_Defects.Items(j).SubItems.Add(p.Pattern)
                        ListView_Defects.Items(j).SubItems.Add(p.GrayMean)
                        ListView_Defects.Items(j).SubItems.Add(p.GrayMin)
                        ListView_Defects.Items(j).SubItems.Add(p.GrayMax)
                        ListView_Defects.Items(j).SubItems.Add(p.Elongation)
                        ListView_Defects.Items(j).SubItems.Add(p.Fullness)
                        ListView_Defects.Items(j).SubItems.Add(p.Compactness)
                        ListView_Defects.Items(j).SubItems.Add(p.MinFeretAngle)
                        ListView_Defects.Items(j).SubItems.Add(p.MaxGray_Fullness)
                        ListView_Defects.Items(j).SubItems.Add(p.StdDev)
                        Me.m_Total_Defect_Count += 1
                    End If
                Else
                    strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                    ListView_Defects.Items.Add(i)
                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobX))
                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobY))
                    ListView_Defects.Items(i).SubItems.Add(p.BlobArea)
                    ListView_Defects.Items(i).SubItems.Add(p.Data)
                    ListView_Defects.Items(i).SubItems.Add(p.Gate)
                    ListView_Defects.Items(i).SubItems.Add(strType)
                    ListView_Defects.Items(i).SubItems.Add(p.Pattern)
                    ListView_Defects.Items(i).SubItems.Add(p.GrayMean)
                    ListView_Defects.Items(i).SubItems.Add(p.GrayMin)
                    ListView_Defects.Items(i).SubItems.Add(p.GrayMax)
                    ListView_Defects.Items(i).SubItems.Add(p.Elongation)
                    ListView_Defects.Items(i).SubItems.Add(p.Fullness)
                    ListView_Defects.Items(i).SubItems.Add(p.Compactness)
                    ListView_Defects.Items(i).SubItems.Add(p.MinFeretAngle)
                    ListView_Defects.Items(i).SubItems.Add(p.MaxGray_Fullness)
                    ListView_Defects.Items(i).SubItems.Add(p.StdDev)
                    Me.m_Total_Defect_Count += 1
                End If
            Next
        Else
            'MsgBox("�ˬd���G�LDefect�C")
        End If
    End Sub
#End Region

#Region "--- CheckBox_ShowAllDefects_CheckedChanged ---"
    Private Sub CheckBox_ShowAllDefects_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_ShowAllDefects.CheckedChanged
        If CheckBox_ShowAllDefects.Checked Then
            DrawAll_PointDefects()
        Else
            Me.m_GraphicsImage_2.Clear(Color.Transparent)
        End If
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown ---"

#Region "--- NumericUpDown_MultiPixel_RegionIndex_ValueChanged ---"
    Private Sub NumericUpDown_MultiPixel_RegionIndex_ValueChanged(sender As System.Object, e As System.EventArgs)
        If CheckBox_DrawDefect.Checked Then
            If Me.ListView_Defects.SelectedIndices.Count > 0 Then Me.DrawMark()
        Else
            Me.m_Form.PaintStop = True
            Me.m_GraphicsImage.Clear(Color.Transparent)
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#End Region

#Region "--- ContextMenuStrip Event ---"

#Region "--- DefectLogContextMenuStrip_ItemClicked ---"
    Private Sub DefectLogContextMenuStrip_ItemClicked(sender As Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles DefectLogContextMenuStrip.ItemClicked
        If e.ClickedItem Is AddToLogToolStripMenuItem Then
            Me.Button_AddToLog.PerformClick()
        ElseIf e.ClickedItem Is SaveImgToFalseToolStripMenuItem Then
            Dim ImagePath As String
            Dim ImageTifFile As String
            Dim SelectIndex As Integer
            Dim ChipID As String
            Dim FalseCharacteristicSW As StreamWriter = Nothing
            Dim p As Position
            If Me.TextBox_PanelID.Text = "" Then
                ChipID = Me.m_Form.PanelID
                If ChipID = "" Then
                    ChipID = "AAAAAAAA"
                End If
            Else
                ChipID = Me.TextBox_PanelID.Text
            End If
            If Not Me.CheckBox_SaveDefectImage.Checked Or Me.TextBox_SaveImgForAIPath.Text = "" Then
                MsgBox("Please Save Defect Image or Input AI Path")
                Exit Sub
            End If
            If ListView_Defects.Items.Count > 0 Then
                ImagePath = Me.TextBox_SaveImgForAIPath.Text & "\" & ChipID & "\False"
                If Not System.IO.Directory.Exists(ImagePath) Then
                    System.IO.Directory.CreateDirectory(ImagePath)
                End If
                If Not ListView_Defects.SelectedIndices Is Nothing Then
                    SelectIndex = ListView_Defects.SelectedIndices(0)
                    If System.IO.File.Exists(Me.m_DefectFilePath(SelectIndex) & Me.m_DefectFileName(SelectIndex)) Then
                        System.IO.File.Copy(Me.m_DefectFilePath(SelectIndex) & Me.m_DefectFileName(SelectIndex), ImagePath & "\" & Me.m_DefectFileName(SelectIndex), True)
                        ImageTifFile = Me.m_DefectFileName(SelectIndex).Substring(0, Me.m_DefectFileName(SelectIndex).Length - 4) & ".tif"
                        If Me.CheckBox_SaveTif.Checked AndAlso System.IO.File.Exists(Me.m_DefectFilePath(SelectIndex) & ImageTifFile) Then
                            System.IO.File.Copy(Me.m_DefectFilePath(SelectIndex) & ImageTifFile, ImagePath & "\" & ImageTifFile, True)
                        End If
                        If Me.CheckBox_SaveCharacteristic.Checked Then
                            p = Me.m_FuncProcess.Func_DefectArray.GetPosition(SelectIndex)
                            FalseCharacteristicSW = File.CreateText(String.Format("{0}\{1}_FalseDefectlog.txt", ImagePath, ChipID))
                            FalseCharacteristicSW.WriteLine("Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness")
                            FalseCharacteristicSW.WriteLine(SelectIndex & vbTab & CInt(p.BlobX) & vbTab & CInt(p.BlobY) & vbTab & p.BlobArea & vbTab & p.Data & vbTab & p.Gate & vbTab & p.Type & vbTab & ComboBox_Pattern.Text & vbTab & p.GrayMean & vbTab & p.GrayMin & vbTab & p.GrayMax & vbTab & p.Elongation & vbTab & p.Fullness & vbTab & p.Compactness & vbTab & p.MinFeretAngle & vbTab & p.MaxGray_Fullness & vbTab & p.StdDev & vbTab & p.Fatness)
                            FalseCharacteristicSW.Close()
                        End If
                    End If
                End If
            End If
        ElseIf e.ClickedItem Is SaveImgToTrueToolStripMenuItem Then
            Dim ImagePath As String
            Dim ImageTifFile As String
            Dim SelectIndex As Integer
            Dim ChipID As String
            Dim TrueCharacteristicSW As StreamWriter = Nothing
            Dim p As Position
            If Me.TextBox_PanelID.Text = "" Then
                ChipID = Me.m_Form.PanelID
                If ChipID = "" Then
                    ChipID = "AAAAAAAA"
                End If
            Else
                ChipID = Me.TextBox_PanelID.Text
            End If
            If Not Me.CheckBox_SaveDefectImage.Checked Or Me.TextBox_SaveImgForAIPath.Text = "" Then
                MsgBox("Please Save Defect Image or Input AI Path")
                Exit Sub
            End If
            If ListView_Defects.Items.Count > 0 Then
                ImagePath = Me.TextBox_SaveImgForAIPath.Text & "\" & ChipID & "\True"
                If Not System.IO.Directory.Exists(ImagePath) Then
                    System.IO.Directory.CreateDirectory(ImagePath)
                End If
                If Not ListView_Defects.SelectedIndices Is Nothing Then
                    SelectIndex = ListView_Defects.SelectedIndices(0)
                    If System.IO.File.Exists(Me.m_DefectFilePath(SelectIndex) & Me.m_DefectFileName(SelectIndex)) Then
                        System.IO.File.Copy(Me.m_DefectFilePath(SelectIndex) & Me.m_DefectFileName(SelectIndex), ImagePath & "\" & Me.m_DefectFileName(SelectIndex), True)
                        ImageTifFile = Me.m_DefectFileName(SelectIndex).Substring(0, Me.m_DefectFileName(SelectIndex).Length - 4) & ".tif"
                        If Me.CheckBox_SaveTif.Checked AndAlso System.IO.File.Exists(Me.m_DefectFilePath(SelectIndex) & ImageTifFile) Then
                            System.IO.File.Copy(Me.m_DefectFilePath(SelectIndex) & ImageTifFile, ImagePath & "\" & ImageTifFile, True)
                        End If
                        If Me.CheckBox_SaveCharacteristic.Checked Then
                            p = Me.m_FuncProcess.Func_DefectArray.GetPosition(SelectIndex)
                            TrueCharacteristicSW = File.CreateText(String.Format("{0}\{1}_TrueDefectlog.txt", ImagePath, ChipID))
                            TrueCharacteristicSW.WriteLine("Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness")
                            TrueCharacteristicSW.WriteLine(SelectIndex & vbTab & CInt(p.BlobX) & vbTab & CInt(p.BlobY) & vbTab & p.BlobArea & vbTab & p.Data & vbTab & p.Gate & vbTab & p.Type & vbTab & ComboBox_Pattern.Text & vbTab & p.GrayMean & vbTab & p.GrayMin & vbTab & p.GrayMax & vbTab & p.Elongation & vbTab & p.Fullness & vbTab & p.Compactness & vbTab & p.MinFeretAngle & vbTab & p.MaxGray_Fullness & vbTab & p.StdDev & vbTab & p.Fatness)
                            TrueCharacteristicSW.Close()
                        End If
                    End If
                End If
            End If
        ElseIf e.ClickedItem Is SaveImgToTrueOtherFalseToolStripMenuItem Then
            Dim ImagePath_True As String
            Dim ImagePath_False As String
            Dim ImageTifFile As String
            Dim TrueIndex As Integer
            Dim ChipID As String
            Dim TrueCharacteristicSW As StreamWriter = Nothing
            Dim FalseCharacteristicSW As StreamWriter = Nothing
            If Me.TextBox_PanelID.Text = "" Then
                ChipID = Me.m_Form.PanelID
                If ChipID = "" Then
                    ChipID = "AAAAAAAA"
                End If
            Else
                ChipID = Me.TextBox_PanelID.Text
            End If
            If Not Me.CheckBox_SaveDefectImage.Checked Or Me.TextBox_SaveImgForAIPath.Text = "" Then
                MsgBox("Please Save Defect Image or Input AI Path")
                Exit Sub
            End If
            If ListView_Defects.Items.Count > 0 Then
                ImagePath_True = Me.TextBox_SaveImgForAIPath.Text & "\" & ChipID & "\True"
                ImagePath_False = Me.TextBox_SaveImgForAIPath.Text & "\" & ChipID & "\False"
                If Not System.IO.Directory.Exists(ImagePath_True) Then
                    System.IO.Directory.CreateDirectory(ImagePath_True)
                End If
                If Not System.IO.Directory.Exists(ImagePath_False) Then
                    System.IO.Directory.CreateDirectory(ImagePath_False)
                End If
                If Not ListView_Defects.SelectedIndices Is Nothing Then
                    TrueIndex = ListView_Defects.SelectedIndices(0)
                    If Me.CheckBox_SaveCharacteristic.Checked Then
                        TrueCharacteristicSW = File.CreateText(String.Format("{0}\{1}_TrueDefectlog.txt", ImagePath_True, ChipID))
                        FalseCharacteristicSW = File.CreateText(String.Format("{0}\{1}_FalseDefectlog.txt", ImagePath_False, ChipID))
                        TrueCharacteristicSW.WriteLine("Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness")
                        FalseCharacteristicSW.WriteLine("Index" & vbTab & "BlobX" & vbTab & "BlobY" & vbTab & "Area" & vbTab & "Data" & vbTab & "Gate" & vbTab & "PType" & vbTab & "Pattern" & vbTab & "GrayMean" & vbTab & "GrayMin" & vbTab & "GrayMax" & vbTab & "Elongation" & vbTab & "Fullness" & vbTab & "Compactness" & vbTab & "MinFeretAngle" & vbTab & "MaxGray_Fullness" & vbTab & "StdDev" & vbTab & "Fatness")
                    End If
                    For i = 0 To ListView_Defects.Items.Count - 1
                        Dim p As Position
                        p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)
                        If i <> TrueIndex Then
                            If System.IO.File.Exists(Me.m_DefectFilePath(i) & Me.m_DefectFileName(i)) Then
                                System.IO.File.Copy(Me.m_DefectFilePath(i) & Me.m_DefectFileName(i), ImagePath_False & "\" & Me.m_DefectFileName(i), True)
                                ImageTifFile = Me.m_DefectFileName(i).Substring(0, Me.m_DefectFileName(i).Length - 4) & ".tif"
                                If Me.CheckBox_SaveTif.Checked AndAlso System.IO.File.Exists(Me.m_DefectFilePath(i) & ImageTifFile) Then
                                    System.IO.File.Copy(Me.m_DefectFilePath(i) & ImageTifFile, ImagePath_False & "\" & ImageTifFile, True)
                                End If
                                If Me.CheckBox_SaveCharacteristic.Checked Then
                                    FalseCharacteristicSW.WriteLine(i & vbTab & CInt(p.BlobX) & vbTab & CInt(p.BlobY) & vbTab & p.BlobArea & vbTab & p.Data & vbTab & p.Gate & vbTab & p.Type & vbTab & ComboBox_Pattern.Text & vbTab & p.GrayMean & vbTab & p.GrayMin & vbTab & p.GrayMax & vbTab & p.Elongation & vbTab & p.Fullness & vbTab & p.Compactness & vbTab & p.MinFeretAngle & vbTab & p.MaxGray_Fullness & vbTab & p.StdDev & vbTab & p.Fatness)
                                End If
                            End If
                        Else
                            If System.IO.File.Exists(Me.m_DefectFilePath(i) & Me.m_DefectFileName(i)) Then
                                System.IO.File.Copy(Me.m_DefectFilePath(i) & Me.m_DefectFileName(i), ImagePath_True & "\" & Me.m_DefectFileName(i), True)
                                ImageTifFile = Me.m_DefectFileName(i).Substring(0, Me.m_DefectFileName(i).Length - 4) & ".tif"
                                If Me.CheckBox_SaveTif.Checked AndAlso System.IO.File.Exists(Me.m_DefectFilePath(i) & ImageTifFile) Then
                                    System.IO.File.Copy(Me.m_DefectFilePath(i) & ImageTifFile, ImagePath_True & "\" & ImageTifFile, True)
                                End If
                                If Me.CheckBox_SaveCharacteristic.Checked Then
                                    TrueCharacteristicSW.WriteLine(i & vbTab & CInt(p.BlobX) & vbTab & CInt(p.BlobY) & vbTab & p.BlobArea & vbTab & p.Data & vbTab & p.Gate & vbTab & p.Type & vbTab & ComboBox_Pattern.Text & vbTab & p.GrayMean & vbTab & p.GrayMin & vbTab & p.GrayMax & vbTab & p.Elongation & vbTab & p.Fullness & vbTab & p.Compactness & vbTab & p.MinFeretAngle & vbTab & p.MaxGray_Fullness & vbTab & p.StdDev & vbTab & p.Fatness)
                                End If
                            End If
                        End If
                    Next
                    If Me.CheckBox_SaveCharacteristic.Checked Then
                        TrueCharacteristicSW.Close()
                        FalseCharacteristicSW.Close()
                    End If
                End If
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- Panel_AxMDisplay Event ---"
    Private Sub Panel_AxMDisplay_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseClick
        If Not CheckBox_ShowAllDefects.Checked Then Exit Sub
        If ListView_Defects.Items.Count = 0 Then Exit Sub
        Dim image As MIL_ID = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)

        Try
            If image <> MIL.M_NULL Then
                Dim i As Integer
                Dim r As Integer
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double
                Dim MouseX As Integer
                Dim MouseY As Integer

                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

                'ZoomX = MIL.MdispInquire(Me.AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                r = Me.m_Size * ZoomX

                If ZoomX > 0 Then
                    MouseX = Math.Floor((e.X) / ZoomX)
                    MouseX += Me.m_HScrollBar.Value
                    MouseY = Math.Floor((e.Y) / ZoomX)
                    MouseY += Me.m_VScrollBar.Value

                    If MouseX < SizeX AndAlso MouseY < SizeY AndAlso MouseX > 0 AndAlso MouseY > 0 Then

                        For i = 0 To Me.m_Total_Defect_Count - 1
                            If Not ListView_Defects.Items(i) Is Nothing Then
                                If (MouseX >= CInt(ListView_Defects.Items(i).SubItems(1).Text - r) AndAlso MouseX < CInt(ListView_Defects.Items(i).SubItems(1).Text) + r) AndAlso (MouseY >= CInt(ListView_Defects.Items(i).SubItems(2).Text - r) AndAlso MouseY < CInt(ListView_Defects.Items(i).SubItems(2).Text) + r) Then
                                    ListView_Defects.Items(i).Selected = True
                                    ListView_Defects.Items(i).Focused = True
                                    ListView_Defects.Items(i).EnsureVisible()
                                Else
                                    ListView_Defects.Items(i).Selected = False
                                    ListView_Defects.Items(i).Focused = False
                                End If
                            End If
                        Next
                    End If
                End If
            End If
        Catch ex As Exception
            Throw New Exception("[Dialog_FuncTestImageProcess.Panel_AxMDisplay_MouseClick]Panel_AxMDisplay_MouseClick Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#Region "--- RadioButton Event ---"

#Region "--- RadioButton_AddData_To_Log_All_Click ---"
    Private Sub RadioButton_AddData_To_Log_All_Click(sender As System.Object, e As System.EventArgs) Handles RadioButton_AddData_To_Log_All.Click
        If Me.RadioButton_AddData_To_Log_All.Checked Then
            Me.TextBox_AddData_To_Log_FileName.Enabled = True
        End If
    End Sub
#End Region

#Region "--- RadioButton_AddData_To_Log_Single_Click ---"
    Private Sub RadioButton_AddData_To_Log_Single_Click(sender As System.Object, e As System.EventArgs) Handles RadioButton_AddData_To_Log_Single.Click
        If Me.RadioButton_AddData_To_Log_Single.Checked Then
            Me.TextBox_AddData_To_Log_FileName.Enabled = False
        End If
    End Sub
#End Region

#End Region

#Region "--- UI Event ---"

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_MouseCaptureChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If Me.Focused Then
            If CheckBox_DrawDefect.Checked Then Me.DrawMark()
            If CheckBox_ShowAllDefects.Checked Then Me.DrawAll_PointDefects()
        End If
    End Sub
    Private Sub HScrollBar_MouseCaptureChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If Me.Focused Then
            If CheckBox_DrawDefect.Checked Then Me.DrawMark()
            If CheckBox_ShowAllDefects.Checked Then Me.DrawAll_PointDefects()
        End If
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_DrawDefect.Checked Then Me.DrawMark()
            If CheckBox_ShowAllDefects.Checked Then Me.DrawAll_PointDefects()
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_DrawDefect.Checked Then Me.DrawMark()
            If CheckBox_ShowAllDefects.Checked Then Me.DrawAll_PointDefects()
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_DrawDefect.Checked Then Me.DrawMark()
            If CheckBox_ShowAllDefects.Checked Then Me.DrawAll_PointDefects()
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_DrawDefect.Checked Then Me.DrawMark()
            If CheckBox_ShowAllDefects.Checked Then Me.DrawAll_PointDefects()
        End If
    End Sub
#End Region

#Region "--- ContextMenuStrip Event ---"
    Private Sub ZoomContextMenuStrip_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)
        If Me.Focused Then
            If e.ClickedItem Is Me.m_Form.ZoomInToolStripMenuItem Then
                Me.m_Form.MoveToCenter = True
                Me.m_Button_ZoomIn.PerformClick()
            ElseIf e.ClickedItem Is Me.m_Form.ZoomOutToolStripMenuItem Then
                Me.m_Form.MoveToCenter = True
                Me.m_Button_ZoomOut.PerformClick()
            ElseIf e.ClickedItem Is Me.m_Form.OriginToolStripMenuItem Then
                Me.m_Button_ZoomO.PerformClick()
            ElseIf e.ClickedItem Is Me.m_Form.ZoomAllToolStripMenuItem Then
                Me.m_Button_ZoomAll.PerformClick()
            End If

            If CheckBox_DrawDefect.Checked Then Me.DrawMark()
            If CheckBox_ShowAllDefects.Checked Then Me.DrawAll_PointDefects()
        End If
    End Sub
#End Region

    Private Sub Dialog_FuncTestImageProcess_KeyUp(sender As System.Object, e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp
        If e.Control AndAlso e.KeyCode = Keys.U Then
            Me.gbReadInlineInfo.Visible = Not Me.gbReadInlineInfo.Visible
            Me.RichTextBox_FuncInfo.Text = ""

        End If

    End Sub

#End Region



    Private Function GetUNCPath(ByVal sFilePath As String) As String

        Dim allDrives() As DriveInfo = DriveInfo.GetDrives()
        Dim d As DriveInfo
        Dim DriveType, Ctr As Integer
        Dim DriveLtr, UNCName As String
        Dim StrBldr As New StringBuilder

        If sFilePath.StartsWith("\\") Then Return sFilePath

        UNCName = Space(160)
        GetUNCPath = ""

        DriveLtr = sFilePath.Substring(0, 3)

        For Each d In allDrives
            If d.Name = DriveLtr Then
                DriveType = d.DriveType
                Exit For
            End If
        Next

        If DriveType = 4 Then

            Ctr = WNetGetConnection(sFilePath.Substring(0, 2), UNCName, UNCName.Length)

            If Ctr = 0 Then
                UNCName = UNCName.Trim
                For Ctr = 0 To UNCName.Length - 1
                    Dim SingleChar As Char = UNCName(Ctr)
                    Dim asciiValue As Integer = Asc(SingleChar)
                    If asciiValue > 0 Then
                        StrBldr.Append(SingleChar)
                    Else
                        Exit For
                    End If
                Next
                StrBldr.Append(sFilePath.Substring(2))
                GetUNCPath = StrBldr.ToString
            Else
                MsgBox("Cannot Retrieve UNC path" & vbCrLf & "Must Use Mapped Drive of SQLServer", MsgBoxStyle.Critical)
            End If
        Else
            GetUNCPath = sFilePath
        End If

    End Function

    Declare Function WNetGetConnection Lib "mpr.dll" Alias "WNetGetConnectionA" (ByVal lpszLocalName As String, _
      ByVal lpszRemoteName As String, ByRef cbRemoteName As Integer) As Integer

    Private Sub Button_SaveImgForAI_Path_Click(sender As System.Object, e As System.EventArgs) Handles Button_SaveImgForAI_Path.Click
        Me.FolderBrowserDialog_SaveImgPath.ShowDialog()
        Me.TextBox_SaveImgForAIPath.Text = Me.FolderBrowserDialog_SaveImgPath.SelectedPath
    End Sub

    Private Sub Button_ReadFuncInfo_Click(sender As System.Object, e As System.EventArgs) Handles Button_ReadFuncInfo.Click

        Dim i As Integer
        Dim j As Integer
        Dim ParticleDefectString As String = ""
        Dim strs1 As String()
        Dim strs2 As String()
        Dim Defect_Count As Integer = 0
        Dim GrabNo As String = ""
        Dim strType As String
        Dim p As Position

        Me.CheckPattern()
        Me.ClearResult()

        Me.m_FuncProcess.DefectArray.Clear()
        Me.m_FuncProcess.Func_DefectArray.Clear()

        ParticleDefectString = Me.RichTextBox_FuncInfo.Text
        strs1 = ParticleDefectString.Split(";")
        If strs1.Length < 4 Then
            MessageBox.Show("strs1.Length < 4")
            Exit Sub
        End If

        Defect_Count = CInt(strs1(4))

        If (Defect_Count > 0) Then

            If CInt(strs1(4)) > CInt(strs1(5)) Then Defect_Count = CInt(strs1(5)) Else Defect_Count = CInt(strs1(4))
            If strs1(strs1.Length - 1) = "" Then
                If Defect_Count + 4 <> strs1.Length - 1 Then Defect_Count = strs1.Length - 1 - 6
            Else
                If Defect_Count + 4 <> strs1.Length Then Defect_Count = strs1.Length - 6
            End If

            ReDim Me.m_DefectFileName(Defect_Count - 1)
            ReDim Me.m_DefectFilePath(Defect_Count - 1)

            If Me.m_FuncProcess.Func_DefectArray.Count > 0 Then Me.m_FuncProcess.Func_DefectArray.Clear()
            GrabNo = Me.m_IPBootConfig.GrabNo.Value
            For i = 6 To 6 + Defect_Count - 1
                '(1)m_BlobX, (2)m_BlobY, (3)m_BlobArea, (4)m_Data, (5)m_Gate, (6)m_Type, (7)m_Pattern, (8)m_GrayMean, (9)FileName (10)NetDiskPath (11)MinGray (12)MaxGray (13)Elongation (14)Fullness (15)MaxGray_Fullness(16)Standard_Deviation			
                strs2 = strs1(i).Split(",") '(1)m_BlobX, (2)m_BlobY, (3)m_BlobArea, (4)m_Data, (5)m_Gate, (6)m_Type, (7)m_Pattern, (8)m_GrayMean, (9)FileName, (10)NetDiskPath, (11)GrayMin, (12)GrayMax, (13)Elongation, (14)Fullness, (15)Compactness, (16)MinFeretAngle, (17)MaxGray_Fullness, (18)StdDev, (19)DataMin, (20)GateMin, (21)DataMax, (22)GateMax, (23)Fatness  

                If m_IPBootConfig.DetailOutput.Value Then
                    p = New Position(strs2(1), strs2(2), strs2(3), strs2(4), strs2(5), strs2(6), strs2(7), GrabNo, strs2(8), strs2(9), strs2(10), strs2(11), strs2(12), strs2(13), strs2(14), strs2(15), strs2(16), strs2(17), strs2(18), strs2(23))
                Else
                    p = New Position(strs2(1), strs2(2), strs2(3), strs2(4), strs2(5), strs2(6), strs2(7), GrabNo, strs2(8), strs2(9), strs2(10), strs2(11), strs2(12), strs2(13), strs2(14), 0, 0, strs2(15), strs2(16), 0)
                End If
                ' Me.m_DefectFileName(i - 6) = p.FileName
                ' Me.m_DefectFilePath(i - 6) = p.NetDiskPath
                Me.m_FuncProcess.Func_DefectArray.Add(p)
            Next
        End If

        '--- ��ܵ��G ---
        Label_Defects_X.Text = "Offset X�G" & Me.m_MainProcess.DOffsetX
        Label_Defects_Y.Text = "Offset Y�G" & Me.m_MainProcess.DOffsetY
        Label_Defects_Count.Text = "Count�G" & Me.m_FuncProcess.Func_DefectArray.Count
        Me.m_Total_Defect_Count = 0

        If Me.m_FuncProcess.Func_DefectArray.Count > 0 Then
            j = -1
            For i = 0 To Me.m_FuncProcess.Func_DefectArray.Count - 1
                p = Me.m_FuncProcess.Func_DefectArray.GetPosition(i)

                If Me.CheckBox_NoShowMinusOne.Checked Then

                    If Not p.Data = -1 Or Not p.Gate = -1 Then
                        j = j + 1
                        strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                        ListView_Defects.Items.Add(i)
                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobX))
                        ListView_Defects.Items(j).SubItems.Add(CInt(p.BlobY))
                        ListView_Defects.Items(j).SubItems.Add(p.BlobArea)
                        ListView_Defects.Items(j).SubItems.Add(p.Data)
                        ListView_Defects.Items(j).SubItems.Add(p.Gate)
                        ListView_Defects.Items(j).SubItems.Add(strType)
                        ListView_Defects.Items(j).SubItems.Add(p.Pattern)
                        ListView_Defects.Items(j).SubItems.Add(p.GrayMean)
                        ListView_Defects.Items(j).SubItems.Add(p.GrayMin)
                        ListView_Defects.Items(j).SubItems.Add(p.GrayMax)
                        ListView_Defects.Items(j).SubItems.Add(p.Elongation)
                        ListView_Defects.Items(j).SubItems.Add(p.Fullness)
                        ListView_Defects.Items(j).SubItems.Add(p.Compactness)
                        ListView_Defects.Items(j).SubItems.Add(p.MinFeretAngle)
                        ListView_Defects.Items(j).SubItems.Add(p.MaxGray_Fullness)
                        ListView_Defects.Items(j).SubItems.Add(p.StdDev)
                        ListView_Defects.Items(j).SubItems.Add(p.Fatness)
                        Me.m_Total_Defect_Count += 1
                    End If
                Else
                    strType = [Enum].GetName(GetType(PointTypeDefine), p.Type)
                    ListView_Defects.Items.Add(i)
                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobX))
                    ListView_Defects.Items(i).SubItems.Add(CInt(p.BlobY))
                    ListView_Defects.Items(i).SubItems.Add(p.BlobArea)
                    ListView_Defects.Items(i).SubItems.Add(p.Data)
                    ListView_Defects.Items(i).SubItems.Add(p.Gate)
                    ListView_Defects.Items(i).SubItems.Add(strType)
                    ListView_Defects.Items(i).SubItems.Add(p.Pattern)
                    ListView_Defects.Items(i).SubItems.Add(p.GrayMean)
                    ListView_Defects.Items(i).SubItems.Add(p.GrayMin)
                    ListView_Defects.Items(i).SubItems.Add(p.GrayMax)
                    ListView_Defects.Items(i).SubItems.Add(p.Elongation)
                    ListView_Defects.Items(i).SubItems.Add(p.Fullness)
                    ListView_Defects.Items(i).SubItems.Add(p.Compactness)
                    ListView_Defects.Items(i).SubItems.Add(p.MinFeretAngle)
                    ListView_Defects.Items(i).SubItems.Add(p.MaxGray_Fullness)
                    ListView_Defects.Items(i).SubItems.Add(p.StdDev)
                    ListView_Defects.Items(i).SubItems.Add(p.Fatness)
                    Me.m_Total_Defect_Count += 1
                End If
            Next
        Else
            'MsgBox("�ˬd���G�LDefect�C")
        End If

    End Sub
End Class