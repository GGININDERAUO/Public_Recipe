Imports System.Windows.Forms
Imports System.IO
Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.Threading
Imports System.Globalization

<CLSCompliant(False)> _
Public Class Dialog_FuncResult
    Private m_Form As Main_Form
    Private m_FuncProcess As ClsFuncProcess
    Private m_MainProcess As ClsMainProcess
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_Size As Integer
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

    Private res As System.Resources.ResourceManager '

    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_FuncResult", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------
        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_FuncProcess = form.MainProcess.FuncProcess

        If Not Me.m_MainProcess.CheckIP() Then
            Me.m_MainProcess.IsIPConnected = False
            'MessageBox.Show("Can't connect to IP-" & Me.m_MainProcess.CCDNo & "�APLZ restart IP !", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            Me.m_MainProcess.IsIPConnected = True
        End If

        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_Pen = New Pen(Color.White)
        Me.m_SolidBrush = New SolidBrush(Color.White)
        Me.m_Size = 15

        image = Me.m_FuncProcess.Img_Original_NonPage
        If image <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0

        Me.m_Form.ImageUpdate()
    End Sub

#Region "--- Dialog Event ---"

    Private Sub Dialog_Result_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Integer
        Dim j As Integer = 0
        Dim k As Integer = 0
        Dim p As New Position

        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Label_PanelID.Text = "PanelID�G " & Me.m_MainProcess.ChipId
        Label_OffsetX.Text = "ROI_OffsetX: " & Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        Label_OffsetY.Text = "ROI_OffsetY: " & Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        If Me.m_FuncProcess.DefectArray.Count <> 0 Then
            i = Me.m_FuncProcess.DefectArray.Count
            For i = 0 To Me.m_FuncProcess.DefectArray.Count - 1
                p = Me.m_FuncProcess.DefectArray.GetPosition(i)
                Select Case p.Type
                    Case ClassLibrary.PointTypeDefine.R_BRIGHT_POINT, _
                        ClassLibrary.PointTypeDefine.G_BRIGHT_POINT, _
                        ClassLibrary.PointTypeDefine.B_BRIGHT_POINT, _
                        ClassLibrary.PointTypeDefine.W_BRIGHT_POINT, _
                        ClassLibrary.PointTypeDefine.R_DARK_POINT, _
                        ClassLibrary.PointTypeDefine.G_DARK_POINT, _
                        ClassLibrary.PointTypeDefine.B_DARK_POINT, _
                        ClassLibrary.PointTypeDefine.W_DARK_POINT, _
                        ClassLibrary.PointTypeDefine.OTHER_GLASS_DEFECT
                        ListView_BlobDefects.Items.Add(j)
                        ListView_BlobDefects.Items(j).SubItems.Add(CInt(p.BlobX))
                        ListView_BlobDefects.Items(j).SubItems.Add(CInt(p.BlobY))
                        ListView_BlobDefects.Items(j).SubItems.Add(p.BlobArea)
                        ListView_BlobDefects.Items(j).SubItems.Add(p.Data)
                        ListView_BlobDefects.Items(j).SubItems.Add(p.Gate)
                        ListView_BlobDefects.Items(j).SubItems.Add(p.Type)
                        ListView_BlobDefects.Items(j).SubItems.Add(p.Pattern)
                        j = j + 1
                    Case Else
                        ListView_BandDefects.Items.Add(k)
                        ListView_BandDefects.Items(k).SubItems.Add(CInt(p.BlobX))
                        ListView_BandDefects.Items(k).SubItems.Add(CInt(p.BlobY))
                        ListView_BandDefects.Items(k).SubItems.Add(p.BlobArea)
                        ListView_BandDefects.Items(k).SubItems.Add(p.Data)
                        ListView_BandDefects.Items(k).SubItems.Add(p.Gate)
                        ListView_BandDefects.Items(k).SubItems.Add(p.Type)
                        ListView_BandDefects.Items(k).SubItems.Add(p.Pattern)
                        k = k + 1
                End Select
            Next
        Else
            MsgBox("���o�{Defects")
        End If

        Me.Update()
    End Sub

    Private Sub Dialog_FuncResult_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
#End Region

#Region "--- ListView ---"

    Private Sub ListView_BlobDefects_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_BlobDefects.DoubleClick
        Dim i As Integer
        Dim picsize As Integer
        Dim offset_X, offset_Y As Integer
        Dim p As New Position
        Dim ZoomX As Double

        'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
        Me.m_Form.SetStatusBarPanel_Scale("�Y�� = " & ZoomX)
        Me.m_Form.SetButton_ZoomIn(True)
        Me.m_Form.SetButton_ZoomOut(True)
        Me.m_Form.ResetScrollBar()

        i = ListView_BlobDefects.SelectedIndices(0)
        p.BlobX = CInt(ListView_BlobDefects.Items(i).SubItems(1).Text)
        p.BlobY = CInt(ListView_BlobDefects.Items(i).SubItems(2).Text)
        p.BlobArea = CInt(ListView_BlobDefects.Items(i).SubItems(3).Text)
        p.Type = ListView_BlobDefects.Items(i).SubItems(6).Text

        Select Case p.Type
            'Case ClassLibrary.PointTypeDefine.BRIGHT_POINT, ClassLibrary.PointTypeDefine.DARK_POINT, ClassLibrary.PointTypeDefine.DARK_BRIGHT_POINT
            Case ClassLibrary.PointTypeDefine.R_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.G_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.B_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.W_BRIGHT_POINT, _
                ClassLibrary.PointTypeDefine.R_DARK_POINT, _
                ClassLibrary.PointTypeDefine.G_DARK_POINT, _
                ClassLibrary.PointTypeDefine.B_DARK_POINT, _
                ClassLibrary.PointTypeDefine.W_DARK_POINT

                picsize = Math.Max(CInt(((p.BlobArea) ^ 0.5) * 2), 100)
                Select Case Me.m_Form.ComboBox_Type.SelectedIndex

                    Case 0
                        offset_X = Math.Max(CInt(p.BlobX) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(p.BlobY) - CInt(picsize / 2), 0)
                    Case 1
                        offset_X = Math.Max(CInt(p.BlobX - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(p.BlobY - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - CInt(picsize / 2), 0)
                End Select

        End Select
        offset_X = Math.Min(offset_X, Me.m_Form.HScrollBar.Maximum)
        offset_Y = Math.Min(offset_Y, Me.m_Form.VScrollBar.Maximum)
        Me.m_Form.HScrollBar.Value = offset_X
        Me.m_Form.VScrollBar.Value = offset_Y
        Me.m_Form.ResetScrollBar()
        Me.DrawMark()

    End Sub

    Private Sub ListView_BandDefects_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListView_BandDefects.DoubleClick
        Dim i As Integer
        Dim offset_X, offset_Y As Integer
        Dim p As New Position
        Dim ZoomX As Double

        'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
        Me.m_Form.SetStatusBarPanel_Scale("�Y�� = " & ZoomX)
        Me.m_Form.SetButton_ZoomIn(True)
        Me.m_Form.SetButton_ZoomOut(True)
        Me.m_Form.ResetScrollBar()

        i = ListView_BandDefects.SelectedIndices(0)
        p.BlobX = CInt(ListView_BandDefects.Items(i).SubItems(1).Text)
        p.BlobY = CInt(ListView_BandDefects.Items(i).SubItems(2).Text)
        p.BlobArea = CInt(ListView_BandDefects.Items(i).SubItems(3).Text)
        p.Type = ListView_BandDefects.Items(i).SubItems(6).Text
        p.Pattern = ListView_BandDefects.Items(i).SubItems(7).Text

        Select Case p.Type
            Case ClassLibrary.PointTypeDefine.BRIGHT_HLINE, ClassLibrary.PointTypeDefine.BRIGHT_VLINE, ClassLibrary.PointTypeDefine.DARK_HLINE, ClassLibrary.PointTypeDefine.DARK_VLINE _
                  , ClassLibrary.PointTypeDefine.HBITLINE, ClassLibrary.PointTypeDefine.HBLOCK, ClassLibrary.PointTypeDefine.VBITLINE, ClassLibrary.PointTypeDefine.VBLOCK _
                  , ClassLibrary.PointTypeDefine.VBLOCK
                Select Case Me.m_Form.ComboBox_Type.SelectedIndex

                    Case 0
                        If p.BlobX = -1 Then
                            offset_X = 50
                            offset_Y = Math.Max(CInt(p.BlobY) - 50, 0)
                        End If
                        If p.BlobY = -1 Then
                            offset_X = Math.Max(CInt(p.BlobX) - 50, 0)
                            offset_Y = 50
                        End If
                    Case 1
                        If p.BlobX = -1 Then
                            offset_X = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                            offset_Y = Math.Max(CInt(p.BlobY - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - 50, 0)
                        End If
                        If p.BlobY = -1 Then
                            offset_X = Math.Max(CInt(p.BlobX - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - 50, 0)
                            offset_Y = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                        End If
                End Select

        End Select
        offset_X = Math.Min(offset_X, Me.m_Form.HScrollBar.Maximum)
        offset_Y = Math.Min(offset_Y, Me.m_Form.VScrollBar.Maximum)
        Me.m_Form.HScrollBar.Value = offset_X
        Me.m_Form.VScrollBar.Value = offset_Y

        Me.DrawMark()
    End Sub

#End Region

#Region "--- Darw Event ---"

    Private Sub m_Panel_AxMDisplay_PaintEvent(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark()
        End If
    End Sub

    Private Sub DrawMark()
        Dim image As MIL_ID = M_NULL
        Dim offX As Integer
        Dim offY As Integer
        Dim i As Integer
        Dim lvi_blobx As Integer
        Dim lvi_bloby As Integer
        Dim lvi_bandx As Integer
        Dim lvi_bandy As Integer

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If

        '--- Initial ---
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        '--- Initial ---

        For i = 0 To Me.ListView_BlobDefects.SelectedItems.Count - 1
            lvi_blobx = CInt(Me.ListView_BlobDefects.SelectedItems.Item(i).SubItems(1).Text)
            lvi_bloby = CInt(Me.ListView_BlobDefects.SelectedItems.Item(i).SubItems(2).Text)
        Next
        For i = 0 To Me.ListView_BandDefects.SelectedItems.Count - 1
            lvi_bandx = CInt(Me.ListView_BandDefects.SelectedItems.Item(i).SubItems(1).Text)
            lvi_bandy = CInt(Me.ListView_BandDefects.SelectedItems.Item(i).SubItems(2).Text)
        Next
        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    'Me.DrawBlobDefect(offX, offY)
                    Me.DrawBlobDefect(0, 0)
                    If lvi_bandx = -1 And lvi_bandy <> 0 Then
                        Me.DrawHBandDefect(0, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX)
                    End If
                    If lvi_bandx <> 0 And lvi_bandy = -1 Then
                        Me.DrawVBandDefect(0, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY)
                    End If
                End If
            Case 1
                Me.DrawBlobDefect(-offX, -offY)
                If lvi_bandx = -1 And lvi_bandy <> 0 Then
                    Me.DrawHBandDefect(-offY, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX)
                End If
                If lvi_bandx <> 0 And lvi_bandy = -1 Then
                    Me.DrawVBandDefect(-offX, 0, Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY)
                End If
        End Select
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_Form.PaintStop = False
    End Sub

    Private Sub DrawBlobDefect(ByVal offX As Integer, ByVal offY As Integer)
        Dim Image As MIL_ID = M_NULL
        Dim i As Integer
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem

        Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        bx = MbufInquire(Image, M_SIZE_X, M_NULL)
        by = MbufInquire(Image, M_SIZE_Y, M_NULL)
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        's = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red
        For i = 0 To Me.ListView_BlobDefects.SelectedItems.Count - 1
            lvi = Me.ListView_BlobDefects.SelectedItems.Item(i)
            x = CInt(lvi.SubItems(1).Text)
            y = CInt(lvi.SubItems(2).Text)
            x = (x - ox + 0.5) * s - hr   ' -hr , �]���q 0�׶}�l�e��
            y = (y - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Next
    End Sub

    Private Sub DrawHBandDefect(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim i As Integer
        Dim h As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim ZoomX As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem

        rect = New Rectangle
        Me.m_Pen.Color = Color.Red
        ox = Me.m_Form.HScrollBar.Value - s
        oy = Me.m_Form.VScrollBar.Value - offset
        'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
        Me.m_SolidBrush.Color = Color.Red

        For i = 0 To Me.ListView_BandDefects.SelectedItems.Count - 1
            lvi = Me.ListView_BandDefects.SelectedItems.Item(i)
            h = (-ox + 0.5) * ZoomX
            rect.X = h
            h = (lvi.SubItems(2).Text - oy) * ZoomX
            rect.Y = h
            rect.Width = (e - s + 1) * ZoomX
            rect.Height = Math.Ceiling(ZoomX)
            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next
    End Sub

    Private Sub DrawVBandDefect(ByVal offset As Integer, ByVal s As Integer, ByVal e As Integer)
        Dim i As Integer
        Dim v As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim ZoomX As Double
        Dim rect As Rectangle
        Dim lvi As ListViewItem

        rect = New Rectangle
        Me.m_Pen.Color = Color.Green
        ox = Me.m_Form.HScrollBar.Value - offset
        oy = Me.m_Form.VScrollBar.Value - s
        'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
        Me.m_SolidBrush.Color = Color.Red

        For i = 0 To Me.ListView_BandDefects.SelectedItems.Count - 1
            lvi = Me.ListView_BandDefects.SelectedItems.Item(i)
            v = (lvi.SubItems(1).Text - ox) * ZoomX
            rect.X = v
            v = (-oy + 0.5) * ZoomX
            rect.Y = v
            rect.Width = Math.Ceiling(ZoomX)
            rect.Height = (e - s + 1) * ZoomX
            Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
        Next
    End Sub

#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Label1.Text = res.GetString("Label1.Text")
                OK_Button.Text = res.GetString("OK_Button.Text")
        End Select
    End Sub
#End Region

End Class
