<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_FuncTestImageProcess
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_FuncTestImageProcess))
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.GroupBox_ImageSource = New System.Windows.Forms.GroupBox()
        Me.Button_LoadImage = New System.Windows.Forms.Button()
        Me.GroupBox_ImgTest = New System.Windows.Forms.GroupBox()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.ComboBox_Pattern = New System.Windows.Forms.ComboBox()
        Me.Button_Execute = New System.Windows.Forms.Button()
        Me.ComboBox_ImageProcess = New System.Windows.Forms.ComboBox()
        Me.ListView_Defects = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader8 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader9 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader10 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader11 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader12 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader13 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader14 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader15 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader16 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader17 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader18 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label_Defects_X = New System.Windows.Forms.Label()
        Me.Label_Defects_Y = New System.Windows.Forms.Label()
        Me.Label_Defects_Count = New System.Windows.Forms.Label()
        Me.CheckBox_DrawDefect = New System.Windows.Forms.CheckBox()
        Me.CheckBox_NoShowMinusOne = New System.Windows.Forms.CheckBox()
        Me.Label_Msg = New System.Windows.Forms.Label()
        Me.CheckBox_FilterBackParticle = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FilterHotPixel = New System.Windows.Forms.CheckBox()
        Me.CheckBox_FilterFalseDefect = New System.Windows.Forms.CheckBox()
        Me.CheckBox_EnableFalseRule = New System.Windows.Forms.CheckBox()
        Me.Button_AddToLog = New System.Windows.Forms.Button()
        Me.GroupBox_CharacteristicAnalysis = New System.Windows.Forms.GroupBox()
        Me.CheckBox_FilterCharacteristic = New System.Windows.Forms.CheckBox()
        Me.Button_SaveCharacteristicRecipe = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Compactness_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Fullness_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayMax_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayMax_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayMin_Max = New System.Windows.Forms.NumericUpDown()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayMin_Min = New System.Windows.Forms.NumericUpDown()
        Me.DefectLogContextMenuStrip = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddToLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveImgToTrueToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveImgToFalseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveImgToTrueOtherFalseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CheckBox_ShowAllDefects = New System.Windows.Forms.CheckBox()
        Me.GroupBox_GoTo_Point = New System.Windows.Forms.GroupBox()
        Me.Button_x2GoTo_Position = New System.Windows.Forms.Button()
        Me.Button_GoTo_Position = New System.Windows.Forms.Button()
        Me.TextBox_GoTo_BlobY = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox_GoTo_BlobX = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CheckBox_Filter_By_Characteristics = New System.Windows.Forms.CheckBox()
        Me.GroupBox_AddData_To_Log = New System.Windows.Forms.GroupBox()
        Me.TextBox_AddData_To_Log_FileName = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.RadioButton_AddData_To_Log_All = New System.Windows.Forms.RadioButton()
        Me.RadioButton_AddData_To_Log_Single = New System.Windows.Forms.RadioButton()
        Me.CheckBox_SaveDefectImage = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CheckBox_SaveTif = New System.Windows.Forms.CheckBox()
        Me.CheckBox_SaveCharacteristic = New System.Windows.Forms.CheckBox()
        Me.Button_SaveImgForAI_Path = New System.Windows.Forms.Button()
        Me.TextBox_SaveImgForAIPath = New System.Windows.Forms.TextBox()
        Me.SaveImgForAI_Path = New System.Windows.Forms.Label()
        Me.TextBox_PanelID = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog_SaveImgPath = New System.Windows.Forms.FolderBrowserDialog()
        Me.gbReadInlineInfo = New System.Windows.Forms.GroupBox()
        Me.Button_ReadFuncInfo = New System.Windows.Forms.Button()
        Me.RichTextBox_FuncInfo = New System.Windows.Forms.RichTextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TextBox_LaserInfo2 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox_LaserInfo1 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.CheckBox_FilterByImageFilter = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CreateFilterImage = New System.Windows.Forms.CheckBox()
        Me.GroupBox_ImageSource.SuspendLayout()
        Me.GroupBox_ImgTest.SuspendLayout()
        Me.GroupBox_CharacteristicAnalysis.SuspendLayout()
        CType(Me.NumericUpDown_Compactness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Fullness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayMax_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayMax_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayMin_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayMin_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.DefectLogContextMenuStrip.SuspendLayout()
        Me.GroupBox_GoTo_Point.SuspendLayout()
        Me.GroupBox_AddData_To_Log.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.gbReadInlineInfo.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Cancel_Button
        '
        resources.ApplyResources(Me.Cancel_Button, "Cancel_Button")
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Name = "Cancel_Button"
        '
        'GroupBox_ImageSource
        '
        resources.ApplyResources(Me.GroupBox_ImageSource, "GroupBox_ImageSource")
        Me.GroupBox_ImageSource.Controls.Add(Me.Button_LoadImage)
        Me.GroupBox_ImageSource.Name = "GroupBox_ImageSource"
        Me.GroupBox_ImageSource.TabStop = False
        '
        'Button_LoadImage
        '
        resources.ApplyResources(Me.Button_LoadImage, "Button_LoadImage")
        Me.Button_LoadImage.Name = "Button_LoadImage"
        Me.Button_LoadImage.UseVisualStyleBackColor = True
        '
        'GroupBox_ImgTest
        '
        resources.ApplyResources(Me.GroupBox_ImgTest, "GroupBox_ImgTest")
        Me.GroupBox_ImgTest.Controls.Add(Me.Label_Pattern)
        Me.GroupBox_ImgTest.Controls.Add(Me.ComboBox_Pattern)
        Me.GroupBox_ImgTest.Controls.Add(Me.Button_Execute)
        Me.GroupBox_ImgTest.Controls.Add(Me.ComboBox_ImageProcess)
        Me.GroupBox_ImgTest.Name = "GroupBox_ImgTest"
        Me.GroupBox_ImgTest.TabStop = False
        '
        'Label_Pattern
        '
        resources.ApplyResources(Me.Label_Pattern, "Label_Pattern")
        Me.Label_Pattern.Name = "Label_Pattern"
        '
        'ComboBox_Pattern
        '
        resources.ApplyResources(Me.ComboBox_Pattern, "ComboBox_Pattern")
        Me.ComboBox_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Pattern.Name = "ComboBox_Pattern"
        '
        'Button_Execute
        '
        resources.ApplyResources(Me.Button_Execute, "Button_Execute")
        Me.Button_Execute.Name = "Button_Execute"
        Me.Button_Execute.UseVisualStyleBackColor = True
        '
        'ComboBox_ImageProcess
        '
        resources.ApplyResources(Me.ComboBox_ImageProcess, "ComboBox_ImageProcess")
        Me.ComboBox_ImageProcess.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_ImageProcess.FormattingEnabled = True
        Me.ComboBox_ImageProcess.Items.AddRange(New Object() {resources.GetString("ComboBox_ImageProcess.Items"), resources.GetString("ComboBox_ImageProcess.Items1"), resources.GetString("ComboBox_ImageProcess.Items2"), resources.GetString("ComboBox_ImageProcess.Items3"), resources.GetString("ComboBox_ImageProcess.Items4"), resources.GetString("ComboBox_ImageProcess.Items5"), resources.GetString("ComboBox_ImageProcess.Items6"), resources.GetString("ComboBox_ImageProcess.Items7")})
        Me.ComboBox_ImageProcess.Name = "ComboBox_ImageProcess"
        '
        'ListView_Defects
        '
        resources.ApplyResources(Me.ListView_Defects, "ListView_Defects")
        Me.ListView_Defects.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader7, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader8, Me.ColumnHeader9, Me.ColumnHeader10, Me.ColumnHeader11, Me.ColumnHeader12, Me.ColumnHeader13, Me.ColumnHeader14, Me.ColumnHeader15, Me.ColumnHeader16, Me.ColumnHeader17, Me.ColumnHeader18})
        Me.ListView_Defects.FullRowSelect = True
        Me.ListView_Defects.GridLines = True
        Me.ListView_Defects.HideSelection = False
        Me.ListView_Defects.Name = "ListView_Defects"
        Me.ListView_Defects.UseCompatibleStateImageBehavior = False
        Me.ListView_Defects.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        resources.ApplyResources(Me.ColumnHeader1, "ColumnHeader1")
        '
        'ColumnHeader2
        '
        resources.ApplyResources(Me.ColumnHeader2, "ColumnHeader2")
        '
        'ColumnHeader3
        '
        resources.ApplyResources(Me.ColumnHeader3, "ColumnHeader3")
        '
        'ColumnHeader7
        '
        resources.ApplyResources(Me.ColumnHeader7, "ColumnHeader7")
        '
        'ColumnHeader4
        '
        resources.ApplyResources(Me.ColumnHeader4, "ColumnHeader4")
        '
        'ColumnHeader5
        '
        resources.ApplyResources(Me.ColumnHeader5, "ColumnHeader5")
        '
        'ColumnHeader6
        '
        resources.ApplyResources(Me.ColumnHeader6, "ColumnHeader6")
        '
        'ColumnHeader8
        '
        resources.ApplyResources(Me.ColumnHeader8, "ColumnHeader8")
        '
        'ColumnHeader9
        '
        resources.ApplyResources(Me.ColumnHeader9, "ColumnHeader9")
        '
        'ColumnHeader10
        '
        resources.ApplyResources(Me.ColumnHeader10, "ColumnHeader10")
        '
        'ColumnHeader11
        '
        resources.ApplyResources(Me.ColumnHeader11, "ColumnHeader11")
        '
        'ColumnHeader12
        '
        resources.ApplyResources(Me.ColumnHeader12, "ColumnHeader12")
        '
        'ColumnHeader13
        '
        resources.ApplyResources(Me.ColumnHeader13, "ColumnHeader13")
        '
        'ColumnHeader14
        '
        resources.ApplyResources(Me.ColumnHeader14, "ColumnHeader14")
        '
        'ColumnHeader15
        '
        resources.ApplyResources(Me.ColumnHeader15, "ColumnHeader15")
        '
        'ColumnHeader16
        '
        resources.ApplyResources(Me.ColumnHeader16, "ColumnHeader16")
        '
        'ColumnHeader17
        '
        resources.ApplyResources(Me.ColumnHeader17, "ColumnHeader17")
        '
        'ColumnHeader18
        '
        resources.ApplyResources(Me.ColumnHeader18, "ColumnHeader18")
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label_Defects_X
        '
        resources.ApplyResources(Me.Label_Defects_X, "Label_Defects_X")
        Me.Label_Defects_X.Name = "Label_Defects_X"
        '
        'Label_Defects_Y
        '
        resources.ApplyResources(Me.Label_Defects_Y, "Label_Defects_Y")
        Me.Label_Defects_Y.Name = "Label_Defects_Y"
        '
        'Label_Defects_Count
        '
        resources.ApplyResources(Me.Label_Defects_Count, "Label_Defects_Count")
        Me.Label_Defects_Count.Name = "Label_Defects_Count"
        '
        'CheckBox_DrawDefect
        '
        resources.ApplyResources(Me.CheckBox_DrawDefect, "CheckBox_DrawDefect")
        Me.CheckBox_DrawDefect.Checked = True
        Me.CheckBox_DrawDefect.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_DrawDefect.Name = "CheckBox_DrawDefect"
        Me.CheckBox_DrawDefect.UseVisualStyleBackColor = True
        '
        'CheckBox_NoShowMinusOne
        '
        resources.ApplyResources(Me.CheckBox_NoShowMinusOne, "CheckBox_NoShowMinusOne")
        Me.CheckBox_NoShowMinusOne.Name = "CheckBox_NoShowMinusOne"
        Me.CheckBox_NoShowMinusOne.UseVisualStyleBackColor = True
        '
        'Label_Msg
        '
        resources.ApplyResources(Me.Label_Msg, "Label_Msg")
        Me.Label_Msg.Name = "Label_Msg"
        '
        'CheckBox_FilterBackParticle
        '
        resources.ApplyResources(Me.CheckBox_FilterBackParticle, "CheckBox_FilterBackParticle")
        Me.CheckBox_FilterBackParticle.Name = "CheckBox_FilterBackParticle"
        Me.CheckBox_FilterBackParticle.UseVisualStyleBackColor = True
        '
        'CheckBox_FilterHotPixel
        '
        resources.ApplyResources(Me.CheckBox_FilterHotPixel, "CheckBox_FilterHotPixel")
        Me.CheckBox_FilterHotPixel.Name = "CheckBox_FilterHotPixel"
        Me.CheckBox_FilterHotPixel.UseVisualStyleBackColor = True
        '
        'CheckBox_FilterFalseDefect
        '
        resources.ApplyResources(Me.CheckBox_FilterFalseDefect, "CheckBox_FilterFalseDefect")
        Me.CheckBox_FilterFalseDefect.Name = "CheckBox_FilterFalseDefect"
        Me.CheckBox_FilterFalseDefect.UseVisualStyleBackColor = True
        '
        'CheckBox_EnableFalseRule
        '
        resources.ApplyResources(Me.CheckBox_EnableFalseRule, "CheckBox_EnableFalseRule")
        Me.CheckBox_EnableFalseRule.Name = "CheckBox_EnableFalseRule"
        Me.CheckBox_EnableFalseRule.UseVisualStyleBackColor = True
        '
        'Button_AddToLog
        '
        resources.ApplyResources(Me.Button_AddToLog, "Button_AddToLog")
        Me.Button_AddToLog.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_AddToLog.Name = "Button_AddToLog"
        '
        'GroupBox_CharacteristicAnalysis
        '
        resources.ApplyResources(Me.GroupBox_CharacteristicAnalysis, "GroupBox_CharacteristicAnalysis")
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.CheckBox_FilterCharacteristic)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Button_SaveCharacteristicRecipe)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label9)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_Compactness_Max)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label5)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_Fullness_Max)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label6)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_Fullness_Min)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label7)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_Elongation_Max)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label8)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_Elongation_Min)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label2)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_GrayMax_Max)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label4)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_GrayMax_Min)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label1)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_GrayMin_Max)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.Label48)
        Me.GroupBox_CharacteristicAnalysis.Controls.Add(Me.NumericUpDown_GrayMin_Min)
        Me.GroupBox_CharacteristicAnalysis.Name = "GroupBox_CharacteristicAnalysis"
        Me.GroupBox_CharacteristicAnalysis.TabStop = False
        '
        'CheckBox_FilterCharacteristic
        '
        resources.ApplyResources(Me.CheckBox_FilterCharacteristic, "CheckBox_FilterCharacteristic")
        Me.CheckBox_FilterCharacteristic.Name = "CheckBox_FilterCharacteristic"
        Me.CheckBox_FilterCharacteristic.UseVisualStyleBackColor = True
        '
        'Button_SaveCharacteristicRecipe
        '
        resources.ApplyResources(Me.Button_SaveCharacteristicRecipe, "Button_SaveCharacteristicRecipe")
        Me.Button_SaveCharacteristicRecipe.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_SaveCharacteristicRecipe.Name = "Button_SaveCharacteristicRecipe"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'NumericUpDown_Compactness_Max
        '
        resources.ApplyResources(Me.NumericUpDown_Compactness_Max, "NumericUpDown_Compactness_Max")
        Me.NumericUpDown_Compactness_Max.DecimalPlaces = 2
        Me.NumericUpDown_Compactness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_Compactness_Max.Name = "NumericUpDown_Compactness_Max"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'NumericUpDown_Fullness_Max
        '
        resources.ApplyResources(Me.NumericUpDown_Fullness_Max, "NumericUpDown_Fullness_Max")
        Me.NumericUpDown_Fullness_Max.DecimalPlaces = 2
        Me.NumericUpDown_Fullness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_Fullness_Max.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Fullness_Max.Name = "NumericUpDown_Fullness_Max"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'NumericUpDown_Fullness_Min
        '
        resources.ApplyResources(Me.NumericUpDown_Fullness_Min, "NumericUpDown_Fullness_Min")
        Me.NumericUpDown_Fullness_Min.DecimalPlaces = 2
        Me.NumericUpDown_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_Fullness_Min.Maximum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Fullness_Min.Name = "NumericUpDown_Fullness_Min"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'NumericUpDown_Elongation_Max
        '
        resources.ApplyResources(Me.NumericUpDown_Elongation_Max, "NumericUpDown_Elongation_Max")
        Me.NumericUpDown_Elongation_Max.DecimalPlaces = 2
        Me.NumericUpDown_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_Elongation_Max.Name = "NumericUpDown_Elongation_Max"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'NumericUpDown_Elongation_Min
        '
        resources.ApplyResources(Me.NumericUpDown_Elongation_Min, "NumericUpDown_Elongation_Min")
        Me.NumericUpDown_Elongation_Min.DecimalPlaces = 2
        Me.NumericUpDown_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_Elongation_Min.Name = "NumericUpDown_Elongation_Min"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'NumericUpDown_GrayMax_Max
        '
        resources.ApplyResources(Me.NumericUpDown_GrayMax_Max, "NumericUpDown_GrayMax_Max")
        Me.NumericUpDown_GrayMax_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_GrayMax_Max.Name = "NumericUpDown_GrayMax_Max"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'NumericUpDown_GrayMax_Min
        '
        resources.ApplyResources(Me.NumericUpDown_GrayMax_Min, "NumericUpDown_GrayMax_Min")
        Me.NumericUpDown_GrayMax_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_GrayMax_Min.Name = "NumericUpDown_GrayMax_Min"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'NumericUpDown_GrayMin_Max
        '
        resources.ApplyResources(Me.NumericUpDown_GrayMin_Max, "NumericUpDown_GrayMin_Max")
        Me.NumericUpDown_GrayMin_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_GrayMin_Max.Name = "NumericUpDown_GrayMin_Max"
        '
        'Label48
        '
        resources.ApplyResources(Me.Label48, "Label48")
        Me.Label48.Name = "Label48"
        '
        'NumericUpDown_GrayMin_Min
        '
        resources.ApplyResources(Me.NumericUpDown_GrayMin_Min, "NumericUpDown_GrayMin_Min")
        Me.NumericUpDown_GrayMin_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_GrayMin_Min.Name = "NumericUpDown_GrayMin_Min"
        '
        'DefectLogContextMenuStrip
        '
        resources.ApplyResources(Me.DefectLogContextMenuStrip, "DefectLogContextMenuStrip")
        Me.DefectLogContextMenuStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToLogToolStripMenuItem, Me.SaveImgToTrueToolStripMenuItem, Me.SaveImgToFalseToolStripMenuItem, Me.SaveImgToTrueOtherFalseToolStripMenuItem})
        Me.DefectLogContextMenuStrip.Name = "ContextMenuStrip1"
        '
        'AddToLogToolStripMenuItem
        '
        resources.ApplyResources(Me.AddToLogToolStripMenuItem, "AddToLogToolStripMenuItem")
        Me.AddToLogToolStripMenuItem.Name = "AddToLogToolStripMenuItem"
        '
        'SaveImgToTrueToolStripMenuItem
        '
        resources.ApplyResources(Me.SaveImgToTrueToolStripMenuItem, "SaveImgToTrueToolStripMenuItem")
        Me.SaveImgToTrueToolStripMenuItem.Name = "SaveImgToTrueToolStripMenuItem"
        '
        'SaveImgToFalseToolStripMenuItem
        '
        resources.ApplyResources(Me.SaveImgToFalseToolStripMenuItem, "SaveImgToFalseToolStripMenuItem")
        Me.SaveImgToFalseToolStripMenuItem.Name = "SaveImgToFalseToolStripMenuItem"
        '
        'SaveImgToTrueOtherFalseToolStripMenuItem
        '
        resources.ApplyResources(Me.SaveImgToTrueOtherFalseToolStripMenuItem, "SaveImgToTrueOtherFalseToolStripMenuItem")
        Me.SaveImgToTrueOtherFalseToolStripMenuItem.Name = "SaveImgToTrueOtherFalseToolStripMenuItem"
        '
        'CheckBox_ShowAllDefects
        '
        resources.ApplyResources(Me.CheckBox_ShowAllDefects, "CheckBox_ShowAllDefects")
        Me.CheckBox_ShowAllDefects.Name = "CheckBox_ShowAllDefects"
        Me.CheckBox_ShowAllDefects.UseVisualStyleBackColor = True
        '
        'GroupBox_GoTo_Point
        '
        resources.ApplyResources(Me.GroupBox_GoTo_Point, "GroupBox_GoTo_Point")
        Me.GroupBox_GoTo_Point.Controls.Add(Me.Button_x2GoTo_Position)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.Button_GoTo_Position)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.TextBox_GoTo_BlobY)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.Label11)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.TextBox_GoTo_BlobX)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.Label10)
        Me.GroupBox_GoTo_Point.Name = "GroupBox_GoTo_Point"
        Me.GroupBox_GoTo_Point.TabStop = False
        '
        'Button_x2GoTo_Position
        '
        resources.ApplyResources(Me.Button_x2GoTo_Position, "Button_x2GoTo_Position")
        Me.Button_x2GoTo_Position.Name = "Button_x2GoTo_Position"
        Me.Button_x2GoTo_Position.UseVisualStyleBackColor = True
        '
        'Button_GoTo_Position
        '
        resources.ApplyResources(Me.Button_GoTo_Position, "Button_GoTo_Position")
        Me.Button_GoTo_Position.Name = "Button_GoTo_Position"
        Me.Button_GoTo_Position.UseVisualStyleBackColor = True
        '
        'TextBox_GoTo_BlobY
        '
        resources.ApplyResources(Me.TextBox_GoTo_BlobY, "TextBox_GoTo_BlobY")
        Me.TextBox_GoTo_BlobY.Name = "TextBox_GoTo_BlobY"
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'TextBox_GoTo_BlobX
        '
        resources.ApplyResources(Me.TextBox_GoTo_BlobX, "TextBox_GoTo_BlobX")
        Me.TextBox_GoTo_BlobX.Name = "TextBox_GoTo_BlobX"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'CheckBox_Filter_By_Characteristics
        '
        resources.ApplyResources(Me.CheckBox_Filter_By_Characteristics, "CheckBox_Filter_By_Characteristics")
        Me.CheckBox_Filter_By_Characteristics.Name = "CheckBox_Filter_By_Characteristics"
        Me.CheckBox_Filter_By_Characteristics.UseVisualStyleBackColor = True
        '
        'GroupBox_AddData_To_Log
        '
        resources.ApplyResources(Me.GroupBox_AddData_To_Log, "GroupBox_AddData_To_Log")
        Me.GroupBox_AddData_To_Log.Controls.Add(Me.TextBox_AddData_To_Log_FileName)
        Me.GroupBox_AddData_To_Log.Controls.Add(Me.Label12)
        Me.GroupBox_AddData_To_Log.Controls.Add(Me.RadioButton_AddData_To_Log_All)
        Me.GroupBox_AddData_To_Log.Controls.Add(Me.RadioButton_AddData_To_Log_Single)
        Me.GroupBox_AddData_To_Log.Controls.Add(Me.Button_AddToLog)
        Me.GroupBox_AddData_To_Log.Name = "GroupBox_AddData_To_Log"
        Me.GroupBox_AddData_To_Log.TabStop = False
        '
        'TextBox_AddData_To_Log_FileName
        '
        resources.ApplyResources(Me.TextBox_AddData_To_Log_FileName, "TextBox_AddData_To_Log_FileName")
        Me.TextBox_AddData_To_Log_FileName.Name = "TextBox_AddData_To_Log_FileName"
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'RadioButton_AddData_To_Log_All
        '
        resources.ApplyResources(Me.RadioButton_AddData_To_Log_All, "RadioButton_AddData_To_Log_All")
        Me.RadioButton_AddData_To_Log_All.Name = "RadioButton_AddData_To_Log_All"
        Me.RadioButton_AddData_To_Log_All.UseVisualStyleBackColor = True
        '
        'RadioButton_AddData_To_Log_Single
        '
        resources.ApplyResources(Me.RadioButton_AddData_To_Log_Single, "RadioButton_AddData_To_Log_Single")
        Me.RadioButton_AddData_To_Log_Single.Checked = True
        Me.RadioButton_AddData_To_Log_Single.Name = "RadioButton_AddData_To_Log_Single"
        Me.RadioButton_AddData_To_Log_Single.TabStop = True
        Me.RadioButton_AddData_To_Log_Single.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveDefectImage
        '
        resources.ApplyResources(Me.CheckBox_SaveDefectImage, "CheckBox_SaveDefectImage")
        Me.CheckBox_SaveDefectImage.Name = "CheckBox_SaveDefectImage"
        Me.CheckBox_SaveDefectImage.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.CheckBox_SaveTif)
        Me.GroupBox1.Controls.Add(Me.CheckBox_SaveCharacteristic)
        Me.GroupBox1.Controls.Add(Me.Button_SaveImgForAI_Path)
        Me.GroupBox1.Controls.Add(Me.TextBox_SaveImgForAIPath)
        Me.GroupBox1.Controls.Add(Me.SaveImgForAI_Path)
        Me.GroupBox1.Controls.Add(Me.TextBox_PanelID)
        Me.GroupBox1.Controls.Add(Me.Label13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'CheckBox_SaveTif
        '
        resources.ApplyResources(Me.CheckBox_SaveTif, "CheckBox_SaveTif")
        Me.CheckBox_SaveTif.Name = "CheckBox_SaveTif"
        Me.CheckBox_SaveTif.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveCharacteristic
        '
        resources.ApplyResources(Me.CheckBox_SaveCharacteristic, "CheckBox_SaveCharacteristic")
        Me.CheckBox_SaveCharacteristic.Name = "CheckBox_SaveCharacteristic"
        Me.CheckBox_SaveCharacteristic.UseVisualStyleBackColor = True
        '
        'Button_SaveImgForAI_Path
        '
        resources.ApplyResources(Me.Button_SaveImgForAI_Path, "Button_SaveImgForAI_Path")
        Me.Button_SaveImgForAI_Path.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_SaveImgForAI_Path.Name = "Button_SaveImgForAI_Path"
        '
        'TextBox_SaveImgForAIPath
        '
        resources.ApplyResources(Me.TextBox_SaveImgForAIPath, "TextBox_SaveImgForAIPath")
        Me.TextBox_SaveImgForAIPath.Name = "TextBox_SaveImgForAIPath"
        '
        'SaveImgForAI_Path
        '
        resources.ApplyResources(Me.SaveImgForAI_Path, "SaveImgForAI_Path")
        Me.SaveImgForAI_Path.Name = "SaveImgForAI_Path"
        '
        'TextBox_PanelID
        '
        resources.ApplyResources(Me.TextBox_PanelID, "TextBox_PanelID")
        Me.TextBox_PanelID.Name = "TextBox_PanelID"
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'FolderBrowserDialog_SaveImgPath
        '
        resources.ApplyResources(Me.FolderBrowserDialog_SaveImgPath, "FolderBrowserDialog_SaveImgPath")
        '
        'gbReadInlineInfo
        '
        resources.ApplyResources(Me.gbReadInlineInfo, "gbReadInlineInfo")
        Me.gbReadInlineInfo.Controls.Add(Me.Button_ReadFuncInfo)
        Me.gbReadInlineInfo.Controls.Add(Me.RichTextBox_FuncInfo)
        Me.gbReadInlineInfo.Name = "gbReadInlineInfo"
        Me.gbReadInlineInfo.TabStop = False
        '
        'Button_ReadFuncInfo
        '
        resources.ApplyResources(Me.Button_ReadFuncInfo, "Button_ReadFuncInfo")
        Me.Button_ReadFuncInfo.Name = "Button_ReadFuncInfo"
        Me.Button_ReadFuncInfo.UseVisualStyleBackColor = True
        '
        'RichTextBox_FuncInfo
        '
        resources.ApplyResources(Me.RichTextBox_FuncInfo, "RichTextBox_FuncInfo")
        Me.RichTextBox_FuncInfo.Name = "RichTextBox_FuncInfo"
        '
        'GroupBox2
        '
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.Controls.Add(Me.TextBox_LaserInfo2)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.TextBox_LaserInfo1)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'TextBox_LaserInfo2
        '
        resources.ApplyResources(Me.TextBox_LaserInfo2, "TextBox_LaserInfo2")
        Me.TextBox_LaserInfo2.Name = "TextBox_LaserInfo2"
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'TextBox_LaserInfo1
        '
        resources.ApplyResources(Me.TextBox_LaserInfo1, "TextBox_LaserInfo1")
        Me.TextBox_LaserInfo1.Name = "TextBox_LaserInfo1"
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'CheckBox_FilterByImageFilter
        '
        resources.ApplyResources(Me.CheckBox_FilterByImageFilter, "CheckBox_FilterByImageFilter")
        Me.CheckBox_FilterByImageFilter.Name = "CheckBox_FilterByImageFilter"
        Me.CheckBox_FilterByImageFilter.UseVisualStyleBackColor = True
        '
        'CheckBox_CreateFilterImage
        '
        resources.ApplyResources(Me.CheckBox_CreateFilterImage, "CheckBox_CreateFilterImage")
        Me.CheckBox_CreateFilterImage.Name = "CheckBox_CreateFilterImage"
        Me.CheckBox_CreateFilterImage.UseVisualStyleBackColor = True
        '
        'Dialog_FuncTestImageProcess
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.CheckBox_CreateFilterImage)
        Me.Controls.Add(Me.CheckBox_FilterByImageFilter)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.gbReadInlineInfo)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CheckBox_SaveDefectImage)
        Me.Controls.Add(Me.GroupBox_AddData_To_Log)
        Me.Controls.Add(Me.CheckBox_Filter_By_Characteristics)
        Me.Controls.Add(Me.GroupBox_GoTo_Point)
        Me.Controls.Add(Me.CheckBox_ShowAllDefects)
        Me.Controls.Add(Me.GroupBox_CharacteristicAnalysis)
        Me.Controls.Add(Me.Cancel_Button)
        Me.Controls.Add(Me.CheckBox_EnableFalseRule)
        Me.Controls.Add(Me.CheckBox_FilterFalseDefect)
        Me.Controls.Add(Me.CheckBox_FilterHotPixel)
        Me.Controls.Add(Me.CheckBox_FilterBackParticle)
        Me.Controls.Add(Me.Label_Msg)
        Me.Controls.Add(Me.CheckBox_NoShowMinusOne)
        Me.Controls.Add(Me.CheckBox_DrawDefect)
        Me.Controls.Add(Me.Label_Defects_Count)
        Me.Controls.Add(Me.Label_Defects_Y)
        Me.Controls.Add(Me.Label_Defects_X)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ListView_Defects)
        Me.Controls.Add(Me.GroupBox_ImgTest)
        Me.Controls.Add(Me.GroupBox_ImageSource)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_FuncTestImageProcess"
        Me.ShowInTaskbar = False
        Me.GroupBox_ImageSource.ResumeLayout(False)
        Me.GroupBox_ImgTest.ResumeLayout(False)
        Me.GroupBox_CharacteristicAnalysis.ResumeLayout(False)
        Me.GroupBox_CharacteristicAnalysis.PerformLayout()
        CType(Me.NumericUpDown_Compactness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Fullness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayMax_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayMax_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayMin_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayMin_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.DefectLogContextMenuStrip.ResumeLayout(False)
        Me.GroupBox_GoTo_Point.ResumeLayout(False)
        Me.GroupBox_GoTo_Point.PerformLayout()
        Me.GroupBox_AddData_To_Log.ResumeLayout(False)
        Me.GroupBox_AddData_To_Log.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.gbReadInlineInfo.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents GroupBox_ImageSource As System.Windows.Forms.GroupBox
    Friend WithEvents Button_LoadImage As System.Windows.Forms.Button
    Friend WithEvents GroupBox_ImgTest As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Execute As System.Windows.Forms.Button
    Friend WithEvents ComboBox_ImageProcess As System.Windows.Forms.ComboBox
    Friend WithEvents ListView_Defects As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader8 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label_Defects_X As System.Windows.Forms.Label
    Friend WithEvents Label_Defects_Y As System.Windows.Forms.Label
    Friend WithEvents Label_Defects_Count As System.Windows.Forms.Label
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox_DrawDefect As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_NoShowMinusOne As System.Windows.Forms.CheckBox
    Friend WithEvents ColumnHeader9 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label_Msg As System.Windows.Forms.Label
    Friend WithEvents CheckBox_FilterBackParticle As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FilterHotPixel As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FilterFalseDefect As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_EnableFalseRule As System.Windows.Forms.CheckBox
    Friend WithEvents ColumnHeader10 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader11 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader12 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader13 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader14 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader15 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader16 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader17 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Button_AddToLog As System.Windows.Forms.Button
    Friend WithEvents GroupBox_CharacteristicAnalysis As System.Windows.Forms.GroupBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Compactness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Fullness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayMax_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayMax_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayMin_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayMin_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_SaveCharacteristicRecipe As System.Windows.Forms.Button
    Friend WithEvents CheckBox_FilterCharacteristic As System.Windows.Forms.CheckBox
    Friend WithEvents DefectLogContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AddToLogToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckBox_ShowAllDefects As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_GoTo_Point As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox_GoTo_BlobY As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox_GoTo_BlobX As System.Windows.Forms.TextBox
    Friend WithEvents Button_GoTo_Position As System.Windows.Forms.Button
    Friend WithEvents CheckBox_Filter_By_Characteristics As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_AddData_To_Log As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_AddData_To_Log_All As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_AddData_To_Log_Single As System.Windows.Forms.RadioButton
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox_AddData_To_Log_FileName As System.Windows.Forms.TextBox
    Friend WithEvents ColumnHeader18 As System.Windows.Forms.ColumnHeader
    Friend WithEvents CheckBox_SaveDefectImage As System.Windows.Forms.CheckBox
    Friend WithEvents SaveImgToTrueToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveImgToFalseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button_SaveImgForAI_Path As System.Windows.Forms.Button
    Friend WithEvents TextBox_SaveImgForAIPath As System.Windows.Forms.TextBox
    Friend WithEvents SaveImgForAI_Path As System.Windows.Forms.Label
    Friend WithEvents TextBox_PanelID As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents FolderBrowserDialog_SaveImgPath As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents SaveImgToTrueOtherFalseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CheckBox_SaveCharacteristic As System.Windows.Forms.CheckBox
    Friend WithEvents Button_x2GoTo_Position As System.Windows.Forms.Button
    Friend WithEvents gbReadInlineInfo As System.Windows.Forms.GroupBox
    Friend WithEvents RichTextBox_FuncInfo As System.Windows.Forms.RichTextBox
    Friend WithEvents Button_ReadFuncInfo As System.Windows.Forms.Button
    Friend WithEvents CheckBox_SaveTif As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_LaserInfo2 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBox_LaserInfo1 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_FilterByImageFilter As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_CreateFilterImage As System.Windows.Forms.CheckBox

End Class
