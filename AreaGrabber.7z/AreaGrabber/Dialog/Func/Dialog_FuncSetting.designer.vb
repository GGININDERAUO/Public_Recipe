<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_FuncSetting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_FuncSetting))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Button_LoadImage = New System.Windows.Forms.Button()
        Me.TabControl_Setting = New System.Windows.Forms.TabControl()
        Me.TabPage_Point = New System.Windows.Forms.TabPage()
        Me.CheckBox_Waku_Inspect_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_WakuSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_WakuEdgeOffset = New System.Windows.Forms.NumericUpDown()
        Me.ComboBox_WakuEdge = New System.Windows.Forms.ComboBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WakuMaxValue = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WakuMinValue = New System.Windows.Forms.NumericUpDown()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.NumericUpDown_WakuEdgeWidth = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_WakuSplitNum = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_EnableLeakPoint = New System.Windows.Forms.CheckBox()
        Me.GroupBox_SeparateBP = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_SeparateBPBlob = New System.Windows.Forms.NumericUpDown()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.NumericUpDown_SeparateBPArea = New System.Windows.Forms.NumericUpDown()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.CheckBox_SeparateBPEnable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BPoint = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BP_RimThreshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_RimThreshold_Low = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_Threshold_Low = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_Threshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_RimThreshold = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_CPD_Enable = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Report_Multi_Pixel = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Inverse_Point_EnableFixArea = New System.Windows.Forms.CheckBox()
        Me.NumericUpDown_CheckBox_Inverse_Point_FixArea = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Inverse_Point_DefectType = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Align_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_PointMode = New System.Windows.Forms.GroupBox()
        Me.RadioButton_BPDP = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP = New System.Windows.Forms.RadioButton()
        Me.GroupBox_PointCommonSetting = New System.Windows.Forms.GroupBox()
        Me.RadioButton_DP_AreaMin = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP_AreaMax = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Point_OverNum = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Point_OverNum = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Point_ByPassY = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Point_ByPassX = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_AreaMin = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_AreaMax = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Point_ByPassY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Point_ByPassX = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_DPoint = New System.Windows.Forms.GroupBox()
        Me.RadioButton_DP_Threshold_Low = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_Threshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_RimThreshold_Low = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_RimThreshold_Low = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_RimThreshold = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_Point_Enable = New System.Windows.Forms.CheckBox()
        Me.TabPage_Point_Characteristic = New System.Windows.Forms.TabPage()
        Me.GroupBox_DP_Characteristics = New System.Windows.Forms.GroupBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.NumericUpDown_DP_MinGray_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_Compactness_Max = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP_StdDev_Max = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_Compactness_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_StdDev_Max = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_MinGray_Max = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_MinGray_Max = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_GrayMean_Max = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_GrayMean_Max = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_MaxGray_Fullness_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_MaxGray_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_Fullness_Max = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP_Fullness_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_Fullness_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_DP_Elongation_Max = New System.Windows.Forms.RadioButton()
        Me.RadioButton_DP_Elongation_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DP_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_DP_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_BP_Characteristics = New System.Windows.Forms.GroupBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BP_MaxGray_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_StdDev_Max = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_StdDev_Max = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_Compactness_Max = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_Compactness_Max = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_MaxGray_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_MaxGray_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_GrayMean_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_GrayMean_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_MaxGray_Fullness_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_MaxGray_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_Fullness_Max = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_Fullness_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_Fullness_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_Fullness_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BP_Elongation_Max = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BP_Elongation_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BP_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BP_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.TabPage_GSBP = New System.Windows.Forms.TabPage()
        Me.CheckBox_BLDP_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BLDPCommonSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BLDP_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BLDP_Elongation_Max = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_Elongation_Max = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BLDP_Elongation_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_Fatness_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_Fatness_Min = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_OverNum = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_OverNum = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_Scratch_Length = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_Scratch_Length = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_RangeY = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_RangeY = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_RangeX = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_RangeX = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_Count_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_Count_Min = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BLDP_AreaMin = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BLDP_AreaMax = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_BLDP_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_BLDP = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BLDP_EnhanceCount = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_EnhanceCount = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_ThresholdRim = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BLDP_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BLDP_RimThreshold = New System.Windows.Forms.RadioButton()
        Me.CheckBox_GSBP_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_GSBPCommonSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_GSBP_GrayMax_Low = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GSBP_GrayMax_High = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_GrayMax_Low = New System.Windows.Forms.RadioButton()
        Me.RadioButton_GSBP_GrayMax_High = New System.Windows.Forms.RadioButton()
        Me.RadioButton_GSBP_NumOfHoles = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_GSBP_NumOfHoles = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GSBP_OverNum = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_OverNum = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_GSBP_Scratch_Length = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_Scratch_Length = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_GSBP_RangeY = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_RangeY = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_GSBP_RangeX = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_RangeX = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_GSBP_Count_Min = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_Count_Min = New System.Windows.Forms.RadioButton()
        Me.RadioButton_GSBP_AreaMin = New System.Windows.Forms.RadioButton()
        Me.RadioButton_GSBP_AreaMax = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_GSBP_AreaMin = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GSBP_AreaMax = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_GSBP = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_GSBP_ThresholdRim = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_GSBP_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_GSBP_RimThreshold = New System.Windows.Forms.RadioButton()
        Me.TabPage_Line = New System.Windows.Forms.TabPage()
        Me.GroupBox_DLine = New System.Windows.Forms.GroupBox()
        Me.RadioButton_DL_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_DL_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_DL_Threshold = New System.Windows.Forms.TrackBar()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.NumericUpDown_DL_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_DL_RimThreshold = New System.Windows.Forms.TrackBar()
        Me.NumericUpDown_LeakPointRadius = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_Elongation_Min = New System.Windows.Forms.NumericUpDown()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.CheckBox_Filter_VH_Scratch = New System.Windows.Forms.CheckBox()
        Me.CheckBox_HalfScreen_Enable = New System.Windows.Forms.CheckBox()
        Me.CheckBox_DLine_Enable = New System.Windows.Forms.CheckBox()
        Me.CheckBox_BLine_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BLine = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TrackBar_BL_RimThreshold = New System.Windows.Forms.TrackBar()
        Me.NumericUpDown_BL_RimThreshold = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_BL_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_BL_Threshold = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_BL_Threshold = New System.Windows.Forms.TrackBar()
        Me.CheckBox_VLine_NotAddToOutput = New System.Windows.Forms.CheckBox()
        Me.CheckBox_HLine_NotAddToOutput = New System.Windows.Forms.CheckBox()
        Me.GroupBox_LineCommonSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Line_Short_Cut_H = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ShortCut_H = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_Cut_H = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_Cut_H = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_ByPassRightV = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ByPassRightV = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_ByPassLeftV = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ByPassLeftV = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Block_OverNumber = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Block_OverNum = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Line_ByPassUpH = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_Short_Cut = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_ByPassUpH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_ByPassDownH = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_ShortCut = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_Line_Cut = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_OverNumber = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_Line_OverNum = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Line_ByPassDownH = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Line_Cut = New System.Windows.Forms.RadioButton()
        Me.GroupBox_MeanDiff = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_MeanDifference = New System.Windows.Forms.NumericUpDown()
        Me.Button_MeanRange = New System.Windows.Forms.Button()
        Me.TrackBar_MeanDifference = New System.Windows.Forms.TrackBar()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CheckBox_Line_Enable = New System.Windows.Forms.CheckBox()
        Me.TabPage_GrayAbnormal = New System.Windows.Forms.TabPage()
        Me.GroupBox_GrayAbnormal = New System.Windows.Forms.GroupBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormal_NoDisplay = New System.Windows.Forms.NumericUpDown()
        Me.Lbl_GrayAbnormal_NegLimit = New System.Windows.Forms.Label()
        Me.Lbl_GrayAbnormal_PosLimit = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormal_NegLimit = New System.Windows.Forms.NumericUpDown()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayAbnormalStandardGray = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_GrayAbnormal_PosLimit = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_GrayAbnormal_Enable = New System.Windows.Forms.CheckBox()
        Me.TabPage_Auto = New System.Windows.Forms.TabPage()
        Me.GroupBox_AutoExposure = New System.Windows.Forms.GroupBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AutoExposure_GrabDelayTime = New System.Windows.Forms.NumericUpDown()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AutoExposure_LargeErrorRange_DL = New System.Windows.Forms.NumericUpDown()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AutoExposure_SmallErrorRange = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_AutoExposure_LargeErrorRange_UL = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_AutoExposure_TargetMean = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_AutoExposure_Kp = New System.Windows.Forms.NumericUpDown()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TabPage_Other = New System.Windows.Forms.TabPage()
        Me.GroupBox_AiSetting = New System.Windows.Forms.GroupBox()
        Me.ComboBox_IsAISaveROI = New System.Windows.Forms.ComboBox()
        Me.NumericUpDown_AiResizeY = New System.Windows.Forms.NumericUpDown()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AiResizeX = New System.Windows.Forms.NumericUpDown()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.GroupBox_ImgProcBoundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Boundary_MulWidth_RX = New System.Windows.Forms.NumericUpDown()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Boundary_MulWidth_BY = New System.Windows.Forms.NumericUpDown()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Boundary_MulWidth_LX = New System.Windows.Forms.NumericUpDown()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Boundary_MulWidth_TY = New System.Windows.Forms.NumericUpDown()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.GroupBox_LinePitchSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Line_PitchY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Line_PitchX = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox_LineAverageFilter = New System.Windows.Forms.GroupBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AverageFilter = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_FuncRawDataFilterMura_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Point_Algorithm = New System.Windows.Forms.GroupBox()
        Me.RadioButton_PointAlgorithm_6 = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PointAlgorithm_5 = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PointAlgorithm_4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PointAlgorithm_3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PointAlgorithm_2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PointAlgorithm_1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PointAlgorithm_0 = New System.Windows.Forms.RadioButton()
        Me.GroupBox_PointPitchSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_Point_PitchY = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Point_PitchX = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TabPage_Mark = New System.Windows.Forms.TabPage()
        Me.CheckBox_MarkTH = New System.Windows.Forms.CheckBox()
        Me.CheckBox_PLMark_Enable = New System.Windows.Forms.CheckBox()
        Me.CheckBox_CurrentPLMark_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_PLMark_Setting = New System.Windows.Forms.GroupBox()
        Me.GroupBox_MatchSetting = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_GrayMarkErodeCount = New System.Windows.Forms.NumericUpDown()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GrayMarkSmoothCount = New System.Windows.Forms.NumericUpDown()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.CheckBox_PreProcess = New System.Windows.Forms.CheckBox()
        Me.ComboBox_MatchImg = New System.Windows.Forms.ComboBox()
        Me.CheckBox_PLMark_RegionMannual = New System.Windows.Forms.CheckBox()
        Me.CheckBox_PLMark_ShowBoundary = New System.Windows.Forms.CheckBox()
        Me.GroupBox_PLMark_SearchMode = New System.Windows.Forms.GroupBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.NumericUpDown_SearchMarkCount = New System.Windows.Forms.NumericUpDown()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.CheckBox_FillOfHole = New System.Windows.Forms.CheckBox()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label_SearchRange_PLMark_Multiple = New System.Windows.Forms.Label()
        Me.NumericUpDown_SearchRange_PLMark_Multiple = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_PLMarkSet = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_MarkGroup = New System.Windows.Forms.NumericUpDown()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.NumericUpDown_PLMark_Acceptance = New System.Windows.Forms.NumericUpDown()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.TextBox_PLMark_MarkName = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.GroupBox_PLMark_Boundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_PLMark_BoundaryRight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_PLMark_BoundaryLeft = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_PLMark_BoundaryBottom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_PLMark_BoundaryTop = New System.Windows.Forms.NumericUpDown()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.GroupBox_BypassSetting = New System.Windows.Forms.GroupBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.CheckBox_BlobFillHole = New System.Windows.Forms.CheckBox()
        Me.ComboBox_BypassRegion = New System.Windows.Forms.ComboBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BlobArea = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_PLMark_DilateCount = New System.Windows.Forms.NumericUpDown()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label = New System.Windows.Forms.Label()
        Me.NumericUpDown_MarkTH = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_PLMark_Bin = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PLMark_Original = New System.Windows.Forms.RadioButton()
        Me.Button_Save_PLMark = New System.Windows.Forms.Button()
        Me.Button_PLMark_PatTest = New System.Windows.Forms.Button()
        Me.Panel_AxMDisplay_PLMark = New System.Windows.Forms.Panel()
        Me.CheckedListBox_PLMark = New System.Windows.Forms.CheckedListBox()
        Me.Label_PLMark_CurrentMark = New System.Windows.Forms.Label()
        Me.TabPage_HotPixel = New System.Windows.Forms.TabPage()
        Me.CheckBox_Filter_HotPixel_With_Characteristics = New System.Windows.Forms.CheckBox()
        Me.CheckBox_HotPixelEnable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_HotPixel = New System.Windows.Forms.GroupBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.NumericUpDown_HotPixelMaxMean = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton_HotPixel_Threshold = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown_HotPixelRecipe = New System.Windows.Forms.NumericUpDown()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.NumericUpDown_HotPixelFilterDistance = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_HotPixel_Threshold = New System.Windows.Forms.TrackBar()
        Me.TabPage_TPMark = New System.Windows.Forms.TabPage()
        Me.CheckBox_TPMark_Enable = New System.Windows.Forms.CheckBox()
        Me.GroupBox_TPMark_Setting = New System.Windows.Forms.GroupBox()
        Me.GroupBox_TPMarkSet = New System.Windows.Forms.GroupBox()
        Me.ComboBox_TPMark_Action = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown_TPMark_Acceptance = New System.Windows.Forms.NumericUpDown()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TextBox_TPMark_MarkName = New System.Windows.Forms.TextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.GroupBox_TPMark_Boundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_TPMark_BoundaryRight = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_TPMark_BoundaryLeft = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_TPMark_BoundaryBottom = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_TPMark_BoundaryTop = New System.Windows.Forms.NumericUpDown()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.CheckBox_TPMark_RegionMannual = New System.Windows.Forms.CheckBox()
        Me.CheckBox_TPMark_ShowBoundary = New System.Windows.Forms.CheckBox()
        Me.CheckBox_TPMark_ShowResult = New System.Windows.Forms.CheckBox()
        Me.Button_Save_TPMark = New System.Windows.Forms.Button()
        Me.Button_TPMark_PatTest = New System.Windows.Forms.Button()
        Me.Panel_AxMDisplay_TPMark = New System.Windows.Forms.Panel()
        Me.CheckedListBox_TPMark = New System.Windows.Forms.CheckedListBox()
        Me.Label_TPMark_CurrentMark = New System.Windows.Forms.Label()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.ComboBox_Pattern = New System.Windows.Forms.ComboBox()
        Me.ContextMenuStrip_PLMark = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem_AddPLMark = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_RemovePLMark = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip_TPMark = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem_AddTPMark = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_RemoveTPMark = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_EditTPMark = New System.Windows.Forms.ToolStripMenuItem()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TabControl_Setting.SuspendLayout()
        Me.TabPage_Point.SuspendLayout()
        Me.GroupBox_WakuSetting.SuspendLayout()
        CType(Me.NumericUpDown_WakuEdgeOffset, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WakuMaxValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WakuMinValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WakuEdgeWidth, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_WakuSplitNum, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_SeparateBP.SuspendLayout()
        CType(Me.NumericUpDown_SeparateBPBlob, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_SeparateBPArea, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BPoint.SuspendLayout()
        CType(Me.NumericUpDown_BP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Threshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_CheckBox_Inverse_Point_FixArea, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PointMode.SuspendLayout()
        Me.GroupBox_PointCommonSetting.SuspendLayout()
        CType(Me.NumericUpDown_DP_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_OverNum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_ByPassY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_ByPassX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_DPoint.SuspendLayout()
        CType(Me.NumericUpDown_DP_Threshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Point_Characteristic.SuspendLayout()
        Me.GroupBox_DP_Characteristics.SuspendLayout()
        CType(Me.NumericUpDown_DP_MinGray_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Compactness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_StdDev_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_MinGray_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_GrayMean_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Fullness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DP_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BP_Characteristics.SuspendLayout()
        CType(Me.NumericUpDown_BP_MaxGray_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_StdDev_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Compactness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_MaxGray_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_GrayMean_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Fullness_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Fullness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BP_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_GSBP.SuspendLayout()
        Me.GroupBox_BLDPCommonSetting.SuspendLayout()
        CType(Me.NumericUpDown_BLDP_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_Elongation_Max, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_Fatness_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_OverNum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_Scratch_Length, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_RangeY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_RangeX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_Count_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BLDP.SuspendLayout()
        CType(Me.NumericUpDown_BLDP_EnhanceCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_ThresholdRim, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BLDP_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_GSBPCommonSetting.SuspendLayout()
        CType(Me.NumericUpDown_GSBP_GrayMax_Low, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_GrayMax_High, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_NumOfHoles, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_OverNum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_Scratch_Length, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_RangeY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_RangeX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_Count_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_AreaMin, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_AreaMax, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_GSBP.SuspendLayout()
        CType(Me.NumericUpDown_GSBP_ThresholdRim, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GSBP_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Line.SuspendLayout()
        Me.GroupBox_DLine.SuspendLayout()
        CType(Me.NumericUpDown_DL_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_DL_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_DL_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_DL_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LeakPointRadius, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_Elongation_Min, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BLine.SuspendLayout()
        CType(Me.TrackBar_BL_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BL_RimThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BL_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_BL_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_LineCommonSetting.SuspendLayout()
        CType(Me.NumericUpDown_Line_Short_Cut_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_Cut_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassRightV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassLeftV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Block_OverNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_Short_Cut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassUpH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_ByPassDownH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_Cut, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_OverNumber, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MeanDiff.SuspendLayout()
        CType(Me.NumericUpDown_MeanDifference, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_MeanDifference, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_GrayAbnormal.SuspendLayout()
        Me.GroupBox_GrayAbnormal.SuspendLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NoDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Auto.SuspendLayout()
        Me.GroupBox_AutoExposure.SuspendLayout()
        CType(Me.NumericUpDown_AutoExposure_GrabDelayTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_SmallErrorRange, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_TargetMean, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AutoExposure_Kp, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Other.SuspendLayout()
        Me.GroupBox_AiSetting.SuspendLayout()
        CType(Me.NumericUpDown_AiResizeY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AiResizeX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ImgProcBoundary.SuspendLayout()
        CType(Me.NumericUpDown_Boundary_MulWidth_RX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_BY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_LX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_TY, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_LinePitchSetting.SuspendLayout()
        CType(Me.NumericUpDown_Line_PitchY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Line_PitchX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_LineAverageFilter.SuspendLayout()
        CType(Me.NumericUpDown_AverageFilter, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Point_Algorithm.SuspendLayout()
        Me.GroupBox_PointPitchSetting.SuspendLayout()
        CType(Me.NumericUpDown_Point_PitchY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Point_PitchX, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_Mark.SuspendLayout()
        Me.GroupBox_PLMark_Setting.SuspendLayout()
        Me.GroupBox_MatchSetting.SuspendLayout()
        CType(Me.NumericUpDown_GrayMarkErodeCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GrayMarkSmoothCount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PLMark_SearchMode.SuspendLayout()
        CType(Me.NumericUpDown_SearchMarkCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_SearchRange_PLMark_Multiple, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PLMarkSet.SuspendLayout()
        CType(Me.NumericUpDown_MarkGroup, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_PLMark_Acceptance, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_PLMark_Boundary.SuspendLayout()
        CType(Me.NumericUpDown_PLMark_BoundaryRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_PLMark_BoundaryLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_PLMark_BoundaryBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_PLMark_BoundaryTop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BypassSetting.SuspendLayout()
        CType(Me.NumericUpDown_BlobArea, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_PLMark_DilateCount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_MarkTH, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_HotPixel.SuspendLayout()
        Me.GroupBox_HotPixel.SuspendLayout()
        CType(Me.NumericUpDown_HotPixelMaxMean, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HotPixelRecipe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_HotPixelFilterDistance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_HotPixel_Threshold, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage_TPMark.SuspendLayout()
        Me.GroupBox_TPMark_Setting.SuspendLayout()
        Me.GroupBox_TPMarkSet.SuspendLayout()
        CType(Me.NumericUpDown_TPMark_Acceptance, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_TPMark_Boundary.SuspendLayout()
        CType(Me.NumericUpDown_TPMark_BoundaryRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_TPMark_BoundaryLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_TPMark_BoundaryBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_TPMark_BoundaryTop, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip_PLMark.SuspendLayout()
        Me.ContextMenuStrip_TPMark.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        resources.ApplyResources(Me.TableLayoutPanel1, "TableLayoutPanel1")
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Save, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_LoadImage, 0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.UseVisualStyleBackColor = True
        '
        'Button_LoadImage
        '
        resources.ApplyResources(Me.Button_LoadImage, "Button_LoadImage")
        Me.Button_LoadImage.Name = "Button_LoadImage"
        Me.Button_LoadImage.UseVisualStyleBackColor = True
        '
        'TabControl_Setting
        '
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Point)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Point_Characteristic)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_GSBP)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Line)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_GrayAbnormal)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Auto)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Other)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_Mark)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_HotPixel)
        Me.TabControl_Setting.Controls.Add(Me.TabPage_TPMark)
        resources.ApplyResources(Me.TabControl_Setting, "TabControl_Setting")
        Me.TabControl_Setting.Multiline = True
        Me.TabControl_Setting.Name = "TabControl_Setting"
        Me.TabControl_Setting.SelectedIndex = 0
        '
        'TabPage_Point
        '
        Me.TabPage_Point.BackColor = System.Drawing.Color.White
        Me.TabPage_Point.Controls.Add(Me.CheckBox_Waku_Inspect_Enable)
        Me.TabPage_Point.Controls.Add(Me.GroupBox_WakuSetting)
        Me.TabPage_Point.Controls.Add(Me.CheckBox_EnableLeakPoint)
        Me.TabPage_Point.Controls.Add(Me.GroupBox_SeparateBP)
        Me.TabPage_Point.Controls.Add(Me.GroupBox_BPoint)
        Me.TabPage_Point.Controls.Add(Me.CheckBox_CPD_Enable)
        Me.TabPage_Point.Controls.Add(Me.CheckBox_Report_Multi_Pixel)
        Me.TabPage_Point.Controls.Add(Me.CheckBox_Inverse_Point_EnableFixArea)
        Me.TabPage_Point.Controls.Add(Me.NumericUpDown_CheckBox_Inverse_Point_FixArea)
        Me.TabPage_Point.Controls.Add(Me.CheckBox_Inverse_Point_DefectType)
        Me.TabPage_Point.Controls.Add(Me.CheckBox_Align_Enable)
        Me.TabPage_Point.Controls.Add(Me.GroupBox_PointMode)
        Me.TabPage_Point.Controls.Add(Me.GroupBox_PointCommonSetting)
        Me.TabPage_Point.Controls.Add(Me.GroupBox_DPoint)
        Me.TabPage_Point.Controls.Add(Me.CheckBox_Point_Enable)
        resources.ApplyResources(Me.TabPage_Point, "TabPage_Point")
        Me.TabPage_Point.Name = "TabPage_Point"
        Me.TabPage_Point.UseVisualStyleBackColor = True
        '
        'CheckBox_Waku_Inspect_Enable
        '
        resources.ApplyResources(Me.CheckBox_Waku_Inspect_Enable, "CheckBox_Waku_Inspect_Enable")
        Me.CheckBox_Waku_Inspect_Enable.Name = "CheckBox_Waku_Inspect_Enable"
        Me.CheckBox_Waku_Inspect_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_WakuSetting
        '
        Me.GroupBox_WakuSetting.Controls.Add(Me.NumericUpDown_WakuEdgeOffset)
        Me.GroupBox_WakuSetting.Controls.Add(Me.ComboBox_WakuEdge)
        Me.GroupBox_WakuSetting.Controls.Add(Me.Label69)
        Me.GroupBox_WakuSetting.Controls.Add(Me.NumericUpDown_WakuMaxValue)
        Me.GroupBox_WakuSetting.Controls.Add(Me.NumericUpDown_WakuMinValue)
        Me.GroupBox_WakuSetting.Controls.Add(Me.Label73)
        Me.GroupBox_WakuSetting.Controls.Add(Me.Label72)
        Me.GroupBox_WakuSetting.Controls.Add(Me.Label71)
        Me.GroupBox_WakuSetting.Controls.Add(Me.Label70)
        Me.GroupBox_WakuSetting.Controls.Add(Me.Label68)
        Me.GroupBox_WakuSetting.Controls.Add(Me.NumericUpDown_WakuEdgeWidth)
        Me.GroupBox_WakuSetting.Controls.Add(Me.NumericUpDown_WakuSplitNum)
        resources.ApplyResources(Me.GroupBox_WakuSetting, "GroupBox_WakuSetting")
        Me.GroupBox_WakuSetting.Name = "GroupBox_WakuSetting"
        Me.GroupBox_WakuSetting.TabStop = False
        '
        'NumericUpDown_WakuEdgeOffset
        '
        resources.ApplyResources(Me.NumericUpDown_WakuEdgeOffset, "NumericUpDown_WakuEdgeOffset")
        Me.NumericUpDown_WakuEdgeOffset.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.NumericUpDown_WakuEdgeOffset.Name = "NumericUpDown_WakuEdgeOffset"
        '
        'ComboBox_WakuEdge
        '
        Me.ComboBox_WakuEdge.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_WakuEdge.FormattingEnabled = True
        Me.ComboBox_WakuEdge.Items.AddRange(New Object() {resources.GetString("ComboBox_WakuEdge.Items"), resources.GetString("ComboBox_WakuEdge.Items1"), resources.GetString("ComboBox_WakuEdge.Items2"), resources.GetString("ComboBox_WakuEdge.Items3")})
        resources.ApplyResources(Me.ComboBox_WakuEdge, "ComboBox_WakuEdge")
        Me.ComboBox_WakuEdge.Name = "ComboBox_WakuEdge"
        '
        'Label69
        '
        resources.ApplyResources(Me.Label69, "Label69")
        Me.Label69.Name = "Label69"
        '
        'NumericUpDown_WakuMaxValue
        '
        Me.NumericUpDown_WakuMaxValue.DecimalPlaces = 2
        resources.ApplyResources(Me.NumericUpDown_WakuMaxValue, "NumericUpDown_WakuMaxValue")
        Me.NumericUpDown_WakuMaxValue.Maximum = New Decimal(New Integer() {9999999, 0, 0, 0})
        Me.NumericUpDown_WakuMaxValue.Name = "NumericUpDown_WakuMaxValue"
        '
        'NumericUpDown_WakuMinValue
        '
        Me.NumericUpDown_WakuMinValue.DecimalPlaces = 2
        resources.ApplyResources(Me.NumericUpDown_WakuMinValue, "NumericUpDown_WakuMinValue")
        Me.NumericUpDown_WakuMinValue.Maximum = New Decimal(New Integer() {9999999, 0, 0, 0})
        Me.NumericUpDown_WakuMinValue.Name = "NumericUpDown_WakuMinValue"
        '
        'Label73
        '
        resources.ApplyResources(Me.Label73, "Label73")
        Me.Label73.Name = "Label73"
        '
        'Label72
        '
        resources.ApplyResources(Me.Label72, "Label72")
        Me.Label72.Name = "Label72"
        '
        'Label71
        '
        resources.ApplyResources(Me.Label71, "Label71")
        Me.Label71.Name = "Label71"
        '
        'Label70
        '
        resources.ApplyResources(Me.Label70, "Label70")
        Me.Label70.Name = "Label70"
        '
        'Label68
        '
        resources.ApplyResources(Me.Label68, "Label68")
        Me.Label68.Name = "Label68"
        '
        'NumericUpDown_WakuEdgeWidth
        '
        resources.ApplyResources(Me.NumericUpDown_WakuEdgeWidth, "NumericUpDown_WakuEdgeWidth")
        Me.NumericUpDown_WakuEdgeWidth.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.NumericUpDown_WakuEdgeWidth.Name = "NumericUpDown_WakuEdgeWidth"
        Me.NumericUpDown_WakuEdgeWidth.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown_WakuSplitNum
        '
        resources.ApplyResources(Me.NumericUpDown_WakuSplitNum, "NumericUpDown_WakuSplitNum")
        Me.NumericUpDown_WakuSplitNum.Maximum = New Decimal(New Integer() {99999, 0, 0, 0})
        Me.NumericUpDown_WakuSplitNum.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_WakuSplitNum.Name = "NumericUpDown_WakuSplitNum"
        Me.NumericUpDown_WakuSplitNum.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'CheckBox_EnableLeakPoint
        '
        resources.ApplyResources(Me.CheckBox_EnableLeakPoint, "CheckBox_EnableLeakPoint")
        Me.CheckBox_EnableLeakPoint.Name = "CheckBox_EnableLeakPoint"
        Me.CheckBox_EnableLeakPoint.UseVisualStyleBackColor = True
        '
        'GroupBox_SeparateBP
        '
        Me.GroupBox_SeparateBP.Controls.Add(Me.NumericUpDown_SeparateBPBlob)
        Me.GroupBox_SeparateBP.Controls.Add(Me.Label38)
        Me.GroupBox_SeparateBP.Controls.Add(Me.NumericUpDown_SeparateBPArea)
        Me.GroupBox_SeparateBP.Controls.Add(Me.Label31)
        Me.GroupBox_SeparateBP.Controls.Add(Me.CheckBox_SeparateBPEnable)
        resources.ApplyResources(Me.GroupBox_SeparateBP, "GroupBox_SeparateBP")
        Me.GroupBox_SeparateBP.Name = "GroupBox_SeparateBP"
        Me.GroupBox_SeparateBP.TabStop = False
        '
        'NumericUpDown_SeparateBPBlob
        '
        resources.ApplyResources(Me.NumericUpDown_SeparateBPBlob, "NumericUpDown_SeparateBPBlob")
        Me.NumericUpDown_SeparateBPBlob.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_SeparateBPBlob.Name = "NumericUpDown_SeparateBPBlob"
        '
        'Label38
        '
        resources.ApplyResources(Me.Label38, "Label38")
        Me.Label38.Name = "Label38"
        '
        'NumericUpDown_SeparateBPArea
        '
        resources.ApplyResources(Me.NumericUpDown_SeparateBPArea, "NumericUpDown_SeparateBPArea")
        Me.NumericUpDown_SeparateBPArea.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown_SeparateBPArea.Name = "NumericUpDown_SeparateBPArea"
        '
        'Label31
        '
        resources.ApplyResources(Me.Label31, "Label31")
        Me.Label31.Name = "Label31"
        '
        'CheckBox_SeparateBPEnable
        '
        resources.ApplyResources(Me.CheckBox_SeparateBPEnable, "CheckBox_SeparateBPEnable")
        Me.CheckBox_SeparateBPEnable.Name = "CheckBox_SeparateBPEnable"
        Me.CheckBox_SeparateBPEnable.UseVisualStyleBackColor = True
        '
        'GroupBox_BPoint
        '
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_RimThreshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_RimThreshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_Threshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_Threshold_Low)
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_RimThreshold)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_RimThreshold)
        Me.GroupBox_BPoint.Controls.Add(Me.RadioButton_BP_Threshold)
        Me.GroupBox_BPoint.Controls.Add(Me.NumericUpDown_BP_Threshold)
        resources.ApplyResources(Me.GroupBox_BPoint, "GroupBox_BPoint")
        Me.GroupBox_BPoint.Name = "GroupBox_BPoint"
        Me.GroupBox_BPoint.TabStop = False
        '
        'NumericUpDown_BP_RimThreshold_Low
        '
        resources.ApplyResources(Me.NumericUpDown_BP_RimThreshold_Low, "NumericUpDown_BP_RimThreshold_Low")
        Me.NumericUpDown_BP_RimThreshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold_Low.Name = "NumericUpDown_BP_RimThreshold_Low"
        '
        'RadioButton_BP_RimThreshold_Low
        '
        resources.ApplyResources(Me.RadioButton_BP_RimThreshold_Low, "RadioButton_BP_RimThreshold_Low")
        Me.RadioButton_BP_RimThreshold_Low.Name = "RadioButton_BP_RimThreshold_Low"
        Me.RadioButton_BP_RimThreshold_Low.TabStop = True
        Me.RadioButton_BP_RimThreshold_Low.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_Threshold_Low
        '
        resources.ApplyResources(Me.RadioButton_BP_Threshold_Low, "RadioButton_BP_Threshold_Low")
        Me.RadioButton_BP_Threshold_Low.Name = "RadioButton_BP_Threshold_Low"
        Me.RadioButton_BP_Threshold_Low.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_Threshold_Low
        '
        resources.ApplyResources(Me.NumericUpDown_BP_Threshold_Low, "NumericUpDown_BP_Threshold_Low")
        Me.NumericUpDown_BP_Threshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold_Low.Name = "NumericUpDown_BP_Threshold_Low"
        '
        'NumericUpDown_BP_RimThreshold
        '
        resources.ApplyResources(Me.NumericUpDown_BP_RimThreshold, "NumericUpDown_BP_RimThreshold")
        Me.NumericUpDown_BP_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_RimThreshold.Name = "NumericUpDown_BP_RimThreshold"
        '
        'RadioButton_BP_RimThreshold
        '
        resources.ApplyResources(Me.RadioButton_BP_RimThreshold, "RadioButton_BP_RimThreshold")
        Me.RadioButton_BP_RimThreshold.Name = "RadioButton_BP_RimThreshold"
        Me.RadioButton_BP_RimThreshold.TabStop = True
        Me.RadioButton_BP_RimThreshold.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_Threshold
        '
        resources.ApplyResources(Me.RadioButton_BP_Threshold, "RadioButton_BP_Threshold")
        Me.RadioButton_BP_Threshold.Name = "RadioButton_BP_Threshold"
        Me.RadioButton_BP_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_BP_Threshold, "NumericUpDown_BP_Threshold")
        Me.NumericUpDown_BP_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BP_Threshold.Name = "NumericUpDown_BP_Threshold"
        '
        'CheckBox_CPD_Enable
        '
        resources.ApplyResources(Me.CheckBox_CPD_Enable, "CheckBox_CPD_Enable")
        Me.CheckBox_CPD_Enable.Name = "CheckBox_CPD_Enable"
        Me.CheckBox_CPD_Enable.UseVisualStyleBackColor = True
        '
        'CheckBox_Report_Multi_Pixel
        '
        resources.ApplyResources(Me.CheckBox_Report_Multi_Pixel, "CheckBox_Report_Multi_Pixel")
        Me.CheckBox_Report_Multi_Pixel.Name = "CheckBox_Report_Multi_Pixel"
        Me.CheckBox_Report_Multi_Pixel.UseVisualStyleBackColor = True
        '
        'CheckBox_Inverse_Point_EnableFixArea
        '
        resources.ApplyResources(Me.CheckBox_Inverse_Point_EnableFixArea, "CheckBox_Inverse_Point_EnableFixArea")
        Me.CheckBox_Inverse_Point_EnableFixArea.Name = "CheckBox_Inverse_Point_EnableFixArea"
        Me.CheckBox_Inverse_Point_EnableFixArea.UseVisualStyleBackColor = True
        '
        'NumericUpDown_CheckBox_Inverse_Point_FixArea
        '
        resources.ApplyResources(Me.NumericUpDown_CheckBox_Inverse_Point_FixArea, "NumericUpDown_CheckBox_Inverse_Point_FixArea")
        Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Name = "NumericUpDown_CheckBox_Inverse_Point_FixArea"
        Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'CheckBox_Inverse_Point_DefectType
        '
        resources.ApplyResources(Me.CheckBox_Inverse_Point_DefectType, "CheckBox_Inverse_Point_DefectType")
        Me.CheckBox_Inverse_Point_DefectType.Name = "CheckBox_Inverse_Point_DefectType"
        Me.CheckBox_Inverse_Point_DefectType.UseVisualStyleBackColor = True
        '
        'CheckBox_Align_Enable
        '
        resources.ApplyResources(Me.CheckBox_Align_Enable, "CheckBox_Align_Enable")
        Me.CheckBox_Align_Enable.Name = "CheckBox_Align_Enable"
        Me.CheckBox_Align_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_PointMode
        '
        Me.GroupBox_PointMode.Controls.Add(Me.RadioButton_BPDP)
        Me.GroupBox_PointMode.Controls.Add(Me.RadioButton_DP)
        Me.GroupBox_PointMode.Controls.Add(Me.RadioButton_BP)
        resources.ApplyResources(Me.GroupBox_PointMode, "GroupBox_PointMode")
        Me.GroupBox_PointMode.Name = "GroupBox_PointMode"
        Me.GroupBox_PointMode.TabStop = False
        '
        'RadioButton_BPDP
        '
        resources.ApplyResources(Me.RadioButton_BPDP, "RadioButton_BPDP")
        Me.RadioButton_BPDP.Name = "RadioButton_BPDP"
        Me.RadioButton_BPDP.TabStop = True
        Me.RadioButton_BPDP.UseVisualStyleBackColor = True
        '
        'RadioButton_DP
        '
        resources.ApplyResources(Me.RadioButton_DP, "RadioButton_DP")
        Me.RadioButton_DP.Name = "RadioButton_DP"
        Me.RadioButton_DP.TabStop = True
        Me.RadioButton_DP.UseVisualStyleBackColor = True
        '
        'RadioButton_BP
        '
        resources.ApplyResources(Me.RadioButton_BP, "RadioButton_BP")
        Me.RadioButton_BP.Name = "RadioButton_BP"
        Me.RadioButton_BP.TabStop = True
        Me.RadioButton_BP.UseVisualStyleBackColor = True
        '
        'GroupBox_PointCommonSetting
        '
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.RadioButton_DP_AreaMin)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.RadioButton_DP_AreaMax)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_DP_AreaMin)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_DP_AreaMax)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_Point_OverNum)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.RadioButton_Point_OverNum)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.RadioButton_Point_ByPassY)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.RadioButton_Point_ByPassX)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.RadioButton_BP_AreaMin)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.RadioButton_BP_AreaMax)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_Point_ByPassY)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_Point_ByPassX)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_BP_AreaMin)
        Me.GroupBox_PointCommonSetting.Controls.Add(Me.NumericUpDown_BP_AreaMax)
        resources.ApplyResources(Me.GroupBox_PointCommonSetting, "GroupBox_PointCommonSetting")
        Me.GroupBox_PointCommonSetting.Name = "GroupBox_PointCommonSetting"
        Me.GroupBox_PointCommonSetting.TabStop = False
        '
        'RadioButton_DP_AreaMin
        '
        resources.ApplyResources(Me.RadioButton_DP_AreaMin, "RadioButton_DP_AreaMin")
        Me.RadioButton_DP_AreaMin.Name = "RadioButton_DP_AreaMin"
        Me.RadioButton_DP_AreaMin.UseVisualStyleBackColor = True
        '
        'RadioButton_DP_AreaMax
        '
        resources.ApplyResources(Me.RadioButton_DP_AreaMax, "RadioButton_DP_AreaMax")
        Me.RadioButton_DP_AreaMax.Name = "RadioButton_DP_AreaMax"
        Me.RadioButton_DP_AreaMax.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_AreaMin
        '
        resources.ApplyResources(Me.NumericUpDown_DP_AreaMin, "NumericUpDown_DP_AreaMin")
        Me.NumericUpDown_DP_AreaMin.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_DP_AreaMin.Name = "NumericUpDown_DP_AreaMin"
        '
        'NumericUpDown_DP_AreaMax
        '
        resources.ApplyResources(Me.NumericUpDown_DP_AreaMax, "NumericUpDown_DP_AreaMax")
        Me.NumericUpDown_DP_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_DP_AreaMax.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_AreaMax.Name = "NumericUpDown_DP_AreaMax"
        Me.NumericUpDown_DP_AreaMax.Value = New Decimal(New Integer() {250, 0, 0, 0})
        '
        'NumericUpDown_Point_OverNum
        '
        resources.ApplyResources(Me.NumericUpDown_Point_OverNum, "NumericUpDown_Point_OverNum")
        Me.NumericUpDown_Point_OverNum.Maximum = New Decimal(New Integer() {200000000, 0, 0, 0})
        Me.NumericUpDown_Point_OverNum.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Point_OverNum.Name = "NumericUpDown_Point_OverNum"
        Me.NumericUpDown_Point_OverNum.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'RadioButton_Point_OverNum
        '
        resources.ApplyResources(Me.RadioButton_Point_OverNum, "RadioButton_Point_OverNum")
        Me.RadioButton_Point_OverNum.Name = "RadioButton_Point_OverNum"
        Me.RadioButton_Point_OverNum.UseVisualStyleBackColor = True
        '
        'RadioButton_Point_ByPassY
        '
        resources.ApplyResources(Me.RadioButton_Point_ByPassY, "RadioButton_Point_ByPassY")
        Me.RadioButton_Point_ByPassY.Name = "RadioButton_Point_ByPassY"
        Me.RadioButton_Point_ByPassY.UseVisualStyleBackColor = True
        '
        'RadioButton_Point_ByPassX
        '
        resources.ApplyResources(Me.RadioButton_Point_ByPassX, "RadioButton_Point_ByPassX")
        Me.RadioButton_Point_ByPassX.Name = "RadioButton_Point_ByPassX"
        Me.RadioButton_Point_ByPassX.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_AreaMin
        '
        resources.ApplyResources(Me.RadioButton_BP_AreaMin, "RadioButton_BP_AreaMin")
        Me.RadioButton_BP_AreaMin.Name = "RadioButton_BP_AreaMin"
        Me.RadioButton_BP_AreaMin.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_AreaMax
        '
        resources.ApplyResources(Me.RadioButton_BP_AreaMax, "RadioButton_BP_AreaMax")
        Me.RadioButton_BP_AreaMax.Name = "RadioButton_BP_AreaMax"
        Me.RadioButton_BP_AreaMax.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Point_ByPassY
        '
        resources.ApplyResources(Me.NumericUpDown_Point_ByPassY, "NumericUpDown_Point_ByPassY")
        Me.NumericUpDown_Point_ByPassY.Name = "NumericUpDown_Point_ByPassY"
        '
        'NumericUpDown_Point_ByPassX
        '
        resources.ApplyResources(Me.NumericUpDown_Point_ByPassX, "NumericUpDown_Point_ByPassX")
        Me.NumericUpDown_Point_ByPassX.Name = "NumericUpDown_Point_ByPassX"
        '
        'NumericUpDown_BP_AreaMin
        '
        resources.ApplyResources(Me.NumericUpDown_BP_AreaMin, "NumericUpDown_BP_AreaMin")
        Me.NumericUpDown_BP_AreaMin.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BP_AreaMin.Name = "NumericUpDown_BP_AreaMin"
        '
        'NumericUpDown_BP_AreaMax
        '
        resources.ApplyResources(Me.NumericUpDown_BP_AreaMax, "NumericUpDown_BP_AreaMax")
        Me.NumericUpDown_BP_AreaMax.Maximum = New Decimal(New Integer() {1000000, 0, 0, 0})
        Me.NumericUpDown_BP_AreaMax.Minimum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_AreaMax.Name = "NumericUpDown_BP_AreaMax"
        Me.NumericUpDown_BP_AreaMax.Value = New Decimal(New Integer() {250, 0, 0, 0})
        '
        'GroupBox_DPoint
        '
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_Threshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_Threshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_RimThreshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_RimThreshold_Low)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_RimThreshold)
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_RimThreshold)
        Me.GroupBox_DPoint.Controls.Add(Me.RadioButton_DP_Threshold)
        Me.GroupBox_DPoint.Controls.Add(Me.NumericUpDown_DP_Threshold)
        resources.ApplyResources(Me.GroupBox_DPoint, "GroupBox_DPoint")
        Me.GroupBox_DPoint.Name = "GroupBox_DPoint"
        Me.GroupBox_DPoint.TabStop = False
        '
        'RadioButton_DP_Threshold_Low
        '
        resources.ApplyResources(Me.RadioButton_DP_Threshold_Low, "RadioButton_DP_Threshold_Low")
        Me.RadioButton_DP_Threshold_Low.Name = "RadioButton_DP_Threshold_Low"
        Me.RadioButton_DP_Threshold_Low.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_Threshold_Low
        '
        resources.ApplyResources(Me.NumericUpDown_DP_Threshold_Low, "NumericUpDown_DP_Threshold_Low")
        Me.NumericUpDown_DP_Threshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold_Low.Name = "NumericUpDown_DP_Threshold_Low"
        '
        'NumericUpDown_DP_RimThreshold_Low
        '
        resources.ApplyResources(Me.NumericUpDown_DP_RimThreshold_Low, "NumericUpDown_DP_RimThreshold_Low")
        Me.NumericUpDown_DP_RimThreshold_Low.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold_Low.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold_Low.Name = "NumericUpDown_DP_RimThreshold_Low"
        '
        'RadioButton_DP_RimThreshold_Low
        '
        resources.ApplyResources(Me.RadioButton_DP_RimThreshold_Low, "RadioButton_DP_RimThreshold_Low")
        Me.RadioButton_DP_RimThreshold_Low.Name = "RadioButton_DP_RimThreshold_Low"
        Me.RadioButton_DP_RimThreshold_Low.TabStop = True
        Me.RadioButton_DP_RimThreshold_Low.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_RimThreshold
        '
        resources.ApplyResources(Me.NumericUpDown_DP_RimThreshold, "NumericUpDown_DP_RimThreshold")
        Me.NumericUpDown_DP_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_RimThreshold.Name = "NumericUpDown_DP_RimThreshold"
        '
        'RadioButton_DP_RimThreshold
        '
        resources.ApplyResources(Me.RadioButton_DP_RimThreshold, "RadioButton_DP_RimThreshold")
        Me.RadioButton_DP_RimThreshold.Name = "RadioButton_DP_RimThreshold"
        Me.RadioButton_DP_RimThreshold.TabStop = True
        Me.RadioButton_DP_RimThreshold.UseVisualStyleBackColor = True
        '
        'RadioButton_DP_Threshold
        '
        resources.ApplyResources(Me.RadioButton_DP_Threshold, "RadioButton_DP_Threshold")
        Me.RadioButton_DP_Threshold.Name = "RadioButton_DP_Threshold"
        Me.RadioButton_DP_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_DP_Threshold, "NumericUpDown_DP_Threshold")
        Me.NumericUpDown_DP_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_DP_Threshold.Name = "NumericUpDown_DP_Threshold"
        '
        'CheckBox_Point_Enable
        '
        Me.CheckBox_Point_Enable.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar
        resources.ApplyResources(Me.CheckBox_Point_Enable, "CheckBox_Point_Enable")
        Me.CheckBox_Point_Enable.Name = "CheckBox_Point_Enable"
        Me.CheckBox_Point_Enable.UseVisualStyleBackColor = True
        '
        'TabPage_Point_Characteristic
        '
        Me.TabPage_Point_Characteristic.Controls.Add(Me.GroupBox_DP_Characteristics)
        Me.TabPage_Point_Characteristic.Controls.Add(Me.GroupBox_BP_Characteristics)
        resources.ApplyResources(Me.TabPage_Point_Characteristic, "TabPage_Point_Characteristic")
        Me.TabPage_Point_Characteristic.Name = "TabPage_Point_Characteristic"
        Me.TabPage_Point_Characteristic.UseVisualStyleBackColor = True
        '
        'GroupBox_DP_Characteristics
        '
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.Label50)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_MinGray_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_Compactness_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_StdDev_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Compactness_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_StdDev_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_MinGray_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_MinGray_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_GrayMean_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_GrayMean_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_MaxGray_Fullness_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_MaxGray_Fullness_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_Fullness_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_Fullness_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Fullness_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Fullness_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_Elongation_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.RadioButton_DP_Elongation_Min)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Elongation_Max)
        Me.GroupBox_DP_Characteristics.Controls.Add(Me.NumericUpDown_DP_Elongation_Min)
        resources.ApplyResources(Me.GroupBox_DP_Characteristics, "GroupBox_DP_Characteristics")
        Me.GroupBox_DP_Characteristics.Name = "GroupBox_DP_Characteristics"
        Me.GroupBox_DP_Characteristics.TabStop = False
        '
        'Label50
        '
        resources.ApplyResources(Me.Label50, "Label50")
        Me.Label50.Name = "Label50"
        '
        'NumericUpDown_DP_MinGray_Min
        '
        resources.ApplyResources(Me.NumericUpDown_DP_MinGray_Min, "NumericUpDown_DP_MinGray_Min")
        Me.NumericUpDown_DP_MinGray_Min.Maximum = New Decimal(New Integer() {200000000, 0, 0, 0})
        Me.NumericUpDown_DP_MinGray_Min.Name = "NumericUpDown_DP_MinGray_Min"
        '
        'RadioButton_DP_Compactness_Max
        '
        resources.ApplyResources(Me.RadioButton_DP_Compactness_Max, "RadioButton_DP_Compactness_Max")
        Me.RadioButton_DP_Compactness_Max.Name = "RadioButton_DP_Compactness_Max"
        Me.RadioButton_DP_Compactness_Max.UseVisualStyleBackColor = True
        '
        'RadioButton_DP_StdDev_Max
        '
        resources.ApplyResources(Me.RadioButton_DP_StdDev_Max, "RadioButton_DP_StdDev_Max")
        Me.RadioButton_DP_StdDev_Max.Name = "RadioButton_DP_StdDev_Max"
        Me.RadioButton_DP_StdDev_Max.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_Compactness_Max
        '
        Me.NumericUpDown_DP_Compactness_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_Compactness_Max, "NumericUpDown_DP_Compactness_Max")
        Me.NumericUpDown_DP_Compactness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Compactness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_Compactness_Max.Name = "NumericUpDown_DP_Compactness_Max"
        '
        'NumericUpDown_DP_StdDev_Max
        '
        Me.NumericUpDown_DP_StdDev_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_StdDev_Max, "NumericUpDown_DP_StdDev_Max")
        Me.NumericUpDown_DP_StdDev_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_StdDev_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_StdDev_Max.Name = "NumericUpDown_DP_StdDev_Max"
        '
        'RadioButton_DP_MinGray_Max
        '
        resources.ApplyResources(Me.RadioButton_DP_MinGray_Max, "RadioButton_DP_MinGray_Max")
        Me.RadioButton_DP_MinGray_Max.Name = "RadioButton_DP_MinGray_Max"
        Me.RadioButton_DP_MinGray_Max.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_MinGray_Max
        '
        Me.NumericUpDown_DP_MinGray_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_MinGray_Max, "NumericUpDown_DP_MinGray_Max")
        Me.NumericUpDown_DP_MinGray_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_MinGray_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_MinGray_Max.Name = "NumericUpDown_DP_MinGray_Max"
        '
        'RadioButton_DP_GrayMean_Max
        '
        resources.ApplyResources(Me.RadioButton_DP_GrayMean_Max, "RadioButton_DP_GrayMean_Max")
        Me.RadioButton_DP_GrayMean_Max.Name = "RadioButton_DP_GrayMean_Max"
        Me.RadioButton_DP_GrayMean_Max.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_GrayMean_Max
        '
        Me.NumericUpDown_DP_GrayMean_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_GrayMean_Max, "NumericUpDown_DP_GrayMean_Max")
        Me.NumericUpDown_DP_GrayMean_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_GrayMean_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_GrayMean_Max.Name = "NumericUpDown_DP_GrayMean_Max"
        '
        'RadioButton_DP_MaxGray_Fullness_Min
        '
        resources.ApplyResources(Me.RadioButton_DP_MaxGray_Fullness_Min, "RadioButton_DP_MaxGray_Fullness_Min")
        Me.RadioButton_DP_MaxGray_Fullness_Min.Name = "RadioButton_DP_MaxGray_Fullness_Min"
        Me.RadioButton_DP_MaxGray_Fullness_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_MaxGray_Fullness_Min
        '
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_MaxGray_Fullness_Min, "NumericUpDown_DP_MaxGray_Fullness_Min")
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DP_MaxGray_Fullness_Min.Name = "NumericUpDown_DP_MaxGray_Fullness_Min"
        '
        'RadioButton_DP_Fullness_Max
        '
        resources.ApplyResources(Me.RadioButton_DP_Fullness_Max, "RadioButton_DP_Fullness_Max")
        Me.RadioButton_DP_Fullness_Max.Name = "RadioButton_DP_Fullness_Max"
        Me.RadioButton_DP_Fullness_Max.UseVisualStyleBackColor = True
        '
        'RadioButton_DP_Fullness_Min
        '
        resources.ApplyResources(Me.RadioButton_DP_Fullness_Min, "RadioButton_DP_Fullness_Min")
        Me.RadioButton_DP_Fullness_Min.Name = "RadioButton_DP_Fullness_Min"
        Me.RadioButton_DP_Fullness_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_Fullness_Max
        '
        Me.NumericUpDown_DP_Fullness_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_Fullness_Max, "NumericUpDown_DP_Fullness_Max")
        Me.NumericUpDown_DP_Fullness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Fullness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_Fullness_Max.Name = "NumericUpDown_DP_Fullness_Max"
        '
        'NumericUpDown_DP_Fullness_Min
        '
        Me.NumericUpDown_DP_Fullness_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_Fullness_Min, "NumericUpDown_DP_Fullness_Min")
        Me.NumericUpDown_DP_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Fullness_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_DP_Fullness_Min.Name = "NumericUpDown_DP_Fullness_Min"
        '
        'RadioButton_DP_Elongation_Max
        '
        resources.ApplyResources(Me.RadioButton_DP_Elongation_Max, "RadioButton_DP_Elongation_Max")
        Me.RadioButton_DP_Elongation_Max.Name = "RadioButton_DP_Elongation_Max"
        Me.RadioButton_DP_Elongation_Max.UseVisualStyleBackColor = True
        '
        'RadioButton_DP_Elongation_Min
        '
        resources.ApplyResources(Me.RadioButton_DP_Elongation_Min, "RadioButton_DP_Elongation_Min")
        Me.RadioButton_DP_Elongation_Min.Name = "RadioButton_DP_Elongation_Min"
        Me.RadioButton_DP_Elongation_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DP_Elongation_Max
        '
        Me.NumericUpDown_DP_Elongation_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_Elongation_Max, "NumericUpDown_DP_Elongation_Max")
        Me.NumericUpDown_DP_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Elongation_Max.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_DP_Elongation_Max.Name = "NumericUpDown_DP_Elongation_Max"
        '
        'NumericUpDown_DP_Elongation_Min
        '
        Me.NumericUpDown_DP_Elongation_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_DP_Elongation_Min, "NumericUpDown_DP_Elongation_Min")
        Me.NumericUpDown_DP_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_DP_Elongation_Min.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_DP_Elongation_Min.Name = "NumericUpDown_DP_Elongation_Min"
        '
        'GroupBox_BP_Characteristics
        '
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.Label49)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_MaxGray_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_StdDev_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_StdDev_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_Compactness_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Compactness_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_MaxGray_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_MaxGray_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_GrayMean_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_GrayMean_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_MaxGray_Fullness_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_MaxGray_Fullness_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_Fullness_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_Fullness_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Fullness_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Fullness_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_Elongation_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.RadioButton_BP_Elongation_Min)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Elongation_Max)
        Me.GroupBox_BP_Characteristics.Controls.Add(Me.NumericUpDown_BP_Elongation_Min)
        resources.ApplyResources(Me.GroupBox_BP_Characteristics, "GroupBox_BP_Characteristics")
        Me.GroupBox_BP_Characteristics.Name = "GroupBox_BP_Characteristics"
        Me.GroupBox_BP_Characteristics.TabStop = False
        '
        'Label49
        '
        resources.ApplyResources(Me.Label49, "Label49")
        Me.Label49.Name = "Label49"
        '
        'NumericUpDown_BP_MaxGray_Max
        '
        resources.ApplyResources(Me.NumericUpDown_BP_MaxGray_Max, "NumericUpDown_BP_MaxGray_Max")
        Me.NumericUpDown_BP_MaxGray_Max.Maximum = New Decimal(New Integer() {200000000, 0, 0, 0})
        Me.NumericUpDown_BP_MaxGray_Max.Name = "NumericUpDown_BP_MaxGray_Max"
        '
        'NumericUpDown_BP_StdDev_Max
        '
        Me.NumericUpDown_BP_StdDev_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_StdDev_Max, "NumericUpDown_BP_StdDev_Max")
        Me.NumericUpDown_BP_StdDev_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_StdDev_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_StdDev_Max.Name = "NumericUpDown_BP_StdDev_Max"
        '
        'RadioButton_BP_StdDev_Max
        '
        resources.ApplyResources(Me.RadioButton_BP_StdDev_Max, "RadioButton_BP_StdDev_Max")
        Me.RadioButton_BP_StdDev_Max.Name = "RadioButton_BP_StdDev_Max"
        Me.RadioButton_BP_StdDev_Max.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_Compactness_Max
        '
        resources.ApplyResources(Me.RadioButton_BP_Compactness_Max, "RadioButton_BP_Compactness_Max")
        Me.RadioButton_BP_Compactness_Max.Name = "RadioButton_BP_Compactness_Max"
        Me.RadioButton_BP_Compactness_Max.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_Compactness_Max
        '
        Me.NumericUpDown_BP_Compactness_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_Compactness_Max, "NumericUpDown_BP_Compactness_Max")
        Me.NumericUpDown_BP_Compactness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Compactness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_Compactness_Max.Name = "NumericUpDown_BP_Compactness_Max"
        '
        'RadioButton_BP_MaxGray_Min
        '
        resources.ApplyResources(Me.RadioButton_BP_MaxGray_Min, "RadioButton_BP_MaxGray_Min")
        Me.RadioButton_BP_MaxGray_Min.Name = "RadioButton_BP_MaxGray_Min"
        Me.RadioButton_BP_MaxGray_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_MaxGray_Min
        '
        Me.NumericUpDown_BP_MaxGray_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_MaxGray_Min, "NumericUpDown_BP_MaxGray_Min")
        Me.NumericUpDown_BP_MaxGray_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_MaxGray_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_MaxGray_Min.Name = "NumericUpDown_BP_MaxGray_Min"
        '
        'RadioButton_BP_GrayMean_Min
        '
        resources.ApplyResources(Me.RadioButton_BP_GrayMean_Min, "RadioButton_BP_GrayMean_Min")
        Me.RadioButton_BP_GrayMean_Min.Name = "RadioButton_BP_GrayMean_Min"
        Me.RadioButton_BP_GrayMean_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_GrayMean_Min
        '
        Me.NumericUpDown_BP_GrayMean_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_GrayMean_Min, "NumericUpDown_BP_GrayMean_Min")
        Me.NumericUpDown_BP_GrayMean_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_GrayMean_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_GrayMean_Min.Name = "NumericUpDown_BP_GrayMean_Min"
        '
        'RadioButton_BP_MaxGray_Fullness_Min
        '
        resources.ApplyResources(Me.RadioButton_BP_MaxGray_Fullness_Min, "RadioButton_BP_MaxGray_Fullness_Min")
        Me.RadioButton_BP_MaxGray_Fullness_Min.Name = "RadioButton_BP_MaxGray_Fullness_Min"
        Me.RadioButton_BP_MaxGray_Fullness_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_MaxGray_Fullness_Min
        '
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_MaxGray_Fullness_Min, "NumericUpDown_BP_MaxGray_Fullness_Min")
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BP_MaxGray_Fullness_Min.Name = "NumericUpDown_BP_MaxGray_Fullness_Min"
        '
        'RadioButton_BP_Fullness_Max
        '
        resources.ApplyResources(Me.RadioButton_BP_Fullness_Max, "RadioButton_BP_Fullness_Max")
        Me.RadioButton_BP_Fullness_Max.Name = "RadioButton_BP_Fullness_Max"
        Me.RadioButton_BP_Fullness_Max.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_Fullness_Min
        '
        resources.ApplyResources(Me.RadioButton_BP_Fullness_Min, "RadioButton_BP_Fullness_Min")
        Me.RadioButton_BP_Fullness_Min.Name = "RadioButton_BP_Fullness_Min"
        Me.RadioButton_BP_Fullness_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_Fullness_Max
        '
        Me.NumericUpDown_BP_Fullness_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_Fullness_Max, "NumericUpDown_BP_Fullness_Max")
        Me.NumericUpDown_BP_Fullness_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Fullness_Max.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_Fullness_Max.Name = "NumericUpDown_BP_Fullness_Max"
        '
        'NumericUpDown_BP_Fullness_Min
        '
        Me.NumericUpDown_BP_Fullness_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_Fullness_Min, "NumericUpDown_BP_Fullness_Min")
        Me.NumericUpDown_BP_Fullness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Fullness_Min.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BP_Fullness_Min.Name = "NumericUpDown_BP_Fullness_Min"
        '
        'RadioButton_BP_Elongation_Max
        '
        resources.ApplyResources(Me.RadioButton_BP_Elongation_Max, "RadioButton_BP_Elongation_Max")
        Me.RadioButton_BP_Elongation_Max.Name = "RadioButton_BP_Elongation_Max"
        Me.RadioButton_BP_Elongation_Max.UseVisualStyleBackColor = True
        '
        'RadioButton_BP_Elongation_Min
        '
        resources.ApplyResources(Me.RadioButton_BP_Elongation_Min, "RadioButton_BP_Elongation_Min")
        Me.RadioButton_BP_Elongation_Min.Name = "RadioButton_BP_Elongation_Min"
        Me.RadioButton_BP_Elongation_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BP_Elongation_Max
        '
        Me.NumericUpDown_BP_Elongation_Max.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_Elongation_Max, "NumericUpDown_BP_Elongation_Max")
        Me.NumericUpDown_BP_Elongation_Max.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Elongation_Max.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_BP_Elongation_Max.Name = "NumericUpDown_BP_Elongation_Max"
        '
        'NumericUpDown_BP_Elongation_Min
        '
        Me.NumericUpDown_BP_Elongation_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BP_Elongation_Min, "NumericUpDown_BP_Elongation_Min")
        Me.NumericUpDown_BP_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BP_Elongation_Min.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_BP_Elongation_Min.Name = "NumericUpDown_BP_Elongation_Min"
        '
        'TabPage_GSBP
        '
        Me.TabPage_GSBP.Controls.Add(Me.CheckBox_BLDP_Enable)
        Me.TabPage_GSBP.Controls.Add(Me.GroupBox_BLDPCommonSetting)
        Me.TabPage_GSBP.Controls.Add(Me.GroupBox_BLDP)
        Me.TabPage_GSBP.Controls.Add(Me.CheckBox_GSBP_Enable)
        Me.TabPage_GSBP.Controls.Add(Me.GroupBox_GSBPCommonSetting)
        Me.TabPage_GSBP.Controls.Add(Me.GroupBox_GSBP)
        resources.ApplyResources(Me.TabPage_GSBP, "TabPage_GSBP")
        Me.TabPage_GSBP.Name = "TabPage_GSBP"
        Me.TabPage_GSBP.UseVisualStyleBackColor = True
        '
        'CheckBox_BLDP_Enable
        '
        resources.ApplyResources(Me.CheckBox_BLDP_Enable, "CheckBox_BLDP_Enable")
        Me.CheckBox_BLDP_Enable.Name = "CheckBox_BLDP_Enable"
        Me.CheckBox_BLDP_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_BLDPCommonSetting
        '
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_Elongation_Min)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_Elongation_Max)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_Elongation_Max)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_Elongation_Min)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_Fatness_Min)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_Fatness_Min)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_OverNum)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_OverNum)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_Scratch_Length)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_Scratch_Length)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_RangeY)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_RangeY)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_RangeX)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_RangeX)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_Count_Min)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_Count_Min)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_AreaMin)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.RadioButton_BLDP_AreaMax)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_AreaMin)
        Me.GroupBox_BLDPCommonSetting.Controls.Add(Me.NumericUpDown_BLDP_AreaMax)
        resources.ApplyResources(Me.GroupBox_BLDPCommonSetting, "GroupBox_BLDPCommonSetting")
        Me.GroupBox_BLDPCommonSetting.Name = "GroupBox_BLDPCommonSetting"
        Me.GroupBox_BLDPCommonSetting.TabStop = False
        '
        'NumericUpDown_BLDP_Elongation_Min
        '
        Me.NumericUpDown_BLDP_Elongation_Min.DecimalPlaces = 2
        resources.ApplyResources(Me.NumericUpDown_BLDP_Elongation_Min, "NumericUpDown_BLDP_Elongation_Min")
        Me.NumericUpDown_BLDP_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BLDP_Elongation_Min.Maximum = New Decimal(New Integer() {200000, 0, 0, 0})
        Me.NumericUpDown_BLDP_Elongation_Min.Name = "NumericUpDown_BLDP_Elongation_Min"
        Me.NumericUpDown_BLDP_Elongation_Min.Value = New Decimal(New Integer() {3, 0, 0, 131072})
        '
        'NumericUpDown_BLDP_Elongation_Max
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_Elongation_Max, "NumericUpDown_BLDP_Elongation_Max")
        Me.NumericUpDown_BLDP_Elongation_Max.Maximum = New Decimal(New Integer() {200000, 0, 0, 0})
        Me.NumericUpDown_BLDP_Elongation_Max.Name = "NumericUpDown_BLDP_Elongation_Max"
        Me.NumericUpDown_BLDP_Elongation_Max.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'RadioButton_BLDP_Elongation_Max
        '
        resources.ApplyResources(Me.RadioButton_BLDP_Elongation_Max, "RadioButton_BLDP_Elongation_Max")
        Me.RadioButton_BLDP_Elongation_Max.Name = "RadioButton_BLDP_Elongation_Max"
        Me.RadioButton_BLDP_Elongation_Max.TabStop = True
        Me.RadioButton_BLDP_Elongation_Max.UseVisualStyleBackColor = True
        '
        'RadioButton_BLDP_Elongation_Min
        '
        resources.ApplyResources(Me.RadioButton_BLDP_Elongation_Min, "RadioButton_BLDP_Elongation_Min")
        Me.RadioButton_BLDP_Elongation_Min.Name = "RadioButton_BLDP_Elongation_Min"
        Me.RadioButton_BLDP_Elongation_Min.TabStop = True
        Me.RadioButton_BLDP_Elongation_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_Fatness_Min
        '
        Me.NumericUpDown_BLDP_Fatness_Min.DecimalPlaces = 1
        resources.ApplyResources(Me.NumericUpDown_BLDP_Fatness_Min, "NumericUpDown_BLDP_Fatness_Min")
        Me.NumericUpDown_BLDP_Fatness_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BLDP_Fatness_Min.Maximum = New Decimal(New Integer() {200000, 0, 0, 0})
        Me.NumericUpDown_BLDP_Fatness_Min.Minimum = New Decimal(New Integer() {1, 0, 0, 65536})
        Me.NumericUpDown_BLDP_Fatness_Min.Name = "NumericUpDown_BLDP_Fatness_Min"
        Me.NumericUpDown_BLDP_Fatness_Min.Value = New Decimal(New Integer() {21, 0, 0, 65536})
        '
        'RadioButton_BLDP_Fatness_Min
        '
        resources.ApplyResources(Me.RadioButton_BLDP_Fatness_Min, "RadioButton_BLDP_Fatness_Min")
        Me.RadioButton_BLDP_Fatness_Min.Name = "RadioButton_BLDP_Fatness_Min"
        Me.RadioButton_BLDP_Fatness_Min.TabStop = True
        Me.RadioButton_BLDP_Fatness_Min.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_OverNum
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_OverNum, "NumericUpDown_BLDP_OverNum")
        Me.NumericUpDown_BLDP_OverNum.Maximum = New Decimal(New Integer() {200000, 0, 0, 0})
        Me.NumericUpDown_BLDP_OverNum.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BLDP_OverNum.Name = "NumericUpDown_BLDP_OverNum"
        Me.NumericUpDown_BLDP_OverNum.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'RadioButton_BLDP_OverNum
        '
        resources.ApplyResources(Me.RadioButton_BLDP_OverNum, "RadioButton_BLDP_OverNum")
        Me.RadioButton_BLDP_OverNum.Name = "RadioButton_BLDP_OverNum"
        Me.RadioButton_BLDP_OverNum.TabStop = True
        Me.RadioButton_BLDP_OverNum.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_Scratch_Length
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_Scratch_Length, "NumericUpDown_BLDP_Scratch_Length")
        Me.NumericUpDown_BLDP_Scratch_Length.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_BLDP_Scratch_Length.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BLDP_Scratch_Length.Name = "NumericUpDown_BLDP_Scratch_Length"
        Me.NumericUpDown_BLDP_Scratch_Length.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'RadioButton_BLDP_Scratch_Length
        '
        resources.ApplyResources(Me.RadioButton_BLDP_Scratch_Length, "RadioButton_BLDP_Scratch_Length")
        Me.RadioButton_BLDP_Scratch_Length.Name = "RadioButton_BLDP_Scratch_Length"
        Me.RadioButton_BLDP_Scratch_Length.TabStop = True
        Me.RadioButton_BLDP_Scratch_Length.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_RangeY
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_RangeY, "NumericUpDown_BLDP_RangeY")
        Me.NumericUpDown_BLDP_RangeY.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_BLDP_RangeY.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BLDP_RangeY.Name = "NumericUpDown_BLDP_RangeY"
        Me.NumericUpDown_BLDP_RangeY.Value = New Decimal(New Integer() {200, 0, 0, 0})
        '
        'RadioButton_BLDP_RangeY
        '
        resources.ApplyResources(Me.RadioButton_BLDP_RangeY, "RadioButton_BLDP_RangeY")
        Me.RadioButton_BLDP_RangeY.Name = "RadioButton_BLDP_RangeY"
        Me.RadioButton_BLDP_RangeY.TabStop = True
        Me.RadioButton_BLDP_RangeY.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_RangeX
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_RangeX, "NumericUpDown_BLDP_RangeX")
        Me.NumericUpDown_BLDP_RangeX.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_BLDP_RangeX.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BLDP_RangeX.Name = "NumericUpDown_BLDP_RangeX"
        Me.NumericUpDown_BLDP_RangeX.Value = New Decimal(New Integer() {200, 0, 0, 0})
        '
        'RadioButton_BLDP_RangeX
        '
        resources.ApplyResources(Me.RadioButton_BLDP_RangeX, "RadioButton_BLDP_RangeX")
        Me.RadioButton_BLDP_RangeX.Name = "RadioButton_BLDP_RangeX"
        Me.RadioButton_BLDP_RangeX.TabStop = True
        Me.RadioButton_BLDP_RangeX.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_Count_Min
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_Count_Min, "NumericUpDown_BLDP_Count_Min")
        Me.NumericUpDown_BLDP_Count_Min.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_BLDP_Count_Min.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_BLDP_Count_Min.Name = "NumericUpDown_BLDP_Count_Min"
        Me.NumericUpDown_BLDP_Count_Min.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'RadioButton_BLDP_Count_Min
        '
        resources.ApplyResources(Me.RadioButton_BLDP_Count_Min, "RadioButton_BLDP_Count_Min")
        Me.RadioButton_BLDP_Count_Min.Name = "RadioButton_BLDP_Count_Min"
        Me.RadioButton_BLDP_Count_Min.TabStop = True
        Me.RadioButton_BLDP_Count_Min.UseVisualStyleBackColor = True
        '
        'RadioButton_BLDP_AreaMin
        '
        resources.ApplyResources(Me.RadioButton_BLDP_AreaMin, "RadioButton_BLDP_AreaMin")
        Me.RadioButton_BLDP_AreaMin.Name = "RadioButton_BLDP_AreaMin"
        Me.RadioButton_BLDP_AreaMin.UseVisualStyleBackColor = True
        '
        'RadioButton_BLDP_AreaMax
        '
        resources.ApplyResources(Me.RadioButton_BLDP_AreaMax, "RadioButton_BLDP_AreaMax")
        Me.RadioButton_BLDP_AreaMax.Name = "RadioButton_BLDP_AreaMax"
        Me.RadioButton_BLDP_AreaMax.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_AreaMin
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_AreaMin, "NumericUpDown_BLDP_AreaMin")
        Me.NumericUpDown_BLDP_AreaMin.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_BLDP_AreaMin.Name = "NumericUpDown_BLDP_AreaMin"
        '
        'NumericUpDown_BLDP_AreaMax
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_AreaMax, "NumericUpDown_BLDP_AreaMax")
        Me.NumericUpDown_BLDP_AreaMax.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_BLDP_AreaMax.Minimum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDown_BLDP_AreaMax.Name = "NumericUpDown_BLDP_AreaMax"
        Me.NumericUpDown_BLDP_AreaMax.Value = New Decimal(New Integer() {250, 0, 0, 0})
        '
        'GroupBox_BLDP
        '
        Me.GroupBox_BLDP.Controls.Add(Me.NumericUpDown_BLDP_EnhanceCount)
        Me.GroupBox_BLDP.Controls.Add(Me.RadioButton_BLDP_EnhanceCount)
        Me.GroupBox_BLDP.Controls.Add(Me.NumericUpDown_BLDP_ThresholdRim)
        Me.GroupBox_BLDP.Controls.Add(Me.RadioButton_BLDP_Threshold)
        Me.GroupBox_BLDP.Controls.Add(Me.NumericUpDown_BLDP_Threshold)
        Me.GroupBox_BLDP.Controls.Add(Me.RadioButton_BLDP_RimThreshold)
        resources.ApplyResources(Me.GroupBox_BLDP, "GroupBox_BLDP")
        Me.GroupBox_BLDP.Name = "GroupBox_BLDP"
        Me.GroupBox_BLDP.TabStop = False
        '
        'NumericUpDown_BLDP_EnhanceCount
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_EnhanceCount, "NumericUpDown_BLDP_EnhanceCount")
        Me.NumericUpDown_BLDP_EnhanceCount.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BLDP_EnhanceCount.Name = "NumericUpDown_BLDP_EnhanceCount"
        '
        'RadioButton_BLDP_EnhanceCount
        '
        resources.ApplyResources(Me.RadioButton_BLDP_EnhanceCount, "RadioButton_BLDP_EnhanceCount")
        Me.RadioButton_BLDP_EnhanceCount.Name = "RadioButton_BLDP_EnhanceCount"
        Me.RadioButton_BLDP_EnhanceCount.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_ThresholdRim
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_ThresholdRim, "NumericUpDown_BLDP_ThresholdRim")
        Me.NumericUpDown_BLDP_ThresholdRim.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BLDP_ThresholdRim.Name = "NumericUpDown_BLDP_ThresholdRim"
        '
        'RadioButton_BLDP_Threshold
        '
        resources.ApplyResources(Me.RadioButton_BLDP_Threshold, "RadioButton_BLDP_Threshold")
        Me.RadioButton_BLDP_Threshold.Name = "RadioButton_BLDP_Threshold"
        Me.RadioButton_BLDP_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BLDP_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_BLDP_Threshold, "NumericUpDown_BLDP_Threshold")
        Me.NumericUpDown_BLDP_Threshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BLDP_Threshold.Name = "NumericUpDown_BLDP_Threshold"
        '
        'RadioButton_BLDP_RimThreshold
        '
        resources.ApplyResources(Me.RadioButton_BLDP_RimThreshold, "RadioButton_BLDP_RimThreshold")
        Me.RadioButton_BLDP_RimThreshold.Name = "RadioButton_BLDP_RimThreshold"
        Me.RadioButton_BLDP_RimThreshold.UseVisualStyleBackColor = True
        '
        'CheckBox_GSBP_Enable
        '
        resources.ApplyResources(Me.CheckBox_GSBP_Enable, "CheckBox_GSBP_Enable")
        Me.CheckBox_GSBP_Enable.Name = "CheckBox_GSBP_Enable"
        Me.CheckBox_GSBP_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_GSBPCommonSetting
        '
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_GrayMax_Low)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_GrayMax_High)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_GrayMax_Low)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_GrayMax_High)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_NumOfHoles)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_NumOfHoles)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_OverNum)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_OverNum)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_Scratch_Length)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_Scratch_Length)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_RangeY)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_RangeY)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_RangeX)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_RangeX)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_Count_Min)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_Count_Min)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_AreaMin)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.RadioButton_GSBP_AreaMax)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_AreaMin)
        Me.GroupBox_GSBPCommonSetting.Controls.Add(Me.NumericUpDown_GSBP_AreaMax)
        resources.ApplyResources(Me.GroupBox_GSBPCommonSetting, "GroupBox_GSBPCommonSetting")
        Me.GroupBox_GSBPCommonSetting.Name = "GroupBox_GSBPCommonSetting"
        Me.GroupBox_GSBPCommonSetting.TabStop = False
        '
        'NumericUpDown_GSBP_GrayMax_Low
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_GrayMax_Low, "NumericUpDown_GSBP_GrayMax_Low")
        Me.NumericUpDown_GSBP_GrayMax_Low.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown_GSBP_GrayMax_Low.Name = "NumericUpDown_GSBP_GrayMax_Low"
        '
        'NumericUpDown_GSBP_GrayMax_High
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_GrayMax_High, "NumericUpDown_GSBP_GrayMax_High")
        Me.NumericUpDown_GSBP_GrayMax_High.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown_GSBP_GrayMax_High.Name = "NumericUpDown_GSBP_GrayMax_High"
        '
        'RadioButton_GSBP_GrayMax_Low
        '
        resources.ApplyResources(Me.RadioButton_GSBP_GrayMax_Low, "RadioButton_GSBP_GrayMax_Low")
        Me.RadioButton_GSBP_GrayMax_Low.Name = "RadioButton_GSBP_GrayMax_Low"
        Me.RadioButton_GSBP_GrayMax_Low.UseVisualStyleBackColor = True
        '
        'RadioButton_GSBP_GrayMax_High
        '
        resources.ApplyResources(Me.RadioButton_GSBP_GrayMax_High, "RadioButton_GSBP_GrayMax_High")
        Me.RadioButton_GSBP_GrayMax_High.Name = "RadioButton_GSBP_GrayMax_High"
        Me.RadioButton_GSBP_GrayMax_High.UseVisualStyleBackColor = True
        '
        'RadioButton_GSBP_NumOfHoles
        '
        resources.ApplyResources(Me.RadioButton_GSBP_NumOfHoles, "RadioButton_GSBP_NumOfHoles")
        Me.RadioButton_GSBP_NumOfHoles.Name = "RadioButton_GSBP_NumOfHoles"
        Me.RadioButton_GSBP_NumOfHoles.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GSBP_NumOfHoles
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_NumOfHoles, "NumericUpDown_GSBP_NumOfHoles")
        Me.NumericUpDown_GSBP_NumOfHoles.Maximum = New Decimal(New Integer() {1500, 0, 0, 0})
        Me.NumericUpDown_GSBP_NumOfHoles.Name = "NumericUpDown_GSBP_NumOfHoles"
        '
        'NumericUpDown_GSBP_OverNum
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_OverNum, "NumericUpDown_GSBP_OverNum")
        Me.NumericUpDown_GSBP_OverNum.Maximum = New Decimal(New Integer() {200000, 0, 0, 0})
        Me.NumericUpDown_GSBP_OverNum.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_GSBP_OverNum.Name = "NumericUpDown_GSBP_OverNum"
        Me.NumericUpDown_GSBP_OverNum.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'RadioButton_GSBP_OverNum
        '
        resources.ApplyResources(Me.RadioButton_GSBP_OverNum, "RadioButton_GSBP_OverNum")
        Me.RadioButton_GSBP_OverNum.Name = "RadioButton_GSBP_OverNum"
        Me.RadioButton_GSBP_OverNum.TabStop = True
        Me.RadioButton_GSBP_OverNum.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GSBP_Scratch_Length
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_Scratch_Length, "NumericUpDown_GSBP_Scratch_Length")
        Me.NumericUpDown_GSBP_Scratch_Length.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_GSBP_Scratch_Length.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_GSBP_Scratch_Length.Name = "NumericUpDown_GSBP_Scratch_Length"
        Me.NumericUpDown_GSBP_Scratch_Length.Value = New Decimal(New Integer() {100, 0, 0, 0})
        '
        'RadioButton_GSBP_Scratch_Length
        '
        resources.ApplyResources(Me.RadioButton_GSBP_Scratch_Length, "RadioButton_GSBP_Scratch_Length")
        Me.RadioButton_GSBP_Scratch_Length.Name = "RadioButton_GSBP_Scratch_Length"
        Me.RadioButton_GSBP_Scratch_Length.TabStop = True
        Me.RadioButton_GSBP_Scratch_Length.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GSBP_RangeY
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_RangeY, "NumericUpDown_GSBP_RangeY")
        Me.NumericUpDown_GSBP_RangeY.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_GSBP_RangeY.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_GSBP_RangeY.Name = "NumericUpDown_GSBP_RangeY"
        Me.NumericUpDown_GSBP_RangeY.Value = New Decimal(New Integer() {200, 0, 0, 0})
        '
        'RadioButton_GSBP_RangeY
        '
        resources.ApplyResources(Me.RadioButton_GSBP_RangeY, "RadioButton_GSBP_RangeY")
        Me.RadioButton_GSBP_RangeY.Name = "RadioButton_GSBP_RangeY"
        Me.RadioButton_GSBP_RangeY.TabStop = True
        Me.RadioButton_GSBP_RangeY.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GSBP_RangeX
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_RangeX, "NumericUpDown_GSBP_RangeX")
        Me.NumericUpDown_GSBP_RangeX.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_GSBP_RangeX.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_GSBP_RangeX.Name = "NumericUpDown_GSBP_RangeX"
        Me.NumericUpDown_GSBP_RangeX.Value = New Decimal(New Integer() {200, 0, 0, 0})
        '
        'RadioButton_GSBP_RangeX
        '
        resources.ApplyResources(Me.RadioButton_GSBP_RangeX, "RadioButton_GSBP_RangeX")
        Me.RadioButton_GSBP_RangeX.Name = "RadioButton_GSBP_RangeX"
        Me.RadioButton_GSBP_RangeX.TabStop = True
        Me.RadioButton_GSBP_RangeX.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GSBP_Count_Min
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_Count_Min, "NumericUpDown_GSBP_Count_Min")
        Me.NumericUpDown_GSBP_Count_Min.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_GSBP_Count_Min.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_GSBP_Count_Min.Name = "NumericUpDown_GSBP_Count_Min"
        Me.NumericUpDown_GSBP_Count_Min.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'RadioButton_GSBP_Count_Min
        '
        resources.ApplyResources(Me.RadioButton_GSBP_Count_Min, "RadioButton_GSBP_Count_Min")
        Me.RadioButton_GSBP_Count_Min.Name = "RadioButton_GSBP_Count_Min"
        Me.RadioButton_GSBP_Count_Min.TabStop = True
        Me.RadioButton_GSBP_Count_Min.UseVisualStyleBackColor = True
        '
        'RadioButton_GSBP_AreaMin
        '
        resources.ApplyResources(Me.RadioButton_GSBP_AreaMin, "RadioButton_GSBP_AreaMin")
        Me.RadioButton_GSBP_AreaMin.Name = "RadioButton_GSBP_AreaMin"
        Me.RadioButton_GSBP_AreaMin.UseVisualStyleBackColor = True
        '
        'RadioButton_GSBP_AreaMax
        '
        resources.ApplyResources(Me.RadioButton_GSBP_AreaMax, "RadioButton_GSBP_AreaMax")
        Me.RadioButton_GSBP_AreaMax.Name = "RadioButton_GSBP_AreaMax"
        Me.RadioButton_GSBP_AreaMax.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GSBP_AreaMin
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_AreaMin, "NumericUpDown_GSBP_AreaMin")
        Me.NumericUpDown_GSBP_AreaMin.Maximum = New Decimal(New Integer() {1500, 0, 0, 0})
        Me.NumericUpDown_GSBP_AreaMin.Name = "NumericUpDown_GSBP_AreaMin"
        '
        'NumericUpDown_GSBP_AreaMax
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_AreaMax, "NumericUpDown_GSBP_AreaMax")
        Me.NumericUpDown_GSBP_AreaMax.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_GSBP_AreaMax.Minimum = New Decimal(New Integer() {50, 0, 0, 0})
        Me.NumericUpDown_GSBP_AreaMax.Name = "NumericUpDown_GSBP_AreaMax"
        Me.NumericUpDown_GSBP_AreaMax.Value = New Decimal(New Integer() {250, 0, 0, 0})
        '
        'GroupBox_GSBP
        '
        Me.GroupBox_GSBP.Controls.Add(Me.NumericUpDown_GSBP_ThresholdRim)
        Me.GroupBox_GSBP.Controls.Add(Me.RadioButton_GSBP_Threshold)
        Me.GroupBox_GSBP.Controls.Add(Me.NumericUpDown_GSBP_Threshold)
        Me.GroupBox_GSBP.Controls.Add(Me.RadioButton_GSBP_RimThreshold)
        resources.ApplyResources(Me.GroupBox_GSBP, "GroupBox_GSBP")
        Me.GroupBox_GSBP.Name = "GroupBox_GSBP"
        Me.GroupBox_GSBP.TabStop = False
        '
        'NumericUpDown_GSBP_ThresholdRim
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_ThresholdRim, "NumericUpDown_GSBP_ThresholdRim")
        Me.NumericUpDown_GSBP_ThresholdRim.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GSBP_ThresholdRim.Name = "NumericUpDown_GSBP_ThresholdRim"
        '
        'RadioButton_GSBP_Threshold
        '
        resources.ApplyResources(Me.RadioButton_GSBP_Threshold, "RadioButton_GSBP_Threshold")
        Me.RadioButton_GSBP_Threshold.Name = "RadioButton_GSBP_Threshold"
        Me.RadioButton_GSBP_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GSBP_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_GSBP_Threshold, "NumericUpDown_GSBP_Threshold")
        Me.NumericUpDown_GSBP_Threshold.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GSBP_Threshold.Name = "NumericUpDown_GSBP_Threshold"
        '
        'RadioButton_GSBP_RimThreshold
        '
        resources.ApplyResources(Me.RadioButton_GSBP_RimThreshold, "RadioButton_GSBP_RimThreshold")
        Me.RadioButton_GSBP_RimThreshold.Name = "RadioButton_GSBP_RimThreshold"
        Me.RadioButton_GSBP_RimThreshold.UseVisualStyleBackColor = True
        '
        'TabPage_Line
        '
        Me.TabPage_Line.BackColor = System.Drawing.Color.White
        Me.TabPage_Line.Controls.Add(Me.GroupBox_DLine)
        Me.TabPage_Line.Controls.Add(Me.NumericUpDown_LeakPointRadius)
        Me.TabPage_Line.Controls.Add(Me.NumericUpDown_Line_Elongation_Min)
        Me.TabPage_Line.Controls.Add(Me.Label62)
        Me.TabPage_Line.Controls.Add(Me.Label43)
        Me.TabPage_Line.Controls.Add(Me.CheckBox_Filter_VH_Scratch)
        Me.TabPage_Line.Controls.Add(Me.CheckBox_HalfScreen_Enable)
        Me.TabPage_Line.Controls.Add(Me.CheckBox_DLine_Enable)
        Me.TabPage_Line.Controls.Add(Me.CheckBox_BLine_Enable)
        Me.TabPage_Line.Controls.Add(Me.GroupBox_BLine)
        Me.TabPage_Line.Controls.Add(Me.CheckBox_VLine_NotAddToOutput)
        Me.TabPage_Line.Controls.Add(Me.CheckBox_HLine_NotAddToOutput)
        Me.TabPage_Line.Controls.Add(Me.GroupBox_LineCommonSetting)
        Me.TabPage_Line.Controls.Add(Me.GroupBox_MeanDiff)
        Me.TabPage_Line.Controls.Add(Me.CheckBox_Line_Enable)
        resources.ApplyResources(Me.TabPage_Line, "TabPage_Line")
        Me.TabPage_Line.Name = "TabPage_Line"
        Me.TabPage_Line.UseVisualStyleBackColor = True
        '
        'GroupBox_DLine
        '
        Me.GroupBox_DLine.Controls.Add(Me.RadioButton_DL_Threshold)
        Me.GroupBox_DLine.Controls.Add(Me.NumericUpDown_DL_Threshold)
        Me.GroupBox_DLine.Controls.Add(Me.TrackBar_DL_Threshold)
        Me.GroupBox_DLine.Controls.Add(Me.Label18)
        Me.GroupBox_DLine.Controls.Add(Me.NumericUpDown_DL_RimThreshold)
        Me.GroupBox_DLine.Controls.Add(Me.TrackBar_DL_RimThreshold)
        resources.ApplyResources(Me.GroupBox_DLine, "GroupBox_DLine")
        Me.GroupBox_DLine.Name = "GroupBox_DLine"
        Me.GroupBox_DLine.TabStop = False
        '
        'RadioButton_DL_Threshold
        '
        resources.ApplyResources(Me.RadioButton_DL_Threshold, "RadioButton_DL_Threshold")
        Me.RadioButton_DL_Threshold.Name = "RadioButton_DL_Threshold"
        Me.RadioButton_DL_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_DL_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_DL_Threshold, "NumericUpDown_DL_Threshold")
        Me.NumericUpDown_DL_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_DL_Threshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_DL_Threshold.Name = "NumericUpDown_DL_Threshold"
        '
        'TrackBar_DL_Threshold
        '
        Me.TrackBar_DL_Threshold.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.TrackBar_DL_Threshold, "TrackBar_DL_Threshold")
        Me.TrackBar_DL_Threshold.Maximum = 4095
        Me.TrackBar_DL_Threshold.Name = "TrackBar_DL_Threshold"
        Me.TrackBar_DL_Threshold.TickFrequency = 495
        Me.TrackBar_DL_Threshold.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'Label18
        '
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        '
        'NumericUpDown_DL_RimThreshold
        '
        Me.NumericUpDown_DL_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        resources.ApplyResources(Me.NumericUpDown_DL_RimThreshold, "NumericUpDown_DL_RimThreshold")
        Me.NumericUpDown_DL_RimThreshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_DL_RimThreshold.Name = "NumericUpDown_DL_RimThreshold"
        '
        'TrackBar_DL_RimThreshold
        '
        Me.TrackBar_DL_RimThreshold.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.TrackBar_DL_RimThreshold, "TrackBar_DL_RimThreshold")
        Me.TrackBar_DL_RimThreshold.Maximum = 4095
        Me.TrackBar_DL_RimThreshold.Name = "TrackBar_DL_RimThreshold"
        Me.TrackBar_DL_RimThreshold.TickFrequency = 495
        Me.TrackBar_DL_RimThreshold.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'NumericUpDown_LeakPointRadius
        '
        resources.ApplyResources(Me.NumericUpDown_LeakPointRadius, "NumericUpDown_LeakPointRadius")
        Me.NumericUpDown_LeakPointRadius.Name = "NumericUpDown_LeakPointRadius"
        '
        'NumericUpDown_Line_Elongation_Min
        '
        Me.NumericUpDown_Line_Elongation_Min.DecimalPlaces = 1
        Me.NumericUpDown_Line_Elongation_Min.Increment = New Decimal(New Integer() {1, 0, 0, 65536})
        resources.ApplyResources(Me.NumericUpDown_Line_Elongation_Min, "NumericUpDown_Line_Elongation_Min")
        Me.NumericUpDown_Line_Elongation_Min.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_Line_Elongation_Min.Name = "NumericUpDown_Line_Elongation_Min"
        Me.NumericUpDown_Line_Elongation_Min.Value = New Decimal(New Integer() {9999, 0, 0, 0})
        '
        'Label62
        '
        resources.ApplyResources(Me.Label62, "Label62")
        Me.Label62.Name = "Label62"
        '
        'Label43
        '
        resources.ApplyResources(Me.Label43, "Label43")
        Me.Label43.Name = "Label43"
        '
        'CheckBox_Filter_VH_Scratch
        '
        resources.ApplyResources(Me.CheckBox_Filter_VH_Scratch, "CheckBox_Filter_VH_Scratch")
        Me.CheckBox_Filter_VH_Scratch.Name = "CheckBox_Filter_VH_Scratch"
        Me.CheckBox_Filter_VH_Scratch.UseVisualStyleBackColor = True
        '
        'CheckBox_HalfScreen_Enable
        '
        resources.ApplyResources(Me.CheckBox_HalfScreen_Enable, "CheckBox_HalfScreen_Enable")
        Me.CheckBox_HalfScreen_Enable.Name = "CheckBox_HalfScreen_Enable"
        Me.CheckBox_HalfScreen_Enable.UseVisualStyleBackColor = True
        '
        'CheckBox_DLine_Enable
        '
        resources.ApplyResources(Me.CheckBox_DLine_Enable, "CheckBox_DLine_Enable")
        Me.CheckBox_DLine_Enable.Name = "CheckBox_DLine_Enable"
        Me.CheckBox_DLine_Enable.UseVisualStyleBackColor = True
        '
        'CheckBox_BLine_Enable
        '
        resources.ApplyResources(Me.CheckBox_BLine_Enable, "CheckBox_BLine_Enable")
        Me.CheckBox_BLine_Enable.Name = "CheckBox_BLine_Enable"
        Me.CheckBox_BLine_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_BLine
        '
        Me.GroupBox_BLine.Controls.Add(Me.Label7)
        Me.GroupBox_BLine.Controls.Add(Me.TrackBar_BL_RimThreshold)
        Me.GroupBox_BLine.Controls.Add(Me.NumericUpDown_BL_RimThreshold)
        Me.GroupBox_BLine.Controls.Add(Me.RadioButton_BL_Threshold)
        Me.GroupBox_BLine.Controls.Add(Me.NumericUpDown_BL_Threshold)
        Me.GroupBox_BLine.Controls.Add(Me.TrackBar_BL_Threshold)
        resources.ApplyResources(Me.GroupBox_BLine, "GroupBox_BLine")
        Me.GroupBox_BLine.Name = "GroupBox_BLine"
        Me.GroupBox_BLine.TabStop = False
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'TrackBar_BL_RimThreshold
        '
        Me.TrackBar_BL_RimThreshold.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.TrackBar_BL_RimThreshold, "TrackBar_BL_RimThreshold")
        Me.TrackBar_BL_RimThreshold.Maximum = 4095
        Me.TrackBar_BL_RimThreshold.Name = "TrackBar_BL_RimThreshold"
        Me.TrackBar_BL_RimThreshold.TickFrequency = 495
        Me.TrackBar_BL_RimThreshold.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'NumericUpDown_BL_RimThreshold
        '
        Me.NumericUpDown_BL_RimThreshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        resources.ApplyResources(Me.NumericUpDown_BL_RimThreshold, "NumericUpDown_BL_RimThreshold")
        Me.NumericUpDown_BL_RimThreshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_BL_RimThreshold.Name = "NumericUpDown_BL_RimThreshold"
        '
        'RadioButton_BL_Threshold
        '
        resources.ApplyResources(Me.RadioButton_BL_Threshold, "RadioButton_BL_Threshold")
        Me.RadioButton_BL_Threshold.Name = "RadioButton_BL_Threshold"
        Me.RadioButton_BL_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_BL_Threshold
        '
        resources.ApplyResources(Me.NumericUpDown_BL_Threshold, "NumericUpDown_BL_Threshold")
        Me.NumericUpDown_BL_Threshold.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        Me.NumericUpDown_BL_Threshold.Maximum = New Decimal(New Integer() {40950, 0, 0, 0})
        Me.NumericUpDown_BL_Threshold.Name = "NumericUpDown_BL_Threshold"
        '
        'TrackBar_BL_Threshold
        '
        Me.TrackBar_BL_Threshold.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.TrackBar_BL_Threshold, "TrackBar_BL_Threshold")
        Me.TrackBar_BL_Threshold.Maximum = 4095
        Me.TrackBar_BL_Threshold.Name = "TrackBar_BL_Threshold"
        Me.TrackBar_BL_Threshold.TickFrequency = 495
        Me.TrackBar_BL_Threshold.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'CheckBox_VLine_NotAddToOutput
        '
        resources.ApplyResources(Me.CheckBox_VLine_NotAddToOutput, "CheckBox_VLine_NotAddToOutput")
        Me.CheckBox_VLine_NotAddToOutput.Name = "CheckBox_VLine_NotAddToOutput"
        Me.CheckBox_VLine_NotAddToOutput.UseVisualStyleBackColor = True
        '
        'CheckBox_HLine_NotAddToOutput
        '
        resources.ApplyResources(Me.CheckBox_HLine_NotAddToOutput, "CheckBox_HLine_NotAddToOutput")
        Me.CheckBox_HLine_NotAddToOutput.Name = "CheckBox_HLine_NotAddToOutput"
        Me.CheckBox_HLine_NotAddToOutput.UseVisualStyleBackColor = True
        '
        'GroupBox_LineCommonSetting
        '
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Short_Cut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ShortCut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Cut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_Cut_H)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassRightV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassRightV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassLeftV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassLeftV)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Block_OverNumber)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Block_OverNum)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassUpH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Short_Cut)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassUpH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_ByPassDownH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ShortCut)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_Cut)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.NumericUpDown_Line_OverNumber)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_OverNum)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_ByPassDownH)
        Me.GroupBox_LineCommonSetting.Controls.Add(Me.RadioButton_Line_Cut)
        resources.ApplyResources(Me.GroupBox_LineCommonSetting, "GroupBox_LineCommonSetting")
        Me.GroupBox_LineCommonSetting.Name = "GroupBox_LineCommonSetting"
        Me.GroupBox_LineCommonSetting.TabStop = False
        '
        'NumericUpDown_Line_Short_Cut_H
        '
        resources.ApplyResources(Me.NumericUpDown_Line_Short_Cut_H, "NumericUpDown_Line_Short_Cut_H")
        Me.NumericUpDown_Line_Short_Cut_H.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_Line_Short_Cut_H.Name = "NumericUpDown_Line_Short_Cut_H"
        '
        'RadioButton_Line_ShortCut_H
        '
        resources.ApplyResources(Me.RadioButton_Line_ShortCut_H, "RadioButton_Line_ShortCut_H")
        Me.RadioButton_Line_ShortCut_H.Name = "RadioButton_Line_ShortCut_H"
        Me.RadioButton_Line_ShortCut_H.TabStop = True
        Me.RadioButton_Line_ShortCut_H.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_Cut_H
        '
        resources.ApplyResources(Me.NumericUpDown_Line_Cut_H, "NumericUpDown_Line_Cut_H")
        Me.NumericUpDown_Line_Cut_H.Maximum = New Decimal(New Integer() {30000, 0, 0, 0})
        Me.NumericUpDown_Line_Cut_H.Name = "NumericUpDown_Line_Cut_H"
        '
        'RadioButton_Line_Cut_H
        '
        resources.ApplyResources(Me.RadioButton_Line_Cut_H, "RadioButton_Line_Cut_H")
        Me.RadioButton_Line_Cut_H.Name = "RadioButton_Line_Cut_H"
        Me.RadioButton_Line_Cut_H.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_ByPassRightV
        '
        resources.ApplyResources(Me.NumericUpDown_Line_ByPassRightV, "NumericUpDown_Line_ByPassRightV")
        Me.NumericUpDown_Line_ByPassRightV.Name = "NumericUpDown_Line_ByPassRightV"
        '
        'RadioButton_Line_ByPassRightV
        '
        resources.ApplyResources(Me.RadioButton_Line_ByPassRightV, "RadioButton_Line_ByPassRightV")
        Me.RadioButton_Line_ByPassRightV.Name = "RadioButton_Line_ByPassRightV"
        Me.RadioButton_Line_ByPassRightV.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_ByPassLeftV
        '
        resources.ApplyResources(Me.NumericUpDown_Line_ByPassLeftV, "NumericUpDown_Line_ByPassLeftV")
        Me.NumericUpDown_Line_ByPassLeftV.Name = "NumericUpDown_Line_ByPassLeftV"
        '
        'RadioButton_Line_ByPassLeftV
        '
        resources.ApplyResources(Me.RadioButton_Line_ByPassLeftV, "RadioButton_Line_ByPassLeftV")
        Me.RadioButton_Line_ByPassLeftV.Name = "RadioButton_Line_ByPassLeftV"
        Me.RadioButton_Line_ByPassLeftV.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Block_OverNumber
        '
        resources.ApplyResources(Me.NumericUpDown_Block_OverNumber, "NumericUpDown_Block_OverNumber")
        Me.NumericUpDown_Block_OverNumber.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Block_OverNumber.Name = "NumericUpDown_Block_OverNumber"
        '
        'RadioButton_Block_OverNum
        '
        resources.ApplyResources(Me.RadioButton_Block_OverNum, "RadioButton_Block_OverNum")
        Me.RadioButton_Block_OverNum.Name = "RadioButton_Block_OverNum"
        Me.RadioButton_Block_OverNum.TabStop = True
        Me.RadioButton_Block_OverNum.UseVisualStyleBackColor = True
        '
        'RadioButton_Line_ByPassUpH
        '
        resources.ApplyResources(Me.RadioButton_Line_ByPassUpH, "RadioButton_Line_ByPassUpH")
        Me.RadioButton_Line_ByPassUpH.Name = "RadioButton_Line_ByPassUpH"
        Me.RadioButton_Line_ByPassUpH.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_Short_Cut
        '
        resources.ApplyResources(Me.NumericUpDown_Line_Short_Cut, "NumericUpDown_Line_Short_Cut")
        Me.NumericUpDown_Line_Short_Cut.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_Line_Short_Cut.Name = "NumericUpDown_Line_Short_Cut"
        '
        'NumericUpDown_Line_ByPassUpH
        '
        resources.ApplyResources(Me.NumericUpDown_Line_ByPassUpH, "NumericUpDown_Line_ByPassUpH")
        Me.NumericUpDown_Line_ByPassUpH.Name = "NumericUpDown_Line_ByPassUpH"
        '
        'NumericUpDown_Line_ByPassDownH
        '
        resources.ApplyResources(Me.NumericUpDown_Line_ByPassDownH, "NumericUpDown_Line_ByPassDownH")
        Me.NumericUpDown_Line_ByPassDownH.Name = "NumericUpDown_Line_ByPassDownH"
        '
        'RadioButton_Line_ShortCut
        '
        resources.ApplyResources(Me.RadioButton_Line_ShortCut, "RadioButton_Line_ShortCut")
        Me.RadioButton_Line_ShortCut.Name = "RadioButton_Line_ShortCut"
        Me.RadioButton_Line_ShortCut.TabStop = True
        Me.RadioButton_Line_ShortCut.UseVisualStyleBackColor = True
        '
        'NumericUpDown_Line_Cut
        '
        resources.ApplyResources(Me.NumericUpDown_Line_Cut, "NumericUpDown_Line_Cut")
        Me.NumericUpDown_Line_Cut.Maximum = New Decimal(New Integer() {30000, 0, 0, 0})
        Me.NumericUpDown_Line_Cut.Name = "NumericUpDown_Line_Cut"
        '
        'NumericUpDown_Line_OverNumber
        '
        resources.ApplyResources(Me.NumericUpDown_Line_OverNumber, "NumericUpDown_Line_OverNumber")
        Me.NumericUpDown_Line_OverNumber.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_Line_OverNumber.Name = "NumericUpDown_Line_OverNumber"
        '
        'RadioButton_Line_OverNum
        '
        resources.ApplyResources(Me.RadioButton_Line_OverNum, "RadioButton_Line_OverNum")
        Me.RadioButton_Line_OverNum.Name = "RadioButton_Line_OverNum"
        Me.RadioButton_Line_OverNum.TabStop = True
        Me.RadioButton_Line_OverNum.UseVisualStyleBackColor = True
        '
        'RadioButton_Line_ByPassDownH
        '
        resources.ApplyResources(Me.RadioButton_Line_ByPassDownH, "RadioButton_Line_ByPassDownH")
        Me.RadioButton_Line_ByPassDownH.Name = "RadioButton_Line_ByPassDownH"
        Me.RadioButton_Line_ByPassDownH.UseVisualStyleBackColor = True
        '
        'RadioButton_Line_Cut
        '
        resources.ApplyResources(Me.RadioButton_Line_Cut, "RadioButton_Line_Cut")
        Me.RadioButton_Line_Cut.Name = "RadioButton_Line_Cut"
        Me.RadioButton_Line_Cut.UseVisualStyleBackColor = True
        '
        'GroupBox_MeanDiff
        '
        Me.GroupBox_MeanDiff.Controls.Add(Me.NumericUpDown_MeanDifference)
        Me.GroupBox_MeanDiff.Controls.Add(Me.Button_MeanRange)
        Me.GroupBox_MeanDiff.Controls.Add(Me.TrackBar_MeanDifference)
        Me.GroupBox_MeanDiff.Controls.Add(Me.Label3)
        resources.ApplyResources(Me.GroupBox_MeanDiff, "GroupBox_MeanDiff")
        Me.GroupBox_MeanDiff.Name = "GroupBox_MeanDiff"
        Me.GroupBox_MeanDiff.TabStop = False
        '
        'NumericUpDown_MeanDifference
        '
        resources.ApplyResources(Me.NumericUpDown_MeanDifference, "NumericUpDown_MeanDifference")
        Me.NumericUpDown_MeanDifference.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_MeanDifference.Name = "NumericUpDown_MeanDifference"
        '
        'Button_MeanRange
        '
        resources.ApplyResources(Me.Button_MeanRange, "Button_MeanRange")
        Me.Button_MeanRange.Name = "Button_MeanRange"
        Me.Button_MeanRange.UseVisualStyleBackColor = True
        '
        'TrackBar_MeanDifference
        '
        Me.TrackBar_MeanDifference.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.TrackBar_MeanDifference, "TrackBar_MeanDifference")
        Me.TrackBar_MeanDifference.Maximum = 65535
        Me.TrackBar_MeanDifference.Name = "TrackBar_MeanDifference"
        Me.TrackBar_MeanDifference.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'CheckBox_Line_Enable
        '
        resources.ApplyResources(Me.CheckBox_Line_Enable, "CheckBox_Line_Enable")
        Me.CheckBox_Line_Enable.Name = "CheckBox_Line_Enable"
        Me.CheckBox_Line_Enable.UseVisualStyleBackColor = True
        '
        'TabPage_GrayAbnormal
        '
        Me.TabPage_GrayAbnormal.Controls.Add(Me.GroupBox_GrayAbnormal)
        Me.TabPage_GrayAbnormal.Controls.Add(Me.CheckBox_GrayAbnormal_Enable)
        resources.ApplyResources(Me.TabPage_GrayAbnormal, "TabPage_GrayAbnormal")
        Me.TabPage_GrayAbnormal.Name = "TabPage_GrayAbnormal"
        Me.TabPage_GrayAbnormal.UseVisualStyleBackColor = True
        '
        'GroupBox_GrayAbnormal
        '
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label51)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.NumericUpDown_GrayAbnormal_NoDisplay)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Lbl_GrayAbnormal_NegLimit)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Lbl_GrayAbnormal_PosLimit)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.NumericUpDown_GrayAbnormal_NegLimit)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label22)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label23)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label10)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label9)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.Label11)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.NumericUpDown_GrayAbnormalStandardGray)
        Me.GroupBox_GrayAbnormal.Controls.Add(Me.NumericUpDown_GrayAbnormal_PosLimit)
        resources.ApplyResources(Me.GroupBox_GrayAbnormal, "GroupBox_GrayAbnormal")
        Me.GroupBox_GrayAbnormal.Name = "GroupBox_GrayAbnormal"
        Me.GroupBox_GrayAbnormal.TabStop = False
        '
        'Label51
        '
        resources.ApplyResources(Me.Label51, "Label51")
        Me.Label51.Name = "Label51"
        '
        'NumericUpDown_GrayAbnormal_NoDisplay
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_NoDisplay, "NumericUpDown_GrayAbnormal_NoDisplay")
        Me.NumericUpDown_GrayAbnormal_NoDisplay.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GrayAbnormal_NoDisplay.Name = "NumericUpDown_GrayAbnormal_NoDisplay"
        '
        'Lbl_GrayAbnormal_NegLimit
        '
        Me.Lbl_GrayAbnormal_NegLimit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.Lbl_GrayAbnormal_NegLimit, "Lbl_GrayAbnormal_NegLimit")
        Me.Lbl_GrayAbnormal_NegLimit.Name = "Lbl_GrayAbnormal_NegLimit"
        '
        'Lbl_GrayAbnormal_PosLimit
        '
        Me.Lbl_GrayAbnormal_PosLimit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Lbl_GrayAbnormal_PosLimit.ForeColor = System.Drawing.SystemColors.InfoText
        resources.ApplyResources(Me.Lbl_GrayAbnormal_PosLimit, "Lbl_GrayAbnormal_PosLimit")
        Me.Lbl_GrayAbnormal_PosLimit.Name = "Lbl_GrayAbnormal_PosLimit"
        '
        'NumericUpDown_GrayAbnormal_NegLimit
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_NegLimit, "NumericUpDown_GrayAbnormal_NegLimit")
        Me.NumericUpDown_GrayAbnormal_NegLimit.Name = "NumericUpDown_GrayAbnormal_NegLimit"
        '
        'Label22
        '
        resources.ApplyResources(Me.Label22, "Label22")
        Me.Label22.Name = "Label22"
        '
        'Label23
        '
        resources.ApplyResources(Me.Label23, "Label23")
        Me.Label23.Name = "Label23"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'NumericUpDown_GrayAbnormalStandardGray
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormalStandardGray, "NumericUpDown_GrayAbnormalStandardGray")
        Me.NumericUpDown_GrayAbnormalStandardGray.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_GrayAbnormalStandardGray.Name = "NumericUpDown_GrayAbnormalStandardGray"
        '
        'NumericUpDown_GrayAbnormal_PosLimit
        '
        resources.ApplyResources(Me.NumericUpDown_GrayAbnormal_PosLimit, "NumericUpDown_GrayAbnormal_PosLimit")
        Me.NumericUpDown_GrayAbnormal_PosLimit.Name = "NumericUpDown_GrayAbnormal_PosLimit"
        '
        'CheckBox_GrayAbnormal_Enable
        '
        resources.ApplyResources(Me.CheckBox_GrayAbnormal_Enable, "CheckBox_GrayAbnormal_Enable")
        Me.CheckBox_GrayAbnormal_Enable.Name = "CheckBox_GrayAbnormal_Enable"
        Me.CheckBox_GrayAbnormal_Enable.UseVisualStyleBackColor = True
        '
        'TabPage_Auto
        '
        Me.TabPage_Auto.Controls.Add(Me.GroupBox_AutoExposure)
        resources.ApplyResources(Me.TabPage_Auto, "TabPage_Auto")
        Me.TabPage_Auto.Name = "TabPage_Auto"
        Me.TabPage_Auto.UseVisualStyleBackColor = True
        '
        'GroupBox_AutoExposure
        '
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label42)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_GrabDelayTime)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label41)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label21)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label20)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label19)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label15)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label14)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_SmallErrorRange)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_TargetMean)
        Me.GroupBox_AutoExposure.Controls.Add(Me.NumericUpDown_AutoExposure_Kp)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label13)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label12)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label16)
        Me.GroupBox_AutoExposure.Controls.Add(Me.Label17)
        resources.ApplyResources(Me.GroupBox_AutoExposure, "GroupBox_AutoExposure")
        Me.GroupBox_AutoExposure.Name = "GroupBox_AutoExposure"
        Me.GroupBox_AutoExposure.TabStop = False
        '
        'Label42
        '
        resources.ApplyResources(Me.Label42, "Label42")
        Me.Label42.Name = "Label42"
        '
        'NumericUpDown_AutoExposure_GrabDelayTime
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_GrabDelayTime, "NumericUpDown_AutoExposure_GrabDelayTime")
        Me.NumericUpDown_AutoExposure_GrabDelayTime.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_GrabDelayTime.Name = "NumericUpDown_AutoExposure_GrabDelayTime"
        '
        'Label41
        '
        resources.ApplyResources(Me.Label41, "Label41")
        Me.Label41.Name = "Label41"
        '
        'Label21
        '
        resources.ApplyResources(Me.Label21, "Label21")
        Me.Label21.Name = "Label21"
        '
        'NumericUpDown_AutoExposure_LargeErrorRange_DL
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL, "NumericUpDown_AutoExposure_LargeErrorRange_DL")
        Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum = New Decimal(New Integer() {200, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_LargeErrorRange_DL.Name = "NumericUpDown_AutoExposure_LargeErrorRange_DL"
        '
        'Label20
        '
        resources.ApplyResources(Me.Label20, "Label20")
        Me.Label20.Name = "Label20"
        '
        'Label19
        '
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.Name = "Label19"
        '
        'Label15
        '
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'Label14
        '
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'NumericUpDown_AutoExposure_SmallErrorRange
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_SmallErrorRange, "NumericUpDown_AutoExposure_SmallErrorRange")
        Me.NumericUpDown_AutoExposure_SmallErrorRange.Name = "NumericUpDown_AutoExposure_SmallErrorRange"
        '
        'NumericUpDown_AutoExposure_LargeErrorRange_UL
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL, "NumericUpDown_AutoExposure_LargeErrorRange_UL")
        Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_LargeErrorRange_UL.Name = "NumericUpDown_AutoExposure_LargeErrorRange_UL"
        '
        'NumericUpDown_AutoExposure_TargetMean
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_TargetMean, "NumericUpDown_AutoExposure_TargetMean")
        Me.NumericUpDown_AutoExposure_TargetMean.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_TargetMean.Name = "NumericUpDown_AutoExposure_TargetMean"
        '
        'NumericUpDown_AutoExposure_Kp
        '
        resources.ApplyResources(Me.NumericUpDown_AutoExposure_Kp, "NumericUpDown_AutoExposure_Kp")
        Me.NumericUpDown_AutoExposure_Kp.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown_AutoExposure_Kp.Name = "NumericUpDown_AutoExposure_Kp"
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'Label16
        '
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        '
        'Label17
        '
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        '
        'TabPage_Other
        '
        Me.TabPage_Other.Controls.Add(Me.GroupBox_AiSetting)
        Me.TabPage_Other.Controls.Add(Me.GroupBox_ImgProcBoundary)
        Me.TabPage_Other.Controls.Add(Me.GroupBox_LinePitchSetting)
        Me.TabPage_Other.Controls.Add(Me.GroupBox_LineAverageFilter)
        Me.TabPage_Other.Controls.Add(Me.CheckBox_FuncRawDataFilterMura_Enable)
        Me.TabPage_Other.Controls.Add(Me.GroupBox_Point_Algorithm)
        Me.TabPage_Other.Controls.Add(Me.GroupBox_PointPitchSetting)
        resources.ApplyResources(Me.TabPage_Other, "TabPage_Other")
        Me.TabPage_Other.Name = "TabPage_Other"
        Me.TabPage_Other.UseVisualStyleBackColor = True
        '
        'GroupBox_AiSetting
        '
        Me.GroupBox_AiSetting.Controls.Add(Me.ComboBox_IsAISaveROI)
        Me.GroupBox_AiSetting.Controls.Add(Me.NumericUpDown_AiResizeY)
        Me.GroupBox_AiSetting.Controls.Add(Me.Label61)
        Me.GroupBox_AiSetting.Controls.Add(Me.NumericUpDown_AiResizeX)
        Me.GroupBox_AiSetting.Controls.Add(Me.Label67)
        Me.GroupBox_AiSetting.Controls.Add(Me.Label60)
        resources.ApplyResources(Me.GroupBox_AiSetting, "GroupBox_AiSetting")
        Me.GroupBox_AiSetting.Name = "GroupBox_AiSetting"
        Me.GroupBox_AiSetting.TabStop = False
        '
        'ComboBox_IsAISaveROI
        '
        Me.ComboBox_IsAISaveROI.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_IsAISaveROI.FormattingEnabled = True
        Me.ComboBox_IsAISaveROI.Items.AddRange(New Object() {resources.GetString("ComboBox_IsAISaveROI.Items"), resources.GetString("ComboBox_IsAISaveROI.Items1")})
        resources.ApplyResources(Me.ComboBox_IsAISaveROI, "ComboBox_IsAISaveROI")
        Me.ComboBox_IsAISaveROI.Name = "ComboBox_IsAISaveROI"
        '
        'NumericUpDown_AiResizeY
        '
        resources.ApplyResources(Me.NumericUpDown_AiResizeY, "NumericUpDown_AiResizeY")
        Me.NumericUpDown_AiResizeY.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_AiResizeY.Name = "NumericUpDown_AiResizeY"
        '
        'Label61
        '
        resources.ApplyResources(Me.Label61, "Label61")
        Me.Label61.Name = "Label61"
        '
        'NumericUpDown_AiResizeX
        '
        resources.ApplyResources(Me.NumericUpDown_AiResizeX, "NumericUpDown_AiResizeX")
        Me.NumericUpDown_AiResizeX.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_AiResizeX.Name = "NumericUpDown_AiResizeX"
        '
        'Label67
        '
        resources.ApplyResources(Me.Label67, "Label67")
        Me.Label67.Name = "Label67"
        '
        'Label60
        '
        resources.ApplyResources(Me.Label60, "Label60")
        Me.Label60.Name = "Label60"
        '
        'GroupBox_ImgProcBoundary
        '
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_RX)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label29)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label30)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label27)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_BY)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label28)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_LX)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label25)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label8)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.NumericUpDown_Boundary_MulWidth_TY)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label24)
        Me.GroupBox_ImgProcBoundary.Controls.Add(Me.Label26)
        resources.ApplyResources(Me.GroupBox_ImgProcBoundary, "GroupBox_ImgProcBoundary")
        Me.GroupBox_ImgProcBoundary.Name = "GroupBox_ImgProcBoundary"
        Me.GroupBox_ImgProcBoundary.TabStop = False
        '
        'NumericUpDown_Boundary_MulWidth_RX
        '
        resources.ApplyResources(Me.NumericUpDown_Boundary_MulWidth_RX, "NumericUpDown_Boundary_MulWidth_RX")
        Me.NumericUpDown_Boundary_MulWidth_RX.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_RX.Name = "NumericUpDown_Boundary_MulWidth_RX"
        '
        'Label29
        '
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Name = "Label29"
        '
        'Label30
        '
        resources.ApplyResources(Me.Label30, "Label30")
        Me.Label30.Name = "Label30"
        '
        'Label27
        '
        resources.ApplyResources(Me.Label27, "Label27")
        Me.Label27.Name = "Label27"
        '
        'NumericUpDown_Boundary_MulWidth_BY
        '
        resources.ApplyResources(Me.NumericUpDown_Boundary_MulWidth_BY, "NumericUpDown_Boundary_MulWidth_BY")
        Me.NumericUpDown_Boundary_MulWidth_BY.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_BY.Name = "NumericUpDown_Boundary_MulWidth_BY"
        '
        'Label28
        '
        resources.ApplyResources(Me.Label28, "Label28")
        Me.Label28.Name = "Label28"
        '
        'NumericUpDown_Boundary_MulWidth_LX
        '
        resources.ApplyResources(Me.NumericUpDown_Boundary_MulWidth_LX, "NumericUpDown_Boundary_MulWidth_LX")
        Me.NumericUpDown_Boundary_MulWidth_LX.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_LX.Name = "NumericUpDown_Boundary_MulWidth_LX"
        '
        'Label25
        '
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'NumericUpDown_Boundary_MulWidth_TY
        '
        resources.ApplyResources(Me.NumericUpDown_Boundary_MulWidth_TY, "NumericUpDown_Boundary_MulWidth_TY")
        Me.NumericUpDown_Boundary_MulWidth_TY.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_Boundary_MulWidth_TY.Name = "NumericUpDown_Boundary_MulWidth_TY"
        '
        'Label24
        '
        resources.ApplyResources(Me.Label24, "Label24")
        Me.Label24.Name = "Label24"
        '
        'Label26
        '
        resources.ApplyResources(Me.Label26, "Label26")
        Me.Label26.Name = "Label26"
        '
        'GroupBox_LinePitchSetting
        '
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.NumericUpDown_Line_PitchY)
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.NumericUpDown_Line_PitchX)
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.Label6)
        Me.GroupBox_LinePitchSetting.Controls.Add(Me.Label2)
        resources.ApplyResources(Me.GroupBox_LinePitchSetting, "GroupBox_LinePitchSetting")
        Me.GroupBox_LinePitchSetting.Name = "GroupBox_LinePitchSetting"
        Me.GroupBox_LinePitchSetting.TabStop = False
        '
        'NumericUpDown_Line_PitchY
        '
        resources.ApplyResources(Me.NumericUpDown_Line_PitchY, "NumericUpDown_Line_PitchY")
        Me.NumericUpDown_Line_PitchY.Name = "NumericUpDown_Line_PitchY"
        '
        'NumericUpDown_Line_PitchX
        '
        resources.ApplyResources(Me.NumericUpDown_Line_PitchX, "NumericUpDown_Line_PitchX")
        Me.NumericUpDown_Line_PitchX.Name = "NumericUpDown_Line_PitchX"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'GroupBox_LineAverageFilter
        '
        Me.GroupBox_LineAverageFilter.Controls.Add(Me.Label44)
        Me.GroupBox_LineAverageFilter.Controls.Add(Me.NumericUpDown_AverageFilter)
        resources.ApplyResources(Me.GroupBox_LineAverageFilter, "GroupBox_LineAverageFilter")
        Me.GroupBox_LineAverageFilter.Name = "GroupBox_LineAverageFilter"
        Me.GroupBox_LineAverageFilter.TabStop = False
        '
        'Label44
        '
        resources.ApplyResources(Me.Label44, "Label44")
        Me.Label44.Name = "Label44"
        '
        'NumericUpDown_AverageFilter
        '
        resources.ApplyResources(Me.NumericUpDown_AverageFilter, "NumericUpDown_AverageFilter")
        Me.NumericUpDown_AverageFilter.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDown_AverageFilter.Name = "NumericUpDown_AverageFilter"
        '
        'CheckBox_FuncRawDataFilterMura_Enable
        '
        resources.ApplyResources(Me.CheckBox_FuncRawDataFilterMura_Enable, "CheckBox_FuncRawDataFilterMura_Enable")
        Me.CheckBox_FuncRawDataFilterMura_Enable.Name = "CheckBox_FuncRawDataFilterMura_Enable"
        Me.CheckBox_FuncRawDataFilterMura_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_Point_Algorithm
        '
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_6)
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_5)
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_4)
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_3)
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_2)
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_1)
        Me.GroupBox_Point_Algorithm.Controls.Add(Me.RadioButton_PointAlgorithm_0)
        resources.ApplyResources(Me.GroupBox_Point_Algorithm, "GroupBox_Point_Algorithm")
        Me.GroupBox_Point_Algorithm.Name = "GroupBox_Point_Algorithm"
        Me.GroupBox_Point_Algorithm.TabStop = False
        '
        'RadioButton_PointAlgorithm_6
        '
        resources.ApplyResources(Me.RadioButton_PointAlgorithm_6, "RadioButton_PointAlgorithm_6")
        Me.RadioButton_PointAlgorithm_6.Name = "RadioButton_PointAlgorithm_6"
        Me.RadioButton_PointAlgorithm_6.UseVisualStyleBackColor = True
        '
        'RadioButton_PointAlgorithm_5
        '
        resources.ApplyResources(Me.RadioButton_PointAlgorithm_5, "RadioButton_PointAlgorithm_5")
        Me.RadioButton_PointAlgorithm_5.Name = "RadioButton_PointAlgorithm_5"
        Me.RadioButton_PointAlgorithm_5.UseVisualStyleBackColor = True
        '
        'RadioButton_PointAlgorithm_4
        '
        resources.ApplyResources(Me.RadioButton_PointAlgorithm_4, "RadioButton_PointAlgorithm_4")
        Me.RadioButton_PointAlgorithm_4.Name = "RadioButton_PointAlgorithm_4"
        Me.RadioButton_PointAlgorithm_4.UseVisualStyleBackColor = True
        '
        'RadioButton_PointAlgorithm_3
        '
        resources.ApplyResources(Me.RadioButton_PointAlgorithm_3, "RadioButton_PointAlgorithm_3")
        Me.RadioButton_PointAlgorithm_3.Name = "RadioButton_PointAlgorithm_3"
        Me.RadioButton_PointAlgorithm_3.UseVisualStyleBackColor = True
        '
        'RadioButton_PointAlgorithm_2
        '
        resources.ApplyResources(Me.RadioButton_PointAlgorithm_2, "RadioButton_PointAlgorithm_2")
        Me.RadioButton_PointAlgorithm_2.Name = "RadioButton_PointAlgorithm_2"
        Me.RadioButton_PointAlgorithm_2.UseVisualStyleBackColor = True
        '
        'RadioButton_PointAlgorithm_1
        '
        resources.ApplyResources(Me.RadioButton_PointAlgorithm_1, "RadioButton_PointAlgorithm_1")
        Me.RadioButton_PointAlgorithm_1.Name = "RadioButton_PointAlgorithm_1"
        Me.RadioButton_PointAlgorithm_1.UseVisualStyleBackColor = True
        '
        'RadioButton_PointAlgorithm_0
        '
        resources.ApplyResources(Me.RadioButton_PointAlgorithm_0, "RadioButton_PointAlgorithm_0")
        Me.RadioButton_PointAlgorithm_0.Checked = True
        Me.RadioButton_PointAlgorithm_0.Name = "RadioButton_PointAlgorithm_0"
        Me.RadioButton_PointAlgorithm_0.TabStop = True
        Me.RadioButton_PointAlgorithm_0.UseVisualStyleBackColor = True
        '
        'GroupBox_PointPitchSetting
        '
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.NumericUpDown_Point_PitchY)
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.NumericUpDown_Point_PitchX)
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.Label5)
        Me.GroupBox_PointPitchSetting.Controls.Add(Me.Label4)
        resources.ApplyResources(Me.GroupBox_PointPitchSetting, "GroupBox_PointPitchSetting")
        Me.GroupBox_PointPitchSetting.Name = "GroupBox_PointPitchSetting"
        Me.GroupBox_PointPitchSetting.TabStop = False
        '
        'NumericUpDown_Point_PitchY
        '
        resources.ApplyResources(Me.NumericUpDown_Point_PitchY, "NumericUpDown_Point_PitchY")
        Me.NumericUpDown_Point_PitchY.Maximum = New Decimal(New Integer() {60, 0, 0, 0})
        Me.NumericUpDown_Point_PitchY.Name = "NumericUpDown_Point_PitchY"
        '
        'NumericUpDown_Point_PitchX
        '
        resources.ApplyResources(Me.NumericUpDown_Point_PitchX, "NumericUpDown_Point_PitchX")
        Me.NumericUpDown_Point_PitchX.Name = "NumericUpDown_Point_PitchX"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'TabPage_Mark
        '
        Me.TabPage_Mark.Controls.Add(Me.CheckBox_MarkTH)
        Me.TabPage_Mark.Controls.Add(Me.CheckBox_PLMark_Enable)
        Me.TabPage_Mark.Controls.Add(Me.CheckBox_CurrentPLMark_Enable)
        Me.TabPage_Mark.Controls.Add(Me.GroupBox_PLMark_Setting)
        Me.TabPage_Mark.Controls.Add(Me.Label)
        Me.TabPage_Mark.Controls.Add(Me.NumericUpDown_MarkTH)
        Me.TabPage_Mark.Controls.Add(Me.RadioButton_PLMark_Bin)
        Me.TabPage_Mark.Controls.Add(Me.RadioButton_PLMark_Original)
        Me.TabPage_Mark.Controls.Add(Me.Button_Save_PLMark)
        Me.TabPage_Mark.Controls.Add(Me.Button_PLMark_PatTest)
        Me.TabPage_Mark.Controls.Add(Me.Panel_AxMDisplay_PLMark)
        Me.TabPage_Mark.Controls.Add(Me.CheckedListBox_PLMark)
        Me.TabPage_Mark.Controls.Add(Me.Label_PLMark_CurrentMark)
        resources.ApplyResources(Me.TabPage_Mark, "TabPage_Mark")
        Me.TabPage_Mark.Name = "TabPage_Mark"
        Me.TabPage_Mark.UseVisualStyleBackColor = True
        '
        'CheckBox_MarkTH
        '
        resources.ApplyResources(Me.CheckBox_MarkTH, "CheckBox_MarkTH")
        Me.CheckBox_MarkTH.Name = "CheckBox_MarkTH"
        Me.CheckBox_MarkTH.UseVisualStyleBackColor = True
        '
        'CheckBox_PLMark_Enable
        '
        resources.ApplyResources(Me.CheckBox_PLMark_Enable, "CheckBox_PLMark_Enable")
        Me.CheckBox_PLMark_Enable.Name = "CheckBox_PLMark_Enable"
        Me.CheckBox_PLMark_Enable.UseVisualStyleBackColor = True
        '
        'CheckBox_CurrentPLMark_Enable
        '
        resources.ApplyResources(Me.CheckBox_CurrentPLMark_Enable, "CheckBox_CurrentPLMark_Enable")
        Me.CheckBox_CurrentPLMark_Enable.Name = "CheckBox_CurrentPLMark_Enable"
        Me.CheckBox_CurrentPLMark_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_PLMark_Setting
        '
        Me.GroupBox_PLMark_Setting.Controls.Add(Me.GroupBox_MatchSetting)
        Me.GroupBox_PLMark_Setting.Controls.Add(Me.CheckBox_PLMark_RegionMannual)
        Me.GroupBox_PLMark_Setting.Controls.Add(Me.CheckBox_PLMark_ShowBoundary)
        Me.GroupBox_PLMark_Setting.Controls.Add(Me.GroupBox_PLMark_SearchMode)
        Me.GroupBox_PLMark_Setting.Controls.Add(Me.GroupBox_PLMarkSet)
        Me.GroupBox_PLMark_Setting.Controls.Add(Me.GroupBox_PLMark_Boundary)
        Me.GroupBox_PLMark_Setting.Controls.Add(Me.GroupBox_BypassSetting)
        resources.ApplyResources(Me.GroupBox_PLMark_Setting, "GroupBox_PLMark_Setting")
        Me.GroupBox_PLMark_Setting.Name = "GroupBox_PLMark_Setting"
        Me.GroupBox_PLMark_Setting.TabStop = False
        '
        'GroupBox_MatchSetting
        '
        Me.GroupBox_MatchSetting.Controls.Add(Me.NumericUpDown_GrayMarkErodeCount)
        Me.GroupBox_MatchSetting.Controls.Add(Me.Label65)
        Me.GroupBox_MatchSetting.Controls.Add(Me.NumericUpDown_GrayMarkSmoothCount)
        Me.GroupBox_MatchSetting.Controls.Add(Me.Label39)
        Me.GroupBox_MatchSetting.Controls.Add(Me.Label63)
        Me.GroupBox_MatchSetting.Controls.Add(Me.CheckBox_PreProcess)
        Me.GroupBox_MatchSetting.Controls.Add(Me.ComboBox_MatchImg)
        resources.ApplyResources(Me.GroupBox_MatchSetting, "GroupBox_MatchSetting")
        Me.GroupBox_MatchSetting.Name = "GroupBox_MatchSetting"
        Me.GroupBox_MatchSetting.TabStop = False
        '
        'NumericUpDown_GrayMarkErodeCount
        '
        resources.ApplyResources(Me.NumericUpDown_GrayMarkErodeCount, "NumericUpDown_GrayMarkErodeCount")
        Me.NumericUpDown_GrayMarkErodeCount.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.NumericUpDown_GrayMarkErodeCount.Name = "NumericUpDown_GrayMarkErodeCount"
        '
        'Label65
        '
        resources.ApplyResources(Me.Label65, "Label65")
        Me.Label65.Name = "Label65"
        '
        'NumericUpDown_GrayMarkSmoothCount
        '
        resources.ApplyResources(Me.NumericUpDown_GrayMarkSmoothCount, "NumericUpDown_GrayMarkSmoothCount")
        Me.NumericUpDown_GrayMarkSmoothCount.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.NumericUpDown_GrayMarkSmoothCount.Name = "NumericUpDown_GrayMarkSmoothCount"
        '
        'Label39
        '
        resources.ApplyResources(Me.Label39, "Label39")
        Me.Label39.Name = "Label39"
        '
        'Label63
        '
        resources.ApplyResources(Me.Label63, "Label63")
        Me.Label63.Name = "Label63"
        '
        'CheckBox_PreProcess
        '
        resources.ApplyResources(Me.CheckBox_PreProcess, "CheckBox_PreProcess")
        Me.CheckBox_PreProcess.Name = "CheckBox_PreProcess"
        Me.CheckBox_PreProcess.UseVisualStyleBackColor = True
        '
        'ComboBox_MatchImg
        '
        Me.ComboBox_MatchImg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_MatchImg.FormattingEnabled = True
        Me.ComboBox_MatchImg.Items.AddRange(New Object() {resources.GetString("ComboBox_MatchImg.Items"), resources.GetString("ComboBox_MatchImg.Items1")})
        resources.ApplyResources(Me.ComboBox_MatchImg, "ComboBox_MatchImg")
        Me.ComboBox_MatchImg.Name = "ComboBox_MatchImg"
        '
        'CheckBox_PLMark_RegionMannual
        '
        resources.ApplyResources(Me.CheckBox_PLMark_RegionMannual, "CheckBox_PLMark_RegionMannual")
        Me.CheckBox_PLMark_RegionMannual.Name = "CheckBox_PLMark_RegionMannual"
        Me.CheckBox_PLMark_RegionMannual.UseVisualStyleBackColor = True
        '
        'CheckBox_PLMark_ShowBoundary
        '
        resources.ApplyResources(Me.CheckBox_PLMark_ShowBoundary, "CheckBox_PLMark_ShowBoundary")
        Me.CheckBox_PLMark_ShowBoundary.Name = "CheckBox_PLMark_ShowBoundary"
        Me.CheckBox_PLMark_ShowBoundary.UseVisualStyleBackColor = True
        '
        'GroupBox_PLMark_SearchMode
        '
        Me.GroupBox_PLMark_SearchMode.Controls.Add(Me.Label66)
        Me.GroupBox_PLMark_SearchMode.Controls.Add(Me.NumericUpDown_SearchMarkCount)
        Me.GroupBox_PLMark_SearchMode.Controls.Add(Me.Label59)
        Me.GroupBox_PLMark_SearchMode.Controls.Add(Me.CheckBox_FillOfHole)
        Me.GroupBox_PLMark_SearchMode.Controls.Add(Me.Label40)
        Me.GroupBox_PLMark_SearchMode.Controls.Add(Me.Label_SearchRange_PLMark_Multiple)
        Me.GroupBox_PLMark_SearchMode.Controls.Add(Me.NumericUpDown_SearchRange_PLMark_Multiple)
        resources.ApplyResources(Me.GroupBox_PLMark_SearchMode, "GroupBox_PLMark_SearchMode")
        Me.GroupBox_PLMark_SearchMode.Name = "GroupBox_PLMark_SearchMode"
        Me.GroupBox_PLMark_SearchMode.TabStop = False
        '
        'Label66
        '
        resources.ApplyResources(Me.Label66, "Label66")
        Me.Label66.Name = "Label66"
        '
        'NumericUpDown_SearchMarkCount
        '
        resources.ApplyResources(Me.NumericUpDown_SearchMarkCount, "NumericUpDown_SearchMarkCount")
        Me.NumericUpDown_SearchMarkCount.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDown_SearchMarkCount.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_SearchMarkCount.Name = "NumericUpDown_SearchMarkCount"
        Me.NumericUpDown_SearchMarkCount.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label59
        '
        resources.ApplyResources(Me.Label59, "Label59")
        Me.Label59.Name = "Label59"
        '
        'CheckBox_FillOfHole
        '
        resources.ApplyResources(Me.CheckBox_FillOfHole, "CheckBox_FillOfHole")
        Me.CheckBox_FillOfHole.Name = "CheckBox_FillOfHole"
        Me.CheckBox_FillOfHole.UseVisualStyleBackColor = True
        '
        'Label40
        '
        resources.ApplyResources(Me.Label40, "Label40")
        Me.Label40.Name = "Label40"
        '
        'Label_SearchRange_PLMark_Multiple
        '
        resources.ApplyResources(Me.Label_SearchRange_PLMark_Multiple, "Label_SearchRange_PLMark_Multiple")
        Me.Label_SearchRange_PLMark_Multiple.Name = "Label_SearchRange_PLMark_Multiple"
        '
        'NumericUpDown_SearchRange_PLMark_Multiple
        '
        resources.ApplyResources(Me.NumericUpDown_SearchRange_PLMark_Multiple, "NumericUpDown_SearchRange_PLMark_Multiple")
        Me.NumericUpDown_SearchRange_PLMark_Multiple.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_SearchRange_PLMark_Multiple.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_SearchRange_PLMark_Multiple.Name = "NumericUpDown_SearchRange_PLMark_Multiple"
        Me.NumericUpDown_SearchRange_PLMark_Multiple.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'GroupBox_PLMarkSet
        '
        Me.GroupBox_PLMarkSet.Controls.Add(Me.NumericUpDown_MarkGroup)
        Me.GroupBox_PLMarkSet.Controls.Add(Me.Label52)
        Me.GroupBox_PLMarkSet.Controls.Add(Me.NumericUpDown_PLMark_Acceptance)
        Me.GroupBox_PLMarkSet.Controls.Add(Me.Label37)
        Me.GroupBox_PLMarkSet.Controls.Add(Me.TextBox_PLMark_MarkName)
        Me.GroupBox_PLMarkSet.Controls.Add(Me.Label36)
        resources.ApplyResources(Me.GroupBox_PLMarkSet, "GroupBox_PLMarkSet")
        Me.GroupBox_PLMarkSet.Name = "GroupBox_PLMarkSet"
        Me.GroupBox_PLMarkSet.TabStop = False
        '
        'NumericUpDown_MarkGroup
        '
        resources.ApplyResources(Me.NumericUpDown_MarkGroup, "NumericUpDown_MarkGroup")
        Me.NumericUpDown_MarkGroup.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MarkGroup.Name = "NumericUpDown_MarkGroup"
        Me.NumericUpDown_MarkGroup.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label52
        '
        resources.ApplyResources(Me.Label52, "Label52")
        Me.Label52.Name = "Label52"
        '
        'NumericUpDown_PLMark_Acceptance
        '
        resources.ApplyResources(Me.NumericUpDown_PLMark_Acceptance, "NumericUpDown_PLMark_Acceptance")
        Me.NumericUpDown_PLMark_Acceptance.Name = "NumericUpDown_PLMark_Acceptance"
        Me.NumericUpDown_PLMark_Acceptance.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'Label37
        '
        resources.ApplyResources(Me.Label37, "Label37")
        Me.Label37.Name = "Label37"
        '
        'TextBox_PLMark_MarkName
        '
        resources.ApplyResources(Me.TextBox_PLMark_MarkName, "TextBox_PLMark_MarkName")
        Me.TextBox_PLMark_MarkName.Name = "TextBox_PLMark_MarkName"
        '
        'Label36
        '
        resources.ApplyResources(Me.Label36, "Label36")
        Me.Label36.Name = "Label36"
        '
        'GroupBox_PLMark_Boundary
        '
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.NumericUpDown_PLMark_BoundaryRight)
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.NumericUpDown_PLMark_BoundaryLeft)
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.NumericUpDown_PLMark_BoundaryBottom)
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.NumericUpDown_PLMark_BoundaryTop)
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.Label35)
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.Label34)
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.Label33)
        Me.GroupBox_PLMark_Boundary.Controls.Add(Me.Label32)
        resources.ApplyResources(Me.GroupBox_PLMark_Boundary, "GroupBox_PLMark_Boundary")
        Me.GroupBox_PLMark_Boundary.Name = "GroupBox_PLMark_Boundary"
        Me.GroupBox_PLMark_Boundary.TabStop = False
        '
        'NumericUpDown_PLMark_BoundaryRight
        '
        resources.ApplyResources(Me.NumericUpDown_PLMark_BoundaryRight, "NumericUpDown_PLMark_BoundaryRight")
        Me.NumericUpDown_PLMark_BoundaryRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_PLMark_BoundaryRight.Name = "NumericUpDown_PLMark_BoundaryRight"
        '
        'NumericUpDown_PLMark_BoundaryLeft
        '
        resources.ApplyResources(Me.NumericUpDown_PLMark_BoundaryLeft, "NumericUpDown_PLMark_BoundaryLeft")
        Me.NumericUpDown_PLMark_BoundaryLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_PLMark_BoundaryLeft.Name = "NumericUpDown_PLMark_BoundaryLeft"
        '
        'NumericUpDown_PLMark_BoundaryBottom
        '
        resources.ApplyResources(Me.NumericUpDown_PLMark_BoundaryBottom, "NumericUpDown_PLMark_BoundaryBottom")
        Me.NumericUpDown_PLMark_BoundaryBottom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_PLMark_BoundaryBottom.Name = "NumericUpDown_PLMark_BoundaryBottom"
        '
        'NumericUpDown_PLMark_BoundaryTop
        '
        resources.ApplyResources(Me.NumericUpDown_PLMark_BoundaryTop, "NumericUpDown_PLMark_BoundaryTop")
        Me.NumericUpDown_PLMark_BoundaryTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_PLMark_BoundaryTop.Name = "NumericUpDown_PLMark_BoundaryTop"
        '
        'Label35
        '
        resources.ApplyResources(Me.Label35, "Label35")
        Me.Label35.Name = "Label35"
        '
        'Label34
        '
        resources.ApplyResources(Me.Label34, "Label34")
        Me.Label34.Name = "Label34"
        '
        'Label33
        '
        resources.ApplyResources(Me.Label33, "Label33")
        Me.Label33.Name = "Label33"
        '
        'Label32
        '
        resources.ApplyResources(Me.Label32, "Label32")
        Me.Label32.Name = "Label32"
        '
        'GroupBox_BypassSetting
        '
        Me.GroupBox_BypassSetting.Controls.Add(Me.Label64)
        Me.GroupBox_BypassSetting.Controls.Add(Me.CheckBox_BlobFillHole)
        Me.GroupBox_BypassSetting.Controls.Add(Me.ComboBox_BypassRegion)
        Me.GroupBox_BypassSetting.Controls.Add(Me.Label45)
        Me.GroupBox_BypassSetting.Controls.Add(Me.NumericUpDown_BlobArea)
        Me.GroupBox_BypassSetting.Controls.Add(Me.NumericUpDown_PLMark_DilateCount)
        Me.GroupBox_BypassSetting.Controls.Add(Me.Label46)
        resources.ApplyResources(Me.GroupBox_BypassSetting, "GroupBox_BypassSetting")
        Me.GroupBox_BypassSetting.Name = "GroupBox_BypassSetting"
        Me.GroupBox_BypassSetting.TabStop = False
        '
        'Label64
        '
        resources.ApplyResources(Me.Label64, "Label64")
        Me.Label64.Name = "Label64"
        '
        'CheckBox_BlobFillHole
        '
        resources.ApplyResources(Me.CheckBox_BlobFillHole, "CheckBox_BlobFillHole")
        Me.CheckBox_BlobFillHole.Name = "CheckBox_BlobFillHole"
        Me.CheckBox_BlobFillHole.UseVisualStyleBackColor = True
        '
        'ComboBox_BypassRegion
        '
        Me.ComboBox_BypassRegion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_BypassRegion.FormattingEnabled = True
        Me.ComboBox_BypassRegion.Items.AddRange(New Object() {resources.GetString("ComboBox_BypassRegion.Items"), resources.GetString("ComboBox_BypassRegion.Items1")})
        resources.ApplyResources(Me.ComboBox_BypassRegion, "ComboBox_BypassRegion")
        Me.ComboBox_BypassRegion.Name = "ComboBox_BypassRegion"
        '
        'Label45
        '
        resources.ApplyResources(Me.Label45, "Label45")
        Me.Label45.Name = "Label45"
        '
        'NumericUpDown_BlobArea
        '
        resources.ApplyResources(Me.NumericUpDown_BlobArea, "NumericUpDown_BlobArea")
        Me.NumericUpDown_BlobArea.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BlobArea.Name = "NumericUpDown_BlobArea"
        '
        'NumericUpDown_PLMark_DilateCount
        '
        resources.ApplyResources(Me.NumericUpDown_PLMark_DilateCount, "NumericUpDown_PLMark_DilateCount")
        Me.NumericUpDown_PLMark_DilateCount.Maximum = New Decimal(New Integer() {30, 0, 0, 0})
        Me.NumericUpDown_PLMark_DilateCount.Name = "NumericUpDown_PLMark_DilateCount"
        '
        'Label46
        '
        resources.ApplyResources(Me.Label46, "Label46")
        Me.Label46.Name = "Label46"
        '
        'Label
        '
        resources.ApplyResources(Me.Label, "Label")
        Me.Label.Name = "Label"
        '
        'NumericUpDown_MarkTH
        '
        Me.NumericUpDown_MarkTH.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        resources.ApplyResources(Me.NumericUpDown_MarkTH, "NumericUpDown_MarkTH")
        Me.NumericUpDown_MarkTH.Maximum = New Decimal(New Integer() {4095, 0, 0, 0})
        Me.NumericUpDown_MarkTH.Name = "NumericUpDown_MarkTH"
        Me.NumericUpDown_MarkTH.Value = New Decimal(New Integer() {900, 0, 0, 0})
        '
        'RadioButton_PLMark_Bin
        '
        resources.ApplyResources(Me.RadioButton_PLMark_Bin, "RadioButton_PLMark_Bin")
        Me.RadioButton_PLMark_Bin.Name = "RadioButton_PLMark_Bin"
        Me.RadioButton_PLMark_Bin.TabStop = True
        Me.RadioButton_PLMark_Bin.UseVisualStyleBackColor = True
        '
        'RadioButton_PLMark_Original
        '
        resources.ApplyResources(Me.RadioButton_PLMark_Original, "RadioButton_PLMark_Original")
        Me.RadioButton_PLMark_Original.Name = "RadioButton_PLMark_Original"
        Me.RadioButton_PLMark_Original.TabStop = True
        Me.RadioButton_PLMark_Original.UseVisualStyleBackColor = True
        '
        'Button_Save_PLMark
        '
        resources.ApplyResources(Me.Button_Save_PLMark, "Button_Save_PLMark")
        Me.Button_Save_PLMark.Name = "Button_Save_PLMark"
        Me.Button_Save_PLMark.UseVisualStyleBackColor = True
        '
        'Button_PLMark_PatTest
        '
        resources.ApplyResources(Me.Button_PLMark_PatTest, "Button_PLMark_PatTest")
        Me.Button_PLMark_PatTest.Name = "Button_PLMark_PatTest"
        Me.Button_PLMark_PatTest.UseVisualStyleBackColor = True
        '
        'Panel_AxMDisplay_PLMark
        '
        Me.Panel_AxMDisplay_PLMark.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        resources.ApplyResources(Me.Panel_AxMDisplay_PLMark, "Panel_AxMDisplay_PLMark")
        Me.Panel_AxMDisplay_PLMark.Name = "Panel_AxMDisplay_PLMark"
        '
        'CheckedListBox_PLMark
        '
        Me.CheckedListBox_PLMark.FormattingEnabled = True
        resources.ApplyResources(Me.CheckedListBox_PLMark, "CheckedListBox_PLMark")
        Me.CheckedListBox_PLMark.Name = "CheckedListBox_PLMark"
        '
        'Label_PLMark_CurrentMark
        '
        resources.ApplyResources(Me.Label_PLMark_CurrentMark, "Label_PLMark_CurrentMark")
        Me.Label_PLMark_CurrentMark.Name = "Label_PLMark_CurrentMark"
        '
        'TabPage_HotPixel
        '
        Me.TabPage_HotPixel.Controls.Add(Me.CheckBox_Filter_HotPixel_With_Characteristics)
        Me.TabPage_HotPixel.Controls.Add(Me.CheckBox_HotPixelEnable)
        Me.TabPage_HotPixel.Controls.Add(Me.GroupBox_HotPixel)
        resources.ApplyResources(Me.TabPage_HotPixel, "TabPage_HotPixel")
        Me.TabPage_HotPixel.Name = "TabPage_HotPixel"
        Me.TabPage_HotPixel.UseVisualStyleBackColor = True
        '
        'CheckBox_Filter_HotPixel_With_Characteristics
        '
        resources.ApplyResources(Me.CheckBox_Filter_HotPixel_With_Characteristics, "CheckBox_Filter_HotPixel_With_Characteristics")
        Me.CheckBox_Filter_HotPixel_With_Characteristics.Name = "CheckBox_Filter_HotPixel_With_Characteristics"
        Me.CheckBox_Filter_HotPixel_With_Characteristics.UseVisualStyleBackColor = True
        '
        'CheckBox_HotPixelEnable
        '
        resources.ApplyResources(Me.CheckBox_HotPixelEnable, "CheckBox_HotPixelEnable")
        Me.CheckBox_HotPixelEnable.Name = "CheckBox_HotPixelEnable"
        Me.CheckBox_HotPixelEnable.UseVisualStyleBackColor = True
        '
        'GroupBox_HotPixel
        '
        Me.GroupBox_HotPixel.Controls.Add(Me.Label47)
        Me.GroupBox_HotPixel.Controls.Add(Me.NumericUpDown_HotPixelMaxMean)
        Me.GroupBox_HotPixel.Controls.Add(Me.RadioButton_HotPixel_Threshold)
        Me.GroupBox_HotPixel.Controls.Add(Me.NumericUpDown_HotPixelRecipe)
        Me.GroupBox_HotPixel.Controls.Add(Me.Label48)
        Me.GroupBox_HotPixel.Controls.Add(Me.NumericUpDown_HotPixelFilterDistance)
        Me.GroupBox_HotPixel.Controls.Add(Me.TrackBar_HotPixel_Threshold)
        resources.ApplyResources(Me.GroupBox_HotPixel, "GroupBox_HotPixel")
        Me.GroupBox_HotPixel.Name = "GroupBox_HotPixel"
        Me.GroupBox_HotPixel.TabStop = False
        '
        'Label47
        '
        resources.ApplyResources(Me.Label47, "Label47")
        Me.Label47.Name = "Label47"
        '
        'NumericUpDown_HotPixelMaxMean
        '
        resources.ApplyResources(Me.NumericUpDown_HotPixelMaxMean, "NumericUpDown_HotPixelMaxMean")
        Me.NumericUpDown_HotPixelMaxMean.Maximum = New Decimal(New Integer() {4095, 0, 0, 0})
        Me.NumericUpDown_HotPixelMaxMean.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_HotPixelMaxMean.Name = "NumericUpDown_HotPixelMaxMean"
        Me.NumericUpDown_HotPixelMaxMean.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'RadioButton_HotPixel_Threshold
        '
        resources.ApplyResources(Me.RadioButton_HotPixel_Threshold, "RadioButton_HotPixel_Threshold")
        Me.RadioButton_HotPixel_Threshold.Name = "RadioButton_HotPixel_Threshold"
        Me.RadioButton_HotPixel_Threshold.UseVisualStyleBackColor = True
        '
        'NumericUpDown_HotPixelRecipe
        '
        Me.NumericUpDown_HotPixelRecipe.Increment = New Decimal(New Integer() {10, 0, 0, 0})
        resources.ApplyResources(Me.NumericUpDown_HotPixelRecipe, "NumericUpDown_HotPixelRecipe")
        Me.NumericUpDown_HotPixelRecipe.Maximum = New Decimal(New Integer() {4095, 0, 0, 0})
        Me.NumericUpDown_HotPixelRecipe.Name = "NumericUpDown_HotPixelRecipe"
        '
        'Label48
        '
        resources.ApplyResources(Me.Label48, "Label48")
        Me.Label48.Name = "Label48"
        '
        'NumericUpDown_HotPixelFilterDistance
        '
        resources.ApplyResources(Me.NumericUpDown_HotPixelFilterDistance, "NumericUpDown_HotPixelFilterDistance")
        Me.NumericUpDown_HotPixelFilterDistance.Maximum = New Decimal(New Integer() {20, 0, 0, 0})
        Me.NumericUpDown_HotPixelFilterDistance.Name = "NumericUpDown_HotPixelFilterDistance"
        '
        'TrackBar_HotPixel_Threshold
        '
        Me.TrackBar_HotPixel_Threshold.BackColor = System.Drawing.SystemColors.ButtonHighlight
        resources.ApplyResources(Me.TrackBar_HotPixel_Threshold, "TrackBar_HotPixel_Threshold")
        Me.TrackBar_HotPixel_Threshold.Maximum = 6000
        Me.TrackBar_HotPixel_Threshold.Name = "TrackBar_HotPixel_Threshold"
        Me.TrackBar_HotPixel_Threshold.TickFrequency = 495
        Me.TrackBar_HotPixel_Threshold.TickStyle = System.Windows.Forms.TickStyle.None
        '
        'TabPage_TPMark
        '
        Me.TabPage_TPMark.Controls.Add(Me.CheckBox_TPMark_Enable)
        Me.TabPage_TPMark.Controls.Add(Me.GroupBox_TPMark_Setting)
        Me.TabPage_TPMark.Controls.Add(Me.CheckBox_TPMark_ShowResult)
        Me.TabPage_TPMark.Controls.Add(Me.Button_Save_TPMark)
        Me.TabPage_TPMark.Controls.Add(Me.Button_TPMark_PatTest)
        Me.TabPage_TPMark.Controls.Add(Me.Panel_AxMDisplay_TPMark)
        Me.TabPage_TPMark.Controls.Add(Me.CheckedListBox_TPMark)
        Me.TabPage_TPMark.Controls.Add(Me.Label_TPMark_CurrentMark)
        resources.ApplyResources(Me.TabPage_TPMark, "TabPage_TPMark")
        Me.TabPage_TPMark.Name = "TabPage_TPMark"
        Me.TabPage_TPMark.UseVisualStyleBackColor = True
        '
        'CheckBox_TPMark_Enable
        '
        resources.ApplyResources(Me.CheckBox_TPMark_Enable, "CheckBox_TPMark_Enable")
        Me.CheckBox_TPMark_Enable.Name = "CheckBox_TPMark_Enable"
        Me.CheckBox_TPMark_Enable.UseVisualStyleBackColor = True
        '
        'GroupBox_TPMark_Setting
        '
        Me.GroupBox_TPMark_Setting.Controls.Add(Me.GroupBox_TPMarkSet)
        Me.GroupBox_TPMark_Setting.Controls.Add(Me.GroupBox_TPMark_Boundary)
        Me.GroupBox_TPMark_Setting.Controls.Add(Me.CheckBox_TPMark_RegionMannual)
        Me.GroupBox_TPMark_Setting.Controls.Add(Me.CheckBox_TPMark_ShowBoundary)
        resources.ApplyResources(Me.GroupBox_TPMark_Setting, "GroupBox_TPMark_Setting")
        Me.GroupBox_TPMark_Setting.Name = "GroupBox_TPMark_Setting"
        Me.GroupBox_TPMark_Setting.TabStop = False
        '
        'GroupBox_TPMarkSet
        '
        Me.GroupBox_TPMarkSet.Controls.Add(Me.ComboBox_TPMark_Action)
        Me.GroupBox_TPMarkSet.Controls.Add(Me.Label1)
        Me.GroupBox_TPMarkSet.Controls.Add(Me.NumericUpDown_TPMark_Acceptance)
        Me.GroupBox_TPMarkSet.Controls.Add(Me.Label53)
        Me.GroupBox_TPMarkSet.Controls.Add(Me.TextBox_TPMark_MarkName)
        Me.GroupBox_TPMarkSet.Controls.Add(Me.Label54)
        resources.ApplyResources(Me.GroupBox_TPMarkSet, "GroupBox_TPMarkSet")
        Me.GroupBox_TPMarkSet.Name = "GroupBox_TPMarkSet"
        Me.GroupBox_TPMarkSet.TabStop = False
        '
        'ComboBox_TPMark_Action
        '
        Me.ComboBox_TPMark_Action.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_TPMark_Action.FormattingEnabled = True
        Me.ComboBox_TPMark_Action.Items.AddRange(New Object() {resources.GetString("ComboBox_TPMark_Action.Items"), resources.GetString("ComboBox_TPMark_Action.Items1")})
        resources.ApplyResources(Me.ComboBox_TPMark_Action, "ComboBox_TPMark_Action")
        Me.ComboBox_TPMark_Action.Name = "ComboBox_TPMark_Action"
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'NumericUpDown_TPMark_Acceptance
        '
        resources.ApplyResources(Me.NumericUpDown_TPMark_Acceptance, "NumericUpDown_TPMark_Acceptance")
        Me.NumericUpDown_TPMark_Acceptance.Name = "NumericUpDown_TPMark_Acceptance"
        Me.NumericUpDown_TPMark_Acceptance.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'Label53
        '
        resources.ApplyResources(Me.Label53, "Label53")
        Me.Label53.Name = "Label53"
        '
        'TextBox_TPMark_MarkName
        '
        resources.ApplyResources(Me.TextBox_TPMark_MarkName, "TextBox_TPMark_MarkName")
        Me.TextBox_TPMark_MarkName.Name = "TextBox_TPMark_MarkName"
        '
        'Label54
        '
        resources.ApplyResources(Me.Label54, "Label54")
        Me.Label54.Name = "Label54"
        '
        'GroupBox_TPMark_Boundary
        '
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.NumericUpDown_TPMark_BoundaryRight)
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.NumericUpDown_TPMark_BoundaryLeft)
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.NumericUpDown_TPMark_BoundaryBottom)
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.NumericUpDown_TPMark_BoundaryTop)
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.Label55)
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.Label56)
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.Label57)
        Me.GroupBox_TPMark_Boundary.Controls.Add(Me.Label58)
        resources.ApplyResources(Me.GroupBox_TPMark_Boundary, "GroupBox_TPMark_Boundary")
        Me.GroupBox_TPMark_Boundary.Name = "GroupBox_TPMark_Boundary"
        Me.GroupBox_TPMark_Boundary.TabStop = False
        '
        'NumericUpDown_TPMark_BoundaryRight
        '
        resources.ApplyResources(Me.NumericUpDown_TPMark_BoundaryRight, "NumericUpDown_TPMark_BoundaryRight")
        Me.NumericUpDown_TPMark_BoundaryRight.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TPMark_BoundaryRight.Name = "NumericUpDown_TPMark_BoundaryRight"
        '
        'NumericUpDown_TPMark_BoundaryLeft
        '
        resources.ApplyResources(Me.NumericUpDown_TPMark_BoundaryLeft, "NumericUpDown_TPMark_BoundaryLeft")
        Me.NumericUpDown_TPMark_BoundaryLeft.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TPMark_BoundaryLeft.Name = "NumericUpDown_TPMark_BoundaryLeft"
        '
        'NumericUpDown_TPMark_BoundaryBottom
        '
        resources.ApplyResources(Me.NumericUpDown_TPMark_BoundaryBottom, "NumericUpDown_TPMark_BoundaryBottom")
        Me.NumericUpDown_TPMark_BoundaryBottom.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TPMark_BoundaryBottom.Name = "NumericUpDown_TPMark_BoundaryBottom"
        '
        'NumericUpDown_TPMark_BoundaryTop
        '
        resources.ApplyResources(Me.NumericUpDown_TPMark_BoundaryTop, "NumericUpDown_TPMark_BoundaryTop")
        Me.NumericUpDown_TPMark_BoundaryTop.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.NumericUpDown_TPMark_BoundaryTop.Name = "NumericUpDown_TPMark_BoundaryTop"
        '
        'Label55
        '
        resources.ApplyResources(Me.Label55, "Label55")
        Me.Label55.Name = "Label55"
        '
        'Label56
        '
        resources.ApplyResources(Me.Label56, "Label56")
        Me.Label56.Name = "Label56"
        '
        'Label57
        '
        resources.ApplyResources(Me.Label57, "Label57")
        Me.Label57.Name = "Label57"
        '
        'Label58
        '
        resources.ApplyResources(Me.Label58, "Label58")
        Me.Label58.Name = "Label58"
        '
        'CheckBox_TPMark_RegionMannual
        '
        resources.ApplyResources(Me.CheckBox_TPMark_RegionMannual, "CheckBox_TPMark_RegionMannual")
        Me.CheckBox_TPMark_RegionMannual.Name = "CheckBox_TPMark_RegionMannual"
        Me.CheckBox_TPMark_RegionMannual.UseVisualStyleBackColor = True
        '
        'CheckBox_TPMark_ShowBoundary
        '
        resources.ApplyResources(Me.CheckBox_TPMark_ShowBoundary, "CheckBox_TPMark_ShowBoundary")
        Me.CheckBox_TPMark_ShowBoundary.Name = "CheckBox_TPMark_ShowBoundary"
        Me.CheckBox_TPMark_ShowBoundary.UseVisualStyleBackColor = True
        '
        'CheckBox_TPMark_ShowResult
        '
        resources.ApplyResources(Me.CheckBox_TPMark_ShowResult, "CheckBox_TPMark_ShowResult")
        Me.CheckBox_TPMark_ShowResult.Name = "CheckBox_TPMark_ShowResult"
        Me.CheckBox_TPMark_ShowResult.UseVisualStyleBackColor = True
        '
        'Button_Save_TPMark
        '
        resources.ApplyResources(Me.Button_Save_TPMark, "Button_Save_TPMark")
        Me.Button_Save_TPMark.Name = "Button_Save_TPMark"
        Me.Button_Save_TPMark.UseVisualStyleBackColor = True
        '
        'Button_TPMark_PatTest
        '
        resources.ApplyResources(Me.Button_TPMark_PatTest, "Button_TPMark_PatTest")
        Me.Button_TPMark_PatTest.Name = "Button_TPMark_PatTest"
        Me.Button_TPMark_PatTest.UseVisualStyleBackColor = True
        '
        'Panel_AxMDisplay_TPMark
        '
        Me.Panel_AxMDisplay_TPMark.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        resources.ApplyResources(Me.Panel_AxMDisplay_TPMark, "Panel_AxMDisplay_TPMark")
        Me.Panel_AxMDisplay_TPMark.Name = "Panel_AxMDisplay_TPMark"
        '
        'CheckedListBox_TPMark
        '
        resources.ApplyResources(Me.CheckedListBox_TPMark, "CheckedListBox_TPMark")
        Me.CheckedListBox_TPMark.Name = "CheckedListBox_TPMark"
        '
        'Label_TPMark_CurrentMark
        '
        resources.ApplyResources(Me.Label_TPMark_CurrentMark, "Label_TPMark_CurrentMark")
        Me.Label_TPMark_CurrentMark.Name = "Label_TPMark_CurrentMark"
        '
        'Label_Pattern
        '
        resources.ApplyResources(Me.Label_Pattern, "Label_Pattern")
        Me.Label_Pattern.Name = "Label_Pattern"
        '
        'ComboBox_Pattern
        '
        Me.ComboBox_Pattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        resources.ApplyResources(Me.ComboBox_Pattern, "ComboBox_Pattern")
        Me.ComboBox_Pattern.Name = "ComboBox_Pattern"
        '
        'ContextMenuStrip_PLMark
        '
        Me.ContextMenuStrip_PLMark.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem_AddPLMark, Me.ToolStripMenuItem_RemovePLMark})
        Me.ContextMenuStrip_PLMark.Name = "ContextMenuStrip_PLMark"
        resources.ApplyResources(Me.ContextMenuStrip_PLMark, "ContextMenuStrip_PLMark")
        '
        'ToolStripMenuItem_AddPLMark
        '
        Me.ToolStripMenuItem_AddPLMark.Name = "ToolStripMenuItem_AddPLMark"
        resources.ApplyResources(Me.ToolStripMenuItem_AddPLMark, "ToolStripMenuItem_AddPLMark")
        '
        'ToolStripMenuItem_RemovePLMark
        '
        Me.ToolStripMenuItem_RemovePLMark.Name = "ToolStripMenuItem_RemovePLMark"
        resources.ApplyResources(Me.ToolStripMenuItem_RemovePLMark, "ToolStripMenuItem_RemovePLMark")
        '
        'ContextMenuStrip_TPMark
        '
        Me.ContextMenuStrip_TPMark.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem_AddTPMark, Me.ToolStripMenuItem_RemoveTPMark, Me.ToolStripMenuItem_EditTPMark})
        Me.ContextMenuStrip_TPMark.Name = "ContextMenuStrip_PLMark"
        resources.ApplyResources(Me.ContextMenuStrip_TPMark, "ContextMenuStrip_TPMark")
        '
        'ToolStripMenuItem_AddTPMark
        '
        Me.ToolStripMenuItem_AddTPMark.Name = "ToolStripMenuItem_AddTPMark"
        resources.ApplyResources(Me.ToolStripMenuItem_AddTPMark, "ToolStripMenuItem_AddTPMark")
        '
        'ToolStripMenuItem_RemoveTPMark
        '
        Me.ToolStripMenuItem_RemoveTPMark.Name = "ToolStripMenuItem_RemoveTPMark"
        resources.ApplyResources(Me.ToolStripMenuItem_RemoveTPMark, "ToolStripMenuItem_RemoveTPMark")
        '
        'ToolStripMenuItem_EditTPMark
        '
        Me.ToolStripMenuItem_EditTPMark.Name = "ToolStripMenuItem_EditTPMark"
        resources.ApplyResources(Me.ToolStripMenuItem_EditTPMark, "ToolStripMenuItem_EditTPMark")
        '
        'Dialog_FuncSetting
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Label_Pattern)
        Me.Controls.Add(Me.TabControl_Setting)
        Me.Controls.Add(Me.ComboBox_Pattern)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_FuncSetting"
        Me.ShowInTaskbar = False
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TabControl_Setting.ResumeLayout(False)
        Me.TabPage_Point.ResumeLayout(False)
        Me.TabPage_Point.PerformLayout()
        Me.GroupBox_WakuSetting.ResumeLayout(False)
        Me.GroupBox_WakuSetting.PerformLayout()
        CType(Me.NumericUpDown_WakuEdgeOffset, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WakuMaxValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WakuMinValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WakuEdgeWidth, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_WakuSplitNum, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_SeparateBP.ResumeLayout(False)
        Me.GroupBox_SeparateBP.PerformLayout()
        CType(Me.NumericUpDown_SeparateBPBlob, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_SeparateBPArea, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BPoint.ResumeLayout(False)
        Me.GroupBox_BPoint.PerformLayout()
        CType(Me.NumericUpDown_BP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Threshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_CheckBox_Inverse_Point_FixArea, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PointMode.ResumeLayout(False)
        Me.GroupBox_PointMode.PerformLayout()
        Me.GroupBox_PointCommonSetting.ResumeLayout(False)
        Me.GroupBox_PointCommonSetting.PerformLayout()
        CType(Me.NumericUpDown_DP_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_OverNum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_ByPassY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_ByPassX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_DPoint.ResumeLayout(False)
        Me.GroupBox_DPoint.PerformLayout()
        CType(Me.NumericUpDown_DP_Threshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_RimThreshold_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Point_Characteristic.ResumeLayout(False)
        Me.GroupBox_DP_Characteristics.ResumeLayout(False)
        Me.GroupBox_DP_Characteristics.PerformLayout()
        CType(Me.NumericUpDown_DP_MinGray_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Compactness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_StdDev_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_MinGray_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_GrayMean_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Fullness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DP_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BP_Characteristics.ResumeLayout(False)
        Me.GroupBox_BP_Characteristics.PerformLayout()
        CType(Me.NumericUpDown_BP_MaxGray_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_StdDev_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Compactness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_MaxGray_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_GrayMean_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_MaxGray_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Fullness_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Fullness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BP_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_GSBP.ResumeLayout(False)
        Me.TabPage_GSBP.PerformLayout()
        Me.GroupBox_BLDPCommonSetting.ResumeLayout(False)
        Me.GroupBox_BLDPCommonSetting.PerformLayout()
        CType(Me.NumericUpDown_BLDP_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_Elongation_Max, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_Fatness_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_OverNum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_Scratch_Length, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_RangeY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_RangeX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_Count_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BLDP.ResumeLayout(False)
        Me.GroupBox_BLDP.PerformLayout()
        CType(Me.NumericUpDown_BLDP_EnhanceCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_ThresholdRim, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BLDP_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_GSBPCommonSetting.ResumeLayout(False)
        Me.GroupBox_GSBPCommonSetting.PerformLayout()
        CType(Me.NumericUpDown_GSBP_GrayMax_Low, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_GrayMax_High, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_NumOfHoles, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_OverNum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_Scratch_Length, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_RangeY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_RangeX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_Count_Min, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_AreaMin, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_AreaMax, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_GSBP.ResumeLayout(False)
        Me.GroupBox_GSBP.PerformLayout()
        CType(Me.NumericUpDown_GSBP_ThresholdRim, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GSBP_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Line.ResumeLayout(False)
        Me.TabPage_Line.PerformLayout()
        Me.GroupBox_DLine.ResumeLayout(False)
        Me.GroupBox_DLine.PerformLayout()
        CType(Me.NumericUpDown_DL_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_DL_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_DL_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_DL_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LeakPointRadius, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_Elongation_Min, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BLine.ResumeLayout(False)
        Me.GroupBox_BLine.PerformLayout()
        CType(Me.TrackBar_BL_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BL_RimThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BL_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_BL_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_LineCommonSetting.ResumeLayout(False)
        Me.GroupBox_LineCommonSetting.PerformLayout()
        CType(Me.NumericUpDown_Line_Short_Cut_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_Cut_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassRightV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassLeftV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Block_OverNumber, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_Short_Cut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassUpH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_ByPassDownH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_Cut, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_OverNumber, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MeanDiff.ResumeLayout(False)
        Me.GroupBox_MeanDiff.PerformLayout()
        CType(Me.NumericUpDown_MeanDifference, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_MeanDifference, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_GrayAbnormal.ResumeLayout(False)
        Me.TabPage_GrayAbnormal.PerformLayout()
        Me.GroupBox_GrayAbnormal.ResumeLayout(False)
        Me.GroupBox_GrayAbnormal.PerformLayout()
        CType(Me.NumericUpDown_GrayAbnormal_NoDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormal_NegLimit, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormalStandardGray, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayAbnormal_PosLimit, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Auto.ResumeLayout(False)
        Me.GroupBox_AutoExposure.ResumeLayout(False)
        Me.GroupBox_AutoExposure.PerformLayout()
        CType(Me.NumericUpDown_AutoExposure_GrabDelayTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_DL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_SmallErrorRange, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_LargeErrorRange_UL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_TargetMean, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AutoExposure_Kp, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Other.ResumeLayout(False)
        Me.TabPage_Other.PerformLayout()
        Me.GroupBox_AiSetting.ResumeLayout(False)
        Me.GroupBox_AiSetting.PerformLayout()
        CType(Me.NumericUpDown_AiResizeY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AiResizeX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_ImgProcBoundary.ResumeLayout(False)
        Me.GroupBox_ImgProcBoundary.PerformLayout()
        CType(Me.NumericUpDown_Boundary_MulWidth_RX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_BY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_LX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Boundary_MulWidth_TY, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_LinePitchSetting.ResumeLayout(False)
        Me.GroupBox_LinePitchSetting.PerformLayout()
        CType(Me.NumericUpDown_Line_PitchY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Line_PitchX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_LineAverageFilter.ResumeLayout(False)
        Me.GroupBox_LineAverageFilter.PerformLayout()
        CType(Me.NumericUpDown_AverageFilter, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Point_Algorithm.ResumeLayout(False)
        Me.GroupBox_Point_Algorithm.PerformLayout()
        Me.GroupBox_PointPitchSetting.ResumeLayout(False)
        Me.GroupBox_PointPitchSetting.PerformLayout()
        CType(Me.NumericUpDown_Point_PitchY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Point_PitchX, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_Mark.ResumeLayout(False)
        Me.TabPage_Mark.PerformLayout()
        Me.GroupBox_PLMark_Setting.ResumeLayout(False)
        Me.GroupBox_PLMark_Setting.PerformLayout()
        Me.GroupBox_MatchSetting.ResumeLayout(False)
        Me.GroupBox_MatchSetting.PerformLayout()
        CType(Me.NumericUpDown_GrayMarkErodeCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GrayMarkSmoothCount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PLMark_SearchMode.ResumeLayout(False)
        Me.GroupBox_PLMark_SearchMode.PerformLayout()
        CType(Me.NumericUpDown_SearchMarkCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_SearchRange_PLMark_Multiple, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PLMarkSet.ResumeLayout(False)
        Me.GroupBox_PLMarkSet.PerformLayout()
        CType(Me.NumericUpDown_MarkGroup, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_PLMark_Acceptance, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_PLMark_Boundary.ResumeLayout(False)
        Me.GroupBox_PLMark_Boundary.PerformLayout()
        CType(Me.NumericUpDown_PLMark_BoundaryRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_PLMark_BoundaryLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_PLMark_BoundaryBottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_PLMark_BoundaryTop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BypassSetting.ResumeLayout(False)
        Me.GroupBox_BypassSetting.PerformLayout()
        CType(Me.NumericUpDown_BlobArea, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_PLMark_DilateCount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_MarkTH, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_HotPixel.ResumeLayout(False)
        Me.TabPage_HotPixel.PerformLayout()
        Me.GroupBox_HotPixel.ResumeLayout(False)
        Me.GroupBox_HotPixel.PerformLayout()
        CType(Me.NumericUpDown_HotPixelMaxMean, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HotPixelRecipe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_HotPixelFilterDistance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_HotPixel_Threshold, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage_TPMark.ResumeLayout(False)
        Me.TabPage_TPMark.PerformLayout()
        Me.GroupBox_TPMark_Setting.ResumeLayout(False)
        Me.GroupBox_TPMark_Setting.PerformLayout()
        Me.GroupBox_TPMarkSet.ResumeLayout(False)
        Me.GroupBox_TPMarkSet.PerformLayout()
        CType(Me.NumericUpDown_TPMark_Acceptance, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_TPMark_Boundary.ResumeLayout(False)
        Me.GroupBox_TPMark_Boundary.PerformLayout()
        CType(Me.NumericUpDown_TPMark_BoundaryRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_TPMark_BoundaryLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_TPMark_BoundaryBottom, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_TPMark_BoundaryTop, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip_PLMark.ResumeLayout(False)
        Me.ContextMenuStrip_TPMark.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TabControl_Setting As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Point As System.Windows.Forms.TabPage
    Friend WithEvents TabPage_Line As System.Windows.Forms.TabPage
    Friend WithEvents RadioButton_Line_Cut As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Line_ByPassDownH As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Line_ByPassUpH As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_Cut As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_ByPassDownH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_ByPassUpH As System.Windows.Forms.NumericUpDown
    Friend WithEvents TabPage_Other As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_BPoint As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BP_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_LoadImage As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents CheckBox_Point_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Line_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_Pattern As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox_PointCommonSetting As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_DPoint As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_DP_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Point_OverNum As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Point_OverNum As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Point_ByPassY As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Point_ByPassX As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_AreaMin As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_AreaMax As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Point_ByPassY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Point_ByPassX As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_PointMode As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BPDP As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_MeanDiff As System.Windows.Forms.GroupBox
    Friend WithEvents Button_MeanRange As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TrackBar_MeanDifference As System.Windows.Forms.TrackBar
    Friend WithEvents NumericUpDown_MeanDifference As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_PointPitchSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Point_PitchY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Point_PitchX As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_OverNum As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_OverNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Align_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage_GrayAbnormal As System.Windows.Forms.TabPage
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormalStandardGray As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_GrayAbnormal_PosLimit As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_GrayAbnormal_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_GrayAbnormal As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Point_Algorithm As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_PointAlgorithm_0 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_PointAlgorithm_1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Line_ShortCut As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_Short_Cut As System.Windows.Forms.NumericUpDown
    Friend WithEvents TabPage_Auto As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_AutoExposure As System.Windows.Forms.GroupBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AutoExposure_SmallErrorRange As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_AutoExposure_LargeErrorRange_UL As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_AutoExposure_TargetMean As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_AutoExposure_Kp As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_HalfScreen_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_LineCommonSetting As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_HLine_NotAddToOutput As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_FuncRawDataFilterMura_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_VLine_NotAddToOutput As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_BP_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_RimThreshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_RimThreshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_AutoExposure_LargeErrorRange_DL As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Block_OverNumber As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Block_OverNum As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GrayAbnormal_NegLimit As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Lbl_GrayAbnormal_NegLimit As System.Windows.Forms.Label
    Friend WithEvents Lbl_GrayAbnormal_PosLimit As System.Windows.Forms.Label
    Friend WithEvents GroupBox_LinePitchSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Line_PitchY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_PitchX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_LineAverageFilter As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_BLine As System.Windows.Forms.GroupBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TrackBar_DL_RimThreshold As System.Windows.Forms.TrackBar
    Friend WithEvents NumericUpDown_DL_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BL_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BL_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DL_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DL_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents TrackBar_DL_Threshold As System.Windows.Forms.TrackBar
    Friend WithEvents TrackBar_BL_Threshold As System.Windows.Forms.TrackBar
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TrackBar_BL_RimThreshold As System.Windows.Forms.TrackBar
    Friend WithEvents NumericUpDown_BL_RimThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Boundary_MulWidth_LX As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_BLine_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_DLine As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_DLine_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Inverse_Point_DefectType As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_CheckBox_Inverse_Point_FixArea As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Inverse_Point_EnableFixArea As System.Windows.Forms.CheckBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Boundary_MulWidth_TY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_ImgProcBoundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Boundary_MulWidth_RX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Boundary_MulWidth_BY As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents RadioButton_PointAlgorithm_2 As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage_Mark As System.Windows.Forms.TabPage
    Friend WithEvents Label_PLMark_CurrentMark As System.Windows.Forms.Label
    Friend WithEvents CheckedListBox_PLMark As System.Windows.Forms.CheckedListBox
    Friend WithEvents Panel_AxMDisplay_PLMark As System.Windows.Forms.Panel
    Friend WithEvents GroupBox_PLMark_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_PLMark_ShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_PLMark_RegionMannual As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_PLMark_Boundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_PLMark_BoundaryTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_PLMark_BoundaryRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_PLMark_BoundaryLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_PLMark_BoundaryBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_PLMarkSet As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox_PLMark_MarkName As System.Windows.Forms.TextBox
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_PLMark_Acceptance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_CurrentPLMark_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents Button_PLMark_PatTest As System.Windows.Forms.Button
    Friend WithEvents GroupBox_PLMark_SearchMode As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Save_PLMark As System.Windows.Forms.Button
    Friend WithEvents ContextMenuStrip_PLMark As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem_RemovePLMark As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AutoExposure_GrabDelayTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_SearchRange_PLMark_Multiple As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_SearchRange_PLMark_Multiple As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AverageFilter As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_AreaMin As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP_AreaMax As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Report_Multi_Pixel As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_DP_RimThreshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_RimThreshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP_Threshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_Threshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_PointAlgorithm_3 As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_PLMark_DilateCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents TabPage_HotPixel As System.Windows.Forms.TabPage
    Friend WithEvents CheckBox_HotPixelEnable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_HotPixel As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_HotPixel_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_HotPixelRecipe As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HotPixelFilterDistance As System.Windows.Forms.NumericUpDown
    Friend WithEvents TrackBar_HotPixel_Threshold As System.Windows.Forms.TrackBar
    Friend WithEvents NumericUpDown_Line_ByPassRightV As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_ByPassRightV As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_ByPassLeftV As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_ByPassLeftV As System.Windows.Forms.RadioButton
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_HotPixelMaxMean As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_CPD_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_PointAlgorithm_4 As System.Windows.Forms.RadioButton
    Friend WithEvents TabPage_Point_Characteristic As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_BP_Characteristics As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BP_Elongation_Max As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_Elongation_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_Fullness_Max As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_Fullness_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_Fullness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_Threshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_Threshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BP_RimThreshold_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_RimThreshold_Low As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_MaxGray_Fullness_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_MaxGray_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_DP_Characteristics As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_DP_MaxGray_Fullness_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_MaxGray_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_Fullness_Max As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP_Fullness_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_Fullness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_Fullness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_Elongation_Max As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP_Elongation_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_DP_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_GrayMean_Max As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_GrayMean_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_GrayMean_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_GrayMean_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_MaxGray_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_MaxGray_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_MinGray_Max As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_MinGray_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_DP_StdDev_Max As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_StdDev_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckedListBox_TPMark As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label_TPMark_CurrentMark As System.Windows.Forms.Label
    Friend WithEvents Panel_AxMDisplay_TPMark As System.Windows.Forms.Panel
    Friend WithEvents CheckBox_TPMark_ShowResult As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Save_TPMark As System.Windows.Forms.Button
    Friend WithEvents Button_TPMark_PatTest As System.Windows.Forms.Button
    Friend WithEvents CheckBox_TPMark_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_TPMark_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_TPMarkSet As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_TPMark_Acceptance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents TextBox_TPMark_MarkName As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_TPMark_Boundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_TPMark_BoundaryRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_TPMark_BoundaryLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_TPMark_BoundaryBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_TPMark_BoundaryTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_TPMark_RegionMannual As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_TPMark_ShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents ContextMenuStrip_TPMark As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem_AddTPMark As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_RemoveTPMark As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_EditTPMark As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_TPMark_Action As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage_TPMark As System.Windows.Forms.TabPage
    Friend WithEvents RadioButton_PointAlgorithm_5 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BP_Compactness_Max As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_Compactness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Filter_HotPixel_With_Characteristics As System.Windows.Forms.CheckBox
    Friend WithEvents RadioButton_PLMark_Original As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_PLMark_Bin As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_PointAlgorithm_6 As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BP_StdDev_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BP_StdDev_Max As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_DP_Compactness_Max As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_DP_Compactness_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_Filter_VH_Scratch As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage_GSBP As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox_GSBP As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_GSBP_ThresholdRim As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_RimThreshold As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_GSBPCommonSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_GSBP_Scratch_Length As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_Scratch_Length As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_RangeY As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_RangeY As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_RangeX As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_RangeX As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_Count_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_Count_Min As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_GSBP_AreaMin As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_GSBP_AreaMax As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_GSBP_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_GSBP_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_GSBP_OverNum As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_OverNum As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_BLDP As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BLDP_ThresholdRim As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_Threshold As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_Threshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_RimThreshold As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_BLDPCommonSetting As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BLDP_OverNum As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_OverNum As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_Scratch_Length As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_Scratch_Length As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_RangeY As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_RangeY As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_RangeX As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_RangeX As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_Count_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_Count_Min As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BLDP_AreaMin As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BLDP_AreaMax As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_AreaMin As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_BLDP_AreaMax As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_BLDP_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_BLDP_EnhanceCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_EnhanceCount As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_Fatness_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_Fatness_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_Elongation_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_Elongation_Max As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_BLDP_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_BLDP_Elongation_Min As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_Elongation_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BlobArea As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayAbnormal_NoDisplay As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_MarkTH As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_BypassSetting As System.Windows.Forms.GroupBox
    Friend WithEvents ToolStripMenuItem_AddPLMark As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RadioButton_GSBP_NumOfHoles As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_NumOfHoles As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_GrayMax_High As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_GrayMax_High As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_GSBP_GrayMax_Low As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_GSBP_GrayMax_Low As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_PLMark_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_SeparateBP As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_SeparateBPBlob As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_SeparateBPArea As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_SeparateBPEnable As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_MarkGroup As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_FillOfHole As System.Windows.Forms.CheckBox
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_MarkTH As System.Windows.Forms.CheckBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BP_MaxGray_Max As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_DP_MinGray_Min As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_AiSetting As System.Windows.Forms.GroupBox
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AiResizeY As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_AiResizeX As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_EnableLeakPoint As System.Windows.Forms.CheckBox
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LeakPointRadius As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_Line_Short_Cut_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_ShortCut_H As System.Windows.Forms.RadioButton
    Friend WithEvents NumericUpDown_Line_Cut_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents RadioButton_Line_Cut_H As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_BlobFillHole As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_MatchSetting As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_PreProcess As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox_MatchImg As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_BypassRegion As System.Windows.Forms.ComboBox
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayMarkSmoothCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_GrayMarkErodeCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_SearchMarkCount As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_IsAISaveROI As System.Windows.Forms.ComboBox
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_Waku_Inspect_Enable As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_WakuSetting As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox_WakuEdge As System.Windows.Forms.ComboBox
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WakuMaxValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WakuMinValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WakuEdgeOffset As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_WakuEdgeWidth As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_WakuSplitNum As System.Windows.Forms.NumericUpDown

End Class
