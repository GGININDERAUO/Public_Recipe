<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_FuncSettingBase
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_FuncSettingBase))
        Me.TabControl_FuncSetting = New System.Windows.Forms.TabControl()
        Me.TabPage_Model = New System.Windows.Forms.TabPage()
        Me.ListView_Model = New System.Windows.Forms.ListView()
        Me.ColumnHeader_Model = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage_Pattern = New System.Windows.Forms.TabPage()
        Me.ListView_Pattern = New System.Windows.Forms.ListView()
        Me.ColumnHeader_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ContextMenuStrip_Model = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem_AddModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_RemoveModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_SetCurrentModel = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip_Pattern = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ToolStripMenuItem_AddPattern = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem_RemovePattern = New System.Windows.Forms.ToolStripMenuItem()
        Me.Button_Cancel = New System.Windows.Forms.Button()
        Me.TabControl_FuncSetting.SuspendLayout()
        Me.TabPage_Model.SuspendLayout()
        Me.TabPage_Pattern.SuspendLayout()
        Me.ContextMenuStrip_Model.SuspendLayout()
        Me.ContextMenuStrip_Pattern.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl_FuncSetting
        '
        resources.ApplyResources(Me.TabControl_FuncSetting, "TabControl_FuncSetting")
        Me.TabControl_FuncSetting.Controls.Add(Me.TabPage_Model)
        Me.TabControl_FuncSetting.Controls.Add(Me.TabPage_Pattern)
        Me.TabControl_FuncSetting.Name = "TabControl_FuncSetting"
        Me.TabControl_FuncSetting.SelectedIndex = 0
        '
        'TabPage_Model
        '
        resources.ApplyResources(Me.TabPage_Model, "TabPage_Model")
        Me.TabPage_Model.Controls.Add(Me.ListView_Model)
        Me.TabPage_Model.Name = "TabPage_Model"
        Me.TabPage_Model.UseVisualStyleBackColor = True
        '
        'ListView_Model
        '
        resources.ApplyResources(Me.ListView_Model, "ListView_Model")
        Me.ListView_Model.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.ListView_Model.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_Model})
        Me.ListView_Model.FullRowSelect = True
        Me.ListView_Model.MultiSelect = False
        Me.ListView_Model.Name = "ListView_Model"
        Me.ListView_Model.UseCompatibleStateImageBehavior = False
        Me.ListView_Model.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_Model
        '
        resources.ApplyResources(Me.ColumnHeader_Model, "ColumnHeader_Model")
        '
        'TabPage_Pattern
        '
        resources.ApplyResources(Me.TabPage_Pattern, "TabPage_Pattern")
        Me.TabPage_Pattern.Controls.Add(Me.ListView_Pattern)
        Me.TabPage_Pattern.Name = "TabPage_Pattern"
        Me.TabPage_Pattern.UseVisualStyleBackColor = True
        '
        'ListView_Pattern
        '
        resources.ApplyResources(Me.ListView_Pattern, "ListView_Pattern")
        Me.ListView_Pattern.Activation = System.Windows.Forms.ItemActivation.OneClick
        Me.ListView_Pattern.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_Pattern})
        Me.ListView_Pattern.FullRowSelect = True
        Me.ListView_Pattern.MultiSelect = False
        Me.ListView_Pattern.Name = "ListView_Pattern"
        Me.ListView_Pattern.UseCompatibleStateImageBehavior = False
        Me.ListView_Pattern.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_Pattern
        '
        resources.ApplyResources(Me.ColumnHeader_Pattern, "ColumnHeader_Pattern")
        '
        'ContextMenuStrip_Model
        '
        resources.ApplyResources(Me.ContextMenuStrip_Model, "ContextMenuStrip_Model")
        Me.ContextMenuStrip_Model.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem_AddModel, Me.ToolStripMenuItem_RemoveModel, Me.ToolStripMenuItem_SetCurrentModel})
        Me.ContextMenuStrip_Model.Name = "ContextMenuStrip_Model"
        '
        'ToolStripMenuItem_AddModel
        '
        resources.ApplyResources(Me.ToolStripMenuItem_AddModel, "ToolStripMenuItem_AddModel")
        Me.ToolStripMenuItem_AddModel.Name = "ToolStripMenuItem_AddModel"
        '
        'ToolStripMenuItem_RemoveModel
        '
        resources.ApplyResources(Me.ToolStripMenuItem_RemoveModel, "ToolStripMenuItem_RemoveModel")
        Me.ToolStripMenuItem_RemoveModel.Name = "ToolStripMenuItem_RemoveModel"
        '
        'ToolStripMenuItem_SetCurrentModel
        '
        resources.ApplyResources(Me.ToolStripMenuItem_SetCurrentModel, "ToolStripMenuItem_SetCurrentModel")
        Me.ToolStripMenuItem_SetCurrentModel.Name = "ToolStripMenuItem_SetCurrentModel"
        '
        'ContextMenuStrip_Pattern
        '
        resources.ApplyResources(Me.ContextMenuStrip_Pattern, "ContextMenuStrip_Pattern")
        Me.ContextMenuStrip_Pattern.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem_AddPattern, Me.ToolStripMenuItem_RemovePattern})
        Me.ContextMenuStrip_Pattern.Name = "ContextMenuStrip"
        '
        'ToolStripMenuItem_AddPattern
        '
        resources.ApplyResources(Me.ToolStripMenuItem_AddPattern, "ToolStripMenuItem_AddPattern")
        Me.ToolStripMenuItem_AddPattern.Name = "ToolStripMenuItem_AddPattern"
        '
        'ToolStripMenuItem_RemovePattern
        '
        resources.ApplyResources(Me.ToolStripMenuItem_RemovePattern, "ToolStripMenuItem_RemovePattern")
        Me.ToolStripMenuItem_RemovePattern.Name = "ToolStripMenuItem_RemovePattern"
        '
        'Button_Cancel
        '
        resources.ApplyResources(Me.Button_Cancel, "Button_Cancel")
        Me.Button_Cancel.Name = "Button_Cancel"
        Me.Button_Cancel.UseVisualStyleBackColor = True
        '
        'Dialog_FuncSettingBase
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.Button_Cancel)
        Me.Controls.Add(Me.TabControl_FuncSetting)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_FuncSettingBase"
        Me.ShowInTaskbar = False
        Me.TabControl_FuncSetting.ResumeLayout(False)
        Me.TabPage_Model.ResumeLayout(False)
        Me.TabPage_Pattern.ResumeLayout(False)
        Me.ContextMenuStrip_Model.ResumeLayout(False)
        Me.ContextMenuStrip_Pattern.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl_FuncSetting As System.Windows.Forms.TabControl
    Friend WithEvents TabPage_Model As System.Windows.Forms.TabPage
    Friend WithEvents ListView_Model As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Model As System.Windows.Forms.ColumnHeader
    Friend WithEvents ContextMenuStrip_Model As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem_AddModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_RemoveModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_SetCurrentModel As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage_Pattern As System.Windows.Forms.TabPage
    Friend WithEvents ListView_Pattern As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents ContextMenuStrip_Pattern As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ToolStripMenuItem_AddPattern As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem_RemovePattern As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Button_Cancel As System.Windows.Forms.Button

End Class
