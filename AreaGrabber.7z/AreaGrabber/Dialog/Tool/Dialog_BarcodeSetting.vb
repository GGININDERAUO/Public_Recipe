﻿Imports System.Windows.Forms
Imports System.IO
Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl

Public Class Dialog_BarcodeSetting
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig

    Private m_Left As Boolean
    Private m_Right As Boolean
    Private m_Top As Boolean
    Private m_Bottom As Boolean

    Private m_BarcodeBoundary As ClsParameterBoundary

    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_AxMDisplay As MIL_ID
    Private m_AxMDisplay_Barcode As MIL_ID = M_NULL
    Private m_Img_16U_Barcode_PreImgProc As MIL_ID = M_NULL
    Private m_Img_8U_Barcode_Bin As MIL_ID = M_NULL
    Private m_Img_8U_Barcode_Close As MIL_ID = M_NULL

    '--- 連線參數 ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar
    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private WithEvents m_ZoomContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents m_ZoomInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_OriginToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form)
        Dim image As MIL_ID = M_NULL

        Try
            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess
            Me.m_FuncProcess = form.MainProcess.FuncProcess
            Me.m_MuraProcess = form.MainProcess.MuraProcess

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            Else
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            End If

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
            Me.m_AxMDisplay = Me.m_Form.AxMDisplay
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)
            Me.m_Pen = New Pen(Color.White)
            Me.m_Form.PaintStop = True

            image = Me.m_FuncProcess.Img_Original_NonPage
            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If

            '--- UI ---
            Me.m_VScrollBar = Me.m_Form.VScrollBar
            Me.m_HScrollBar = Me.m_Form.HScrollBar

            Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
            Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
            Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
            Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
            Me.m_ZoomContextMenuStrip = Me.m_Form.ZoomContextMenuStrip
            Me.m_ZoomInToolStripMenuItem = Me.m_Form.ZoomInToolStripMenuItem
            Me.m_ZoomOutToolStripMenuItem = Me.m_Form.ZoomOutToolStripMenuItem
            Me.m_OriginToolStripMenuItem = Me.m_Form.OriginToolStripMenuItem
            Me.m_ZoomAllToolStripMenuItem = Me.m_Form.ZoomAllToolStripMenuItem

            If Me.m_AxMDisplay_Barcode <> M_NULL Then
                MdispFree(Me.m_AxMDisplay_Barcode)
                Me.m_AxMDisplay_Barcode = M_NULL
            End If
            MdispAlloc(Me.m_MainProcess.System_Host, M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay_Barcode)

            '--- UI ---
            Me.UpdateData()
            'Me.UpdateUserLevel()
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncSettingBase.SetMainForm]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Dialog Event ---"
    Private Sub Dialog_BarcodeSetting_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If
        Me.RadioButton_BoundaryFinish.Checked = True
        Me.m_Form.ImageUpdate()
        Me.m_Form.ImageZoomAll()
        'Me.UpdateUserLevel()
    End Sub

    Private Sub Dialog_BarcodeSetting_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_Form.TabControl_HightLevel.Enabled = True
        Me.m_Form.PaintStop = True
        Me.m_Form.Focus()
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub

    Private Sub Dialog_BarcodeSetting_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        If Me.m_AxMDisplay_Barcode <> M_NULL Then
            MdispFree(Me.m_AxMDisplay_Barcode)
        End If

        If Me.m_Img_16U_Barcode_PreImgProc <> M_NULL Then
            MbufFree(Me.m_Img_16U_Barcode_PreImgProc)
        End If

        If Me.m_Img_8U_Barcode_Bin <> M_NULL Then
            MbufFree(Me.m_Img_8U_Barcode_Bin)
        End If

        If Me.m_Img_8U_Barcode_Close <> M_NULL Then
            MbufFree(Me.m_Img_8U_Barcode_Close)
        End If

    End Sub

#End Region

#Region "--- 方法函式 ---"

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- UpdateData ---"

    Private Sub UpdateData()
        Dim ibc As ClsIPBootConfig
        Dim bcmr As ClsBarcodeModelRecipe
        ibc = Me.m_MainProcess.IPBootConfig
        Try
            bcmr = Me.m_MainProcess.FuncProcess.FuncModelRecipe.BarcodeModelRecipe
            Me.m_BarcodeBoundary = Me.m_MainProcess.FuncProcess.FuncModelRecipe.BarcodeModelRecipe.BarcodeBoundary

            '--- 第一頁 ---
            '--- [1] Barcode Color --
            If bcmr.BarcodeColor.Value = BarcodeColor.Black Then
                Me.RadioButton_BarcodeColor_Black.Checked = True
            ElseIf bcmr.BarcodeColor.Value = BarcodeColor.White Then
                Me.RadioButton_BarcodeColor_White.Checked = True
            End If

            '--- [2] ROI ---
            If Me.m_BarcodeBoundary.LeftX >= 0 And Me.m_BarcodeBoundary.RightX >= 0 And Me.m_BarcodeBoundary.TopY >= 0 And Me.m_BarcodeBoundary.BottomY >= 0 Then
                Me.NumericUpDown_BoundaryTop.Maximum = Me.m_BarcodeBoundary.BottomY - 1
                Me.NumericUpDown_BoundaryBottom.Maximum = Me.m_IPBootConfig.ImageSizeY.Value - 1
                Me.NumericUpDown_BoundaryBottom.Minimum = Me.m_BarcodeBoundary.TopY + 1
                Me.NumericUpDown_BoundaryLeft.Maximum = Me.m_BarcodeBoundary.RightX - 1
                Me.NumericUpDown_BoundaryRight.Maximum = Me.m_IPBootConfig.ImageSizeX.Value - 1
                Me.NumericUpDown_BoundaryRight.Minimum = Me.m_BarcodeBoundary.LeftX + 1

                If Me.m_BarcodeBoundary.TopY >= Me.NumericUpDown_BoundaryTop.Maximum Then Me.m_BarcodeBoundary.TopY = Me.NumericUpDown_BoundaryTop.Maximum
                If Me.m_BarcodeBoundary.BottomY >= Me.NumericUpDown_BoundaryBottom.Maximum Then Me.m_BarcodeBoundary.BottomY = Me.NumericUpDown_BoundaryBottom.Maximum
                If Me.m_BarcodeBoundary.LeftX >= Me.NumericUpDown_BoundaryLeft.Maximum Then Me.m_BarcodeBoundary.LeftX = Me.NumericUpDown_BoundaryLeft.Maximum
                If Me.m_BarcodeBoundary.RightX >= Me.NumericUpDown_BoundaryRight.Maximum Then Me.m_BarcodeBoundary.RightX = Me.NumericUpDown_BoundaryRight.Maximum

                Me.NumericUpDown_BoundaryTop.Value = Me.m_BarcodeBoundary.TopY
                Me.NumericUpDown_BoundaryBottom.Value = Me.m_BarcodeBoundary.BottomY
                Me.NumericUpDown_BoundaryLeft.Value = Me.m_BarcodeBoundary.LeftX
                Me.NumericUpDown_BoundaryRight.Value = Me.m_BarcodeBoundary.RightX
            End If

            '--- [3] Barcode Process Setting ---
            If bcmr.BarcodeMirror.Value Then
                Me.CheckBox_BarcodeMirror.Checked = True
            End If

            If bcmr.BarcodeAutoThreshold.Value Then
                Me.CheckBox_BarcodeAutoThreshold.Checked = True
            End If

            Me.NumericUpDown_BarcodeThresholdValue.Value = bcmr.BarcodeThresholdValue.Value
            Me.NumericUpDown_BarcodeImageCloseNum.Value = bcmr.BarcodeImageCloseNum.Value

            '--- [4] Barcode Enable Setting ---
            If bcmr.SaveBarcodeImage.Value Then
                Me.CheckBox_SaveBarcodeImage.Checked = True
            End If

            Me.RadioButton_BoundaryFinish.Checked = True
        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.UpdateData_Func]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.UpdateData_Func]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- Setting ---"

    Private Sub Setting()
        Dim ibc As ClsIPBootConfig
        Dim bcmr As ClsBarcodeModelRecipe
        ibc = Me.m_MainProcess.IPBootConfig

        Try
            bcmr = Me.m_MainProcess.FuncProcess.FuncModelRecipe.BarcodeModelRecipe
            Me.m_BarcodeBoundary = bcmr.BarcodeBoundary

            '--- 第一頁 ---
            '--- [1] Barcode Color --
            If Me.RadioButton_BarcodeColor_Black.Checked Then
                bcmr.BarcodeColor.Value = BarcodeColor.Black
            ElseIf Me.RadioButton_BarcodeColor_White.Checked Then
                bcmr.BarcodeColor.Value = BarcodeColor.White
            End If

            '--- [2] ROI ---
            Me.m_BarcodeBoundary.TopY = Me.NumericUpDown_BoundaryTop.Value
            Me.m_BarcodeBoundary.BottomY = Me.NumericUpDown_BoundaryBottom.Value
            Me.m_BarcodeBoundary.LeftX = Me.NumericUpDown_BoundaryLeft.Value
            Me.m_BarcodeBoundary.RightX = Me.NumericUpDown_BoundaryRight.Value

            '--- [3] Barcode Process Setting ---
            bcmr.BarcodeMirror.Value = Me.CheckBox_BarcodeMirror.Checked
            bcmr.BarcodeAutoThreshold.Value = Me.CheckBox_BarcodeAutoThreshold.Checked
            bcmr.BarcodeThresholdValue.Value = Me.NumericUpDown_BarcodeThresholdValue.Value
            bcmr.BarcodeImageCloseNum.Value = Me.NumericUpDown_BarcodeImageCloseNum.Value

            '--- [4] Barcode Enable Setting ---
            bcmr.SaveBarcodeImage.Value = Me.CheckBox_SaveBarcodeImage.Checked

        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Setting]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.Setting]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Save.Enabled = En
        Button_Close.Enabled = En
        Button_LoadImage.Enabled = En
    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "---SaveTempBoundary---"
    Private Sub SaveTempBoundary(ByVal fileName As String, ByVal pb As ClsParameterBoundary)
        Dim sw As StreamWriter
        sw = File.CreateText(fileName)

        Try
            sw.WriteLine("Top" & vbTab & "Buttom" & vbTab & "Left" & vbTab & "Right")
            sw.WriteLine(pb.TopY & "," & pb.BottomY & "," & pb.LeftX & "," & pb.RightX)

        Catch ex As Exception
            Throw New Exception("[Dialig_Align.SaveTempBoundary]SaveTempBoundary Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        Finally
            sw.Close()
        End Try

    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_LoadImage_Click ---"
    Private Sub Button_LoadImage_Click(sender As System.Object, e As System.EventArgs) Handles Button_LoadImage.Click
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                image = Me.m_FuncProcess.Img_Original_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_FuncProcess.Img_Original_NonPage)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(System.IO.Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 100000 '100 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        Button_Enable(True)
                        Exit Sub
                    End If

                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        If image <> M_NULL Then
                            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                            Type = MbufInquire(image, M_TYPE, M_NULL)

                            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                MbufFree(imageBuffer)
                                imageBuffer = M_NULL
                                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                            MbufCopy(image, imageBuffer)

                            MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                            MbufControl(image, M_MODIFIED, M_DEFAULT)
                            MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                            Me.m_Form.ResetScrollBar()
                        End If
                    Else
                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                If (Me.m_IPBootConfig.MuraUI.Value) Then
                    image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                    '[1] image2 ---
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                    If image2 <> M_NULL Then
                        If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image2)
                            image2 = M_NULL
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                    If Not Me.m_IPBootConfig.FuncUI.Value Then
                        '[2] Img_16U_Grab ---
                        If image2 <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                                Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                                Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)
                    End If

                    If Not Response_OK Then
                        Button_Enable(True)
                        Exit Sub
                    End If
                End If

            End If

            'If Me.m_Form.OpenFileDialog.FileName <> "" Then
            '    If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
            '        Try
            '            If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            '        Catch ex As Exception
            '            'MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
            '            Button_Enable(True)
            '        End Try
            '    Else
            '        If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
            '            MbufFree(Me.m_FuncProcess.Img_OriginalROI)
            '            Me.m_FuncProcess.Img_OriginalROI = M_NULL
            '        End If

            '        SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
            '        SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
            '        Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
            '    End If

            'End If
            Call Me.m_Form.ImageZoomAll()

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_FuncTestImageProcess.Button_LoadImage]" & ex.Message & "(" & ex.StackTrace & ")")
            'MessageBox.Show("[Dialog_FuncTestImageProcess.Button_LoadImage]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Save_Click ---"
    Private Sub Button_Save_Click(sender As System.Object, e As System.EventArgs) Handles Button_Save.Click
        Dim Parameter_Lists As String = ""
        Dim ipbc As ClsIPBootConfig
        Dim bcmr As ClsBarcodeModelRecipe
        Dim MasterSlaveMode As Integer = 0

        Try
            '---Button Control ---   
            Button_Enable(False)

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_Form.PaintStop = True

            ipbc = Me.m_MainProcess.IPBootConfig
            bcmr = Me.m_MainProcess.FuncProcess.FuncModelRecipe.BarcodeModelRecipe
            Me.m_BarcodeBoundary = bcmr.BarcodeBoundary
            Me.Setting()
            Me.m_MainProcess.SaveBoot()
            Me.m_MainProcess.SaveAreaBoot()

            '----------------------------------------------------------------------------------------------
            ' Dialog_IPBootConfig Setting   ==> Request_Command = "DIALOG_BARCODE_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_BARCODE_SETTING"
                TimeOut = 10000 '10 secs

                'UI Recipe Setting -----------------------------------

                '--- 第一頁 ---
                '---  ---
                Parameter_Lists = "BarcodeTop," & m_BarcodeBoundary.TopY & ";" & _
                                              "BarcodeBottom," & m_BarcodeBoundary.BottomY & ";" & _
                                              "BarcodeLeft," & m_BarcodeBoundary.LeftX & ";" & _
                                              "BarcodeRight," & m_BarcodeBoundary.RightX & ";" & _
                                              "BarcodeColor," & bcmr.BarcodeColor.Value & ";" & _
                                              "BarcodeMirror," & bcmr.BarcodeMirror.Value & ";" & _
                                              "BarcodeAutoThreshold," & bcmr.BarcodeAutoThreshold.Value & ";" & _
                                              "BarcodeThresholdValue," & bcmr.BarcodeThresholdValue.Value & ";" & _
                                              "BarcodeImageCloseNum," & bcmr.BarcodeImageCloseNum.Value & ";" & _
                                              "SaveBarcodeImage," & bcmr.SaveBarcodeImage.Value & ";"

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_Barcode Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_Barcode.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Boot Config Recipe ==> Request_Command = "SAVE_ALL_FUNC_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_ALL_FUNC_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Boot Config Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_Barcode.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '---Button Control ---   
            Button_Enable(True)

            Me.Update()
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_Barcode.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_Barcode.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Cancel_Click ---"
    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub
#End Region

#Region "--- Button_BarcodeReader_Click ---"
    Private Sub Button_BarcodeReader_Click(sender As System.Object, e As System.EventArgs) Handles Button_BarcodeReader.Click
        Dim Image As MIL_ID = M_NULL
        Dim OutputString As String = ""
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim strPath = ""
        Dim IP_Address As String = ""
        Dim Result As DialogResult

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Image = MdispInquire(Me.m_Form.AxMDisplay, M_SELECTED, M_NULL)
            If Image = M_NULL Then
                MsgBox("請載入影像")
            Else
                '----------------------------------------------------------------------------------------------------------------------
                ' Barcode Reader  ==> Request_Command = "CALCULATE_BARCODE_READER" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_BARCODE_READER"
                    TimeOut = 3000000 '3000 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        OutputString = SubSystemResult.Responses(0).Param1
                    ElseIf SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.ERR Then
                        OutputString = SubSystemResult.Responses(0).Param1
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            '--- Update Image ---
            LoadResultImage(IP_Address, "Img_16U_BarcodePreImgProc.tif", Me.m_Img_16U_Barcode_PreImgProc)
            LoadResultImage(IP_Address, "Img_16U_BarcodeBin.tif", Me.m_Img_8U_Barcode_Bin)
            LoadResultImage(IP_Address, "Img_16U_BarcodeClose.tif", Me.m_Img_8U_Barcode_Close)

            If MdispInquire(Me.m_AxMDisplay_Barcode, M_SELECTED, M_NULL) = M_NULL Then
                If Me.RadioButton_PreImgProc.Checked = True Then
                    Me.RadioButton_PreImgProc.Checked = False
                    Me.RadioButton_PreImgProc.Checked = True
                ElseIf Me.RadioButton_Bin.Checked = True Then
                    Me.RadioButton_Bin.Checked = False
                    Me.RadioButton_Bin.Checked = True
                Else
                    Me.RadioButton_Close.Checked = False
                    Me.RadioButton_Bin.Checked = True
                End If
            End If

            Result = MessageBox.Show(OutputString, "Message", MessageBoxButtons.OK)

            '--- Button Control ---   
            Button_Enable(True)

        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LoadResultImage(ByVal IP_Address As String, ByVal ImgFileName As String, ByRef LoadImage As MIL_ID)
        Dim SizeX, SizeY, Type As Integer

        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & ImgFileName
            strPath = strPath.Replace("\\", "\")
        Else
            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & ImgFileName
            RepairPath_2(strPath)
        End If

        If System.IO.File.Exists(strPath) Then
            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
            MbufDiskInquire(strPath, M_TYPE, Type)
            If LoadImage <> M_NULL Then
                If MbufInquire(LoadImage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(LoadImage, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(LoadImage)
                    LoadImage = M_NULL
                    LoadImage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
            Else
                LoadImage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
            End If

            '--- Load Remote Image ---
            MbufLoad(strPath, LoadImage)

            If System.IO.File.Exists(strPath) = True Then
                System.IO.File.Delete(strPath)
            End If
        End If

    End Sub

#End Region

#End Region

#Region "--- MouseDown ---"

#Region "--- MouseDownPageROI ---"
    Private Sub MouseDownPageROI(ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.RadioButton_BoundaryManual.Checked And Me.CheckBox_ShowBoundary.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

            If ZoomX <= 0 Then ZoomX = 0.1 '2012/09/05 Rick add
            If ZoomY <= 0 Then ZoomY = 0.1 '2012/09/05 Rick add

            p = (Me.NumericUpDown_BoundaryLeft.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = (Me.NumericUpDown_BoundaryRight.Value - Me.m_Form.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right = True
                End If
            End If
            p = (Me.NumericUpDown_BoundaryTop.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = (Me.NumericUpDown_BoundaryBottom.Value - Me.m_Form.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Top = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Bottom = True
                End If
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- MouseMove ---"

#Region "--- MouseMovePageROI ---"
    Private Sub MouseMovePageROI()
        If Me.RadioButton_BoundaryManual.Checked And Me.CheckBox_ShowBoundary.Checked Then
            If Me.m_Left Then
                If Me.m_Form.MouseX >= Me.NumericUpDown_BoundaryRight.Value Then
                    Me.NumericUpDown_BoundaryLeft.Value = Me.NumericUpDown_BoundaryRight.Value - 1
                Else
                    If Me.m_Form.MouseX <= Me.NumericUpDown_BoundaryLeft.Minimum Then
                        Me.NumericUpDown_BoundaryLeft.Value = Me.NumericUpDown_BoundaryLeft.Minimum
                    Else
                        Me.NumericUpDown_BoundaryLeft.Value = Me.m_Form.MouseX
                    End If
                End If
            End If

            If Me.m_Right Then
                If Me.m_Form.MouseX <= Me.NumericUpDown_BoundaryLeft.Value Then
                    Me.NumericUpDown_BoundaryRight.Value = Me.NumericUpDown_BoundaryLeft.Value + 1
                Else
                    If Me.m_Form.MouseX >= Me.NumericUpDown_BoundaryRight.Maximum Then
                        Me.NumericUpDown_BoundaryRight.Value = Me.NumericUpDown_BoundaryRight.Maximum - 1
                    Else
                        Me.NumericUpDown_BoundaryRight.Value = Me.m_Form.MouseX
                    End If
                End If
            End If

            If Me.m_Top Then
                If Me.m_Form.MouseY >= Me.NumericUpDown_BoundaryBottom.Value Then
                    Me.NumericUpDown_BoundaryTop.Value = Me.NumericUpDown_BoundaryBottom.Value - 1
                Else
                    If Me.m_Form.MouseY <= Me.NumericUpDown_BoundaryTop.Minimum Then
                        Me.NumericUpDown_BoundaryTop.Value = Me.NumericUpDown_BoundaryTop.Minimum
                    Else
                        Me.NumericUpDown_BoundaryTop.Value = Me.m_Form.MouseY
                    End If
                End If
            End If

            If Me.m_Bottom Then
                If Me.m_Form.MouseY <= Me.NumericUpDown_BoundaryTop.Value Then
                    Me.NumericUpDown_BoundaryBottom.Value = Me.NumericUpDown_BoundaryTop.Value + 1
                Else
                    If Me.m_Form.MouseY >= Me.NumericUpDown_BoundaryBottom.Maximum Then
                        Me.NumericUpDown_BoundaryBottom.Value = Me.NumericUpDown_BoundaryBottom.Maximum - 1
                    Else
                        Me.NumericUpDown_BoundaryBottom.Value = Me.m_Form.MouseY
                    End If
                End If
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"
#Region "--- CheckBox_ShowBoundary_CheckedChanged ---"
    Private Sub CheckBox_ShowBoundary_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_ShowBoundary.CheckedChanged
        If CheckBox_ShowBoundary.Checked Then
            Me.RadioButton_BoundaryManual.Checked = True
            Me.ReDrawROI()
        Else
            Me.RadioButton_BoundaryFinish.Checked = True
            Me.m_Form.Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
        End If
    End Sub
#End Region

#Region "--- CheckBox_BarcodeAutoThreshold_CheckedChanged ---"
    Private Sub CheckBox_BarcodeAutoThreshold_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_BarcodeAutoThreshold.CheckedChanged

        If Me.CheckBox_BarcodeAutoThreshold.Checked = True Then
            Me.NumericUpDown_BarcodeThresholdValue.Enabled = False
        Else
            Me.NumericUpDown_BarcodeThresholdValue.Enabled = True
        End If

    End Sub
#End Region

#End Region

#Region "--- RadioButton Event ---"
#Region "--- RadioButton_BoundaryManual_CheckedChanged ---"
    Private Sub RadioButton_BoundaryManual_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BoundaryManual.CheckedChanged
        If Me.RadioButton_BoundaryManual.Checked Then
            Me.m_Form.PaintStop = False
            Me.GroupBox_Boundary.Enabled = True
        End If
    End Sub
#End Region

#Region "--- RadioButton_BoundaryFinish_CheckedChanged ---"
    Private Sub RadioButton_BoundaryFinish_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_BoundaryFinish.CheckedChanged
        Dim boundary As ClsParameterBoundary
        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex <= Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
        End If

        If Me.RadioButton_BoundaryFinish.Checked Then
            Me.GroupBox_Boundary.Enabled = False
            Me.m_Form.PaintStop = True
            boundary = Me.m_FuncProcess.FuncModelRecipe.BarcodeModelRecipe.BarcodeBoundary
            boundary.TopY = Me.NumericUpDown_BoundaryTop.Value
            boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Value
            boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Value
            boundary.RightX = Me.NumericUpDown_BoundaryRight.Value
        End If
    End Sub
#End Region

#Region "--- RadioButton_PreImgProc_CheckedChanged ---"
    Private Sub RadioButton_PreImgProc_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_PreImgProc.CheckedChanged
        '--- Display ---
        If RadioButton_PreImgProc.Checked = False OrElse Me.m_Img_16U_Barcode_PreImgProc = M_NULL Then
            Exit Sub
        End If
        MdispSelectWindow(Me.m_AxMDisplay_Barcode, Me.m_Img_16U_Barcode_PreImgProc, Me.Panel_AxMDisplay_Barcode.Handle)
        MbufControl(Me.m_Img_16U_Barcode_PreImgProc, M_MODIFIED, M_DEFAULT)
        MdispControl(Me.m_AxMDisplay_Barcode, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
        Me.Barcode_ImageZoomAll()
    End Sub
#End Region

#Region "--- RadioButton_Bin_CheckedChanged ---"
    Private Sub RadioButton_Bin_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_Bin.CheckedChanged
        If RadioButton_Bin.Checked = False OrElse Me.m_Img_8U_Barcode_Bin = M_NULL Then
            Exit Sub
        End If
        '--- Display ---
        MdispSelectWindow(Me.m_AxMDisplay_Barcode, Me.m_Img_8U_Barcode_Bin, Me.Panel_AxMDisplay_Barcode.Handle)
        MbufControl(Me.m_Img_8U_Barcode_Bin, M_MODIFIED, M_DEFAULT)
        MdispControl(Me.m_AxMDisplay_Barcode, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
        Me.Barcode_ImageZoomAll()
    End Sub
#End Region

#Region "--- RadioButton_Close_CheckedChanged ---"
    Private Sub RadioButton_Close_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles RadioButton_Close.CheckedChanged
        If RadioButton_Close.Checked = False OrElse Me.m_Img_8U_Barcode_Close = M_NULL Then
            Exit Sub
        End If
        '--- Display ---
        MdispSelectWindow(Me.m_AxMDisplay_Barcode, Me.m_Img_8U_Barcode_Close, Me.Panel_AxMDisplay_Barcode.Handle)
        MbufControl(Me.m_Img_8U_Barcode_Close, M_MODIFIED, M_DEFAULT)
        MdispControl(Me.m_AxMDisplay_Barcode, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
        Me.Barcode_ImageZoomAll()
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown_Boundary Event ---"

#Region "--- Boundary ROI ---"
    Private Sub NumericUpDown_BoundaryTop_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_BoundaryTop.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryBottom.Minimum = Me.NumericUpDown_BoundaryTop.Value + 1
    End Sub

    Private Sub NumericUpDown_BoundaryBottom_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_BoundaryBottom.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryTop.Maximum = Me.NumericUpDown_BoundaryBottom.Value - 1
    End Sub

    Private Sub NumericUpDown_BoundaryLeft_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_BoundaryLeft.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryRight.Minimum = Me.NumericUpDown_BoundaryLeft.Value + 1
    End Sub

    Private Sub NumericUpDown_BoundaryRight_ValueChanged(sender As System.Object, e As System.EventArgs) Handles NumericUpDown_BoundaryRight.ValueChanged
        Me.ReDrawROI()
        Me.NumericUpDown_BoundaryLeft.Maximum = Me.NumericUpDown_BoundaryRight.Value - 1
    End Sub
#End Region

#End Region

#Region "--- AxMDisplay Event ---"
    Private Sub m_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                If Me.CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
            End If
        End If
    End Sub

    Private Sub m_Panel_AxMDisplay_MouseDownEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Left Then '滑鼠左鍵
            If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                If Me.RadioButton_BoundaryManual.Checked Then
                    Me.MouseDownPageROI(e)
                End If
            End If
        End If
    End Sub

    Private Sub m_AxMDisplay_MouseUpEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_Left = False
            Me.m_Right = False
            Me.m_Top = False
            Me.m_Bottom = False
        End If
    End Sub

    Private Sub m_AxMDisplay_MouseMoveEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
            If Me.RadioButton_BoundaryManual.Checked Then
                Me.MouseMovePageROI()
            End If
        End If
    End Sub

    Private Sub Panel_AxMDisplay_Barcode_MouseMove(sender As System.Object, e As System.Windows.Forms.MouseEventArgs) Handles Panel_AxMDisplay_Barcode.MouseMove
        Dim lFetchedValue() As Integer = {0} ' Label of the background.
        Dim image As MIL_ID = MdispInquire(Me.m_AxMDisplay_Barcode, M_SELECTED, M_NULL)
        Dim MouseX As Integer = 0
        Dim MouseY As Integer = 0

        Try
            If image <> MIL.M_NULL Then
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double

                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

                'ZoomX = MIL.MdispInquire(Me.AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay_Barcode, M_ZOOM_FACTOR_X, ZoomX)

                If ZoomX > 0 Then
                    MouseX = Math.Floor((e.X) / ZoomX)
                    MouseY = Math.Floor((e.Y) / ZoomX)

                    If MouseX < SizeX AndAlso MouseY < SizeY AndAlso MouseX > 0 AndAlso MouseY > 0 Then

                        MIL.MbufGet2d(image, MouseX, MouseY, 1, 1, lFetchedValue)

                        Me.StatusBarXYV("(" & MouseX & "," & MouseY & ")", lFetchedValue(0))
                    Else
                        If MouseX < 0 Then MouseX = 1
                        If MouseY < 0 Then MouseY = 1
                        If MouseX > SizeX Then MouseX = SizeX - 1
                        If MouseY > SizeY Then MouseY = SizeY - 1
                        Me.StatusBarXYV("NULL", "NULL")
                    End If
                End If
            Else
                Me.StatusBarXYV("NULL", "NULL")
            End If
        Catch ex As Exception
            Throw New Exception("[MainForm.ShowValue]Show Value Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub

#Region "--- Barcode_ImageZoomAll ---"
    Public Sub Barcode_ImageZoomAll()
        Dim image As MIL_ID = M_NULL
        Dim sx As Double
        Dim sy As Double
        Dim s_Max As Double
        Dim s_Min As Double

        image = MdispInquire(Me.m_AxMDisplay_Barcode, M_SELECTED, M_NULL)
        If image = M_NULL Then Exit Sub

        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim DisplayWidth As Integer = Me.Panel_AxMDisplay_Barcode.Size.Width
        Dim DisplayHeight As Integer = Me.Panel_AxMDisplay_Barcode.Size.Height

        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

        If SizeX > 0 And SizeY > 0 Then
            sx = DisplayWidth / SizeX
            sy = DisplayHeight / SizeY
            s_Max = Math.Max(sx, sy)
            s_Min = Math.Min(sx, sy)

            'If s < 0.1 Then s = 0.1
            MIL.MdispZoom(Me.m_AxMDisplay_Barcode, s_Min, s_Min)
        End If

        'Me.ResetScrollBar()
    End Sub
#End Region
#End Region

#Region "--- ReDraw ---"
    Private Sub ReDrawROI()
        Dim image As MIL_ID = M_NULL
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        Me.m_Form.PaintStop = True
        Me.m_Form.Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If Me.CheckBox_ShowBoundary.Checked Then

            '--- Initial ---
            rect = New Rectangle
            'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, M_NULL)

            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

            s = Math.Ceiling(ZoomX)

            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

            '[1] Draw Center Area Boundary ---
            Me.m_SolidBrush.Color = Color.Red
            v = (Me.NumericUpDown_BoundaryLeft.Value - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_BoundaryRight.Value - Me.m_Form.HScrollBar.Value) * ZoomX
            If v >= 0 And v < Me.m_BitMap.Width Then
                h = SizeY * ZoomY
                If h >= Me.m_BitMap.Height Then
                    h = Me.m_BitMap.Height - 1
                End If
                rect.X = v
                rect.Y = 0
                rect.Width = s
                rect.Height = h
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_BoundaryTop.Value - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            v = (Me.NumericUpDown_BoundaryBottom.Value - Me.m_Form.VScrollBar.Value) * ZoomY
            If v >= 0 And v < Me.m_BitMap.Height Then
                h = SizeX * ZoomX
                If h >= Me.m_BitMap.Width Then
                    h = Me.m_BitMap.Width - 1
                End If
                rect.X = 0
                rect.Y = v
                rect.Width = h
                rect.Height = s
                Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            'Me.m_Form.PaintStop = False
        End If
    End Sub

#End Region

#Region "--- UI Event ---"
#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If Me.CheckBox_ShowBoundary.Checked Then
            If CheckBox_ShowBoundary.Checked Then
                Me.ReDrawROI()
            End If
        End If
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If Me.CheckBox_ShowBoundary.Checked Then
            If CheckBox_ShowBoundary.Checked Then
                Me.ReDrawROI()
            End If
        End If
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused AndAlso Me.CheckBox_ShowBoundary.Checked Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_ShowBoundary.Checked Then Me.ReDrawROI()
        End If
    End Sub
#End Region
#End Region

#Region "--- Status Event ---"
    Private Delegate Sub StatusBarXYVCallback(ByVal xy As String, ByVal value As String)
    Public Sub StatusBarXYV(ByVal xy As String, ByVal value As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New StatusBarXYVCallback(AddressOf StatusBarXYV), New Object() {xy, value})
        Else
            Me.StatusBarPanel_XY.Text = "(X,Y) = " & xy
            Me.StatusBarPanel_Value.Text = "亮度 = " & value
            Me.Update()
        End If
    End Sub
#End Region

End Class