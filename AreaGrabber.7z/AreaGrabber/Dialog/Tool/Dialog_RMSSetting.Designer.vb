﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_RMSSetting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RadioButton_MeanRegionMura = New System.Windows.Forms.RadioButton()
        Me.RadioButton_MeanRegionFunc = New System.Windows.Forms.RadioButton()
        Me.GroupBox_Setting = New System.Windows.Forms.GroupBox()
        Me.Button_Add = New System.Windows.Forms.Button()
        Me.NumericUpDown_TotalRegion = New System.Windows.Forms.NumericUpDown()
        Me.TextBox_MaxY = New System.Windows.Forms.TextBox()
        Me.TextBox_MaxX = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button_MeanRegionClearAll = New System.Windows.Forms.Button()
        Me.TextBox_MinX = New System.Windows.Forms.TextBox()
        Me.ListView_MeanRegion = New System.Windows.Forms.ListView()
        Me.Ch_LeftX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_TopY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_RightX = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_BottomY = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Ch_Pattern = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TextBox_MinY = New System.Windows.Forms.TextBox()
        Me.GroupBox_MeanRegionAutoAdd = New System.Windows.Forms.GroupBox()
        Me.CheckBox_MeanRegionShow = New System.Windows.Forms.CheckBox()
        Me.CheckBox_MeanRegionMannual = New System.Windows.Forms.CheckBox()
        Me.Button_MeanRegionCancel = New System.Windows.Forms.Button()
        Me.Button_MeanRegionSave = New System.Windows.Forms.Button()
        Me.Label_Pattern = New System.Windows.Forms.Label()
        Me.ComboBox_MeanRegionPattern = New System.Windows.Forms.ComboBox()
        Me.GroupBox_Setting.SuspendLayout()
        CType(Me.NumericUpDown_TotalRegion, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_MeanRegionAutoAdd.SuspendLayout()
        Me.SuspendLayout()
        '
        'RadioButton_MeanRegionMura
        '
        Me.RadioButton_MeanRegionMura.AutoSize = True
        Me.RadioButton_MeanRegionMura.Location = New System.Drawing.Point(215, 13)
        Me.RadioButton_MeanRegionMura.Name = "RadioButton_MeanRegionMura"
        Me.RadioButton_MeanRegionMura.Size = New System.Drawing.Size(48, 16)
        Me.RadioButton_MeanRegionMura.TabIndex = 107
        Me.RadioButton_MeanRegionMura.Text = "Mura"
        Me.RadioButton_MeanRegionMura.UseVisualStyleBackColor = True
        '
        'RadioButton_MeanRegionFunc
        '
        Me.RadioButton_MeanRegionFunc.AutoSize = True
        Me.RadioButton_MeanRegionFunc.Location = New System.Drawing.Point(269, 14)
        Me.RadioButton_MeanRegionFunc.Name = "RadioButton_MeanRegionFunc"
        Me.RadioButton_MeanRegionFunc.Size = New System.Drawing.Size(46, 16)
        Me.RadioButton_MeanRegionFunc.TabIndex = 106
        Me.RadioButton_MeanRegionFunc.Text = "Func"
        Me.RadioButton_MeanRegionFunc.UseVisualStyleBackColor = True
        '
        'GroupBox_Setting
        '
        Me.GroupBox_Setting.Controls.Add(Me.Button_Add)
        Me.GroupBox_Setting.Controls.Add(Me.NumericUpDown_TotalRegion)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_MaxY)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_MaxX)
        Me.GroupBox_Setting.Controls.Add(Me.Label1)
        Me.GroupBox_Setting.Controls.Add(Me.Button_MeanRegionClearAll)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_MinX)
        Me.GroupBox_Setting.Controls.Add(Me.ListView_MeanRegion)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_MinY)
        Me.GroupBox_Setting.Controls.Add(Me.GroupBox_MeanRegionAutoAdd)
        Me.GroupBox_Setting.Location = New System.Drawing.Point(7, 41)
        Me.GroupBox_Setting.Name = "GroupBox_Setting"
        Me.GroupBox_Setting.Size = New System.Drawing.Size(427, 224)
        Me.GroupBox_Setting.TabIndex = 105
        Me.GroupBox_Setting.TabStop = False
        Me.GroupBox_Setting.Text = "Setting"
        '
        'Button_Add
        '
        Me.Button_Add.Location = New System.Drawing.Point(187, 182)
        Me.Button_Add.Name = "Button_Add"
        Me.Button_Add.Size = New System.Drawing.Size(77, 25)
        Me.Button_Add.TabIndex = 92
        Me.Button_Add.Text = "加入"
        Me.Button_Add.UseVisualStyleBackColor = True
        '
        'NumericUpDown_TotalRegion
        '
        Me.NumericUpDown_TotalRegion.Enabled = False
        Me.NumericUpDown_TotalRegion.Location = New System.Drawing.Point(362, 109)
        Me.NumericUpDown_TotalRegion.Maximum = New Decimal(New Integer() {3, 0, 0, 0})
        Me.NumericUpDown_TotalRegion.Name = "NumericUpDown_TotalRegion"
        Me.NumericUpDown_TotalRegion.Size = New System.Drawing.Size(33, 22)
        Me.NumericUpDown_TotalRegion.TabIndex = 91
        '
        'TextBox_MaxY
        '
        Me.TextBox_MaxY.Location = New System.Drawing.Point(208, 149)
        Me.TextBox_MaxY.Name = "TextBox_MaxY"
        Me.TextBox_MaxY.Size = New System.Drawing.Size(56, 22)
        Me.TextBox_MaxY.TabIndex = 69
        Me.TextBox_MaxY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_MaxX
        '
        Me.TextBox_MaxX.Location = New System.Drawing.Point(144, 149)
        Me.TextBox_MaxX.Name = "TextBox_MaxX"
        Me.TextBox_MaxX.Size = New System.Drawing.Size(56, 22)
        Me.TextBox_MaxX.TabIndex = 68
        Me.TextBox_MaxX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(321, 113)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 12)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "Total:"
        '
        'Button_MeanRegionClearAll
        '
        Me.Button_MeanRegionClearAll.Location = New System.Drawing.Point(8, 111)
        Me.Button_MeanRegionClearAll.Name = "Button_MeanRegionClearAll"
        Me.Button_MeanRegionClearAll.Size = New System.Drawing.Size(77, 25)
        Me.Button_MeanRegionClearAll.TabIndex = 88
        Me.Button_MeanRegionClearAll.Text = "全部刪除"
        Me.Button_MeanRegionClearAll.UseVisualStyleBackColor = True
        '
        'TextBox_MinX
        '
        Me.TextBox_MinX.Location = New System.Drawing.Point(16, 149)
        Me.TextBox_MinX.Name = "TextBox_MinX"
        Me.TextBox_MinX.Size = New System.Drawing.Size(56, 22)
        Me.TextBox_MinX.TabIndex = 64
        Me.TextBox_MinX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ListView_MeanRegion
        '
        Me.ListView_MeanRegion.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.Ch_LeftX, Me.Ch_TopY, Me.Ch_RightX, Me.Ch_BottomY, Me.Ch_Pattern})
        Me.ListView_MeanRegion.Font = New System.Drawing.Font("PMingLiU", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.ListView_MeanRegion.FullRowSelect = True
        Me.ListView_MeanRegion.GridLines = True
        Me.ListView_MeanRegion.Location = New System.Drawing.Point(8, 21)
        Me.ListView_MeanRegion.Name = "ListView_MeanRegion"
        Me.ListView_MeanRegion.Size = New System.Drawing.Size(404, 84)
        Me.ListView_MeanRegion.TabIndex = 86
        Me.ListView_MeanRegion.UseCompatibleStateImageBehavior = False
        Me.ListView_MeanRegion.View = System.Windows.Forms.View.Details
        '
        'Ch_LeftX
        '
        Me.Ch_LeftX.Text = "左邊界"
        Me.Ch_LeftX.Width = 80
        '
        'Ch_TopY
        '
        Me.Ch_TopY.Text = "上邊界"
        Me.Ch_TopY.Width = 80
        '
        'Ch_RightX
        '
        Me.Ch_RightX.Text = "右邊界"
        Me.Ch_RightX.Width = 80
        '
        'Ch_BottomY
        '
        Me.Ch_BottomY.Text = "下邊界"
        Me.Ch_BottomY.Width = 80
        '
        'Ch_Pattern
        '
        Me.Ch_Pattern.Text = "Pattern"
        Me.Ch_Pattern.Width = 80
        '
        'TextBox_MinY
        '
        Me.TextBox_MinY.Location = New System.Drawing.Point(80, 149)
        Me.TextBox_MinY.Name = "TextBox_MinY"
        Me.TextBox_MinY.Size = New System.Drawing.Size(56, 22)
        Me.TextBox_MinY.TabIndex = 65
        Me.TextBox_MinY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox_MeanRegionAutoAdd
        '
        Me.GroupBox_MeanRegionAutoAdd.Controls.Add(Me.CheckBox_MeanRegionShow)
        Me.GroupBox_MeanRegionAutoAdd.Controls.Add(Me.CheckBox_MeanRegionMannual)
        Me.GroupBox_MeanRegionAutoAdd.Location = New System.Drawing.Point(297, 139)
        Me.GroupBox_MeanRegionAutoAdd.Name = "GroupBox_MeanRegionAutoAdd"
        Me.GroupBox_MeanRegionAutoAdd.Size = New System.Drawing.Size(103, 68)
        Me.GroupBox_MeanRegionAutoAdd.TabIndex = 85
        Me.GroupBox_MeanRegionAutoAdd.TabStop = False
        Me.GroupBox_MeanRegionAutoAdd.Text = "Auto Add"
        '
        'CheckBox_MeanRegionShow
        '
        Me.CheckBox_MeanRegionShow.AutoSize = True
        Me.CheckBox_MeanRegionShow.Location = New System.Drawing.Point(7, 21)
        Me.CheckBox_MeanRegionShow.Name = "CheckBox_MeanRegionShow"
        Me.CheckBox_MeanRegionShow.Size = New System.Drawing.Size(48, 16)
        Me.CheckBox_MeanRegionShow.TabIndex = 79
        Me.CheckBox_MeanRegionShow.Text = "顯示"
        Me.CheckBox_MeanRegionShow.UseVisualStyleBackColor = True
        '
        'CheckBox_MeanRegionMannual
        '
        Me.CheckBox_MeanRegionMannual.AutoSize = True
        Me.CheckBox_MeanRegionMannual.Location = New System.Drawing.Point(7, 43)
        Me.CheckBox_MeanRegionMannual.Name = "CheckBox_MeanRegionMannual"
        Me.CheckBox_MeanRegionMannual.Size = New System.Drawing.Size(72, 16)
        Me.CheckBox_MeanRegionMannual.TabIndex = 80
        Me.CheckBox_MeanRegionMannual.Text = "手動設定"
        Me.CheckBox_MeanRegionMannual.UseVisualStyleBackColor = True
        '
        'Button_MeanRegionCancel
        '
        Me.Button_MeanRegionCancel.Location = New System.Drawing.Point(386, 271)
        Me.Button_MeanRegionCancel.Name = "Button_MeanRegionCancel"
        Me.Button_MeanRegionCancel.Size = New System.Drawing.Size(48, 23)
        Me.Button_MeanRegionCancel.TabIndex = 104
        Me.Button_MeanRegionCancel.Text = "關閉"
        '
        'Button_MeanRegionSave
        '
        Me.Button_MeanRegionSave.Location = New System.Drawing.Point(335, 271)
        Me.Button_MeanRegionSave.Name = "Button_MeanRegionSave"
        Me.Button_MeanRegionSave.Size = New System.Drawing.Size(48, 23)
        Me.Button_MeanRegionSave.TabIndex = 103
        Me.Button_MeanRegionSave.Text = "儲存"
        '
        'Label_Pattern
        '
        Me.Label_Pattern.Location = New System.Drawing.Point(13, 10)
        Me.Label_Pattern.Name = "Label_Pattern"
        Me.Label_Pattern.Size = New System.Drawing.Size(55, 23)
        Me.Label_Pattern.TabIndex = 102
        Me.Label_Pattern.Text = "Pattern ："
        Me.Label_Pattern.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_MeanRegionPattern
        '
        Me.ComboBox_MeanRegionPattern.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_MeanRegionPattern.Location = New System.Drawing.Point(71, 12)
        Me.ComboBox_MeanRegionPattern.Name = "ComboBox_MeanRegionPattern"
        Me.ComboBox_MeanRegionPattern.Size = New System.Drawing.Size(122, 20)
        Me.ComboBox_MeanRegionPattern.TabIndex = 101
        '
        'Dialog_RMSSetting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(445, 304)
        Me.Controls.Add(Me.RadioButton_MeanRegionMura)
        Me.Controls.Add(Me.RadioButton_MeanRegionFunc)
        Me.Controls.Add(Me.GroupBox_Setting)
        Me.Controls.Add(Me.Button_MeanRegionCancel)
        Me.Controls.Add(Me.Button_MeanRegionSave)
        Me.Controls.Add(Me.Label_Pattern)
        Me.Controls.Add(Me.ComboBox_MeanRegionPattern)
        Me.Name = "Dialog_RMSSetting"
        Me.Text = "Dialig_RMSSetting"
        Me.GroupBox_Setting.ResumeLayout(False)
        Me.GroupBox_Setting.PerformLayout()
        CType(Me.NumericUpDown_TotalRegion, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_MeanRegionAutoAdd.ResumeLayout(False)
        Me.GroupBox_MeanRegionAutoAdd.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RadioButton_MeanRegionMura As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_MeanRegionFunc As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Add As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_TotalRegion As System.Windows.Forms.NumericUpDown
    Friend WithEvents TextBox_MaxY As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_MaxX As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button_MeanRegionClearAll As System.Windows.Forms.Button
    Friend WithEvents TextBox_MinX As System.Windows.Forms.TextBox
    Friend WithEvents ListView_MeanRegion As System.Windows.Forms.ListView
    Friend WithEvents Ch_LeftX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_TopY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_RightX As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_BottomY As System.Windows.Forms.ColumnHeader
    Friend WithEvents Ch_Pattern As System.Windows.Forms.ColumnHeader
    Friend WithEvents TextBox_MinY As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox_MeanRegionAutoAdd As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_MeanRegionShow As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_MeanRegionMannual As System.Windows.Forms.CheckBox
    Friend WithEvents Button_MeanRegionCancel As System.Windows.Forms.Button
    Friend WithEvents Button_MeanRegionSave As System.Windows.Forms.Button
    Friend WithEvents Label_Pattern As System.Windows.Forms.Label
    Friend WithEvents ComboBox_MeanRegionPattern As System.Windows.Forms.ComboBox
End Class
