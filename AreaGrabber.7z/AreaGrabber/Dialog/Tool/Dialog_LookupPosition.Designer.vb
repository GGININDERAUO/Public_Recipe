<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_LookupPosition
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox_RealY = New System.Windows.Forms.TextBox()
        Me.TextBox_RealX = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox_Gate = New System.Windows.Forms.TextBox()
        Me.TextBox_Data = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label_Data = New System.Windows.Forms.Label()
        Me.Button_Inverse_MapToReal = New System.Windows.Forms.Button()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button_LoadImage = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.NumericUpDown_ResData = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_ResGate = New System.Windows.Forms.NumericUpDown()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.NumericUpDown_ResData, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ResGate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.PictureBox1)
        Me.GroupBox1.Controls.Add(Me.TextBox_RealY)
        Me.GroupBox1.Controls.Add(Me.TextBox_RealX)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.TextBox_Gate)
        Me.GroupBox1.Controls.Add(Me.TextBox_Data)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label_Data)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 71)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(306, 94)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Map To Real"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.AreaGrabber.My.Resources.Resources.R_Arrow
        Me.PictureBox1.Location = New System.Drawing.Point(120, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(64, 64)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'TextBox_RealY
        '
        Me.TextBox_RealY.Location = New System.Drawing.Point(240, 53)
        Me.TextBox_RealY.Name = "TextBox_RealY"
        Me.TextBox_RealY.Size = New System.Drawing.Size(53, 22)
        Me.TextBox_RealY.TabIndex = 5
        '
        'TextBox_RealX
        '
        Me.TextBox_RealX.Location = New System.Drawing.Point(240, 26)
        Me.TextBox_RealX.Name = "TextBox_RealX"
        Me.TextBox_RealX.Size = New System.Drawing.Size(53, 22)
        Me.TextBox_RealX.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(195, 59)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Real Y : "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(195, 54)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(8, 12)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = " "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(195, 32)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 12)
        Me.Label5.TabIndex = 3
        Me.Label5.Text = "Real X : "
        '
        'TextBox_Gate
        '
        Me.TextBox_Gate.Location = New System.Drawing.Point(59, 53)
        Me.TextBox_Gate.Name = "TextBox_Gate"
        Me.TextBox_Gate.Size = New System.Drawing.Size(53, 22)
        Me.TextBox_Gate.TabIndex = 1
        '
        'TextBox_Data
        '
        Me.TextBox_Data.Location = New System.Drawing.Point(59, 26)
        Me.TextBox_Data.Name = "TextBox_Data"
        Me.TextBox_Data.Size = New System.Drawing.Size(53, 22)
        Me.TextBox_Data.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 12)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Gate : "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(8, 12)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = " "
        '
        'Label_Data
        '
        Me.Label_Data.AutoSize = True
        Me.Label_Data.Location = New System.Drawing.Point(18, 32)
        Me.Label_Data.Name = "Label_Data"
        Me.Label_Data.Size = New System.Drawing.Size(35, 12)
        Me.Label_Data.TabIndex = 1
        Me.Label_Data.Text = "Data : "
        '
        'Button_Inverse_MapToReal
        '
        Me.Button_Inverse_MapToReal.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button_Inverse_MapToReal.Location = New System.Drawing.Point(127, 5)
        Me.Button_Inverse_MapToReal.Name = "Button_Inverse_MapToReal"
        Me.Button_Inverse_MapToReal.Size = New System.Drawing.Size(100, 24)
        Me.Button_Inverse_MapToReal.TabIndex = 0
        Me.Button_Inverse_MapToReal.Text = "Map To Real"
        '
        'Button_Close
        '
        Me.Button_Close.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Button_Close.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button_Close.Location = New System.Drawing.Point(234, 5)
        Me.Button_Close.Name = "Button_Close"
        Me.Button_Close.Size = New System.Drawing.Size(67, 24)
        Me.Button_Close.TabIndex = 1
        Me.Button_Close.Text = "Close"
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 3
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.52288!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.64052!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.5098!))
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Inverse_MapToReal, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_LoadImage, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Button_Close, 2, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(12, 174)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(306, 34)
        Me.TableLayoutPanel1.TabIndex = 9
        '
        'Button_LoadImage
        '
        Me.Button_LoadImage.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Button_LoadImage.Location = New System.Drawing.Point(3, 5)
        Me.Button_LoadImage.Name = "Button_LoadImage"
        Me.Button_LoadImage.Size = New System.Drawing.Size(81, 23)
        Me.Button_LoadImage.TabIndex = 10
        Me.Button_LoadImage.Text = "���J����"
        Me.Button_LoadImage.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_ResGate)
        Me.GroupBox2.Controls.Add(Me.NumericUpDown_ResData)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(306, 48)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Resolution"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(18, 57)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(8, 12)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = " "
        '
        'NumericUpDown_ResData
        '
        Me.NumericUpDown_ResData.Location = New System.Drawing.Point(71, 17)
        Me.NumericUpDown_ResData.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_ResData.Name = "NumericUpDown_ResData"
        Me.NumericUpDown_ResData.Size = New System.Drawing.Size(67, 22)
        Me.NumericUpDown_ResData.TabIndex = 2
        '
        'NumericUpDown_ResGate
        '
        Me.NumericUpDown_ResGate.Location = New System.Drawing.Point(194, 17)
        Me.NumericUpDown_ResGate.Maximum = New Decimal(New Integer() {10000000, 0, 0, 0})
        Me.NumericUpDown_ResGate.Name = "NumericUpDown_ResGate"
        Me.NumericUpDown_ResGate.Size = New System.Drawing.Size(67, 22)
        Me.NumericUpDown_ResGate.TabIndex = 3
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(36, 20)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 12)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Data : "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(157, 20)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(35, 12)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Gate : "
        '
        'Dialog_LookupPosition
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(327, 220)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Dialog_LookupPosition"
        Me.Text = "Dialog_LookupPosition"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.NumericUpDown_ResData, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ResGate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label_Data As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Gate As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_Data As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_RealY As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_RealX As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button_Inverse_MapToReal As System.Windows.Forms.Button
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button_LoadImage As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ResGate As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_ResData As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label10 As System.Windows.Forms.Label
End Class
