
Imports System.Windows.Forms
Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl


<CLSCompliant(False)> _
Public Class Dialog_LookupPosition

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig

    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_Size As Integer

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

    Public Sub SetMainForm(ByVal form As Main_Form)
        Dim image As MIL_ID = M_NULL

        Try
            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess
            Me.m_FuncProcess = form.MainProcess.FuncProcess
            Me.m_MuraProcess = form.MainProcess.MuraProcess

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
            Me.m_AxMDisplay = Me.m_Form.AxMDisplay
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)
            Me.m_Pen = New Pen(Color.White)
            Me.m_Size = 30

            image = Me.m_FuncProcess.Img_Original_NonPage
            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_LookupPosition.SetMainForm]" & ex.Message)
        End Try
    End Sub

#Region "--- ��k�禡 ---"

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        Button_Inverse_MapToReal.Enabled = En
        Button_Close.Enabled = En
    End Sub
#End Region

#Region "--- DrawDefect ---"

    Private Sub DrawDefect()
        Dim picsize As Integer
        Dim offset_X, offset_Y As Integer
        Dim ZoomX As Double

        Try
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

            Me.m_Form.SetStatusBarPanel_Scale("�Y�� = " & ZoomX)
            Me.m_Form.SetButton_ZoomIn(True)
            Me.m_Form.SetButton_ZoomOut(True)
            Me.m_Form.ResetScrollBar()

            picsize = 100

            Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                Case 0
                    If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        offset_X = Math.Max(CInt(Me.TextBox_RealX.Text) - CInt(picsize / 2), 0)
                        offset_Y = Math.Max(CInt(Me.TextBox_RealY.Text) - CInt(picsize / 2), 0)
                    End If
                Case 1
                    offset_X = Math.Max(CInt(Val(Me.TextBox_RealX.Text) - Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX) - CInt(picsize / 2), 0)
                    offset_Y = Math.Max(CInt(Val(Me.TextBox_RealY.Text) - Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY) - CInt(picsize / 2), 0)
            End Select

            offset_X = Math.Min(offset_X, Me.m_Form.HScrollBar.Maximum)
            offset_Y = Math.Min(offset_Y, Me.m_Form.VScrollBar.Maximum)

            Me.m_Form.HScrollBar.Value = offset_X
            Me.m_Form.VScrollBar.Value = offset_Y
            Me.m_Form.ResetScrollBar()

            Me.DrawMark()

        Catch ex As Exception
            Throw New Exception("[Dialog_LookupPosition.DrawDefect]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub

#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#End Region

#Region "--- Darw Event ---"

#Region "--- m_AxMDisplay_PaintEvent ---"
    Private Sub m_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            Me.DrawMark()
        End If
    End Sub
#End Region

#Region "--- DrawMark ---"
    Private Sub DrawMark()
        Dim offX As Integer
        Dim offY As Integer
        Dim blobx As Integer
        Dim bloby As Integer
        Dim image As MIL_ID = M_NULL

        If Me.TextBox_RealX.Text <> "" Or Me.TextBox_RealY.Text <> "" Then
            blobx = CInt(Me.TextBox_RealX.Text)
            bloby = CInt(Me.TextBox_RealY.Text)
        Else
            Exit Sub
        End If

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY




        Select Case Me.m_Form.ComboBox_Type.SelectedIndex
            Case 0
                If Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                    Me.DrawBlobDefect(0, 0)
                End If
            Case 1
                Me.DrawBlobDefect(-offX, -offY)
        End Select
        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_Form.PaintStop = False
    End Sub
#End Region

#Region "--- DrawBlobDefect ---"
    Private Sub DrawBlobDefect(ByVal offX As Integer, ByVal offY As Integer)
        Dim x As Integer
        Dim y As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double

        Try
            bx = MdispInquire(Me.m_AxMDisplay, M_SIZE_X, M_NULL)
            by = MdispInquire(Me.m_AxMDisplay, M_SIZE_Y, M_NULL)
            ox = Me.m_Form.HScrollBar.Value - offX
            oy = Me.m_Form.VScrollBar.Value - offY
            's = MdispInquire(Me.m_AxMDisplay, M_ZOOM_X, M_NULL)
            MIL.MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)  'v2012.09.04
            r = Me.m_Size * s
            If r <= 0 Then
                r = 1
            End If
            hr = 0.5 * Me.m_Size * s
            Me.m_Pen.Color = Color.Red

            x = CInt(Me.TextBox_RealX.Text)
            y = CInt(Me.TextBox_RealY.Text)
            x = (x - ox + 0.5) * s - hr   ' -hr , �]���q 0�׶}�l�e��
            y = (y - oy + 0.5) * s - hr
            If x < bx And y < by Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        Catch ex As Exception
            Throw New Exception("[Dialog_LookupPosition.DrawBlobDefect] Draw Blob Defect Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Inverse_MapToReal_Click ---"
    Private Sub Button_Inverse_MapToReal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Inverse_MapToReal.Click
        Dim Image As MIL_ID
        Dim Average_Data As Integer
        Dim Average_Gate As Integer
        Dim CCDNo As Integer
        Dim i As Integer
        Dim Total_IP As Integer
        Dim Data As Integer
        Dim Gate As Integer
        Dim FuncType As Boolean = False

        '---Check Date/Gate Not Empty---
        If TextBox_Data.Text = "" Or TextBox_Gate.Text = "" Then
            MsgBox("Please Key in Data/Gate Value", MsgBoxStyle.Critical)
            Exit Sub
        End If

        Total_IP = Me.m_MainProcess.IPNetworkConfig.Total_IP

        If Me.m_Form.MainProcess.IPBootConfig.Panel_TransferMode.Value <> "MAPPINGTABLE" Then

            If Me.NumericUpDown_ResData.Value = 0 Or Me.NumericUpDown_ResGate.Value = 0 Then
                MsgBox("Please Key in Resolution Data/Gate Value", MsgBoxStyle.Critical)
                Exit Sub
            End If

            If Me.m_MainProcess.IPNetworkConfig.Total_IP = 1 Then
                CCDNo = 1
            ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 3 Then
                If CInt(Me.TextBox_Data.Text) <= Me.NumericUpDown_ResData.Value / 3 Then
                    CCDNo = 1
                ElseIf CInt(Me.TextBox_Data.Text) <= 2 * Me.NumericUpDown_ResData.Value / 3 Then
                    CCDNo = 2
                Else
                    CCDNo = 3
                End If
            ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 4 Then
                If CInt(Me.TextBox_Data.Text) <= Me.NumericUpDown_ResData.Value / 2 Then
                    If CInt(Me.TextBox_Gate.Text) <= Me.NumericUpDown_ResGate.Value / 2 Then
                        CCDNo = 1
                    Else
                        CCDNo = 2
                    End If
                Else
                    If CInt(Me.TextBox_Gate.Text) <= Me.NumericUpDown_ResGate.Value / 2 Then
                        CCDNo = 3
                    Else
                        CCDNo = 4
                    End If
                End If
            ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 9 Then
                If CInt(Me.TextBox_Data.Text) <= Me.NumericUpDown_ResData.Value / 3 Then
                    If CInt(Me.TextBox_Gate.Text) <= Me.NumericUpDown_ResGate.Value / 3 Then
                        CCDNo = 4
                    ElseIf CInt(Me.TextBox_Gate.Text) <= 2 * Me.NumericUpDown_ResGate.Value / 3 Then
                        CCDNo = 1
                    Else
                        CCDNo = 7
                    End If
                ElseIf CInt(Me.TextBox_Data.Text) <= 2 * Me.NumericUpDown_ResData.Value / 3 Then
                    If CInt(Me.TextBox_Gate.Text) <= Me.NumericUpDown_ResGate.Value / 3 Then
                        CCDNo = 5
                    ElseIf CInt(Me.TextBox_Gate.Text) <= 2 * Me.NumericUpDown_ResGate.Value / 3 Then
                        CCDNo = 2
                    Else
                        CCDNo = 8
                    End If
                Else
                    If CInt(Me.TextBox_Gate.Text) <= Me.NumericUpDown_ResGate.Value / 3 Then
                        CCDNo = 6
                    ElseIf CInt(Me.TextBox_Gate.Text) <= 2 * Me.NumericUpDown_ResGate.Value / 3 Then
                        CCDNo = 3
                    Else
                        CCDNo = 9
                    End If
                End If
            End If

        Else
            '--- Choose IP NO --- 
            Average_Data = Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
            Average_Gate = Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value

            If Me.m_MainProcess.IPNetworkConfig.Total_IP = 1 Then
                CCDNo = 1
            ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 3 Then
                For i = 0 To Me.m_MainProcess.IPNetworkConfig.Total_IP - 1
                    If (TextBox_Data.Text >= Average_Data * i) AndAlso (TextBox_Data.Text < Average_Data * (i + 1)) Then
                        CCDNo = i + 1
                    End If
                Next
            ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 9 Then
                For i = 0 To 2
                    If (TextBox_Data.Text >= Average_Data * i) AndAlso (TextBox_Data.Text < Average_Data * (i + 1)) Then
                        For j = 0 To 2
                            If (TextBox_Gate.Text >= Average_Gate * j) AndAlso (TextBox_Gate.Text < Average_Gate * (j + 1)) Then
                                Select Case i
                                    Case 0
                                        Select Case j
                                            Case 0
                                                CCDNo = 4
                                            Case 1
                                                CCDNo = 1
                                            Case 2
                                                CCDNo = 7
                                        End Select
                                    Case 1
                                        Select Case j
                                            Case 0
                                                CCDNo = 5
                                            Case 1
                                                CCDNo = 2
                                            Case 2
                                                CCDNo = 8
                                        End Select
                                    Case 2
                                        Select Case j
                                            Case 0
                                                CCDNo = 6
                                            Case 1
                                                CCDNo = 3
                                            Case 2
                                                CCDNo = 9
                                        End Select
                                End Select
                            End If
                        Next
                    End If
                Next
            ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 4 Then
                For i = 0 To 1
                    If (TextBox_Data.Text >= Average_Data * i) AndAlso (TextBox_Data.Text < Average_Data * (i + 1)) Then
                        For j = 0 To 1
                            If (TextBox_Gate.Text >= Average_Gate * j) AndAlso (TextBox_Gate.Text < Average_Gate * (j + 1)) Then
                                Select Case i
                                    Case 0
                                        Select Case j
                                            Case 0
                                                CCDNo = 1
                                            Case 1
                                                CCDNo = 2
                                        End Select
                                    Case 1
                                        Select Case j
                                            Case 0
                                                CCDNo = 3
                                            Case 1
                                                CCDNo = 4
                                        End Select
                                End Select
                            End If
                        Next
                    End If
                Next
            End If
        End If


        If CCDNo <> Me.m_Form.ComboBox_CCD.Text And CCDNo >= 1 Then
            Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1
        End If
        '---------------------

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If Image = M_NULL Then
                MsgBox("�и��J�v��")
            Else

                '[1] Inverse Panel Position To Real Position
                '----------------------------------------------------------------------------------------------
                ' Inverse Panel Position To Real Position ==> Request_Command = "INVERSE_MAP_TO_REAL" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "INVERSE_MAP_TO_REAL"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    If Me.m_MainProcess.IPNetworkConfig.Total_IP = 3 Then
                        If CCDNo > 0 Then
                            Data = Me.TextBox_Data.Text - (CCDNo - 1) * Average_Data
                            Gate = Me.TextBox_Gate.Text
                        Else
                            Data = Me.TextBox_Data.Text
                            Gate = Me.TextBox_Gate.Text
                        End If
                    ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 9 Then
                        Select Case CCDNo
                            Case 1
                                Data = Me.TextBox_Data.Text
                                Gate = CInt(Me.TextBox_Gate.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                            Case 2
                                Data = CInt(Me.TextBox_Data.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = CInt(Me.TextBox_Gate.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                            Case 3
                                Data = CInt(Me.TextBox_Data.Text) - 2 * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = CInt(Me.TextBox_Gate.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                            Case 4
                                Data = Me.TextBox_Data.Text
                                Gate = Me.TextBox_Gate.Text
                            Case 5
                                Data = CInt(Me.TextBox_Data.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = Me.TextBox_Gate.Text
                            Case 6
                                Data = CInt(Me.TextBox_Data.Text) - 2 * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = Me.TextBox_Gate.Text
                            Case 7
                                Data = Me.TextBox_Data.Text
                                Gate = CInt(Me.TextBox_Gate.Text) - 2 * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                            Case 8
                                Data = CInt(Me.TextBox_Data.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = CInt(Me.TextBox_Gate.Text) - 2 * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                            Case 9
                                Data = CInt(Me.TextBox_Data.Text) - 2 * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = CInt(Me.TextBox_Gate.Text) - 2 * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                        End Select

                    ElseIf Me.m_MainProcess.IPNetworkConfig.Total_IP = 4 Then
                        Select Case CCDNo
                            Case 1
                                Data = Me.TextBox_Data.Text
                                Gate = Me.TextBox_Gate.Text
                            Case 2
                                Data = Me.TextBox_Data.Text
                                Gate = CInt(Me.TextBox_Gate.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                            Case 3
                                Data = CInt(Me.TextBox_Data.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = Me.TextBox_Gate.Text
                            Case 4
                                Data = CInt(Me.TextBox_Data.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableHCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.DataFreQ.Value
                                Gate = CInt(Me.TextBox_Gate.Text) - Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.TableVCount.Value * Me.m_MainProcess.TableProcess.MappingTableRecipe.ctp.GateFreQ.Value
                        End Select

                    End If

                    If Me.m_Form.GetTypeIndexInfo = 0 And Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex + 1 > Me.m_Form.MuraProcess.MuraModelRecipe.PatternCount.Value Then
                        FuncType = True
                    End If

                    'If MdispInquire(Me.m_Form.AxMDisplay, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value AndAlso MdispInquire(Me.m_Form.AxMDisplay, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    '    FuncType = True
                    'End If

                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Str(Data), Str(Gate), FuncType, CInt(Me.TextBox_Data.Text), CInt(Me.TextBox_Gate.Text), , , , TimeOut)   'grant add mapping table
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        Me.TextBox_RealX.Text = SubSystemResult.Responses(0).Param1
                        Me.TextBox_RealY.Text = SubSystemResult.Responses(0).Param2
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Inverse Panel Position To Real Position Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                        MessageBox.Show("[Dialog_LookupPosition.Button_Inverse_MapToReal]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Enable(True)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '[2] --- Draw Defect --- 
                Me.DrawDefect()

            End If

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_LookupPosition.Button_Alignment]" & ex.Message)
            MessageBox.Show("[Dialog_LookupPosition.Button_Inverse_MapToReal]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_LoadImage_Click ---"
    Private Sub Button_LoadImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LoadImage.Click
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Initial --- 
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                image = Me.m_FuncProcess.Img_Original_NonPage
                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, image)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                Me.m_Form.StatusBarStatus(System.IO.Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("���ˬd�Ҷ}�Ҫ��v���ɮ׬O�_�ŦX�ثeIP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 100000 '100 secs

                    FilePath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_LoadImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                        Exit Sub
                    End If

                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        If image <> M_NULL Then
                            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                            Type = MbufInquire(image, M_TYPE, M_NULL)

                            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                MbufFree(imageBuffer)
                                imageBuffer = M_NULL
                                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                            MbufCopy(image, imageBuffer)

                            MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                            MbufControl(image, M_MODIFIED, M_DEFAULT)
                            MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                            Me.m_Form.ResetScrollBar()
                        End If
                    Else
                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                If (Me.m_IPBootConfig.MuraUI.Value) Then
                    '[1] image2 ---
                    image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                    If image2 <> M_NULL Then
                        If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image2)
                            image2 = M_NULL
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, image2)

                    '[2] Img_16U_Grab ---
                    If image <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                            Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                            Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    If Not Me.m_IPBootConfig.FuncUI.Value Then MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                    If Not Response_OK Then
                        Button_Enable(True)
                        Exit Sub
                    End If

                    '--- Resize Original image ---
                    If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                        '----------------------------------------------------------------------------------------------
                        ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "RESIZE_ORIGINAL"
                            TimeOut = 100000 '100 secs
                            SaveImage = True

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.Button_LoadImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Button_Enable(True)
                                Exit Sub
                            End If

                            If SaveImage AndAlso Response_OK Then
                                '[1] --- Update Processed Image ---
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                                Else
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                                End If

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If image <> M_NULL Then
                                        If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(image)
                                            image = M_NULL
                                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, image)

                                    If System.IO.File.Exists(strPath) = True Then
                                        System.IO.File.Delete(strPath)
                                    End If
                                End If

                                Me.m_Form.ImageUpdate()

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If
                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try
                    End If
                End If
            End If

            If Me.m_Form.OpenFileDialog.FileName <> "" Then
                If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("�Э��s����Align�A[Func�򥻳]�w]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Button_Enable(True)
                    End Try
                Else
                    If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                        Me.m_FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If

            End If
            Call Me.m_Form.ImageZoomAll()

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message)
            MessageBox.Show("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Close_Click ---"
    Private Sub Button_Close_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Close.Click
        Me.Close()
    End Sub
#End Region

#End Region




End Class