﻿Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl
Imports System.IO
Imports System.Threading
Imports System.Globalization

<CLSCompliant(False)> _
Public Class Dialog_CameraAlignment

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_Have_MDigitizer As Boolean
    Private m_ContinueGrab As Boolean
    Private m_Thread1_RunCommand As Threading.Thread = Nothing  '「執行命令」執行緒 1
    Private m_Grab_OK As Boolean
    Private m_ReadWriteLock As New System.Threading.ReaderWriterLock()
    Private m_Initial_Finished As Boolean
    Private m_Max_ExposureTime As Integer
    Private m_Form_Closing As Boolean

    '--- 連線參數 ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '--- 繪圖 ---
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_Pen As Pen
    Private m_Size As Integer
    Private m_SolidBrush As SolidBrush
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    Private pb As New ClsParameterBoundary

    Private m_MouseX As Integer
    Private m_MouseY As Integer
    Private m_MousreHScroll As Boolean=False

    '--- Display ---
    Private m_AxMDisplay As MIL_ID   ' MIL Display identifier.
    Private m_ZoomFactor As Double
    Private m_ZoomMin As Double
    Private m_ZoomMax As Double
    Private m_Left As Boolean
    Private m_Right As Boolean
    Private m_Top As Boolean
    Private m_Bottom As Boolean

    '--- Master\Slave Mode ---
    Private m_MasterSlaveMode_Enable As Boolean
    Private m_Master_ID As Integer
    Private m_Slave_ID As Integer
    Private res As System.Resources.ResourceManager '揃埭奪燴

#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form,ByVal language as String)
        Dim image As MIL_ID = M_NULL

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_CameraAlignment", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------

        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_FuncProcess = form.MainProcess.FuncProcess
        Me.m_MuraProcess = form.MainProcess.MuraProcess
        Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
        Me.m_Max_ExposureTime = Me.m_MainProcess.AreaBootConfig.Max_ExposureTime.Value
        Me.NumericUpDown_ExposureTime.Maximum = Me.m_Max_ExposureTime
        Me.TrackBar_ExposureTime.Maximum = Me.m_Max_ExposureTime

        Me.m_MasterSlaveMode_Enable = Me.m_IPBootConfig.MasterSlaveMode_Enable.Value  '2014/12/04 Rick add
        Me.m_Master_ID = 0
        Me.m_Slave_ID = 1

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Check Digitizer  ==> Request_Command = "CHECK_DIGITIZER" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CHECK_DIGITIZER"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                If SubSystemResult.Responses(0).Param1.ToUpper = "TRUE" Then
                    Me.m_Have_MDigitizer = True
                Else
                    Me.m_Have_MDigitizer = False
                End If
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Check Digitizer Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_CameraAlignment.SetMainForm]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Me.m_Have_MDigitizer Then
                Me.GroupBox_Grab.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = True
            Else
                Me.GroupBox_Grab.Enabled = False
                Me.GroupBox_ExposureTime.Enabled = False
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.SetMainForm]Check Digitizer Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_CameraAlignment.SetMainForm]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Display ---
        Try
            If Me.m_AxMDisplay <> MIL.M_NULL Then
                MdispFree(Me.m_AxMDisplay)
                Me.m_AxMDisplay = MIL.M_NULL
            End If

            Me.m_ZoomMin = Me.m_Form.ZoomMin
            Me.m_ZoomMax = Me.m_Form.ZoomMax
            Me.m_ZoomFactor = Me.m_Form.ZoomFactor

            MIL.MdispAlloc(Me.m_MainProcess.System_Host, MIL.M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay)
        Catch ex As Exception
            MsgBox("[Dialog_CameraAlignment.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        Try
            '--- 光學邊界調整繪圖 ---
            Me.m_Panel_AxMDisplay = Me.Panel_AxMDisplay_CA
            Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_Pen = New Pen(Color.White)
            Me.m_Form.PaintStop = True
            Me.m_Size = 15

            Me.ImageZoomAll()

            Me.m_ContinueGrab = False
            Me.m_Grab_OK = False
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
            MsgBox("[Dialog_CameraAlignment.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        Try
            Me.UpdateData()
        Catch ex As Exception
            MsgBox("[Dialog_CameraAlignment.SetMainForm] Update Data Error ! " & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Dialog_CameraAlignment_Load ---"

    Private Sub Dialog_CameraAlignment_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Try
            Me.m_Initial_Finished = False
            Me.SetButton_Grab(False)

            'If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
            '    Me.GroupBox_Mode.Enabled = True
            'Else
            '    Me.GroupBox_Mode.Enabled = False
            'End If

            Me.GroupBox_ExposureTime.Enabled = Me.m_Have_MDigitizer

            If Not Me.m_Have_MDigitizer Then
                Button_Continue.Enabled = False
            End If

            'Me.m_Form.ImageUpdate()
            Me.Update()
            Me.m_Initial_Finished = True
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.FormLoad]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

    End Sub

#End Region

#Region "--- Dialog_CameraAlignment_Closing ---"
    Private Sub Dialog_CameraAlignment_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing

        Me.m_Form_Closing = True
        Me.m_ContinueGrab = False
        Me.m_Form.PaintStop = True

        ''--- Stop Grab First ---
        Me.WaitGrabReady()

        System.Threading.Thread.Sleep(GetExposureTimeInfo() / 1000)
        Me.m_Form.PaintStop = True


        '--- Free Display Object ---
        If Me.m_AxMDisplay <> M_NULL Then
            MdispFree(Me.m_AxMDisplay)
            Me.m_AxMDisplay = M_NULL
        End If

        '--- 釋放 RunCommand thread --- 
        Me.m_Thread1_RunCommand = Nothing
        Me.Dispose()
    End Sub
#End Region

#Region "--- Dialog_CameraAlignment_MouseWheel ---"
    Private Sub Dialog_CameraAlignment_MouseWheel(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseWheel
        Dim Zoom As Double
        Dim SetValue As Integer
        Dim numberOfTextLinesToMove As Integer = CInt(e.Delta)
        Dim numberOfPixelsToMove As Integer = 0


        If Me.m_MousreHScroll Then
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, Zoom)
            numberOfPixelsToMove = numberOfTextLinesToMove * Zoom * 1.2
            If numberOfPixelsToMove <> 0 Then
                SetValue = Me.HScrollBar.Value + numberOfTextLinesToMove
                If SetValue > Me.HScrollBar.Maximum Then
                    Me.HScrollBar.Value = Me.HScrollBar.Maximum
                    SetValue = Me.HScrollBar.Maximum
                ElseIf SetValue < Me.HScrollBar.Minimum Then
                    Me.HScrollBar.Value = Me.HScrollBar.Minimum
                    SetValue = Me.HScrollBar.Minimum
                Else
                    Me.HScrollBar.Value = SetValue
                End If
                MdispPan(Me.m_AxMDisplay, SetValue, Me.VScrollBar.Value)
            End If
        Else
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, Zoom)
            numberOfPixelsToMove = numberOfTextLinesToMove * Zoom * 0.8
            If numberOfPixelsToMove <> 0 Then
                SetValue = Me.VScrollBar.Value - numberOfTextLinesToMove
                If SetValue > Me.VScrollBar.Maximum Then
                    Me.VScrollBar.Value = Me.VScrollBar.Maximum
                    SetValue = Me.VScrollBar.Maximum
                ElseIf SetValue < Me.VScrollBar.Minimum Then
                    Me.VScrollBar.Value = Me.VScrollBar.Minimum
                    SetValue = Me.VScrollBar.Minimum
                Else
                    Me.VScrollBar.Value = SetValue
                End If
                MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Value, SetValue)
            End If
        End If

    End Sub
#End Region

#Region "--- 方法函式 ---"

#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim car As ClsCameraAlignmentRecipe = Me.m_FuncProcess.CameraAlignmentRecipe

        Try
            Me.NumericUpDown_ExposureTime.Value = car.ExposureTime.Value
            Me.NumericUpDown_Pitch.Value = car.Panel_Pitch.Value
            Me.TextBox_CCD_X_Num.Text = car.CCD_X_Num.Value
            Me.TextBox_CCD_Y_Num.Text = car.CCD_Y_Num.Value

            Me.TextBox_Panel_Resolution_H.Text = car.Panel_Resolution_H.Value
            Me.TextBox_Panel_Resolution_V.Text = car.Panel_Resolution_V.Value
            Me.CheckBo_CCD_Rotate_90.Checked = car.Panel_Rotate_90.Value

            If Not car.Panel_Rotate_90.Value Then
                Me.TextBox_CCD_Resolution_H.Text = car.CCD_Resolution_H.Value
                Me.TextBox_CCD_Resolution_V.Text = car.CCD_Resolution_V.Value
            End If

            '---Alignment---
            Me.NumericUpDown_BoundaryTop.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
            Me.NumericUpDown_BoundaryBottom.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY
            Me.NumericUpDown_BoundaryLeft.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            Me.NumericUpDown_BoundaryRight.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX
            Me.CheckBox_Func_TopAnalysis.Checked = Me.m_FuncProcess.FuncModelRecipe.TopAnalysis.Value
            Me.CheckBox_Func_BottomAnalysis.Checked = Me.m_FuncProcess.FuncModelRecipe.BottomAnalysis.Value
            Me.CheckBox_Func_LeftAnalysis.Checked = Me.m_FuncProcess.FuncModelRecipe.LeftAnalysis.Value
            Me.CheckBox_Func_RightAnalysis.Checked = Me.m_FuncProcess.FuncModelRecipe.RightAnalysis.Value
            Me.NumericUpDown_AlignmentShift.Value = Me.m_FuncProcess.FuncModelRecipe.Alignment_Shift.Value
            Me.NumericUpDown_AlignTolerance.Value = Me.m_FuncProcess.FuncModelRecipe.AlignTolerance.Value
            Me.CheckBox_EnhanceEdge.Checked = Me.m_FuncProcess.FuncModelRecipe.EnhanceEdge.Value

        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_CameraAlignment.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_CameraAlignment.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim car As ClsCameraAlignmentRecipe = Me.m_FuncProcess.CameraAlignmentRecipe
        Dim File_Path As String = ""

        Try
            car.ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
            car.Panel_Pitch.Value = Me.NumericUpDown_Pitch.Value
            car.CCD_X_Num.Value = Me.TextBox_CCD_X_Num.Text
            car.CCD_Y_Num.Value = Me.TextBox_CCD_Y_Num.Text

            If Me.CheckBo_CCD_Rotate_90.Checked Then
                car.CCD_Resolution_H.Value = Me.TextBox_CCD_Resolution_V.Text
                car.CCD_Resolution_V.Value = Me.TextBox_CCD_Resolution_H.Text
            Else
                car.CCD_Resolution_H.Value = Me.TextBox_CCD_Resolution_H.Text
                car.CCD_Resolution_V.Value = Me.TextBox_CCD_Resolution_V.Text
            End If

            car.Panel_Resolution_H.Value = Me.TextBox_Panel_Resolution_H.Text
            car.Panel_Resolution_V.Value = Me.TextBox_Panel_Resolution_V.Text
            car.Panel_Rotate_90.Value = Me.CheckBo_CCD_Rotate_90.Checked

            '--- Save To Camera Alignment File ---
            File_Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\CameraAlignmentRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
            RepairPath_2(File_Path)
            If File_Path.Substring(0, 1) = "\" Then
                File_Path = "\" + File_Path
            End If
            ClsCameraAlignmentRecipe.WriteXML(car, File_Path)
        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_CameraAlignment.Setting]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_CameraAlignment.Setting]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- ScrollBar_Enable ---"
    Private Sub ScrollBar_Enable(ByVal En As Boolean)
        Me.HScrollBar_Enable(En)
        Me.VScrollBar_Enable(En)
    End Sub
#End Region

#Region "--- UpdateGrabImage_With_ExposureTime ---"
    Public Sub UpdateGrabImage_With_ExposureTime()
        Dim Image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim FocusValue As Integer
        Dim ExposureTime As Long
        Dim strs() As String
        Dim strPath_Exists As Boolean
        Dim ROISizeX, ROISizeY As Integer

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
            End If
       
            If System.IO.File.Exists(strPath) Then
                Directory.CreateDirectory(strPath)
            End If

            '--- Disable ScrollBar ---
            'Me.ScrollBar_Enable(False)

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)


            'Call ImageZoomAll()

            Try
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                SyncLock Me.m_MainProcess.IP_Dispatcher1
                    '--- Prepare Command ---
                    Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    ExposureTime = Me.GetExposureTimeInfo()
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ExposureTime, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                End SyncLock

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image With ExposureTime Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Response_OK = False
                Me.m_ContinueGrab = False
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                Me.RepairPath_2(strPath)
            End If
         
            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
            MbufDiskInquire(strPath, M_TYPE, Type)
            strPath_Exists = System.IO.File.Exists(strPath)

            Do
                Me.m_Grab_OK = False
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        ExposureTime = Me.GetExposureTimeInfo()
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ExposureTime, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image With ExposureTime Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    If Response_OK AndAlso Not (Me.m_AxMDisplay = M_NULL) Then
                        '--- Update Processed Image ---
                        Grab_Success = Grab_Success + 1
                        Image = Me.m_MainProcess.Img_16U_Grab_1

                        If strPath_Exists Then

                            If Image <> M_NULL Then
                                If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image)
                                    Image = M_NULL
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Image)
                            Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                            If Image <> M_NULL Then
                                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                Type = MbufInquire(Image, M_TYPE, M_NULL)

                                If Me.CheckBox_Defocus.Checked Then
                                    SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                                    ROISizeX = SizeX / 2
                                    SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                                    ROISizeY = SizeY / 2
                                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> ROISizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> ROISizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                        MbufFree(imageBuffer)
                                        imageBuffer = M_NULL
                                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, ROISizeX, ROISizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                        MbufFree(imageBuffer)
                                        imageBuffer = M_NULL
                                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                    End If
                                End If





                                If Me.CheckBox_Defocus.Checked Then
                                    MimResize(Image, imageBuffer, M_FILL_DESTINATION, M_FILL_DESTINATION, M_DEFAULT)
                                    MimConvolve(imageBuffer, imageBuffer, M_SMOOTH)
                                Else
                                    MbufCopy(Image, imageBuffer)
                                End If


                                MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, Me.GetAxMDisplay_HandleInfo())
                                MbufControl(Image, M_MODIFIED, M_DEFAULT)
                                MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                If Not Me.m_Form_Closing Then Me.ResetScrollBar()
                            End If

                            'If Not Me.m_Form_Closing Then Me.ZoomEnable(False)
                        End If
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' Get Gray Mean  ==> Request_Command = "GET_FOCUSVALUE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        SyncLock Me.m_MainProcess.IP_Dispatcher1
                            '--- Prepare Command ---
                            Request_Command = "GET_FOCUSVALUE"
                            TimeOut = 500000 '500 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                        End SyncLock

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                            If SubSystemResult.Responses(0).Param2 <> "" Then

                                strs = SubSystemResult.Responses(0).Param2.Split(",")
                                FocusValue = strs(1)
                                SetStatusBarPanel_Focus("Focus：" & FocusValue)
                            End If
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Focus Value Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.get_FocusValue]Get Focus Value Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_CameraAlignment.get_FocusValue]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End Try

                    Me.m_Grab_OK = True

                Catch ex As Exception
                    Response_OK = False
                    Me.m_ContinueGrab = False
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Loop While (Me.m_ContinueGrab And Me.Button_Continue.Enabled = False)

            Me.m_Grab_OK = True
            If Not Me.m_Form_Closing Then Me.ScrollBar_Enable(True)
            If Not Me.m_Form_Closing Then Me.ZoomEnable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            If Not Me.m_Form_Closing Then Me.ScrollBar_Enable(True)
            If Not Me.m_Form_Closing Then Me.SetButton_Grab(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#Region "--- UpdateExposureTime ---"
    Public Sub UpdateExposureTime()
        Dim Image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim FocusValue As Integer
        Dim ExposureTime As Long
        Dim strs() As String
        Dim strPath_Exists As Boolean

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
            End If
          
            If System.IO.File.Exists(strPath) Then
                Directory.CreateDirectory(strPath)
            End If

            '--- Disable ScrollBar ---
            'Me.ScrollBar_Enable(False)

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)

            Me.m_Grab_OK = False
            'Call ImageZoomAll()

            Try
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                SyncLock Me.m_MainProcess.IP_Dispatcher1
                    '--- Prepare Command ---
                    Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    ExposureTime = Me.GetExposureTimeInfo()
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ExposureTime, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                End SyncLock

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image With ExposureTime Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Response_OK = False
                Me.m_ContinueGrab = False
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                Me.RepairPath_2(strPath)
            End If
       
            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
            MbufDiskInquire(strPath, M_TYPE, Type)
            strPath_Exists = System.IO.File.Exists(strPath)

            '----------------------------------------------------------------------------------------------
            ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                SyncLock Me.m_MainProcess.IP_Dispatcher1
                    '--- Prepare Command ---
                    Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    ExposureTime = Me.GetExposureTimeInfo()
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ExposureTime, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                End SyncLock

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image With ExposureTime Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                If Response_OK AndAlso Not (Me.m_AxMDisplay = M_NULL) Then
                    '--- Update Processed Image ---
                    Grab_Success = Grab_Success + 1
                    Image = Me.m_MainProcess.Img_16U_Grab_1

                    If strPath_Exists Then

                        If Image <> M_NULL Then
                            If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Image)
                                Image = M_NULL
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Image)
                        Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                        If Image <> M_NULL Then
                            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                            SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                            Type = MbufInquire(Image, M_TYPE, M_NULL)

                            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                MbufFree(imageBuffer)
                                imageBuffer = M_NULL
                                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                            MbufCopy(Image, imageBuffer)

                            MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, Me.GetAxMDisplay_HandleInfo())
                            MbufControl(Image, M_MODIFIED, M_DEFAULT)
                            MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                            If Not Me.m_Form_Closing Then Me.ResetScrollBar()
                        End If

                        'If Not Me.m_Form_Closing Then Me.ZoomEnable(False)
                    End If
                End If

                '----------------------------------------------------------------------------------------------
                ' Get Gray Mean  ==> Request_Command = "GET_FOCUSVALUE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GET_FOCUSVALUE"
                        TimeOut = 500000 '500 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        If SubSystemResult.Responses(0).Param2 <> "" Then

                            strs = SubSystemResult.Responses(0).Param2.Split(",")
                            FocusValue = strs(1)
                            SetStatusBarPanel_Focus("Focus：" & FocusValue)
                        End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Focus Value Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.get_FocusValue]Get Focus Value Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_CameraAlignment.get_FocusValue]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End Try

                Me.m_Grab_OK = True
            Catch ex As Exception
                Response_OK = False
                Me.m_ContinueGrab = False
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.m_Grab_OK = True
            If Not Me.m_Form_Closing Then Me.ScrollBar_Enable(True)
            If Not Me.m_Form_Closing Then Me.ZoomEnable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            If Not Me.m_Form_Closing Then Me.ScrollBar_Enable(True)
            If Not Me.m_Form_Closing Then Me.SetButton_Grab(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#Region "--- WaitGrabReady ---"
    Private Sub WaitGrabReady()
        Dim i As Integer

        i = (Me.GetExposureTimeInfo() / 100000) + 1
        If i < 10 Then i = 10

        If Not Me.m_ContinueGrab Then
            While (Not Me.m_Grab_OK And i >= 0)
                System.Threading.Thread.Sleep(200)
                Application.DoEvents()
                i = i - 1
            End While

            Me.m_Grab_OK = True
        End If
    End Sub
#End Region

#Region "--- Button Event ---"

#Region "--- Button_Continue ---"
    Private Sub Button_Continue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Continue.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Me.Button_Continue.Enabled = False
        Me.Button_Load.Enabled = False
        Me.GroupBox_ExposureTime.Enabled = False

        ''--- Stop Grab First ---
        Me.WaitGrabReady()

        '--- Display  Setting ---
        image = Me.m_MainProcess.Img_16U_Grab_1
        If image <> M_NULL Then
            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage

            If Me.CheckBox_Defocus.Checked Then
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeX = SizeX / 2
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                SizeY = SizeY / 2
            Else
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
            End If

            Type = MbufInquire(image, M_TYPE, M_NULL)

            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                MbufFree(imageBuffer)
                imageBuffer = M_NULL
                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
            End If

            If Me.CheckBox_Defocus.Checked Then
                MimResize(image, imageBuffer, M_FILL_DESTINATION, M_FILL_DESTINATION, M_DEFAULT)
                MimConvolve(imageBuffer, imageBuffer, M_SMOOTH)
            Else
                MbufCopy(image, imageBuffer)
            End If

            MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, Me.GetAxMDisplay_HandleInfo())
            MbufControl(image, M_MODIFIED, M_DEFAULT)
            MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

            Me.ResetScrollBar()
        End If

        Me.ImageZoomAll()
        'Me.ZoomEnable(False)

        'Thread --- Update Grab Image
        '---啟動 Run Command Thread ---

        Me.m_ContinueGrab = True
        Try
            If Not Me.m_Thread1_RunCommand Is Nothing Then
                Me.m_Thread1_RunCommand = Nothing
            End If

            If Not (Not Me.m_Thread1_RunCommand Is Nothing) Then
                Try
                    'If Not Me.m_MasterSlaveMode_Enable Then ' 封~~印~~~~~~~~~~
                    If True Then
                        Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.UpdateGrabImage_With_ExposureTime)
                        Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        Me.m_Thread1_RunCommand.Start()
                    Else
                        '--- MasterSlave Mode ---
                        Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.MS_UpdateGrabImage_With_ExposureTime)
                        Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        Me.m_Thread1_RunCommand.Start()
                    End If
                Catch ex As Exception
                    Throw New Exception(ex.Message)
                End Try
            End If
        Catch ex As Exception
            Me.ZoomEnable(True)
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.GroupBox_ExposureTime.Enabled = True
            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            'Me.Button_Save.Enabled = True
            Me.m_ContinueGrab = False
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.Button_Continue](" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Button_Grab_Click ---"
    Private Sub Button_Grab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Grab.Click
        System.Threading.Thread.Sleep(GetExposureTimeInfo() / 1000)

        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_ContinueGrab = False
        Me.SetButton_Grab(False)
        'Me.Button_Save.Enabled = False

        '--- 停止連續取像 ---
        Me.WaitGrabReady()

        '--- Finish Grab Image Thread ---  
        If Not Me.m_Thread1_RunCommand Is Nothing Then
            Me.m_Thread1_RunCommand = Nothing
        End If

        Try
            'Me.ImageZoomAll()

            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            'Me.Button_Save.Enabled = True

            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.GroupBox_ExposureTime.Enabled = True

        Catch ex As Exception
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.GroupBox_ExposureTime.Enabled = True
            Me.TrackBar_ExposureTime.Enabled = False
            Me.NumericUpDown_ExposureTime.Enabled = False
            Me.m_ContinueGrab = False
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.Button_Grab]Grab Image Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- Button_Load ---"
    Private Sub Button_Load_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Load.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.Button_Load.Enabled = False
        If Me.m_Have_MDigitizer Then
            Me.GroupBox_ExposureTime.Enabled = False
        End If
        ''--- 停止連續取像 ---
        'Me.WaitGrabReady()

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Me.Button_Load.Enabled = True
            If Me.m_Have_MDigitizer Then
                Me.GroupBox_ExposureTime.Enabled = True
            End If
            Exit Sub
        End If

        Try
            Me.ContextMenuStrip_AlignSetting.Visible = False
            Me.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.OpenFileDialog.FileName = ""
            Me.OpenFileDialog.ShowDialog()
            If Me.OpenFileDialog.FileName <> "" Then

                image = Me.m_FuncProcess.Img_Original_NonPage
                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(Me.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(Me.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(Me.OpenFileDialog.FileName, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.OpenFileDialog.FileName, image)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(Me.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                    Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                End If

                If image <> M_NULL Then
                    imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                    Type = MbufInquire(image, M_TYPE, M_NULL)

                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                        MbufFree(imageBuffer)
                        imageBuffer = M_NULL
                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                    MbufCopy(image, imageBuffer)

                    MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, Me.GetAxMDisplay_HandleInfo())
                    MbufControl(image, M_MODIFIED, M_DEFAULT)
                    MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                    Me.ResetScrollBar()
                End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 200000 '200 secs

                    FilePath = Me.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_CameraAlignment.Button_Load]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Load.Enabled = True
                        If Me.m_Have_MDigitizer Then
                            Me.GroupBox_ExposureTime.Enabled = True
                        End If
                        Exit Sub
                    End If

                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.Button_Load]Load Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_CameraAlignment.Button_Load]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Throw New Exception(ex.Message)
                End Try

                Me.Button_Load.Enabled = True
                If Me.m_Have_MDigitizer Then
                    Me.GroupBox_ExposureTime.Enabled = True
                End If

                Call Me.ImageZoomAll()
                'Me.Button_Save.Enabled = True
            End If

            Me.ContextMenuStrip_AlignSetting.Visible = True
            Me.Button_Load.Enabled = True
        Catch ex As Exception
            Me.Button_Load.Enabled = True
            If Me.m_Have_MDigitizer Then
                Me.GroupBox_ExposureTime.Enabled = True
            End If
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.Button_Load]" & ex.Message)
            MessageBox.Show("[Dialog_CameraAlignment.Button_Load_Click]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Save_Click ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Me.Setting()
    End Sub
#End Region

#Region "--- Button_SaveAlignment_Click ---"
    Private Sub Button_SaveAlignmentRecipe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SaveAlignmentRecipe.Click

        Me.CheckBox_ShowROI.Checked = False
        Me.CheckBox_ShowBoundary.Checked = False
        Me.ContextMenuStrip_AlignSetting.Visible = False

        Me.m_Form.PaintStop = True

        If MsgBox("Are you sure to save the alignment recipe?", MsgBoxStyle.OkCancel, "Save") = MsgBoxResult.Ok Then
            Dim Parameter_Lists As String = ""
            Try
                '--- 建立連線 ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                '----------------------------------------------------------------------------------------------
                ' Dialog_FuncSettingBase Setting   ==> Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '---UpdateData---
                    Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY = Me.NumericUpDown_BoundaryTop.Value
                    Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Value
                    Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Value
                    Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX = Me.NumericUpDown_BoundaryRight.Value
                    Me.m_FuncProcess.FuncModelRecipe.TopAnalysis.Value = Me.CheckBox_Func_TopAnalysis.Checked
                    Me.m_FuncProcess.FuncModelRecipe.BottomAnalysis.Value = Me.CheckBox_Func_BottomAnalysis.Checked
                    Me.m_FuncProcess.FuncModelRecipe.LeftAnalysis.Value = Me.CheckBox_Func_LeftAnalysis.Checked
                    Me.m_FuncProcess.FuncModelRecipe.RightAnalysis.Value = Me.CheckBox_Func_RightAnalysis.Checked
                    Me.m_FuncProcess.FuncModelRecipe.Alignment_Shift.Value = Me.NumericUpDown_AlignmentShift.Value
                    Me.m_FuncProcess.FuncModelRecipe.AlignTolerance.Value = Me.NumericUpDown_AlignTolerance.Value
                    Me.m_FuncProcess.FuncModelRecipe.EnhanceEdge.Value = Me.CheckBox_EnhanceEdge.Checked

                    '--- Prepare Command ---
                    Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING"
                    TimeOut = 10000 '10 secs

                    'UI Recipe Setting -----------------------------------
                    '--- 第一頁 ---
                    Parameter_Lists = "BoundaryTop," & Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY & ";" & "BoundaryBottom," & Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY & ";" & "BoundaryLeft," & Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX & ";" & "BoundaryRight," & Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX & ";"     'grant add new mappingtable

                    '--- 第四頁 ---
                    Parameter_Lists = Parameter_Lists & "AlignmentShift," & Me.NumericUpDown_AlignmentShift.Value & ";" & "AlignTolerance," & Me.NumericUpDown_AlignTolerance.Value & ";" & _
                                       "TopAnalysis," & Me.CheckBox_Func_TopAnalysis.Checked & ";" & "BottomAnalysis," & Me.CheckBox_Func_BottomAnalysis.Checked & ";" & "LeftAnalysis," & Me.CheckBox_Func_LeftAnalysis.Checked & ";" & "RightAnalysis," & Me.CheckBox_Func_RightAnalysis.Checked & ";" & "EnhanceEdge," & Me.CheckBox_EnhanceEdge.Checked & ";"
                    'End UI Recipe Setting -----------------------------------


                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                '--- 更新路徑 ---
                strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                Me.RepairPath_2(strPath)

                '----------------------------------------------------------------------------------------------
                ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_FUNC_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save MappingTable Recipe  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_MAPPINGTABLE_RECIPE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                Me.CheckBox_ShowROI.Checked = True
                Me.ContextMenuStrip_AlignSetting.Visible = True
                '--- Button Control ---   
            Catch ex As Exception
                Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#Region "---Button_Alignment---"
    Private Sub Button_Alignment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Alignment.Click
        Dim Image As MIL_ID = M_NULL
        Dim OutputString As String = ""
        Dim strs1() As String
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim strPath = ""
        Dim Func_Boundary As ClsParameterBoundary
        Dim SizeX, SizeY As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Me.CheckBox_ShowROI.Checked = False
            Me.CheckBox_ShowBoundary.Checked = False
            Me.ContextMenuStrip_AlignSetting.Visible = False
            Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If Image = M_NULL Then
                MsgBox("請載入影像")
            Else

                '----------------------------------------------------------------------------------------------
                ' Dialog_FuncSettingBase Setting   ==> Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "DIALOG_FUNCSETTINGBASE_SETTING"
                    TimeOut = 10000 '10 secs

                    'UI Recipe Setting -----------------------------------
                    '--- 第一頁 ---
                    Parameter_Lists = "BoundaryTop," & Me.NumericUpDown_BoundaryTop.Value & ";" & "BoundaryBottom," & Me.NumericUpDown_BoundaryBottom.Value & ";" & "BoundaryLeft," & Me.NumericUpDown_BoundaryLeft.Value & ";" & "BoundaryRight," & Me.NumericUpDown_BoundaryRight.Value & ";"     'grant add new mappingtable


                    '--- 第四頁 ---
                    Parameter_Lists = Parameter_Lists & "AlignmentShift," & Me.NumericUpDown_AlignmentShift.Value & ";" & "AlignTolerance," & Me.NumericUpDown_AlignTolerance.Value & ";" & _
                                       "TopAnalysis," & Me.CheckBox_Func_TopAnalysis.Checked & ";" & "BottomAnalysis," & Me.CheckBox_Func_BottomAnalysis.Checked & ";" & "LeftAnalysis," & Me.CheckBox_Func_LeftAnalysis.Checked & ";" & "RightAnalysis," & Me.CheckBox_Func_RightAnalysis.Checked & ";" & "EnhanceEdge," & Me.CheckBox_EnhanceEdge.Checked & ";"
                    'End UI Recipe Setting -----------------------------------

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------------------------------
                'Calculate Func Original Boundary (Func's ROI)  ==> Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY"
                    TimeOut = 3000000 '3000 secs
                    Parameter_Lists = "0"         '2010/07/26 grant add mappingtable find 3CCD mark (Not Make MappingTable, emblem=>false)
                    Parameter_Lists1 = "Defect"   '2010/07/28 grant add mappingtable to distinguish "Standard_Theta" or "Defect_Theta"
                    Func_Boundary = Me.m_FuncProcess.FuncModelRecipe.Boundary   '2011/03/03 Rick add

                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Parameter_Lists, Parameter_Lists1, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                        If SubSystemResult.Responses(0).Param3 = "False" Then
                            Me.StatusBarPanel_Msg.Text = SubSystemResult.Responses(0).Param4
                        Else
                            '--- 解析 ROI Boundary ----
                            OutputString = SubSystemResult.Responses(0).Param2
                            strs1 = OutputString.Split(";")

                            If (CInt(strs1(0)) = 0 And CInt(strs1(1)) = 0 And CInt(strs1(2)) = 0 And CInt(strs1(3)) = 0) Then
                                Me.m_FuncProcess.FuncModelRecipe.Boundary = Func_Boundary
                            Else
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(strs1(0))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(strs1(1))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(strs1(2))
                                Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(strs1(3))
                                Me.NumericUpDown_BoundaryTop.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                                Me.NumericUpDown_BoundaryBottom.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY
                                Me.NumericUpDown_BoundaryLeft.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                                Me.NumericUpDown_BoundaryRight.Value = Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX
                                Me.m_FuncProcess.FuncModelRecipe.TopAnalysis.Value = Me.CheckBox_Func_TopAnalysis.Checked
                                Me.m_FuncProcess.FuncModelRecipe.BottomAnalysis.Value = Me.CheckBox_Func_BottomAnalysis.Checked
                                Me.m_FuncProcess.FuncModelRecipe.LeftAnalysis.Value = Me.CheckBox_Func_LeftAnalysis.Checked
                                Me.m_FuncProcess.FuncModelRecipe.RightAnalysis.Value = Me.CheckBox_Func_RightAnalysis.Checked
                                Me.m_MainProcess.DOffsetX = CInt(strs1(4))
                                Me.m_MainProcess.DOffsetY = CInt(strs1(5))
                                Me.m_MainProcess.DTheta = (strs1(6))
                                Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointX.Value = CInt(strs1(4))
                                Me.m_MainProcess.TableProcess.MappingTableRecipe.DPointY.Value = CInt(strs1(5))
                            End If

                            '--- Status Message ---
                            Me.StatusBarPanel_Msg.Text = SubSystemResult.Responses(0).Param4
                        End If

                    Else
                        MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment_Click]" & SubSystemResult.Responses(0).Param2, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '--- Calculate ROI Image ---
                Try
                    If Me.m_Form.OpenFileDialog.FileName <> "" Then
                        If MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_IPBootConfig.ImageSizeY.Value Then
                            Try
                                If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                            Catch ex As Exception
                                Me.StatusBarPanel_Msg.Text = "Please make sure ROI is correctly"
                            End Try
                        Else
                            If Me.m_FuncProcess.Img_OriginalROI <> M_NULL Then
                                MbufFree(Me.m_FuncProcess.Img_OriginalROI)
                                Me.m_FuncProcess.Img_OriginalROI = M_NULL
                            End If

                            SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                            Me.m_FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                        End If
                    End If
                Catch ex As Exception
                    Throw New Exception("Calculate Func ROI Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
                End Try

                '--- 更新路徑 ---
                strPath = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                Me.RepairPath_2(strPath)
                'MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_FuncProcess.FuncModelRecipe, strPath)

                '----------------------------------------------------------------------------------------------
                ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_FUNC_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Me.StatusBarPanel_Msg.Text = "[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Save MappingTable Recipe  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_MAPPINGTABLE_RECIPE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Me.StatusBarPanel_Msg.Text = "[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            Me.CheckBox_ShowROI.Checked = True
            Me.ContextMenuStrip_AlignSetting.Visible = True

            '--- Button Control ---   
        Catch ex As Exception
            Me.StatusBarPanel_Msg.Text = "[Dialog_CameraAlignment.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")"
            MessageBox.Show("[Dialog_CameraAlignment.Button_Alignment]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#End Region

#Region "--- TrackBar Event ---"

#Region "--- TrackBar_ExposureTime_MouseUp ---"
    Private Sub TrackBar_ExposureTime_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_ExposureTime.MouseUp
        If Me.m_Initial_Finished = False Then Exit Sub

        '--- 更新曝光時間 ---
        '--- 須滿足最小曝光時間 16000 --- 
        'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
        Me.NumericUpDown_ExposureTime.Value = Me.TrackBar_ExposureTime.Value
        Call UpdateExposureTime()

    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_ShowBoundary_CheckedChanged ---"
    Private Sub CheckBox_ShowBoundary_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowBoundary.CheckedChanged
        Me.m_Form.PaintStop = Not Me.CheckBox_ShowBoundary.Checked

        If CheckBox_ShowBoundary.Checked Then
            Me.CheckBox_ShowROI.Enabled = False
        Else
            Me.CheckBox_ShowROI.Enabled = True
        End If

        If CheckBox_ShowBoundary.Checked Then
            Me.DrawMark1()
        Else
            Me.m_GraphicsImage.Clear(Color.Transparent)
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBox_ShowBoundary_CheckedChanged ---"
    Private Sub CheckBox_ShowROI_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox_ShowROI.CheckedChanged
        Me.m_Form.PaintStop = Not Me.CheckBox_ShowROI.Checked

        If CheckBox_ShowROI.Checked Then
            Me.CheckBox_ShowBoundary.Enabled = False
        Else
            Me.CheckBox_ShowBoundary.Enabled = True
        End If

        If CheckBox_ShowROI.Checked Then
            Me.DrawMark2()
        Else
            Me.m_GraphicsImage.Clear(Color.Transparent)
            Me.m_Panel_AxMDisplay.Refresh()
        End If
    End Sub
#End Region

#Region "--- CheckBo_CCD_Rotate_90_CheckedChanged ---"
    Private Sub CheckBo_CCD_Rotate_90_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBo_CCD_Rotate_90.CheckedChanged
        Dim car As ClsCameraAlignmentRecipe = Me.m_FuncProcess.CameraAlignmentRecipe

        If CheckBo_CCD_Rotate_90.Checked Then
            Me.TextBox_CCD_Resolution_H.Text = car.CCD_Resolution_V.Value
            Me.TextBox_CCD_Resolution_V.Text = car.CCD_Resolution_H.Value
        Else
            Me.TextBox_CCD_Resolution_H.Text = car.CCD_Resolution_H.Value
            Me.TextBox_CCD_Resolution_V.Text = car.CCD_Resolution_V.Value
        End If
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- NumericUpDown_ExposureTime_ValueChanged ---"
    Private Sub NumericUpDown_ExposureTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_ExposureTime.ValueChanged
        If Me.m_Initial_Finished = False Then Exit Sub

        Me.TrackBar_ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
        Call UpdateExposureTime()
    End Sub
#End Region

#End Region

#Region "--- ZommEnable ---"
    Private Sub ZoomEnable(ByVal En As Boolean)
        Me.SetButton_ZoomIn(En)
        Me.SetButton_ZoomOut(En)
        Me.SetButton_ZoomO(En)
        Me.SetButton_ZoomAll(En)
    End Sub
#End Region

#Region "--- Darw Event ---"

#Region "--- m_AxMDisplay_PaintEvent ---"
    Private Sub m_AxMDisplay_PaintEvent(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            If CheckBox_ShowBoundary.Checked Then
                Me.DrawMark1()
            ElseIf CheckBox_ShowROI.Checked Then
                Me.DrawMark2()
            End If
        End If
    End Sub
#End Region

#Region "--- DrawMark ---"

    Private Sub DrawMark1()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image <> M_NULL Then
            DrawPitch(image, Me.m_MainProcess.IPNetworkConfig.Total_IP)
        End If
    End Sub

    Private Sub DrawMark2()
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image <> M_NULL Then
            DrawROI(image, Me.m_MainProcess.IPNetworkConfig.Total_IP)
        End If
    End Sub

#End Region

#Region "--- Draw ---"

#Region "--- DrawPitch ---"
    Private Sub DrawPitch(ByVal image As MIL_ID, ByVal CCDMode As Integer)
        If Not Me.GetShowBoundaryEnableInfo Then Exit Sub

        Dim rect As Rectangle
        Dim s As Double
        Dim LeftX As Double
        Dim RightX As Double
        Dim TopY As Double
        Dim BottomY As Double
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer
        Dim CCDPixel_X_PerCCD As Double
        Dim CCDPixel_Y_PerCCD As Double
        Dim Draw_LeftX, Draw_TopY, Draw_RightX, Draw_BottomY As Double
        Dim P1 As Point
        Dim P2 As Point


        CCDPixel_X_PerCCD = Val(Me.TextBox_Panel_Resolution_H.Text) * Val(Me.NumericUpDown_Pitch.Value) / Val(Me.TextBox_CCD_X_Num.Text)
        CCDPixel_Y_PerCCD = Val(Me.TextBox_Panel_Resolution_V.Text) * Val(Me.NumericUpDown_Pitch.Value) / Val(Me.TextBox_CCD_Y_Num.Text)

        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        Try
            image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If image <> M_NULL Then

                '--- Initial ---
                rect = New Rectangle
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

                If ZoomX <= 0 Then ZoomX = 0.1
                If ZoomY <= 0 Then ZoomY = 0.1

                s = Math.Ceiling(ZoomX)

                SizeX = MIL.MbufInquire(image, MIL.M_SIZE_X, M_NULL)
                SizeY = MIL.MbufInquire(image, MIL.M_SIZE_Y, M_NULL)

                Me.m_Pen.Color = Color.Red

                '--- Initial ---
                LeftX = ((Val(TextBox_CCD_Resolution_H.Text) - CCDPixel_X_PerCCD) / 2) * ZoomX
                TopY = ((Val(TextBox_CCD_Resolution_V.Text) - CCDPixel_Y_PerCCD) / 2) * ZoomY
                RightX = LeftX + CCDPixel_X_PerCCD * ZoomX
                BottomY = TopY + CCDPixel_Y_PerCCD * ZoomY

                If Me.CheckBo_CCD_Rotate_90.Checked Then
                    Draw_LeftX = TopY + Val(Me.TextBox_ROI_OffsetX.Text) - Me.HScrollBar.Value * ZoomX
                    Draw_TopY = LeftX + Val(Me.TextBox_ROI_OffsetY.Text) - Me.VScrollBar.Value * ZoomY
                    Draw_RightX = BottomY + Val(Me.TextBox_ROI_OffsetX.Text) - Me.HScrollBar.Value * ZoomX
                    Draw_BottomY = RightX + Val(Me.TextBox_ROI_OffsetY.Text) - Me.VScrollBar.Value * ZoomY
                Else
                    Draw_LeftX = LeftX + Val(Me.TextBox_ROI_OffsetX.Text) - Me.HScrollBar.Value * ZoomX
                    Draw_TopY = TopY + Val(Me.TextBox_ROI_OffsetY.Text) - Me.VScrollBar.Value * ZoomY
                    Draw_RightX = RightX + Val(Me.TextBox_ROI_OffsetX.Text) - Me.HScrollBar.Value * ZoomX
                    Draw_BottomY = BottomY + Val(Me.TextBox_ROI_OffsetY.Text) - Me.VScrollBar.Value * ZoomY
                End If

                '-----------------------
                If Draw_LeftX <= 0 Then
                    Draw_LeftX = 0
                End If
                If Draw_TopY <= 0 Then
                    Draw_TopY = 0
                End If
                '-----------------------

                If Draw_LeftX >= Me.m_BitMap.Width Then
                    Draw_LeftX = Me.m_BitMap.Width - 2
                End If
                If Draw_RightX >= Me.m_BitMap.Width Then
                    Draw_RightX = Me.m_BitMap.Width - 1
                End If
                If Draw_TopY >= Me.m_BitMap.Height Then
                    Draw_TopY = Me.m_BitMap.Height - 2
                End If
                If Draw_BottomY >= Me.m_BitMap.Height Then
                    Draw_BottomY = Me.m_BitMap.Height - 1
                End If

                rect.X = Draw_LeftX
                rect.Y = Draw_TopY
                rect.Width = Draw_RightX - Draw_LeftX + 1
                rect.Height = Draw_BottomY - Draw_TopY + 1
                Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)


                '--- 畫十字線 ---  '2016/01/25 Rick add
                Me.m_Pen.Width = 2 * s
                P1.X = (Draw_RightX + Draw_LeftX) * 0.5 - 16 * s
                P1.Y = (Draw_BottomY + Draw_TopY) * 0.5
                P2.X = (Draw_RightX + Draw_LeftX) * 0.5 + 16 * s
                P2.Y = (Draw_BottomY + Draw_TopY) * 0.5
                If P1.X > 0 AndAlso P1.Y > 0 Then
                    Me.m_GraphicsImage.DrawLine(Me.m_Pen, P1, P2)
                End If

                P1.X = (Draw_RightX + Draw_LeftX) * 0.5
                P1.Y = (Draw_TopY + Draw_BottomY) * 0.5 - 16 * s
                P2.X = (Draw_RightX + Draw_LeftX) * 0.5
                P2.Y = (Draw_TopY + Draw_BottomY) * 0.5 + 16 * s
                If P1.X > 0 AndAlso P1.Y > 0 Then
                    Me.m_GraphicsImage.DrawLine(Me.m_Pen, P1, P2)
                End If

            End If

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.StatusBarPanel_Msg.Text = "[Dialog_CameraAlignment.DrawROI]" & ex.Message & "(" & ex.StackTrace & ")"
        End Try
    End Sub
#End Region

#Region "--- DrawROI ---"
    Private Sub DrawROI(ByVal image As MIL_ID, ByVal CCDMode As Integer)
        If Not Me.GetShowROIEnableInfo Then Exit Sub

        Dim rect As Rectangle
        Dim s As Double
        Dim ZoomX, ZoomY As Double
        Dim SizeX, SizeY As Integer
        Dim v As Integer
        Dim h As Integer

        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)
        Me.m_SolidBrush = New SolidBrush(Color.Yellow)

        Try
            image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If image <> M_NULL Then

                '--- Initial ---
                rect = New Rectangle
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

                If ZoomX <= 0 Then ZoomX = 0.1 '2012/09/04 Rick add
                If ZoomY <= 0 Then ZoomY = 0.1 '2012/09/04 Rick add

                s = Math.Ceiling(ZoomX)

                SizeX = MIL.MbufInquire(image, MIL.M_SIZE_X, M_NULL)
                SizeY = MIL.MbufInquire(image, MIL.M_SIZE_Y, M_NULL)

                '--- Initial ---

                v = (Me.NumericUpDown_BoundaryLeft.Value - Me.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_BoundaryRight.Value - Me.HScrollBar.Value) * ZoomX
                If v >= 0 And v < Me.m_BitMap.Width Then
                    h = SizeY * ZoomY
                    If h >= Me.m_BitMap.Height Then
                        h = Me.m_BitMap.Height - 1
                    End If
                    rect.X = v
                    rect.Y = 0
                    rect.Width = s
                    rect.Height = h
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_BoundaryTop.Value - Me.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
                v = (Me.NumericUpDown_BoundaryBottom.Value - Me.VScrollBar.Value) * ZoomY
                If v >= 0 And v < Me.m_BitMap.Height Then
                    h = SizeX * ZoomX
                    If h >= Me.m_BitMap.Width Then
                        h = Me.m_BitMap.Width - 1
                    End If
                    rect.X = 0
                    rect.Y = v
                    rect.Width = h
                    rect.Height = s
                    Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                End If
            End If
            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_CameraAlignment.DrawROI]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- DrawGoTo_Blob ---"
    Private Sub DrawGoTo_Blob(ByVal BlobX As Integer, ByVal BlobY As Integer)
        Dim image As MIL_ID = M_NULL
        Dim offX As Integer
        Dim offY As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim s As Double
        Dim x As Integer
        Dim y As Integer
        Dim r As Integer
        Dim hr As Integer

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then
            Return
        End If
        MIL.MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, s)
        Me.m_Form.PaintStop = True

        '--- Initial ---
        Me.m_Panel_AxMDisplay.Refresh()
        Me.m_GraphicsImage.Clear(Color.Transparent)

        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        '--- Initial ---
        ox = Me.HScrollBar.Value
        oy = Me.VScrollBar.Value

        '--- Draw Image ---
        r = Me.m_Size * s
        If r <= 0 Then
            r = 1
        End If
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red

        If BlobX > 0 And BlobY > 0 Then
            x = BlobX
            y = BlobY
            x = (x - ox + 0.5) * s - hr   ' -hr , 因為從 0度開始畫圓
            y = (y - oy + 0.5) * s - hr
            If x < MdispInquire(Me.m_AxMDisplay, M_SIZE_X, M_NULL) And y < MdispInquire(Me.m_AxMDisplay, M_SIZE_Y, M_NULL) Then
                Me.m_GraphicsImage.DrawArc(Me.m_Pen, x, y, r, r, 0.0F, 360.0F)
            End If
        End If

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
    End Sub

#End Region

#End Region

#End Region

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles VScrollBar.ValueChanged
        MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Value, Me.VScrollBar.Value)
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles HScrollBar.ValueChanged
        MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Value, Me.VScrollBar.Value)
    End Sub
#End Region

#Region "--- AxMDisplay Operation ---"

#Region "--- Panel_AxMDisplay_MouseMove ---"
    Private Sub Panel_AxMDisplay_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        Dim lFetchedValue() As Integer = {0} ' Label of the background.
        Dim image As MIL_ID = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)

        Try
            If image <> MIL.M_NULL Then
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double

                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

                'ZoomX = MIL.MdispInquire(Me.AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

                If ZoomX > 0 Then
                    Me.m_MouseX = Math.Floor((e.X) / ZoomX)
                    Me.m_MouseX += Me.HScrollBar.Value
                    Me.m_MouseY = Math.Floor((e.Y) / ZoomX)
                    Me.m_MouseY += Me.VScrollBar.Value

                    If Me.m_MouseX < SizeX AndAlso Me.m_MouseY < SizeY AndAlso Me.m_MouseX > 0 AndAlso Me.m_MouseY > 0 Then

                        MIL.MbufGet2d(image, Me.m_MouseX, Me.m_MouseY, 1, 1, lFetchedValue)

                        Me.StatusBarXYV("(" & Me.m_MouseX & "," & Me.m_MouseY & ")", lFetchedValue(0))
                    Else
                        If Me.m_MouseX < 0 Then Me.m_MouseX = 1
                        If Me.m_MouseY < 0 Then Me.m_MouseY = 1
                        If Me.m_MouseX > SizeX Then Me.m_MouseX = SizeX - 1
                        If Me.m_MouseY > SizeY Then Me.m_MouseY = SizeY - 1
                        Me.StatusBarXYV("NULL", "NULL")
                    End If
                End If
            Else
                Me.StatusBarXYV("NULL", "NULL")
            End If
        Catch ex As Exception
            Throw New Exception("[MainForm.ShowValue]Show Value Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#End Region

#Region "--- ImageUpdate ---"
    Private Sub ImageUpdate(ByRef Img_Current As MIL_ID)
        If Img_Current = M_NULL Then Exit Sub

        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        If Img_Current = M_NULL Then
            MdispSelect(Me.m_AxMDisplay, M_NULL)
        Else
            If Img_Current <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(Img_Current, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Img_Current, M_SIZE_Y, M_NULL)
                Type = MbufInquire(Img_Current, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(Img_Current, imageBuffer)

                MbufControl(Img_Current, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, GetAxMDisplay_HandleInfo())  '2013/01/24 Rick modify
            Else
                MdispSelect(Me.m_AxMDisplay, M_NULL)
            End If
        End If
    End Sub
#End Region
#Region "--- Change Language ---"


    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Button_Continue.Text = res.GetString("Button_Continue.Text")
                Button_Grab.Text = res.GetString("Button_Grab.Text")
                Button_Load.Text = res.GetString("Button_Load.Text")
                Button_ZoomAll.Text = res.GetString("Button_ZoomAll.Text")
                Button_ZoomO.Text = res.GetString("Button_ZoomO.Text")
                Button_ZoomOut.Text = res.GetString("Button_ZoomOut.Text")
                CheckBox_ShowBoundary.Text = res.GetString("CheckBox_ShowBoundary.Text")
                CheckBox_ShowROI.Text = res.GetString("CheckBox_ShowROI.Text")
                GroupBox_Boundary.Text = res.GetString("GroupBox_Boundary.Text")
                GroupBox_ExposureTime.Text = res.GetString("GroupBox_ExposureTime.Text")
                GroupBox_Grab.Text = res.GetString("GroupBox_Grab.Text")
                Label_BoundaryBottom.Text = res.GetString("Label_BoundaryBottom.Text")
                Label_BoundaryLeft.Text = res.GetString("Label_BoundaryLeft.Text")
                Label_BoundaryRight.Text = res.GetString("Label_BoundaryRight.Text")
                Label_BoundaryTop.Text = res.GetString("Label_BoundaryTop.Text")
                Label_ExposureTime.Text = res.GetString("Label_ExposureTime.Text")
                StatusBarPanel_Scale.Text = res.GetString("StatusBarPanel_Scale.Text")
        End Select
    End Sub
#End Region



#End Region

#Region "--- 方法函式 (MasterSlave Mode) ---"

#Region "--- MS_ConnectToIP ---"
    Public Function MS_ConnectToIP()
        Dim Master_GrabNo As String = ""
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        '--- 建立 Master IP 連線 ---
        ip = New ClsIPInfo
        ip.CCDNo = 1
        Me.m_Form.Change_GrabNo(ip.CCDNo, Master_GrabNo)
        ip.GrabNo = Master_GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)

        '--- 建立 Slave IP 連線 ---
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)

        For Each r As ClsIPInfo In Me.m_MainProcess.IPInfo
            Me.m_MainProcess.Init_IP(r.CCDNo, Me.m_MainProcess.IPNetworkConfig.Total_IP)
        Next

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- MS_UpdateGrabImage_With_ExposureTime ---"
    Public Sub MS_UpdateGrabImage_With_ExposureTime()
        Dim Image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim FocusValue As Integer
        Dim ExposureTime As Long
        Dim strs() As String
        Dim strPath_Exists As Boolean

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
            End If
           
            If System.IO.File.Exists(strPath) Then
                Directory.CreateDirectory(strPath)
            End If

            '--- Disable ScrollBar ---
            'Me.ScrollBar_Enable(False)

            '--- 建立連線 ---
            If Not Me.MS_ConnectToIP Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)

            Me.m_Grab_OK = False
            'Call ImageZoomAll()

            Try
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                SyncLock Me.m_MainProcess.IP_Dispatcher1
                    '--- Prepare Command ---
                    Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    ExposureTime = Me.GetExposureTimeInfo()
                    Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Master_ID, Request_Command, ExposureTime, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                End SyncLock

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image With ExposureTime Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_CameraAlignment.MS_UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Response_OK = False
                Me.m_ContinueGrab = False
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                Me.RepairPath_2(strPath)
            End If
         
            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
            MbufDiskInquire(strPath, M_TYPE, Type)
            strPath_Exists = System.IO.File.Exists(strPath)

            Do
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GRAB_ONESHOT_WITH_EXPOSURETIME"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        ExposureTime = Me.GetExposureTimeInfo()
                        Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Master_ID, Request_Command, ExposureTime, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image With ExposureTime Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    If Response_OK AndAlso Not (Me.m_AxMDisplay = M_NULL) Then
                        '--- Update Processed Image ---
                        Grab_Success = Grab_Success + 1
                        Image = Me.m_MainProcess.Img_16U_Grab_1

                        If strPath_Exists Then

                            If Image <> M_NULL Then
                                If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image)
                                    Image = M_NULL
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Image)
                            Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                            If Image <> M_NULL Then
                                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                                Type = MbufInquire(Image, M_TYPE, M_NULL)

                                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                    MbufFree(imageBuffer)
                                    imageBuffer = M_NULL
                                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                End If
                                MbufCopy(Image, imageBuffer)

                                MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, Me.GetAxMDisplay_HandleInfo())
                                MbufControl(Image, M_MODIFIED, M_DEFAULT)
                                MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                If Not Me.m_Form_Closing Then Me.ResetScrollBar()
                            End If

                            'If Not Me.m_Form_Closing Then Me.ZoomEnable(False)
                        End If
                    End If

                    '----------------------------------------------------------------------------------------------
                    ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "LOAD_IMAGE"
                        TimeOut = 200000 '200 secs

                        '--- Initial ---  
                        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Slave_ID, Request_Command, "", "", strPath, , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_CameraAlignment.Button_Grab]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            If Me.m_Have_MDigitizer Then
                                Me.GroupBox_ExposureTime.Enabled = True
                            End If
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.Button_Grab]Load Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_CameraAlignment.Button_Grab]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Throw New Exception(ex.Message)
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Get Gray Mean  ==> Request_Command = "GET_FOCUSVALUE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        SyncLock Me.m_MainProcess.IP_Dispatcher1
                            '--- Prepare Command ---
                            Request_Command = "GET_FOCUSVALUE"
                            TimeOut = 500000 '500 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Slave_ID, Request_Command, , , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                        End SyncLock

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                            If SubSystemResult.Responses(0).Param2 <> "" Then

                                strs = SubSystemResult.Responses(0).Param2.Split(",")
                                FocusValue = strs(1)
                                SetStatusBarPanel_Focus("Focus：" & FocusValue)
                            End If
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Focus Value Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_CameraAlignment.MS_UpdateGrabImage_With_ExposureTime]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_CameraAlignment.get_FocusValue]Get Focus Value Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_CameraAlignment.get_FocusValue]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End Try

                    Me.m_Grab_OK = True

                Catch ex As Exception
                    Response_OK = False
                    Me.m_ContinueGrab = False
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Loop While (Me.m_ContinueGrab And Me.Button_Continue.Enabled = False)

            Me.m_Grab_OK = True
            If Not Me.m_Form_Closing Then Me.ScrollBar_Enable(True)
            If Not Me.m_Form_Closing Then Me.ZoomEnable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            If Not Me.m_Form_Closing Then Me.ScrollBar_Enable(True)
            If Not Me.m_Form_Closing Then Me.SetButton_Grab(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_CameraAlignment.UpdateGrabImage_With_ExposureTime]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#End Region

#Region "--- UI 介面 ---"

#Region "--- Zoom Operation --"

#Region "--- Button_ZoomIn_Click ---"
    Private Sub Button_ZoomIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomIn.Click
        Dim s As Double
        Dim ZoomX As Double

        'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
        s = ZoomX * Me.m_ZoomFactor
        MdispZoom(Me.m_AxMDisplay, s, s)
        Me.SetStatusBarPanel_Scale("縮放 = " & s)

        If Me.m_ZoomMax < s * Me.m_ZoomFactor Then
            Me.SetButton_ZoomIn(False)
        End If
        Me.SetButton_ZoomOut(True)

        Me.ResetScrollBar()
    End Sub
#End Region

#Region "--- Button_ZoomOut_Click ---"
    Private Sub Button_ZoomOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomOut.Click
        Dim s As Double
        Dim ZoomX As Double

        'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

        s = ZoomX / Me.m_ZoomFactor
        If s < Me.m_ZoomMin Then Exit Sub

        If s / Me.m_ZoomFactor < Me.m_ZoomMin Then
            Me.SetButton_ZoomOut(False)
            MdispZoom(Me.m_AxMDisplay, Me.m_ZoomMin, Me.m_ZoomMin)
            Me.ResetScrollBar()
        Else
            MdispZoom(Me.m_AxMDisplay, s, s)
            Me.SetStatusBarPanel_Scale("縮放 = " & s)
            Me.SetButton_ZoomIn(True)
            Me.ResetScrollBar()
        End If
    End Sub
#End Region

#Region "--- Button_ZoomO_Click ---"
    Private Sub Button_ZoomO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomO.Click
        Call ImageZoomO()
    End Sub
#End Region

#Region "--- ImageZoomO ---"
    Public Sub ImageZoomO()
        MdispZoom(Me.m_AxMDisplay, 1, 1)
        Me.SetStatusBarPanel_Scale("縮放 = " & 1.0)
        Me.SetButton_ZoomIn(True)
        Me.SetButton_ZoomOut(True)
        Me.ResetScrollBar()
    End Sub
#End Region

#Region "--- Button_ZoomAll_Click ---"
    Private Sub Button_ZoomAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomAll.Click
        Call ImageZoomAll()
    End Sub
#End Region

#Region "--- ImageZoomAll ---"
    Public Sub ImageZoomAll()
        Dim image As MIL_ID = M_NULL
        Dim s As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then Exit Sub

        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim DisplayWidth As Integer = Me.m_Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.m_Panel_AxMDisplay.Size.Height

        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

        If SizeX > 0 And SizeY > 0 Then
            s = Math.Max(DisplayWidth / SizeX, DisplayHeight / SizeY)
            Me.m_ZoomMin = s
            'If s < 0.1 Then s = 0.1
            MIL.MdispZoom(Me.m_AxMDisplay, s, s)
            Me.StatusBarPanel_Scale.Text = "縮放 = " & s
        End If

        If Me.m_ZoomMax < s * Me.m_ZoomFactor Then
            Me.SetButton_ZoomIn(False)
        Else
            Me.SetButton_ZoomIn(True)
        End If
        If s / Me.m_ZoomFactor < Me.m_ZoomMin Then
            Me.SetButton_ZoomOut(False)
        Else
            Me.SetButton_ZoomOut(True)
        End If

        Me.ResetScrollBar()
    End Sub
#End Region

#Region "--- Button_GoTo_Position ---"
    Private Sub Button_GoTo_Position_Click(sender As System.Object, e As System.EventArgs) Handles Button_GoTo_Position.Click
        If CInt(TextBox_GoTo_BlobX.Text) > 0 And CInt(TextBox_GoTo_BlobY.Text) > 0 Then
            Try
                Dim picsize As Integer
                Dim offset_X, offset_Y As Integer
                Dim p As New Position
                Dim offX As Integer
                Dim offY As Integer
                Dim DisplayWidth As Integer = Me.m_Panel_AxMDisplay.Size.Width
                Dim DisplayHeight As Integer = Me.m_Panel_AxMDisplay.Size.Height
                Dim Image As MIL_ID = M_NULL
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double
                Dim CenterHScroll As Double
                Dim OffsetHScroll As Double
                Dim CenterVScroll As Double
                Dim OffsetVScroll As Double

                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

                p.BlobX = CInt(TextBox_GoTo_BlobX.Text)
                p.BlobY = CInt(TextBox_GoTo_BlobY.Text)

                offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
                offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
                picsize = Math.Max(CInt(((50) ^ 0.5) * 2), 100)

                offset_X = Math.Max(CInt(p.BlobX) - CInt(picsize / 2), 0)
                offset_Y = Math.Max(CInt(p.BlobY) - CInt(picsize / 2), 0)

                Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

                CenterHScroll = ((offset_X + CInt(picsize / 2)) * Me.HScrollBar.Maximum) / (SizeX - DisplayWidth / ZoomX)
                OffsetHScroll = ((DisplayWidth / ZoomX) / 2) * (Me.HScrollBar.Maximum / (SizeX - DisplayWidth / ZoomX))
                CenterVScroll = ((offset_Y + CInt(picsize / 2)) * Me.VScrollBar.Maximum) / (SizeY - DisplayHeight / ZoomX)
                OffsetVScroll = ((DisplayHeight / ZoomX) / 2) * (Me.VScrollBar.Maximum / (SizeY - DisplayHeight / ZoomX))

                CenterHScroll = CenterHScroll - OffsetHScroll
                CenterVScroll = CenterVScroll - OffsetVScroll

                If CenterHScroll < 0 Then
                    Me.HScrollBar.Value = 0
                ElseIf CenterHScroll > Me.HScrollBar.Maximum Then
                    Me.HScrollBar.Value = Me.HScrollBar.Maximum
                Else
                    If CenterHScroll > 0 Then Me.HScrollBar.Value = CenterHScroll
                End If

                If CenterVScroll < 0 Then
                    Me.VScrollBar.Value = 0
                ElseIf CenterVScroll > Me.VScrollBar.Maximum Then
                    Me.VScrollBar.Value = Me.VScrollBar.Maximum
                Else
                    If CenterVScroll > 0 Then Me.VScrollBar.Value = CenterVScroll
                End If

                Me.DrawGoTo_Blob(p.BlobX, p.BlobY)
            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncTestImageProcess.Button_GoTo_Position_Click]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        Else
            MsgBox("請檢查輸入數值大於 0 !", MsgBoxStyle.Exclamation, "[AreaGrabber]")
        End If
    End Sub
#End Region

#End Region

#Region "--- ResetScrollBar ---"
    Public Sub ResetScrollBar()
        ' ErrorCode = ErrorCodeBase + 670
        Dim Image As MIL_ID = M_NULL
        Dim s As Integer

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 670
        Try
            Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If Image = M_NULL Then
                Me.HScrollBar.Maximum = 0
                Me.VScrollBar.Maximum = 0
            Else
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double

                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)


                If ZoomX > 0 Then
                    s = SizeX - Math.Floor(Me.m_Panel_AxMDisplay.Size.Width / ZoomX)
                    If s <= 0 Then
                        s = 0
                    End If
                    Me.SetHScrollBar(s)

                    s = SizeY - Math.Floor(Me.m_Panel_AxMDisplay.Size.Height / ZoomX)
                    If s <= 0 Then
                        s = 0
                    End If
                    Me.SetVScrollBar(s)

                    If MdispInquire(Me.m_AxMDisplay, M_WINDOW_PAN_X, M_NULL) > Me.HScrollBar.Maximum _
                        Or MdispInquire(Me.m_AxMDisplay, M_WINDOW_PAN_Y, M_NULL) > Me.VScrollBar.Maximum Then

                        MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Maximum, Me.VScrollBar.Maximum)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.LogDailyManager("[Dialog_CameraAlignment.ResetScrollBar][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Reset Scroll Bar Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_CameraAlignment.ResetScrollBar][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Reset Scroll Bar Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#End Region

#Region "--- 更新目前的狀態 ---"

#Region "--- Button Event ---"

#Region "--- Zoom Event ---"

#Region "--- SetButton_ZoomIn ---"
    Private Delegate Function SetButton_ZoomInCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomIn(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomIn.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomInCallback(AddressOf SetButton_ZoomIn), New Object() {En})
        Else
            Me.Button_ZoomIn.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- SetButton_ZoomOut ---"
    Private Delegate Function SetButton_ZoomOutCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomOut(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomOut.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomOutCallback(AddressOf SetButton_ZoomOut), New Object() {En})
        Else
            Me.Button_ZoomOut.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- SetButton_ZoomO ---"
    Private Delegate Function SetButton_ZoomOCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomO(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomO.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomOCallback(AddressOf SetButton_ZoomO), New Object() {En})
        Else
            Me.Button_ZoomO.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- SetButton_ZoomAll ---"
    Private Delegate Function SetButton_ZoomAllCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomAll(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomAll.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomAllCallback(AddressOf SetButton_ZoomAll), New Object() {En})
        Else
            Me.Button_ZoomAll.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#End Region

#Region "--- Grab Image Event ---"

#Region "--- SetButton_Continue ---"
    Private Delegate Function SetButton_ContinueCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Continue(ByVal En As Boolean) As Boolean
        If Me.Button_Continue.InvokeRequired Then
            Me.Invoke(New SetButton_ContinueCallback(AddressOf SetButton_Continue), New Object() {En})
        Else
            Me.Button_Continue.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- SetButton_Load ---"
    Private Delegate Function SetButton_LoadCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Load(ByVal En As Boolean) As Boolean
        If Me.Button_Load.InvokeRequired Then
            Me.Invoke(New SetButton_LoadCallback(AddressOf SetButton_Load), New Object() {En})
        Else
            Me.Button_Load.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- SetButton_Grab ---"
    Private Delegate Function SetButton_GrabCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Grab(ByVal En As Boolean) As Boolean
        If Me.Button_Grab.InvokeRequired Then
            Me.Invoke(New SetButton_GrabCallback(AddressOf SetButton_Grab), New Object() {En})
        Else
            Me.Button_Grab.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#End Region

#End Region

#Region "--- Status Event ---"

#Region "--- StatusBarXYV ---"
    Private Delegate Sub StatusBarXYVCallback(ByVal xy As String, ByVal value As String)
    Public Sub StatusBarXYV(ByVal xy As String, ByVal value As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New StatusBarXYVCallback(AddressOf StatusBarXYV), New Object() {xy, value})
        Else
            Me.StatusBarPanel_XY.Text = "(X,Y) = " & xy
            Me.StatusBarPanel_Value.Text = "亮度 = " & value
            Me.Update()
        End If
    End Sub
#End Region

#Region "--- SetStatusBarPanel_Scale ---"
    Private Delegate Sub SetStatusBarPanel_ScaleCallback(ByVal msg As String)
    Public Sub SetStatusBarPanel_Scale(ByVal msg As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New SetStatusBarPanel_ScaleCallback(AddressOf SetStatusBarPanel_Scale), New Object() {msg})
        Else
            Me.StatusBarPanel_Scale.Text = msg
            Me.Update()
        End If
    End Sub
#End Region

#Region "--- SetStatusBarPanel_Focus ---"
    Private Delegate Sub SetStatusBarPanel_FocusCallback(ByVal msg As String)
    Public Sub SetStatusBarPanel_Focus(ByVal msg As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New SetStatusBarPanel_FocusCallback(AddressOf SetStatusBarPanel_Focus), New Object() {msg})
        Else
            Me.StatusBarPanel_Focus.Text = msg
            Me.Update()
        End If
    End Sub
#End Region

#End Region

#Region "--- AxMDisplay Event ---"

#Region "--- GetAxMDisplay_HandleInfo ---"
    Delegate Function GetAxMDisplay_HandleInfoCallback() As Integer
    Public Function GetAxMDisplay_HandleInfo() As Integer
        Dim i As Integer
        If Me.m_Panel_AxMDisplay.InvokeRequired Then
            Return Me.Invoke(New GetAxMDisplay_HandleInfoCallback(AddressOf GetAxMDisplay_HandleInfo), New Object() {})
        Else
            i = Me.m_Panel_AxMDisplay.Handle
            Return i
        End If
    End Function
#End Region

#Region "--- m_Panel_AxMDisplay_MouseDownEvent ---"
    Private Sub m_Panel_AxMDisplay_MouseDownEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown

        If e.Button = Windows.Forms.MouseButtons.Left Then '滑鼠左鍵
            Me.MouseDownPage0(e)
        ElseIf e.Button = Windows.Forms.MouseButtons.Middle Then
            If Me.m_MousreHScroll Then
                Me.m_MousreHScroll = False
            Else
                Me.m_MousreHScroll = True
            End If
        ElseIf e.Button = Windows.Forms.MouseButtons.Right Then
            If Not Me.m_MousreHScroll Then
                Me.m_Panel_AxMDisplay.ContextMenuStrip = Me.ContextMenuStrip_AlignSetting
                If Me.m_ContinueGrab Then
                    Me.GrabImageToolStripMenuItem.Visible = False
                    Me.StopGrabToolStripMenuItem.Visible = True
                    Me.SaveToolStripMenuItem.Visible = False
                    Me.AlignmentToolStripMenuItem.Visible = False
                    Me.LoadImageToolStripMenuItem.Visible = False
                Else
                    Me.GrabImageToolStripMenuItem.Visible = True
                    Me.StopGrabToolStripMenuItem.Visible = False
                    Me.SaveToolStripMenuItem.Visible = True
                    Me.AlignmentToolStripMenuItem.Visible = True
                    Me.LoadImageToolStripMenuItem.Visible = True
                End If
            End If
        End If

    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseUpEvent ---"
    Private Sub m_AxMDisplay_MouseUpEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        If e.Button = Windows.Forms.MouseButtons.Left Then
            Me.m_Left = False
            Me.m_Right = False
            Me.m_Top = False
            Me.m_Bottom = False
        End If
    End Sub
#End Region

#Region "--- m_AxMDisplay_MouseMoveEvent ---"
    Private Sub m_AxMDisplay_MouseMoveEvent(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseMove
        Me.MouseMovePage0()
    End Sub
#End Region


#End Region

#Region "--- ScrollBar Event "

#Region "--- HScrollBar_Enable ---"
    Private Delegate Function HScrollBar_EnableScrollCallback(ByVal V As Boolean) As Boolean
    Public Function HScrollBar_Enable(ByVal V As Boolean) As Boolean
        If Not Me.HScrollBar Is Nothing Then
            If Me.HScrollBar.InvokeRequired Then
                Me.Invoke(New HScrollBar_EnableScrollCallback(AddressOf HScrollBar_Enable), New Object() {V})
            Else
                Me.HScrollBar.Enabled = V
                Me.Update()
            End If
        End If

        Return True
    End Function
#End Region

#Region "--- VScrollBar_Enable ---"
    Private Delegate Function VScrollBar_EnableScrollCallback(ByVal V As Boolean) As Boolean
    Public Function VScrollBar_Enable(ByVal V As Boolean) As Boolean
        If Me.VScrollBar.InvokeRequired Then
            Me.Invoke(New VScrollBar_EnableScrollCallback(AddressOf VScrollBar_Enable), New Object() {V})
        Else
            Me.VScrollBar.Enabled = V
            Me.Update()
        End If
        Return True
    End Function
#End Region

#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- GetExposureTimeInfo ---"
    Delegate Function GetExposureTimeInfoCallback() As Long
    Public Function GetExposureTimeInfo() As Long
        Dim i As Long
        If Me.NumericUpDown_ExposureTime.InvokeRequired Then
            Return Me.Invoke(New GetExposureTimeInfoCallback(AddressOf GetExposureTimeInfo), New Object() {})
        Else
            i = Me.NumericUpDown_ExposureTime.Value
            Me.Update()
            Return i
        End If
    End Function
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- GetShowBoundaryEnableInfo ---"
    Delegate Function GetShowBoundaryEnableInfoCallback() As Boolean
    Public Function GetShowBoundaryEnableInfo() As Boolean
        Dim i As Boolean
        If Me.CheckBox_ShowBoundary.InvokeRequired Then
            Return Me.Invoke(New GetShowBoundaryEnableInfoCallback(AddressOf GetShowBoundaryEnableInfo), New Object() {})
        Else
            i = Me.CheckBox_ShowBoundary.Checked
            Me.Update()
            Return i
        End If
    End Function
#End Region

#Region "--- GetShowBoundaryEnableInfo ---"
    Delegate Function GetShowROIEnableInfoCallback() As Boolean
    Public Function GetShowROIEnableInfo() As Boolean
        Dim i As Boolean
        If Me.CheckBox_ShowROI.InvokeRequired Then
            Return Me.Invoke(New GetShowBoundaryEnableInfoCallback(AddressOf GetShowROIEnableInfo), New Object() {})
        Else
            i = Me.CheckBox_ShowROI.Checked
            Me.Update()
            Return i
        End If
    End Function
#End Region

#End Region

#Region "---Mouse Event---"

#Region "--- MouseDown ---"

    Private Sub MouseDownPage0(e As System.Windows.Forms.MouseEventArgs)
        Dim p As Double
        Dim dis1 As Double
        Dim dis2 As Double
        Dim ZoomX, ZoomY As Double

        If Me.CheckBox_ShowROI.Checked Then
            'ZoomX = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)
            'ZoomY = MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, M_NULL)
            MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_Y, ZoomY)

            If ZoomX <= 0 Then ZoomX = 0.1 '2012/09/05 Rick add
            If ZoomY <= 0 Then ZoomY = 0.1 '2012/09/05 Rick add

            p = (Me.NumericUpDown_BoundaryLeft.Value - Me.HScrollBar.Value + 0.5) * ZoomX
            dis1 = Math.Abs(e.X - p)
            p = (Me.NumericUpDown_BoundaryRight.Value - Me.HScrollBar.Value + 0.5) * ZoomX
            dis2 = Math.Abs(e.X - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Left = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Right = True
                End If
            End If
            p = (Me.NumericUpDown_BoundaryTop.Value - Me.VScrollBar.Value + 0.5) * ZoomY
            dis1 = Math.Abs(e.Y - p)
            p = (Me.NumericUpDown_BoundaryBottom.Value - Me.VScrollBar.Value + 0.5) * ZoomY
            dis2 = Math.Abs(e.Y - p)
            If dis1 < dis2 Then
                If dis1 < ZoomX * 0.5 + 3 Then
                    Me.m_Top = True
                End If
            Else
                If dis2 < ZoomX * 0.5 + 3 Then
                    Me.m_Bottom = True
                End If
            End If
        End If
    End Sub

#End Region

#Region "--- MouseMove ---"

    Private Sub MouseMovePage0()
        If Me.CheckBox_ShowROI.Checked Then
            If Me.m_Left Then
                If Me.m_MouseX >= Me.NumericUpDown_BoundaryRight.Value Then
                    Me.NumericUpDown_BoundaryLeft.Value = Me.NumericUpDown_BoundaryRight.Value - 1
                Else
                    If Me.m_MouseX <= Me.NumericUpDown_BoundaryLeft.Minimum Then
                        Me.NumericUpDown_BoundaryLeft.Value = Me.NumericUpDown_BoundaryLeft.Minimum
                    Else
                        Me.NumericUpDown_BoundaryLeft.Value = Me.m_MouseX
                    End If
                End If
            End If

            If Me.m_Right Then
                If Me.m_MouseX <= Me.NumericUpDown_BoundaryLeft.Value Then
                    Me.NumericUpDown_BoundaryRight.Value = Me.NumericUpDown_BoundaryLeft.Value + 1
                Else
                    If Me.m_MouseX >= Me.NumericUpDown_BoundaryRight.Maximum Then
                        Me.NumericUpDown_BoundaryRight.Value = Me.NumericUpDown_BoundaryRight.Maximum - 1
                    Else
                        Me.NumericUpDown_BoundaryRight.Value = Me.m_MouseX
                    End If
                End If
            End If

            If Me.m_Top Then
                If Me.m_MouseY >= Me.NumericUpDown_BoundaryBottom.Value Then
                    Me.NumericUpDown_BoundaryTop.Value = Me.NumericUpDown_BoundaryBottom.Value - 1
                Else
                    If Me.m_MouseY <= Me.NumericUpDown_BoundaryTop.Minimum Then
                        Me.NumericUpDown_BoundaryTop.Value = Me.NumericUpDown_BoundaryTop.Minimum
                    Else
                        Me.NumericUpDown_BoundaryTop.Value = Me.m_MouseY
                    End If
                End If
            End If

            If Me.m_Bottom Then
                If Me.m_MouseY <= Me.NumericUpDown_BoundaryTop.Value Then
                    Me.NumericUpDown_BoundaryBottom.Value = Me.NumericUpDown_BoundaryTop.Value + 1
                Else
                    If Me.m_MouseY >= Me.NumericUpDown_BoundaryBottom.Maximum Then
                        Me.NumericUpDown_BoundaryBottom.Value = Me.NumericUpDown_BoundaryBottom.Maximum - 1
                    Else
                        Me.NumericUpDown_BoundaryBottom.Value = Me.m_MouseY
                    End If
                End If
            End If
            If Me.m_Left Or Me.m_Right Or Me.m_Top Or Me.m_Bottom Then
                Me.Refresh()
            End If
        End If
    End Sub

#End Region

#End Region

#End Region

#Region "---ContextMenu---"

    Private Sub ContextMenuStrip_AlignSetting_ItemClicked(sender As Object, e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ContextMenuStrip_AlignSetting.ItemClicked

        If e.ClickedItem Is LoadImageToolStripMenuItem Then
            Me.Button_Load.PerformClick()
        ElseIf e.ClickedItem Is ShowROIToolStripMenuItem Then
            If Me.CheckBox_ShowROI.Checked = True Then
                Me.CheckBox_ShowROI.Checked = False
            Else
                Me.CheckBox_ShowROI.Checked = True
            End If
        ElseIf e.ClickedItem Is AlignmentToolStripMenuItem Then
            Me.Button_Alignment.PerformClick()
        ElseIf e.ClickedItem Is SaveToolStripMenuItem Then
            Me.Button_SaveAlignmentRecipe.PerformClick()
        ElseIf e.ClickedItem Is GrabImageToolStripMenuItem Then
            Me.Button_Continue.PerformClick()
        ElseIf e.ClickedItem Is StopGrabToolStripMenuItem Then
            Me.Button_Grab.PerformClick()
        End If

    End Sub

#End Region


    Delegate Sub SetHScrollBarMaxCallback(ByVal index As Integer)
    Public Sub SetHScrollBar(ByVal index As Integer)
        If Me.HScrollBar.InvokeRequired Then
            Me.Invoke(New SetHScrollBarMaxCallback(AddressOf SetHScrollBar), New Object() {index})
        Else
            Me.HScrollBar.Maximum = index
        End If
    End Sub

    Delegate Sub SetVScrollBarMaxCallback(ByVal index As Integer)
    Public Sub SetVScrollBar(ByVal index As Integer)
        If Me.VScrollBar.InvokeRequired Then
            Me.Invoke(New SetVScrollBarMaxCallback(AddressOf SetVScrollBar), New Object() {index})
        Else
            Me.VScrollBar.Maximum = index
        End If
    End Sub


End Class