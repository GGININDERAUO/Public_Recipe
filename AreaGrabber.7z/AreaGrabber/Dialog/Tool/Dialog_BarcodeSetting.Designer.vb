﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_BarcodeSetting
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button_LoadImage = New System.Windows.Forms.Button()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.GroupBox_BoundaryModify = New System.Windows.Forms.GroupBox()
        Me.RadioButton_BoundaryManual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BoundaryFinish = New System.Windows.Forms.RadioButton()
        Me.CheckBox_ShowBoundary = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Boundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BoundaryRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryTop = New System.Windows.Forms.Label()
        Me.Button_BarcodeReader = New System.Windows.Forms.Button()
        Me.GroupBox_BarcodeColor = New System.Windows.Forms.GroupBox()
        Me.RadioButton_BarcodeColor_White = New System.Windows.Forms.RadioButton()
        Me.RadioButton_BarcodeColor_Black = New System.Windows.Forms.RadioButton()
        Me.CheckBox_SaveBarcodeImage = New System.Windows.Forms.CheckBox()
        Me.GroupBox_BarcodeEnableSetting = New System.Windows.Forms.GroupBox()
        Me.GroupBox_BarcodeProcessSetting = New System.Windows.Forms.GroupBox()
        Me.RadioButton_Close = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Bin = New System.Windows.Forms.RadioButton()
        Me.RadioButton_PreImgProc = New System.Windows.Forms.RadioButton()
        Me.Panel_AxMDisplay_Barcode = New System.Windows.Forms.Panel()
        Me.NumericUpDown_BarcodeImageCloseNum = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_BarcodeThresholdValue = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.CheckBox_BarcodeAutoThreshold = New System.Windows.Forms.CheckBox()
        Me.CheckBox_BarcodeMirror = New System.Windows.Forms.CheckBox()
        Me.StatusBar = New System.Windows.Forms.StatusBar()
        Me.StatusBarPanel_XY = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Value = New System.Windows.Forms.StatusBarPanel()
        Me.GroupBox_BoundaryModify.SuspendLayout()
        Me.GroupBox_Boundary.SuspendLayout()
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_BarcodeColor.SuspendLayout()
        Me.GroupBox_BarcodeEnableSetting.SuspendLayout()
        Me.GroupBox_BarcodeProcessSetting.SuspendLayout()
        CType(Me.NumericUpDown_BarcodeImageCloseNum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BarcodeThresholdValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_XY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Value, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button_LoadImage
        '
        Me.Button_LoadImage.Location = New System.Drawing.Point(290, 453)
        Me.Button_LoadImage.Name = "Button_LoadImage"
        Me.Button_LoadImage.Size = New System.Drawing.Size(75, 23)
        Me.Button_LoadImage.TabIndex = 54
        Me.Button_LoadImage.Text = "Load Image"
        Me.Button_LoadImage.UseVisualStyleBackColor = True
        '
        'Button_Save
        '
        Me.Button_Save.Location = New System.Drawing.Point(9, 453)
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.Size = New System.Drawing.Size(64, 23)
        Me.Button_Save.TabIndex = 55
        Me.Button_Save.Text = "Save"
        '
        'Button_Close
        '
        Me.Button_Close.Location = New System.Drawing.Point(220, 453)
        Me.Button_Close.Name = "Button_Close"
        Me.Button_Close.Size = New System.Drawing.Size(65, 23)
        Me.Button_Close.TabIndex = 56
        Me.Button_Close.Text = "Close"
        Me.Button_Close.UseVisualStyleBackColor = True
        '
        'GroupBox_BoundaryModify
        '
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryManual)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.RadioButton_BoundaryFinish)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.CheckBox_ShowBoundary)
        Me.GroupBox_BoundaryModify.Controls.Add(Me.GroupBox_Boundary)
        Me.GroupBox_BoundaryModify.Location = New System.Drawing.Point(9, 62)
        Me.GroupBox_BoundaryModify.Name = "GroupBox_BoundaryModify"
        Me.GroupBox_BoundaryModify.Size = New System.Drawing.Size(356, 131)
        Me.GroupBox_BoundaryModify.TabIndex = 57
        Me.GroupBox_BoundaryModify.TabStop = False
        Me.GroupBox_BoundaryModify.Text = "可視區分析參數調整"
        '
        'RadioButton_BoundaryManual
        '
        Me.RadioButton_BoundaryManual.Location = New System.Drawing.Point(135, 11)
        Me.RadioButton_BoundaryManual.Name = "RadioButton_BoundaryManual"
        Me.RadioButton_BoundaryManual.Size = New System.Drawing.Size(72, 36)
        Me.RadioButton_BoundaryManual.TabIndex = 14
        Me.RadioButton_BoundaryManual.Text = "手動設定  (Adjust)"
        '
        'RadioButton_BoundaryFinish
        '
        Me.RadioButton_BoundaryFinish.Location = New System.Drawing.Point(47, 11)
        Me.RadioButton_BoundaryFinish.Name = "RadioButton_BoundaryFinish"
        Me.RadioButton_BoundaryFinish.Size = New System.Drawing.Size(72, 36)
        Me.RadioButton_BoundaryFinish.TabIndex = 12
        Me.RadioButton_BoundaryFinish.Text = "完成設定    (Finsh)"
        '
        'CheckBox_ShowBoundary
        '
        Me.CheckBox_ShowBoundary.Location = New System.Drawing.Point(221, 17)
        Me.CheckBox_ShowBoundary.Name = "CheckBox_ShowBoundary"
        Me.CheckBox_ShowBoundary.Size = New System.Drawing.Size(83, 24)
        Me.CheckBox_ShowBoundary.TabIndex = 15
        Me.CheckBox_ShowBoundary.Text = "顯示(Show)"
        '
        'GroupBox_Boundary
        '
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryTop)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryTop)
        Me.GroupBox_Boundary.Enabled = False
        Me.GroupBox_Boundary.Location = New System.Drawing.Point(19, 48)
        Me.GroupBox_Boundary.Name = "GroupBox_Boundary"
        Me.GroupBox_Boundary.Size = New System.Drawing.Size(307, 75)
        Me.GroupBox_Boundary.TabIndex = 13
        Me.GroupBox_Boundary.TabStop = False
        Me.GroupBox_Boundary.Text = "分析參數"
        '
        'NumericUpDown_BoundaryRight
        '
        Me.NumericUpDown_BoundaryRight.Location = New System.Drawing.Point(229, 43)
        Me.NumericUpDown_BoundaryRight.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryRight.Name = "NumericUpDown_BoundaryRight"
        Me.NumericUpDown_BoundaryRight.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_BoundaryRight.TabIndex = 8
        Me.NumericUpDown_BoundaryRight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryRight
        '
        Me.Label_BoundaryRight.Location = New System.Drawing.Point(181, 43)
        Me.Label_BoundaryRight.Name = "Label_BoundaryRight"
        Me.Label_BoundaryRight.Size = New System.Drawing.Size(48, 23)
        Me.Label_BoundaryRight.TabIndex = 7
        Me.Label_BoundaryRight.Text = "右邊界 :"
        Me.Label_BoundaryRight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BoundaryLeft
        '
        Me.NumericUpDown_BoundaryLeft.Location = New System.Drawing.Point(78, 43)
        Me.NumericUpDown_BoundaryLeft.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BoundaryLeft.Name = "NumericUpDown_BoundaryLeft"
        Me.NumericUpDown_BoundaryLeft.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_BoundaryLeft.TabIndex = 6
        Me.NumericUpDown_BoundaryLeft.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryLeft
        '
        Me.Label_BoundaryLeft.Location = New System.Drawing.Point(30, 43)
        Me.Label_BoundaryLeft.Name = "Label_BoundaryLeft"
        Me.Label_BoundaryLeft.Size = New System.Drawing.Size(48, 23)
        Me.Label_BoundaryLeft.TabIndex = 5
        Me.Label_BoundaryLeft.Text = "左邊界 :"
        Me.Label_BoundaryLeft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BoundaryTop
        '
        Me.NumericUpDown_BoundaryTop.Location = New System.Drawing.Point(78, 19)
        Me.NumericUpDown_BoundaryTop.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_BoundaryTop.Name = "NumericUpDown_BoundaryTop"
        Me.NumericUpDown_BoundaryTop.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_BoundaryTop.TabIndex = 2
        Me.NumericUpDown_BoundaryTop.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryBottom
        '
        Me.Label_BoundaryBottom.Location = New System.Drawing.Point(181, 19)
        Me.Label_BoundaryBottom.Name = "Label_BoundaryBottom"
        Me.Label_BoundaryBottom.Size = New System.Drawing.Size(48, 23)
        Me.Label_BoundaryBottom.TabIndex = 3
        Me.Label_BoundaryBottom.Text = "下邊界 :"
        Me.Label_BoundaryBottom.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_BoundaryBottom
        '
        Me.NumericUpDown_BoundaryBottom.Location = New System.Drawing.Point(229, 19)
        Me.NumericUpDown_BoundaryBottom.Maximum = New Decimal(New Integer() {5000, 0, 0, 0})
        Me.NumericUpDown_BoundaryBottom.Name = "NumericUpDown_BoundaryBottom"
        Me.NumericUpDown_BoundaryBottom.Size = New System.Drawing.Size(56, 22)
        Me.NumericUpDown_BoundaryBottom.TabIndex = 4
        Me.NumericUpDown_BoundaryBottom.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_BoundaryTop
        '
        Me.Label_BoundaryTop.Location = New System.Drawing.Point(30, 19)
        Me.Label_BoundaryTop.Name = "Label_BoundaryTop"
        Me.Label_BoundaryTop.Size = New System.Drawing.Size(48, 23)
        Me.Label_BoundaryTop.TabIndex = 1
        Me.Label_BoundaryTop.Text = "上邊界 :"
        Me.Label_BoundaryTop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button_BarcodeReader
        '
        Me.Button_BarcodeReader.Location = New System.Drawing.Point(9, 415)
        Me.Button_BarcodeReader.Name = "Button_BarcodeReader"
        Me.Button_BarcodeReader.Size = New System.Drawing.Size(110, 23)
        Me.Button_BarcodeReader.TabIndex = 83
        Me.Button_BarcodeReader.Text = "Barcode Reader"
        Me.Button_BarcodeReader.UseVisualStyleBackColor = True
        '
        'GroupBox_BarcodeColor
        '
        Me.GroupBox_BarcodeColor.Controls.Add(Me.RadioButton_BarcodeColor_White)
        Me.GroupBox_BarcodeColor.Controls.Add(Me.RadioButton_BarcodeColor_Black)
        Me.GroupBox_BarcodeColor.Location = New System.Drawing.Point(9, 12)
        Me.GroupBox_BarcodeColor.Name = "GroupBox_BarcodeColor"
        Me.GroupBox_BarcodeColor.Size = New System.Drawing.Size(356, 44)
        Me.GroupBox_BarcodeColor.TabIndex = 84
        Me.GroupBox_BarcodeColor.TabStop = False
        Me.GroupBox_BarcodeColor.Text = "Barcode Color"
        '
        'RadioButton_BarcodeColor_White
        '
        Me.RadioButton_BarcodeColor_White.AutoSize = True
        Me.RadioButton_BarcodeColor_White.Location = New System.Drawing.Point(192, 16)
        Me.RadioButton_BarcodeColor_White.Name = "RadioButton_BarcodeColor_White"
        Me.RadioButton_BarcodeColor_White.Size = New System.Drawing.Size(51, 16)
        Me.RadioButton_BarcodeColor_White.TabIndex = 53
        Me.RadioButton_BarcodeColor_White.Text = "White"
        Me.RadioButton_BarcodeColor_White.UseVisualStyleBackColor = True
        '
        'RadioButton_BarcodeColor_Black
        '
        Me.RadioButton_BarcodeColor_Black.AutoSize = True
        Me.RadioButton_BarcodeColor_Black.Checked = True
        Me.RadioButton_BarcodeColor_Black.Location = New System.Drawing.Point(103, 16)
        Me.RadioButton_BarcodeColor_Black.Name = "RadioButton_BarcodeColor_Black"
        Me.RadioButton_BarcodeColor_Black.Size = New System.Drawing.Size(50, 16)
        Me.RadioButton_BarcodeColor_Black.TabIndex = 53
        Me.RadioButton_BarcodeColor_Black.TabStop = True
        Me.RadioButton_BarcodeColor_Black.Text = "Black"
        Me.RadioButton_BarcodeColor_Black.UseVisualStyleBackColor = True
        '
        'CheckBox_SaveBarcodeImage
        '
        Me.CheckBox_SaveBarcodeImage.AutoSize = True
        Me.CheckBox_SaveBarcodeImage.Location = New System.Drawing.Point(22, 18)
        Me.CheckBox_SaveBarcodeImage.Name = "CheckBox_SaveBarcodeImage"
        Me.CheckBox_SaveBarcodeImage.Size = New System.Drawing.Size(120, 16)
        Me.CheckBox_SaveBarcodeImage.TabIndex = 85
        Me.CheckBox_SaveBarcodeImage.Text = "Save Barcode Image"
        Me.CheckBox_SaveBarcodeImage.UseVisualStyleBackColor = True
        '
        'GroupBox_BarcodeEnableSetting
        '
        Me.GroupBox_BarcodeEnableSetting.Controls.Add(Me.CheckBox_SaveBarcodeImage)
        Me.GroupBox_BarcodeEnableSetting.Location = New System.Drawing.Point(162, 405)
        Me.GroupBox_BarcodeEnableSetting.Name = "GroupBox_BarcodeEnableSetting"
        Me.GroupBox_BarcodeEnableSetting.Size = New System.Drawing.Size(203, 44)
        Me.GroupBox_BarcodeEnableSetting.TabIndex = 86
        Me.GroupBox_BarcodeEnableSetting.TabStop = False
        Me.GroupBox_BarcodeEnableSetting.Text = "Barcode Enable Setting"
        '
        'GroupBox_BarcodeProcessSetting
        '
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.RadioButton_Close)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.RadioButton_Bin)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.RadioButton_PreImgProc)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.Panel_AxMDisplay_Barcode)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.NumericUpDown_BarcodeImageCloseNum)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.Label2)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.NumericUpDown_BarcodeThresholdValue)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.Label1)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.CheckBox_BarcodeAutoThreshold)
        Me.GroupBox_BarcodeProcessSetting.Controls.Add(Me.CheckBox_BarcodeMirror)
        Me.GroupBox_BarcodeProcessSetting.Location = New System.Drawing.Point(9, 199)
        Me.GroupBox_BarcodeProcessSetting.Name = "GroupBox_BarcodeProcessSetting"
        Me.GroupBox_BarcodeProcessSetting.Size = New System.Drawing.Size(356, 200)
        Me.GroupBox_BarcodeProcessSetting.TabIndex = 86
        Me.GroupBox_BarcodeProcessSetting.TabStop = False
        Me.GroupBox_BarcodeProcessSetting.Text = "Barcode Process Setting"
        '
        'RadioButton_Close
        '
        Me.RadioButton_Close.AutoSize = True
        Me.RadioButton_Close.Location = New System.Drawing.Point(284, 11)
        Me.RadioButton_Close.Name = "RadioButton_Close"
        Me.RadioButton_Close.Size = New System.Drawing.Size(49, 16)
        Me.RadioButton_Close.TabIndex = 93
        Me.RadioButton_Close.Text = "Close"
        Me.RadioButton_Close.UseVisualStyleBackColor = True
        '
        'RadioButton_Bin
        '
        Me.RadioButton_Bin.AutoSize = True
        Me.RadioButton_Bin.Location = New System.Drawing.Point(238, 11)
        Me.RadioButton_Bin.Name = "RadioButton_Bin"
        Me.RadioButton_Bin.Size = New System.Drawing.Size(40, 16)
        Me.RadioButton_Bin.TabIndex = 92
        Me.RadioButton_Bin.Text = "Bin"
        Me.RadioButton_Bin.UseVisualStyleBackColor = True
        '
        'RadioButton_PreImgProc
        '
        Me.RadioButton_PreImgProc.AutoSize = True
        Me.RadioButton_PreImgProc.Checked = True
        Me.RadioButton_PreImgProc.Location = New System.Drawing.Point(155, 11)
        Me.RadioButton_PreImgProc.Name = "RadioButton_PreImgProc"
        Me.RadioButton_PreImgProc.Size = New System.Drawing.Size(78, 16)
        Me.RadioButton_PreImgProc.TabIndex = 54
        Me.RadioButton_PreImgProc.TabStop = True
        Me.RadioButton_PreImgProc.Text = "PreImgProc"
        Me.RadioButton_PreImgProc.UseVisualStyleBackColor = True
        '
        'Panel_AxMDisplay_Barcode
        '
        Me.Panel_AxMDisplay_Barcode.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel_AxMDisplay_Barcode.Location = New System.Drawing.Point(140, 33)
        Me.Panel_AxMDisplay_Barcode.Name = "Panel_AxMDisplay_Barcode"
        Me.Panel_AxMDisplay_Barcode.Size = New System.Drawing.Size(210, 161)
        Me.Panel_AxMDisplay_Barcode.TabIndex = 91
        '
        'NumericUpDown_BarcodeImageCloseNum
        '
        Me.NumericUpDown_BarcodeImageCloseNum.Location = New System.Drawing.Point(73, 128)
        Me.NumericUpDown_BarcodeImageCloseNum.Name = "NumericUpDown_BarcodeImageCloseNum"
        Me.NumericUpDown_BarcodeImageCloseNum.Size = New System.Drawing.Size(59, 22)
        Me.NumericUpDown_BarcodeImageCloseNum.TabIndex = 90
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 133)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 12)
        Me.Label2.TabIndex = 89
        Me.Label2.Text = "Close Num:"
        '
        'NumericUpDown_BarcodeThresholdValue
        '
        Me.NumericUpDown_BarcodeThresholdValue.Location = New System.Drawing.Point(73, 95)
        Me.NumericUpDown_BarcodeThresholdValue.Maximum = New Decimal(New Integer() {65535, 0, 0, 0})
        Me.NumericUpDown_BarcodeThresholdValue.Name = "NumericUpDown_BarcodeThresholdValue"
        Me.NumericUpDown_BarcodeThresholdValue.Size = New System.Drawing.Size(59, 22)
        Me.NumericUpDown_BarcodeThresholdValue.TabIndex = 88
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 100)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(55, 12)
        Me.Label1.TabIndex = 87
        Me.Label1.Text = "Threshold:"
        '
        'CheckBox_BarcodeAutoThreshold
        '
        Me.CheckBox_BarcodeAutoThreshold.AutoSize = True
        Me.CheckBox_BarcodeAutoThreshold.Location = New System.Drawing.Point(11, 67)
        Me.CheckBox_BarcodeAutoThreshold.Name = "CheckBox_BarcodeAutoThreshold"
        Me.CheckBox_BarcodeAutoThreshold.Size = New System.Drawing.Size(97, 16)
        Me.CheckBox_BarcodeAutoThreshold.TabIndex = 86
        Me.CheckBox_BarcodeAutoThreshold.Text = "Auto Threshold"
        Me.CheckBox_BarcodeAutoThreshold.UseVisualStyleBackColor = True
        '
        'CheckBox_BarcodeMirror
        '
        Me.CheckBox_BarcodeMirror.AutoSize = True
        Me.CheckBox_BarcodeMirror.Location = New System.Drawing.Point(11, 39)
        Me.CheckBox_BarcodeMirror.Name = "CheckBox_BarcodeMirror"
        Me.CheckBox_BarcodeMirror.Size = New System.Drawing.Size(97, 16)
        Me.CheckBox_BarcodeMirror.TabIndex = 85
        Me.CheckBox_BarcodeMirror.Text = "Barcode Mirror"
        Me.CheckBox_BarcodeMirror.UseVisualStyleBackColor = True
        '
        'StatusBar
        '
        Me.StatusBar.Location = New System.Drawing.Point(0, 487)
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel_XY, Me.StatusBarPanel_Value})
        Me.StatusBar.ShowPanels = True
        Me.StatusBar.Size = New System.Drawing.Size(377, 22)
        Me.StatusBar.TabIndex = 87
        Me.StatusBar.Text = "StatusBar1"
        '
        'StatusBarPanel_XY
        '
        Me.StatusBarPanel_XY.Name = "StatusBarPanel_XY"
        Me.StatusBarPanel_XY.Text = "(X,Y) = NULL"
        '
        'StatusBarPanel_Value
        '
        Me.StatusBarPanel_Value.Name = "StatusBarPanel_Value"
        Me.StatusBarPanel_Value.Text = "亮度 = NULL"
        Me.StatusBarPanel_Value.Width = 120
        '
        'Dialog_BarcodeSetting
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(377, 509)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.GroupBox_BarcodeProcessSetting)
        Me.Controls.Add(Me.GroupBox_BarcodeEnableSetting)
        Me.Controls.Add(Me.GroupBox_BarcodeColor)
        Me.Controls.Add(Me.Button_BarcodeReader)
        Me.Controls.Add(Me.GroupBox_BoundaryModify)
        Me.Controls.Add(Me.Button_Close)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.Button_LoadImage)
        Me.Name = "Dialog_BarcodeSetting"
        Me.Text = "Barcode參數調整"
        Me.GroupBox_BoundaryModify.ResumeLayout(False)
        Me.GroupBox_Boundary.ResumeLayout(False)
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_BarcodeColor.ResumeLayout(False)
        Me.GroupBox_BarcodeColor.PerformLayout()
        Me.GroupBox_BarcodeEnableSetting.ResumeLayout(False)
        Me.GroupBox_BarcodeEnableSetting.PerformLayout()
        Me.GroupBox_BarcodeProcessSetting.ResumeLayout(False)
        Me.GroupBox_BarcodeProcessSetting.PerformLayout()
        CType(Me.NumericUpDown_BarcodeImageCloseNum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BarcodeThresholdValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_XY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Value, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button_LoadImage As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents GroupBox_BoundaryModify As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BoundaryManual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BoundaryFinish As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_ShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Boundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BoundaryRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryTop As System.Windows.Forms.Label
    Friend WithEvents Button_BarcodeReader As System.Windows.Forms.Button
    Friend WithEvents GroupBox_BarcodeColor As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton_BarcodeColor_White As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_BarcodeColor_Black As System.Windows.Forms.RadioButton
    Friend WithEvents CheckBox_SaveBarcodeImage As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_BarcodeEnableSetting As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_BarcodeProcessSetting As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_BarcodeMirror As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_BarcodeAutoThreshold As System.Windows.Forms.CheckBox
    Friend WithEvents NumericUpDown_BarcodeThresholdValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BarcodeImageCloseNum As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Panel_AxMDisplay_Barcode As System.Windows.Forms.Panel
    Friend WithEvents RadioButton_PreImgProc As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Close As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Bin As System.Windows.Forms.RadioButton
    Friend WithEvents StatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents StatusBarPanel_XY As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_Value As System.Windows.Forms.StatusBarPanel
End Class
