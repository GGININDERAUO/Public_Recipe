﻿Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl
Imports System.IO
Public Class Dialog_RMSSetting
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_Size As Integer
    Private m_AxMDisplay As MIL_ID

    '--- 連線參數 ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '--- UI ---
    Private WithEvents m_VScrollBar As System.Windows.Forms.VScrollBar
    Private WithEvents m_HScrollBar As System.Windows.Forms.HScrollBar
    Private WithEvents m_Button_ZoomIn As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomOut As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomO As System.Windows.Forms.Button
    Private WithEvents m_Button_ZoomAll As System.Windows.Forms.Button
    Private WithEvents m_ZoomContextMenuStrip As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents m_ZoomInToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomOutToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_OriginToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents m_ZoomAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem


    Public Sub SetMainForm(ByVal form As Main_Form)
        Dim image As MIL_ID = M_NULL
        Try
            Me.m_Form = form
            Me.m_MainProcess = form.MainProcess
            Me.m_FuncProcess = form.MainProcess.FuncProcess
            Me.m_MuraProcess = form.MainProcess.MuraProcess
            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            Else
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            End If

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
            Me.m_AxMDisplay = Me.m_Form.AxMDisplay
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)
            Me.m_Pen = New Pen(Color.White)
            Me.m_Form.PaintStop = True

            image = Me.m_FuncProcess.Img_Original_NonPage
            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If

            Me.m_Form.ImageZoomAll()   '09/26 Rick add
            Me.UpdateUserLevel() '5/14 add

            Me.RadioButton_MeanRegionFunc.Checked = True
            If Not Me.m_IPBootConfig.MuraUI.Value Then Me.RadioButton_MeanRegionMura.Enabled = False '10/27 Rick add
            Me.UpdateData()

            Me.ComboBox_MeanRegionPattern.Items.Clear()
            For i = 0 To Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value - 1
                Me.ComboBox_MeanRegionPattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_MeanRegionPattern.SelectedIndex = 0

            '--- UI ---
            Me.m_VScrollBar = Me.m_Form.VScrollBar
            Me.m_HScrollBar = Me.m_Form.HScrollBar

            Me.m_Button_ZoomIn = Me.m_Form.Button_ZoomIn
            Me.m_Button_ZoomOut = Me.m_Form.Button_ZoomOut
            Me.m_Button_ZoomO = Me.m_Form.Button_ZoomO
            Me.m_Button_ZoomAll = Me.m_Form.Button_ZoomAll
            Me.m_ZoomContextMenuStrip = Me.m_Form.ZoomContextMenuStrip
            Me.m_ZoomInToolStripMenuItem = Me.m_Form.ZoomInToolStripMenuItem
            Me.m_ZoomOutToolStripMenuItem = Me.m_Form.ZoomOutToolStripMenuItem
            Me.m_OriginToolStripMenuItem = Me.m_Form.OriginToolStripMenuItem
            Me.m_ZoomAllToolStripMenuItem = Me.m_Form.ZoomAllToolStripMenuItem

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_RMSSetting.SetMainForm]" & ex.Message)
        End Try
    End Sub

    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_Setting.Enabled = False
            Case 1 'PM
                Me.GroupBox_Setting.Enabled = True
            Case 2 'ENG
                Me.GroupBox_Setting.Enabled = True
            Case 3 'ALL
                Me.GroupBox_Setting.Enabled = True
        End Select
    End Sub

    Private Sub UpdateData()
        Dim fpr As ClsFuncPatternRecipe
        Dim mpr As ClsMuraPatternRecipe
        fpr = m_FuncProcess.CurrentFuncPatternRecipe
        mpr = m_MuraProcess.CurrentMuraPatternRecipe
        Me.ListView_MeanRegion.Items.Clear()
        If Me.RadioButton_MeanRegionFunc.Checked Then
            If fpr.MeanUploadArea1.Pattern <> "ALL" Then
                Me.ListView_MeanRegion.Items.Add(fpr.MeanUploadArea1.LeftX)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(fpr.MeanUploadArea1.TopY)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(fpr.MeanUploadArea1.RightX)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(fpr.MeanUploadArea1.BottomY)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(fpr.MeanUploadArea1.Pattern)
            End If

            If fpr.MeanUploadArea2.Pattern <> "ALL" Then
                Me.ListView_MeanRegion.Items.Add(fpr.MeanUploadArea2.LeftX)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(fpr.MeanUploadArea2.TopY)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(fpr.MeanUploadArea2.RightX)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(fpr.MeanUploadArea2.BottomY)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(fpr.MeanUploadArea2.Pattern)
            End If

            If fpr.MeanUploadArea3.Pattern <> "ALL" Then
                Me.ListView_MeanRegion.Items.Add(fpr.MeanUploadArea3.LeftX)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(fpr.MeanUploadArea3.TopY)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(fpr.MeanUploadArea3.RightX)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(fpr.MeanUploadArea3.BottomY)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(fpr.MeanUploadArea3.Pattern)
            End If
        Else
            If mpr.MeanUploadArea1.Pattern <> "ALL" Then
                Me.ListView_MeanRegion.Items.Add(mpr.MeanUploadArea1.LeftX)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(mpr.MeanUploadArea1.TopY)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(mpr.MeanUploadArea1.RightX)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(mpr.MeanUploadArea1.BottomY)
                Me.ListView_MeanRegion.Items(0).SubItems.Add(mpr.MeanUploadArea1.Pattern)
            End If

            If mpr.MeanUploadArea2.Pattern <> "ALL" Then
                Me.ListView_MeanRegion.Items.Add(mpr.MeanUploadArea2.LeftX)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(mpr.MeanUploadArea2.TopY)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(mpr.MeanUploadArea2.RightX)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(mpr.MeanUploadArea2.BottomY)
                Me.ListView_MeanRegion.Items(1).SubItems.Add(mpr.MeanUploadArea2.Pattern)
            End If

            If mpr.MeanUploadArea3.Pattern <> "ALL" Then
                Me.ListView_MeanRegion.Items.Add(mpr.MeanUploadArea3.LeftX)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(mpr.MeanUploadArea3.TopY)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(mpr.MeanUploadArea3.RightX)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(mpr.MeanUploadArea3.BottomY)
                Me.ListView_MeanRegion.Items(2).SubItems.Add(mpr.MeanUploadArea3.Pattern)
            End If
        End If

        Me.NumericUpDown_TotalRegion.Value = Me.ListView_MeanRegion.Items.Count

    End Sub

#Region "---RadioButton---"

    Private Sub RadioButton_Func_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_MeanRegionFunc.CheckedChanged
        Dim i As Integer
        Dim PatternName As String
        Dim Parameter_Lists As String = ""

        Me.ComboBox_MeanRegionPattern.Items.Clear()
        If Me.RadioButton_MeanRegionFunc.Checked = True Then
            Me.CheckBox_MeanRegionShow.Checked = False
            Me.CheckBox_MeanRegionMannual.Checked = False
            For i = 0 To Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value - 1
                Me.ComboBox_MeanRegionPattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_MeanRegionPattern.SelectedIndex = 0
            Try
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_MeanRegionPattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count
                Me.UpdateData()
                Me.UpdateUserLevel()
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message)
                MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 300000 '300 secs

                '--- PatternName ---
                PatternName = Me.ComboBox_MeanRegionPattern.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        End If
    End Sub

    Private Sub RadioButton_Mura_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_MeanRegionMura.CheckedChanged
        Dim i As Integer
        Dim PatternName As String
        Me.ComboBox_MeanRegionPattern.Items.Clear()
        If Me.RadioButton_MeanRegionMura.Checked = True Then
            Me.CheckBox_MeanRegionShow.Checked = False
            Me.CheckBox_MeanRegionMannual.Checked = False
            For i = 0 To Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1
                Me.ComboBox_MeanRegionPattern.Items.Add(Me.m_Form.MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next
            Me.ComboBox_MeanRegionPattern.SelectedIndex = 0
            Try
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_MeanRegionPattern.SelectedIndex
                Me.UpdateData()
                Me.UpdateUserLevel()
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message)
                MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 300000 '300 secs

                '--- PatternName ---
                PatternName = Me.ComboBox_MeanRegionPattern.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        End If
    End Sub

#End Region

#Region "---ComboBox---"

    Private Sub ComboBox_Pattern_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox_MeanRegionPattern.SelectedIndexChanged
        Dim PatternName As String
        Me.CheckBox_MeanRegionShow.Checked = False
        Me.CheckBox_MeanRegionMannual.Checked = False

        If Me.RadioButton_MeanRegionFunc.Checked Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_MeanRegionPattern.SelectedIndex + Me.m_MuraProcess.MuraPatternRecipeArray.Count
        Else
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.ComboBox_MeanRegionPattern.SelectedIndex
        End If

        Try
            Me.UpdateData()
            Me.UpdateUserLevel()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message)
            MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 300000 '300 secs

            '--- PatternName ---
            PatternName = Me.ComboBox_MeanRegionPattern.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
        Me.UpdateData()
    End Sub

#End Region

#Region "---Button---"

    Private Sub Button_ClearAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MeanRegionClearAll.Click
        Dim fpr As ClsFuncPatternRecipe
        Dim mpr As ClsMuraPatternRecipe
        Dim dir As String
        fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
        mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
        Me.ListView_MeanRegion.Items.Clear()
        If Me.RadioButton_MeanRegionFunc.Checked Then
            dir = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_IPBootConfig.CCD.Value & "\" & Me.m_Form.TextBox_Product.Text & "\Func" & "\FuncPatternRecipe_C" & Me.m_IPBootConfig.GrabNo.Value & "_P" & Me.ComboBox_MeanRegionPattern.SelectedIndex + 1 & ".xml"
            fpr.MeanUploadArea1 = New ClsParameterBoundary
            fpr.MeanUploadArea2 = New ClsParameterBoundary
            fpr.MeanUploadArea3 = New ClsParameterBoundary
            Me.m_FuncProcess.SaveCurrentFuncPatternRecipe(dir, 0)
        Else
            dir = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_IPBootConfig.CCD.Value & "\" & Me.m_Form.TextBox_Product.Text & "\Mura" & "\MuraPatternRecipe_C" & Me.m_IPBootConfig.GrabNo.Value & "_P" & Me.ComboBox_MeanRegionPattern.SelectedIndex + 1 & ".xml"
            mpr.MeanUploadArea1 = New ClsParameterBoundary
            mpr.MeanUploadArea2 = New ClsParameterBoundary
            mpr.MeanUploadArea3 = New ClsParameterBoundary
            Me.m_Form.MuraProcess.SaveCurrentMuraPatternRecipe(dir, 0)
        End If
        Me.NumericUpDown_TotalRegion.Value = 0
        Me.m_Form.PaintStop = True
        Me.DrawMark()
    End Sub

    Private Sub Button_Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MeanRegionCancel.Click
        Me.Close()
    End Sub

    Private Sub Button_MeanRegionSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MeanRegionSave.Click
        Dim fpr As ClsFuncPatternRecipe
        Dim mpr As ClsMuraPatternRecipe
        Dim dir As String
        fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
        mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
        If Me.RadioButton_MeanRegionFunc.Checked Then
            dir = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_IPBootConfig.CCD.Value & "\" & Me.m_Form.TextBox_Product.Text & "\Func" & "\FuncPatternRecipe_C" & Me.m_IPBootConfig.GrabNo.Value & "_P" & Me.ComboBox_MeanRegionPattern.SelectedIndex + 1 & ".xml"
            If NumericUpDown_TotalRegion.Value = 1 Then
                fpr.MeanUploadArea1.LeftX = Me.ListView_MeanRegion.Items(0).Text
                fpr.MeanUploadArea1.TopY = Me.ListView_MeanRegion.Items(0).SubItems(1).Text
                fpr.MeanUploadArea1.RightX = Me.ListView_MeanRegion.Items(0).SubItems(2).Text
                fpr.MeanUploadArea1.BottomY = Me.ListView_MeanRegion.Items(0).SubItems(3).Text
                fpr.MeanUploadArea1.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
            End If
            If NumericUpDown_TotalRegion.Value = 2 Then
                fpr.MeanUploadArea1.LeftX = Me.ListView_MeanRegion.Items(0).Text
                fpr.MeanUploadArea1.TopY = Me.ListView_MeanRegion.Items(0).SubItems(1).Text
                fpr.MeanUploadArea1.RightX = Me.ListView_MeanRegion.Items(0).SubItems(2).Text
                fpr.MeanUploadArea1.BottomY = Me.ListView_MeanRegion.Items(0).SubItems(3).Text
                fpr.MeanUploadArea1.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
                fpr.MeanUploadArea2.LeftX = Me.ListView_MeanRegion.Items(1).Text
                fpr.MeanUploadArea2.TopY = Me.ListView_MeanRegion.Items(1).SubItems(1).Text
                fpr.MeanUploadArea2.RightX = Me.ListView_MeanRegion.Items(1).SubItems(2).Text
                fpr.MeanUploadArea2.BottomY = Me.ListView_MeanRegion.Items(1).SubItems(3).Text
                fpr.MeanUploadArea2.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
            End If
            If NumericUpDown_TotalRegion.Value = 3 Then
                fpr.MeanUploadArea1.LeftX = Me.ListView_MeanRegion.Items(0).Text
                fpr.MeanUploadArea1.TopY = Me.ListView_MeanRegion.Items(0).SubItems(1).Text
                fpr.MeanUploadArea1.RightX = Me.ListView_MeanRegion.Items(0).SubItems(2).Text
                fpr.MeanUploadArea1.BottomY = Me.ListView_MeanRegion.Items(0).SubItems(3).Text
                fpr.MeanUploadArea1.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
                fpr.MeanUploadArea2.LeftX = Me.ListView_MeanRegion.Items(1).Text
                fpr.MeanUploadArea2.TopY = Me.ListView_MeanRegion.Items(1).SubItems(1).Text
                fpr.MeanUploadArea2.RightX = Me.ListView_MeanRegion.Items(1).SubItems(2).Text
                fpr.MeanUploadArea2.BottomY = Me.ListView_MeanRegion.Items(1).SubItems(3).Text
                fpr.MeanUploadArea2.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
                fpr.MeanUploadArea3.LeftX = Me.ListView_MeanRegion.Items(2).Text
                fpr.MeanUploadArea3.TopY = Me.ListView_MeanRegion.Items(2).SubItems(1).Text
                fpr.MeanUploadArea3.RightX = Me.ListView_MeanRegion.Items(2).SubItems(2).Text
                fpr.MeanUploadArea3.BottomY = Me.ListView_MeanRegion.Items(2).SubItems(3).Text
                fpr.MeanUploadArea3.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
            End If
            Me.m_FuncProcess.SaveCurrentFuncPatternRecipe(dir, 0)
        Else
            dir = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_IPBootConfig.CCD.Value & "\" & Me.m_Form.TextBox_Product.Text & "\Mura" & "\MuraPatternRecipe_C" & Me.m_IPBootConfig.GrabNo.Value & "_P" & Me.ComboBox_MeanRegionPattern.SelectedIndex + 1 & ".xml"
            If NumericUpDown_TotalRegion.Value = 1 Then
                mpr.MeanUploadArea1.LeftX = Me.ListView_MeanRegion.Items(0).Text
                mpr.MeanUploadArea1.TopY = Me.ListView_MeanRegion.Items(0).SubItems(1).Text
                mpr.MeanUploadArea1.RightX = Me.ListView_MeanRegion.Items(0).SubItems(2).Text
                mpr.MeanUploadArea1.BottomY = Me.ListView_MeanRegion.Items(0).SubItems(3).Text
                mpr.MeanUploadArea1.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
            End If
            If NumericUpDown_TotalRegion.Value = 2 Then
                mpr.MeanUploadArea1.LeftX = Me.ListView_MeanRegion.Items(0).Text
                mpr.MeanUploadArea1.TopY = Me.ListView_MeanRegion.Items(0).SubItems(1).Text
                mpr.MeanUploadArea1.RightX = Me.ListView_MeanRegion.Items(0).SubItems(2).Text
                mpr.MeanUploadArea1.BottomY = Me.ListView_MeanRegion.Items(0).SubItems(3).Text
                mpr.MeanUploadArea1.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
                mpr.MeanUploadArea2.LeftX = Me.ListView_MeanRegion.Items(1).Text
                mpr.MeanUploadArea2.TopY = Me.ListView_MeanRegion.Items(1).SubItems(1).Text
                mpr.MeanUploadArea2.RightX = Me.ListView_MeanRegion.Items(1).SubItems(2).Text
                mpr.MeanUploadArea2.BottomY = Me.ListView_MeanRegion.Items(1).SubItems(3).Text
                mpr.MeanUploadArea2.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
            End If
            If NumericUpDown_TotalRegion.Value = 3 Then
                mpr.MeanUploadArea1.LeftX = Me.ListView_MeanRegion.Items(0).Text
                mpr.MeanUploadArea1.TopY = Me.ListView_MeanRegion.Items(0).SubItems(1).Text
                mpr.MeanUploadArea1.RightX = Me.ListView_MeanRegion.Items(0).SubItems(2).Text
                mpr.MeanUploadArea1.BottomY = Me.ListView_MeanRegion.Items(0).SubItems(3).Text
                mpr.MeanUploadArea1.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
                mpr.MeanUploadArea2.LeftX = Me.ListView_MeanRegion.Items(1).Text
                mpr.MeanUploadArea2.TopY = Me.ListView_MeanRegion.Items(1).SubItems(1).Text
                mpr.MeanUploadArea2.RightX = Me.ListView_MeanRegion.Items(1).SubItems(2).Text
                mpr.MeanUploadArea2.BottomY = Me.ListView_MeanRegion.Items(1).SubItems(3).Text
                mpr.MeanUploadArea2.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
                mpr.MeanUploadArea3.LeftX = Me.ListView_MeanRegion.Items(2).Text
                mpr.MeanUploadArea3.TopY = Me.ListView_MeanRegion.Items(2).SubItems(1).Text
                mpr.MeanUploadArea3.RightX = Me.ListView_MeanRegion.Items(2).SubItems(2).Text
                mpr.MeanUploadArea3.BottomY = Me.ListView_MeanRegion.Items(2).SubItems(3).Text
                mpr.MeanUploadArea3.Pattern = Me.ComboBox_MeanRegionPattern.SelectedItem
            End If
            Me.m_Form.MuraProcess.SaveCurrentMuraPatternRecipe(dir, 0)
        End If
    End Sub

#End Region

#Region "--- Draw ---"

    Private Sub DrawMark()
        Dim offX As Integer
        Dim offY As Integer
        Dim image As MIL_ID = M_NULL

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image <> M_NULL Then
            Select Case Me.m_Form.ComboBox_Type.SelectedIndex
                Case 0
                    Me.DrawMeanRegion(0, 0)
                Case 1
                    Me.DrawMeanRegion(0, 0)
            End Select
        End If

        Me.m_Form.PaintStop = True
        Me.m_GraphicsImage.Clear(Color.Transparent)
        offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_Form.PaintStop = False
        Update()
    End Sub

    Private Sub DrawMeanRegion(ByVal offX As Integer, ByVal offY As Integer)
        Dim i As Integer
        Dim bx As Integer
        Dim by As Integer
        Dim ox As Integer
        Dim oy As Integer
        Dim r As Integer
        Dim hr As Integer
        Dim s As Double
        Dim lvi As ListViewItem
        Dim intLabelLeft As Integer
        Dim intLabelRight As Integer
        Dim intLabelTop As Integer
        Dim intLabelBottom As Integer
        Dim rect As Rectangle
        Dim SizeX, SizeY As Integer
        Dim ZoomX As Double

        rect = New Rectangle
        MdispInquire(Me.m_AxMDisplay, MIL.M_SIZE_X, SizeX)
        MdispInquire(Me.m_AxMDisplay, MIL.M_SIZE_Y, SizeX)
        MdispInquire(Me.m_AxMDisplay, MIL.M_ZOOM_FACTOR_X, ZoomX)

        bx = SizeX
        by = SizeY
        ox = Me.m_Form.HScrollBar.Value - offX
        oy = Me.m_Form.VScrollBar.Value - offY
        s = ZoomX
        r = Me.m_Size * s
        hr = 0.5 * Me.m_Size * s
        Me.m_Pen.Color = Color.Red
        Me.m_Pen.Width = s
        For i = 0 To Me.ListView_MeanRegion.Items.Count - 1
            lvi = Me.ListView_MeanRegion.Items(i)
            intLabelLeft = (lvi.SubItems(0).Text - Me.m_Form.HScrollBar.Value - offX) * s
            intLabelRight = (lvi.SubItems(2).Text - Me.m_Form.HScrollBar.Value - offX) * s
            intLabelTop = (lvi.SubItems(1).Text - Me.m_Form.VScrollBar.Value - offY) * s
            intLabelBottom = (lvi.SubItems(3).Text - Me.m_Form.VScrollBar.Value - offY) * s
            rect.X = intLabelLeft
            rect.Y = intLabelTop
            rect.Width = intLabelRight - intLabelLeft + 1
            rect.Height = intLabelBottom - intLabelTop + 1
            Me.m_GraphicsImage.DrawRectangle(Me.m_Pen, rect)
        Next

        Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
        Me.m_Form.PaintStop = False

    End Sub

#End Region

#Region "---CheckBox---"

    Private Sub CheckBox_Show_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_MeanRegionShow.CheckedChanged
        If Me.CheckBox_MeanRegionShow.Checked Then
            Me.DrawMark()
        Else
            Me.m_Form.PaintStop = True
            Update()
        End If
    End Sub

    Private Sub CheckBox_Mannual_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox_MeanRegionMannual.CheckedChanged
        If Me.CheckBox_MeanRegionMannual.Checked Then
            If NumericUpDown_TotalRegion.Value = 3 Then
                MsgBox("[請先刪除全部區域]", MsgBoxStyle.Critical, "[Dialog_RMSSetting]")
            End If
        End If
    End Sub

#End Region

#Region "--- AxMDisplay Mouse Event ---"

    Private Sub m_Panel_AxMDisplay_MouseDown(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseDown
        'Filter Region ---
        If Me.CheckBox_MeanRegionMannual.Checked And Me.CheckBox_MeanRegionShow.Checked Then
            Me.TextBox_MinX.Text = Me.m_Form.MouseX
            Me.TextBox_MinY.Text = Me.m_Form.MouseY
        End If
    End Sub
    Private Sub m_Panel_AxMDisplay_MouseUp(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles m_Panel_AxMDisplay.MouseUp
        'Filter Region ---
        If Me.CheckBox_MeanRegionMannual.Checked And Me.CheckBox_MeanRegionShow.Checked Then
            Me.TextBox_MaxX.Text = Me.m_Form.MouseX
            Me.TextBox_MaxY.Text = Me.m_Form.MouseY
        End If
    End Sub
#End Region

    Private Sub Dialog_RMSSetting_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Me.m_Form.PaintStop = True
        Update()
    End Sub

    Private Sub Button_Add_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Add.Click
        Dim i As Integer
        If NumericUpDown_TotalRegion.Value = 3 Then
            Me.m_Form.PaintStop = True
            MsgBox("[請先刪除全部區域]", MsgBoxStyle.Critical, "[Dialog_RMSSetting]")
            Exit Sub
        End If
        Me.ListView_MeanRegion.Items.Add(Me.TextBox_MinX.Text)
        i = Me.NumericUpDown_TotalRegion.Value
        Me.ListView_MeanRegion.Items(i).SubItems.Add(Me.TextBox_MinY.Text)
        Me.ListView_MeanRegion.Items(i).SubItems.Add(Me.TextBox_MaxX.Text)
        Me.ListView_MeanRegion.Items(i).SubItems.Add(Me.TextBox_MaxY.Text)
        Me.ListView_MeanRegion.Items(i).SubItems.Add(Me.ComboBox_MeanRegionPattern.SelectedItem)
        Me.NumericUpDown_TotalRegion.Value = Me.ListView_MeanRegion.Items.Count
        Me.DrawMark()
    End Sub

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region


#Region "--- UI Event ---"

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_VScrollBar.MouseCaptureChanged
        If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
            Me.DrawMark()
        End If
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_HScrollBar.MouseCaptureChanged
        If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
            Me.DrawMark()
        End If
    End Sub
#End Region

#Region "--- Button Event ---"
    Private Sub m_Button_ZoomIn_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomIn.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomIn.PerformClick()
            If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                Me.DrawMark()
            End If
        End If
    End Sub
    Private Sub m_Button_ZoomOut_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomOut.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomOut.PerformClick()
            If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                Me.DrawMark()
            End If
        End If
    End Sub
    Private Sub m_Button_ZoomO_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomO.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomO.PerformClick()
            If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                Me.DrawMark()
            End If
        End If
    End Sub
    Private Sub m_Button_ZoomAll_MouseClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles m_Button_ZoomAll.MouseClick
        If Me.Focused Then
            Me.m_Form.Button_ZoomAll.PerformClick()
            If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                Me.DrawMark()
            End If
        End If
    End Sub
#End Region

#Region "---ContextMenu Event"

    Private Sub ZoomContextMenuStrip_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles m_ZoomContextMenuStrip.ItemClicked
        If Me.Focused Then
            If e.ClickedItem Is Me.m_ZoomInToolStripMenuItem Then
                Me.m_Form.MoveToCenter = True
                Me.m_Form.Button_ZoomIn.PerformClick()
                If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                    Me.DrawMark()
                End If
            ElseIf e.ClickedItem Is Me.m_ZoomOutToolStripMenuItem Then
                Me.m_Form.MoveToCenter = True
                Me.m_Form.Button_ZoomOut.PerformClick()
                If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                    Me.DrawMark()
                End If
            ElseIf e.ClickedItem Is Me.m_OriginToolStripMenuItem Then
                Me.m_Form.MoveToCenter = True
                Me.m_Form.Button_ZoomO.PerformClick()
                If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                    Me.DrawMark()
                End If
            ElseIf e.ClickedItem Is m_ZoomAllToolStripMenuItem Then
                Me.m_Form.MoveToCenter = True
                Me.m_Form.Button_ZoomAll.PerformClick()
                If CheckBox_MeanRegionMannual.Checked And CheckBox_MeanRegionShow.Checked Then
                    Me.DrawMark()
                End If
            End If
        End If
    End Sub

#End Region

#End Region

End Class