﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_CameraAlignment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_CameraAlignment))
        Me.Panel_AxMDisplay_CA = New System.Windows.Forms.Panel()
        Me.Button_ZoomAll = New System.Windows.Forms.Button()
        Me.Button_ZoomOut = New System.Windows.Forms.Button()
        Me.Button_ZoomIn = New System.Windows.Forms.Button()
        Me.Button_ZoomO = New System.Windows.Forms.Button()
        Me.GroupBox_Setting = New System.Windows.Forms.GroupBox()
        Me.CheckBo_CCD_Rotate_90 = New System.Windows.Forms.CheckBox()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox_CCD_Y_Num = New System.Windows.Forms.TextBox()
        Me.TextBox_CCD_X_Num = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox_CCD_Resolution_V = New System.Windows.Forms.TextBox()
        Me.TextBox_CCD_Resolution_H = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CheckBox_ShowBoundary = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox_ROI_OffsetY = New System.Windows.Forms.TextBox()
        Me.TextBox_ROI_OffsetX = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox_Panel_Resolution_V = New System.Windows.Forms.TextBox()
        Me.TextBox_Panel_Resolution_H = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NumericUpDown_Pitch = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox_Grab = New System.Windows.Forms.GroupBox()
        Me.Button_Grab = New System.Windows.Forms.Button()
        Me.Button_Continue = New System.Windows.Forms.Button()
        Me.VScrollBar = New System.Windows.Forms.VScrollBar()
        Me.HScrollBar = New System.Windows.Forms.HScrollBar()
        Me.GroupBox_ExposureTime = New System.Windows.Forms.GroupBox()
        Me.Label_ExposureTime = New System.Windows.Forms.Label()
        Me.NumericUpDown_ExposureTime = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_ExposureTime = New System.Windows.Forms.TrackBar()
        Me.StatusBar = New System.Windows.Forms.StatusBar()
        Me.StatusBarPanel_XY = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Value = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Scale = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Focus = New System.Windows.Forms.StatusBarPanel()
        Me.StatusBarPanel_Msg = New System.Windows.Forms.StatusBarPanel()
        Me.Button_Load = New System.Windows.Forms.Button()
        Me.OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox_Alignment = New System.Windows.Forms.GroupBox()
        Me.GroupBox_Alignment_Direction = New System.Windows.Forms.GroupBox()
        Me.CheckBox_Func_RightAnalysis = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Func_BottomAnalysis = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Func_LeftAnalysis = New System.Windows.Forms.CheckBox()
        Me.CheckBox_Func_TopAnalysis = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button_SaveAlignmentRecipe = New System.Windows.Forms.Button()
        Me.CheckBox_EnhanceEdge = New System.Windows.Forms.CheckBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AlignTolerance = New System.Windows.Forms.NumericUpDown()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.NumericUpDown_AlignmentShift = New System.Windows.Forms.NumericUpDown()
        Me.Button_Alignment = New System.Windows.Forms.Button()
        Me.GroupBox_Boundary = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_BoundaryRight = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryRight = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryLeft = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryLeft = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryTop = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryBottom = New System.Windows.Forms.Label()
        Me.NumericUpDown_BoundaryBottom = New System.Windows.Forms.NumericUpDown()
        Me.Label_BoundaryTop = New System.Windows.Forms.Label()
        Me.CheckBox_ShowROI = New System.Windows.Forms.CheckBox()
        Me.ContextMenuStrip_AlignSetting = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.GrabImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StopGrabToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoadImageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowROIToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlignmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox_GoTo_Point = New System.Windows.Forms.GroupBox()
        Me.Button_GoTo_Position = New System.Windows.Forms.Button()
        Me.TextBox_GoTo_BlobY = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox_GoTo_BlobX = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.CheckBox_Defocus = New System.Windows.Forms.CheckBox()
        Me.GroupBox_Setting.SuspendLayout()
        CType(Me.NumericUpDown_Pitch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Grab.SuspendLayout()
        Me.GroupBox_ExposureTime.SuspendLayout()
        CType(Me.NumericUpDown_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_XY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Value, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Scale, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Focus, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel_Msg, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Alignment.SuspendLayout()
        Me.GroupBox_Alignment_Direction.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.NumericUpDown_AlignTolerance, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_AlignmentShift, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Boundary.SuspendLayout()
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ContextMenuStrip_AlignSetting.SuspendLayout()
        Me.GroupBox_GoTo_Point.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel_AxMDisplay_CA
        '
        resources.ApplyResources(Me.Panel_AxMDisplay_CA, "Panel_AxMDisplay_CA")
        Me.Panel_AxMDisplay_CA.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Panel_AxMDisplay_CA.Name = "Panel_AxMDisplay_CA"
        '
        'Button_ZoomAll
        '
        resources.ApplyResources(Me.Button_ZoomAll, "Button_ZoomAll")
        Me.Button_ZoomAll.Name = "Button_ZoomAll"
        '
        'Button_ZoomOut
        '
        resources.ApplyResources(Me.Button_ZoomOut, "Button_ZoomOut")
        Me.Button_ZoomOut.Name = "Button_ZoomOut"
        '
        'Button_ZoomIn
        '
        resources.ApplyResources(Me.Button_ZoomIn, "Button_ZoomIn")
        Me.Button_ZoomIn.Name = "Button_ZoomIn"
        '
        'Button_ZoomO
        '
        resources.ApplyResources(Me.Button_ZoomO, "Button_ZoomO")
        Me.Button_ZoomO.Name = "Button_ZoomO"
        '
        'GroupBox_Setting
        '
        resources.ApplyResources(Me.GroupBox_Setting, "GroupBox_Setting")
        Me.GroupBox_Setting.Controls.Add(Me.CheckBo_CCD_Rotate_90)
        Me.GroupBox_Setting.Controls.Add(Me.Button_Save)
        Me.GroupBox_Setting.Controls.Add(Me.Label8)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_CCD_Y_Num)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_CCD_X_Num)
        Me.GroupBox_Setting.Controls.Add(Me.Label9)
        Me.GroupBox_Setting.Controls.Add(Me.Label7)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_CCD_Resolution_V)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_CCD_Resolution_H)
        Me.GroupBox_Setting.Controls.Add(Me.Label6)
        Me.GroupBox_Setting.Controls.Add(Me.CheckBox_ShowBoundary)
        Me.GroupBox_Setting.Controls.Add(Me.Label4)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_ROI_OffsetY)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_ROI_OffsetX)
        Me.GroupBox_Setting.Controls.Add(Me.Label5)
        Me.GroupBox_Setting.Controls.Add(Me.Label3)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_Panel_Resolution_V)
        Me.GroupBox_Setting.Controls.Add(Me.TextBox_Panel_Resolution_H)
        Me.GroupBox_Setting.Controls.Add(Me.Label2)
        Me.GroupBox_Setting.Controls.Add(Me.NumericUpDown_Pitch)
        Me.GroupBox_Setting.Controls.Add(Me.Label1)
        Me.GroupBox_Setting.Name = "GroupBox_Setting"
        Me.GroupBox_Setting.TabStop = False
        '
        'CheckBo_CCD_Rotate_90
        '
        resources.ApplyResources(Me.CheckBo_CCD_Rotate_90, "CheckBo_CCD_Rotate_90")
        Me.CheckBo_CCD_Rotate_90.Name = "CheckBo_CCD_Rotate_90"
        Me.CheckBo_CCD_Rotate_90.UseVisualStyleBackColor = True
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.UseVisualStyleBackColor = True
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'TextBox_CCD_Y_Num
        '
        resources.ApplyResources(Me.TextBox_CCD_Y_Num, "TextBox_CCD_Y_Num")
        Me.TextBox_CCD_Y_Num.Name = "TextBox_CCD_Y_Num"
        '
        'TextBox_CCD_X_Num
        '
        resources.ApplyResources(Me.TextBox_CCD_X_Num, "TextBox_CCD_X_Num")
        Me.TextBox_CCD_X_Num.Name = "TextBox_CCD_X_Num"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        Me.Label9.Tag = ""
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'TextBox_CCD_Resolution_V
        '
        resources.ApplyResources(Me.TextBox_CCD_Resolution_V, "TextBox_CCD_Resolution_V")
        Me.TextBox_CCD_Resolution_V.Name = "TextBox_CCD_Resolution_V"
        '
        'TextBox_CCD_Resolution_H
        '
        resources.ApplyResources(Me.TextBox_CCD_Resolution_H, "TextBox_CCD_Resolution_H")
        Me.TextBox_CCD_Resolution_H.Name = "TextBox_CCD_Resolution_H"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        Me.Label6.Tag = ""
        '
        'CheckBox_ShowBoundary
        '
        resources.ApplyResources(Me.CheckBox_ShowBoundary, "CheckBox_ShowBoundary")
        Me.CheckBox_ShowBoundary.Name = "CheckBox_ShowBoundary"
        Me.CheckBox_ShowBoundary.UseVisualStyleBackColor = True
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'TextBox_ROI_OffsetY
        '
        resources.ApplyResources(Me.TextBox_ROI_OffsetY, "TextBox_ROI_OffsetY")
        Me.TextBox_ROI_OffsetY.Name = "TextBox_ROI_OffsetY"
        '
        'TextBox_ROI_OffsetX
        '
        resources.ApplyResources(Me.TextBox_ROI_OffsetX, "TextBox_ROI_OffsetX")
        Me.TextBox_ROI_OffsetX.Name = "TextBox_ROI_OffsetX"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'TextBox_Panel_Resolution_V
        '
        resources.ApplyResources(Me.TextBox_Panel_Resolution_V, "TextBox_Panel_Resolution_V")
        Me.TextBox_Panel_Resolution_V.Name = "TextBox_Panel_Resolution_V"
        '
        'TextBox_Panel_Resolution_H
        '
        resources.ApplyResources(Me.TextBox_Panel_Resolution_H, "TextBox_Panel_Resolution_H")
        Me.TextBox_Panel_Resolution_H.Name = "TextBox_Panel_Resolution_H"
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'NumericUpDown_Pitch
        '
        resources.ApplyResources(Me.NumericUpDown_Pitch, "NumericUpDown_Pitch")
        Me.NumericUpDown_Pitch.DecimalPlaces = 1
        Me.NumericUpDown_Pitch.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDown_Pitch.Name = "NumericUpDown_Pitch"
        Me.NumericUpDown_Pitch.Value = New Decimal(New Integer() {4, 0, 0, 0})
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'GroupBox_Grab
        '
        resources.ApplyResources(Me.GroupBox_Grab, "GroupBox_Grab")
        Me.GroupBox_Grab.Controls.Add(Me.Button_Grab)
        Me.GroupBox_Grab.Controls.Add(Me.Button_Continue)
        Me.GroupBox_Grab.Name = "GroupBox_Grab"
        Me.GroupBox_Grab.TabStop = False
        '
        'Button_Grab
        '
        resources.ApplyResources(Me.Button_Grab, "Button_Grab")
        Me.Button_Grab.Name = "Button_Grab"
        '
        'Button_Continue
        '
        resources.ApplyResources(Me.Button_Continue, "Button_Continue")
        Me.Button_Continue.Name = "Button_Continue"
        '
        'VScrollBar
        '
        resources.ApplyResources(Me.VScrollBar, "VScrollBar")
        Me.VScrollBar.LargeChange = 1
        Me.VScrollBar.Name = "VScrollBar"
        '
        'HScrollBar
        '
        resources.ApplyResources(Me.HScrollBar, "HScrollBar")
        Me.HScrollBar.LargeChange = 1
        Me.HScrollBar.Name = "HScrollBar"
        '
        'GroupBox_ExposureTime
        '
        resources.ApplyResources(Me.GroupBox_ExposureTime, "GroupBox_ExposureTime")
        Me.GroupBox_ExposureTime.Controls.Add(Me.Label_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.NumericUpDown_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.TrackBar_ExposureTime)
        Me.GroupBox_ExposureTime.Name = "GroupBox_ExposureTime"
        Me.GroupBox_ExposureTime.TabStop = False
        '
        'Label_ExposureTime
        '
        resources.ApplyResources(Me.Label_ExposureTime, "Label_ExposureTime")
        Me.Label_ExposureTime.Name = "Label_ExposureTime"
        '
        'NumericUpDown_ExposureTime
        '
        resources.ApplyResources(Me.NumericUpDown_ExposureTime, "NumericUpDown_ExposureTime")
        Me.NumericUpDown_ExposureTime.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Maximum = New Decimal(New Integer() {7000000, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Name = "NumericUpDown_ExposureTime"
        Me.NumericUpDown_ExposureTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'TrackBar_ExposureTime
        '
        resources.ApplyResources(Me.TrackBar_ExposureTime, "TrackBar_ExposureTime")
        Me.TrackBar_ExposureTime.LargeChange = 10000
        Me.TrackBar_ExposureTime.Maximum = 7000000
        Me.TrackBar_ExposureTime.Minimum = 1
        Me.TrackBar_ExposureTime.Name = "TrackBar_ExposureTime"
        Me.TrackBar_ExposureTime.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_ExposureTime.Value = 1
        '
        'StatusBar
        '
        resources.ApplyResources(Me.StatusBar, "StatusBar")
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel_XY, Me.StatusBarPanel_Value, Me.StatusBarPanel_Scale, Me.StatusBarPanel_Focus, Me.StatusBarPanel_Msg})
        Me.StatusBar.ShowPanels = True
        '
        'StatusBarPanel_XY
        '
        resources.ApplyResources(Me.StatusBarPanel_XY, "StatusBarPanel_XY")
        '
        'StatusBarPanel_Value
        '
        resources.ApplyResources(Me.StatusBarPanel_Value, "StatusBarPanel_Value")
        '
        'StatusBarPanel_Scale
        '
        resources.ApplyResources(Me.StatusBarPanel_Scale, "StatusBarPanel_Scale")
        '
        'StatusBarPanel_Focus
        '
        resources.ApplyResources(Me.StatusBarPanel_Focus, "StatusBarPanel_Focus")
        '
        'StatusBarPanel_Msg
        '
        resources.ApplyResources(Me.StatusBarPanel_Msg, "StatusBarPanel_Msg")
        '
        'Button_Load
        '
        resources.ApplyResources(Me.Button_Load, "Button_Load")
        Me.Button_Load.Name = "Button_Load"
        '
        'OpenFileDialog
        '
        Me.OpenFileDialog.FileName = "OpenFileDialog1"
        resources.ApplyResources(Me.OpenFileDialog, "OpenFileDialog")
        '
        'GroupBox_Alignment
        '
        resources.ApplyResources(Me.GroupBox_Alignment, "GroupBox_Alignment")
        Me.GroupBox_Alignment.Controls.Add(Me.GroupBox_Alignment_Direction)
        Me.GroupBox_Alignment.Controls.Add(Me.GroupBox1)
        Me.GroupBox_Alignment.Controls.Add(Me.GroupBox_Boundary)
        Me.GroupBox_Alignment.Controls.Add(Me.CheckBox_ShowROI)
        Me.GroupBox_Alignment.Name = "GroupBox_Alignment"
        Me.GroupBox_Alignment.TabStop = False
        '
        'GroupBox_Alignment_Direction
        '
        resources.ApplyResources(Me.GroupBox_Alignment_Direction, "GroupBox_Alignment_Direction")
        Me.GroupBox_Alignment_Direction.Controls.Add(Me.CheckBox_Func_RightAnalysis)
        Me.GroupBox_Alignment_Direction.Controls.Add(Me.CheckBox_Func_BottomAnalysis)
        Me.GroupBox_Alignment_Direction.Controls.Add(Me.CheckBox_Func_LeftAnalysis)
        Me.GroupBox_Alignment_Direction.Controls.Add(Me.CheckBox_Func_TopAnalysis)
        Me.GroupBox_Alignment_Direction.Name = "GroupBox_Alignment_Direction"
        Me.GroupBox_Alignment_Direction.TabStop = False
        '
        'CheckBox_Func_RightAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_RightAnalysis, "CheckBox_Func_RightAnalysis")
        Me.CheckBox_Func_RightAnalysis.Name = "CheckBox_Func_RightAnalysis"
        Me.CheckBox_Func_RightAnalysis.UseVisualStyleBackColor = True
        '
        'CheckBox_Func_BottomAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_BottomAnalysis, "CheckBox_Func_BottomAnalysis")
        Me.CheckBox_Func_BottomAnalysis.Name = "CheckBox_Func_BottomAnalysis"
        Me.CheckBox_Func_BottomAnalysis.UseVisualStyleBackColor = True
        '
        'CheckBox_Func_LeftAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_LeftAnalysis, "CheckBox_Func_LeftAnalysis")
        Me.CheckBox_Func_LeftAnalysis.Name = "CheckBox_Func_LeftAnalysis"
        Me.CheckBox_Func_LeftAnalysis.UseVisualStyleBackColor = True
        '
        'CheckBox_Func_TopAnalysis
        '
        resources.ApplyResources(Me.CheckBox_Func_TopAnalysis, "CheckBox_Func_TopAnalysis")
        Me.CheckBox_Func_TopAnalysis.Name = "CheckBox_Func_TopAnalysis"
        Me.CheckBox_Func_TopAnalysis.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.Controls.Add(Me.Button_SaveAlignmentRecipe)
        Me.GroupBox1.Controls.Add(Me.CheckBox_EnhanceEdge)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_AlignTolerance)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.NumericUpDown_AlignmentShift)
        Me.GroupBox1.Controls.Add(Me.Button_Alignment)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'Button_SaveAlignmentRecipe
        '
        resources.ApplyResources(Me.Button_SaveAlignmentRecipe, "Button_SaveAlignmentRecipe")
        Me.Button_SaveAlignmentRecipe.Name = "Button_SaveAlignmentRecipe"
        Me.Button_SaveAlignmentRecipe.UseVisualStyleBackColor = True
        '
        'CheckBox_EnhanceEdge
        '
        resources.ApplyResources(Me.CheckBox_EnhanceEdge, "CheckBox_EnhanceEdge")
        Me.CheckBox_EnhanceEdge.Name = "CheckBox_EnhanceEdge"
        Me.CheckBox_EnhanceEdge.UseVisualStyleBackColor = True
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'NumericUpDown_AlignTolerance
        '
        resources.ApplyResources(Me.NumericUpDown_AlignTolerance, "NumericUpDown_AlignTolerance")
        Me.NumericUpDown_AlignTolerance.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_AlignTolerance.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_AlignTolerance.Name = "NumericUpDown_AlignTolerance"
        Me.NumericUpDown_AlignTolerance.Value = New Decimal(New Integer() {40, 0, 0, 0})
        '
        'Label12
        '
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'NumericUpDown_AlignmentShift
        '
        resources.ApplyResources(Me.NumericUpDown_AlignmentShift, "NumericUpDown_AlignmentShift")
        Me.NumericUpDown_AlignmentShift.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown_AlignmentShift.Minimum = New Decimal(New Integer() {1000, 0, 0, -2147483648})
        Me.NumericUpDown_AlignmentShift.Name = "NumericUpDown_AlignmentShift"
        Me.NumericUpDown_AlignmentShift.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Button_Alignment
        '
        resources.ApplyResources(Me.Button_Alignment, "Button_Alignment")
        Me.Button_Alignment.Name = "Button_Alignment"
        Me.Button_Alignment.UseVisualStyleBackColor = True
        '
        'GroupBox_Boundary
        '
        resources.ApplyResources(Me.GroupBox_Boundary, "GroupBox_Boundary")
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryRight)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryLeft)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryTop)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.NumericUpDown_BoundaryBottom)
        Me.GroupBox_Boundary.Controls.Add(Me.Label_BoundaryTop)
        Me.GroupBox_Boundary.Name = "GroupBox_Boundary"
        Me.GroupBox_Boundary.TabStop = False
        '
        'NumericUpDown_BoundaryRight
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryRight, "NumericUpDown_BoundaryRight")
        Me.NumericUpDown_BoundaryRight.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryRight.Name = "NumericUpDown_BoundaryRight"
        '
        'Label_BoundaryRight
        '
        resources.ApplyResources(Me.Label_BoundaryRight, "Label_BoundaryRight")
        Me.Label_BoundaryRight.Name = "Label_BoundaryRight"
        '
        'NumericUpDown_BoundaryLeft
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryLeft, "NumericUpDown_BoundaryLeft")
        Me.NumericUpDown_BoundaryLeft.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryLeft.Name = "NumericUpDown_BoundaryLeft"
        '
        'Label_BoundaryLeft
        '
        resources.ApplyResources(Me.Label_BoundaryLeft, "Label_BoundaryLeft")
        Me.Label_BoundaryLeft.Name = "Label_BoundaryLeft"
        '
        'NumericUpDown_BoundaryTop
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryTop, "NumericUpDown_BoundaryTop")
        Me.NumericUpDown_BoundaryTop.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryTop.Name = "NumericUpDown_BoundaryTop"
        '
        'Label_BoundaryBottom
        '
        resources.ApplyResources(Me.Label_BoundaryBottom, "Label_BoundaryBottom")
        Me.Label_BoundaryBottom.Name = "Label_BoundaryBottom"
        '
        'NumericUpDown_BoundaryBottom
        '
        resources.ApplyResources(Me.NumericUpDown_BoundaryBottom, "NumericUpDown_BoundaryBottom")
        Me.NumericUpDown_BoundaryBottom.Maximum = New Decimal(New Integer() {50000, 0, 0, 0})
        Me.NumericUpDown_BoundaryBottom.Name = "NumericUpDown_BoundaryBottom"
        '
        'Label_BoundaryTop
        '
        resources.ApplyResources(Me.Label_BoundaryTop, "Label_BoundaryTop")
        Me.Label_BoundaryTop.Name = "Label_BoundaryTop"
        '
        'CheckBox_ShowROI
        '
        resources.ApplyResources(Me.CheckBox_ShowROI, "CheckBox_ShowROI")
        Me.CheckBox_ShowROI.Name = "CheckBox_ShowROI"
        Me.CheckBox_ShowROI.UseVisualStyleBackColor = True
        '
        'ContextMenuStrip_AlignSetting
        '
        resources.ApplyResources(Me.ContextMenuStrip_AlignSetting, "ContextMenuStrip_AlignSetting")
        Me.ContextMenuStrip_AlignSetting.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.GrabImageToolStripMenuItem, Me.StopGrabToolStripMenuItem, Me.LoadImageToolStripMenuItem, Me.ShowROIToolStripMenuItem, Me.AlignmentToolStripMenuItem, Me.SaveToolStripMenuItem})
        Me.ContextMenuStrip_AlignSetting.Name = "ContextMenuStrip_AlignSetting"
        '
        'GrabImageToolStripMenuItem
        '
        resources.ApplyResources(Me.GrabImageToolStripMenuItem, "GrabImageToolStripMenuItem")
        Me.GrabImageToolStripMenuItem.Name = "GrabImageToolStripMenuItem"
        '
        'StopGrabToolStripMenuItem
        '
        resources.ApplyResources(Me.StopGrabToolStripMenuItem, "StopGrabToolStripMenuItem")
        Me.StopGrabToolStripMenuItem.Name = "StopGrabToolStripMenuItem"
        '
        'LoadImageToolStripMenuItem
        '
        resources.ApplyResources(Me.LoadImageToolStripMenuItem, "LoadImageToolStripMenuItem")
        Me.LoadImageToolStripMenuItem.Name = "LoadImageToolStripMenuItem"
        '
        'ShowROIToolStripMenuItem
        '
        resources.ApplyResources(Me.ShowROIToolStripMenuItem, "ShowROIToolStripMenuItem")
        Me.ShowROIToolStripMenuItem.Name = "ShowROIToolStripMenuItem"
        '
        'AlignmentToolStripMenuItem
        '
        resources.ApplyResources(Me.AlignmentToolStripMenuItem, "AlignmentToolStripMenuItem")
        Me.AlignmentToolStripMenuItem.Name = "AlignmentToolStripMenuItem"
        '
        'SaveToolStripMenuItem
        '
        resources.ApplyResources(Me.SaveToolStripMenuItem, "SaveToolStripMenuItem")
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        '
        'GroupBox_GoTo_Point
        '
        resources.ApplyResources(Me.GroupBox_GoTo_Point, "GroupBox_GoTo_Point")
        Me.GroupBox_GoTo_Point.Controls.Add(Me.Button_GoTo_Position)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.TextBox_GoTo_BlobY)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.Label11)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.TextBox_GoTo_BlobX)
        Me.GroupBox_GoTo_Point.Controls.Add(Me.Label13)
        Me.GroupBox_GoTo_Point.Name = "GroupBox_GoTo_Point"
        Me.GroupBox_GoTo_Point.TabStop = False
        '
        'Button_GoTo_Position
        '
        resources.ApplyResources(Me.Button_GoTo_Position, "Button_GoTo_Position")
        Me.Button_GoTo_Position.Name = "Button_GoTo_Position"
        Me.Button_GoTo_Position.UseVisualStyleBackColor = True
        '
        'TextBox_GoTo_BlobY
        '
        resources.ApplyResources(Me.TextBox_GoTo_BlobY, "TextBox_GoTo_BlobY")
        Me.TextBox_GoTo_BlobY.Name = "TextBox_GoTo_BlobY"
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'TextBox_GoTo_BlobX
        '
        resources.ApplyResources(Me.TextBox_GoTo_BlobX, "TextBox_GoTo_BlobX")
        Me.TextBox_GoTo_BlobX.Name = "TextBox_GoTo_BlobX"
        '
        'Label13
        '
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'CheckBox_Defocus
        '
        resources.ApplyResources(Me.CheckBox_Defocus, "CheckBox_Defocus")
        Me.CheckBox_Defocus.Name = "CheckBox_Defocus"
        Me.CheckBox_Defocus.UseVisualStyleBackColor = True
        '
        'Dialog_CameraAlignment
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.CheckBox_Defocus)
        Me.Controls.Add(Me.GroupBox_GoTo_Point)
        Me.Controls.Add(Me.HScrollBar)
        Me.Controls.Add(Me.GroupBox_Alignment)
        Me.Controls.Add(Me.Button_Load)
        Me.Controls.Add(Me.GroupBox_Setting)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.GroupBox_ExposureTime)
        Me.Controls.Add(Me.VScrollBar)
        Me.Controls.Add(Me.GroupBox_Grab)
        Me.Controls.Add(Me.Button_ZoomAll)
        Me.Controls.Add(Me.Button_ZoomOut)
        Me.Controls.Add(Me.Button_ZoomIn)
        Me.Controls.Add(Me.Button_ZoomO)
        Me.Controls.Add(Me.Panel_AxMDisplay_CA)
        Me.Name = "Dialog_CameraAlignment"
        Me.GroupBox_Setting.ResumeLayout(False)
        Me.GroupBox_Setting.PerformLayout()
        CType(Me.NumericUpDown_Pitch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Grab.ResumeLayout(False)
        Me.GroupBox_ExposureTime.ResumeLayout(False)
        Me.GroupBox_ExposureTime.PerformLayout()
        CType(Me.NumericUpDown_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_XY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Value, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Scale, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Focus, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel_Msg, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Alignment.ResumeLayout(False)
        Me.GroupBox_Alignment.PerformLayout()
        Me.GroupBox_Alignment_Direction.ResumeLayout(False)
        Me.GroupBox_Alignment_Direction.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.NumericUpDown_AlignTolerance, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_AlignmentShift, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Boundary.ResumeLayout(False)
        CType(Me.NumericUpDown_BoundaryRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryTop, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_BoundaryBottom, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ContextMenuStrip_AlignSetting.ResumeLayout(False)
        Me.GroupBox_GoTo_Point.ResumeLayout(False)
        Me.GroupBox_GoTo_Point.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel_AxMDisplay_CA As System.Windows.Forms.Panel
    Friend WithEvents Button_ZoomAll As System.Windows.Forms.Button
    Friend WithEvents Button_ZoomOut As System.Windows.Forms.Button
    Friend WithEvents Button_ZoomIn As System.Windows.Forms.Button
    Friend WithEvents Button_ZoomO As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Setting As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Pitch As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Panel_Resolution_V As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_Panel_Resolution_H As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox_ROI_OffsetY As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_ROI_OffsetX As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Grab As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Grab As System.Windows.Forms.Button
    Friend WithEvents Button_Continue As System.Windows.Forms.Button
    Friend WithEvents VScrollBar As System.Windows.Forms.VScrollBar
    Friend WithEvents HScrollBar As System.Windows.Forms.HScrollBar
    Friend WithEvents GroupBox_ExposureTime As System.Windows.Forms.GroupBox
    Friend WithEvents Label_ExposureTime As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ExposureTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents TrackBar_ExposureTime As System.Windows.Forms.TrackBar
    Friend WithEvents StatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents StatusBarPanel_XY As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_Value As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_Scale As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel_Focus As System.Windows.Forms.StatusBarPanel
    Friend WithEvents Button_Load As System.Windows.Forms.Button
    Friend WithEvents CheckBox_ShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents OpenFileDialog As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CCD_Resolution_V As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_CCD_Resolution_H As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox_CCD_Y_Num As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_CCD_X_Num As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents CheckBo_CCD_Rotate_90 As System.Windows.Forms.CheckBox
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents GroupBox_Alignment As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_ShowROI As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_Boundary As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_BoundaryRight As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryRight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryLeft As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryLeft As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryTop As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryBottom As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_BoundaryBottom As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_BoundaryTop As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Alignment_Direction As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_Func_RightAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_BottomAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_LeftAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox_Func_TopAnalysis As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox_EnhanceEdge As System.Windows.Forms.CheckBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AlignTolerance As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_AlignmentShift As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_Alignment As System.Windows.Forms.Button
    Friend WithEvents Button_SaveAlignmentRecipe As System.Windows.Forms.Button
    Friend WithEvents ContextMenuStrip_AlignSetting As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ShowROIToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AlignmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusBarPanel_Msg As System.Windows.Forms.StatusBarPanel
    Friend WithEvents SaveToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GrabImageToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StopGrabToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox_GoTo_Point As System.Windows.Forms.GroupBox
    Friend WithEvents Button_GoTo_Position As System.Windows.Forms.Button
    Friend WithEvents TextBox_GoTo_BlobY As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents TextBox_GoTo_BlobX As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_Defocus As System.Windows.Forms.CheckBox
End Class
