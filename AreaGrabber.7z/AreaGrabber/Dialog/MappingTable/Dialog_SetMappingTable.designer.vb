<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_SetMappingTable
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox_H = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_MinDistH = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_StripeThresholdH = New System.Windows.Forms.NumericUpDown()
        Me.Label_MinDistH = New System.Windows.Forms.Label()
        Me.NumericUpDown_EdgeThresholdH = New System.Windows.Forms.NumericUpDown()
        Me.Label_StripeThresholdH = New System.Windows.Forms.Label()
        Me.Label_EdgeThresholdH = New System.Windows.Forms.Label()
        Me.GroupBox_V = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_MinDistV = New System.Windows.Forms.NumericUpDown()
        Me.Label_MinDistV = New System.Windows.Forms.Label()
        Me.NumericUpDown_StripeThresholdV = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_EdgeThresholdV = New System.Windows.Forms.NumericUpDown()
        Me.Label_StripeThresholdV = New System.Windows.Forms.Label()
        Me.Label_EdgeThresholdV = New System.Windows.Forms.Label()
        Me.GroupBox_Step = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.ROIExtension = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_Width = New System.Windows.Forms.NumericUpDown()
        Me.Label_Width = New System.Windows.Forms.Label()
        Me.Label_Hight = New System.Windows.Forms.Label()
        Me.NumericUpDown_Hight = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Stripe = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_StripeX = New System.Windows.Forms.NumericUpDown()
        Me.Label_StripeX = New System.Windows.Forms.Label()
        Me.Label_StripeY = New System.Windows.Forms.Label()
        Me.NumericUpDown_StripeY = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Table = New System.Windows.Forms.GroupBox()
        Me.NumericUpDown_V = New System.Windows.Forms.NumericUpDown()
        Me.Label_V = New System.Windows.Forms.Label()
        Me.Label_H = New System.Windows.Forms.Label()
        Me.NumericUpDown_H = New System.Windows.Forms.NumericUpDown()
        Me.ComboBox_Type = New System.Windows.Forms.ComboBox()
        Me.Label_Type = New System.Windows.Forms.Label()
        Me.Button_Close = New System.Windows.Forms.Button()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.ListView_H = New System.Windows.Forms.ListView()
        Me.ColumnHeader_IndexH = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_StripeH = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_AvgH = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MaxH = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MinH = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ListView_V = New System.Windows.Forms.ListView()
        Me.ColumnHeader_IndexV = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_StripeV = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_AvgV = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MaxV = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader_MinV = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.DataGridView_V = New System.Windows.Forms.DataGridView()
        Me.DataGridView_H = New System.Windows.Forms.DataGridView()
        Me.Label_ResultV = New System.Windows.Forms.Label()
        Me.Label_ResultH = New System.Windows.Forms.Label()
        Me.GroupBox_Operation = New System.Windows.Forms.GroupBox()
        Me.Button_ClearMappingTable = New System.Windows.Forms.Button()
        Me.Button_Calculate = New System.Windows.Forms.Button()
        Me.Button_SaveMappingTable = New System.Windows.Forms.Button()
        Me.Button_LoadMT = New System.Windows.Forms.Button()
        Me.NumericUpDown_Pitch = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox_SubPixelMode = New System.Windows.Forms.ComboBox()
        Me.GBX_L6A = New System.Windows.Forms.GroupBox()
        Me.Button_LoadImage = New System.Windows.Forms.Button()
        Me.TXB_EdgeWidth = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CheckBox_Preprocess = New System.Windows.Forms.CheckBox()
        Me.GroupBox_CNT = New System.Windows.Forms.GroupBox()
        Me.CheckBox_CNT_Display = New System.Windows.Forms.CheckBox()
        Me.Label1_CNT_Status = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.NUD_FramExtend = New System.Windows.Forms.NumericUpDown()
        Me.Btn_CNTCheck = New System.Windows.Forms.Button()
        Me.NUD_CNTThreshold = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_CNTThreshold = New System.Windows.Forms.TrackBar()
        Me.Label_CCD_FilterNum = New System.Windows.Forms.Label()
        Me.NUD_FilterNum = New System.Windows.Forms.NumericUpDown()
        Me.TXB_LCDH = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TXB_CCD2 = New System.Windows.Forms.TextBox()
        Me.Label_CCD2_StartPosition_Of_3CCD = New System.Windows.Forms.Label()
        Me.CheckBox_ManualMark = New System.Windows.Forms.CheckBox()
        Me.ComboBox_CCDMode = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ComboBox_MarkDirect = New System.Windows.Forms.ComboBox()
        Me.Label_Info = New System.Windows.Forms.Label()
        Me.ComboBox_DataFreQ = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox_GateFreQ = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox_LaserGapHeight = New System.Windows.Forms.TextBox()
        Me.TextBox_LaserGapWidth = New System.Windows.Forms.TextBox()
        Me.TextBox_PanelResolutionY = New System.Windows.Forms.TextBox()
        Me.TextBox_PanelResolutionX = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.NumericUpDown_ManualOffsetDate = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_ManualOffsetGate = New System.Windows.Forms.NumericUpDown()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.GroupBox_H.SuspendLayout()
        CType(Me.NumericUpDown_MinDistH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_StripeThresholdH, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_EdgeThresholdH, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_V.SuspendLayout()
        CType(Me.NumericUpDown_MinDistV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_StripeThresholdV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_EdgeThresholdV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Step.SuspendLayout()
        CType(Me.ROIExtension, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Width, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_Hight, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Stripe.SuspendLayout()
        CType(Me.NumericUpDown_StripeX, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_StripeY, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Table.SuspendLayout()
        CType(Me.NumericUpDown_V, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_H, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView_V, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView_H, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_Operation.SuspendLayout()
        CType(Me.NumericUpDown_Pitch, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GBX_L6A.SuspendLayout()
        Me.GroupBox_CNT.SuspendLayout()
        CType(Me.NUD_FramExtend, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_CNTThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_CNTThreshold, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NUD_FilterNum, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ManualOffsetDate, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_ManualOffsetGate, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox_H
        '
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_MinDistH)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_StripeThresholdH)
        Me.GroupBox_H.Controls.Add(Me.Label_MinDistH)
        Me.GroupBox_H.Controls.Add(Me.NumericUpDown_EdgeThresholdH)
        Me.GroupBox_H.Controls.Add(Me.Label_StripeThresholdH)
        Me.GroupBox_H.Controls.Add(Me.Label_EdgeThresholdH)
        Me.GroupBox_H.Location = New System.Drawing.Point(250, 222)
        Me.GroupBox_H.Name = "GroupBox_H"
        Me.GroupBox_H.Size = New System.Drawing.Size(232, 97)
        Me.GroupBox_H.TabIndex = 71
        Me.GroupBox_H.TabStop = False
        Me.GroupBox_H.Text = "Data��V�v���B�z"
        '
        'NumericUpDown_MinDistH
        '
        Me.NumericUpDown_MinDistH.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDown_MinDistH.Location = New System.Drawing.Point(122, 68)
        Me.NumericUpDown_MinDistH.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MinDistH.Name = "NumericUpDown_MinDistH"
        Me.NumericUpDown_MinDistH.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_MinDistH.TabIndex = 66
        Me.NumericUpDown_MinDistH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_MinDistH.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_StripeThresholdH
        '
        Me.NumericUpDown_StripeThresholdH.DecimalPlaces = 1
        Me.NumericUpDown_StripeThresholdH.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDown_StripeThresholdH.Location = New System.Drawing.Point(122, 43)
        Me.NumericUpDown_StripeThresholdH.Name = "NumericUpDown_StripeThresholdH"
        Me.NumericUpDown_StripeThresholdH.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_StripeThresholdH.TabIndex = 22
        Me.NumericUpDown_StripeThresholdH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_MinDistH
        '
        Me.Label_MinDistH.Location = New System.Drawing.Point(8, 68)
        Me.Label_MinDistH.Name = "Label_MinDistH"
        Me.Label_MinDistH.Size = New System.Drawing.Size(110, 23)
        Me.Label_MinDistH.TabIndex = 65
        Me.Label_MinDistH.Text = "�̤p���j :"
        Me.Label_MinDistH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_EdgeThresholdH
        '
        Me.NumericUpDown_EdgeThresholdH.DecimalPlaces = 1
        Me.NumericUpDown_EdgeThresholdH.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDown_EdgeThresholdH.Location = New System.Drawing.Point(122, 18)
        Me.NumericUpDown_EdgeThresholdH.Name = "NumericUpDown_EdgeThresholdH"
        Me.NumericUpDown_EdgeThresholdH.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_EdgeThresholdH.TabIndex = 20
        Me.NumericUpDown_EdgeThresholdH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_StripeThresholdH
        '
        Me.Label_StripeThresholdH.Location = New System.Drawing.Point(8, 40)
        Me.Label_StripeThresholdH.Name = "Label_StripeThresholdH"
        Me.Label_StripeThresholdH.Size = New System.Drawing.Size(110, 23)
        Me.Label_StripeThresholdH.TabIndex = 21
        Me.Label_StripeThresholdH.Text = "Edge Threshold :"
        Me.Label_StripeThresholdH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_EdgeThresholdH
        '
        Me.Label_EdgeThresholdH.Location = New System.Drawing.Point(6, 17)
        Me.Label_EdgeThresholdH.Name = "Label_EdgeThresholdH"
        Me.Label_EdgeThresholdH.Size = New System.Drawing.Size(112, 23)
        Me.Label_EdgeThresholdH.TabIndex = 19
        Me.Label_EdgeThresholdH.Text = "First Edge Threshold :"
        Me.Label_EdgeThresholdH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_V
        '
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_MinDistV)
        Me.GroupBox_V.Controls.Add(Me.Label_MinDistV)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_StripeThresholdV)
        Me.GroupBox_V.Controls.Add(Me.NumericUpDown_EdgeThresholdV)
        Me.GroupBox_V.Controls.Add(Me.Label_StripeThresholdV)
        Me.GroupBox_V.Controls.Add(Me.Label_EdgeThresholdV)
        Me.GroupBox_V.Location = New System.Drawing.Point(2, 217)
        Me.GroupBox_V.Name = "GroupBox_V"
        Me.GroupBox_V.Size = New System.Drawing.Size(240, 103)
        Me.GroupBox_V.TabIndex = 70
        Me.GroupBox_V.TabStop = False
        Me.GroupBox_V.Text = "Gate��V�v���B�z"
        '
        'NumericUpDown_MinDistV
        '
        Me.NumericUpDown_MinDistV.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDown_MinDistV.Location = New System.Drawing.Point(129, 68)
        Me.NumericUpDown_MinDistV.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_MinDistV.Name = "NumericUpDown_MinDistV"
        Me.NumericUpDown_MinDistV.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_MinDistV.TabIndex = 64
        Me.NumericUpDown_MinDistV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_MinDistV.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_MinDistV
        '
        Me.Label_MinDistV.Location = New System.Drawing.Point(8, 70)
        Me.Label_MinDistV.Name = "Label_MinDistV"
        Me.Label_MinDistV.Size = New System.Drawing.Size(110, 23)
        Me.Label_MinDistV.TabIndex = 63
        Me.Label_MinDistV.Text = "�̤p���j :"
        Me.Label_MinDistV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_StripeThresholdV
        '
        Me.NumericUpDown_StripeThresholdV.DecimalPlaces = 1
        Me.NumericUpDown_StripeThresholdV.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDown_StripeThresholdV.Location = New System.Drawing.Point(129, 43)
        Me.NumericUpDown_StripeThresholdV.Name = "NumericUpDown_StripeThresholdV"
        Me.NumericUpDown_StripeThresholdV.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_StripeThresholdV.TabIndex = 22
        Me.NumericUpDown_StripeThresholdV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_EdgeThresholdV
        '
        Me.NumericUpDown_EdgeThresholdV.DecimalPlaces = 1
        Me.NumericUpDown_EdgeThresholdV.Increment = New Decimal(New Integer() {5, 0, 0, 65536})
        Me.NumericUpDown_EdgeThresholdV.Location = New System.Drawing.Point(129, 17)
        Me.NumericUpDown_EdgeThresholdV.Name = "NumericUpDown_EdgeThresholdV"
        Me.NumericUpDown_EdgeThresholdV.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_EdgeThresholdV.TabIndex = 20
        Me.NumericUpDown_EdgeThresholdV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label_StripeThresholdV
        '
        Me.Label_StripeThresholdV.Location = New System.Drawing.Point(8, 42)
        Me.Label_StripeThresholdV.Name = "Label_StripeThresholdV"
        Me.Label_StripeThresholdV.Size = New System.Drawing.Size(110, 23)
        Me.Label_StripeThresholdV.TabIndex = 21
        Me.Label_StripeThresholdV.Text = "Edge Threshold :"
        Me.Label_StripeThresholdV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_EdgeThresholdV
        '
        Me.Label_EdgeThresholdV.Location = New System.Drawing.Point(6, 19)
        Me.Label_EdgeThresholdV.Name = "Label_EdgeThresholdV"
        Me.Label_EdgeThresholdV.Size = New System.Drawing.Size(112, 23)
        Me.Label_EdgeThresholdV.TabIndex = 19
        Me.Label_EdgeThresholdV.Text = "First Edge Threshold :"
        Me.Label_EdgeThresholdV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_Step
        '
        Me.GroupBox_Step.Controls.Add(Me.Label5)
        Me.GroupBox_Step.Controls.Add(Me.ROIExtension)
        Me.GroupBox_Step.Controls.Add(Me.NumericUpDown_Width)
        Me.GroupBox_Step.Controls.Add(Me.Label_Width)
        Me.GroupBox_Step.Controls.Add(Me.Label_Hight)
        Me.GroupBox_Step.Controls.Add(Me.NumericUpDown_Hight)
        Me.GroupBox_Step.Location = New System.Drawing.Point(2, 115)
        Me.GroupBox_Step.Name = "GroupBox_Step"
        Me.GroupBox_Step.Size = New System.Drawing.Size(240, 91)
        Me.GroupBox_Step.TabIndex = 69
        Me.GroupBox_Step.TabStop = False
        Me.GroupBox_Step.Text = "�v���B�z�]�w"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(8, 62)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(118, 23)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "����X�i�e��(����) :"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ROIExtension
        '
        Me.ROIExtension.Location = New System.Drawing.Point(130, 62)
        Me.ROIExtension.Maximum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.ROIExtension.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.ROIExtension.Name = "ROIExtension"
        Me.ROIExtension.Size = New System.Drawing.Size(102, 22)
        Me.ROIExtension.TabIndex = 22
        Me.ROIExtension.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ROIExtension.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_Width
        '
        Me.NumericUpDown_Width.Location = New System.Drawing.Point(130, 16)
        Me.NumericUpDown_Width.Maximum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.NumericUpDown_Width.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Width.Name = "NumericUpDown_Width"
        Me.NumericUpDown_Width.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_Width.TabIndex = 18
        Me.NumericUpDown_Width.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_Width.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_Width
        '
        Me.Label_Width.Location = New System.Drawing.Point(8, 16)
        Me.Label_Width.Name = "Label_Width"
        Me.Label_Width.Size = New System.Drawing.Size(110, 23)
        Me.Label_Width.TabIndex = 17
        Me.Label_Width.Text = "�v���B�z�e�פj�p :"
        Me.Label_Width.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_Hight
        '
        Me.Label_Hight.Location = New System.Drawing.Point(8, 39)
        Me.Label_Hight.Name = "Label_Hight"
        Me.Label_Hight.Size = New System.Drawing.Size(110, 23)
        Me.Label_Hight.TabIndex = 19
        Me.Label_Hight.Text = "�v���B�z���פj�p :"
        Me.Label_Hight.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_Hight
        '
        Me.NumericUpDown_Hight.Location = New System.Drawing.Point(130, 39)
        Me.NumericUpDown_Hight.Maximum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.NumericUpDown_Hight.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_Hight.Name = "NumericUpDown_Hight"
        Me.NumericUpDown_Hight.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_Hight.TabIndex = 20
        Me.NumericUpDown_Hight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_Hight.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'GroupBox_Stripe
        '
        Me.GroupBox_Stripe.Controls.Add(Me.NumericUpDown_StripeX)
        Me.GroupBox_Stripe.Controls.Add(Me.Label_StripeX)
        Me.GroupBox_Stripe.Controls.Add(Me.Label_StripeY)
        Me.GroupBox_Stripe.Controls.Add(Me.NumericUpDown_StripeY)
        Me.GroupBox_Stripe.Location = New System.Drawing.Point(250, 66)
        Me.GroupBox_Stripe.Name = "GroupBox_Stripe"
        Me.GroupBox_Stripe.Size = New System.Drawing.Size(232, 72)
        Me.GroupBox_Stripe.TabIndex = 68
        Me.GroupBox_Stripe.TabStop = False
        Me.GroupBox_Stripe.Text = "���q���R�]�w"
        '
        'NumericUpDown_StripeX
        '
        Me.NumericUpDown_StripeX.Location = New System.Drawing.Point(122, 16)
        Me.NumericUpDown_StripeX.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_StripeX.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_StripeX.Name = "NumericUpDown_StripeX"
        Me.NumericUpDown_StripeX.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_StripeX.TabIndex = 18
        Me.NumericUpDown_StripeX.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_StripeX.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_StripeX
        '
        Me.Label_StripeX.Location = New System.Drawing.Point(8, 16)
        Me.Label_StripeX.Name = "Label_StripeX"
        Me.Label_StripeX.Size = New System.Drawing.Size(110, 23)
        Me.Label_StripeX.TabIndex = 17
        Me.Label_StripeX.Text = "X��V���q�ƶq :"
        Me.Label_StripeX.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_StripeY
        '
        Me.Label_StripeY.Location = New System.Drawing.Point(8, 37)
        Me.Label_StripeY.Name = "Label_StripeY"
        Me.Label_StripeY.Size = New System.Drawing.Size(110, 23)
        Me.Label_StripeY.TabIndex = 19
        Me.Label_StripeY.Text = "Y��V���q�ƶq :"
        Me.Label_StripeY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_StripeY
        '
        Me.NumericUpDown_StripeY.Location = New System.Drawing.Point(122, 40)
        Me.NumericUpDown_StripeY.Maximum = New Decimal(New Integer() {20000, 0, 0, 0})
        Me.NumericUpDown_StripeY.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_StripeY.Name = "NumericUpDown_StripeY"
        Me.NumericUpDown_StripeY.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_StripeY.TabIndex = 20
        Me.NumericUpDown_StripeY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_StripeY.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'GroupBox_Table
        '
        Me.GroupBox_Table.Controls.Add(Me.NumericUpDown_V)
        Me.GroupBox_Table.Controls.Add(Me.Label_V)
        Me.GroupBox_Table.Controls.Add(Me.Label_H)
        Me.GroupBox_Table.Controls.Add(Me.NumericUpDown_H)
        Me.GroupBox_Table.Location = New System.Drawing.Point(250, 144)
        Me.GroupBox_Table.Name = "GroupBox_Table"
        Me.GroupBox_Table.Size = New System.Drawing.Size(232, 72)
        Me.GroupBox_Table.TabIndex = 67
        Me.GroupBox_Table.TabStop = False
        Me.GroupBox_Table.Text = "Table (Data / Gate) �ƶq�]�w"
        '
        'NumericUpDown_V
        '
        Me.NumericUpDown_V.Location = New System.Drawing.Point(122, 16)
        Me.NumericUpDown_V.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_V.Name = "NumericUpDown_V"
        Me.NumericUpDown_V.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_V.TabIndex = 18
        Me.NumericUpDown_V.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_V.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label_V
        '
        Me.Label_V.Location = New System.Drawing.Point(6, 16)
        Me.Label_V.Name = "Label_V"
        Me.Label_V.Size = New System.Drawing.Size(118, 23)
        Me.Label_V.TabIndex = 17
        Me.Label_V.Text = "Gate��VPixel�ƶq :"
        Me.Label_V.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_H
        '
        Me.Label_H.Location = New System.Drawing.Point(6, 39)
        Me.Label_H.Name = "Label_H"
        Me.Label_H.Size = New System.Drawing.Size(116, 23)
        Me.Label_H.TabIndex = 19
        Me.Label_H.Text = "Data��VPixel�ƶq :"
        Me.Label_H.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'NumericUpDown_H
        '
        Me.NumericUpDown_H.Location = New System.Drawing.Point(122, 40)
        Me.NumericUpDown_H.Maximum = New Decimal(New Integer() {10000, 0, 0, 0})
        Me.NumericUpDown_H.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_H.Name = "NumericUpDown_H"
        Me.NumericUpDown_H.Size = New System.Drawing.Size(102, 22)
        Me.NumericUpDown_H.TabIndex = 20
        Me.NumericUpDown_H.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NumericUpDown_H.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'ComboBox_Type
        '
        Me.ComboBox_Type.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Type.Items.AddRange(New Object() {"���W", "���U", "�k�W", "�k�U", "���W�k", "���k", "���U�k"})
        Me.ComboBox_Type.Location = New System.Drawing.Point(128, 55)
        Me.ComboBox_Type.Name = "ComboBox_Type"
        Me.ComboBox_Type.Size = New System.Drawing.Size(102, 20)
        Me.ComboBox_Type.TabIndex = 65
        '
        'Label_Type
        '
        Me.Label_Type.AutoSize = True
        Me.Label_Type.Location = New System.Drawing.Point(39, 59)
        Me.Label_Type.Name = "Label_Type"
        Me.Label_Type.Size = New System.Drawing.Size(61, 12)
        Me.Label_Type.TabIndex = 64
        Me.Label_Type.Text = "Table���� :"
        Me.Label_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Button_Close
        '
        Me.Button_Close.Location = New System.Drawing.Point(545, 653)
        Me.Button_Close.Name = "Button_Close"
        Me.Button_Close.Size = New System.Drawing.Size(48, 23)
        Me.Button_Close.TabIndex = 95
        Me.Button_Close.Text = "Close"
        '
        'Button_Save
        '
        Me.Button_Save.Location = New System.Drawing.Point(487, 653)
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.Size = New System.Drawing.Size(48, 23)
        Me.Button_Save.TabIndex = 94
        Me.Button_Save.Text = "Save"
        '
        'ListView_H
        '
        Me.ListView_H.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_IndexH, Me.ColumnHeader_StripeH, Me.ColumnHeader_AvgH, Me.ColumnHeader_MaxH, Me.ColumnHeader_MinH})
        Me.ListView_H.FullRowSelect = True
        Me.ListView_H.GridLines = True
        Me.ListView_H.Location = New System.Drawing.Point(248, 391)
        Me.ListView_H.MultiSelect = False
        Me.ListView_H.Name = "ListView_H"
        Me.ListView_H.Size = New System.Drawing.Size(230, 128)
        Me.ListView_H.TabIndex = 90
        Me.ListView_H.UseCompatibleStateImageBehavior = False
        Me.ListView_H.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_IndexH
        '
        Me.ColumnHeader_IndexH.Text = "Seq."
        Me.ColumnHeader_IndexH.Width = 35
        '
        'ColumnHeader_StripeH
        '
        Me.ColumnHeader_StripeH.Text = "Stripe"
        Me.ColumnHeader_StripeH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_StripeH.Width = 50
        '
        'ColumnHeader_AvgH
        '
        Me.ColumnHeader_AvgH.Text = "Avg."
        Me.ColumnHeader_AvgH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_AvgH.Width = 45
        '
        'ColumnHeader_MaxH
        '
        Me.ColumnHeader_MaxH.Text = "Max"
        Me.ColumnHeader_MaxH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_MaxH.Width = 45
        '
        'ColumnHeader_MinH
        '
        Me.ColumnHeader_MinH.Text = "Min"
        Me.ColumnHeader_MinH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_MinH.Width = 45
        '
        'ListView_V
        '
        Me.ListView_V.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader_IndexV, Me.ColumnHeader_StripeV, Me.ColumnHeader_AvgV, Me.ColumnHeader_MaxV, Me.ColumnHeader_MinV})
        Me.ListView_V.FullRowSelect = True
        Me.ListView_V.GridLines = True
        Me.ListView_V.Location = New System.Drawing.Point(12, 391)
        Me.ListView_V.MultiSelect = False
        Me.ListView_V.Name = "ListView_V"
        Me.ListView_V.Size = New System.Drawing.Size(230, 128)
        Me.ListView_V.TabIndex = 89
        Me.ListView_V.UseCompatibleStateImageBehavior = False
        Me.ListView_V.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader_IndexV
        '
        Me.ColumnHeader_IndexV.Text = "Seq."
        Me.ColumnHeader_IndexV.Width = 35
        '
        'ColumnHeader_StripeV
        '
        Me.ColumnHeader_StripeV.Text = "Stripe"
        Me.ColumnHeader_StripeV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_StripeV.Width = 50
        '
        'ColumnHeader_AvgV
        '
        Me.ColumnHeader_AvgV.Text = "Avg."
        Me.ColumnHeader_AvgV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_AvgV.Width = 45
        '
        'ColumnHeader_MaxV
        '
        Me.ColumnHeader_MaxV.Text = "Max."
        Me.ColumnHeader_MaxV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_MaxV.Width = 45
        '
        'ColumnHeader_MinV
        '
        Me.ColumnHeader_MinV.Text = "Min."
        Me.ColumnHeader_MinV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.ColumnHeader_MinV.Width = 45
        '
        'DataGridView_V
        '
        Me.DataGridView_V.AllowUserToAddRows = False
        Me.DataGridView_V.AllowUserToDeleteRows = False
        Me.DataGridView_V.AllowUserToResizeColumns = False
        Me.DataGridView_V.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("PMingLiU", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView_V.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView_V.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("PMingLiU", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView_V.DefaultCellStyle = DataGridViewCellStyle2
        Me.DataGridView_V.Location = New System.Drawing.Point(12, 525)
        Me.DataGridView_V.Name = "DataGridView_V"
        Me.DataGridView_V.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("PMingLiU", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView_V.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.DataGridView_V.RowHeadersVisible = False
        Me.DataGridView_V.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.DataGridView_V.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridView_V.RowTemplate.Height = 15
        Me.DataGridView_V.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView_V.Size = New System.Drawing.Size(230, 123)
        Me.DataGridView_V.TabIndex = 101
        '
        'DataGridView_H
        '
        Me.DataGridView_H.AllowUserToAddRows = False
        Me.DataGridView_H.AllowUserToDeleteRows = False
        Me.DataGridView_H.AllowUserToResizeColumns = False
        Me.DataGridView_H.AllowUserToResizeRows = False
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("PMingLiU", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView_H.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DataGridView_H.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle5.Font = New System.Drawing.Font("PMingLiU", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView_H.DefaultCellStyle = DataGridViewCellStyle5
        Me.DataGridView_H.Location = New System.Drawing.Point(248, 525)
        Me.DataGridView_H.Name = "DataGridView_H"
        Me.DataGridView_H.ReadOnly = True
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("PMingLiU", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView_H.RowHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.DataGridView_H.RowHeadersVisible = False
        Me.DataGridView_H.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.DataGridView_H.RowTemplate.DefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight
        Me.DataGridView_H.RowTemplate.Height = 15
        Me.DataGridView_H.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView_H.Size = New System.Drawing.Size(230, 123)
        Me.DataGridView_H.TabIndex = 102
        '
        'Label_ResultV
        '
        Me.Label_ResultV.Location = New System.Drawing.Point(12, 369)
        Me.Label_ResultV.Name = "Label_ResultV"
        Me.Label_ResultV.Size = New System.Drawing.Size(232, 23)
        Me.Label_ResultV.TabIndex = 103
        Me.Label_ResultV.Text = "������V���R���G :"
        Me.Label_ResultV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label_ResultH
        '
        Me.Label_ResultH.Location = New System.Drawing.Point(246, 368)
        Me.Label_ResultH.Name = "Label_ResultH"
        Me.Label_ResultH.Size = New System.Drawing.Size(232, 23)
        Me.Label_ResultH.TabIndex = 104
        Me.Label_ResultH.Text = "������V���R���G :"
        Me.Label_ResultH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox_Operation
        '
        Me.GroupBox_Operation.Controls.Add(Me.Button_ClearMappingTable)
        Me.GroupBox_Operation.Controls.Add(Me.Button_Calculate)
        Me.GroupBox_Operation.Controls.Add(Me.Button_SaveMappingTable)
        Me.GroupBox_Operation.Controls.Add(Me.Button_LoadMT)
        Me.GroupBox_Operation.Location = New System.Drawing.Point(2, 321)
        Me.GroupBox_Operation.Name = "GroupBox_Operation"
        Me.GroupBox_Operation.Size = New System.Drawing.Size(480, 50)
        Me.GroupBox_Operation.TabIndex = 118
        Me.GroupBox_Operation.TabStop = False
        '
        'Button_ClearMappingTable
        '
        Me.Button_ClearMappingTable.Location = New System.Drawing.Point(246, 19)
        Me.Button_ClearMappingTable.Name = "Button_ClearMappingTable"
        Me.Button_ClearMappingTable.Size = New System.Drawing.Size(112, 23)
        Me.Button_ClearMappingTable.TabIndex = 121
        Me.Button_ClearMappingTable.Text = "�M��Mapping Table"
        Me.Button_ClearMappingTable.UseVisualStyleBackColor = True
        '
        'Button_Calculate
        '
        Me.Button_Calculate.Location = New System.Drawing.Point(12, 19)
        Me.Button_Calculate.Name = "Button_Calculate"
        Me.Button_Calculate.Size = New System.Drawing.Size(112, 23)
        Me.Button_Calculate.TabIndex = 118
        Me.Button_Calculate.Text = "�p��Mapping Table"
        '
        'Button_SaveMappingTable
        '
        Me.Button_SaveMappingTable.Location = New System.Drawing.Point(130, 18)
        Me.Button_SaveMappingTable.Name = "Button_SaveMappingTable"
        Me.Button_SaveMappingTable.Size = New System.Drawing.Size(110, 23)
        Me.Button_SaveMappingTable.TabIndex = 120
        Me.Button_SaveMappingTable.Text = "�x�sMapping Table"
        Me.Button_SaveMappingTable.UseVisualStyleBackColor = True
        '
        'Button_LoadMT
        '
        Me.Button_LoadMT.Location = New System.Drawing.Point(362, 19)
        Me.Button_LoadMT.Name = "Button_LoadMT"
        Me.Button_LoadMT.Size = New System.Drawing.Size(110, 23)
        Me.Button_LoadMT.TabIndex = 119
        Me.Button_LoadMT.Text = "���JMapping Table"
        '
        'NumericUpDown_Pitch
        '
        Me.NumericUpDown_Pitch.Location = New System.Drawing.Point(162, 80)
        Me.NumericUpDown_Pitch.Name = "NumericUpDown_Pitch"
        Me.NumericUpDown_Pitch.Size = New System.Drawing.Size(68, 22)
        Me.NumericUpDown_Pitch.TabIndex = 119
        Me.NumericUpDown_Pitch.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(66, 85)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 12)
        Me.Label1.TabIndex = 120
        Me.Label1.Text = "Pitch :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(76, 12)
        Me.Label3.TabIndex = 123
        Me.Label3.Text = "SubPixel���� :"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_SubPixelMode
        '
        Me.ComboBox_SubPixelMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_SubPixelMode.Items.AddRange(New Object() {"Normal", "RGBW", "TriGate"})
        Me.ComboBox_SubPixelMode.Location = New System.Drawing.Point(128, 31)
        Me.ComboBox_SubPixelMode.Name = "ComboBox_SubPixelMode"
        Me.ComboBox_SubPixelMode.Size = New System.Drawing.Size(102, 20)
        Me.ComboBox_SubPixelMode.TabIndex = 124
        '
        'GBX_L6A
        '
        Me.GBX_L6A.Controls.Add(Me.Button_LoadImage)
        Me.GBX_L6A.Controls.Add(Me.TXB_EdgeWidth)
        Me.GBX_L6A.Controls.Add(Me.Label10)
        Me.GBX_L6A.Controls.Add(Me.CheckBox_Preprocess)
        Me.GBX_L6A.Controls.Add(Me.GroupBox_CNT)
        Me.GBX_L6A.Enabled = False
        Me.GBX_L6A.Location = New System.Drawing.Point(488, 177)
        Me.GBX_L6A.Name = "GBX_L6A"
        Me.GBX_L6A.Size = New System.Drawing.Size(222, 218)
        Me.GBX_L6A.TabIndex = 129
        Me.GBX_L6A.TabStop = False
        Me.GBX_L6A.Text = "CCD����270 Angle"
        '
        'Button_LoadImage
        '
        Me.Button_LoadImage.Location = New System.Drawing.Point(20, 186)
        Me.Button_LoadImage.Name = "Button_LoadImage"
        Me.Button_LoadImage.Size = New System.Drawing.Size(75, 23)
        Me.Button_LoadImage.TabIndex = 140
        Me.Button_LoadImage.Text = "���J����"
        Me.Button_LoadImage.UseVisualStyleBackColor = True
        '
        'TXB_EdgeWidth
        '
        Me.TXB_EdgeWidth.Location = New System.Drawing.Point(105, 16)
        Me.TXB_EdgeWidth.Name = "TXB_EdgeWidth"
        Me.TXB_EdgeWidth.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TXB_EdgeWidth.Size = New System.Drawing.Size(100, 22)
        Me.TXB_EdgeWidth.TabIndex = 126
        Me.TXB_EdgeWidth.Text = "50"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(24, 21)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 12)
        Me.Label10.TabIndex = 125
        Me.Label10.Text = "��t�j�M�e��:"
        '
        'CheckBox_Preprocess
        '
        Me.CheckBox_Preprocess.AutoSize = True
        Me.CheckBox_Preprocess.Location = New System.Drawing.Point(120, 190)
        Me.CheckBox_Preprocess.Name = "CheckBox_Preprocess"
        Me.CheckBox_Preprocess.Size = New System.Drawing.Size(92, 16)
        Me.CheckBox_Preprocess.TabIndex = 134
        Me.CheckBox_Preprocess.Text = "�e�B�zEnable"
        Me.CheckBox_Preprocess.UseVisualStyleBackColor = True
        '
        'GroupBox_CNT
        '
        Me.GroupBox_CNT.Controls.Add(Me.CheckBox_CNT_Display)
        Me.GroupBox_CNT.Controls.Add(Me.Label1_CNT_Status)
        Me.GroupBox_CNT.Controls.Add(Me.Label11)
        Me.GroupBox_CNT.Controls.Add(Me.NUD_FramExtend)
        Me.GroupBox_CNT.Controls.Add(Me.Btn_CNTCheck)
        Me.GroupBox_CNT.Controls.Add(Me.NUD_CNTThreshold)
        Me.GroupBox_CNT.Controls.Add(Me.TrackBar_CNTThreshold)
        Me.GroupBox_CNT.Location = New System.Drawing.Point(11, 44)
        Me.GroupBox_CNT.Name = "GroupBox_CNT"
        Me.GroupBox_CNT.Size = New System.Drawing.Size(200, 135)
        Me.GroupBox_CNT.TabIndex = 138
        Me.GroupBox_CNT.TabStop = False
        Me.GroupBox_CNT.Text = "CCD2��״���"
        '
        'CheckBox_CNT_Display
        '
        Me.CheckBox_CNT_Display.AutoSize = True
        Me.CheckBox_CNT_Display.Location = New System.Drawing.Point(14, 55)
        Me.CheckBox_CNT_Display.Name = "CheckBox_CNT_Display"
        Me.CheckBox_CNT_Display.Size = New System.Drawing.Size(96, 16)
        Me.CheckBox_CNT_Display.TabIndex = 141
        Me.CheckBox_CNT_Display.Text = "��ܦ��İϰ�"
        Me.CheckBox_CNT_Display.UseVisualStyleBackColor = True
        '
        'Label1_CNT_Status
        '
        Me.Label1_CNT_Status.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Label1_CNT_Status.AutoSize = True
        Me.Label1_CNT_Status.ForeColor = System.Drawing.Color.Blue
        Me.Label1_CNT_Status.Location = New System.Drawing.Point(10, 111)
        Me.Label1_CNT_Status.Name = "Label1_CNT_Status"
        Me.Label1_CNT_Status.Size = New System.Drawing.Size(89, 12)
        Me.Label1_CNT_Status.TabIndex = 140
        Me.Label1_CNT_Status.Text = "Connection Status"
        Me.Label1_CNT_Status.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(13, 81)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(86, 12)
        Me.Label11.TabIndex = 139
        Me.Label11.Text = "����X�i�e�� : "
        '
        'NUD_FramExtend
        '
        Me.NUD_FramExtend.Location = New System.Drawing.Point(142, 75)
        Me.NUD_FramExtend.Maximum = New Decimal(New Integer() {254, 0, 0, 0})
        Me.NUD_FramExtend.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NUD_FramExtend.Name = "NUD_FramExtend"
        Me.NUD_FramExtend.Size = New System.Drawing.Size(50, 22)
        Me.NUD_FramExtend.TabIndex = 138
        Me.NUD_FramExtend.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NUD_FramExtend.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Btn_CNTCheck
        '
        Me.Btn_CNTCheck.Location = New System.Drawing.Point(119, 104)
        Me.Btn_CNTCheck.Name = "Btn_CNTCheck"
        Me.Btn_CNTCheck.Size = New System.Drawing.Size(75, 23)
        Me.Btn_CNTCheck.TabIndex = 134
        Me.Btn_CNTCheck.Text = "�s�q�T�{"
        Me.Btn_CNTCheck.UseVisualStyleBackColor = True
        '
        'NUD_CNTThreshold
        '
        Me.NUD_CNTThreshold.Location = New System.Drawing.Point(142, 24)
        Me.NUD_CNTThreshold.Maximum = New Decimal(New Integer() {254, 0, 0, 0})
        Me.NUD_CNTThreshold.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NUD_CNTThreshold.Name = "NUD_CNTThreshold"
        Me.NUD_CNTThreshold.Size = New System.Drawing.Size(50, 22)
        Me.NUD_CNTThreshold.TabIndex = 137
        Me.NUD_CNTThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NUD_CNTThreshold.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'TrackBar_CNTThreshold
        '
        Me.TrackBar_CNTThreshold.BackColor = System.Drawing.SystemColors.Control
        Me.TrackBar_CNTThreshold.Location = New System.Drawing.Point(11, 23)
        Me.TrackBar_CNTThreshold.Maximum = 254
        Me.TrackBar_CNTThreshold.Minimum = 1
        Me.TrackBar_CNTThreshold.Name = "TrackBar_CNTThreshold"
        Me.TrackBar_CNTThreshold.Size = New System.Drawing.Size(122, 45)
        Me.TrackBar_CNTThreshold.TabIndex = 135
        Me.TrackBar_CNTThreshold.TickFrequency = 495
        Me.TrackBar_CNTThreshold.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_CNTThreshold.Value = 50
        '
        'Label_CCD_FilterNum
        '
        Me.Label_CCD_FilterNum.AutoSize = True
        Me.Label_CCD_FilterNum.Location = New System.Drawing.Point(513, 62)
        Me.Label_CCD_FilterNum.Name = "Label_CCD_FilterNum"
        Me.Label_CCD_FilterNum.Size = New System.Drawing.Size(80, 12)
        Me.Label_CCD_FilterNum.TabIndex = 120
        Me.Label_CCD_FilterNum.Text = "CCD�o�i����:"
        '
        'NUD_FilterNum
        '
        Me.NUD_FilterNum.Location = New System.Drawing.Point(597, 57)
        Me.NUD_FilterNum.Maximum = New Decimal(New Integer() {500, 0, 0, 0})
        Me.NUD_FilterNum.Name = "NUD_FilterNum"
        Me.NUD_FilterNum.Size = New System.Drawing.Size(102, 22)
        Me.NUD_FilterNum.TabIndex = 23
        Me.NUD_FilterNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.NUD_FilterNum.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'TXB_LCDH
        '
        Me.TXB_LCDH.Location = New System.Drawing.Point(372, 1)
        Me.TXB_LCDH.Name = "TXB_LCDH"
        Me.TXB_LCDH.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TXB_LCDH.Size = New System.Drawing.Size(100, 22)
        Me.TXB_LCDH.TabIndex = 124
        Me.TXB_LCDH.Text = "1366"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(257, 7)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(103, 12)
        Me.Label7.TabIndex = 123
        Me.Label7.Text = "���O����Pixel�`��:"
        '
        'TXB_CCD2
        '
        Me.TXB_CCD2.Location = New System.Drawing.Point(597, 30)
        Me.TXB_CCD2.Name = "TXB_CCD2"
        Me.TXB_CCD2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TXB_CCD2.Size = New System.Drawing.Size(100, 22)
        Me.TXB_CCD2.TabIndex = 122
        Me.TXB_CCD2.Text = "443"
        '
        'Label_CCD2_StartPosition_Of_3CCD
        '
        Me.Label_CCD2_StartPosition_Of_3CCD.AutoSize = True
        Me.Label_CCD2_StartPosition_Of_3CCD.Location = New System.Drawing.Point(508, 35)
        Me.Label_CCD2_StartPosition_Of_3CCD.Name = "Label_CCD2_StartPosition_Of_3CCD"
        Me.Label_CCD2_StartPosition_Of_3CCD.Size = New System.Drawing.Size(86, 12)
        Me.Label_CCD2_StartPosition_Of_3CCD.TabIndex = 121
        Me.Label_CCD2_StartPosition_Of_3CCD.Text = "CCD2�_�l��m:"
        '
        'CheckBox_ManualMark
        '
        Me.CheckBox_ManualMark.AutoSize = True
        Me.CheckBox_ManualMark.Location = New System.Drawing.Point(506, 7)
        Me.CheckBox_ManualMark.Name = "CheckBox_ManualMark"
        Me.CheckBox_ManualMark.Size = New System.Drawing.Size(87, 16)
        Me.CheckBox_ManualMark.TabIndex = 125
        Me.CheckBox_ManualMark.Text = "Manual Mark"
        Me.CheckBox_ManualMark.UseVisualStyleBackColor = True
        '
        'ComboBox_CCDMode
        '
        Me.ComboBox_CCDMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_CCDMode.Items.AddRange(New Object() {"1CCD", "2CCD", "3CCD", "4CCD", "9CCD"})
        Me.ComboBox_CCDMode.Location = New System.Drawing.Point(128, 7)
        Me.ComboBox_CCDMode.Name = "ComboBox_CCDMode"
        Me.ComboBox_CCDMode.Size = New System.Drawing.Size(102, 20)
        Me.ComboBox_CCDMode.TabIndex = 131
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(13, 5)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(118, 23)
        Me.Label8.TabIndex = 130
        Me.Label8.Text = "CCD���� :"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_MarkDirect
        '
        Me.ComboBox_MarkDirect.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_MarkDirect.Enabled = False
        Me.ComboBox_MarkDirect.Items.AddRange(New Object() {"Right", "Left"})
        Me.ComboBox_MarkDirect.Location = New System.Drawing.Point(597, 4)
        Me.ComboBox_MarkDirect.Name = "ComboBox_MarkDirect"
        Me.ComboBox_MarkDirect.Size = New System.Drawing.Size(63, 20)
        Me.ComboBox_MarkDirect.TabIndex = 134
        '
        'Label_Info
        '
        Me.Label_Info.AutoSize = True
        Me.Label_Info.Location = New System.Drawing.Point(10, 661)
        Me.Label_Info.Name = "Label_Info"
        Me.Label_Info.Size = New System.Drawing.Size(38, 12)
        Me.Label_Info.TabIndex = 135
        Me.Label_Info.Tag = " "
        Me.Label_Info.Text = "�T�� : "
        '
        'ComboBox_DataFreQ
        '
        Me.ComboBox_DataFreQ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_DataFreQ.Items.AddRange(New Object() {"1", "2", "3"})
        Me.ComboBox_DataFreQ.Location = New System.Drawing.Point(426, 24)
        Me.ComboBox_DataFreQ.Name = "ComboBox_DataFreQ"
        Me.ComboBox_DataFreQ.Size = New System.Drawing.Size(46, 20)
        Me.ComboBox_DataFreQ.TabIndex = 137
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(304, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 12)
        Me.Label2.TabIndex = 136
        Me.Label2.Text = "Data�g�� :"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ComboBox_GateFreQ
        '
        Me.ComboBox_GateFreQ.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_GateFreQ.Items.AddRange(New Object() {"1", "2", "3"})
        Me.ComboBox_GateFreQ.Location = New System.Drawing.Point(426, 46)
        Me.ComboBox_GateFreQ.Name = "ComboBox_GateFreQ"
        Me.ComboBox_GateFreQ.Size = New System.Drawing.Size(46, 20)
        Me.ComboBox_GateFreQ.TabIndex = 139
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(304, 46)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(56, 12)
        Me.Label12.TabIndex = 138
        Me.Label12.Text = "Gate�g�� :"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel1.Location = New System.Drawing.Point(491, 167)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(221, 2)
        Me.Panel1.TabIndex = 149
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(506, 115)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(86, 12)
        Me.Label14.TabIndex = 148
        Me.Label14.Text = "LaserGap Height:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(508, 89)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(84, 12)
        Me.Label13.TabIndex = 147
        Me.Label13.Text = "LaserGap Width:"
        '
        'TextBox_LaserGapHeight
        '
        Me.TextBox_LaserGapHeight.Location = New System.Drawing.Point(596, 110)
        Me.TextBox_LaserGapHeight.Name = "TextBox_LaserGapHeight"
        Me.TextBox_LaserGapHeight.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBox_LaserGapHeight.Size = New System.Drawing.Size(44, 22)
        Me.TextBox_LaserGapHeight.TabIndex = 146
        Me.TextBox_LaserGapHeight.Text = "1366"
        '
        'TextBox_LaserGapWidth
        '
        Me.TextBox_LaserGapWidth.Location = New System.Drawing.Point(596, 84)
        Me.TextBox_LaserGapWidth.Name = "TextBox_LaserGapWidth"
        Me.TextBox_LaserGapWidth.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TextBox_LaserGapWidth.Size = New System.Drawing.Size(44, 22)
        Me.TextBox_LaserGapWidth.TabIndex = 145
        Me.TextBox_LaserGapWidth.Text = "1366"
        '
        'TextBox_PanelResolutionY
        '
        Me.TextBox_PanelResolutionY.Location = New System.Drawing.Point(643, 138)
        Me.TextBox_PanelResolutionY.Name = "TextBox_PanelResolutionY"
        Me.TextBox_PanelResolutionY.Size = New System.Drawing.Size(55, 22)
        Me.TextBox_PanelResolutionY.TabIndex = 153
        Me.TextBox_PanelResolutionY.Text = "30"
        Me.TextBox_PanelResolutionY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox_PanelResolutionX
        '
        Me.TextBox_PanelResolutionX.Location = New System.Drawing.Point(574, 137)
        Me.TextBox_PanelResolutionX.Name = "TextBox_PanelResolutionX"
        Me.TextBox_PanelResolutionX.Size = New System.Drawing.Size(55, 22)
        Me.TextBox_PanelResolutionX.TabIndex = 152
        Me.TextBox_PanelResolutionX.Text = "30"
        Me.TextBox_PanelResolutionX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("PMingLiU", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label15.Location = New System.Drawing.Point(627, 140)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(19, 16)
        Me.Label15.TabIndex = 151
        Me.Label15.Text = "X"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(507, 142)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(61, 12)
        Me.Label16.TabIndex = 150
        Me.Label16.Text = "Resolution :"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel2.Location = New System.Drawing.Point(491, 418)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(221, 2)
        Me.Panel2.TabIndex = 150
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(504, 464)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(92, 12)
        Me.Label4.TabIndex = 155
        Me.Label4.Text = "ManualOffsetGate:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(504, 439)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(92, 12)
        Me.Label6.TabIndex = 154
        Me.Label6.Text = "ManualOffsetData:"
        '
        'NumericUpDown_ManualOffsetDate
        '
        Me.NumericUpDown_ManualOffsetDate.Location = New System.Drawing.Point(604, 432)
        Me.NumericUpDown_ManualOffsetDate.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.NumericUpDown_ManualOffsetDate.Name = "NumericUpDown_ManualOffsetDate"
        Me.NumericUpDown_ManualOffsetDate.Size = New System.Drawing.Size(58, 22)
        Me.NumericUpDown_ManualOffsetDate.TabIndex = 65
        Me.NumericUpDown_ManualOffsetDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'NumericUpDown_ManualOffsetGate
        '
        Me.NumericUpDown_ManualOffsetGate.Location = New System.Drawing.Point(604, 460)
        Me.NumericUpDown_ManualOffsetGate.Minimum = New Decimal(New Integer() {100, 0, 0, -2147483648})
        Me.NumericUpDown_ManualOffsetGate.Name = "NumericUpDown_ManualOffsetGate"
        Me.NumericUpDown_ManualOffsetGate.Size = New System.Drawing.Size(58, 22)
        Me.NumericUpDown_ManualOffsetGate.TabIndex = 156
        Me.NumericUpDown_ManualOffsetGate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Panel3.Location = New System.Drawing.Point(491, 488)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(221, 2)
        Me.Panel3.TabIndex = 157
        '
        'Dialog_SetMappingTable
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(729, 692)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.NumericUpDown_ManualOffsetGate)
        Me.Controls.Add(Me.NumericUpDown_ManualOffsetDate)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.TextBox_PanelResolutionY)
        Me.Controls.Add(Me.TextBox_PanelResolutionX)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TextBox_LaserGapHeight)
        Me.Controls.Add(Me.TextBox_LaserGapWidth)
        Me.Controls.Add(Me.ComboBox_GateFreQ)
        Me.Controls.Add(Me.Label_Info)
        Me.Controls.Add(Me.ComboBox_MarkDirect)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label_CCD_FilterNum)
        Me.Controls.Add(Me.NUD_FilterNum)
        Me.Controls.Add(Me.ComboBox_DataFreQ)
        Me.Controls.Add(Me.CheckBox_ManualMark)
        Me.Controls.Add(Me.TXB_LCDH)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ComboBox_CCDMode)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TXB_CCD2)
        Me.Controls.Add(Me.Label_CCD2_StartPosition_Of_3CCD)
        Me.Controls.Add(Me.GBX_L6A)
        Me.Controls.Add(Me.ComboBox_SubPixelMode)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.NumericUpDown_Pitch)
        Me.Controls.Add(Me.GroupBox_Operation)
        Me.Controls.Add(Me.Label_ResultH)
        Me.Controls.Add(Me.Label_ResultV)
        Me.Controls.Add(Me.DataGridView_H)
        Me.Controls.Add(Me.DataGridView_V)
        Me.Controls.Add(Me.Button_Close)
        Me.Controls.Add(Me.Button_Save)
        Me.Controls.Add(Me.ListView_H)
        Me.Controls.Add(Me.ListView_V)
        Me.Controls.Add(Me.GroupBox_H)
        Me.Controls.Add(Me.GroupBox_V)
        Me.Controls.Add(Me.GroupBox_Step)
        Me.Controls.Add(Me.GroupBox_Stripe)
        Me.Controls.Add(Me.GroupBox_Table)
        Me.Controls.Add(Me.ComboBox_Type)
        Me.Controls.Add(Me.Label_Type)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_SetMappingTable"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Mapping Table"
        Me.GroupBox_H.ResumeLayout(False)
        CType(Me.NumericUpDown_MinDistH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_StripeThresholdH, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_EdgeThresholdH, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_V.ResumeLayout(False)
        CType(Me.NumericUpDown_MinDistV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_StripeThresholdV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_EdgeThresholdV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Step.ResumeLayout(False)
        CType(Me.ROIExtension, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Width, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_Hight, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Stripe.ResumeLayout(False)
        CType(Me.NumericUpDown_StripeX, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_StripeY, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Table.ResumeLayout(False)
        CType(Me.NumericUpDown_V, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_H, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView_V, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView_H, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_Operation.ResumeLayout(False)
        CType(Me.NumericUpDown_Pitch, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GBX_L6A.ResumeLayout(False)
        Me.GBX_L6A.PerformLayout()
        Me.GroupBox_CNT.ResumeLayout(False)
        Me.GroupBox_CNT.PerformLayout()
        CType(Me.NUD_FramExtend, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_CNTThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_CNTThreshold, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NUD_FilterNum, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ManualOffsetDate, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_ManualOffsetGate, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox_H As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_MinDistH As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_StripeThresholdH As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_MinDistH As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_EdgeThresholdH As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_StripeThresholdH As System.Windows.Forms.Label
    Friend WithEvents Label_EdgeThresholdH As System.Windows.Forms.Label
    Friend WithEvents GroupBox_V As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_MinDistV As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_MinDistV As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_StripeThresholdV As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_EdgeThresholdV As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_StripeThresholdV As System.Windows.Forms.Label
    Friend WithEvents Label_EdgeThresholdV As System.Windows.Forms.Label
    Friend WithEvents GroupBox_Step As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_Width As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_Width As System.Windows.Forms.Label
    Friend WithEvents Label_Hight As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_Hight As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_Stripe As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_StripeX As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_StripeX As System.Windows.Forms.Label
    Friend WithEvents Label_StripeY As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_StripeY As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_Table As System.Windows.Forms.GroupBox
    Friend WithEvents NumericUpDown_V As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label_V As System.Windows.Forms.Label
    Friend WithEvents Label_H As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_H As System.Windows.Forms.NumericUpDown
    Friend WithEvents ComboBox_Type As System.Windows.Forms.ComboBox
    Friend WithEvents Label_Type As System.Windows.Forms.Label
    Friend WithEvents Button_Close As System.Windows.Forms.Button
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents ListView_H As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_IndexH As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_StripeH As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_AvgH As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MaxH As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MinH As System.Windows.Forms.ColumnHeader
    Friend WithEvents ListView_V As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader_IndexV As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_StripeV As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_AvgV As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MaxV As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader_MinV As System.Windows.Forms.ColumnHeader
    Friend WithEvents DataGridView_V As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridView_H As System.Windows.Forms.DataGridView
    Friend WithEvents Label_ResultV As System.Windows.Forms.Label
    Friend WithEvents Label_ResultH As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents ROIExtension As System.Windows.Forms.NumericUpDown
    Friend WithEvents GroupBox_Operation As System.Windows.Forms.GroupBox
    Friend WithEvents Button_ClearMappingTable As System.Windows.Forms.Button
    Friend WithEvents Button_Calculate As System.Windows.Forms.Button
    Friend WithEvents Button_SaveMappingTable As System.Windows.Forms.Button
    Friend WithEvents Button_LoadMT As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_Pitch As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_SubPixelMode As System.Windows.Forms.ComboBox
    Friend WithEvents GBX_L6A As System.Windows.Forms.GroupBox
    Friend WithEvents TXB_LCDH As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TXB_CCD2 As System.Windows.Forms.TextBox
    Friend WithEvents Label_CCD2_StartPosition_Of_3CCD As System.Windows.Forms.Label
    Friend WithEvents Label_CCD_FilterNum As System.Windows.Forms.Label
    Friend WithEvents NUD_FilterNum As System.Windows.Forms.NumericUpDown
    Friend WithEvents ComboBox_CCDMode As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TXB_EdgeWidth As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_ManualMark As System.Windows.Forms.CheckBox
    Friend WithEvents Btn_CNTCheck As System.Windows.Forms.Button
    Friend WithEvents TrackBar_CNTThreshold As System.Windows.Forms.TrackBar
    Friend WithEvents CheckBox_Preprocess As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox_CNT As System.Windows.Forms.GroupBox
    Friend WithEvents NUD_CNTThreshold As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents NUD_FramExtend As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_LoadImage As System.Windows.Forms.Button
    Friend WithEvents Label1_CNT_Status As System.Windows.Forms.Label
    Friend WithEvents CheckBox_CNT_Display As System.Windows.Forms.CheckBox
    Friend WithEvents ComboBox_MarkDirect As System.Windows.Forms.ComboBox
    Friend WithEvents Label_Info As System.Windows.Forms.Label
    Friend WithEvents ComboBox_DataFreQ As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_GateFreQ As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox_LaserGapHeight As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_LaserGapWidth As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_PanelResolutionY As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_PanelResolutionX As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ManualOffsetDate As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_ManualOffsetGate As System.Windows.Forms.NumericUpDown
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
End Class
