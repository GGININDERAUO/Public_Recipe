﻿
'--- Imports --- 
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL

Imports ClassLibrary
Imports MILOperationLib

Imports AUO.SubSystemControl

Imports System.IO
Imports System.Net
Imports System.Text
Imports System.Resources
Imports System.Threading
Imports System.Globalization


Public Class Main_Form

#Region "--- Parameters ---"

    Dim Main_Form As Object

    '--- Additional Library ---
    Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Integer) As Short
    Private Declare Function FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr
    Private Declare Function PostMessage Lib "user32" Alias "PostMessageA" (ByVal Hwnd As Integer, ByVal wMsg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Private Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long)

    '--- Key Define ---
    Private Const KEYEVENTF_KEYUP = &H2
    Private Const VK_CONTROL = &H11
    Private Const VK_LMENU = &HA4
    Private Const VK_O = &H4F

    '--- Process ---
    Private WithEvents m_MainProcess As ClsMainProcess        'MainProcss
    Private WithEvents m_MuraProcess As ClsMuraProcess        'MuraProcess

    '--- Display ---
    Private m_AxMDisplay As MIL_ID   ' MIL Display identifier.
    Private m_ZoomFactor As Double
    Private m_ZoomMin As Double
    Private m_ZoomMax As Double
    Private m_MouseX As Integer
    Private m_MouseY As Integer
    Private m_PaintStop As Boolean = True
    Private m_MoveToCenter As Boolean = False
    Private m_MousreHScroll As Boolean = False
    Private m_PanelID As String = ""
    Private m_ViewBit As Integer

    '--- Image Update ---
    Private m_Img_Current As MIL_ID
    Private m_IsSetExpTimeFlag As Boolean
    Private m_CurrentIndex0 As Integer
    Private m_CurrentIndex1 As Integer
    Private m_CurrentIndex2 As Integer
    Private m_CurrentIndex3 As Integer

    ''------- Mura Dialog -------
    Friend WithEvents m_DialogMuraAutoManual As Dialog_MuraAutoManual
    Friend WithEvents m_DialogMuraBoundary As Dialog_MuraBoundary
    Friend WithEvents m_DialogMuraSmooth As Dialog_MuraSmooth
    Friend WithEvents m_DialogMuraCollection As Dialog_MuraCollection
    Friend WithEvents m_DialogBlobMuraLocal As Dialog_BlobMuraLocal
    Friend WithEvents m_DialogBlobMuraRound As Dialog_BlobMuraRound
    Friend WithEvents m_DialogBandMura As Dialog_BandMura
    Friend WithEvents m_DialogMuraJND As Dialog_MuraJND
    Friend WithEvents m_DialogMuraFalseDefect As Dialog_MuraFalseDefect
    Friend WithEvents m_DialogMuraResult As Dialog_MuraResult
    Friend WithEvents m_DialogMuraSettingBase As Dialog_MuraSettingBase
    Friend WithEvents m_DialogMuraSetting As Dialog_MuraSetting

    ''------- Func Dialog -------
    Friend WithEvents m_DialogFuncSettingBase As Dialog_FuncSettingBase
    Friend WithEvents m_DialogFuncSetting As Dialog_FuncSetting
    Friend WithEvents m_DialogADJMean As Dialog_ADJMean
    Friend WithEvents m_DialogFuncTestImgProc As Dialog_FuncTestImageProcess
    Friend WithEvents m_DialogFuncFalseDefect As Dialog_FuncFalseDefect
    Friend WithEvents m_DialogFuncResult As Dialog_FuncResult
    Friend WithEvents m_DialogSetMappingTable As Dialog_SetMappingTable
    Friend WithEvents m_DialogAlign As Dialog_Align
    Friend WithEvents m_DialogBarcodeSetting As Dialog_BarcodeSetting

    ''------- Recipe Dialog -------
    Friend WithEvents m_DialogIPNetWorkConfig As Dialog_IPNetWorkConfig
    Friend WithEvents m_DialogIPBootConfig As Dialog_IPBootConfig

    ''------- Measurement Dialog -------
    Friend WithEvents m_DialogCalculateMeasurement As Dialog_CalculateMeasurement

    ''------- Tool Dialog --------
    Friend WithEvents m_DialogLookupPosition As Dialog_LookupPosition
    Friend WithEvents m_DialogMDCSetting As Dialog_MDCSetting
    Friend WithEvents m_DialogCameraAlignment As Dialog_CameraAlignment
    Friend WithEvents m_DialogRMSSetting As Dialog_RMSSetting

    Private m_AutoClose As Boolean = False
    Private Arguments() As String

    '--- UI Object ---
    Private PicIP() As PictureBox
    Private m_ProductUIIMP As ClsProductUIIMP
    Private m_AdjustExpTimeUIIMP As ClsAdjustExpTimeUIIMP
    Private m_AlignUIIMP As ClsAlignUIIMP
    Private m_FuncParamUIIMP As ClsFuncParamUIIMP
    Private m_MuraParamUIIMP As ClsMuraParamUIIMP

    '--- 連線參數 ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""


    '--- Net Control Tool ---
    Private m_NetControlTool As ClsNetControlTool
    '
    Private res As System.Resources.ResourceManager '資源檔管理員
    Private m_VisableFunctionOpen As Boolean
#End Region

#Region "<--- Property --->"

    Public Property PanelID As String
        Get
            Return Me.m_PanelID
        End Get
        Set(ByVal Value As String)
            Me.m_PanelID = Value
        End Set
    End Property

#Region "--- Process ---"
    Public ReadOnly Property MainProcess() As ClsMainProcess   'MainProcess
        Get
            Return m_MainProcess
        End Get
    End Property
    Public ReadOnly Property MuraProcess() As ClsMuraProcess   'MuraProcess
        Get
            Return m_MuraProcess
        End Get
    End Property
#End Region

#Region "--- Display ---"
    Public ReadOnly Property AxMDisplay() As MIL_ID
        Get
            Return Me.m_AxMDisplay
        End Get
    End Property
    Public ReadOnly Property ZoomFactor() As Double
        Get
            Return m_ZoomFactor
        End Get
    End Property
    Public ReadOnly Property ZoomMin() As Double
        Get
            Return m_ZoomMin
        End Get
    End Property
    Public ReadOnly Property ZoomMax() As Double
        Get
            Return m_ZoomMax
        End Get
    End Property
    Public ReadOnly Property MouseX() As Integer
        Get
            Return m_MouseX
        End Get
    End Property
    Public ReadOnly Property MouseY() As Integer
        Get
            Return m_MouseY
        End Get
    End Property
    Public Property PaintStop() As Boolean
        Get
            Return Me.m_PaintStop
        End Get
        Set(ByVal Value As Boolean)
            Me.m_PaintStop = Value
        End Set
    End Property
    Public Property MoveToCenter() As Boolean
        Get
            Return Me.m_MoveToCenter
        End Get
        Set(ByVal Value As Boolean)
            Me.m_MoveToCenter = Value
        End Set
    End Property
#End Region

#Region "--- Image Update ---"
    Public Property CurrentIndex0() As Integer
        Get
            Return Me.m_CurrentIndex0
        End Get
        Set(ByVal Value As Integer)
            Me.m_CurrentIndex0 = Value
        End Set
    End Property
    Public Property CurrentIndex1() As Integer
        Get
            Return Me.m_CurrentIndex1
        End Get
        Set(ByVal Value As Integer)
            Me.m_CurrentIndex1 = Value
        End Set
    End Property
    Public Property CurrentIndex2() As Integer
        Get
            Return Me.m_CurrentIndex2
        End Get
        Set(ByVal Value As Integer)
            Me.m_CurrentIndex2 = Value
        End Set
    End Property
    Public Property CurrentIndex3() As Integer
        Get
            Return Me.m_CurrentIndex3
        End Get
        Set(ByVal Value As Integer)
            Me.m_CurrentIndex3 = Value
        End Set
    End Property
#End Region

#Region "--- Net Control Tool ---"

    Public Property NetControlTool() As ClsNetControlTool
        Get
            Return Me.m_NetControlTool
        End Get
        Set(ByVal Value As ClsNetControlTool)
            Me.m_NetControlTool = Value
        End Set
    End Property
#End Region

#End Region

#Region "<--- Constructor --->"
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        'UI Setting
        Me.InitialUI()
    End Sub
#End Region

#Region "<--- 方法函式 --->"

#Region "--- CheckGrabber ---"
    Private Sub CheckGrabber()
        Dim GrabberProc() As Process
        Dim arrProc As New ArrayList
        Dim i As Integer

        GrabberProc = Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName)
        For i = 0 To GrabberProc.Length - 1
            arrProc.Add(GrabberProc(i).MainWindowTitle)
        Next

        If arrProc.Contains(Me.Text) Then
            MessageBox.Show(Me.Text & "程式已開啟 !!", "注意", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End
        End If
    End Sub
#End Region

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP(ByVal CCDNo As Integer, ByVal GrabNo As String)
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = CCDNo
        ip.GrabNo = GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- RemoveOldImage ---"
    Private Sub RemoveOldImage(ByVal day As Integer, ByVal s As Double, ByVal CCD As Integer)
        Dim i As Integer
        Dim Arguments() As String
        Dim strs() As String
        Dim str As String
        Dim myDate As Date
        Dim cdrive As DriveInfo

        cdrive = My.Computer.FileSystem.GetDriveInfo(Directory.GetDirectoryRoot(Me.m_MainProcess.IMAGE_PATH))
        If cdrive.TotalFreeSpace <= s * cdrive.TotalSize Then
            '--- 刪除過期圖檔 ---
            Arguments = Directory.GetDirectories(Me.m_MainProcess.IMAGE_PATH & "\IP" & CCD & "\")
            For i = 0 To Arguments.Length - 1
                strs = Arguments(i).Split("\")
                str = strs(strs.Length - 1)
                If str.Length = 8 Then

                    Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 720
                    Try
                        myDate = New Date(str.Substring(0, 4), str.Substring(4, 2), str.Substring(6, 2))
                        If Now.Subtract(myDate).Days > day Then
                            Directory.Delete(Arguments(i), True)
                            Exit For
                        Else
                            If MsgBox("[MainForm.RemoveOldImage]" & "存放影像的磁碟空間不足，是否刪除" & vbCrLf & Arguments(i), MsgBoxStyle.OkCancel, "[AreaGrabber]") = MsgBoxResult.Ok Then
                                Directory.Delete(Arguments(i), True)
                                Exit For
                            End If
                        End If
                    Catch ex As Exception
                        Throw New Exception("[MainForm.RemoveOldImage][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Remove Old Image Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
                    End Try
                End If
            Next
        End If
    End Sub
#End Region

#Region "--- UpdateUserLevel ---"
    Private Sub UpdateUserLevel(ByVal UserLevel As Integer, ByRef ErrorCode As UInt32)
        'ErrorCode = 190 ~ 193

        ErrorCode = Me.m_MainProcess.ErrorCodeBase + 190
        Try
            Me.CloseAllDialog()

            Select Case UserLevel
                Case -1
                    Me.SetTabControlEnableInfo(False)
                    Me.SetButton_FuncResult(False)
                    Me.SetButton_MuraResult(False)
                    Me.SetButton_Load(False)
                    Me.SetButton_Save(False)
                    Me.SetGroupBox_CCD(False)
                    Me.SetButton_InitialIP(False)
                    Me.SetButton_KillIP(False)
                Case 0 'OP
                    Me.SetTabControlEnableInfo(False)
                    Me.SetButton_FuncResult(True)
                    Me.SetButton_MuraResult(True)
                    Me.SetButton_Load(False)
                    Me.SetButton_Save(False)
                    Me.SetGroupBox_CCD(False)
                    Me.SetButton_InitialIP(False)
                    Me.SetButton_KillIP(False)
                Case Else
                    Me.SetTabControlEnableInfo(True)
                    Me.SetButton_FuncResult(True)
                    Me.SetButton_MuraResult(True)
                    Me.SetButton_Load(True)
                    Me.SetButton_Save(True)
                    Me.SetGroupBox_CCD(False)
                    Me.SetButton_InitialIP(False)
                    Me.SetButton_KillIP(False)
            End Select
        Catch ex As Exception
            Throw New Exception("[UpdateUserLevel][ErrorCode = " & ErrorCode & "]Diable all Dialog Error !" & ex.Message)
        End Try

        Try
            Select Case UserLevel
                Case 0 'OP

                    ErrorCode = Me.m_MainProcess.ErrorCodeBase + 191
                    Try
                        Me.SetTabControlEnableInfo(False)

                        If Not Me.m_DialogSetMappingTable Is Nothing Then
                            Me.m_DialogSetMappingTable.Close()
                        End If

                        '---Mura---
                        If Not Me.m_DialogMuraAutoManual Is Nothing Then
                            Me.m_DialogMuraAutoManual.Close()
                        End If

                        If Not Me.m_DialogMuraBoundary Is Nothing Then
                            Me.m_DialogMuraBoundary.Close()
                        End If

                        If Not Me.m_DialogMuraSmooth Is Nothing Then
                            Me.m_DialogMuraSmooth.Close()
                        End If
                        If Not Me.m_DialogMuraCollection Is Nothing Then
                            Me.m_DialogMuraCollection.Close()
                        End If

                        If Not Me.m_DialogBlobMuraLocal Is Nothing Then
                            Me.m_DialogBlobMuraLocal.Close()
                        End If

                        If Not Me.m_DialogBlobMuraRound Is Nothing Then
                            Me.m_DialogBlobMuraRound.Close()
                        End If

                        If Not Me.m_DialogBandMura Is Nothing Then
                            Me.m_DialogBandMura.Close()
                        End If

                        If Not Me.m_DialogMuraJND Is Nothing Then
                            Me.m_DialogMuraJND.Close()
                        End If

                        If Not Me.m_DialogMuraFalseDefect Is Nothing Then
                            Me.m_DialogMuraFalseDefect.Close()
                        End If

                        If Not Me.m_DialogMuraResult Is Nothing Then
                            Me.m_DialogMuraResult.Close()
                        End If

                        If Not Me.m_DialogMuraSettingBase Is Nothing Then
                            Me.m_DialogMuraSettingBase.Close()
                        End If

                        If Not Me.m_DialogMuraSetting Is Nothing Then
                            Me.m_DialogMuraSetting.Close()
                        End If

                        '---Func---
                        If Not Me.m_DialogADJMean Is Nothing Then
                            Me.m_DialogADJMean.Close()
                        End If
                        If Not Me.m_DialogFuncFalseDefect Is Nothing Then
                            Me.m_DialogFuncFalseDefect.Close()
                        End If
                        If Not Me.m_DialogFuncResult Is Nothing Then
                            Me.m_DialogFuncResult.Close()
                        End If
                        If Not Me.m_DialogFuncSetting Is Nothing Then
                            Me.m_DialogFuncSetting.Close()
                        End If
                        If Not Me.m_DialogFuncSettingBase Is Nothing Then
                            Me.m_DialogFuncSettingBase.Close()
                        End If
                        If Not Me.m_DialogFuncTestImgProc Is Nothing Then
                            Me.m_DialogFuncTestImgProc.Close()
                        End If
                        If Not Me.m_DialogSetMappingTable Is Nothing Then
                            Me.m_DialogSetMappingTable.Close()
                        End If
                        'Recipe ---
                        If Not Me.m_DialogIPNetWorkConfig Is Nothing Then
                            Me.m_DialogIPNetWorkConfig.Close()
                        End If
                        If Not Me.m_DialogIPBootConfig Is Nothing Then
                            Me.m_DialogIPBootConfig.Close()
                        End If

                        'Measurement ---
                        If Not Me.m_DialogCalculateMeasurement Is Nothing Then
                            Me.m_DialogCalculateMeasurement.Close()
                        End If

                        'Tool ---
                        If Not Me.m_DialogLookupPosition Is Nothing Then
                            Me.m_DialogLookupPosition.Close()
                        End If
                        If Not Me.m_DialogMDCSetting Is Nothing Then
                            Me.m_DialogMDCSetting.Close()
                        End If
                        If Not Me.m_DialogCameraAlignment Is Nothing Then
                            Me.m_DialogCameraAlignment.Close()
                        End If
                        If Not Me.m_DialogRMSSetting Is Nothing Then
                            Me.m_DialogRMSSetting.Close()
                        End If
                        'Align---
                        If Not Me.m_DialogAlign Is Nothing Then
                            Me.m_DialogAlign.Close()
                        End If

                    Catch ex As Exception
                        Throw New Exception("[UpdateUserLevel][ErrorCode = " & ErrorCode & "]Set User level 0 Error !" & ex.Message)
                    End Try

                    'Case 1 'PM

                    ErrorCode = Me.m_MainProcess.ErrorCodeBase + 191
                    Try
                        Me.SetTabControlEnableInfo(True)

                        '---Func---
                        If Not Me.m_DialogADJMean Is Nothing Then
                            Me.m_DialogADJMean.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncFalseDefect Is Nothing Then
                            Me.m_DialogFuncFalseDefect.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncSetting Is Nothing Then
                            Me.m_DialogFuncSetting.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncSettingBase Is Nothing Then
                            Me.m_DialogFuncSettingBase.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncTestImgProc Is Nothing Then
                            Me.m_DialogFuncTestImgProc.UpdateUserLevel()
                        End If
                        'Recipe ---
                        If Not Me.m_DialogIPNetWorkConfig Is Nothing Then
                            Me.m_DialogIPNetWorkConfig.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogIPBootConfig Is Nothing Then
                            Me.m_DialogIPBootConfig.UpdateUserLevel()
                        End If
                        'Measurement ---
                        If Not Me.m_DialogCalculateMeasurement Is Nothing Then
                            Me.m_DialogCalculateMeasurement.UpdateUserLevel()
                        End If

                        '--- UI ---
                        Me.SetGroupBox_CCD(True)
                        Me.SetButton_InitialIP(True)
                        Me.SetButton_KillIP(True)

                    Catch ex As Exception
                        Throw New Exception("[UpdateUserLevel][ErrorCode = " & ErrorCode & "]Set User level 1 Error !" & ex.Message)
                    End Try

                    'Case 2 'ENG

                    ErrorCode = Me.m_MainProcess.ErrorCodeBase + 192
                    Try
                        Me.SetTabControlEnableInfo(True)

                        '---Func---
                        If Not Me.m_DialogADJMean Is Nothing Then
                            Me.m_DialogADJMean.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncFalseDefect Is Nothing Then
                            Me.m_DialogFuncFalseDefect.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncSetting Is Nothing Then
                            Me.m_DialogFuncSetting.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncSettingBase Is Nothing Then
                            Me.m_DialogFuncSettingBase.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncTestImgProc Is Nothing Then
                            Me.m_DialogFuncTestImgProc.UpdateUserLevel()
                        End If
                        'Recipe ---
                        If Not Me.m_DialogIPNetWorkConfig Is Nothing Then
                            Me.m_DialogIPNetWorkConfig.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogIPBootConfig Is Nothing Then
                            Me.m_DialogIPBootConfig.UpdateUserLevel()
                        End If
                        'Measurement ---
                        If Not Me.m_DialogCalculateMeasurement Is Nothing Then
                            Me.m_DialogCalculateMeasurement.UpdateUserLevel()
                        End If
                        '--- UI ---
                        Me.SetGroupBox_CCD(True)
                        Me.SetButton_InitialIP(True)
                        Me.SetButton_KillIP(True)

                    Catch ex As Exception
                        Throw New Exception("[UpdateUserLevel][ErrorCode = " & ErrorCode & "]Set User level 2 Error !" & ex.Message)
                    End Try

                Case 3 'ALL

                    ErrorCode = Me.m_MainProcess.ErrorCodeBase + 193
                    Try
                        Me.SetTabControlEnableInfo(True)

                        '---Func---
                        If Not Me.m_DialogADJMean Is Nothing Then
                            Me.m_DialogADJMean.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncFalseDefect Is Nothing Then
                            Me.m_DialogFuncFalseDefect.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncSetting Is Nothing Then
                            Me.m_DialogFuncSetting.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncSettingBase Is Nothing Then
                            Me.m_DialogFuncSettingBase.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogFuncTestImgProc Is Nothing Then
                            Me.m_DialogFuncTestImgProc.UpdateUserLevel()
                        End If
                        'Recipe ---
                        If Not Me.m_DialogIPNetWorkConfig Is Nothing Then
                            Me.m_DialogIPNetWorkConfig.UpdateUserLevel()
                        End If
                        If Not Me.m_DialogIPBootConfig Is Nothing Then
                            Me.m_DialogIPBootConfig.UpdateUserLevel()
                        End If
                        'Measurement ---
                        If Not Me.m_DialogCalculateMeasurement Is Nothing Then
                            Me.m_DialogCalculateMeasurement.UpdateUserLevel()
                        End If
                        '--- UI ---
                        Me.SetGroupBox_CCD(True)
                        Me.SetButton_InitialIP(True)
                        Me.SetButton_KillIP(True)

                    Catch ex As Exception
                        Throw New Exception("[UpdateUserLevel][ErrorCode = " & ErrorCode & "]Set User level 3 Error !" & ex.Message)
                    End Try

            End Select

            If UserLevel <> -1 Then
                Me.ShowMuraUI(Me.m_MainProcess.IPBootConfig.MuraUI.Value, Me.m_MainProcess.ErrorCode)
                Me.ShowFuncUI(Me.m_MainProcess.IPBootConfig.FuncUI.Value, Me.m_MainProcess.ErrorCode)
            End If

        Catch ex As Exception
            Throw New Exception("[MainForm.UpdateUserLevel]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- ResetAxMDisplay ---"
    Public Sub ResetAxMDisplay()
        Try
            If Me.m_AxMDisplay <> MIL.M_NULL Then
                MdispFree(Me.m_AxMDisplay)
                Me.m_AxMDisplay = MIL.M_NULL
            End If

            MIL.MdispAlloc(Me.m_MainProcess.System_Host, MIL.M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay)
        Catch ex As Exception
            MsgBox("[MainForm.ResetAxMDisplay]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- CloseFormAreaGrabber ---"

    Private Sub CloseFormAreaGrabber()
        ' ErrorCode = ErrorCodeBase + 770
        Dim myProcesses As Process() = Process.GetProcessesByName(Process.GetCurrentProcess.ProcessName)
        Dim myProcess As Process

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 770
        Try
            For Each myProcess In myProcesses
                If myProcess.MainWindowTitle = Me.Text Then myProcess.Kill()
            Next myProcess
        Catch ex As Exception
            Throw New Exception("[Form_AreaGrabber.CloseFormAreaGrabber][ErrorCode = " & Me.m_MainProcess.ErrorCode & "] Close Grabber Error !(" & ex.Message & ")")
        End Try
    End Sub

#End Region

#Region "--- Change_GrabNo ---"
    Function Change_GrabNo(ByVal CCDNo As String, ByRef temp_GrabNo As String) As Boolean
        Try
            temp_GrabNo = Trim(Str(Me.m_MainProcess.IPNetworkConfig.Total_IP) & "_" & CCDNo)
            Return True
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[MainForm.Change_GrabNo]Add One Model Error ! (" & ex.Message & ")")
            Return False
        End Try
    End Function
#End Region

#Region "--- UpdateIPIcon ---"
    Public Sub UpdateIPIcon(ByVal IPCount As Integer)
        Dim MyNewPos As Point
        Dim i As Integer
        Dim j As Integer
        Dim Size As Integer = 18
        ReDim PicIP(IPCount - 1)

        Try
            'IP Icon Array ---
            For i = 0 To IPCount - 1
                PicIP(i) = New PictureBox

                With PicIP(i)
                    .Name = "PicIP" & i.ToString

                    '--- Icon Position ---
                    If IPCount = 9 Then   '2012/08/03 Rick add
                        MyNewPos.X = Size
                        MyNewPos.Y = (Size - 2)

                        Select Case i

                            Case 0 To 2
                                .Left = MyNewPos.X + (i Mod 3) * (Size + 1)
                                .Top = MyNewPos.Y + (Size + 1)
                            Case 3 To 5
                                .Left = MyNewPos.X + (i Mod 3) * (Size + 1)
                                .Top = MyNewPos.Y + 0
                            Case Else
                                .Left = MyNewPos.X + (i Mod 3) * (Size + 1)
                                .Top = MyNewPos.Y + 2 * (Size + 1)

                        End Select

                    Else
                        MyNewPos.X = 15
                        MyNewPos.Y = 15

                        .Left = MyNewPos.X + (i Mod 3) * 19
                        .Top = MyNewPos.Y + j * 19

                        If ((i + 1) Mod 3) = 0 Then
                            j = j + 1
                        End If
                    End If


                    .Width = Size
                    .Height = Size
                    .BringToFront()
                    .SizeMode = PictureBoxSizeMode.StretchImage
                    .Image = My.Resources.Gray_cir
                End With

                GroupBox_IPStatus.Controls.Add(PicIP(i))
            Next

            Me.GroupBox_IPStatus.SendToBack()
        Catch ex As Exception
            Throw New Exception("[UpdateIPIcon]" & ex.Message)
        End Try

    End Sub
#End Region

#Region "--- UpdateOMSUI ---"
    Public Sub UpdateOMSUI()
        Dim i As Integer
        Dim mbc As ClsMeasBootConfig
        Dim ipnc As ClsIPNetWorkConfig

        Try
            mbc = Me.m_MainProcess.MeasProcess.MeasBootConfig
            ipnc = Me.m_MainProcess.IPNetworkConfig

            '--- OMS Enable Setting --- 
            Me.ComboBox_OMS_Enable_IPNo.Items.Clear()

            For i = 0 To Me.m_MainProcess.IPNetworkConfig.NetWorkList.Count - 1
                Me.ComboBox_OMS_Enable_IPNo.Items.Insert(i, i + 1)
            Next

            If mbc.OMS_Enable_IPNo.Value - 1 >= 0 Then
                If mbc.OMS_Enable_IPNo.Value >= ipnc.Total_IP Then
                    Me.ComboBox_OMS_Enable_IPNo.SelectedIndex = ipnc.Total_IP - 1
                    mbc.OMS_Enable_IPNo.Value = ipnc.Total_IP - 1
                Else
                    Me.ComboBox_OMS_Enable_IPNo.SelectedIndex = mbc.OMS_Enable_IPNo.Value - 1
                End If
            End If
        Catch ex As Exception
            Throw New Exception("[MainForm.UpdateOMSUI]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- UpdateMDCUI ---"
    Public Sub UpdateMDCUI()
        Try
            Me.Button_MDC_Setting.Visible = Me.m_MainProcess.AreaBootConfig.MDC_UI.Value
        Catch ex As Exception
            Throw New Exception("[MainForm.UpdateMDCUI]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- UpdateFabTypeUI ---"
    Public Sub UpdateFabTypeUI(ByVal Fab_Type As String)
        Try
            Select Case Fab_Type

                Case "L6B_OLED"
                    Me.Fab_L6B_OLED_UI_Setting()
                Case Else

            End Select
        Catch ex As Exception
            Throw New Exception("[MainForm.UpdateFabTypeUI]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub

#Region "--- Fab_L6B_OLED_UI_Setting ---"
    Public Sub Fab_L6B_OLED_UI_Setting()

        '--- Mura UI ---
        Me.Button_SettingMura.Visible = False
        Me.Button_JND.Visible = False
        Me.Button_MuraAutoTest.Visible = False
        Me.Button_MuraManualTest.Visible = False
        Me.Button_MuraFalseDefect.Visible = False
        'Me.GroupBox_MuraTest.Visible = False

        '--- OMS UI ---
        Me.Button_OMSSetting.Visible = False
        Me.GroupBox_OMS_Enable_Setting.Visible = False

        '--- Tool ---
        Me.Button_LookUpPosition.Visible = False
        Me.Button_MDC_Setting.Visible = False
    End Sub

#End Region

#End Region

#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)

        If Me.m_MainProcess.IPBootConfig.FuncUI.Value Then Me.Button_FuncResult.Enabled = En
        If Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Me.Button_MuraResult.Enabled = En
        Me.Button_InitialIP.Enabled = En
        Me.Button_KillIP.Enabled = En
        Me.btnClearLog.Enabled = En

    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- Open_Log_File ---"
    '----------------------------------
    '功能 : 開啟 Log File
    '----------------------------------
    Public Function Open_Log_File(ByVal FileIndex As Integer, ByVal IPNo As Integer, ByVal GrabNo As String, ByVal sDate As String) As String
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim AreaGrabber_Address As String = ""
        Dim LogPath() As String

        Try
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(IPNo - 1).IP_IPAddress
            AreaGrabber_Address = Me.m_MainProcess.IPNetworkConfig.Server_IPAddress
            LogPath = Me.m_MainProcess.LOG_PATH.Split(":")

            Select Case FileIndex
                Case 0   '[1] IP Daily Log File ---
                    FilePath = "\\" & IP_Address & LogPath(1) & "\IP" & IPNo & "\IP" & GrabNo & "_" & sDate & ".log"
                Case 1   '[2] AreaGrabber Daily Log File ---
                    FilePath = "\\" & AreaGrabber_Address & LogPath(1) & "\AreaGrabber\AreaGrabber_" & sDate & ".log"
                Case 2   '[3] Daily Mean Log ---
                    FilePath = "\\" & IP_Address & LogPath(1) & "\APC\IP" & IPNo & "\DailyMeanLog_C" & GrabNo & "_" & sDate & ".log"
                Case 3   '[4] IP Recipe Changed Log File --- 
                    FilePath = "\\" & IP_Address & LogPath(1) & "\IP" & IPNo & "\IPRecipeChange_C" & GrabNo & "_" & sDate & ".log"
            End Select
            Me.RepairPath_2(FilePath)

            If File.Exists(FilePath) Then
                Shell("NOTEPAD.EXE " & FilePath, AppWinStyle.NormalFocus)
            Else
                Return "File was not exist ! ==>" & FilePath
            End If

            Return ""
        Catch ex As Exception
            Return "[MainForm.Open_Log_File]" & ex.Message
        End Try
    End Function

#End Region

#Region "--- CloseAllDialog ---"
    Public Sub CloseAllDialog()
        Try
            '--- Mura ---
            'No1
            If Not Me.m_DialogMuraAutoManual Is Nothing Then Me.SetDialogMuraAutoManual(False)
            'No2
            If Not Me.m_DialogMuraBoundary Is Nothing Then Me.SetDialogMuraBoundary(False)
            'No3
            If Not Me.m_DialogMuraSmooth Is Nothing Then Me.SetDialogMuraSmooth(False)
            'No4
            If Not Me.m_DialogMuraCollection Is Nothing Then Me.SetDialogMuraCollection(False)
            'No5
            If Not Me.m_DialogBlobMuraLocal Is Nothing Then Me.SetDialogBlobMuraLocal(False)
            'No6
            If Not Me.m_DialogBlobMuraRound Is Nothing Then Me.SetDialogBlobMuraRound(False)
            'No7
            If Not Me.m_DialogBandMura Is Nothing Then Me.SetDialogBandMura(False)
            'No8
            If Not Me.m_DialogMuraJND Is Nothing Then Me.SetDialogMuraJND(False)
            'No9
            If Not Me.m_DialogMuraFalseDefect Is Nothing Then Me.SetDialogMuraFalseDefect(False)
            'No10
            If Not Me.m_DialogMuraResult Is Nothing Then Me.SetDialogMuraResult(False)
            'No11
            If Not Me.m_DialogMuraSettingBase Is Nothing Then Me.SetDialogMuraSettingBase(False)
            'No12
            If Not Me.m_DialogMuraSetting Is Nothing Then Me.SetDialogMuraSetting(False)

            '--- Func ---   
            'No1
            If Not Me.m_DialogADJMean Is Nothing Then Me.SetDialogADJMean(False)
            'No2
            If Not Me.m_DialogFuncFalseDefect Is Nothing Then Me.SetDialogFuncFalseDefect(False)
            'No3
            If Not Me.m_DialogFuncResult Is Nothing Then Me.SetDialogFuncResult(False)
            'No4
            If Not Me.m_DialogFuncSetting Is Nothing Then Me.SetDialogFuncSetting(False)
            'No5
            If Not Me.m_DialogFuncSettingBase Is Nothing Then Me.SetDialogFuncSettingBase(False)
            'No6
            If Not Me.m_DialogFuncTestImgProc Is Nothing Then Me.SetDialogFuncTestImgProc(False)
            'No7
            If Not Me.m_DialogSetMappingTable Is Nothing Then Me.SetDialogSetMappingTable(False)

            '--- Recipe ---
            'No1
            If Not Me.m_DialogIPNetWorkConfig Is Nothing Then Me.SetDialogIPNetWorkConfig(False)
            'No2
            If Not Me.m_DialogIPBootConfig Is Nothing Then Me.SetDialogIPBootConfig(False)

            '--- Measurement ---
            'No1
            If Not Me.m_DialogCalculateMeasurement Is Nothing Then Me.SetDialogCalculateMeasurement(False)

            '--- Tool ---
            'No 1
            If Not Me.m_DialogLookupPosition Is Nothing Then Me.SetDialogLookupPosition(False)
            'No 2
            If Not Me.m_DialogCameraAlignment Is Nothing Then Me.SetDialogCameraAlignment(False)
            If Not Me.m_DialogRMSSetting Is Nothing Then Me.SetDialogRMSSetting(False)

            'No7
            If Not Me.m_DialogAlign Is Nothing Then Me.SetDialogAlign(False)

        Catch ex As Exception
            Throw New Exception("[Main_Form.CloseAllDialog] Close All Dialog Error !(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- CopyDirectory ---"

    Public Sub CopyDirectory(ByVal SourceDir As String, ByVal DestDir As String)
        Dim myDir As DirectoryInfo = New DirectoryInfo(SourceDir)
        Dim FileName As String

        '列舉目錄中的檔案       
        For Each myFile As FileInfo In myDir.GetFiles
            FileName = myFile.FullName.Substring(myFile.FullName.LastIndexOf("\") + 1)  '取出文件名

            myFile.CopyTo(DestDir & "\" & FileName, True)
        Next

    End Sub

#End Region

#Region "--- DeleteDirectory ---"

    Public Sub DeleteDirectory(ByVal dir_name As String)
        Dim file_name As String
        Dim files As Collection
        Dim i As Integer

        '--- Get a list of files it contains.---
        files = New Collection
        file_name = Dir$(dir_name & "\*.*", vbReadOnly + _
            vbHidden + vbSystem + vbDirectory)
        Do While Len(file_name) > 0
            If (file_name <> "..") And (file_name <> ".") Then
                files.Add(dir_name & "\" & file_name)
            End If
            file_name = Dir$()
        Loop

        '--- Delete the files ---
        For i = 1 To files.Count
            file_name = files(i)
            '--- See if it is a directory ---
            If GetAttr(file_name) And vbDirectory Then
                '--- It is a directory. Delete it ---
                DeleteDirectory(file_name)
            Else
                ' It's a file. Delete it.
                'lblStatus.Caption = file_name
                'lblStatus.Refresh()
                SetAttr(file_name, vbNormal)
                Kill(file_name)
            End If
        Next i

        ' The directory is now empty. Delete it.
        'lblStatus.Caption = dir_name
        'lblStatus.Refresh()

        ' Remove the read-only flag if set.
        ' (Thanks to Ralf Wolter.)
        SetAttr(dir_name, vbNormal)
        RmDir(dir_name)
    End Sub

#End Region

#Region "--- Load RotateCalImg ---"
    Private Sub Load_RotateCalImg()
        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FileName As String = ""
        Dim FilePath As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim ResizeRatio As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP(CInt(Me.ComboBox_CCD.Text), Me.ComboBox_GrabNo.Text) Then
                Exit Sub
            End If

            '--- Initial ---   
            FileName = Me.MainProcess.IPBootConfig.RamDiskPath.Value & "\Img_AfterRotate.tif"
            Me.RepairPath_2(FileName)
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Button Control ---   
            Button_Enable(False)

            If Me.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                Me.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            End If

            image = Me.MainProcess.FuncProcess.Img_Original_NonPage

            '[AreaGrabber] Load Image --- (For Display)
            '[1] image ---
            MbufDiskInquire(FileName, M_SIZE_X, SizeX)
            MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
            MbufDiskInquire(FileName, M_TYPE, Type)
            If image <> M_NULL Then
                If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(image)
                    image = M_NULL
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.MainProcess.FuncProcess.Img_Original_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.MainProcess.FuncProcess.Img_Original_NonPage)

            '[2] Img_16U_Grab ---
            If Me.MainProcess.FuncProcess.Img_Original_NonPage <> M_NULL Then
                If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                    MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                    Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
            Else
                Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
            End If
            MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

            Me.StatusBarStatus(Path.GetFileName(FileName))
            'If Me.m_Form.ComboBox_CCD.Text <> "" Then
            '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
            '    If Not (iCheckLoadImage > 0) Then
            '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
            '    End If
            'End If

            '----------------------------------------------------------------------------------------------
            ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "LOAD_IMAGE"
                TimeOut = 100000 '100 secs

                FilePath = FileName
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                    If SubSystemResult.Responses(0).Param1 = "1" Then
                        Me.CheckBox_IsAligned.Checked = True
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                        Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                        strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                        RepairPath_2(strPath)
                        MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.MainProcess.FuncProcess.FuncModelRecipe, strPath)
                        ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value
                        Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX / ResizeRatio)
                        Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY / ResizeRatio)
                        Me.m_MuraProcess.MuraModelRecipe.Boundary.RightX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX / ResizeRatio)
                        Me.m_MuraProcess.MuraModelRecipe.Boundary.BottomY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY / ResizeRatio)
                    Else
                        Me.CheckBox_IsAligned.Checked = False
                    End If
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Button_Enable(True)
                    Exit Sub
                End If

                If Me.ComboBox_Type.SelectedIndex = 0 And Me.ComboBox_Select.SelectedIndex = 2 Then
                    If image <> M_NULL Then
                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)

                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                            MbufFree(imageBuffer)
                            imageBuffer = M_NULL
                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufCopy(image, imageBuffer)

                        MdispSelectWindow(Me.AxMDisplay, imageBuffer, Me.GetAxMDisplay_HandleInfo())
                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                        Me.ResetScrollBar()
                    End If
                Else
                    Me.CurrentIndex0 = 2
                    Me.ComboBox_Type.SelectedIndex = 0
                    Me.ComboBox_Select.SelectedIndex = 2
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If (Me.MainProcess.IPBootConfig.MuraUI.Value) Then
                image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image2 ---
                MbufDiskInquire(FileName, M_SIZE_X, SizeX)
                MbufDiskInquire(FileName, M_SIZE_Y, SizeY)
                MbufDiskInquire(FileName, M_TYPE, Type)
                If image2 <> M_NULL Then
                    If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image2)
                        image2 = M_NULL
                        image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MuraProcess.Img_CurrentOriginal_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MuraProcess.Img_CurrentOriginal_NonPage)

                '[2] Img_16U_Grab ---
                If image2 <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FileName, Me.m_MainProcess.Img_16U_Grab_1)

                If Not Response_OK Then
                    Button_Enable(True)
                    Exit Sub
                End If

                '--- Resize Original image ---
                If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 100000 '100 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) AndAlso FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                                Else
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                                End If

                                If System.IO.File.Exists(strPath) = True Then
                                    System.IO.File.Delete(strPath)
                                End If
                            End If

                            Me.ImageUpdate()
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try
                End If
            End If



            If FileName <> "" Then
                If MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.MainProcess.IPBootConfig.ImageSizeX.Value And MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.MainProcess.IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.MainProcess.FuncProcess.Img_Original_NonPage <> M_NULL Then Me.MainProcess.FuncProcess.CalculateOriginalROI(Me.MainProcess.FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If Me.MainProcess.FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.MainProcess.FuncProcess.Img_OriginalROI)
                        Me.MainProcess.FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.MainProcess.FuncProcess.Img_OriginalROI = MbufChild2d(Me.MainProcess.FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
            End If
            Call Me.ImageZoomAll()
            System.IO.File.Delete(FileName)
            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.OutputErrorInfo("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Change Language ---"
    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                '
                Button_ProductModelSetting.Text = res.GetString("Button_ProductModelSetting.Text")
                Button_ADJMean.Text = res.GetString("Button_ADJMean.Text")
                Button_Align.Text = res.GetString("Button_Align.Text")
                Button_CameraAlignment.Text = res.GetString("Button_CameraAlignment.Text")
                Button_SaveFuncParam.Text = res.GetString("Button_SaveFuncParam.Text")
                Button_FuncFalseDefect.Text = res.GetString("Button_FuncFalseDefect.Text")
                Button_FuncImgProcTest.Text = res.GetString("Button_FuncImgProcTest.Text")
                Button_FuncResult.Text = res.GetString("Button_FuncResult.Text")
                Button_FuncSettingBase.Text = res.GetString("Button_FuncSettingBase.Text")
                Button_JND.Text = res.GetString("Button_JND.Text")
                Button_MuraAutoTest.Text = res.GetString("Button_MuraAutoTest.Text")
                Button_MuraFalseDefect.Text = res.GetString("Button_MuraFalseDefect.Text")
                Button_MuraManualTest.Text = res.GetString("Button_MuraManualTest.Text")
                Button_MuraResult.Text = res.GetString("Button_MuraResult.Text")
                Button_SettingBase.Text = res.GetString("Button_SettingBase.Text")
                Button_SettingFunc.Text = res.GetString("Button_SettingFunc.Text")
                Button_SettingMura.Text = res.GetString("Button_SettingMura.Text")
                Button_ZoomAll.Text = res.GetString("Button_ZoomAll.Text")
                Button_ZoomIn.Text = res.GetString("Button_ZoomIn.Text")
                Button_ZoomO.Text = res.GetString("Button_ZoomO.Text")
                Button_ZoomOut.Text = res.GetString("Button_ZoomOut.Text")
                Button_Continue.Text = res.GetString("Button_Continue.Text")
                Button_StopGrab.Text = res.GetString("Button_StopGrab.Text")
                Button_MuraParamSave.Text = res.GetString("Button_MuraParamSave.Text")
                Button_MuraPrePrcoessPage.Text = res.GetString("Button_MuraPrePrcoessPage.Text")
                Button_MuraCenterPage.Text = res.GetString("Button_MuraCenterPage.Text")
                Button_MuraAroundPage.Text = res.GetString("Button_MuraAroundPage.Text")
                Button_MuraBandPage.Text = res.GetString("Button_MuraBandPage.Text")
                Button_MuraPreprocess.Text = res.GetString("Button_MuraPreprocess.Text")
                Button_AnalysisMuraBlob.Text = res.GetString("Button_AnalysisMuraBlob.Text")
                Button_AnalysisMuraAround.Text = res.GetString("Button_AnalysisMuraAround.Text")
                Button_AnalysisMuraBand.Text = res.GetString("Button_AnalysisMuraBand.Text")

                Label_Product.Text = res.GetString("Label_Product.Text")
                Label_Select.Text = res.GetString("Label_Select.Text")
                Label_Type.Text = res.GetString("Label_Type.Text")
                Label_ProductSetting.Text = res.GetString("Label_ProductSetting.Text")
                Label_FuncPatternSetting.Text = res.GetString("Label_FuncPatternSetting.Text")
                Label_MuraPatternSetting.Text = res.GetString("Label_MuraPatternSetting.Text")
                Label_BoundaryTop.Text = res.GetString("Label_BoundaryTop.Text")
                Label_BoundaryBottom.Text = res.GetString("Label_BoundaryBottom.Text")
                Label_BoundaryLeft.Text = res.GetString("Label_BoundaryLeft.Text")
                Label_BoundaryRight.Text = res.GetString("Label_BoundaryRight.Text")
                Label_LocalTop.Text = res.GetString("Label_LocalTop.Text")
                Label_LocalBottom.Text = res.GetString("Label_LocalBottom.Text")
                Label_LocalLeft.Text = res.GetString("Label_LocalLeft.Text")
                Label_LocalRight.Text = res.GetString("Label_LocalRight.Text")

                StatusBarPanel_Scale.Text = res.GetString("StatusBarPanel_Scale.Text")
                tsmEdit.Text = res.GetString("tsmEdit.Text")
                GroupBox_FuncSetting.Text = res.GetString("GroupBox_FuncSetting.Text")
                GroupBox_ExposureTime.Text = res.GetString("GroupBox_ExposureTime.Text")
                GroupBox_BoundaryModify.Text = res.GetString("GroupBox_BoundaryModify.Text")
                GroupBox_Boundary.Text = res.GetString("GroupBox_Boundary.Text")
                GroupBox_MT.Text = res.GetString("GroupBox_MT.Text")
                GroupBox_Local.Text = res.GetString("GroupBox_Local.Text")
                'GroupBox_FuncTest.Text = res.GetString("GroupBox_FuncTest.Text")

                RadioButton_BoundaryFinish.Text = res.GetString("RadioButton_BoundaryFinish.Text")
                RadioButton_BoundaryManual.Text = res.GetString("RadioButton_BoundaryManual.Text")
                RadioButton_BP.Text = res.GetString("RadioButton_BP.Text")
                RadioButton_DP.Text = res.GetString("RadioButton_DP.Text")
                RadioButton_BPDP.Text = res.GetString("RadioButton_BPDP.Text")

                CheckBox_AlignShowBoundary.Text = res.GetString("CheckBox_AlignShowBoundary.Text")
                CheckBox_PanelRotate.Text = res.GetString("CheckBox_PanelRotate.Text")
                CheckBox_PanelMirror.Text = res.GetString("CheckBox_PanelMirror.Text")
                CheckBox_Point_Enable.Text = res.GetString("CheckBox_Point_Enable.Text")
                CheckBox_Line_Enable.Text = res.GetString("CheckBox_Line_Enable.Text")
                CheckBox_BLine_Enable.Text = res.GetString("CheckBox_BLine_Enable.Text")
                CheckBox_DLine_Enable.Text = res.GetString("CheckBox_DLine_Enable.Text")
                CheckBox_GrayAbnormal_Enable.Text = res.GetString("CheckBox_GrayAbnormal_Enable.Text")
                CheckBox_HLine_NotAddToOutput.Text = res.GetString("CheckBox_HLine_NotAddToOutput.Text")
                CheckBox_VLine_NotAddToOutput.Text = res.GetString("CheckBox_VLine_NotAddToOutput.Text")
                CheckBox_AnalysisCenterMuraEnable.Text = res.GetString("CheckBox_AnalysisCenterMuraEnable.Text")
                CheckBox_AnalysisAroundMuraEnable.Text = res.GetString("CheckBox_AnalysisAroundMuraEnable.Text")
                CheckBox_AnalysisBandMuraEnable.Text = res.GetString("CheckBox_AnalysisBandMuraEnable.Text")
        End Select
    End Sub
#End Region

#Region "---RefreshUI---"
    Public Sub RefreshUI()
        Me.Update()
    End Sub
#End Region

#Region "--- CheckGrabStatus ---"
    Private Function GetCaptureStatus() As Boolean
        Try
            If Me.m_AdjustExpTimeUIIMP Is Nothing Then
                MessageBox.Show("程式撰写异常, 请关闭联系开发人员.", "ERR", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If
            If Me.m_AdjustExpTimeUIIMP.IsGrabStatus Then

                MessageBox.Show("持续取像中, 请关闭实时取像后即可变更设定.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return True
            End If
            Return False
        Catch ex As Exception
            MessageBox.Show("程式撰写异常, 请关闭联系开发人员.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End Try
    End Function
#End Region
#End Region

#Region "<--- UI 介面 --->"
#Region "Initial UI"
    Private Sub InitialUI()
        '
        Me.Size = New Size(1307, 714)
        'Me.Button_MuraParamSave.Size = New Size(125, 50)

        Me.ComboBox_Type.Items.Clear()
        Me.ComboBox_Type.Items.Add("全影像")
        Me.ComboBox_Type.Items.Add("可视区")
        Me.ComboBox_Type.Items.Add("Band")
        Me.ComboBox_Type.Items.Add("亮校正相关")
        'Me.Label_ProductSetting.Font = New System.Drawing.Font("Microsoft JhengHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        'Me.Label_ProductSetting.TextAlign = ContentAlignment.MiddleCenter
        'Me.Label_FuncPatternSetting.Font = New System.Drawing.Font("Microsoft JhengHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        'Me.Label_FuncPatternSetting.TextAlign = ContentAlignment.MiddleCenter
        'Me.Label_MuraPatternSetting.Font = New System.Drawing.Font("Microsoft JhengHei", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        'Me.Label_MuraPatternSetting.TextAlign = ContentAlignment.MiddleCenter

    End Sub
#End Region

#Region "--- ShowUI ---"
    Private Sub ShowMuraUI(ByVal MuraEnable As Boolean, ByRef ErrorCode As UInt32)
        'ErrorCode = ErrorCodeBase + 280

        ErrorCode = Me.m_MainProcess.ErrorCodeBase + 280
        Try
            Me.SetButton_MuraFalseDefect(MuraEnable)
            Me.SetButton_JND(MuraEnable)
            Me.SetButton_MuraResult(MuraEnable)
            Me.SetButton_SettingMura(MuraEnable)
            Me.SetButton_SettingBase(MuraEnable)
            Me.SetButton_MuraResult(MuraEnable)
            Me.SetButton_MuraAutoTest(MuraEnable)
            Me.SetButton_MuraManualTest(MuraEnable)
        Catch ex As Exception
            Throw New Exception("[MainForm.ShowMuraUI][ErrorCode = " & ErrorCode & "]Show Mura UI Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
    Private Sub ShowFuncUI(ByVal FuncEnable As Boolean, ByRef ErrorCode As UInt32)
        'ErrorCode = ErrorCodeBase + 290

        ErrorCode = Me.m_MainProcess.ErrorCodeBase + 290
        Try
            Me.SetButton_FuncSettingBase(FuncEnable)
            Me.SetButton_SettingFunc(FuncEnable)
            Me.SetButton_FuncFalseDefect(FuncEnable)
            Me.SetButton_FuncResult(FuncEnable)
            Me.SetButton_FuncImgProcTest(FuncEnable)
        Catch ex As Exception
            Throw New Exception("[MainForm.ShowFuncUI][ErrorCode = " & ErrorCode & "]Show Func UI Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- ShowFuncResult --"
    Public Sub ShowFuncResult()
        ' ErrorCode = ErrorCodeBase + 690

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 690
        Try
            If Me.m_DialogFuncResult Is Nothing Then
                Me.m_DialogFuncResult = New Dialog_FuncResult
                Me.m_DialogFuncResult.SetMainForm(Me, "zh-CN")
                Me.AddOwnedForm(Me.m_DialogFuncResult)
                Me.m_MainProcess.OffLineTest = True
                Me.m_DialogFuncResult.Left = Me.Left + Me.Size.Width - Me.m_DialogFuncResult.Size.Width
                Me.m_DialogFuncResult.Top = Me.Top + Me.Size.Height - Me.m_DialogFuncResult.Size.Height
                Me.m_DialogFuncResult.Show()
            Else
                Me.m_DialogFuncResult.Show()
            End If
        Catch ex As Exception
            Me.m_MainProcess.LogDailyManager("[MainForm.ShowFuncResult][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Show Func Result!(" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[MainForm.ShowFuncResult][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Show Func Result!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- ShowMuraResult ---"
    Public Sub ShowMuraResult()
        ' ErrorCode = ErrorCodeBase + 680
        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 680
        Try
            If Me.m_DialogMuraResult Is Nothing Then
                Me.m_DialogMuraResult = New Dialog_MuraResult
                Me.m_DialogMuraResult.SetMainForm(Me, "zh-CN")
                Me.AddOwnedForm(Me.m_DialogMuraResult)
                Me.m_MainProcess.OffLineTest = True
                Me.m_DialogMuraResult.Left = Me.Left + Me.Size.Width - Me.m_DialogMuraResult.Size.Width
                Me.m_DialogMuraResult.Top = Me.Top + Me.Size.Height - Me.m_DialogMuraResult.Size.Height
                Me.m_DialogMuraResult.ShowResult()
                Me.m_DialogMuraResult.Show()
            Else
                Me.m_DialogMuraResult.ShowResult()
                Me.m_DialogMuraResult.Show()
            End If
            Me.ImageZoomAll()
        Catch ex As Exception
            Me.m_MainProcess.LogDailyManager("[MainForm.ShowMuraResult][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Show Mura Result!(" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[MainForm.ShowMuraResult][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Show Mura Result!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- ShowFalse ---"
    Public Sub ShowFalse()
        ' ErrorCode = ErrorCodeBase + 700

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 700
        Try
            If Not Me.m_DialogMuraFalseDefect Is Nothing Then Me.m_DialogMuraFalseDefect = Nothing
            If Me.m_DialogMuraFalseDefect Is Nothing Then
                Me.m_DialogMuraFalseDefect = New Dialog_MuraFalseDefect
                Me.m_DialogMuraFalseDefect.SetMainForm(Me, "zh-CN")
                If Not Me.m_MainProcess.IsIPConnected Then Exit Sub
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogMuraFalseDefect)
                Me.m_DialogMuraFalseDefect.Left = Me.Left + Me.Size.Width - Me.m_DialogMuraFalseDefect.Size.Width
                Me.m_DialogMuraFalseDefect.Top = Me.Top + Me.Size.Height - Me.m_DialogMuraFalseDefect.Size.Height
                Me.m_DialogMuraFalseDefect.ShowListView()
                Me.m_DialogMuraFalseDefect.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.ShowFalse] Dialog Mura False Defect Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraFalseDefect = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try

    End Sub
#End Region

#Region "--- ResultUpdate ---"
    Public Sub ResultUpdate()
        ' ErrorCode = ErrorCodeBase + 580

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 580
        Try
            If Not Me.m_DialogMuraResult Is Nothing Then
                Me.m_DialogMuraResult.ShowResult()
                Me.m_DialogMuraResult.Show()
            End If
        Catch ex As Exception
            Throw New Exception("[MainForm.ResultUpdate][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Mura Result Update Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- FalseUpdate ---"
    Public Sub FalseUpdate()
        ' ErrorCode = ErrorCodeBase + 590
        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 590
        Try
            If Not Me.m_DialogMuraFalseDefect Is Nothing Then
                Me.m_DialogMuraFalseDefect.ShowListView()
                Me.m_DialogMuraFalseDefect.Show()
            End If
        Catch ex As Exception
            Throw New Exception("[MainForm.FalseUpdate][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Mura False Defect Update Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- TabControlEnable ---"
    Private Sub TabControlEnable()
        Dim iTotalTabs = Me.TabControl_HightLevel.TabCount()
        Dim X As Integer

        For X = 0 To iTotalTabs - 1
            Me.TabControl_HightLevel.TabPages(X).Enabled = True
        Next
        Me.GroupBox_Image.Enabled = True

    End Sub
#End Region

#Region "--- TabControlDisable ---"
    Private Sub TabControlDisable()
        Dim iTotalTabs = Me.TabControl_HightLevel.TabCount()
        Dim X As Integer

        For X = 0 To iTotalTabs - 1
            Me.TabControl_HightLevel.TabPages(X).Enabled = False
        Next
        Me.GroupBox_Image.Enabled = False

    End Sub
#End Region

#Region "--- Across Form UI-Control ---"

    Private Sub OP_FuncSetting(ByVal OP_FuncSetting As Boolean)
        If Not Me.m_DialogFuncSetting Is Nothing And OP_FuncSetting = False Then
            Me.m_DialogFuncSetting.Button_Save.Enabled = False
            Me.m_DialogFuncSetting.Button_LoadImage.Enabled = False
        ElseIf Not Me.m_DialogFuncSetting Is Nothing And OP_FuncSetting = True Then
            Me.m_DialogFuncSetting.Button_Save.Enabled = True
            Me.m_DialogFuncSetting.Button_LoadImage.Enabled = True
        End If
    End Sub
#End Region

#Region "--- ScrollBar Event ---"
    Private Sub VScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles VScrollBar.ValueChanged
        MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Value, Me.VScrollBar.Value)
    End Sub
    Private Sub HScrollBar_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles HScrollBar.ValueChanged
        MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Value, Me.VScrollBar.Value)
    End Sub
#End Region

#Region "--- ResetScrollBar ---"
    Public Sub ResetScrollBar()
        ' ErrorCode = ErrorCodeBase + 670
        Dim Image As MIL_ID = M_NULL
        Dim s As Integer

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 670
        Try
            Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            If Image = M_NULL Then
                Me.SetHScrollBar(0)
                Me.SetVScrollBar(0)
            Else
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double
                Dim ZoomY As Double

                SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, ZoomY)

                If ZoomX > 0 Then
                    s = SizeX - Math.Floor(Me.Panel_AxMDisplay.Size.Width / ZoomX)
                    If s <= 0 Then
                        s = 0
                    End If
                    Me.SetHScrollBar(s)

                    s = SizeY - Math.Floor(Me.Panel_AxMDisplay.Size.Height / ZoomY)
                    If s <= 0 Then
                        s = 0
                    End If
                    Me.SetVScrollBar(s)

                    If MdispInquire(Me.m_AxMDisplay, M_WINDOW_PAN_X, M_NULL) > Me.HScrollBar.Maximum _
                        Or MdispInquire(Me.m_AxMDisplay, M_WINDOW_PAN_Y, M_NULL) > Me.VScrollBar.Maximum Then

                        MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Maximum, Me.VScrollBar.Maximum)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.LogDailyManager("[MainForm.ResetScrollBar][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Reset Scroll Bar Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[MainForm.ResetScrollBar][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Reset Scroll Bar Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Zoom Operation --"

#Region "--- Button_ZoomIn_Click ---"
    Private Sub Button_ZoomIn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomIn.Click
        Dim s As Double
        Dim ZoomX As Double
        Dim CenterHScroll As Double
        Dim OffsetHScroll As Double
        Dim CenterVScroll As Double
        Dim OffsetVScroll As Double
        Dim DisplayWidth As Integer = Me.Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.Panel_AxMDisplay.Size.Height
        Dim Image As MIL_ID = M_NULL
        Dim SizeX As Integer
        Dim SizeY As Integer

        'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)
        s = ZoomX * Me.m_ZoomFactor
        MdispZoom(Me.m_AxMDisplay, s, s)
        Me.SetStatusBarPanel_Scale("縮放 = " & s)

        If Me.m_ZoomMax < s * Me.m_ZoomFactor Then
            Me.SetButton_ZoomIn(False)
        End If
        Me.SetButton_ZoomOut(True)

        Me.ResetScrollBar()


        If Me.m_MoveToCenter Then

            Image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
            SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
            SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)

            CenterHScroll = (Me.m_MouseX * Me.HScrollBar.Maximum) / (SizeX - DisplayWidth / s)
            OffsetHScroll = ((DisplayWidth / s) / 2) * (Me.HScrollBar.Maximum / (SizeX - DisplayWidth / s))
            CenterVScroll = (Me.m_MouseY * Me.VScrollBar.Maximum) / (SizeY - DisplayHeight / s)
            OffsetVScroll = ((DisplayHeight / s) / 2) * (Me.VScrollBar.Maximum / (SizeY - DisplayHeight / s))

            CenterHScroll = CenterHScroll - OffsetHScroll
            CenterVScroll = CenterVScroll - OffsetVScroll

            If CenterHScroll < 0 Then
                Me.HScrollBar.Value = 0
            ElseIf CenterHScroll > Me.HScrollBar.Maximum Then
                Me.HScrollBar.Value = Me.HScrollBar.Maximum
            Else
                If CenterHScroll > 0 Then Me.HScrollBar.Value = CenterHScroll
            End If

            If CenterVScroll < 0 Then
                Me.VScrollBar.Value = 0
            ElseIf CenterVScroll > Me.VScrollBar.Maximum Then
                Me.VScrollBar.Value = Me.VScrollBar.Maximum
            Else
                If CenterVScroll > 0 Then Me.VScrollBar.Value = CenterVScroll
            End If

            Me.m_MoveToCenter = False

        End If
    End Sub
#End Region

#Region "--- Button_ZoomOut_Click ---"
    Private Sub Button_ZoomOut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomOut.Click
        Dim s As Double
        Dim ZoomX As Double
        Dim CenterHScroll As Double
        Dim OffsetHScroll As Double
        Dim CenterVScroll As Double
        Dim OffsetVScroll As Double
        Dim DisplayWidth As Integer = Me.Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.Panel_AxMDisplay.Size.Height

        'ZoomX = MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, M_NULL)
        MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

        s = ZoomX / Me.m_ZoomFactor
        If s < Me.m_ZoomMin Then Exit Sub

        If s / Me.m_ZoomFactor < Me.m_ZoomMin Then
            Me.SetButton_ZoomOut(False)
            MdispZoom(Me.AxMDisplay, Me.m_ZoomMin, Me.m_ZoomMin)
            Me.ResetScrollBar()
        Else
            MdispZoom(Me.AxMDisplay, s, s)
            Me.SetStatusBarPanel_Scale("縮放 = " & s)
            Me.SetButton_ZoomIn(True)
            Me.ResetScrollBar()
        End If

        If Me.m_MoveToCenter Then

            CenterHScroll = (Me.m_MouseX * Me.HScrollBar.Maximum) / (Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - DisplayWidth / s)
            OffsetHScroll = ((DisplayWidth / s) / 2) * (Me.HScrollBar.Maximum / (Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - DisplayWidth / s))
            CenterVScroll = (Me.m_MouseY * Me.VScrollBar.Maximum) / (Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - DisplayHeight / s)
            OffsetVScroll = ((DisplayHeight / s) / 2) * (Me.VScrollBar.Maximum / (Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - DisplayHeight / s))

            CenterHScroll = CenterHScroll - OffsetHScroll
            CenterVScroll = CenterVScroll - OffsetVScroll

            If CenterHScroll < 0 Then
                Me.HScrollBar.Value = 0
            ElseIf CenterHScroll > Me.HScrollBar.Maximum Then
                Me.HScrollBar.Value = Me.HScrollBar.Maximum
            Else
                If CenterHScroll > 0 Then Me.HScrollBar.Value = CenterHScroll
            End If

            If CenterVScroll < 0 Then
                Me.VScrollBar.Value = 0
            ElseIf CenterVScroll > Me.VScrollBar.Maximum Then
                Me.VScrollBar.Value = Me.VScrollBar.Maximum
            Else
                If CenterVScroll > 0 Then Me.VScrollBar.Value = CenterVScroll
            End If

            Me.m_MoveToCenter = False

        End If
    End Sub
#End Region

#Region "--- Button_ZoomO_Click ---"
    Private Sub Button_ZoomO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomO.Click
        Call ImageZoomO()
    End Sub
#End Region

#Region "--- ImageZoomO ---"
    Public Sub ImageZoomO()
        MdispZoom(Me.AxMDisplay, 1, 1)
        Me.SetStatusBarPanel_Scale("縮放 = " & 1.0)
        Me.SetButton_ZoomIn(True)
        Me.SetButton_ZoomOut(True)
        Me.ResetScrollBar()
    End Sub
#End Region

#Region "--- Button_ZoomAll_Click ---"
    Private Sub Button_ZoomAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ZoomAll.Click
        Call ImageZoomAll()
    End Sub
#End Region

#Region "--- ImageZoomAll ---"
    Public Sub ImageZoomAll()
        Dim image As MIL_ID = M_NULL
        Dim sx As Double
        Dim sy As Double
        Dim s_Max As Double
        Dim s_Min As Double

        image = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)
        If image = M_NULL Then Exit Sub

        Dim SizeX As Integer
        Dim SizeY As Integer
        Dim DisplayWidth As Integer = Me.Panel_AxMDisplay.Size.Width
        Dim DisplayHeight As Integer = Me.Panel_AxMDisplay.Size.Height

        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

        If SizeX > 0 And SizeY > 0 Then
            sx = DisplayWidth / SizeX
            sy = DisplayHeight / SizeY
            s_Max = Math.Max(sx, sy)
            s_Min = Math.Min(sx, sy)

            'If s < 0.1 Then s = 0.1
            MIL.MdispZoom(Me.m_AxMDisplay, s_Min, s_Min)
            Me.SetStatusBarPanel_Scale("縮放 = " & s_Min)
        End If

        If Me.m_ZoomMax < s_Max * Me.m_ZoomFactor Then
            Me.SetButton_ZoomIn(False)
        Else
            Me.SetButton_ZoomIn(True)
        End If
        If sx / Me.m_ZoomFactor < Me.m_ZoomMin Then
            Me.SetButton_ZoomOut(False)
        Else
            Me.SetButton_ZoomOut(True)
        End If

        Me.ResetScrollBar()
    End Sub
#End Region

#End Region

#Region "--- AxMDisplay Operation ---"

#Region "--- Panel_AxMDisplay_MouseDown ---"
    Private Sub Panel_AxMDisplay_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel_AxMDisplay.MouseDown
        If e.Button = Windows.Forms.MouseButtons.Right Then
            Me.ContextMenuStrip = ZoomContextMenuStrip
        ElseIf e.Button = Windows.Forms.MouseButtons.Middle Then
            If Me.m_MousreHScroll Then
                Me.m_MousreHScroll = False
            Else
                Me.m_MousreHScroll = True
            End If
        End If
    End Sub
#End Region

#Region "--- Panel_AxMDisplay_MouseMove ---"
    Private Sub Panel_AxMDisplay_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel_AxMDisplay.MouseMove
        Dim lFetchedValue() As Integer = {0} ' Label of the background.
        Dim image As MIL_ID = MdispInquire(Me.m_AxMDisplay, M_SELECTED, M_NULL)

        Try
            If image <> MIL.M_NULL Then
                Dim SizeX As Integer
                Dim SizeY As Integer
                Dim ZoomX As Double

                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)

                'ZoomX = MIL.MdispInquire(Me.AxMDisplay, MIL.M_ZOOM_FACTOR_X, M_NULL)
                MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, ZoomX)

                If ZoomX > 0 Then
                    Me.m_MouseX = Math.Floor((e.X) / ZoomX)
                    Me.m_MouseX += Me.HScrollBar.Value
                    Me.m_MouseY = Math.Floor((e.Y) / ZoomX)
                    Me.m_MouseY += Me.VScrollBar.Value

                    If Me.m_MouseX < SizeX AndAlso Me.m_MouseY < SizeY AndAlso Me.m_MouseX > 0 AndAlso Me.m_MouseY > 0 Then
                        MIL.MbufGet2d(image, Me.m_MouseX, Me.m_MouseY, 1, 1, lFetchedValue)
                        Me.LabelXYValue(Me.m_MouseX, Me.m_MouseY, lFetchedValue(0))
                        Me.StatusBarXYV("(" & Me.m_MouseX & "," & Me.m_MouseY & ")", lFetchedValue(0))
                    Else
                        If Me.m_MouseX < 0 Then Me.m_MouseX = 1
                        If Me.m_MouseY < 0 Then Me.m_MouseY = 1
                        If Me.m_MouseX > SizeX Then Me.m_MouseX = SizeX - 1
                        If Me.m_MouseY > SizeY Then Me.m_MouseY = SizeY - 1

                        Me.LabelXYValue("NULL", "NULL", "NULL")
                        Me.StatusBarXYV("NULL", "NULL")
                    End If
                End If
            Else
                Me.LabelXYValue("NULL", "NULL", "NULL")
                Me.StatusBarXYV("NULL", "NULL")
            End If
        Catch ex As Exception
            Throw New Exception("[MainForm.ShowValue]Show Value Error!(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#Region "--- Main_Form_MouseWheel ---"
    Private Sub Main_Form_MouseWheel(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseWheel
        Dim Zoom As Double
        Dim SetValue As Integer
        Dim numberOfTextLinesToMove As Integer = CInt(e.Delta)
        Dim numberOfPixelsToMove As Integer = 0

        Me.m_PaintStop = True

        If Me.m_MousreHScroll Then
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_X, Zoom)
            numberOfPixelsToMove = numberOfTextLinesToMove * Zoom * 1.2
            If numberOfPixelsToMove <> 0 Then
                SetValue = Me.HScrollBar.Value + numberOfTextLinesToMove
                If SetValue > Me.HScrollBar.Maximum Then
                    Me.HScrollBar.Value = Me.HScrollBar.Maximum
                    SetValue = Me.HScrollBar.Maximum
                ElseIf SetValue < Me.HScrollBar.Minimum Then
                    Me.HScrollBar.Value = Me.HScrollBar.Minimum
                    SetValue = Me.HScrollBar.Minimum
                Else
                    If SetValue > 0 Then Me.HScrollBar.Value = SetValue
                End If
                MdispPan(Me.m_AxMDisplay, SetValue, Me.VScrollBar.Value)
            End If
        Else
            MdispInquire(Me.m_AxMDisplay, M_ZOOM_FACTOR_Y, Zoom)
            numberOfPixelsToMove = numberOfTextLinesToMove * Zoom * 0.8
            If numberOfPixelsToMove <> 0 Then
                SetValue = Me.VScrollBar.Value - numberOfTextLinesToMove
                If SetValue > Me.VScrollBar.Maximum Then
                    Me.VScrollBar.Value = Me.VScrollBar.Maximum
                    SetValue = Me.VScrollBar.Maximum
                ElseIf SetValue < Me.VScrollBar.Minimum Then
                    Me.VScrollBar.Value = Me.VScrollBar.Minimum
                    SetValue = Me.VScrollBar.Minimum
                Else
                    If SetValue > 0 Then Me.VScrollBar.Value = SetValue
                End If
                MdispPan(Me.m_AxMDisplay, Me.HScrollBar.Value, SetValue)
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- Main_Form_Resize ---"
    Private Sub Main_Form_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        '--- Hide Ti Icon ---
        If Not Me.m_MainProcess Is Nothing AndAlso Me.m_MainProcess.AreaBootConfig.UI_AreaGrabber_HideToIcon_Enable.Value Then
            If (Me.WindowState = FormWindowState.Minimized) Then
                Me.NotifyIcon_AreaGrabber.Visible = True
                Me.Hide()
            Else
                Me.NotifyIcon_AreaGrabber.Visible = False
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- Dialog Closing Event ---"

#Region "--- Mura ---"
    Private Sub m_DialogMuraAutoManual_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraAutoManual.Closing
        Me.m_DialogMuraAutoManual = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraBoundary_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraBoundary.Closing
        Me.m_DialogMuraBoundary = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraSmooth_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraSmooth.Closing
        Me.m_DialogMuraSmooth = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraCollection_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraCollection.Closing
        Me.m_DialogMuraCollection = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogBlobMuralLocal_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogBlobMuraLocal.Closing
        Me.m_DialogBlobMuraLocal = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogBlobMuralRound_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogBlobMuraRound.Closing
        Me.m_DialogBlobMuraRound = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogBandMura_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogBandMura.Closing
        Me.m_DialogBandMura = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraJND_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraJND.Closing
        Me.m_DialogMuraJND = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraFalseDefect_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraFalseDefect.Closing
        Me.m_DialogMuraFalseDefect = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraResult_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraResult.Closing
        Me.m_DialogMuraResult = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraSettingBase_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraSettingBase.Closing
        Me.m_DialogMuraSettingBase = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMuraSetting_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMuraSetting.Closing
        Me.m_DialogMuraSetting = Nothing
        Me.Focus()
    End Sub
#End Region

#Region "--- Func ---"
    Private Sub m_DialogFuncResult_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogFuncResult.Closing
        Me.m_DialogFuncResult = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogFuncFalseDefect_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogFuncFalseDefect.Closing
        Me.m_DialogFuncFalseDefect = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogFuncSetting_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogFuncSetting.Closing
        Me.ComboBox_Pattern_MainFrm.Enabled = True   '12/06 Add, Avoid error when adjusting\saving func parameters.
        Me.m_DialogFuncSetting = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogFuncSettingBase_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogFuncSettingBase.Closing
        Me.m_DialogFuncSettingBase = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogADJMean_Closing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles m_DialogADJMean.FormClosing
        Me.m_DialogADJMean = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogFuncTestImgProc_Closing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles m_DialogFuncTestImgProc.FormClosing
        Me.m_DialogFuncTestImgProc = Nothing
        Me.Focus()
    End Sub
#End Region

#Region "--- MappingTable ---"
    Private Sub m_DialogSetMappingTable_Closing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles m_DialogSetMappingTable.FormClosing
        Me.m_DialogSetMappingTable = Nothing
        Me.Focus()
    End Sub
#End Region

#Region "--- Recipe ---"
    Private Sub m_DialogIPNetWorkConfig_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogIPNetWorkConfig.Closing
        Me.m_DialogIPNetWorkConfig = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogIPBootConfig_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogIPBootConfig.Closing
        Me.m_DialogIPBootConfig = Nothing
        Me.Focus()
    End Sub
#End Region

#Region "--- Measurement ---"
    Private Sub m_DialogCalculateMeasurement_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogCalculateMeasurement.Closing
        Me.m_DialogCalculateMeasurement = Nothing
        Me.Focus()
    End Sub
#End Region

#Region "--- Tool ---"
    Private Sub m_DialogLookupPosition_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogLookupPosition.Closing
        Me.m_DialogLookupPosition = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogMDCSetting_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogMDCSetting.Closing
        Me.m_DialogMDCSetting = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogCameraAlignment_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogCameraAlignment.Closing
        Me.m_DialogCameraAlignment = Nothing
        Me.Focus()
    End Sub
    Private Sub m_DialogRMSSetting_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles m_DialogRMSSetting.Closing
        Me.m_DialogRMSSetting = Nothing
        Me.Focus()
    End Sub
#End Region

#End Region

#Region "--- SetPatternIndex ---"
    Public Sub SetPatternIndex(ByVal i As Integer)
        'ErrorCode = 260
        'i值 ,m_MuraProcess.Pattern值 ,m_FuncProcess.Pattern 值從[1]開始
        Dim count1 As Integer
        Dim count2 As Integer

        If Me.m_MainProcess.IPBootConfig.MuraUI.Value Then
            count1 = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
        End If
        count2 = Me.m_MainProcess.FuncProcess.FuncModelRecipe.PatternCount.Value

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 260
        Try
            If i < count1 + 1 And i <> 0 Then
                Me.m_MuraProcess.Pattern = i
                Me.SetPatternIndexInfo(i)   '從[1]開始
            ElseIf count1 < i And i <= (count1 + count2) Then
                Me.m_MainProcess.FuncProcess.Pattern = i - count1
                Me.SetPatternIndexInfo(i)   '從[1]開始
            End If
        Catch ex As Exception
            'Me.OutputInfo("[SetPatternIndex][ErrorCode = " & Me.m_ErrorCode & "] Set Pattern Recipe Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[SetPatternIndex][ErrorCode = " & Me.m_MainProcess.ErrorCode & "] Set Pattern Recipe Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Button Event ---"

#Region "--- Main UI Button ---"

#Region "--- btnClearLog_Click ---"
    Private Sub btnClearLog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClearLog.Click
        Me.txtOutput.Text = ""
    End Sub
#End Region

#Region "--- Button_InitialIP_Click ---"
    Private Sub Button_InitialIP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_InitialIP.Click
        Me.Button_Enable(False)
        If Not Me.m_MainProcess.ReStart_IP() Then
            MsgBox("[ReStart_IP] ReStart IP Program Fail ! ...")
        End If
        Me.Button_Enable(True)
    End Sub
#End Region

#Region "--- Button_KillIP_Click ---"
    Private Sub Button_KillIP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_KillIP.Click
        Me.Button_Enable(False)
        If Not Me.m_MainProcess.Kill_IP() Then
            MsgBox("[Kill_IP] Kill IP Program Fail ! ...")
        End If
        Me.Button_Enable(True)
    End Sub
#End Region

#Region "--- Button_FuncResult_Click ---"
    Private Sub Button_FuncResult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FuncResult.Click
        Me.ShowFuncResult()
    End Sub
#End Region

#Region "--- Button_MuraResult_Click ---"
    Private Sub Button_MuraResult_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MuraResult.Click
        If GetCaptureStatus() Then Return
        Me.ShowMuraResult()
    End Sub
#End Region

#Region "--- Button_Load_Click ---"
    Private Sub Button_Load_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LoadImage.Click

        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim image3 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim Parameter_Lists As String = ""
        Dim Parameter_Lists1 As String = ""      'grant add mappingtable
        Dim OutputString As String = ""
        Dim FilePath As String = ""
        Dim FileName As String = ""
        Dim IP_Address As String = ""
        Dim FuncProcess As ClsFuncProcess
        Dim SizeX, SizeY, Type As Integer
        Dim SaveAI As String = ""

        Try
            Dim btn As Button = Convert.ChangeType(sender, GetType(Button))
            Me.OutputInfo("Load Image, Button Name : " & btn.Name)
            Me.Button_LoadImage.Enabled = False
            Me.Button_SaveImage.Enabled = False

            If Me.CheckBox_SaveAI.Checked Then
                SaveAI = "ODT"
            Else
                SaveAI = ""
            End If

            If Not Me.m_DialogADJMean Is Nothing Then Me.SetDialogADJMean(False)

            FuncProcess = Me.m_MainProcess.FuncProcess

            '--- 建立連線 ---
            If Not Me.ConnectToIP(CInt(Me.ComboBox_CCD.Text), Me.ComboBox_GrabNo.Text) Then
                Me.ComboBox_CCD.SelectedIndex = -1
                Me.Button_LoadImage.Enabled = True
                Exit Sub
            End If

            If SaveAI <> "" Then
                If Not Me.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                    'MessageBox.Show("請選擇Mura Pattern for Save AI Image!!")
                    Throw New Exception("請選擇Mura Pattern for Save AI Image!!")
                End If
            Else
                If Me.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                    Me.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
                Else
                    Me.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
                End If
            End If

            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            Me.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.OpenFileDialog.FileName = ""
            Me.OpenFileDialog.ShowDialog()

            If SaveAI = "" Then
                If Me.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1 Then
                    Me.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraPatternRecipeArray.Count
                End If
            End If

            If Me.OpenFileDialog.FileName <> "" Then
                'Change FilePath to UNC path
                FilePath = GetUNCPath(Me.OpenFileDialog.FileName)
                FileName = System.IO.Path.GetFileNameWithoutExtension(FilePath)
                If FileName.Split("_")(0) <> "" Then
                    Me.m_PanelID = FileName.Split("_")(0)
                Else
                    Me.m_PanelID = "AAAAAAAA"
                End If
                If Not Me.m_DialogFuncTestImgProc Is Nothing Then
                    Me.m_DialogFuncTestImgProc.PanelID = Me.m_PanelID
                End If
                'Check
                If (FilePath.Contains("_FFunc") Or FilePath.Contains("_FMura")) And Me.m_MainProcess.IPBootConfig.GigE_SerialNum.Value <> "5978" Then
                    If System.IO.Path.GetFileNameWithoutExtension(FilePath).Split("_")(2) <> Me.m_MainProcess.CCDNo Then
                        If MsgBox("載入影像非所選擇CCD,是否載入?", vbOKCancel, "請確認") = MsgBoxResult.Cancel Then
                            Me.Button_LoadImage.Enabled = True
                            Me.Button_SaveImage.Enabled = True
                            Exit Sub
                        Else
                            'Me.Button_Load.Enabled = True
                            'Me.Button_Save.Enabled = True
                            'Exit Sub
                        End If
                    End If
                End If
                image = FuncProcess.Img_Original_NonPage

                '[AreaGrabber] Load Image --- (For Display)
                '[1] image ---
                MbufDiskInquire(FilePath, M_SIZE_X, SizeX)
                MbufDiskInquire(FilePath, M_SIZE_Y, SizeY)
                MbufDiskInquire(FilePath, M_TYPE, Type)
                If image <> M_NULL Then
                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(image)
                        image = M_NULL
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FilePath, image)

                '[2] Img_16U_Grab ---
                If image <> M_NULL Then
                    If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                        MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                        Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                Else
                    Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                End If
                MbufLoad(FilePath, Me.m_MainProcess.Img_16U_Grab_1)

                Me.StatusBarStatus(Path.GetFileName(FilePath))
                'If Me.ComboBox_CCD.Text <> "" Then
                '    iCheckLoadImage = InStr(1, Me.OpenFileDialog.FileName, "IP" & Me.ComboBox_CCD.Text, CompareMethod.Text)
                '    If Not (iCheckLoadImage > 0) Then
                '        MsgBox("請檢查所開啟的影像檔案是否符合目前IP No !( " & Me.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                '    End If
                'End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", FilePath, SaveAI, , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        End If
                        Response_OK = True
                        If SubSystemResult.Responses(0).Param1 = "1" Then
                            Me.CheckBox_IsAligned.Checked = True
                            FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                            FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                            FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                            FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                            If FuncProcess.FuncModelRecipe.LeftAnalysis.Value Then
                                MuraProcess.MuraModelRecipe.Table.LeftX = FuncProcess.FuncModelRecipe.Boundary.LeftX
                            End If
                            If FuncProcess.FuncModelRecipe.TopAnalysis.Value Then
                                MuraProcess.MuraModelRecipe.Table.TopY = FuncProcess.FuncModelRecipe.Boundary.TopY
                            End If
                            If FuncProcess.FuncModelRecipe.RightAnalysis.Value Then
                                MuraProcess.MuraModelRecipe.Table.RightX = FuncProcess.FuncModelRecipe.Boundary.RightX
                            End If
                            If FuncProcess.FuncModelRecipe.BottomAnalysis.Value Then
                                MuraProcess.MuraModelRecipe.Table.BottomY = FuncProcess.FuncModelRecipe.Boundary.BottomY
                            End If
                            strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                            RepairPath_2(strPath)
                            MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.MainProcess.FuncProcess.FuncModelRecipe, strPath)
                            strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.GetProductNameInfo & "\Mura\MuraModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                            RepairPath_2(strPath)
                            MILOperationLib.ClsMuraModelRecipe.WriteXML(Me.MainProcess.MuraProcess.MuraModelRecipe, strPath)
                        Else
                            Me.CheckBox_IsAligned.Checked = False
                        End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Main_Form.Button_Load_Click]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_LoadImage.Enabled = True
                        Me.Button_SaveImage.Enabled = True
                        Exit Sub
                    End If

                    If Me.ComboBox_Type.SelectedIndex = 0 And Me.ComboBox_Select.SelectedIndex = 2 Then
                        If image <> M_NULL Then
                            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                            Type = MbufInquire(image, M_TYPE, M_NULL)

                            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                MbufFree(imageBuffer)
                                imageBuffer = M_NULL
                                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                            MbufCopy(image, imageBuffer)

                            MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, Me.Panel_AxMDisplay.Handle)
                            MbufControl(image, M_MODIFIED, M_DEFAULT)
                            MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                            Me.ResetScrollBar()
                        End If
                    Else
                        Me.CurrentIndex0 = 2
                        Me.ComboBox_Type.SelectedIndex = 0
                        Me.ComboBox_Select.SelectedIndex = 2
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try


                If (Me.m_MainProcess.IPBootConfig.MuraUI.Value) Then

                    '----------------------------------------------------------------------------------------------
                    ' Transfer Mura Boundary  ==> Request_Command = "Transfer_Mura_Boundary" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "Transfer_Mura_Boundary"
                        TimeOut = 10000 '10 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param2.Split(";")(0))
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param2.Split(";")(1))
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2.Split(";")(2))
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param2.Split(";")(3))
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Button_Enable(True)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                    '[AreaGrabber] Load image2 --- (For Display)
                    '[1] image2 ---
                    MbufDiskInquire(Me.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                    MbufDiskInquire(Me.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                    MbufDiskInquire(Me.OpenFileDialog.FileName, M_TYPE, Type)
                    If image2 <> M_NULL Then
                        If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image2)
                            image2 = M_NULL
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.OpenFileDialog.FileName, image2)

                    ''[2] Img_16U_Grab ---
                    'If Not Me.m_MainProcess.IPBootConfig.FuncUI.Value Then
                    '    If image2 <> M_NULL Then
                    '        If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                    '            MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                    '            Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                    '            Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    '        End If
                    '    Else
                    '        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    '    End If
                    '    MbufLoad(Me.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)
                    'End If

                    'If Not Response_OK Then
                    '    Me.Button_Load.Enabled = True
                    '    Me.Button_Save.Enabled = True
                    '    Exit Sub
                    'End If

                    '--- Resize Original image ---
                    If MbufInquire(image, M_SIZE_X, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 100 And MbufInquire(image, M_SIZE_Y, M_NULL) > Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 100 Then
                        '----------------------------------------------------------------------------------------------
                        ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "RESIZE_ORIGINAL"
                            TimeOut = 100000 '100 secs
                            SaveImage = True

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Main_Form.Button_Load_Click]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.Button_LoadImage.Enabled = True
                                Me.Button_SaveImage.Enabled = True
                                Exit Sub
                            End If

                            If SaveImage AndAlso Response_OK Then
                                '[1] Update Processed Image ---
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    image3 = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                                Else
                                    image3 = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                                End If

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If image <> M_NULL Then
                                        If MbufInquire(image3, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image3, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(image3)
                                            image3 = M_NULL
                                            image3 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        image3 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, image3)
                                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                        MbufCopy(image3, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                                    Else
                                        MbufCopy(image3, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                                    End If

                                    If System.IO.File.Exists(strPath) = True Then
                                        System.IO.File.Delete(strPath)
                                    End If
                                End If


                                If Me.OpenFileDialog.FileName <> "" Then
                                    If MbufInquire(Me.m_MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_MainProcess.IPBootConfig.ImageSizeX.Value And MbufInquire(Me.m_MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_MainProcess.IPBootConfig.ImageSizeY.Value Then
                                        Try
                                            If Me.m_MainProcess.FuncProcess.Img_Original_NonPage <> M_NULL Then Me.m_MainProcess.FuncProcess.CalculateOriginalROI(Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                                        Catch ex As Exception
                                            MessageBox.Show("請重新執行Align，[Func 基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        End Try
                                        Me.m_MainProcess.FuncProcess.Func_Set_HWAcc(Me.m_MainProcess.IPBootConfig, Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)

                                        '--- 顯示功能 ---
                                        SizeX = MbufInquire(Me.m_MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                                        SizeY = MbufInquire(Me.m_MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                                        Type = MbufInquire(Me.m_MainProcess.Img_FixRecipe_NonPage, M_TYPE, M_NULL)

                                        If Me.m_MainProcess.Img_FixRecipe_NonPage <> M_NULL Then
                                            MbufFree(Me.m_MainProcess.Img_FixRecipe_NonPage)
                                            Me.m_MainProcess.Img_FixRecipe_NonPage = M_NULL
                                        End If
                                        Me.m_MainProcess.Img_FixRecipe_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                    Else
                                        If Me.m_MainProcess.FuncProcess.Img_OriginalROI <> M_NULL Then
                                            MbufFree(Me.m_MainProcess.FuncProcess.Img_OriginalROI)
                                            Me.m_MainProcess.FuncProcess.Img_OriginalROI = M_NULL
                                        End If

                                        SizeX = MbufInquire(Me.m_MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                                        SizeY = MbufInquire(Me.m_MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                                        Me.m_MainProcess.FuncProcess.Img_OriginalROI = MbufChild2d(Me.m_MainProcess.FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                                    End If
                                End If

                                ''--- Display Image ---   
                                'If Me.GetPatternIndexInfo < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                                '    If image <> M_NULL Then
                                '        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                '        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                                '        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                                '        Type = MbufInquire(image, M_TYPE, M_NULL)

                                '        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                '            MbufFree(imageBuffer)
                                '            imageBuffer = M_NULL
                                '            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                '        End If
                                '        MbufCopy(image, imageBuffer)

                                '        MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, Me.Panel_AxMDisplay.Handle)
                                '        MbufControl(image, M_MODIFIED, M_DEFAULT)
                                '        MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                '        Me.ResetScrollBar()
                                '    End If
                                'End If
                                Me.ImageUpdate()
                            End If

                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try
                    End If
                End If

            End If

            If Me.OpenFileDialog.FileName <> "" Then
                If MbufInquire(FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.m_MainProcess.IPBootConfig.ImageSizeX.Value And MbufInquire(FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.m_MainProcess.IPBootConfig.ImageSizeY.Value Then
                    Try
                        If FuncProcess.Img_Original_NonPage <> M_NULL Then FuncProcess.CalculateOriginalROI(FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(FuncProcess.Img_OriginalROI)
                        FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    FuncProcess.Img_OriginalROI = MbufChild2d(FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
            End If
            Call Me.ImageZoomAll()

            For i = 0 To Me.ComboBox_Pattern_MainFrm.Items.Count - 1
                If Me.OpenFileDialog.FileName.Contains(Me.ComboBox_Pattern_MainFrm.Items(i)) Then
                    Me.ComboBox_Pattern_MainFrm.SelectedIndex = i
                    Exit For
                End If
            Next

            '--- Button Control ---   
            Me.Button_LoadImage.Enabled = True
            Me.Button_SaveImage.Enabled = True
        Catch ex As Exception
            Me.Button_LoadImage.Enabled = True
            Me.Button_SaveImage.Enabled = True
            Me.OutputErrorInfo("[Dialog_FuncSettingBase.Button_LoadImage]" & ex.Message)
            MessageBox.Show("[Form_Main.Button_LoadImage]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button_Save_Click ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SaveImage.Click
        If Me.m_Img_Current = M_NULL Then
            MsgBox("[Save Image] 沒有可存取之影像", MsgBoxStyle.Critical, "[AreaGrabber]")
        Else
            If Me.m_Img_Current <> M_NULL Then
                Me.SetButton_Save(False)

                Me.SaveFileDialog.FileName = ""
                If Me.SaveFileDialog.ShowDialog() = DialogResult.OK Then
                    If Me.SaveFileDialog.FileName <> "" Then
                        MbufSave(Me.SaveFileDialog.FileName, Me.m_Img_Current)
                    End If
                End If

                Me.SetButton_Save(True)
            Else
                MsgBox("[Save Image] 沒有可存取之影像", MsgBoxStyle.Critical, "[AreaGrabber]")
            End If
        End If
    End Sub
#End Region

#Region "--- Button_Log_Open_Click ---"
    Private Sub Button_Log_Open_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Log_Open.Click
        Dim GrabNo As String = ""
        Dim sRet As String = ""

        If Me.ComboBox_Log_IPNo.Text = "" Then
            MessageBox.Show("請選擇 IP No !", "注意", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If
        If Me.ComboBox_Log_Type.Text = "" Then
            MessageBox.Show("請選擇 Log File Type !", "注意", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Exit Sub
        End If

        Me.Button_Log_Open.Enabled = False

        Me.Change_GrabNo(Val(Me.ComboBox_Log_IPNo.Text), GrabNo)
        sRet = Me.Open_Log_File(Me.ComboBox_Log_Type.SelectedIndex, Val(Me.ComboBox_Log_IPNo.Text), GrabNo, Me.DateTimePicker_Log.Value.ToString("yyyyMMdd"))
        If sRet <> "" Then
            MsgBox("[MainProcess.Button_Log_Open] " & sRet)
        End If

        Me.Button_Log_Open.Enabled = True
    End Sub
#End Region

#Region "--- Button_OMS_Save_Click ---"
    Private Sub Button_OMS_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_OMS_Save.Click
        '--- OMS Enable IP NO --- 
        Me.m_MainProcess.MeasProcess.MeasBootConfig.OMS_Enable_IPNo.Value = Val(Me.ComboBox_OMS_Enable_IPNo.Text)
        Me.m_MainProcess.MeasProcess.SaveMeasBootConfig(Me.m_MainProcess.BootRecipePath)
    End Sub
#End Region

#Region "--- Button_QuickAlign_Click ---"
    Private Sub Button_QuickAlign_Click(sender As System.Object, e As System.EventArgs) Handles Button_QuickAlign.Click

        Dim SizeX, SizeY As Integer
        '----------------------------------------------------------------------------------------------------------------------
        'Calculate Func Original Boundary (Func's ROI)  ==> Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY"
            TimeOut = 3000000 '3000 secs

            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, "0", "Defect", , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                If SubSystemResult.Responses(0).Param3 = "False" Then
                    Me.OutputInfo(SubSystemResult.Responses(0).Param4)
                    Me.StatusBarIPStatus(SubSystemResult.Responses(0).Param4)
                Else
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK, Align_OK = " & SubSystemResult.Responses(0).Param3 & ", " & SubSystemResult.Responses(0).Param4)


                    '--- Status Message ---
                    Me.OutputInfo(SubSystemResult.Responses(0).Param4)

                    '---Load After RotateCal Image---
                    If Me.MainProcess.FuncProcess.FuncModelRecipe.RotateCal.Value = True Then
                        Me.Load_RotateCalImg()
                    End If
                End If

            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Alignment Fail !(" & SubSystemResult.Responses(0).Param2 & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment_Click]" & SubSystemResult.Responses(0).Param2, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '--- Calculate ROI Image ---
        Try
            If Me.OpenFileDialog.FileName <> "" Then
                If MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.MainProcess.IPBootConfig.ImageSizeX.Value And MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.MainProcess.IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.MainProcess.FuncProcess.Img_Original_NonPage <> M_NULL Then Me.MainProcess.FuncProcess.CalculateOriginalROI(Me.MainProcess.FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If Me.MainProcess.FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.MainProcess.FuncProcess.Img_OriginalROI)
                        Me.MainProcess.FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.MainProcess.FuncProcess.Img_OriginalROI = MbufChild2d(Me.MainProcess.FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
            End If
        Catch ex As Exception
            Throw New Exception("Calculate Func ROI Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

        '--- 更新路徑 ---
        strPath = Me.MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
        RepairPath_2(strPath)
        MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.MainProcess.FuncProcess.FuncModelRecipe, strPath)

        '----------------------------------------------------------------------------------------------
        ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_FUNC_MODEL_RECIPE"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Save MappingTable Recipe  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_MAPPINGTABLE_RECIPE"
            TimeOut = 200000 '200 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Transfer ROI to Mura Boundary & Save  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        If Me.MainProcess.IPBootConfig.MuraUI.Value Then
            Try
                '--- Prepare Command ---
                Request_Command = "TRANSFER_MURA_BOUNDARY_SAVERECIPE"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If

                Me.MainProcess.LoadMuraRecipe()


            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        End If
    End Sub
#End Region

#Region "--- Button_ImgCal_Click ---"
    Private Sub Button_ImgCal_Click(sender As System.Object, e As System.EventArgs) Handles Button_ImgCal.Click
        Dim SizeX, SizeY As Integer
        '----------------------------------------------------------------------------------------------------------------------
        'Calculate Func Original Boundary (Func's ROI)  ==> Request_Command = "CALCULATE_FUNC_ORIGINALBOUNDARY" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "IMG_CAL"
            TimeOut = 3000000 '3000 secs

            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                If SubSystemResult.Responses(0).Param3 = "False" Then
                    Me.OutputInfo(SubSystemResult.Responses(0).Param4)
                    Me.StatusBarIPStatus(SubSystemResult.Responses(0).Param4)
                Else
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK, Align_OK = " & SubSystemResult.Responses(0).Param3 & ", " & SubSystemResult.Responses(0).Param4)


                    '--- Status Message ---
                    Me.OutputInfo(SubSystemResult.Responses(0).Param4)

                    '---Load After RotateCal Image---
                    If Me.MainProcess.FuncProcess.FuncModelRecipe.RotateCal.Value = True Then
                        Me.Load_RotateCalImg()
                    End If
                End If

            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Alignment Fail !(" & SubSystemResult.Responses(0).Param2 & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment_Click]" & SubSystemResult.Responses(0).Param2, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '--- Calculate ROI Image ---
        Try
            If Me.OpenFileDialog.FileName <> "" Then
                If MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL) = Me.MainProcess.IPBootConfig.ImageSizeX.Value And MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL) = Me.MainProcess.IPBootConfig.ImageSizeY.Value Then
                    Try
                        If Me.MainProcess.FuncProcess.Img_Original_NonPage <> M_NULL Then Me.MainProcess.FuncProcess.CalculateOriginalROI(Me.MainProcess.FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Catch ex As Exception
                        MessageBox.Show("請重新執行Align，[Func基本設定]->[Alignment]", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                Else
                    If Me.MainProcess.FuncProcess.Img_OriginalROI <> M_NULL Then
                        MbufFree(Me.MainProcess.FuncProcess.Img_OriginalROI)
                        Me.MainProcess.FuncProcess.Img_OriginalROI = M_NULL
                    End If

                    SizeX = MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.MainProcess.FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
                    Me.MainProcess.FuncProcess.Img_OriginalROI = MbufChild2d(Me.MainProcess.FuncProcess.Img_Original_NonPage, 0, 0, SizeX, SizeY, M_NULL)
                End If
            End If
        Catch ex As Exception
            Throw New Exception("Calculate Func ROI Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

        '--- 更新路徑 ---
        strPath = Me.MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
        RepairPath_2(strPath)
        MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.MainProcess.FuncProcess.FuncModelRecipe, strPath)

        '----------------------------------------------------------------------------------------------
        ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_FUNC_MODEL_RECIPE"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Save MappingTable Recipe  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_MAPPINGTABLE_RECIPE"
            TimeOut = 200000 '200 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Transfer ROI to Mura Boundary & Save  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        If Me.MainProcess.IPBootConfig.MuraUI.Value Then
            Try
                '--- Prepare Command ---
                Request_Command = "TRANSFER_MURA_BOUNDARY_SAVERECIPE"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)   'grant add mapping table
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Alignment]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If

                Me.MainProcess.LoadMuraRecipe()


            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        End If
    End Sub
#End Region

#End Region

#Region "--- Mura_Button ---"

#Region "--- Button_AutoManual_Click ---"
    Private Sub Button_MuraAutoTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MuraAutoTest.Click
        Try
            If GetCaptureStatus() Then Return
            If Not Me.m_DialogMuraAutoManual Is Nothing Then Me.m_DialogMuraAutoManual = Nothing
            Me.m_DialogMuraAutoManual = New Dialog_MuraAutoManual
            Me.m_DialogMuraAutoManual.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogMuraAutoManual)
            Me.m_DialogMuraAutoManual.Left = Me.Left + 510
            Me.m_DialogMuraAutoManual.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogMuraAutoManual.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_AutoManual_Click] Dialog Auto Manual Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraAutoManual = Nothing
            Me.TabControl_HightLevel.Enabled = True
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_MuraManualTest_Click ---"
    Private Sub Button_MuraManualTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MuraManualTest.Click
        If GetCaptureStatus() Then Return
        If Me.TabControl_SystemParam.SelectedIndex <> 4 Then

            Me.m_MuraParamUIIMP.Init()
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.GroupBox_ExpSetting.Enabled = True
            If Me.m_MainProcess.IsIPConnected = False Then
                Me.GroupBox_ExpSetting.Enabled = False
            End If

            Me.TabControl_SystemParam.SelectedIndex = 4
        End If

        'Me.Button_Boundary_Click()
    End Sub
#End Region

#Region "--- Button_Boundary_Click ---"
    Public Sub Button_Boundary_Click()
        Try
            If Not Me.m_DialogMuraBoundary Is Nothing Then Me.m_DialogMuraBoundary = Nothing
            Me.m_DialogMuraBoundary = New Dialog_MuraBoundary

            If Me.m_MainProcess.MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                Me.m_DialogMuraBoundary.SetMainForm(Me, DialogBoundaryTypeDefine.FFC, "zh-CN")
            Else
                Me.m_DialogMuraBoundary.SetMainForm(Me, DialogBoundaryTypeDefine.ORIGINAL, "zh-CN")
            End If

            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogMuraBoundary)
            Me.m_DialogMuraBoundary.Left = Me.Left + 510
            Me.m_DialogMuraBoundary.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogMuraBoundary.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_Boundary_Click] Dialog Mura Boundary Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraBoundary = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_Smooth_Click ---"
    Public Sub Button_Smooth_Click()
        Try
            If Not Me.m_DialogMuraSmooth Is Nothing Then Me.m_DialogMuraSmooth = Nothing
            Me.m_DialogMuraSmooth = New Dialog_MuraSmooth

            If Me.m_MainProcess.MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                Me.m_DialogMuraSmooth.SetMainForm(Me, DialogBoundaryTypeDefine.FFC, "zh-CN")
            Else
                Me.m_DialogMuraSmooth.SetMainForm(Me, DialogBoundaryTypeDefine.ORIGINAL, "zh-CN")
            End If
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogMuraSmooth)
            Me.m_DialogMuraSmooth.Left = Me.Left + 510
            Me.m_DialogMuraSmooth.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogMuraSmooth.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_Smooth_Click] Dialog Mura Smooth Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraSmooth = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region


#Region "--- Button_Collection_Click ---"
    Public Sub Button_Collection_Click()
        Try
            If Not Me.m_DialogMuraCollection Is Nothing Then Me.m_DialogMuraCollection = Nothing
            Me.m_DialogMuraCollection = New Dialog_MuraCollection
            Me.m_DialogMuraCollection.SetMainForm(Me)
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogMuraCollection)
            Me.m_DialogMuraCollection.Left = Me.Left + 510
            Me.m_DialogMuraCollection.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogMuraCollection.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_Collection_Click] Dialog Mura Collection Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraCollection = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_MuraLocation_Click ---"
    Public Sub Button_MuraLocation_Click()
        Try
            If Not Me.m_DialogBlobMuraLocal Is Nothing Then Me.m_DialogBlobMuraLocal = Nothing
            Me.m_DialogBlobMuraLocal = New Dialog_BlobMuraLocal
            Me.m_DialogBlobMuraLocal.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogBlobMuraLocal)
            Me.m_DialogBlobMuraLocal.Left = Me.Left + 510
            Me.m_DialogBlobMuraLocal.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogBlobMuraLocal.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_MuraLocation_Click] Dialog Blob Mura Loal Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogBlobMuraLocal = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_MuraRound_Click ---"
    Public Sub Button_MuraRound_Click()
        Try
            If Not Me.m_DialogBlobMuraRound Is Nothing Then Me.m_DialogBlobMuraRound = Nothing
            Me.m_DialogBlobMuraRound = New Dialog_BlobMuraRound
            Me.m_DialogBlobMuraRound.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogBlobMuraRound)
            Me.m_DialogBlobMuraRound.Left = Me.Left + 510
            Me.m_DialogBlobMuraRound.Top = Me.Top + 30
            If Me.m_MainProcess.IsIPConnected Then Me.m_DialogBlobMuraRound.Show()

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogBlobMuraRound.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_MuraRound_Click] Dialog Mura Round Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogBlobMuraRound = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_BandMura_Click ---"
    Public Sub Button_BandMura_Click()
        Try
            If Not Me.m_DialogBandMura Is Nothing Then Me.m_DialogBandMura = Nothing
            Me.m_DialogBandMura = New Dialog_BandMura
            Me.m_DialogBandMura.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogBandMura)
            Me.m_DialogBandMura.Left = Me.Left + 510
            Me.m_DialogBandMura.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogBandMura.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_BandMura_Click] Dialog Band Mura Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogBandMura = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_JND_Click ---"
    Private Sub Button_JND_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_JND.Click
        Try
            If GetCaptureStatus() Then Return
            If Not Me.m_DialogMuraJND Is Nothing Then Me.m_DialogMuraJND = Nothing
            Me.m_DialogMuraJND = New Dialog_MuraJND
            Me.m_DialogMuraJND.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogMuraJND)
            Me.m_DialogMuraJND.Left = Me.Left + 510
            Me.m_DialogMuraJND.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogMuraJND.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_JND_Click] Dialog Mura JND Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraJND = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_SettingBase_Click ---"
    Private Sub Button_SettingBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SettingBase.Click
        Try
            If Not Me.m_DialogMuraSettingBase Is Nothing Then Me.m_DialogMuraSettingBase = Nothing
            Me.m_DialogMuraSettingBase = New Dialog_MuraSettingBase
            Me.m_DialogMuraSettingBase.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogMuraSettingBase)
            Me.m_DialogMuraSettingBase.Left = Me.Left + 510
            Me.m_DialogMuraSettingBase.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogMuraSettingBase.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_SettingBase_Click] Dialog Mura Setting Base Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraSettingBase = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_SettingMura_Click ---"
    Private Sub Button_SettingMura_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SettingMura.Click
        Try
            If GetCaptureStatus() Then Return
            If Not Me.m_DialogMuraSetting Is Nothing Then Me.m_DialogMuraSetting = Nothing
            Me.m_DialogMuraSetting = New Dialog_MuraSetting
            Me.m_DialogMuraSetting.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogMuraSetting)
            Me.m_DialogMuraSetting.Left = Me.Left + 510
            Me.m_DialogMuraSetting.Top = Me.Top + 30

            If Me.m_MainProcess.IsIPConnected Then
                Me.m_DialogMuraSetting.Show()
            End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_SettingMura_Click] Dialog Mura Setting Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMuraSetting = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_MuraFalseDefect_Click ---"
    Private Sub Button_MuraFalseDefect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MuraFalseDefect.Click
        If GetCaptureStatus() Then Return
        Me.ShowFalse()
    End Sub
#End Region

#Region "--- Button_MuraCollect_Click ---"

    Private Sub Button_MuraCollect_Click(sender As System.Object, e As System.EventArgs) Handles Button_MuraCollect.Click
        Dim image As MIL_ID = M_NULL

        If Me.GetPatternIndexInfo() > Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1 Then
            Me.ComboBox_Pattern_MainFrm.SelectedIndex = 0
        End If

        image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
        If image <> M_NULL Then
            Me.CurrentIndex0 = 2
            Me.ComboBox_Type.SelectedIndex = 0
            Me.ComboBox_Select.SelectedIndex = 2
        End If
        ImageUpdate()
        Me.Button_ZoomAll.PerformClick()

        'CalculateBoundary
        If Not Me.m_DialogMuraBoundary Is Nothing Then Me.m_DialogMuraBoundary = Nothing
        Me.m_DialogMuraBoundary = New Dialog_MuraBoundary

        If Me.m_MainProcess.MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
            Me.m_DialogMuraBoundary.SetMainForm(Me, DialogBoundaryTypeDefine.FFC, "zh-CN")
        Else
            Me.m_DialogMuraBoundary.SetMainForm(Me, DialogBoundaryTypeDefine.ORIGINAL, "zh-CN")
        End If
        Me.m_DialogMuraBoundary.Calculate()
        Me.m_DialogMuraBoundary.Split()
        Me.m_DialogMuraBoundary = Nothing

        'CalculateSmooth
        If Not Me.m_DialogMuraSmooth Is Nothing Then Me.m_DialogMuraSmooth = Nothing
        Me.m_DialogMuraSmooth = New Dialog_MuraSmooth

        If Me.m_MainProcess.MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
            Me.m_DialogMuraSmooth.SetMainForm(Me, DialogBoundaryTypeDefine.FFC, "zh-CN")
            Me.m_DialogMuraSmooth.FFCAlign()
            Me.m_DialogMuraSmooth.Smooth()
            Me.m_DialogMuraSmooth.Save()
        ElseIf Me.m_MainProcess.MuraProcess.CurrentMuraPatternRecipe.UseFFT.Value Then
            Me.m_DialogMuraSmooth.SetMainForm(Me, DialogBoundaryTypeDefine.ORIGINAL, "zh-CN")
            Me.m_DialogMuraSmooth.CalculateFFT()
            Me.m_DialogMuraSmooth.Smooth()
            Me.m_DialogMuraSmooth.Save()
        ElseIf Me.m_MainProcess.MuraProcess.MuraModelRecipe.UseBLFFC.Value Then
            Me.m_DialogMuraSmooth.SetMainForm(Me, DialogBoundaryTypeDefine.ORIGINAL, "zh-CN")
            Me.m_DialogMuraSmooth.BLFFC()
            Me.m_DialogMuraSmooth.Smooth()
            Me.m_DialogMuraSmooth.Save()
        Else
            Me.m_DialogMuraSmooth.SetMainForm(Me, DialogBoundaryTypeDefine.ORIGINAL, "zh-CN")
            Me.m_DialogMuraSmooth.Smooth()
            Me.m_DialogMuraSmooth.Save()
        End If
        Me.m_DialogMuraSmooth = Nothing

        Me.Button_Collection_Click()

    End Sub

#End Region


#End Region

#Region "--- Func_Button ---"
#Region "--- Button_ProductModelSetting ---"
    Private Sub Button_ProductModelSetting_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ProductModelSetting.Click
        'If Me.m_ProductUIIMP.InitialFinished Then
        '    Me.m_ProductUIIMP.Init()
        'End If
        'Me.ReleaseAllUIIMP()
        'Check action non-Grab 
        If GetCaptureStatus() Then Return
        If Me.TabControl_SystemParam.SelectedIndex <> 0 Then
            Me.TabControl_SystemParam.SelectedIndex = 0
        End If
    End Sub
#End Region

#Region "--- Button_ADJMean_Click ---"
    Private Sub Button_ADJMean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_ADJMean.Click
        'If Me.m_AdjustExpTimeUIIMP.InitialFinished Then
        '    Me.m_AdjustExpTimeUIIMP.Init()
        'End If
        'Me.ReleaseAllUIIMP()

        Try
            If Me.TabControl_SystemParam.SelectedIndex <> 1 Then
                Me.m_AdjustExpTimeUIIMP.Init()

                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.GroupBox_ExpSetting.Enabled = True
                If Me.m_MainProcess.IsIPConnected = False Then
                    Me.GroupBox_ExpSetting.Enabled = False
                End If

                Me.TabControl_SystemParam.SelectedIndex = 1
            End If
            ''--- 須關閉其它Dialog ,因為取像的thread可能還沒完成 ---
            'If Not Me.m_DialogFuncSetting Is Nothing Then
            '    Me.m_DialogFuncSetting.Close()
            '    Me.m_DialogFuncSetting = Nothing
            'End If
            'If Not Me.m_DialogFuncTestImgProc Is Nothing Then
            '    Me.m_DialogFuncTestImgProc.Close()
            '    Me.m_DialogFuncTestImgProc = Nothing
            'End If
            'If Not Me.m_DialogFuncSettingBase Is Nothing Then
            '    Me.m_DialogFuncSettingBase.Close()
            '    Me.m_DialogFuncSettingBase = Nothing
            'End If

            'If Not Me.m_DialogADJMean Is Nothing Then Me.m_DialogADJMean = Nothing

            'Me.m_DialogADJMean = New Dialog_ADJMean
            'Me.m_DialogADJMean.SetMainForm(Me, "zh-CN")
            'Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            'Me.AddOwnedForm(Me.m_DialogADJMean)
            'Me.m_DialogADJMean.Left = Me.Left + 510
            'Me.m_DialogADJMean.Top = Me.Top + 30

            'If Me.m_MainProcess.IsIPConnected Then
            '    Me.m_DialogADJMean.Show()
            'End If
            'Me.TabControlEnable()

        Catch ex As Exception
            'MessageBox.Show("[Main_Form.Button_ADJMean_Click] Dialog ADJ Mean Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.m_DialogADJMean = Nothing
            'Me.TabControlEnable()
            'Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_SetMappingTable_Click ---"
    Private Sub Button_SetMappingTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SetMappingTable.Click
        Dim SizeX As Integer
        Dim SizeY As Integer

        If Not Me.m_DialogSetMappingTable Is Nothing Then Me.m_DialogSetMappingTable = Nothing
        SizeX = Me.m_MainProcess.IPBootConfig.ImageSizeX.Value
        SizeY = Me.m_MainProcess.IPBootConfig.ImageSizeY.Value
        Try
            If Me.m_DialogSetMappingTable Is Nothing OrElse Me.m_DialogSetMappingTable.IsDisposed Then
                Me.m_DialogSetMappingTable = New Dialog_SetMappingTable

                Me.m_DialogSetMappingTable.SetMainForm(Me)
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogSetMappingTable)
                Me.m_DialogSetMappingTable.Left = Me.Left + 100
                Me.m_DialogSetMappingTable.Top = Me.Top + 20
                Me.m_DialogSetMappingTable.Show()
            End If

        Catch ex As Exception
            If Me.m_DialogSetMappingTable Is Nothing Then Me.m_DialogSetMappingTable.Close()
            MessageBox.Show("[Main_Form.Button_SetMappingTable_Click] Dialog Set Mapping Table Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogSetMappingTable = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_FuncFalseDefect_Click ---"
    Private Sub Button_FuncFalseDefect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FuncFalseDefect.Click
        Try
            If GetCaptureStatus() Then Return
            If Not Me.m_DialogFuncFalseDefect Is Nothing Then Me.m_DialogFuncFalseDefect = Nothing
            Me.m_DialogFuncFalseDefect = New Dialog_FuncFalseDefect
            Me.m_DialogFuncFalseDefect.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogFuncFalseDefect)
            Me.m_DialogFuncFalseDefect.Left = Me.Left + Me.Size.Width - Me.m_DialogFuncFalseDefect.Size.Width
            Me.m_DialogFuncFalseDefect.Top = Me.Top + Me.Size.Height - Me.m_DialogFuncFalseDefect.Size.Height
            Me.m_DialogFuncFalseDefect.Show()

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_FuncFalseDefect_Click] Dialog Func False Defect Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogFuncFalseDefect = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_SettingFunc_Click ---"
    Private Sub Button_SettingFunc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_SettingFunc.Click
        Try
            If GetCaptureStatus() Then Return
            If Me.TabControl_SystemParam.SelectedIndex <> 3 Then
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.m_FuncParamUIIMP.Init()
                Me.TabControl_SystemParam.SelectedIndex = 3
            End If

            'If Not Me.m_DialogFuncSetting Is Nothing Then Me.m_DialogFuncSetting = Nothing
            'Me.m_DialogFuncSetting = New Dialog_FuncSetting
            'Me.m_DialogFuncSetting.SetMainForm(Me, "zh-CN")
            'Me.AddOwnedForm(Me.m_DialogFuncSetting)
            'Me.m_DialogFuncSetting.Left = Me.Left + Me.Size.Width - Me.m_DialogFuncSetting.Size.Width
            'Me.m_DialogFuncSetting.Top = Me.Top + Me.Size.Height - Me.m_DialogFuncSetting.Size.Height

            'If Me.m_MainProcess.IsIPConnected Then
            '    Me.m_DialogFuncSetting.Show()
            'End If

        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_SettingFunc_Click] Dialog Func Setting Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogFuncSetting = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_FuncSettingBase_Click ---"
    Private Sub Button_FuncSettingBase_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FuncSettingBase.Click
        Try
            If Not Me.m_DialogFuncSettingBase Is Nothing Then Me.m_DialogFuncSettingBase = Nothing

            If Me.m_DialogFuncSettingBase Is Nothing OrElse Me.m_DialogFuncSettingBase.IsDisposed Then
                Me.m_DialogFuncSettingBase = New Dialog_FuncSettingBase
                Me.m_DialogFuncSettingBase.SetMainForm(Me, "zh-CN")
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogFuncSettingBase)
                Me.m_DialogFuncSettingBase.Left = Me.Left + Me.Size.Width - Me.m_DialogFuncSettingBase.Size.Width
                Me.m_DialogFuncSettingBase.Top = Me.Top + Me.Size.Height - Me.m_DialogFuncSettingBase.Size.Height

                If Me.m_MainProcess.IsIPConnected Then
                    Me.m_DialogFuncSettingBase.Show()
                End If

            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_FuncSettingBase_Click] Dialog Func Setting Base Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogFuncSettingBase = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_FuncTestImgProc_Click ---"
    Private Sub Button_FuncImgProcTest_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_FuncImgProcTest.Click
        Try
            If GetCaptureStatus() Then Return
            If Not Me.m_DialogFuncTestImgProc Is Nothing Then Me.m_DialogFuncTestImgProc = Nothing

            If Me.m_DialogFuncTestImgProc Is Nothing OrElse Me.m_DialogFuncTestImgProc.IsDisposed Then
                Me.m_DialogFuncTestImgProc = New Dialog_FuncTestImageProcess
                Me.m_DialogFuncTestImgProc.SetMainForm(Me, "zh-CN")
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogFuncTestImgProc)
                Me.m_DialogFuncTestImgProc.Left = Me.Left + 510
                Me.m_DialogFuncTestImgProc.Top = Me.Top + 30

                If Me.m_MainProcess.IsIPConnected Then
                    Me.m_DialogFuncTestImgProc.Show()
                End If

            End If
        Catch ex As Exception
            If Me.m_DialogFuncTestImgProc Is Nothing Then Me.m_DialogFuncTestImgProc.Close()
            MessageBox.Show("[Main_Form.Button_FuncTestImgProc_Click] Dialog Func Test Image Process Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogFuncTestImgProc = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_Align_Click ---"
    Private Sub Button_Align_Click(sender As System.Object, e As System.EventArgs) Handles Button_Align.Click
        'If Me.m_AlignUIIMP.InitialFinished Then
        '    Me.m_AlignUIIMP.Init()
        'End If
        'Me.ReleaseAllUIIMP()
        Try
            If GetCaptureStatus() Then Return
            If Me.TabControl_SystemParam.SelectedIndex <> 2 Then
                Me.m_AlignUIIMP.Init()

                Me.TabControl_SystemParam.SelectedIndex = 2
            End If

            'If Not Me.m_DialogAlign Is Nothing Then Me.m_DialogAlign = Nothing

            'If Me.m_DialogAlign Is Nothing OrElse Me.m_DialogAlign.IsDisposed Then
            '    Me.m_DialogAlign = New Dialog_Align
            '    Me.m_DialogAlign.SetMainForm(Me, "zh-CN")
            '    Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            '    Me.AddOwnedForm(Me.m_DialogAlign)
            '    Me.m_DialogAlign.Left = Me.Left + 510
            '    Me.m_DialogAlign.Top = Me.Top + 180

            '    If Me.m_MainProcess.IsIPConnected Then
            '        Me.m_DialogAlign.Show()
            '    End If

            'End If
        Catch ex As Exception
            If Me.m_DialogFuncTestImgProc Is Nothing Then Me.m_DialogFuncTestImgProc.Close()
            MessageBox.Show("[Main_Form.Button_FuncTestImgProc_Click] Dialog Func Test Image Process Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogFuncTestImgProc = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#End Region

#Region "--- Measurement Button ---"
    Private Sub Button_OMSSetting_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_OMSSetting.Click
        Try
            If Me.ComboBox_CCD.SelectedIndex <> Me.ComboBox_OMS_Enable_IPNo.SelectedIndex Then
                MessageBox.Show("請先選擇IP No (在主頁面左上方 IP Selection),再進行OMS與Back Light參數設定 !", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            If Me.m_DialogCalculateMeasurement Is Nothing OrElse Me.m_DialogCalculateMeasurement.IsDisposed Then
                Me.m_DialogCalculateMeasurement = New Dialog_CalculateMeasurement
                Me.m_DialogCalculateMeasurement.SetMainForm(Me)
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogCalculateMeasurement)
                Me.m_DialogCalculateMeasurement.Left = Me.Left + Me.Size.Width - Me.m_DialogCalculateMeasurement.Size.Width
                Me.m_DialogCalculateMeasurement.Top = Me.Top + Me.Size.Height - Me.m_DialogCalculateMeasurement.Size.Height
                Me.m_DialogCalculateMeasurement.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_OMSSetting_Click] Dialog OMS Setting Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogCalculateMeasurement = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Tool Button ---"

#Region "--- Button_LookUpPosition_Click ---"
    Private Sub Button_LookUpPosition_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_LookUpPosition.Click
        Try
            If Me.m_DialogLookupPosition Is Nothing OrElse Me.m_DialogLookupPosition.IsDisposed Then
                Me.m_DialogLookupPosition = New Dialog_LookupPosition
                Me.m_DialogLookupPosition.SetMainForm(Me)
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogLookupPosition)
                Me.m_DialogLookupPosition.Left = Me.Left + Me.Size.Width - Me.m_DialogLookupPosition.Size.Width
                Me.m_DialogLookupPosition.Top = Me.Top + Me.Size.Height - Me.m_DialogLookupPosition.Size.Height
                Me.m_DialogLookupPosition.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_LookUpPosition] Dialog Look up Position Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogLookupPosition = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_MDC_Setting_Click ---"
    Private Sub Button_MDC_Setting_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MDC_Setting.Click
        Try
            If Me.m_DialogMDCSetting Is Nothing OrElse Me.m_DialogMDCSetting.IsDisposed Then
                Me.m_DialogMDCSetting = New Dialog_MDCSetting
                Me.m_DialogMDCSetting.SetMainForm(Me)
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogMDCSetting)
                Me.m_DialogMDCSetting.Left = Me.Left + Me.Size.Width - Me.m_DialogMDCSetting.Size.Width
                Me.m_DialogMDCSetting.Top = Me.Top + Me.Size.Height - Me.m_DialogMDCSetting.Size.Height
                Me.m_DialogMDCSetting.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_MDC_Setting] Dialog MDC Setting Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogMDCSetting = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "--- Button_CameraAlignment_Click ---"
    Private Sub Button_CameraAlignment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_CameraAlignment.Click
        Try
            If GetCaptureStatus() Then Return
            If Me.m_DialogCameraAlignment Is Nothing OrElse Me.m_DialogCameraAlignment.IsDisposed Then
                Me.m_DialogCameraAlignment = New Dialog_CameraAlignment
                Me.m_DialogCameraAlignment.SetMainForm(Me, "zh-CN")
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogCameraAlignment)
                Me.m_DialogCameraAlignment.Left = Me.Left + Me.Size.Width - Me.m_DialogCameraAlignment.Size.Width
                Me.m_DialogCameraAlignment.Top = Me.Top + Me.Size.Height - Me.m_DialogCameraAlignment.Size.Height
                Me.m_DialogCameraAlignment.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_CameraAlignment_Click] Dialog Camera Alignment Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogCameraAlignment = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#Region "---Button_RMSSetting_Click---"
    Private Sub Button_RMSSetting_Click(sender As System.Object, e As System.EventArgs) Handles Button_RMSSetting.Click
        Try
            If Me.m_DialogRMSSetting Is Nothing OrElse Me.m_DialogRMSSetting.IsDisposed Then
                Me.m_DialogRMSSetting = New Dialog_RMSSetting
                Me.m_DialogRMSSetting.SetMainForm(Me)
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogRMSSetting)
                Me.m_DialogRMSSetting.Left = Me.Left + Me.Size.Width - Me.m_DialogRMSSetting.Size.Width
                Me.m_DialogRMSSetting.Top = Me.Top + Me.Size.Height - Me.m_DialogRMSSetting.Size.Height
                Me.m_DialogRMSSetting.Show()
            End If
        Catch ex As Exception
            MessageBox.Show("[Main_Form.Button_CameraAlignment_Click] Dialog Camera Alignment Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogCameraAlignment = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#End Region

#Region "--- Button_BarcodeSetting_Click ---"
    Private Sub Button_BarcodeSetting_Click(sender As System.Object, e As System.EventArgs) Handles Button_BarcodeSetting.Click
        Try
            If Not Me.m_DialogBarcodeSetting Is Nothing Then Me.m_DialogBarcodeSetting = Nothing

            If Me.m_DialogBarcodeSetting Is Nothing OrElse Me.m_DialogBarcodeSetting.IsDisposed Then
                Me.m_DialogBarcodeSetting = New Dialog_BarcodeSetting
                Me.m_DialogBarcodeSetting.SetMainForm(Me)
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogBarcodeSetting)
                Me.m_DialogBarcodeSetting.Left = Me.Left + 510
                Me.m_DialogBarcodeSetting.Top = Me.Top + 30

                If Me.m_MainProcess.IsIPConnected Then
                    Me.m_DialogBarcodeSetting.Show()
                End If

            End If
        Catch ex As Exception
            If Me.m_DialogBarcodeSetting Is Nothing Then Me.m_DialogBarcodeSetting.Close()
            MessageBox.Show("[Main_Form.Button_BarcodeSetting_Click] Dialog Barcode Setting Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogBarcodeSetting = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub
#End Region

#End Region



#Region "--- ComboBox Event ---"

#Region "--- ComboBox_Type_SelectedIndexChanged ---"
    Private Sub ComboBox_Type_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Type.SelectedIndexChanged
        Me.ComboBox_Select.Items.Clear()
        Select Case Me.ComboBox_Type.SelectedIndex
            Case -1
                Me.ComboBox_Select.SelectedIndex = -1
                MdispSelect(Me.AxMDisplay, M_NULL)
                Me.ResetScrollBar()
            Case 0
                Me.ComboBox_Select.Items.Add("抓图影像")
                Me.ComboBox_Select.Items.Add("亮校正影像")
                Me.ComboBox_Select.Items.Add("分析影像")
                Me.ComboBox_Select.Items.Add("MaskMark影像")
                Me.ComboBox_Select.SelectedIndex = Me.m_CurrentIndex0
            Case 1
                Me.ComboBox_Select.Items.Add("分析可视区影像")                     '0
                Me.ComboBox_Select.Items.Add("亮校正结果影像")                     '1
                Me.ComboBox_Select.Items.Add("Blob 平滑处理影像")                  '2
                Me.ComboBox_Select.Items.Add("Macro 平滑处理影像")                 '3
                Me.ComboBox_Select.Items.Add("Blob 缩放影像(H)")                   '4
                Me.ComboBox_Select.Items.Add("Blob 缩放影像(L)")                   '5
                Me.ComboBox_Select.Items.Add("Macro(缩放影像(H))")                 '6
                Me.ComboBox_Select.Items.Add("Macro(缩放影像(L))")                 '7
                Me.ComboBox_Select.Items.Add("Blob 相减影像(亮)")                  '8
                Me.ComboBox_Select.Items.Add("Blob 相减影像(暗)")                  '9
                Me.ComboBox_Select.Items.Add("Macro 相减影像(亮)")                 '10
                Me.ComboBox_Select.Items.Add("Macro 相减影像(暗)")                 '11
                Me.ComboBox_Select.Items.Add("中心Blob 影像处理(亮-Reconstruct)")  '12
                Me.ComboBox_Select.Items.Add("中心Blob 影像处理(暗-Reconstruct)")  '13
                Me.ComboBox_Select.Items.Add("中心Macro 影像处理(亮-Threshold)")   '14
                Me.ComboBox_Select.Items.Add("中心Macro 影像处理(暗-Threshold)")   '15
                Me.ComboBox_Select.Items.Add("边缘Blob 影像处理(亮-Reconstruct)")  '16
                Me.ComboBox_Select.Items.Add("边缘Blob 影像处理(暗-Reconstruct)")  '17
                Me.ComboBox_Select.Items.Add("Func Recipe 调整后影像")             '18
                Me.ComboBox_Select.Items.Add("可视区糊焦后影像")                   '19
                Me.ComboBox_Select.SelectedIndex = Me.m_CurrentIndex1
            Case 2
                Me.ComboBox_Select.Items.Add("水平分析影像")
                Me.ComboBox_Select.Items.Add("水平投影影像")
                Me.ComboBox_Select.Items.Add("水平Golden Band影像")
                Me.ComboBox_Select.Items.Add("水平White Band影像")
                Me.ComboBox_Select.Items.Add("水平Black Band影像")
                Me.ComboBox_Select.Items.Add("水平Band影像处理(亮-Reconstruct)")
                Me.ComboBox_Select.Items.Add("水平Band影像处理(暗-Reconstruct)")
                Me.ComboBox_Select.Items.Add("垂直分析影像")
                Me.ComboBox_Select.Items.Add("垂直分析影像")
                Me.ComboBox_Select.Items.Add("垂直Golden Band影像")
                Me.ComboBox_Select.Items.Add("垂直White Band影像")
                Me.ComboBox_Select.Items.Add("垂直Black Band影像")
                Me.ComboBox_Select.Items.Add("垂直Band影像")
                Me.ComboBox_Select.Items.Add("垂直Band影像处理(亮-Reconstruct)")
                Me.ComboBox_Select.Items.Add("垂直Band影像处理(暗-Reconstruct)")
                Me.ComboBox_Select.SelectedIndex = Me.m_CurrentIndex2
            Case 3
                Me.ComboBox_Select.Items.Add("亮校正可视区影像")
                Me.ComboBox_Select.Items.Add("亮校正影像")
                Me.ComboBox_Select.SelectedIndex = Me.m_CurrentIndex3
        End Select
    End Sub
#End Region

#Region "--- ComboBox_Select_SelectedIndexChanged ---"
    Private Sub ComboBox_Select_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Select.SelectedIndexChanged
        Me.ImageUpdate()
    End Sub
#End Region

#Region "--- ComboBox_Pattern_SelectedIndexChanged ---"
    Private Sub ComboBox_Pattern_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_Pattern_MainFrm.SelectedIndexChanged
        Dim i As Integer
        Dim count1 As Integer
        Dim PatternName As String
        i = Me.GetPatternIndexInfo

        If Me.m_MainProcess.IPBootConfig.MuraUI.Value AndAlso Me.m_MainProcess.IPBootConfig.FuncUI.Value Then
            count1 = Me.m_MuraProcess.MuraPatternRecipeArray.Count
            If Me.m_MuraProcess.Pattern <> (i + 1) Or Me.m_MainProcess.FuncProcess.Pattern <> (i + 1 - count1) Then
                Me.SetPatternIndex(i + 1) 'Load To --> Me.MuraProcess.m_CurrentMuraPatternRecipe  Or Me.m_FuncProcess.m_CurrentFuncPatternRecipe
            End If
        ElseIf Me.m_MainProcess.IPBootConfig.FuncUI.Value Then
            If Me.m_MainProcess.FuncProcess.Pattern <> (i + 1 - count1) Then
                Me.SetPatternIndex(i + 1) 'Load To --> Me.MuraProcess.m_CurrentMuraPatternRecipe  Or Me.m_FuncProcess.m_CurrentFuncPatternRecipe
            End If
        End If

        If Me.m_MainProcess.IsIPConnected Then
            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.GetPatternNameInfo

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If


        Me.PreInfo("您目前操作的是 ==>IP " & Me.ComboBox_CCD.Text & " ,目前操作的 Pattern 為 ==> " & Me.ComboBox_Pattern_MainFrm.Text)
    End Sub
#End Region

#Region "--- ComboBox_CCD_SelectedIndexChanged ---"
    Private Sub ComboBox_CCD_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_CCD.SelectedIndexChanged
        Dim version As String = System.Windows.Forms.Application.ProductVersion
        Dim GrabNo As String = ""
        Dim strPath As String = ""
        Dim IPBootRecipeName As String = ""
        Dim ModelName As String = ""
        Dim PatternName As String = ""
        Dim i As Integer
        Dim count1 As Integer = 0

        Try
            If Me.ComboBox_CCD.SelectedIndex < 0 Then Exit Sub

            Me.CloseAllDialog()
            Me.TabControlDisable()

            '--- [AreaGrabber 端] ---
            If Me.ComboBox_CCD.Text <> "" Then
                If Not Me.Change_GrabNo(Me.ComboBox_CCD.Text, Me.ComboBox_GrabNo.Text) Then
                    Me.TabControlEnable()
                    Exit Sub
                End If

                Me.TabControl_HightLevel.Enabled = True
                Me.Change_GrabNo(Me.m_MainProcess.CCDNo, GrabNo)
                Me.m_MainProcess.GrabNo = GrabNo
                Me.m_MainProcess.CCDNo = Val(Me.ComboBox_CCD.Text)
                Me.m_MainProcess.IPBootConfig = MILOperationLib.ClsIPBootConfig.ReadXML(Directory.GetParent(Me.m_MainProcess.BootRecipeFilename).FullName & "\IPBootConfig_IP" & Me.ComboBox_CCD.Text & "_C" & Me.ComboBox_GrabNo.Text & ".xml")
                Me.m_MainProcess.SetModel(Me.GetProductNameInfo, Me.ComboBox_GrabNo.Text, CInt(Me.ComboBox_CCD.Text), False)
            End If

            If Not Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.ComboBox_CCD.SelectedIndex).IP_Enable Then
                Me.ComboBox_CCD.SelectedIndex = -1
                Me.TabControlEnable()
                Exit Sub
            End If

            '--- [IP 端] ---
            '--- Disconnect All IP ---   
            Me.m_MainProcess.DisconnectIP()

            '--- Check IP ---
            If CInt(Me.ComboBox_CCD.Text) > 0 Then
                '--- 建立連線 ---
                If Not Me.ConnectToIP(CInt(Me.ComboBox_CCD.Text), Me.ComboBox_GrabNo.Text) Then
                    Me.ComboBox_CCD.SelectedIndex = -1
                    Me.TabControlEnable()
                    Exit Sub
                End If
            Else
                Me.ComboBox_CCD.SelectedIndex = -1
                Exit Sub
            End If

            '--- Clear Display ---
            MdispSelectWindow(Me.m_AxMDisplay, M_NULL, Me.Panel_AxMDisplay.Handle)

            'strPath = Directory.GetParent(Me.m_MainProcess.BootRecipeFilename).FullName & "\IPBootConfig_IP" & Me.ComboBox_CCD.Text & "_C" & Me.ComboBox_GrabNo.Text & ".xml"

            If Not Me.m_MainProcess.AreaBootConfig.MDC_UI.Value Then
                Me.Text = "[" & Me.m_MainProcess.AreaBootConfig.AreaGrabber_Name.Value & "] [Version] : " & Me.m_MainProcess.Fab & version
            Else
                Me.Text = "[" & Me.m_MainProcess.AreaBootConfig.AreaGrabber_Name.Value & "] [MDC 版][Version] : " & Me.m_MainProcess.Fab & version
            End If

            Me.PreInfo("您目前操作的是 ==>IP " & Me.ComboBox_CCD.Text & " ,目前操作的 Pattern 為 ==> " & Me.ComboBox_Pattern_MainFrm.Text)

            Try
                '--- Prepare Command ---
                Request_Command = "CHECK_MODELNAME"
                TimeOut = 200000 '200 secs

                ModelName = Me.TextBox_Product.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ModelName, , , , , , , , TimeOut)

                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Set Model Error !(" & SubSystemResult.ErrMessage & "), " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Form_AreaGrabber.ComboBox_CCD_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

                    '--- Kill IP ---   
                    Me.m_MainProcess.DisconnectIP()
                    Me.Button_KillIP.PerformClick()

                    Me.TabControlEnable()
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("Set Model Error ! (" & ex.Message & ")")
            End Try

            i = Me.GetPatternIndexInfo
            If Me.m_MainProcess.IPBootConfig.MuraUI.Value AndAlso Me.m_MainProcess.IPBootConfig.FuncUI.Value Then
                count1 = Me.m_MuraProcess.MuraPatternRecipeArray.Count
                If Me.m_MuraProcess.Pattern <> (i + 1) Or Me.m_MainProcess.FuncProcess.Pattern <> (i + 1 - count1) Then
                    Me.SetPatternIndex(i + 1) 'Load To --> Me.MuraProcess.m_CurrentMuraPatternRecipe  Or Me.m_FuncProcess.m_CurrentFuncPatternRecipe
                End If
            ElseIf Me.m_MainProcess.IPBootConfig.FuncUI.Value Then
                If Me.m_MainProcess.FuncProcess.Pattern <> (i + 1 - count1) Then
                    Me.SetPatternIndex(i + 1) 'Load To --> Me.MuraProcess.m_CurrentMuraPatternRecipe  Or Me.m_FuncProcess.m_CurrentFuncPatternRecipe
                End If
            End If

            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.GetPatternNameInfo

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Main_Form.ComboBox_CCD_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Main_Form.ComboBox_CCD_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
                MessageBox.Show("[Main_Form.ComboBox_CCD_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            'If Me.ComboBox_CCD.Text <> "" Then

            '    If Not Me.m_MainProcess.AreaBootConfig.MDC_UI.Value Then
            '        Me.Text = "[" & Me.m_MainProcess.AreaBootConfig.AreaGrabber_Name.Value & "] [Version] : " & Me.m_MainProcess.Fab & version
            '    Else
            '        Me.Text = "[" & Me.m_MainProcess.AreaBootConfig.AreaGrabber_Name.Value & "] [MDC 版][Version] : " & Me.m_MainProcess.Fab & version
            '    End If

            '    Me.PreInfo("您目前操作的是 ==>IP " & Me.ComboBox_CCD.Text & " ,目前操作的 Pattern 為 ==> " & Me.ComboBox_Pattern.Text)

            '    If CInt(Me.ComboBox_CCD.Text) > 0 And Me.ComboBox_GrabNo.Text <> "" Then
            '        '----------------------------------------------------------------------------------------------
            '        ' Set Model  ==> Request_Command = "SET_MODEL" (Dispatcher 1)
            '        '----------------------------------------------------------------------------------------------
            '        Try
            '            '--- Prepare Command ---
            '            Request_Command = "SET_MODEL"
            '            TimeOut = 200000 '200 secs

            '            Me.m_MainProcess.BootRecipeFilename = strPath
            '            Me.UpatePatternUI()
            '            '---- initial Pattern ----  
            '            Me.SetPatternIndex(1)        'Set 1st Pattern 
            '            Me.m_MainProcess.CCDNo = CInt(Me.ComboBox_CCD.Text)
            '            Me.m_MainProcess.GrabNo = Me.ComboBox_GrabNo.Text

            '            Response_OK = False
            '            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.GetProductNameInfo, Me.ComboBox_GrabNo.Text, Me.ComboBox_CCD.Text, , , , , , TimeOut)

            '            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            '            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
            '                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
            '                Response_OK = True
            '            Else
            '                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & " Set Model Error !(" & SubSystemResult.ErrMessage & "), " & CStr(Me.m_MainProcess.ErrorCode))
            '                MessageBox.Show("[Form_AreaGrabber.ComboBox_CCD_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)

            '                '--- Kill IP ---   
            '                Me.m_MainProcess.DisconnectIP()
            '                Me.Button_KillIP.PerformClick

            '                Me.TabControlEnable()
            '                Exit Sub
            '            End If
            '        Catch ex As Exception
            '            Throw New Exception("Set Model Error ! (" & ex.Message & ")")
            '        End Try
            '    End If

            '    Me.OutputInfo("[Connect] Connect to IP - " & Me.ComboBox_CCD.Text & " , IP Address: " & Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(CInt(Me.ComboBox_CCD.Text) - 1).IP_IPAddress & " , Port 1: " & Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(CInt(Me.ComboBox_CCD.Text) - 1).IP_Port1 & ", Port 2: " & Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(CInt(Me.ComboBox_CCD.Text) - 1).IP_Port2)
            'Else
            '    MsgBox("File Path : " & strPath & " was not exist ! Please create it (Including Image process recipe files), and try again !", MsgBoxStyle.Critical, "[AreaGrabber]")
            'End If

            Me.TabControlEnable()
        Catch ex As Exception
            MessageBox.Show("[Form_AreaGrabber.ComboBox_CCD_SelectedIndexChanged] Dialog ADJ Mean Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.TabControlEnable()
        End Try
    End Sub
#End Region

#Region "--- ComboBox_CCDMode_SelectedIndexChanged ---"
    Private Sub ComboBox_CCDMode_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_CCDMode.SelectedIndexChanged
        Dim i As Integer

        If Me.ComboBox_CCDMode.Text <> "" Then
            For i = Me.ComboBox_GrabNo.Items.Count - 1 To 0 Step -1
                Me.ComboBox_GrabNo.Items.RemoveAt(i)
            Next
        End If

        If Me.ComboBox_CCDMode.Text <> "" Then
            Me.m_MainProcess.IPNetworkConfig.Total_IP = Me.ComboBox_CCDMode.Text
        Else
            Me.ComboBox_CCDMode.Text = Me.m_MainProcess.IPNetworkConfig.Total_IP
        End If

        Select Case Me.ComboBox_CCDMode.Text

            Case "2"
                Me.ComboBox_GrabNo.Items.Insert(0, "1_1")
                Me.ComboBox_GrabNo.Items.Insert(1, "1_2")
                Me.ComboBox_GrabNo.Items.Insert(2, "2_1")
                Me.ComboBox_GrabNo.Items.Insert(3, "2_2")
            Case "3"
                Me.ComboBox_GrabNo.Items.Insert(0, "3_1")
                Me.ComboBox_GrabNo.Items.Insert(1, "3_2")
                Me.ComboBox_GrabNo.Items.Insert(2, "3_3")
            Case "4"
                Me.ComboBox_GrabNo.Items.Insert(0, "1_1")
                Me.ComboBox_GrabNo.Items.Insert(1, "1_2")
                Me.ComboBox_GrabNo.Items.Insert(2, "2_1")
                Me.ComboBox_GrabNo.Items.Insert(3, "2_2")
            Case "9"
                Me.ComboBox_GrabNo.Items.Insert(0, "9_1")
                Me.ComboBox_GrabNo.Items.Insert(1, "9_2")
                Me.ComboBox_GrabNo.Items.Insert(2, "9_3")
                Me.ComboBox_GrabNo.Items.Insert(3, "9_4")
                Me.ComboBox_GrabNo.Items.Insert(4, "9_5")
                Me.ComboBox_GrabNo.Items.Insert(5, "9_6")
                Me.ComboBox_GrabNo.Items.Insert(6, "9_7")
                Me.ComboBox_GrabNo.Items.Insert(7, "9_8")
                Me.ComboBox_GrabNo.Items.Insert(8, "9_9")
        End Select
    End Sub
#End Region

#End Region

#Region "--- ToolStripMenuItem_Event ---"

#Region "--- tsmIPNetWorkConfig_Click ---"
    Private Sub tsmIPNetWorkConfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmIPNetWorkConfig.Click
        If Me.m_DialogIPNetWorkConfig Is Nothing OrElse Me.m_DialogIPNetWorkConfig.IsDisposed Then
            Me.m_DialogIPNetWorkConfig = New Dialog_IPNetWorkConfig
            Me.m_DialogIPNetWorkConfig.SetMainForm(Me)
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogIPNetWorkConfig)
            Me.m_DialogIPNetWorkConfig.Left = Me.Left + Me.Size.Width - Me.m_DialogIPNetWorkConfig.Size.Width
            Me.m_DialogIPNetWorkConfig.Top = Me.Top + Me.Size.Height - Me.m_DialogIPNetWorkConfig.Size.Height
            Me.m_DialogIPNetWorkConfig.Show()
        End If
    End Sub
#End Region

#Region "--- tsmIPBootConfig_Click ---"
    Private Sub tsmIPBootConfig_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tsmIPBootConfig.Click
        If Me.m_DialogIPBootConfig Is Nothing OrElse Me.m_DialogIPBootConfig.IsDisposed Then
            Me.m_DialogIPBootConfig = New Dialog_IPBootConfig
            Me.m_DialogIPBootConfig.SetMainForm(Me, "zh-CN")
            Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
            Me.AddOwnedForm(Me.m_DialogIPBootConfig)
            Me.m_DialogIPBootConfig.Left = Me.Left + Me.Size.Width - Me.m_DialogIPBootConfig.Size.Width
            Me.m_DialogIPBootConfig.Top = Me.Top + Me.Size.Height - Me.m_DialogIPBootConfig.Size.Height
            Me.m_DialogIPBootConfig.Show()
        End If
    End Sub
#End Region

#End Region

#Region "--- NotifyIcon Event ---"
    Private Sub NotifyIcon1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles NotifyIcon_AreaGrabber.DoubleClick
        Me.Show()
        Me.WindowState = FormWindowState.Normal
    End Sub
#End Region

#Region "--- ImageUpdate ---"
    Public Sub ImageUpdate(Optional ByVal ViewBit As Integer = 0)
        ' ErrorCode = ErrorCodeBase + 820 ~ 822
        Dim imageBuffer As MIL_ID = M_NULL
        Dim t As Integer
        Dim s As Integer
        Dim i As Integer
        Dim m_flag As Boolean = False
        Dim count1 As Integer = 0
        Dim count2 As Integer = 0
        Dim SizeX, SizeY, Type As Integer
        Dim VScrollValue As Integer = 0
        Dim HScrollValue As Integer = 0
        Dim BitShift As Integer = 0


        t = Me.GetTypeIndexInfo
        s = Me.GetSelectIndexInfo
        Me.m_Img_Current = Nothing
        i = Me.GetPatternIndexInfo + 1

        count1 = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
        count2 = Me.m_MainProcess.FuncProcess.FuncModelRecipe.PatternCount.Value

        VScrollValue = Me.VScrollBar.Value
        HScrollValue = Me.HScrollBar.Value

        Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 822
        Try
            Select Case t
                Case -1
                    Me.m_Img_Current = Nothing
                Case 0
                    Select Case s
                        Case 0

                            If Me.m_IsSetExpTimeFlag Then 'Not Me.m_DialogADJMean Is Nothing Or Not Me.m_DialogMuraAutoManual Is Nothing
                                'Adjust Exposure Time
                                Me.m_Img_Current = Me.m_MainProcess.Img_16U_Grab_1
                            Else
                                If Me.m_MainProcess.Func_HaveCurrentPattern_2 Then
                                    Me.m_Img_Current = Me.m_MainProcess.FuncProcess.Img_Original_NonPage
                                ElseIf Me.m_MainProcess.Mura_HaveCurrentPattern_2 Then
                                    Me.m_Img_Current = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                                End If

                            End If

                        Case 1
                            Me.m_Img_Current = Me.m_MuraProcess.Img_CurrentSample_NonPage
                        Case 2
                            If i <= count1 And i <> 0 Then
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    Me.m_Img_Current = Me.m_MuraProcess.Img_CurrentSample_NonPage
                                Else
                                    Me.m_Img_Current = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                                End If
                            ElseIf count1 < i And i <= count1 + count2 Then
                                Me.m_Img_Current = Me.m_MainProcess.FuncProcess.Img_Original_NonPage
                            End If
                        Case 3
                            If count1 < i And i <= count1 + count2 Then
                                Me.m_Img_Current = Me.m_MainProcess.FuncProcess.Img_1U_PLMark_Mask
                            End If
                    End Select

                    Me.m_CurrentIndex0 = s
                Case 1
                    Select Case s
                        Case 0
                            If i <= count1 And i <> 0 Then
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    Me.m_Img_Current = Me.m_MuraProcess.Img_ChildSample
                                Else
                                    Me.m_Img_Current = Me.m_MuraProcess.Img_ChildOriginal
                                End If
                            ElseIf count1 < i And i <= count1 + count2 Then
                                Me.m_Img_Current = Me.m_MainProcess.FuncProcess.Img_OriginalROI 'Func
                            End If
                        Case 1
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_FFCResult_NonPage
                        Case 2
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub

                            If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                            Else
                                SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) - 2 * Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
                                SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) - 2 * Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
                            End If
                            If Me.m_MuraProcess.Img_BlobMura_SmoothChild <> M_NULL Then
                                MbufFree(Me.m_MuraProcess.Img_BlobMura_SmoothChild)
                                Me.m_MuraProcess.Img_BlobMura_SmoothChild = M_NULL
                            End If
                            Me.m_MuraProcess.Img_BlobMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value, Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value, SizeX, SizeY, M_NULL)

                            Me.m_Img_Current = Me.m_MuraProcess.Img_BlobMura_SmoothChild
                        Case 3
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_MacroMura_SmoothChild
                        Case 4
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_BlobMura_ResizeHChild
                        Case 5
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_BlobMura_ResizeLChild
                        Case 6
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_MacroMura_ResizeHChild
                        Case 7
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_MacroMura_ResizeLChild
                        Case 8
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_BlobMuraArea_WhiteChild
                        Case 9
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_BlobMuraArea_BlackChild
                        Case 10
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_MacroMura_WhiteChild
                        Case 11
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_MacroMura_BlackChild
                        Case 12
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_WhiteReconstructArea_NonPage
                        Case 13
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_BlackReconstructArea_NonPage
                        Case 14
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_WhiteThreshold_NonPage
                        Case 15
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_BlackThreshold_NonPage
                        Case 16
                            If Not Me.m_MainProcess.IPBootConfig.MuraUI.Value Then Exit Sub
                            Me.m_Img_Current = Me.m_MuraProcess.Img_WhiteReconstructRImChild
                        Case 17
                            Me.m_Img_Current = Me.m_MuraProcess.Img_BlackReconstructRimChild
                        Case 18
                            If count1 < i And i <= count1 + count2 Then
                                Me.m_Img_Current = Me.m_MainProcess.Img_FixRecipe_NonPage   'Func 
                            End If
                        Case 19
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_Defocus_NonPage
                    End Select
                    Me.m_CurrentIndex1 = s
                Case 2
                    Select Case s
                        Case 0
                            Me.m_Img_Current = Me.m_MuraProcess.Img_BandMura_ChildOriginalH
                        Case 1
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_HProject_NonPage
                        Case 2
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_HGolden_NonPage
                        Case 3
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_HBand_White_NonPage
                        Case 4
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_HBand_Black_NonPage
                        Case 5
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_HBand_White_NonPage
                        Case 6
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_HBand_Black_NonPage
                        Case 7
                            Me.m_Img_Current = Me.m_MuraProcess.Img_BandMura_ChildOriginalV
                        Case 8
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_VProject_NonPage
                        Case 9
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_VGolden_NonPage
                        Case 10
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_VBand_White_NonPage
                        Case 11
                            Me.m_Img_Current = Me.m_MuraProcess.Img_16U_VBand_Black_NonPage
                        Case 12
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_VBand_White_NonPage
                        Case 13
                            Me.m_Img_Current = Me.m_MuraProcess.Img_1U_VBand_Black_NonPage
                    End Select
                    Me.m_CurrentIndex2 = s
                Case 3
                    Select Case s
                        Case 0
                            Me.m_Img_Current = Me.m_MuraProcess.Img_ChildSample    '亮校正可視區影像  
                        Case 1
                            Me.m_Img_Current = Me.m_MuraProcess.Img_CurrentFFCAlign '亮校正影像
                    End Select
                    Me.m_CurrentIndex3 = s
            End Select

            If Me.m_Img_Current = M_NULL Then
                MdispSelect(Me.AxMDisplay, M_NULL)
            Else
                If Me.m_Img_Current <> M_NULL Then
                    imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                    SizeX = MbufInquire(Me.m_Img_Current, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_Img_Current, M_SIZE_Y, M_NULL)
                    Type = MbufInquire(Me.m_Img_Current, M_TYPE, M_NULL)

                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                        MbufFree(imageBuffer)
                        imageBuffer = M_NULL
                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                    End If
                    MbufCopy(Me.m_Img_Current, imageBuffer)

                    MbufControl(Me.m_Img_Current, M_MODIFIED, M_DEFAULT)
                    MdispSelectWindow(Me.m_AxMDisplay, imageBuffer, GetAxMDisplay_HandleInfo())  '2013/01/24 Rick modify
                    If ViewBit = 0 Then
                        MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                    Else
                        BitShift = ViewBit - 8 + 1
                        MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_MODE, MIL.M_BIT_SHIFT)
                        MdispControl(Me.m_AxMDisplay, MIL.M_VIEW_BIT_SHIFT, BitShift)
                    End If

                Else
                    MdispSelect(Me.AxMDisplay, M_NULL)
                End If
            End If

            MdispPan(Me.m_AxMDisplay, 0, 0)
            MdispPan(Me.m_AxMDisplay, HScrollValue, VScrollValue)

            'Me.ImageZoomAll()
        Catch ex As Exception
            Me.OutputErrorInfo("[MainForm.ImageUpdate][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]影像更新失敗 (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[MainForm.ImageUpdate][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]影像更新失敗 (" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- SetTabControlEnableInfo ---"
    Public Sub SetTabControlEnableInfo(ByVal En As Boolean)
        '--- TabPage 1 ---
        Me.SetButton_ADJMean(En)

        '--- TabPage 2 ---
        Me.SetGroupBox_FuncSetting(En)
        'Me.SetGroupBox_FuncTest(En)
        Me.SetButton_FuncFalseDefect(En)

        '--- TabPage 3 ---
        'Me.SetGroupBox_MuraSetting(En)
        'Me.SetGroupBox_MuraTest(En)
        Me.SetButton_MuraManualTest(En)
        Me.SetButton_JND(En)
        Me.SetButton_MuraFalseDefect(En)

        '--- TabPage 4 ---
        Me.SetButton_SetMappingTable(En)

        '--- TabPage 6 ---
        Me.SetButton_OMS_Save(En)
        Me.SetButton_OMSSetting(En)

        '--- TabPage 7 ---
        Me.SetButton_LookUpPosition(En)
    End Sub
#End Region



#Region "<--- Main Form Control --->"

#Region "--- Form_AreaGrabber_Load ---"

    Private Sub Form_AreaGrabber_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Main_Form", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo("zh-CN")
        Thread.CurrentThread.CurrentUICulture = New CultureInfo("zh-CN")
        Me.changeLanguage("zh-CN")
        '-------------------------

        Try
            Me.CheckGrabber()

            '--- 載入Boot Recipe Path ---
            Arguments = Environment.GetCommandLineArgs()
            If Arguments.GetLength(0) > 1 Then                      ' 參數數目必須大於1個

                If Not System.IO.File.Exists(Arguments(1)) Then
                    MessageBox.Show("[FormLoad] IPBootConfig File: " & Arguments(1) & " doesn't exist!", "AreaGrabber Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    End
                End If
            Else
                '--- 沒有輸入Recipe的檔案路徑 ---
                Throw New Exception("[Boot]沒有指定IPBootConfig Recipe的路徑！")
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "AreaGrabber", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_AutoClose = True
            Exit Sub
        End Try

        Try
            Me.StartInit()
            If Me.m_MainProcess.IsIPConnected = False Then
                Throw New Exception("Connect IP fail.")
            End If

            'temp test code
            If Me.m_ProductUIIMP Is Nothing Then
                Me.m_ProductUIIMP = New ClsProductUIIMP(Me)
                Me.m_ProductUIIMP.Init()
            End If
            If Me.m_AdjustExpTimeUIIMP Is Nothing Then
                Me.m_AdjustExpTimeUIIMP = New ClsAdjustExpTimeUIIMP(Me)
            End If

            If Me.m_AlignUIIMP Is Nothing Then
                Me.m_AlignUIIMP = New ClsAlignUIIMP(Me)
            End If

            If Me.m_FuncParamUIIMP Is Nothing Then
                Me.m_FuncParamUIIMP = New ClsFuncParamUIIMP(Me)
            End If

            If Me.m_MuraParamUIIMP Is Nothing Then
                Me.m_MuraParamUIIMP = New ClsMuraParamUIIMP(Me)
            End If

            Me.TabControl_SystemParam.Appearance = TabAppearance.Buttons
            Me.TabControl_SystemParam.SizeMode = TabSizeMode.Fixed
            Me.TabControl_SystemParam.ItemSize = New Size(0, 1)
            Me.TabControl_SystemParam.SelectedIndex = 0

            Me.TabControl_MuraParam.Appearance = TabAppearance.Buttons
            Me.TabControl_MuraParam.SizeMode = TabSizeMode.Fixed
            Me.TabControl_MuraParam.ItemSize = New Size(0, 1)
            Me.TabControl_MuraParam.SelectedIndex = 0

            '---[end]temp test code---

        Catch ex As Exception
            Me.m_AutoClose = True
            Me.StatusBarStatus("初始化失敗!")
            MessageBox.Show("[Form_AreaGrabber_Load]" & ex.Message & vbCrLf & ex.StackTrace, "AreaGrabber Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If m_AutoClose = False Then
                tmr.Start()
            End If
        End Try

    End Sub

#End Region

#Region "--- StartInit ---"

    Private Sub StartInit()
        Dim version As String = System.Windows.Forms.Application.ProductVersion
        Dim i As Integer
        Dim NonPage_Used As Integer = 0

        Try
            Me.DoubleBuffered = True
            '--- initial MainProcess ---
            If Me.m_MainProcess Is Nothing Then Me.m_MainProcess = New ClsMainProcess
            Me.m_MainProcess.InitialMainProcess(Arguments)
            Me.TextBox_Product.Text = Me.m_MainProcess.ProductName

            Try
                '--- 建立顯示元件----
                If Me.m_AxMDisplay <> MIL.M_NULL Then
                    MIL.MdispFree(Me.m_AxMDisplay)
                    Me.m_AxMDisplay = MIL.M_NULL
                End If
                MIL.MdispAlloc(Me.m_MainProcess.System_Host, MIL.M_DEFAULT, "M_DEFAULT", MIL.M_DEFAULT, Me.m_AxMDisplay)
                MIL.MdispControl(Me.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                'MIL.MdispSelectWindow(Me.m_AxMDisplay, Me.m_MainProcess.Img_Mapping_NonPage, Me.Panel_AxMDisplay.Handle)

            Catch ex As Exception
                Throw New Exception("[ErrorCode = " & Me.m_MainProcess.ErrorCode & "] Allocate Display object Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
            End Try

            Try
                '--- 建立網路磁碟控制元件----   
                Me.m_NetControlTool = New ClsNetControlTool
            Catch ex As Exception
                Throw New Exception("Create Net Control Tool object Error !(" & ex.Message & ")(" & ex.StackTrace & ")")
            End Try

            '--- Check Image Path ---
            Try
                If Not Directory.Exists(Me.m_MainProcess.IMAGE_PATH) Then
                    Directory.CreateDirectory(Me.m_MainProcess.IMAGE_PATH)
                Else
                    'Me.RemoveOldImage(Me.m_MainProcess.IPBootConfig.DeleteDay, Me.m_MainProcess.IPBootConfig.DeleteScale, Me.m_MainProcess.CCD)   '2009/09/30 Rick modify
                End If
            Catch ex As Exception
                Throw New Exception("[RemoveOldImage][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]")
            End Try

            '--- Display ---
            Me.m_ZoomMin = Me.m_MainProcess.IPBootConfig.ZoomMin.Value
            Me.m_ZoomMax = Me.m_MainProcess.IPBootConfig.ZoomMax.Value
            Me.m_ZoomFactor = Me.m_MainProcess.IPBootConfig.ZoomFactor.Value

            Me.m_MouseX = 0
            Me.m_MouseY = 0

            '--- 影像顯示參數設定 ---
            Me.m_CurrentIndex0 = 0
            Me.m_CurrentIndex1 = 0
            Me.m_CurrentIndex2 = 0
            Me.m_CurrentIndex3 = 0

            '--- Main Form UI ---
            Me.ComboBox_Type.SelectedIndex = -1
            Me.Left = Me.m_MainProcess.IPBootConfig.Left.Value + Me.m_MainProcess.CCDNo * 30 + 20
            Me.Top = Me.m_MainProcess.IPBootConfig.Top.Value + Me.m_MainProcess.CCDNo * 30 - 20

            Me.ResetScrollBar()

            '--- IP No.---
            For i = 0 To Me.m_MainProcess.IPNetworkConfig.Total_IP - 1
                Me.ComboBox_CCD.Items.Insert(i, i + 1)
                Me.ComboBox_Log_IPNo.Items.Insert(i, i + 1)
            Next
            Me.ComboBox_Log_IPNo.SelectedIndex = 0

            '--- Log Item ---
            Me.ComboBox_Log_Type.Items.Insert(0, "IP Daily Log File")
            Me.ComboBox_Log_Type.Items.Insert(1, "AreaGrabber Daily Log File")
            Me.ComboBox_Log_Type.Items.Insert(2, "IP Daily Mean Log File")
            Me.ComboBox_Log_Type.Items.Insert(3, "IP Recipe Changed Log File")
            Me.ComboBox_Log_Type.SelectedIndex = 0

            '--- Update CCD Mode UI ---
            Me.ComboBox_CCDMode.Text = Me.m_MainProcess.IPNetworkConfig.Total_IP

            '--- Update IP Picture Box icon ---
            Me.UpdateIPIcon(Me.m_MainProcess.IPNetworkConfig.Total_IP)
            Me.PreInfo("請先選擇想要操作的 IP (左上方)!")
            Me.TabControlDisable()

            '--- Update OMS UI ---
            Me.UpdateOMSUI()

            '--- Update MDC UI ---
            Me.UpdateMDCUI()

            '--- Time Picker ---
            Me.DateTimePicker_Log.Value = Format(Now, "yyyy/MM/dd")

            '--- 權限控管 ---
            'Me.m_UserLevel = -1 (Disable UI)、0 (表示OP)、1 (表示PM)、2 (表示ENG)、3 (表示Super User)。
            Me.m_MainProcess.UserID = "Un-LogIn-User"
            'Me.m_MainProcess.UserLevel = 3   'In-line Run ，需設為 -1  (測試時,設為3)
            If Me.m_MainProcess.IPBootConfig.AUTH.Value > -1 Then
                Me.m_MainProcess.UserLevel = Me.m_MainProcess.IPBootConfig.AUTH.Value
                Me.OutputInfo("[AUTH] UserID：" & Me.m_MainProcess.UserID & " ; UserLevel：" & Me.m_MainProcess.UserLevel & "， Illegal User Log In !")
            End If
            Me.UpdateUserLevel(Me.m_MainProcess.UserLevel, Me.m_MainProcess.ErrorCode)

            '--- Update Fab Type UI ---  '2012/10/27 Rick add
            Me.UpdateFabTypeUI(Me.m_MainProcess.AreaBootConfig.Fab_Type.Value)

            '--- Show NonPages ---
            NonPage_Used = MappInquire(M_NON_PAGED_MEMORY_USED, M_NULL) / (2 ^ 20)
            Me.StatusBarPanel_UsedNonPage.Text = "Used NonPage = " & NonPage_Used.ToString & " MB"
            Me.OutputInfo("[System] " & Me.StatusBarPanel_UsedNonPage.Text)

            '--- Connect to IP 1 ---
            System.Threading.Thread.Sleep(3000)
            Me.ComboBox_CCD.SelectedIndex = 0

            '---Check Licensed---
            If Me.m_MainProcess.TempLicensed Then
                Me.RadioButton_Licensed.Checked = True
            Else
                Me.RadioButton_Licensed.Checked = False
            End If

            '--- Hide Ti Icon ---
            If Me.m_MainProcess.AreaBootConfig.UI_AreaGrabber_HideToIcon_Enable.Value Then
                Me.WindowState = FormWindowState.Minimized
                Me.ShowInTaskbar = False
            End If

        Catch ex As Exception
            Throw New Exception("[StartInit]" & ex.Message & vbCrLf & "(" & ex.StackTrace & ")")
        End Try

    End Sub

#End Region

#Region "--- Form_AreaGrabber_Closing ---"
    Private Sub Form_AreaGrabber_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing

        'If Me.m_MainProcess.Licensed Then 'license
        If Not Me.m_MainProcess.OffLineTest Then
            If MessageBox.Show("[AreaGrabber] 連線中...，是否關閉 AreaGrabber？", "[AreaGrabber]", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) = Windows.Forms.DialogResult.Cancel Then
                e.Cancel = True
                Exit Sub
            End If
        End If

        '--- Free Display Object ---
        If Me.m_AxMDisplay <> M_NULL Then
            MdispFree(Me.m_AxMDisplay)
            Me.m_AxMDisplay = M_NULL
        End If

        Try
            Me.m_MainProcess.CloseAreaGrabber()
        Catch ex As Exception
            MessageBox.Show("[Form_AreaGrabber Closing]" & ex.Message & vbCrLf & ex.StackTrace, "AreaGrabber Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End
        End Try
        'End If

        Me.CloseFormAreaGrabber()
    End Sub
#End Region

#Region "--- Form_AreaGrabber_VisibleChanged ---"

    Private Sub Form_AreaGrabber_VisibleChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.VisibleChanged
        If Me.m_AutoClose Then
            Me.Close()
        End If
    End Sub

#End Region

#Region "--- ContextMenu Event ---"

    Private Sub ZoomContextMenuStrip_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ZoomContextMenuStrip.ItemClicked
        If e.ClickedItem Is ZoomInToolStripMenuItem Then
            Me.m_MoveToCenter = True
            Me.Button_ZoomIn.PerformClick()
        ElseIf e.ClickedItem Is ZoomOutToolStripMenuItem Then
            Me.m_MoveToCenter = True
            Me.Button_ZoomOut.PerformClick()
        ElseIf e.ClickedItem Is OriginToolStripMenuItem Then
            Me.Button_ZoomO.PerformClick()
        ElseIf e.ClickedItem Is ZoomAllToolStripMenuItem Then
            Me.Button_ZoomAll.PerformClick()
        ElseIf e.ClickedItem Is BitToolStripMenuItem Then
            Me.ImageUpdate(10)
        ElseIf e.ClickedItem Is BitToolStripMenuItem1 Then
            Me.ImageUpdate(8)
        ElseIf e.ClickedItem Is BitToolStripMenuItem2 Then
            Me.ImageUpdate(0)
        End If
    End Sub

#End Region

#End Region


#Region "--- 更新目前的狀態 ---"

#Region "--- MainForm UI ---"
    Delegate Sub OutputInfoCallback(ByVal msg As String)
    Public Sub OutputInfo(ByVal msg As String)
        If Me.txtOutput.InvokeRequired Then
            Me.Invoke(New OutputInfoCallback(AddressOf OutputInfo), New Object() {msg})
        Else
            If Me.m_MainProcess.StartClearText Then
                Me.txtOutput.Clear()
            End If

            SyncLock (Me.m_MainProcess.DailyLogManager)
                Me.m_MainProcess.LogDailyManager(msg)
            End SyncLock

            SyncLock Me.txtOutput
                Me.txtOutput.SelectionColor = Color.Blue
                Me.txtOutput.AppendText(Now.ToString("HH:mm:ss   "))
                Me.txtOutput.SelectionColor = Color.Black
                Me.txtOutput.AppendText(msg & vbCrLf)

                '--- 移至最後一行 ---
                Me.txtOutput.SelectionStart = Me.txtOutput.Text.Length
                Me.txtOutput.Focus()
            End SyncLock
            Me.Update()
        End If
    End Sub

    Delegate Sub OutputErrorInfoCallback(ByVal msg As String)
    Public Sub OutputErrorInfo(ByVal msg As String)
        If Me.txtOutput.InvokeRequired Then
            Me.Invoke(New OutputErrorInfoCallback(AddressOf OutputErrorInfo), New Object() {msg})
        Else
            If Me.m_MainProcess.StartClearText Then
                Me.txtOutput.Clear()
            End If

            SyncLock (Me.m_MainProcess.DailyLogManager)
                Me.m_MainProcess.LogDailyManager(msg)
            End SyncLock

            SyncLock Me.txtOutput
                Me.txtOutput.SelectionColor = Color.Blue
                Me.txtOutput.AppendText(Now.ToString("HH:mm:ss   "))
                Me.txtOutput.SelectionColor = Color.Red
                Me.txtOutput.AppendText(msg & vbCrLf)

                '--- 移至最後一行 ---
                Me.txtOutput.SelectionStart = Me.txtOutput.Text.Length
                Me.txtOutput.Focus()
            End SyncLock
            Me.Update()
        End If
    End Sub

    Delegate Sub PreInfoCallback(ByVal msg As String)
    Public Sub PreInfo(ByVal msg As String)
        If Me.TextBox_PreInfo.InvokeRequired Then
            Me.Invoke(New PreInfoCallback(AddressOf PreInfo), New Object() {msg})
        Else
            SyncLock Me.TextBox_PreInfo
                Me.TextBox_PreInfo.Text = msg
            End SyncLock
            Me.Update()
        End If
    End Sub

    Delegate Sub SetPatternIndexInfoCallback(ByVal i As Integer)
    Public Sub SetPatternIndexInfo(ByVal i As Integer)
        If Me.ComboBox_Pattern_MainFrm.InvokeRequired Then
            Me.Invoke(New SetPatternIndexInfoCallback(AddressOf SetPatternIndexInfo), New Object() {i})
        Else
            Me.ComboBox_Pattern_MainFrm.SelectedIndex = i - 1
            Me.Update()
        End If
    End Sub

    Delegate Function GetPatternIndexInfoCallback() As Integer
    Public Function GetPatternIndexInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_Pattern_MainFrm.InvokeRequired Then
            Return Me.Invoke(New GetPatternIndexInfoCallback(AddressOf GetPatternIndexInfo), New Object() {})
        Else
            i = Me.ComboBox_Pattern_MainFrm.SelectedIndex
            Me.Update()
            Return i
        End If
    End Function

    Delegate Function GetTypeIndexInfoCallback() As Integer
    Public Function GetTypeIndexInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_Type.InvokeRequired Then
            Return Me.Invoke(New GetTypeIndexInfoCallback(AddressOf GetTypeIndexInfo), New Object() {})
        Else
            i = Me.ComboBox_Type.SelectedIndex
            Me.Update()
            Return i
        End If
    End Function

    Delegate Sub SetTypeIndexInfoCallback(ByVal index As Integer)
    Public Sub SetTypeIndexInfo(ByVal index As Integer)
        If Me.ComboBox_Type.InvokeRequired Then
            Me.Invoke(New SetTypeIndexInfoCallback(AddressOf SetTypeIndexInfo), New Object() {index})
        Else
            Me.ComboBox_Type.SelectedIndex = index
        End If
    End Sub

    Delegate Function GetSelectIndexInfoCallback() As Integer
    Public Function GetSelectIndexInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_Select.InvokeRequired Then
            Return Me.Invoke(New GetSelectIndexInfoCallback(AddressOf GetSelectIndexInfo), New Object() {})
        Else
            i = Me.ComboBox_Select.SelectedIndex
            Me.Update()
            Return i
        End If
    End Function

    Delegate Sub SetSelectIndexInfoCallback(ByVal index As Integer)
    Private Sub SetSelectIndexInfo(ByVal index As Integer)
        If Me.ComboBox_Select.InvokeRequired Then
            Me.Invoke(New SetSelectIndexInfoCallback(AddressOf SetSelectIndexInfo), New Object() {index})
        Else
            Me.ComboBox_Select.SelectedIndex = index
        End If
    End Sub

    Private Delegate Sub SetProductNameInfoCallback(ByVal str As String)
    Public Sub SetProductNameInfo(ByVal str As String)
        If Me.TextBox_Product.InvokeRequired Then
            Me.Invoke(New SetProductNameInfoCallback(AddressOf SetProductNameInfo), New Object() {str})
        Else
            Me.TextBox_Product.Text = str
            Me.Update()
        End If
    End Sub

    Private Delegate Function GetProductNameInfoCallback() As String
    Public Function GetProductNameInfo() As String
        Dim str As String
        If Me.TextBox_Product.InvokeRequired Then
            Return Me.Invoke(New GetProductNameInfoCallback(AddressOf GetProductNameInfo), New Object() {})
        Else
            str = Me.TextBox_Product.Text
            Me.Update()
            Return str
        End If
    End Function

    Private Delegate Function GetPatternNameInfoCallback() As String
    Public Function GetPatternNameInfo() As String
        Dim str As String
        If Me.ComboBox_Pattern_MainFrm.InvokeRequired Then
            Return Me.Invoke(New GetPatternNameInfoCallback(AddressOf GetPatternNameInfo), New Object() {})
        Else
            str = Me.ComboBox_Pattern_MainFrm.Text
            Me.Update()
            Return str
        End If
    End Function

    Delegate Sub SetCCDInfoCallback(ByVal index As Integer)
    Private Sub SetCCDInfo(ByVal index As Integer)
        If Me.ComboBox_Select.InvokeRequired Then
            Me.Invoke(New SetCCDInfoCallback(AddressOf SetCCDInfo), New Object() {index})
        Else
            Me.ComboBox_CCD.SelectedIndex = index
        End If
    End Sub

    Delegate Sub SetCCDTextCallback(ByVal index As String)
    Private Sub SetCCDText(ByVal index As String)
        If Me.ComboBox_Select.InvokeRequired Then
            Me.Invoke(New SetCCDTextCallback(AddressOf SetCCDText), New Object() {index})
        Else
            Me.ComboBox_CCD.Text = index
        End If
    End Sub

    Delegate Sub SetGrabNoInfoCallback(ByVal GrabNo As String)
    Private Sub SetGrabNoInfo(ByVal GrabNo As String)
        If Me.ComboBox_GrabNo.InvokeRequired Then
            Me.Invoke(New SetGrabNoInfoCallback(AddressOf SetGrabNoInfo), New Object() {GrabNo})
        Else
            Me.ComboBox_GrabNo.Text = GrabNo
        End If
    End Sub

    Delegate Function GetIPNoInfoCallback() As Integer
    Public Function GetIPNoInfo() As Integer
        Dim i As Integer
        If Me.ComboBox_CCD.InvokeRequired Then
            Return Me.Invoke(New GetIPNoInfoCallback(AddressOf GetIPNoInfo), New Object() {})
        Else
            i = Me.ComboBox_CCD.Text
            Me.Update()
            Return i
        End If
    End Function

    Delegate Function GetAxMDisplay_HandleInfoCallback() As Integer
    Public Function GetAxMDisplay_HandleInfo() As Integer
        Dim i As Integer
        If Me.Panel_AxMDisplay.InvokeRequired Then
            Return Me.Invoke(New GetAxMDisplay_HandleInfoCallback(AddressOf GetAxMDisplay_HandleInfo), New Object() {})
        Else
            i = Me.Panel_AxMDisplay.Handle
            Return i
        End If
    End Function

    Delegate Sub SetHScrollBarMaxCallback(ByVal index As Integer)
    Public Sub SetHScrollBar(ByVal index As Integer)
        If Me.HScrollBar.InvokeRequired Then
            Me.Invoke(New SetHScrollBarMaxCallback(AddressOf SetHScrollBar), New Object() {index})
        Else
            Me.HScrollBar.Maximum = index
        End If
    End Sub

    Delegate Sub SetVScrollBarMaxCallback(ByVal index As Integer)
    Public Sub SetVScrollBar(ByVal index As Integer)
        If Me.VScrollBar.InvokeRequired Then
            Me.Invoke(New SetVScrollBarMaxCallback(AddressOf SetVScrollBar), New Object() {index})
        Else
            Me.VScrollBar.Maximum = index
        End If
    End Sub

#End Region

#Region "--- Update Dialog ---"

#Region "--- Mura Dialog ---"
    '--- Mura Dialog ---
    Delegate Sub SetDialogMuraAutoManualCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraAutoManual(ByVal S As Boolean)
        If Me.m_DialogMuraAutoManual.InvokeRequired Then
            Me.Invoke(New SetDialogMuraAutoManualCallback(AddressOf SetDialogMuraAutoManual), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraAutoManual.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraBoundaryCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraBoundary(ByVal S As Boolean)
        If Me.m_DialogMuraBoundary.InvokeRequired Then
            Me.Invoke(New SetDialogMuraBoundaryCallback(AddressOf SetDialogMuraBoundary), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraBoundary.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraSmoothCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraSmooth(ByVal S As Boolean)
        If Me.m_DialogMuraSmooth.InvokeRequired Then
            Me.Invoke(New SetDialogMuraSmoothCallback(AddressOf SetDialogMuraSmooth), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraSmooth.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraCollectionCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraCollection(ByVal S As Boolean)
        If Me.m_DialogMuraCollection.InvokeRequired Then
            Me.Invoke(New SetDialogMuraCollectionCallback(AddressOf SetDialogMuraCollection), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraCollection.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogBlobMuraLocalCallback(ByVal S As Boolean)
    Public Sub SetDialogBlobMuraLocal(ByVal S As Boolean)
        If Me.m_DialogBlobMuraLocal.InvokeRequired Then
            Me.Invoke(New SetDialogBlobMuraLocalCallback(AddressOf SetDialogBlobMuraLocal), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogBlobMuraLocal.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogBlobMuraRoundCallback(ByVal S As Boolean)
    Public Sub SetDialogBlobMuraRound(ByVal S As Boolean)
        If Me.m_DialogBlobMuraRound.InvokeRequired Then
            Me.Invoke(New SetDialogBlobMuraRoundCallback(AddressOf SetDialogBlobMuraRound), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogBlobMuraRound.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogBandMuraCallback(ByVal S As Boolean)
    Public Sub SetDialogBandMura(ByVal S As Boolean)
        If Me.m_DialogBandMura.InvokeRequired Then
            Me.Invoke(New SetDialogBandMuraCallback(AddressOf SetDialogBandMura), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogBandMura.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraJNDCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraJND(ByVal S As Boolean)
        If Me.m_DialogMuraJND.InvokeRequired Then
            Me.Invoke(New SetDialogMuraJNDCallback(AddressOf SetDialogMuraJND), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraJND.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraFalseDefectCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraFalseDefect(ByVal S As Boolean)
        If Me.m_DialogMuraFalseDefect.InvokeRequired Then
            Me.Invoke(New SetDialogMuraFalseDefectCallback(AddressOf SetDialogMuraFalseDefect), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraFalseDefect.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraResultCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraResult(ByVal S As Boolean)
        If Me.m_DialogMuraResult.InvokeRequired Then
            Me.Invoke(New SetDialogMuraResultCallback(AddressOf SetDialogMuraResult), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraResult.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraSettingBaseCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraSettingBase(ByVal S As Boolean)
        If Me.m_DialogMuraSettingBase.InvokeRequired Then
            Me.Invoke(New SetDialogMuraSettingBaseCallback(AddressOf SetDialogMuraSettingBase), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraSettingBase.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogMuraSettingCallback(ByVal S As Boolean)
    Public Sub SetDialogMuraSetting(ByVal S As Boolean)
        If Me.m_DialogMuraSetting.InvokeRequired Then
            Me.Invoke(New SetDialogMuraSettingCallback(AddressOf SetDialogMuraSetting), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogMuraSetting.Close()
                Me.Update()
            End If
        End If
    End Sub
#End Region

#Region "--- Func Dialog ---"
    '--- Func Dialog ---
    Delegate Sub SetDialogFuncSettingBaseCallback(ByVal S As Boolean)
    Public Sub SetDialogFuncSettingBase(ByVal S As Boolean)
        If Me.m_DialogFuncSettingBase.InvokeRequired Then
            Me.Invoke(New SetDialogFuncSettingBaseCallback(AddressOf SetDialogFuncSettingBase), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogFuncSettingBase.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogFuncSettingCallback(ByVal S As Boolean)
    Public Sub SetDialogFuncSetting(ByVal S As Boolean)
        If Me.m_DialogFuncSetting.InvokeRequired Then
            Me.Invoke(New SetDialogFuncSettingCallback(AddressOf SetDialogFuncSetting), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogFuncSetting.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogADJMeanCallback(ByVal S As Boolean)
    Public Sub SetDialogADJMean(ByVal S As Boolean)
        If Me.m_DialogADJMean.InvokeRequired Then
            Me.Invoke(New SetDialogADJMeanCallback(AddressOf SetDialogADJMean), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogADJMean.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogAlignCallback(ByVal S As Boolean)
    Public Sub SetDialogAlign(ByVal S As Boolean)
        If Me.m_DialogAlign.InvokeRequired Then
            Me.Invoke(New SetDialogADJMeanCallback(AddressOf SetDialogAlign), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogAlign.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogFuncTestImgProcCallback(ByVal S As Boolean)
    Public Sub SetDialogFuncTestImgProc(ByVal S As Boolean)
        If Me.m_DialogFuncTestImgProc.InvokeRequired Then
            Me.Invoke(New SetDialogFuncTestImgProcCallback(AddressOf SetDialogFuncTestImgProc), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogFuncTestImgProc.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogFuncFalseDefectCallback(ByVal S As Boolean)
    Public Sub SetDialogFuncFalseDefect(ByVal S As Boolean)
        If Me.m_DialogFuncFalseDefect.InvokeRequired Then
            Me.Invoke(New SetDialogFuncFalseDefectCallback(AddressOf SetDialogFuncFalseDefect), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogFuncFalseDefect.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogFuncResultCallback(ByVal S As Boolean)
    Public Sub SetDialogFuncResult(ByVal S As Boolean)
        If Me.m_DialogFuncResult.InvokeRequired Then
            Me.Invoke(New SetDialogFuncResultCallback(AddressOf SetDialogFuncResult), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogFuncResult.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetDialogSetMappingTableCallback(ByVal S As Boolean)
    Public Sub SetDialogSetMappingTable(ByVal S As Boolean)
        If Me.m_DialogSetMappingTable.InvokeRequired Then
            Me.Invoke(New SetDialogSetMappingTableCallback(AddressOf SetDialogSetMappingTable), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogSetMappingTable.Close()
                Me.Update()
            End If
        End If
    End Sub
    Delegate Sub SetGroupBox_CCDCallback(ByVal S As Boolean)
    Public Sub SetGroupBox_CCD(ByVal S As Boolean)
        If Me.GroupBox_IP.InvokeRequired Then
            Me.Invoke(New SetGroupBox_CCDCallback(AddressOf SetGroupBox_CCD), New Object() {S})
        Else
            Me.GroupBox_IP.Enabled = S
            Me.Update()
        End If
    End Sub

#End Region

#Region "--- Recipe_Dialog ---"
    Delegate Sub SetDialogIPNetWorkConfigCallback(ByVal S As Boolean)
    Public Sub SetDialogIPNetWorkConfig(ByVal S As Boolean)
        If Me.m_DialogIPNetWorkConfig.InvokeRequired Then
            Me.Invoke(New SetDialogIPNetWorkConfigCallback(AddressOf SetDialogIPNetWorkConfig), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogIPNetWorkConfig.Close()
                Me.Update()
            End If
        End If
    End Sub

    Delegate Sub SetDialogIPBootConfigCallback(ByVal S As Boolean)
    Public Sub SetDialogIPBootConfig(ByVal S As Boolean)
        If Me.m_DialogIPBootConfig.InvokeRequired Then
            Me.Invoke(New SetDialogIPBootConfigCallback(AddressOf SetDialogIPBootConfig), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogIPBootConfig.Close()
                Me.Update()
            End If
        End If
    End Sub
#End Region

#Region "--- Measurement_Dialog ---"
    Delegate Sub SetDialogCalculateMeasurementCallback(ByVal S As Boolean)
    Public Sub SetDialogCalculateMeasurement(ByVal S As Boolean)
        If Me.m_DialogCalculateMeasurement.InvokeRequired Then
            Me.Invoke(New SetDialogCalculateMeasurementCallback(AddressOf SetDialogCalculateMeasurement), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogCalculateMeasurement.Close()
                Me.Update()
            End If
        End If
    End Sub
#End Region

#Region "--- Tool ---"
    Delegate Sub SetDialogCameraAlignmentCallback(ByVal S As Boolean)
    Public Sub SetDialogCameraAlignment(ByVal S As Boolean)
        If Me.m_DialogCameraAlignment.InvokeRequired Then
            Me.Invoke(New SetDialogCameraAlignmentCallback(AddressOf SetDialogCameraAlignment), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogCameraAlignment.Close()
                Me.Update()
            End If
        End If
    End Sub

    Delegate Sub SetDialogLookupPositionCallback(ByVal S As Boolean)
    Public Sub SetDialogLookupPosition(ByVal S As Boolean)
        If Me.m_DialogLookupPosition.InvokeRequired Then
            Me.Invoke(New SetDialogLookupPositionCallback(AddressOf SetDialogLookupPosition), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogLookupPosition.Close()
                Me.Update()
            End If
        End If
    End Sub

    Delegate Sub SetDialogRMSSettingCallback(ByVal S As Boolean)
    Public Sub SetDialogRMSSetting(ByVal S As Boolean)
        If Me.m_DialogRMSSetting.InvokeRequired Then
            Me.Invoke(New SetDialogRMSSettingCallback(AddressOf SetDialogRMSSetting), New Object() {S})
        Else
            If S = False Then
                Me.m_DialogRMSSetting.Close()
                Me.Update()
            End If
        End If
    End Sub
#End Region

#End Region

#Region "--- ScrollBar Event ---"
    Private Delegate Function HScrollBar_EnableScrollCallback(ByVal V As Boolean) As Boolean
    Public Function HScrollBar_Enable(ByVal V As Boolean) As Boolean
        If Me.HScrollBar.InvokeRequired Then
            Me.Invoke(New HScrollBar_EnableScrollCallback(AddressOf HScrollBar_Enable), New Object() {V})
        Else
            Me.HScrollBar.Enabled = V
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function VScrollBar_EnableScrollCallback(ByVal V As Boolean) As Boolean
    Public Function VScrollBar_Enable(ByVal V As Boolean) As Boolean
        If Me.VScrollBar.InvokeRequired Then
            Me.Invoke(New VScrollBar_EnableScrollCallback(AddressOf VScrollBar_Enable), New Object() {V})
        Else
            Me.VScrollBar.Enabled = V
            Me.Update()
        End If
        Return True
    End Function

#End Region

#Region "--- GroupBox Event ---"
    Delegate Sub SetGroupBox_ImageCallback(ByVal En As Boolean)
    Public Sub SetGroupBox_Image(ByVal En As Boolean)
        If Me.GroupBox_Image.InvokeRequired Then
            Me.Invoke(New SetGroupBox_ImageCallback(AddressOf SetGroupBox_Image), New Object() {En})
        Else
            Me.GroupBox_Image.Enabled = En
            Me.Update()
        End If
    End Sub

    Private Delegate Function SetGroupBox_FuncSettingCallback(ByVal En As Boolean) As Boolean
    Private Function SetGroupBox_FuncSetting(ByVal En As Boolean) As Boolean
        If Me.GroupBox_FuncSetting.InvokeRequired Then
            Me.Invoke(New SetGroupBox_FuncSettingCallback(AddressOf SetGroupBox_FuncSetting), New Object() {En})
        Else
            Me.GroupBox_FuncSetting.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    'Private Delegate Function SetGroupBox_FuncTestCallback(ByVal En As Boolean) As Boolean
    'Private Function SetGroupBox_FuncTest(ByVal En As Boolean) As Boolean
    '    If Me.GroupBox_FuncTest.InvokeRequired Then
    '        Me.Invoke(New SetGroupBox_FuncTestCallback(AddressOf SetGroupBox_FuncTest), New Object() {En})
    '    Else
    '        Me.GroupBox_FuncTest.Enabled = En
    '        Me.Update()
    '    End If
    '    Return True
    'End Function

    'Private Delegate Function SetGroupBox_MuraSettingCallback(ByVal En As Boolean) As Boolean
    'Private Function SetGroupBox_MuraSetting(ByVal En As Boolean) As Boolean
    '    If Me.GroupBox_MuraSetting.InvokeRequired Then
    '        Me.Invoke(New SetGroupBox_MuraSettingCallback(AddressOf SetGroupBox_MuraSetting), New Object() {En})
    '    Else
    '        Me.GroupBox_MuraSetting.Enabled = En
    '        Me.Update()
    '    End If
    '    Return True
    'End Function

    'Private Delegate Function SetGroupBox_MuraTestCallback(ByVal En As Boolean) As Boolean
    'Private Function SetGroupBox_MuraTest(ByVal En As Boolean) As Boolean
    '    If Me.GroupBox_MuraTest.InvokeRequired Then
    '        Me.Invoke(New SetGroupBox_MuraTestCallback(AddressOf SetGroupBox_MuraTest), New Object() {En})
    '    Else
    '        Me.GroupBox_MuraTest.Enabled = En
    '        Me.Update()
    '    End If
    '    Return True
    'End Function
#End Region

#Region "--- Button Event ---"

    Private Delegate Function SetButton_ZoomInCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomIn(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomIn.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomInCallback(AddressOf SetButton_ZoomIn), New Object() {En})
        Else
            Me.Button_ZoomIn.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_ZoomOutCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomOut(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomOut.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomOutCallback(AddressOf SetButton_ZoomOut), New Object() {En})
        Else
            Me.Button_ZoomOut.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_ZoomOCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomO(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomO.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomOCallback(AddressOf SetButton_ZoomO), New Object() {En})
        Else
            Me.Button_ZoomO.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_ZoomAllCallback(ByVal En As Boolean) As Boolean
    Public Function SetButton_ZoomAll(ByVal En As Boolean) As Boolean
        If Me.Button_ZoomAll.InvokeRequired Then
            Me.Invoke(New SetButton_ZoomAllCallback(AddressOf SetButton_ZoomAll), New Object() {En})
        Else
            Me.Button_ZoomAll.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_InitialIPCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_InitialIP(ByVal En As Boolean) As Boolean
        If Me.Button_InitialIP.InvokeRequired Then
            Me.Invoke(New SetButton_InitialIPCallback(AddressOf SetButton_InitialIP), New Object() {En})
        Else
            Me.Button_InitialIP.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_KillIPCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_KillIP(ByVal En As Boolean) As Boolean
        If Me.Button_KillIP.InvokeRequired Then
            Me.Invoke(New SetButton_KillIPCallback(AddressOf SetButton_KillIP), New Object() {En})
        Else
            Me.Button_KillIP.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_LoadCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Load(ByVal En As Boolean) As Boolean
        If Me.Button_LoadImage.InvokeRequired Then
            Me.Invoke(New SetButton_LoadCallback(AddressOf SetButton_Load), New Object() {En})
        Else
            Me.Button_LoadImage.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_SaveCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Save(ByVal En As Boolean) As Boolean
        If Me.Button_SaveImage.InvokeRequired Then
            Me.Invoke(New SetButton_SaveCallback(AddressOf SetButton_Save), New Object() {En})
        Else
            Me.Button_SaveImage.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_ADJMeanCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_ADJMean(ByVal En As Boolean) As Boolean
        If Me.Button_ADJMean.InvokeRequired Then
            Me.Invoke(New SetButton_ADJMeanCallback(AddressOf SetButton_ADJMean), New Object() {En})
        Else
            Me.Button_ADJMean.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

#Region "--- Mura ---"
    Private Delegate Function SetButton_MuraFalseDefectCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_MuraFalseDefect(ByVal En As Boolean) As Boolean
        If Me.Button_MuraFalseDefect.InvokeRequired Then
            Me.Invoke(New SetButton_MuraFalseDefectCallback(AddressOf SetButton_MuraFalseDefect), New Object() {En})
        Else
            Me.Button_MuraFalseDefect.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
    Private Delegate Function SetButton_JNDCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_JND(ByVal En As Boolean) As Boolean
        If Me.Button_JND.InvokeRequired Then
            Me.Invoke(New SetButton_JNDCallback(AddressOf SetButton_JND), New Object() {En})
        Else
            Me.Button_JND.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
    Private Delegate Function SetButton_SettingMuraCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_SettingMura(ByVal En As Boolean) As Boolean
        If Me.Button_SettingMura.InvokeRequired Then
            Me.Invoke(New SetButton_SettingMuraCallback(AddressOf SetButton_SettingMura), New Object() {En})
        Else
            Me.Button_SettingMura.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
    Private Delegate Function SetButton_SettingBaseCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_SettingBase(ByVal En As Boolean) As Boolean
        If Me.Button_SettingBase.InvokeRequired Then
            Me.Invoke(New SetButton_SettingBaseCallback(AddressOf SetButton_SettingBase), New Object() {En})
        Else
            Me.Button_SettingBase.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
    Private Delegate Function SetButton_MuraResultCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_MuraResult(ByVal En As Boolean) As Boolean
        If Me.Button_MuraResult.InvokeRequired Then
            Me.Invoke(New SetButton_MuraResultCallback(AddressOf SetButton_MuraResult), New Object() {En})
        Else
            Me.Button_MuraResult.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
    Private Delegate Function SetButton_MuraAutoTestCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_MuraAutoTest(ByVal En As Boolean) As Boolean
        If Me.Button_MuraAutoTest.InvokeRequired Then
            Me.Invoke(New SetButton_MuraAutoTestCallback(AddressOf SetButton_MuraAutoTest), New Object() {En})
        Else
            Me.Button_MuraAutoTest.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
    Private Delegate Function SetButton_MuraManualTestCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_MuraManualTest(ByVal En As Boolean) As Boolean
        If Me.Button_MuraManualTest.InvokeRequired Then
            Me.Invoke(New SetButton_MuraManualTestCallback(AddressOf SetButton_MuraManualTest), New Object() {En})
        Else
            Me.Button_MuraManualTest.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- Func ---"
    Private Delegate Function SetButton_FuncSettingBaseCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_FuncSettingBase(ByVal En As Boolean) As Boolean
        If Me.Button_FuncSettingBase.InvokeRequired Then
            Me.Invoke(New SetButton_FuncSettingBaseCallback(AddressOf SetButton_FuncSettingBase), New Object() {En})
        Else
            Me.Button_FuncSettingBase.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_SettingFuncCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_SettingFunc(ByVal En As Boolean) As Boolean
        If Me.Button_SettingFunc.InvokeRequired Then
            Me.Invoke(New SetButton_SettingFuncCallback(AddressOf SetButton_SettingFunc), New Object() {En})
        Else
            Me.Button_SettingFunc.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_FuncFalseDefectCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_FuncFalseDefect(ByVal En As Boolean) As Boolean
        If Me.Button_FuncFalseDefect.InvokeRequired Then
            Me.Invoke(New SetButton_FuncFalseDefectCallback(AddressOf SetButton_FuncFalseDefect), New Object() {En})
        Else
            Me.Button_FuncFalseDefect.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_FuncResultCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_FuncResult(ByVal En As Boolean) As Boolean
        If Me.Button_FuncResult.InvokeRequired Then
            Me.Invoke(New SetButton_FuncResultCallback(AddressOf SetButton_FuncResult), New Object() {En})
        Else
            Me.Button_FuncResult.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_FuncImgProcTestCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_FuncImgProcTest(ByVal En As Boolean) As Boolean
        If Me.Button_FuncImgProcTest.InvokeRequired Then
            Me.Invoke(New SetButton_FuncImgProcTestCallback(AddressOf SetButton_FuncImgProcTest), New Object() {En})
        Else
            Me.Button_FuncImgProcTest.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_SetMappingTableCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_SetMappingTable(ByVal En As Boolean) As Boolean
        If Me.Button_SetMappingTable.InvokeRequired Then
            Me.Invoke(New SetButton_SetMappingTableCallback(AddressOf SetButton_SetMappingTable), New Object() {En})
        Else
            Me.Button_SetMappingTable.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_OMS_SaveCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_OMS_Save(ByVal En As Boolean) As Boolean
        If Me.Button_OMS_Save.InvokeRequired Then
            Me.Invoke(New SetButton_OMS_SaveCallback(AddressOf SetButton_OMS_Save), New Object() {En})
        Else
            Me.Button_OMS_Save.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_OMSSettingCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_OMSSetting(ByVal En As Boolean) As Boolean
        If Me.Button_OMSSetting.InvokeRequired Then
            Me.Invoke(New SetButton_OMSSettingCallback(AddressOf SetButton_OMSSetting), New Object() {En})
        Else
            Me.Button_OMSSetting.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_LookUpPositionCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_LookUpPosition(ByVal En As Boolean) As Boolean
        If Me.Button_LookUpPosition.InvokeRequired Then
            Me.Invoke(New SetButton_LookUpPositionCallback(AddressOf SetButton_LookUpPosition), New Object() {En})
        Else
            Me.Button_LookUpPosition.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#End Region

#Region "--- UpatePatternUI ---"
    Private Delegate Sub UpatePatternUICallback()
    Public Sub UpatePatternUI()
        'ErrorCode = 250 ~ 254
        If Me.TextBox_Product.InvokeRequired Then
            Me.Invoke(New UpatePatternUICallback(AddressOf UpatePatternUI), New Object() {})
        Else
            Dim i As Integer
            Dim mppa As ClsMuraPatternRecipeArray
            Dim mpp As ClsMuraPatternRecipe
            Dim mp As ClsMuraModelRecipe
            Dim fppa As ClsFuncPatternRecipeArray
            Dim fpp As ClsFuncPatternRecipe
            Dim fp As ClsFuncModelRecipe

            Me.ComboBox_Pattern_MainFrm.Items.Clear()

            If Me.m_MainProcess.IPBootConfig.MuraUI.Value Then
                '--- Load Mura Pattern Recipe ---
                Me.m_MuraProcess = Me.m_MainProcess.MuraProcess
                mp = Me.m_MainProcess.MuraProcess.MuraModelRecipe
                mppa = Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray

                Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 252
                Try
                    For i = 0 To mp.PatternCount.Value - 1
                        mpp = mppa.Item(i)
                        Me.ComboBox_Pattern_MainFrm.Items.Add(mpp.PatternName.Value)
                    Next
                Catch ex As Exception
                    Throw New Exception("[UpatePatternUI][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Add Mura Patterns'UI  Error! (" & ex.Message & ")(" & ex.StackTrace & ")")
                End Try
            End If

            '--- Load Func Pattern Recipe ---
            fp = Me.m_MainProcess.FuncProcess.FuncModelRecipe
            fppa = Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray

            Me.m_MainProcess.ErrorCode = Me.m_MainProcess.ErrorCodeBase + 253
            Try
                For i = 0 To fp.PatternCount.Value - 1
                    fpp = fppa.Item(i)
                    Me.ComboBox_Pattern_MainFrm.Items.Add(fpp.PatternName.Value)
                Next
            Catch ex As Exception
                Throw New Exception("[UpatePatternUI][ErrorCode = " & Me.m_MainProcess.ErrorCode & "]Add Func Patterns'UI  Error! (" & ex.Message & ")(" & ex.StackTrace & ")")
            End Try

            Me.Update()
        End If
    End Sub
#End Region

#Region "--- Status Event ---"
    Private Delegate Sub StatusBarXYVCallback(ByVal xy As String, ByVal value As String)
    Public Sub StatusBarXYV(ByVal xy As String, ByVal value As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New StatusBarXYVCallback(AddressOf StatusBarXYV), New Object() {xy, value})
        Else
            Me.StatusBarPanel_XY.Text = "(X,Y) = " & xy
            Me.StatusBarPanel_Value.Text = "亮度 = " & value
            Me.Update()
        End If
    End Sub

    Private Delegate Sub StatusBarStatusCallback(ByVal msg As String)
    Public Sub StatusBarStatus(ByVal msg As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New StatusBarStatusCallback(AddressOf StatusBarStatus), New Object() {msg})
        Else
            Me.StatusBarPanel_Status.Text = "Status：" & msg
            Me.Update()
        End If
    End Sub

    Private Delegate Sub StatusBarIPStatusCallback(ByVal msg As String)
    Public Sub StatusBarIPStatus(ByVal msg As String)
        If Me.StatusBar_IP.InvokeRequired Then
            Me.Invoke(New StatusBarIPStatusCallback(AddressOf StatusBarIPStatus), New Object() {msg})
        Else
            Me.StatusBarPanel_IPStatus.Text = "Status：" & msg
            Me.Update()
        End If
    End Sub

    Private Delegate Sub SetStatusBarPanel_ScaleCallback(ByVal msg As String)
    Public Sub SetStatusBarPanel_Scale(ByVal msg As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New SetStatusBarPanel_ScaleCallback(AddressOf SetStatusBarPanel_Scale), New Object() {msg})
        Else
            Me.StatusBarPanel_Scale.Text = msg
            Me.Update()
        End If
    End Sub

    Private Delegate Sub SetStatusBarUsedNonPageCallback(ByVal value As String)
    Public Sub SetStatusBarUsedNonPage(ByVal value As String)
        If Me.StatusBar.InvokeRequired Then
            Me.Invoke(New SetStatusBarUsedNonPageCallback(AddressOf SetStatusBarUsedNonPage), New Object() {value})
        Else
            Me.StatusBarPanel_UsedNonPage.Text = value
            Me.Update()
        End If
    End Sub
#End Region

#Region "---Label Event---"
    Private Delegate Sub LabelXYVCallback(ByVal x As String, ByVal y As String, ByVal value As String)
    Public Sub LabelXYValue(ByVal x As String, ByVal y As String, ByVal value As String)
        If Me.Label_imgAnchorPosX.InvokeRequired Then
            Me.Invoke(New LabelXYVCallback(AddressOf LabelXYValue), New Object() {x, y, value})
        Else
            Me.Label_imgAnchorPosX.Text = "X: " & x
            Me.Label_imgAnchorPosY.Text = "Y: " & y
            Me.Label_ImgGrayValue.Text = "亮度 = " & value
            Me.Update()
        End If
    End Sub
#End Region


#End Region

#Region "<--- MainProcess Event --->"

#Region "--- IP1_Connect ---"
    Private Sub m_MainProcess_IP_Connect(ByVal IPNo As Integer) Handles m_MainProcess.IP_Connect
        Me.PicIP(IPNo - 1).Image = My.Resources.G_cir
    End Sub
#End Region

#Region "--- IP1_DisConnect ---"
    Private Sub m_MainProcess_IPDisConnect(ByVal IPCount As Integer) Handles m_MainProcess.IPDisConnect
        Dim i As Integer

        Try
            For i = 0 To IPCount - 1
                If Not Me.PicIP(i) Is Nothing AndAlso Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i).IP_Enable Then
                    Me.PicIP(i).Image = My.Resources.R_cir
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("[IPDisConnect]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- SingleIP_DisConnect ---"
    Private Sub m_MainProcess_SingleIP_DisConnect(ByVal IPNo As Integer) Handles m_MainProcess.SingleIP_DisConnect

        Try
            If Not Me.PicIP(IPNo - 1) Is Nothing AndAlso Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(IPNo - 1).IP_Enable Then
                Me.PicIP(IPNo - 1).Image = My.Resources.R_cir
            End If
        Catch ex As Exception
            MessageBox.Show("[SingleIP_DisConnect]" & ex.Message)
        End Try
    End Sub
#End Region

    Private Sub m_MainProcess_OutputInfoMsg(ByVal strMsg As String) Handles m_MainProcess.OutputInfoMsg
        Me.OutputInfo(strMsg)
    End Sub
    Private Sub m_MainProcess_OutputErrorInfoMsg(ByVal strMsg As String) Handles m_MainProcess.OutputErrorInfoMsg
        Me.OutputErrorInfo(strMsg)
    End Sub
    Private Sub m_MainProcess_UpatePatternUI() Handles m_MainProcess.UpatePatternUI
        Me.UpatePatternUI()
    End Sub
    Private Sub m_MainProcess_SetProductNameUI(ByVal strProductName As String) Handles m_MainProcess.SetProductNameUI
        Me.SetProductNameInfo(strProductName)
    End Sub
    Private Sub m_MainProcess_ShowErrorMessage(ByVal strErrMsg As String) Handles m_MainProcess.ShowErrorMessage
        MessageBox.Show(strErrMsg, "AreaGrabber", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub
    Private Sub m_MainProcess_SetStatusBarStatusUI(ByVal strStatus As String) Handles m_MainProcess.SetStatusBarStatusUI
        Me.StatusBarStatus(strStatus)
    End Sub
    Private Sub m_MainProcess_SetTabPage(ByVal intTabPage As Integer) Handles m_MainProcess.SetTabPage
        Me.TabControl_HightLevel.SelectedIndex = intTabPage
    End Sub
    Private Sub m_MainProcess_SetStatusBarIPStatus(ByVal strStatus As String) Handles m_MainProcess.SetStatusBarIPStatus
        Me.StatusBarIPStatus(strStatus)
    End Sub
    Private Sub m_MainProcess_ResetAxMDisplay() Handles m_MainProcess.ResetAxMDisplay
        Me.ResetAxMDisplay()
    End Sub
    Private Sub m_MainProcess_SetTypeIndexIUI(ByVal intIndex As Integer) Handles m_MainProcess.SetTypeIndexIUI
        Me.SetTypeIndexInfo(intIndex)
    End Sub
    Private Sub m_MainProcess_UpdateUserLevelUI(ByVal UserLevel As Integer) Handles m_MainProcess.UpdateUserLevelUI
        Me.UpdateUserLevel(UserLevel, Me.m_MainProcess.ErrorCode)
    End Sub
    Private Sub m_MainProcess_SetPatternIndexUI(ByVal intIndex As Integer) Handles m_MainProcess.SetPatternIndexUI
        Me.SetPatternIndex(intIndex)
    End Sub
    Private Sub m_MainProcess_SetGrabNoInfoUI(ByVal GrabNo As String) Handles m_MainProcess.SetGrabNoInfoUI
        Me.SetGrabNoInfo(GrabNo)
    End Sub
    Private Sub m_MainProcess_SetCCDUI(ByVal CCDNo As Integer) Handles m_MainProcess.SetCCDNoUI
        Me.SetCCDInfo(CCDNo - 1)   'Selected CCD Index , from 0
    End Sub
    Private Sub m_MainProcess_SetCCDTextUI(ByVal CCDNo As String) Handles m_MainProcess.SetCCDTextUI
        Me.SetCCDText(CCDNo)   'Selected CCD Text , from 1
    End Sub
    Private Sub m_MainProcess_SetPreInfoTextUI(ByVal Msg As String) Handles m_MainProcess.SetPreInfoTextUI
        Me.PreInfo(Msg)
    End Sub
    Private Sub m_MainProcess_CloseNAVWindow() Handles m_MainProcess.CloseNAVWindow
        Dim hwnd As Integer = FindWindow(vbNullString, "Symantec AntiVirus Notification")
        Dim WM_CLOSE As Integer = CInt(&H10)
        'Dim RamRushProc() As Process
        'Dim arrProc As New ArrayList

        'RamRushProc = Process.GetProcessesByName("RAMRush")

        'If RamRushProc.Length > 0 Then
        '    Call keybd_event(VK_CONTROL, 0, 0, 0)
        '    Call keybd_event(VK_LMENU, 0, 0, 0)
        '    Call keybd_event(VK_O, 0, 0, 0)
        '    Call keybd_event(VK_O, 0, KEYEVENTF_KEYUP, 0)
        '    Call keybd_event(VK_LMENU, 0, KEYEVENTF_KEYUP, 0)
        '    Call keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)
        'End If

        If hwnd <> 0 Then
            PostMessage(hwnd, WM_CLOSE, 0, 0)
        End If

    End Sub
#End Region


    Private Function GetUNCPath(ByVal sFilePath As String) As String

        Dim allDrives() As DriveInfo = DriveInfo.GetDrives()
        Dim d As DriveInfo
        Dim DriveType, Ctr As Integer
        Dim DriveLtr, UNCName As String
        Dim StrBldr As New StringBuilder

        If sFilePath.StartsWith("\\") Then Return sFilePath

        UNCName = Space(160)
        GetUNCPath = ""

        DriveLtr = sFilePath.Substring(0, 3)

        For Each d In allDrives
            If d.Name = DriveLtr Then
                DriveType = d.DriveType
                Exit For
            End If
        Next

        If DriveType = 4 Then

            Ctr = WNetGetConnection(sFilePath.Substring(0, 2), UNCName, UNCName.Length)

            If Ctr = 0 Then
                UNCName = UNCName.Trim
                For Ctr = 0 To UNCName.Length - 1
                    Dim SingleChar As Char = UNCName(Ctr)
                    Dim asciiValue As Integer = Asc(SingleChar)
                    If asciiValue > 0 Then
                        StrBldr.Append(SingleChar)
                    Else
                        Exit For
                    End If
                Next
                StrBldr.Append(sFilePath.Substring(2))
                GetUNCPath = StrBldr.ToString
            Else
                MsgBox("Cannot Retrieve UNC path" & vbCrLf & "Must Use Mapped Drive of SQLServer", MsgBoxStyle.Critical)
            End If
        Else
            GetUNCPath = sFilePath
        End If

    End Function

    Declare Function WNetGetConnection Lib "mpr.dll" Alias "WNetGetConnectionA" (ByVal lpszLocalName As String, _
      ByVal lpszRemoteName As String, ByRef cbRemoteName As Integer) As Integer

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

    Private Sub TabControl_SystemParam_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles TabControl_SystemParam.SelectedIndexChanged
        Dim tbPage As TabPage = Me.TabControl_SystemParam.SelectedTab
        Me.m_IsSetExpTimeFlag = False
        Select Case Convert.ToString(tbPage.Tag).ToUpper()
            Case "EXP"
                Me.m_IsSetExpTimeFlag = True
            Case Else

        End Select
    End Sub

    Private Sub TabControl_SystemParam_Selecting(sender As System.Object, e As System.Windows.Forms.TabControlCancelEventArgs) Handles TabControl_SystemParam.Selecting
        Me.TabControl_HightLevel.Enabled = True
        Me.PaintStop = True

        ''--- Free PLMark Display ---
        'If Me.m_AxMDisplay_PLMark <> M_NULL Then
        '    MdispFree(Me.m_AxMDisplay_PLMark)
        '    Me.m_AxMDisplay_PLMark = M_NULL
        'End If

        ''--- Free TPMark Display ---
        'If Me.m_AxMDisplay_TPMark <> M_NULL Then
        '    MdispFree(Me.m_AxMDisplay_TPMark)
        '    Me.m_AxMDisplay_TPMark = M_NULL
        'End If

        'Me.Finalize()
    End Sub

    Private Sub tmr_Tick(sender As System.Object, e As System.EventArgs) Handles tmr.Tick
        If GetAsyncKeyState(Keys.ControlKey) And GetAsyncKeyState(Keys.U) Then
            If Me.m_VisableFunctionOpen Then
                Me.Size = New Size(1564, 714)
                Me.m_VisableFunctionOpen = False
            Else
                Me.Size = New Size(1307, 714)
                Me.m_VisableFunctionOpen = True
            End If
            Me.Update()
        End If
    End Sub

    Private Sub Button_AlignTest_Click(sender As System.Object, e As System.EventArgs) Handles Button_AlignTest.Click
        Try
            If Not Me.m_DialogAlign Is Nothing Then Me.m_DialogAlign = Nothing

            If Me.m_DialogAlign Is Nothing OrElse Me.m_DialogAlign.IsDisposed Then
                Me.m_DialogAlign = New Dialog_Align
                Me.m_DialogAlign.SetMainForm(Me, "zh-CN")
                Me.m_MainProcess.ChangeToHost(Me.m_MainProcess.OffLineTest, Me.m_MainProcess.ErrorCode)
                Me.AddOwnedForm(Me.m_DialogAlign)
                Me.m_DialogAlign.Left = Me.Left + 510
                Me.m_DialogAlign.Top = Me.Top + 180

                If Me.m_MainProcess.IsIPConnected Then
                    Me.m_DialogAlign.Show()
                End If

            End If
        Catch ex As Exception
            If Me.m_DialogFuncTestImgProc Is Nothing Then Me.m_DialogFuncTestImgProc.Close()
            MessageBox.Show("[Main_Form.Button_FuncTestImgProc_Click] Dialog Func Test Image Process Click Error !(" & ex.Message & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Me.m_DialogFuncTestImgProc = Nothing
            Me.TabControlEnable()
            Me.Focus()
        End Try
    End Sub

End Class
