Imports ClassLibrary
Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports AUO.SubSystemControl
Imports System.IO
Imports System.Threading
Imports System.Globalization

<CLSCompliant(False)> _
Public Class Dialog_ADJMean

    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_Have_MDigitizer As Boolean
    Private m_ContinueGrab As Boolean
    Private m_Thread1_RunCommand As Threading.Thread = Nothing  '�u����R�O�v����� 1
    Private m_Grab_OK As Boolean
    Private m_Ever_ContinueGrab As Boolean
    Private m_ReadWriteLock As New System.Threading.ReaderWriterLock()
    Private m_Initial_Finished As Boolean
    Private m_Max_ExposureTime As Integer
    Private m_ManualLoad As Boolean = False
    Private m_ManualPath As String

    '--- �s�u�Ѽ� ---
    Private TimeOut As Integer
    Private ip As ClsIPInfo
    Private Response_OK As Boolean = False
    Private SubSystemResult As CResponseResult
    Private Request_Command As String = ""
    Private strPath As String = ""
    Private m_IsIPConnected As Boolean = False
    Private m_IPConnectMsg As String = ""

    '-----------------ShowBoundary------------------
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    Private pb As New ClsParameterBoundary

    '---ZoomIn / ZoomOut---
    Private m_ZoomIn As Boolean = False
    Private m_ZoomOut As Boolean = False

    '--- Master\Slave Mode ---
    Private m_MasterSlaveMode_Enable As Boolean
    Private m_Master_ID As Integer
    Private m_Slave_ID As Integer
    Private res As System.Resources.ResourceManager '�YԴ�n����T

#Region "--- SetMainForm ---"
    Public Sub SetMainForm(ByVal form As Main_Form, ByVal language As String)
        Dim image As MIL_ID = M_NULL
        Dim strs() As String
        Dim count1 As Integer
        Dim count2 As Integer
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        '--- Change Language ---
        res = New Resources.ResourceManager("AreaGrabber.Dialog_ADJMean", Me.GetType().Assembly)
        Thread.CurrentThread.CurrentCulture = New CultureInfo(language)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(language)
        Me.changeLanguage(language)
        '------------


        Me.m_Form = form
        Me.m_MainProcess = form.MainProcess
        Me.m_FuncProcess = form.MainProcess.FuncProcess
        Me.m_MuraProcess = form.MainProcess.MuraProcess
        Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig
        Me.m_Max_ExposureTime = Me.m_MainProcess.IPBootConfig.Max_ExposureTime.Value   '2012/11/09 Rick add
        Me.NumericUpDown_ExposureTime.Maximum = Me.m_Max_ExposureTime  '2013/01/24 Rick add
        Me.TrackBar_ExposureTime.Maximum = Me.m_Max_ExposureTime  '2013/01/24 Rick add

        Me.m_MasterSlaveMode_Enable = Me.m_IPBootConfig.MasterSlaveMode_Enable.Value  '2014/12/04 Rick add
        Me.m_Master_ID = 1
        Me.m_Slave_ID = 2

        '--- �إ߳s�u ---
        If  Me.ConnectToIP = False Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Check Digitizer  ==> Request_Command = "CHECK_DIGITIZER" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CHECK_DIGITIZER"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                If SubSystemResult.Responses(0).Param1.ToUpper = "TRUE" Then
                    Me.m_Have_MDigitizer = True
                Else
                    Me.m_Have_MDigitizer = False
                End If
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Check Digitizer Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.SetMainForm]Check Digitizer Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Get All Exposure Time   ==> Request_Command = "GET_ALL_EXPOSURE_TIME" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "GET_ALL_EXPOSURE_TIME"
            TimeOut = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True

                strs = SubSystemResult.Responses(0).Param1.Split(",")

                count1 = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
                count2 = Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value

                For i = 0 To strs.Length - 1 Step 2
                    If (strs(i) <> "") Then
                        '[Mura]
                        For j = 0 To count1 - 1
                            If Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(j).PatternName.Value = strs(i) Then
                                If Val(strs(j + 1)) >= Me.m_Max_ExposureTime Then
                                    strs(j + 1) = Me.m_Max_ExposureTime
                                End If
                                Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(j).ExposureTime.Value = Val(strs(i + 1))
                            End If
                        Next

                        '[Func]
                        For k = 0 To count2 - 1
                            If Me.m_FuncProcess.FuncPatternRecipeArray.Item(k).PatternName.Value = strs(i) Then
                                If Val(strs(k + 1)) >= Me.m_Max_ExposureTime Then
                                    strs(k + 1) = Me.m_Max_ExposureTime
                                End If
                                Me.m_FuncProcess.FuncPatternRecipeArray.Item(k).ExposureTime.Value = Val(strs(i + 1))
                            End If
                        Next
                    End If
                Next
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get All Exposure Time  Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.SetMainForm]Get All Exposure Time  Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Try
            '--- ������ɽվ�ø�� ---
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Form.Panel_AxMDisplay.Width, Me.m_Form.Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)
            Me.m_Pen = New Pen(Color.White)
            Me.m_Form.PaintStop = True

            If Me.m_IPBootConfig.MuraUI.Value AndAlso Me.m_IPBootConfig.FuncUI.Value Then
                If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                    image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                Else
                    image = Me.m_FuncProcess.Img_Original_NonPage
                End If
            ElseIf Me.m_IPBootConfig.FuncUI.Value And Not Me.m_IPBootConfig.MuraUI.Value Then
                image = Me.m_FuncProcess.Img_Original_NonPage
            ElseIf Me.m_IPBootConfig.MuraUI.Value And Not Me.m_IPBootConfig.FuncUI.Value Then
                image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
            End If

            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            Else
                Me.GroupBox_Mode.Enabled = False
            End If

            Me.m_Form.ImageZoomAll()
            Me.UpdateUserLevel()

            If Not Me.m_IPBootConfig.MuraUI.Value Then Me.RadioButton_Mura.Enabled = False
            If Me.m_Have_MDigitizer Then
                Me.GroupBox_Grab.Enabled = True
            Else
                Me.GroupBox_Grab.Enabled = False
            End If

            Me.m_ContinueGrab = False
            Me.m_Grab_OK = False
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Dialog_ADJMean_Load ---"
    Private Sub Dialog_ADJMean_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Me.RadioButton_Auto.Checked = True
        Me.Button_MannualMean.Enabled = False

        Try
            Me.m_Initial_Finished = False

            '--- Pattern List ---  
            Me.ComboBox_PatnList.Items.Clear()

            '--- Color Band List ---
            Me.ComboBox_ColorBand.Items.Clear()
            If Me.m_IPBootConfig.Digitizer_Type.Value = DigitizerType.Color Then
                Me.ComboBox_ColorBand.Items.Add("L")
                Me.ComboBox_ColorBand.Items.Add("R")
                Me.ComboBox_ColorBand.Items.Add("G")
                Me.ComboBox_ColorBand.Items.Add("B")
                Me.ComboBox_ColorBand.Items.Add("raw")
                Me.ComboBox_ColorBand.ForeColor = Color.Red
            Else
                Me.ComboBox_ColorBand.Items.Add("L")
            End If

            If Me.m_IPBootConfig.FuncUI.Value And Not Me.m_IPBootConfig.MuraUI.Value Then
                Me.RadioButton_Mura.Enabled = False
                Me.RadioButton_Func.Checked = True
            ElseIf Not Me.m_IPBootConfig.FuncUI.Value And Me.m_IPBootConfig.MuraUI.Value Then
                Me.RadioButton_Func.Checked = False
                Me.RadioButton_Mura.Checked = True
                Me.m_Form.SetPatternIndexInfo(Me.ComboBox_PatnList.SelectedIndex + 1)  '�q[1]�}�l
            ElseIf Me.m_IPBootConfig.FuncUI.Value And Me.m_IPBootConfig.MuraUI.Value Then
                Me.RadioButton_Func.Checked = True
                Me.m_Form.SetPatternIndexInfo(Me.ComboBox_PatnList.SelectedIndex + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value + 1)  '�q[1]�}�l
            End If

            Me.SetButton_Grab(False)

            If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                Me.GroupBox_Mode.Enabled = True
            Else
                Me.GroupBox_Mode.Enabled = False
            End If

            Me.GroupBox_ExposureTime.Enabled = False
            If Not Me.m_Have_MDigitizer Then
                Button_Continue.Enabled = False
            End If

            '--- Color Camera ---
            If Me.m_IPBootConfig.Digitizer_Type.Value = DigitizerType.Color Then
                Me.ComboBox_ColorBand.Text = "L"
            End If

            Me.m_Form.ImageUpdate()
            Me.Update()
            Me.m_Initial_Finished = True
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.FormLoad]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Dialog_ADJMean_Closing ---"
    Private Sub Dialog_ADJMean_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Me.m_ContinueGrab = False

        System.Threading.Thread.Sleep(GetExposureTimeInfo() / 1000)
        Me.m_Form.PaintStop = True
        Me.WaitGrabReady()

        '--- ���� RunCommand thread --- 
        Me.m_Thread1_RunCommand = Nothing
        Me.Dispose()
    End Sub
#End Region

#Region "<--- Property --->"
    Public Property ContinueGrab() As Boolean
        Get
            Return Me.m_ContinueGrab
        End Get
        Set(ByVal Value As Boolean)
            Me.m_ContinueGrab = Value
        End Set
    End Property
#End Region

#Region "--- ��k�禡 ---"

#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- ConnectToSelectedIP ---"
    Public Function ConnectToSelectedIP(ByVal CCD As Integer)
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- �إ� IP �s�u ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = CCD
        ip.GrabNo = Me.m_MainProcess.IPNetworkConfig.Total_IP & "_" & CCD
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, Me.m_IPConnectMsg)
        If Not Me.m_IsIPConnected Or Me.m_IPConnectMsg <> "" Then
            MsgBox("IP�s�u���� !( " & Me.m_IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- UpdateUserLevel ---"
    Public Sub UpdateUserLevel()
        Select Case Me.m_MainProcess.UserLevel
            Case 0 'OP
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
            Case 1 'PM
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
            Case 2 'ENG
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
            Case 3 'ALL
                Me.GroupBox_ImageSource.Enabled = True
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
        End Select
    End Sub
#End Region

#Region "--- UpdateExposureTime ---"
    Public Sub UpdateExposureTime()
        Dim ExposureTime As Long

        If Me.m_Have_MDigitizer Then

            '[AreaGrabber]
            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value Then
                ExposureTime = Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex).ExposureTime.Value
            Else
                ExposureTime = Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex - Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value).ExposureTime.Value
            End If

            '--- �n���ɶ��̤p�ݨD 16000 ---
            'If ExposureTime < 16000 Then ExposureTime = 16000

            Me.TrackBar_ExposureTime.Value = ExposureTime
            Me.NumericUpDown_ExposureTime.Value = ExposureTime

        End If
    End Sub
#End Region

#Region "--- Setting ---"
    Public Sub Setting()
        Dim i As Integer

        If Me.RadioButton_Mura.Checked = True Then
            i = Me.m_MainProcess.MuraPatternRecipeArrayOrder.IndexOf(Me.m_MuraProcess.CurrentMuraPatternRecipe)
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).AutoExposure_Kp.Value = CInt(Me.TextBox_Kp.Text)
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).AutoExposure_TargetMean.Value = CInt(Me.TextBox_MeanTarget.Text)
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).AutoExposure_SmallErrorRange.Value = CInt(Me.TextBox_ErrorRange.Text)

        ElseIf Me.RadioButton_Func.Checked = True Then
            i = Me.m_MainProcess.FuncPatternRecipeArrayOrder.IndexOf(Me.m_FuncProcess.CurrentFuncPatternRecipe)
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).AutoExposure_Kp.Value = CInt(Me.TextBox_Kp.Text)
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).AutoExposure_TargetMean.Value = CInt(Me.TextBox_MeanTarget.Text)
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).AutoExposure_SmallErrorRange.Value = CInt(Me.TextBox_ErrorRange.Text)

        End If

    End Sub
#End Region

#Region "--- UpdateGrabImage ---"
    Public Sub UpdateGrabImage()
        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim FocusValue As Integer
        Dim strs() As String
        Dim strPath_Exists As Boolean
        Dim ColorBand As String = Me.GetColorBandInfo  'Image Band (R\G\B\L --> Color�۾� �G�ť� --> Mono�۾�)

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH
                strPath = strPath.Replace("\\", "\")
                'Me.RepairPath_2(strPath)
                If System.IO.File.Exists(strPath) Then
                    Directory.CreateDirectory(strPath)
                End If
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
                If System.IO.File.Exists(strPath) Then
                    Directory.CreateDirectory(strPath)
                End If
            End If


            '--- Disable ScrollBar ---
            'Me.ScrollBar_Enable(False)

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)

            Me.m_Grab_OK = False

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                If ColorBand = "raw" Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.raw"
                Else
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                End If
                strPath = strPath.Replace("\\", "\")
            Else
                If ColorBand = "raw" Then
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.raw"
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                End If
                Me.RepairPath_2(strPath)
            End If


            Do
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------

                System.Threading.Thread.Sleep(100)

                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GRAB_ONESHOT"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ColorBand, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.UpdateGrabImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    If Response_OK Then
                        '--- Update Processed Image ---
                        Grab_Success = Grab_Success + 1
                        If ColorBand = "raw" Then
                            Image = Me.m_MainProcess.Img_16U_GrabColor_1
                        Else
                            Image = Me.m_MainProcess.Img_16U_Grab_1
                        End If

                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        strPath_Exists = System.IO.File.Exists(strPath)

                        If strPath_Exists Then
                            If ColorBand = "raw" Then
                                '--- Color Image ---
                                If Me.m_MainProcess.Img_16U_GrabColor_1 <> M_NULL Then
                                    If MbufInquire(Me.m_MainProcess.Img_16U_GrabColor_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_GrabColor_1, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MainProcess.Img_16U_GrabColor_1)
                                        Me.m_MainProcess.Img_16U_GrabColor_1 = M_NULL
                                        Me.m_MainProcess.Img_16U_GrabColor_1 = MbufAllocColor(Me.m_MainProcess.System_Host, 3, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MainProcess.Img_16U_GrabColor_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MainProcess.Img_16U_GrabColor_1)
                                Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                                '--- Show Image ---
                                If Me.m_MainProcess.Img_16U_GrabColor_1 = M_NULL Then
                                    MdispSelect(Me.m_Form.AxMDisplay, M_NULL)
                                Else
                                    If Me.m_MainProcess.Img_16U_GrabColor_1 <> M_NULL Then
                                        MdispSelectWindow(Me.m_Form.AxMDisplay, Me.m_MainProcess.Img_16U_GrabColor_1, Me.m_Form.GetAxMDisplay_HandleInfo())  '2013/01/24 Rick modify
                                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                                    Else
                                        MdispSelect(Me.m_Form.AxMDisplay, M_NULL)
                                    End If
                                End If
                                MdispPan(Me.m_Form.AxMDisplay, 0, 0)
                                MdispPan(Me.m_Form.AxMDisplay, Me.m_Form.HScrollBar.Value, Me.m_Form.VScrollBar.Value)
                            Else
                                '--- Gray Image ---
                                If Image <> M_NULL Then
                                    If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Image)
                                        Image = M_NULL
                                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Image)

                                Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                                Me.m_Form.ImageUpdate()
                            End If

                        End If
                    End If

                    If GetCalculateFocusValueEnableInfo() Then
                        '----------------------------------------------------------------------------------------------
                        ' Get Gray Mean  ==> Request_Command = "GET_FOCUSVALUE" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            SyncLock Me.m_MainProcess.IP_Dispatcher1
                                '--- Prepare Command ---
                                Request_Command = "GET_FOCUSVALUE"
                                TimeOut = 500000 '500 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                            End SyncLock

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                'If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                                If SubSystemResult.Responses(0).Param2 <> "" Then

                                    strs = SubSystemResult.Responses(0).Param2.Split(",")
                                    FocusValue = strs(1)
                                    SetLabel_FocusValueInfo("Focus Value�G" & FocusValue)
                                End If
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Focus Value Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_ADJMean.get_FocusValue]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_FocusValue]Get Focus Value Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_ADJMean.get_FocusValue]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End Try

                    End If

                    'Me.m_Grab_OK = True
                Catch ex As Exception
                    Response_OK = False
                    Me.m_ContinueGrab = False
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Loop While (Me.m_ContinueGrab And Me.Button_Continue.Enabled = False)

            Me.m_Grab_OK = True
            Me.ScrollBar_Enable(True)
            Me.ZoomEnable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            Me.ScrollBar_Enable(True)
            Me.SetButton_Grab(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_ADJmean.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_ADJmean.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- WaitGrabReady ---"
    Private Sub WaitGrabReady()
        Dim i As Integer

        i = (Me.GetExposureTimeInfo() / 100000) + 1  '2013/01/25 Rick add
        If i < 10 Then i = 10

        If Not Me.m_ContinueGrab Then
            While (Not Me.m_Grab_OK And i >= 0)
                System.Threading.Thread.Sleep(200)
                Application.DoEvents()
                i = i - 1
            End While

            Me.m_Grab_OK = True
        End If
    End Sub
#End Region

#Region "--- ScrollBar_Enable ---"
    Private Sub ScrollBar_Enable(ByVal En As Boolean)
        Me.m_Form.HScrollBar_Enable(En)
        Me.m_Form.VScrollBar_Enable(En)
    End Sub
#End Region

#Region "--- PatternSelect_Enable ---"
    Private Sub PatternSelect_Enable(ByVal En As Boolean)
        Me.SetComboBox_PatnList_EnableInfo(En)
        Me.SetRadioButton_Mura_EnableInfo(En)
        Me.SetRadioButton_Func_EnableInfo(En)
    End Sub
#End Region

#Region "--- ZommEnable ---"
    Private Sub ZoomEnable(ByVal En As Boolean)
        Me.m_Form.SetButton_ZoomIn(En)
        Me.m_Form.SetButton_ZoomOut(En)
        Me.m_Form.SetButton_ZoomO(En)
        Me.m_Form.SetButton_ZoomAll(En)
    End Sub
#End Region

#Region "--- PitchCheck_Boundary ---"
    Private Sub PitchCheck_Boundary()
        '--------------2010/10/12 grant  add for BoundaryAuto------------------------
        Dim StartX As Integer = 0
        Dim StartY As Integer = 0
        Dim EndX As Integer = 0
        Dim EndY As Integer = 0

        StartX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        EndX = Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX
        StartY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        EndY = Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY

        '2010/12/1 Lena Modify
        Try

            pb.LeftX = StartX
            pb.RightX = EndX
            pb.TopY = StartY
            pb.BottomY = EndY

            ReDraw(pb)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
#End Region

#Region "--- ReDraw ---"
    Private Sub ReDraw(ByVal Boundary As ClsParameterBoundary)
        'OLED
        Try

            Dim image As MIL_ID
            image = MIL.MdispInquire(Me.m_Form.AxMDisplay, MIL.M_SELECTED, MIL.M_NULL)
            If image <> MIL.M_NULL Then
                Me.ReDrawPage0(image, Boundary)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try

    End Sub
#End Region

#Region "--- ReDrawPage0 ---"
    Private Sub ReDrawPage0(ByVal image As MIL_ID, ByVal Boundary As ClsParameterBoundary)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim SizeX, SizeY As Integer

        Try
            Dim Factor As Double
            MIL.MdispInquire(Me.m_Form.AxMDisplay, MIL.M_ZOOM_FACTOR_Y, Factor)

            rect = New Rectangle
            Me.m_Form.PaintStop = True
            Me.m_Form.Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
            If Me.CheckBox_ShowBoundary.Checked Then
                'image = MIL.MdispInquire(Me.m_Form.AxMDisplay, MIL.M_SELECTED, MIL.M_NULL)
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                s = Math.Ceiling(Factor)
                If Me.CheckBox_ShowBoundary.Checked Then
                    Me.m_SolidBrush.Color = Color.Red
                    v = (Boundary.LeftX - Me.m_Form.HScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Width Then
                        h = SizeY * Factor  ' Me.m_Form.ZoomY
                        If h >= Me.m_BitMap.Height Then
                            h = Me.m_BitMap.Height - 1
                        End If
                        rect.X = v
                        rect.Y = 1
                        rect.Width = s
                        rect.Height = h
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                    v = (Boundary.RightX - Me.m_Form.HScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Width Then
                        h = SizeY * Factor
                        If h >= Me.m_BitMap.Height Then
                            h = Me.m_BitMap.Height - 1
                        End If
                        rect.X = v
                        rect.Y = 1
                        rect.Width = s
                        rect.Height = h
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                    v = (Boundary.TopY - Me.m_Form.VScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Height Then
                        h = SizeX * Factor
                        If h >= Me.m_BitMap.Width Then
                            h = Me.m_BitMap.Width - 1
                        End If
                        rect.X = 1
                        rect.Y = v
                        rect.Width = h
                        rect.Height = s
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                    v = (Boundary.BottomY - Me.m_Form.VScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Height Then
                        h = SizeX * Factor
                        If h >= Me.m_BitMap.Width Then
                            h = Me.m_BitMap.Width - 1
                        End If
                        rect.X = 1
                        rect.Y = v
                        rect.Width = h
                        rect.Height = s
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                End If
            End If

            'Me.m_BitMap.Save("D:\\Temp.bmp")

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_Boundary.ReDrawPage0]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Compare ---"

#Region "--- CompareFunc ---"
    Private Sub CompareFunc(ByVal fprOld As ClsFuncPatternRecipe, ByVal fprNew As ClsFuncPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[Exposure Time Change]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        If fprOld.ExposureTime.Value <> fprNew.ExposureTime.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< ExposureTime >: " & fprOld.ExposureTime.Value & " --> " & fprNew.ExposureTime.Value)
            fprOld.ExposureTime = fprNew.ExposureTime
        End If
        If fprOld.AutoExposure_Kp.Value <> fprNew.AutoExposure_Kp.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< AutoExposure_Kp >: " & fprOld.AutoExposure_Kp.Value & " --> " & fprNew.AutoExposure_Kp.Value)
            fprOld.AutoExposure_Kp.Value = fprNew.AutoExposure_Kp.Value
        End If
        If fprOld.AutoExposure_SmallErrorRange.Value <> fprNew.AutoExposure_SmallErrorRange.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< AutoExposure_SmallErrorRange >: " & fprOld.AutoExposure_SmallErrorRange.Value & " --> " & fprNew.AutoExposure_SmallErrorRange.Value)
            fprOld.AutoExposure_SmallErrorRange = fprNew.AutoExposure_SmallErrorRange
        End If
        If fprOld.AutoExposure_TargetMean.Value <> fprNew.AutoExposure_TargetMean.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< AutoExposure_TargetMean >: " & fprOld.AutoExposure_TargetMean.Value & " --> " & fprNew.AutoExposure_TargetMean.Value)
            fprOld.AutoExposure_TargetMean = fprNew.AutoExposure_TargetMean
        End If
    End Sub
#End Region

#Region "--- CompareMura ---"
    Private Sub CompareMura(ByVal mprOld As ClsMuraPatternRecipe, ByVal mprNew As ClsMuraPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[Exposure Time Change]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        If mprOld.ExposureTime.Value <> mprNew.ExposureTime.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< ExposureTime >: " & mprOld.ExposureTime.Value & " --> " & mprNew.ExposureTime.Value)
            mprOld.ExposureTime = mprNew.ExposureTime
        End If
        If mprOld.AutoExposure_Kp.Value <> mprNew.AutoExposure_Kp.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< AutoExposure_Kp >: " & mprOld.AutoExposure_Kp.Value & " --> " & mprNew.AutoExposure_Kp.Value)
            mprOld.AutoExposure_Kp = mprNew.AutoExposure_Kp
        End If
        If mprOld.AutoExposure_SmallErrorRange.Value <> mprNew.AutoExposure_SmallErrorRange.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< AutoExposure_SmallErrorRange >: " & mprOld.AutoExposure_SmallErrorRange.Value & " --> " & mprNew.AutoExposure_SmallErrorRange.Value)
            mprOld.AutoExposure_SmallErrorRange.Value = mprNew.AutoExposure_SmallErrorRange.Value
        End If
        If mprOld.AutoExposure_TargetMean.Value <> mprNew.AutoExposure_TargetMean.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< AutoExposure_SmallErrorRange >: " & mprOld.AutoExposure_TargetMean.Value & " --> " & mprNew.AutoExposure_TargetMean.Value)
            mprOld.AutoExposure_TargetMean.Value = mprNew.AutoExposure_TargetMean.Value
        End If
    End Sub
#End Region

#End Region

#Region "--- AutoExp_Apply ---"
    Private Sub AutoExp_Apply()
        If Me.Label_AutoExposure_Time.Text = "" Then Exit Sub
        'If CInt(Me.Label_AutoExposure.Text) < 16000 Then Me.Label_AutoExposure.Text = 16000
        If Me.Label_AutoExposure.Text <> "" Then Me.NumericUpDown_ExposureTime.Value = CInt(Me.Label_AutoExposure.Text)
        Me.GroupBox_ExposureTime.Enabled = True     '2010/12/05 Rick add
    End Sub
#End Region

#End Region

#Region "--- ��k�禡 (MasterSlave Mode) ---"

#Region "--- MS_ConnectToIP ---"
    Public Function MS_ConnectToIP()
        Dim Master_GrabNo As String = ""
        '--- �_�u�M�� ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        '--- �إ� Master IP �s�u ---
        ip = New ClsIPInfo
        ip.CCDNo = 1
        Me.m_Form.Change_GrabNo(ip.CCDNo, Master_GrabNo)
        ip.GrabNo = Master_GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)

        '--- �إ� Slave IP �s�u ---
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)

        For Each r As ClsIPInfo In Me.m_MainProcess.IPInfo
            Me.m_MainProcess.Init_IP(r.CCDNo, Me.m_MainProcess.IPNetworkConfig.Total_IP)
        Next

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region

#Region "--- MS_UpdateGrabImage ---"
    Public Sub MS_UpdateGrabImage()
        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim FocusValue As Integer
        Dim strs() As String
        Dim strPath_Exists As Boolean
        Dim ColorBand As String = Me.GetColorBandInfo  'Image Band (R\G\B\L --> Color�۾� �G�ť� --> Mono�۾�)

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
            End If

            If System.IO.File.Exists(strPath) Then
                Directory.CreateDirectory(strPath)
            End If

            '--- Disable ScrollBar ---
            'Me.ScrollBar_Enable(False)

            '--- �إ߳s�u ---
            If Not Me.MS_ConnectToIP Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)

            Me.m_Grab_OK = False

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                strPath = strPath.Replace("\\", "\")
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                Me.RepairPath_2(strPath)
            End If

            Do
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GRAB_ONESHOT"
                        TimeOut = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Master_ID, Request_Command, ColorBand, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.UpdateGrabImage]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    If Response_OK Then
                        '--- Update Processed Image ---
                        Grab_Success = Grab_Success + 1
                        Image = Me.m_MainProcess.Img_16U_Grab_1

                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        strPath_Exists = System.IO.File.Exists(strPath)

                        If strPath_Exists Then
                            If Image <> M_NULL Then
                                If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image)
                                    Image = M_NULL
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Image)

                            Me.SetButton_Grab(Not Me.Button_Continue.Enabled)

                            Me.m_Form.ImageUpdate()
                            'Me.ZoomEnable(False)
                        End If
                    End If

                    If GetCalculateFocusValueEnableInfo() Then
                        '----------------------------------------------------------------------------------------------
                        ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "LOAD_IMAGE"
                            TimeOut = 200000 '200 secs

                            '--- Initial ---  
                            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                                Me.RepairPath_2(strPath)
                            End If


                            Me.m_ManualPath = Me.m_Form.OpenFileDialog.FileName
                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Slave_ID, Request_Command, "", "", strPath, , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.Button_Load.Enabled = True
                                If Me.m_Have_MDigitizer Then
                                    Me.GroupBox_ExposureTime.Enabled = True
                                    Me.GroupBox_Mode.Enabled = True
                                End If
                                Exit Sub
                            End If
                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Grab]Load Image Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Throw New Exception(ex.Message)
                        End Try

                        '----------------------------------------------------------------------------------------------
                        ' Get Gray Mean  ==> Request_Command = "GET_FOCUSVALUE" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            SyncLock Me.m_MainProcess.IP_Dispatcher1
                                '--- Prepare Command ---
                                Request_Command = "GET_FOCUSVALUE"
                                TimeOut = 500000 '500 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Slave_ID, Request_Command, , , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)
                            End SyncLock

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                'If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                                If SubSystemResult.Responses(0).Param2 <> "" Then

                                    strs = SubSystemResult.Responses(0).Param2.Split(",")
                                    FocusValue = strs(1)
                                    SetLabel_FocusValueInfo("Focus Value�G" & FocusValue)
                                End If
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Focus Value Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_ADJMean.get_FocusValue]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_FocusValue]Get Focus Value Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_ADJMean.get_FocusValue]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End Try
                    End If

                    'Me.m_Grab_OK = True
                Catch ex As Exception
                    Response_OK = False
                    Me.m_ContinueGrab = False
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Loop While (Me.m_ContinueGrab And Me.Button_Continue.Enabled = False)

            Me.m_Grab_OK = True
            Me.ScrollBar_Enable(True)
            Me.ZoomEnable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            Me.ScrollBar_Enable(True)
            Me.SetButton_Grab(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_ADJmean.MS_UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_ADJmean.MS_UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#End Region

#Region "--- RadioButton Event ---"

#Region "--- RadioButton_Manual_CheckedChanged ---"
    Private Sub RadioButton_Manual_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Manual.CheckedChanged
        If Me.RadioButton_Manual.Checked Then
            Me.Button_MannualMean.Enabled = True
            Me.Button_AutoExposure.Enabled = False
            Me.TextBox_MeanTarget.Enabled = False
            Me.TextBox_Kp.Enabled = False
        End If
    End Sub
#End Region

#Region "--- RadioButton_Auto_CheckedChanged ---"
    Private Sub RadioButton_Auto_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Auto.CheckedChanged
        If Me.RadioButton_Auto.Checked Then
            Me.Button_MannualMean.Enabled = False
            Me.Button_AutoExposure.Enabled = True
            Me.TextBox_MeanTarget.Enabled = True
            Me.TextBox_Kp.Enabled = True
        End If
    End Sub
#End Region

#Region "--- RadioButton_Func_CheckedChanged ---"
    Private Sub RadioButton_Func_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Func.CheckedChanged
        Dim i As Integer
        Dim ExposureTime As Integer
        Dim PatternName As String

        ''--- ����s����� ---
        'Me.WaitGrabReady()

        If Me.RadioButton_Func.Checked = True Then

            '[AreaGrabber]
            Me.ComboBox_PatnList.Items.Clear()
            For i = 0 To Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value - 1
                Me.ComboBox_PatnList.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next

            '[AreaGrabber] Set Recipe ---  
            Me.m_MainProcess.SetRecipe(Me.m_FuncProcess.FuncPatternRecipeArray.Item(0).PatternName.Value, Me.m_MainProcess.ErrorCode)
            Me.ComboBox_PatnList.SelectedIndex = 0

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.ComboBox_PatnList.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    'MessageBox.Show("[Dialog_ADJMean.RadioButton_Func_CheckedChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.RadioButton_Func_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
                ''MessageBox.Show("[Dialog_ADJMean.RadioButton_Func_CheckedChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            If Me.RadioButton_Func.Checked = True Then
                ExposureTime = Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).ExposureTime.Value
                Me.TextBox_Kp.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_Kp.Value)
                Me.TextBox_MeanTarget.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_TargetMean.Value)
                Me.TextBox_ErrorRange.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_SmallErrorRange.Value)

                '--- ��s�n���ɶ� ---
                '--- �������̤p�n���ɶ� 16000 --- 
                'If ExposureTime < 16000 Then
                'ExposureTime = 16000
                Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).ExposureTime.Value = ExposureTime
                'End If

                If Me.m_Have_MDigitizer Then
                    Me.TrackBar_ExposureTime.Value = ExposureTime
                    Me.NumericUpDown_ExposureTime.Value = ExposureTime
                End If
            End If

        End If
    End Sub
#End Region

#Region "--- RadioButton_Mura_CheckedChanged ---"
    Private Sub RadioButton_Mura_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton_Mura.CheckedChanged
        Dim i As Integer
        Dim ExposureTime As Integer
        Dim PatternName As String

        If Me.RadioButton_Mura.Checked = True Then

            ''--- ����s����� ---
            'Me.WaitGrabReady()

            '[AreaGrabber]
            Me.ComboBox_PatnList.Items.Clear()
            For i = 0 To Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1
                Me.ComboBox_PatnList.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next

            '[AreaGrabber] Set Recipe ---   
            Me.m_MainProcess.SetRecipe(Me.m_MuraProcess.MuraPatternRecipeArray.Item(0).PatternName.Value, Me.m_MainProcess.ErrorCode)
            Me.ComboBox_PatnList.SelectedIndex = 0

            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.ComboBox_PatnList.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    'MessageBox.Show("[Dialog_ADJMean.RadioButton_Mura_CheckedChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.RadioButton_Mura_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
                'MessageBox.Show("[Dialog_ADJMean.RadioButton_Mura_CheckedChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            If Me.RadioButton_Func.Checked = True Then
                ExposureTime = Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).ExposureTime.Value
                Me.TextBox_Kp.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_Kp.Value)
                Me.TextBox_MeanTarget.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_TargetMean.Value)
                Me.TextBox_ErrorRange.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_SmallErrorRange.Value)


                '--- ��s�n���ɶ� ---
                '--- �������̤p�n���ɶ� 16000 --- 
                'If ExposureTime < 16000 Then
                'ExposureTime = 16000
                Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).ExposureTime.Value = ExposureTime
                'End If
                If Me.m_Have_MDigitizer Then
                    Me.TrackBar_ExposureTime.Value = ExposureTime
                    Me.NumericUpDown_ExposureTime.Value = ExposureTime
                End If
            End If

        End If
    End Sub
#End Region

#End Region

#Region "--- Button Event ---"

#Region "--- Button_Continue ---"
    Private Sub Button_Continue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Continue.Click
        If Me.m_IPBootConfig.Digitizer_Type.Value = DigitizerType.Color And Me.ComboBox_ColorBand.Text = "" Then
            MsgBox("�Х���� Color Band !", MsgBoxStyle.Critical, "[AreaGrabber]")
            Exit Sub
        End If
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Me.m_Ever_ContinueGrab = True
        Me.Button_Continue.Enabled = False
        Me.Button_Load.Enabled = False
        Me.PatternSelect_Enable(False)

        ''--- Stop Grab First ---
        'Me.WaitGrabReady()

        ''---Initial---
        Me.m_ManualLoad = False

        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
            image = Me.m_MainProcess.Img_16U_Grab_1
            If image <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                Type = MbufInquire(image, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(image, imageBuffer)

                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                MbufControl(image, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                Me.m_Form.ResetScrollBar()
            End If
        Else
            Me.m_Form.CurrentIndex0 = 0
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 0
        End If

        Me.m_Form.ImageZoomAll()
        'Me.ZoomEnable(False)
        Me.UpdateExposureTime()

        If Me.ComboBox_PatnList.Text = "" Then
            Me.Button_Continue.Enabled = True
            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_Save.Enabled = True
            MsgBox("�п��Pattern")
        Else
            Me.GroupBox_Mode.Enabled = False
            Me.GroupBox_ExposureTime.Enabled = True
            Me.TrackBar_ExposureTime.Enabled = False
            Me.NumericUpDown_ExposureTime.Enabled = False
            Me.Button_Save.Enabled = False
        End If


        'Thread --- Update Grab Image
        '---�Ұ� Run Command Thread ---

        Me.m_ContinueGrab = True
        Try
            If Not Me.m_Thread1_RunCommand Is Nothing Then
                Me.m_Thread1_RunCommand = Nothing
            End If

            If Not (Not Me.m_Thread1_RunCommand Is Nothing) Then
                Try
                    'If Not Me.m_MasterSlaveMode_Enable Then ' ��~~�L~~~~~~~~~~
                    If True Then
                        Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.UpdateGrabImage)
                        Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        Me.m_Thread1_RunCommand.Start()
                    Else
                        '--- MasterSlave Mode ---
                        Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.MS_UpdateGrabImage)
                        Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        Me.m_Thread1_RunCommand.Start()
                    End If

                Catch ex As Exception
                    Throw New Exception(ex.Message)
                End Try
            End If
        Catch ex As Exception
            Me.ZoomEnable(True)
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_Save.Enabled = True
            Me.m_ContinueGrab = False
            Me.PatternSelect_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Continue](" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- Button_Grab ---"
    Private Sub Button_Grab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Grab.Click

        System.Threading.Thread.Sleep(GetExposureTimeInfo() / 1000)

        If Me.m_IPBootConfig.IsPixelShiftCCD.Value Then
            If Me.m_IPBootConfig.PixelShiftStage.Value = "1" Then
                Dim DelayTime As Integer = (GetExposureTimeInfo() * 4) / 1000 + 400
                System.Threading.Thread.Sleep(DelayTime)
            ElseIf Me.m_IPBootConfig.PixelShiftStage.Value = "2" Then
                Dim DelayTime As Integer = (GetExposureTimeInfo() * 9) / 1000 + 900
                System.Threading.Thread.Sleep(DelayTime)
            End If
        End If

        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            Me.m_ContinueGrab = False  '2013/01/25 Rick add
            Me.SetButton_Grab(False)
            Me.Button_Save.Enabled = False
            Me.Button_AutoExposure.Enabled = False
            '--- ����s����� ---
            Me.WaitGrabReady()

            '--- Finish Grab Image Thread ---  '2013/01/25 Rick add
            If Not Me.m_Thread1_RunCommand Is Nothing Then
                Me.m_Thread1_RunCommand = Nothing
            End If

            If ComboBox_ColorBand.Text = "raw" Then Exit Sub

            '--- �إ߳s�u ---
            'If Not Me.m_MasterSlaveMode_Enable Then ' ��~~�L~~~~~~~~~~
            If True Then
                If Not Me.ConnectToIP Then
                    Me.Button_Continue.Enabled = True
                    Me.Button_Load.Enabled = True
                    Me.SetButton_Grab(False)
                    Exit Sub
                End If
            Else '--- M\S Mode ---
                If Not Me.MS_ConnectToIP Then
                    Me.Button_Continue.Enabled = True
                    Me.Button_Load.Enabled = True
                    Me.SetButton_Grab(False)
                    Exit Sub
                End If
            End If

            Try
                'If Not Me.m_MasterSlaveMode_Enable Then ' ��~~�L~~~~~~~~~~
                If True Then
                    '----------------------------------------------------------------------------------------------
                    ' IP LOAD GRAB IMAGE  ==> Request_Command = "LOAD_GRABIMAGE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    '--- Prepare Command ---
                    Request_Command = "LOAD_GRABIMAGE"
                    TimeOut = 10000 '100 secs
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Grab Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        'MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Continue.Enabled = True
                        Me.Button_Load.Enabled = True
                        Me.SetButton_Grab(False)
                        Me.GroupBox_Mode.Enabled = True
                        Exit Sub
                    End If

                Else  '--- M\S Mode ---
                    '----------------------------------------------------------------------------------------------
                    ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "LOAD_IMAGE"
                        TimeOut = 200000 '200 secs

                        '--- Initial ---  
                        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        Me.m_ManualPath = Me.m_Form.OpenFileDialog.FileName
                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Slave_ID, Request_Command, "", "", strPath, , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.Button_Load.Enabled = True
                            If Me.m_Have_MDigitizer Then
                                Me.GroupBox_ExposureTime.Enabled = True
                                Me.GroupBox_Mode.Enabled = True
                            End If
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Grab]Load Image Error ! (" & ex.Message & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Throw New Exception(ex.Message)
                    End Try
                End If


                If Response_OK Then
                    '[1] Update Img_16U_Grab_1
                    image = Me.m_MainProcess.Img_16U_Grab_1

                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                        Me.RepairPath_2(strPath)
                    End If



                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_FuncProcess.Img_Original_NonPage)
                        Me.m_Form.ImageUpdate()

                        '--- Display ---
                        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
                            If image <> M_NULL Then
                                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                                Type = MbufInquire(image, M_TYPE, M_NULL)

                                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                    MbufFree(imageBuffer)
                                    imageBuffer = M_NULL
                                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                End If
                                MbufCopy(image, imageBuffer)

                                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                                MbufControl(image, M_MODIFIED, M_DEFAULT)
                                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                Me.m_Form.ResetScrollBar()
                            End If
                        End If
                    End If


                    If Me.RadioButton_Mura.Checked Then
                        Try
                            '--- Prepare Command ---
                            Request_Command = "Transfer_Mura_Boundary"
                            TimeOut = 10000 '10 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                Exit Sub
                            End If
                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try

                        image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                        '[AreaGrabber] Load image2 --- (For Display)
                        '[1] image2 ---
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image2 <> M_NULL Then
                            If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image2)
                                image2 = M_NULL
                                image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(strPath, image2)
                    End If

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    If Me.RadioButton_Mura.Checked Then
                        Try
                            '--- Prepare Command ---
                            Request_Command = "RESIZE_ORIGINAL"
                            TimeOut = 500000 '500 secs
                            SaveImage = True

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                'MessageBox.Show("[Dialog_ADJMean.Button_Grab_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.Button_Continue.Enabled = True
                                Me.Button_Load.Enabled = True
                                Me.SetButton_Grab(False)
                                Exit Sub
                            End If

                            If SaveImage AndAlso Response_OK Then
                                '[1] Update Processed Image --- Resize �᪺�v���Y���Y�p�᪺Mura��l�v��
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                                Else
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                                End If

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If image <> M_NULL Then
                                        If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(image)
                                            image = M_NULL
                                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, image)
                                    'MbufCopy(image, Me.m_MainProcess.Img_Mapping_NonPage)

                                    If System.IO.File.Exists(strPath) = True Then
                                        System.IO.File.Delete(strPath)
                                    End If
                                End If
                            End If

                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try
                    End If
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            Else
                Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            End If

            'Me.m_Form.ImageZoomAll()

            Me.GroupBox_Mode.Enabled = True
            Me.GroupBox_ExposureTime.Enabled = True
            Me.TrackBar_ExposureTime.Enabled = True
            Me.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_Save.Enabled = True
            If Me.RadioButton_Auto.Checked Then
                Me.Button_AutoExposure.Enabled = True
            End If

            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.PatternSelect_Enable(True)

        Catch ex As Exception
            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.GroupBox_Mode.Enabled = False
            Me.TrackBar_ExposureTime.Enabled = False
            Me.NumericUpDown_ExposureTime.Enabled = False
            Me.m_ContinueGrab = False
            Me.PatternSelect_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_AutoManual.Button_Grab]Grab Image Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- Button_Load ---"
    Private Sub Button_Load_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Load.Click
        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim ResizeRatio As Integer

        '--- Initial ---  
        Me.m_ManualLoad = True
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.Button_Load.Enabled = False
        If Me.m_Have_MDigitizer Then
            Me.GroupBox_ExposureTime.Enabled = False
            Me.GroupBox_Mode.Enabled = False
        End If
        ''--- ����s����� ---
        'Me.WaitGrabReady()

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Me.Button_Load.Enabled = True
            If Me.m_Have_MDigitizer Then
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
            End If
            Exit Sub
        End If

        Try
            Me.m_Form.OpenFileDialog.InitialDirectory = Me.m_MainProcess.IMAGE_PATH
            Me.m_Form.OpenFileDialog.FileName = ""
            Me.m_Form.OpenFileDialog.ShowDialog()
            If Me.m_Form.OpenFileDialog.FileName <> "" Then

                If Me.m_IPBootConfig.FuncUI.Value Then
                    image = Me.m_FuncProcess.Img_Original_NonPage

                    '[AreaGrabber] Load Image --- (For Display)
                    '[1] image ---
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_X, SizeX)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_SIZE_Y, SizeY)
                    MbufDiskInquire(Me.m_Form.OpenFileDialog.FileName, M_TYPE, Type)
                    If image <> M_NULL Then
                        If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(image)
                            image = M_NULL
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, image)

                    '[2] Img_16U_Grab ---
                    If image <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_Grab_1, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.Img_16U_Grab_1)
                            Me.m_MainProcess.Img_16U_Grab_1 = M_NULL
                            Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.Img_16U_Grab_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If
                    MbufLoad(Me.m_Form.OpenFileDialog.FileName, Me.m_MainProcess.Img_16U_Grab_1)

                    If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
                        Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    End If

                    Me.m_Form.StatusBarStatus(Path.GetFileName(Me.m_Form.OpenFileDialog.FileName))
                    'If Me.m_Form.ComboBox_CCD.Text <> "" Then
                    '    iCheckLoadImage = InStr(1, Me.m_Form.OpenFileDialog.FileName, Me.m_Form.ComboBox_GrabNo.Text, CompareMethod.Text)
                    '    If Not (iCheckLoadImage > 0) Then
                    '        MsgBox("���ˬd�Ҷ}�Ҫ��v���ɮ׬O�_�ŦX�ثeIP No !( " & Me.m_Form.OpenFileDialog.FileName & " )", MsgBoxStyle.Exclamation, "[AreaGrabber]")
                    '    End If
                    'End If

                    If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 2 Then
                        If image <> M_NULL Then
                            imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                            SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                            Type = MbufInquire(image, M_TYPE, M_NULL)

                            If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                MbufFree(imageBuffer)
                                imageBuffer = M_NULL
                                imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                            End If
                            MbufCopy(image, imageBuffer)

                            MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                            MbufControl(image, M_MODIFIED, M_DEFAULT)
                            MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                            Me.m_Form.ResetScrollBar()
                        End If
                    Else
                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2
                    End If
                End If

                '----------------------------------------------------------------------------------------------
                ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "LOAD_IMAGE"
                    TimeOut = 200000 '200 secs

                    Me.m_ManualPath = Me.m_Form.OpenFileDialog.FileName
                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, "", "", Me.m_ManualPath, , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                        If SubSystemResult.Responses(0).Param1 = "1" Then
                            Me.m_Form.CheckBox_IsAligned.Checked = True
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX = CInt(SubSystemResult.Responses(0).Param2)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY = CInt(SubSystemResult.Responses(0).Param3)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX = CInt(SubSystemResult.Responses(0).Param4)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY = CInt(SubSystemResult.Responses(0).Param5)
                            strPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
                            RepairPath_2(strPath)
                            MILOperationLib.ClsFuncModelRecipe.WriteXML(Me.m_MainProcess.FuncProcess.FuncModelRecipe, strPath)
                            ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.LeftX / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.TopY / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.RightX = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.RightX / ResizeRatio)
                            Me.m_MuraProcess.MuraModelRecipe.Boundary.BottomY = (Me.m_MainProcess.FuncProcess.FuncModelRecipe.Boundary.BottomY / ResizeRatio)
                        Else
                            Me.m_Form.CheckBox_IsAligned.Checked = False
                        End If
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_Load]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Load.Enabled = True
                        If Me.m_Have_MDigitizer Then
                            Me.GroupBox_ExposureTime.Enabled = True
                            Me.GroupBox_Mode.Enabled = True
                        End If
                        Exit Sub
                    End If
                Catch ex As Exception
                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Load]Load Image Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_ADJMean.Button_Load]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Throw New Exception(ex.Message)
                End Try

                If Me.m_IPBootConfig.MuraUI.Value Then

                    '----------------------------------------------------------------------------------------------
                    ' Transfer Mura Boundary  ==> Request_Command = "Transfer_Mura_Boundary" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "Transfer_Mura_Boundary"
                        TimeOut = 10000 '10 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    '----------------------------------------------------------------------------------------------
                    ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "RESIZE_ORIGINAL"
                        TimeOut = 100000 '100 secs
                        SaveImage = True

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            Exit Sub
                        End If

                        If SaveImage AndAlso Response_OK Then
                            '[1] Update Processed Image ---
                            If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                            Else
                                image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                            End If

                            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                strPath = strPath.Replace("\\", "\")
                            Else
                                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                Me.RepairPath_2(strPath)
                            End If

                            If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                MbufDiskInquire(strPath, M_TYPE, Type)
                                If image <> M_NULL Then
                                    If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(image)
                                        image = M_NULL
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, image)
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage)
                                Else
                                    MbufCopy(image, Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage)
                                End If

                                'If System.IO.File.Exists(strPath) = True Then
                                '    System.IO.File.Delete(strPath)
                                'End If
                            End If

                            '--- Display Image ---  
                            If Me.m_Form.GetPatternIndexInfo < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                                If image <> M_NULL Then
                                    imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                    SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                                    Type = MbufInquire(image, M_TYPE, M_NULL)

                                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                        MbufFree(imageBuffer)
                                        imageBuffer = M_NULL
                                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                    End If
                                    MbufCopy(image, imageBuffer)

                                    MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                                    MbufControl(image, M_MODIFIED, M_DEFAULT)
                                    MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                    Me.m_Form.ResetScrollBar()
                                End If
                            End If
                        End If

                    Catch ex As Exception
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Load_Click]Mura Resize Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_Load_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Throw New Exception(ex.Message)
                    End Try
                End If

                '--- �� ROI ---
                Try
                    If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                        Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    Else
                        Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                    End If
                Catch ex As Exception
                    MsgBox("�Э��s����Align�A[Func�򥻳]�w]->[Alignment]", MsgBoxStyle.Critical, "[AreaGrabber]")
                End Try

                Me.Button_Load.Enabled = True
                If Me.m_Have_MDigitizer Then
                    Me.GroupBox_ExposureTime.Enabled = True
                    Me.GroupBox_Mode.Enabled = True
                End If

                Me.UpdateUserLevel()
                ' Me.m_Form.ImageUpdate()     'v2012.09.06
                Call Me.m_Form.ImageZoomAll()
                Me.Button_Save.Enabled = True
            End If

            Me.Button_Load.Enabled = True
        Catch ex As Exception
            Me.Button_Load.Enabled = True
            If Me.m_Have_MDigitizer Then
                Me.GroupBox_ExposureTime.Enabled = True
                Me.GroupBox_Mode.Enabled = True
            End If
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Load]" & ex.Message)
            MessageBox.Show("[Dialog_ADJMean.Button_Load_Click]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- Button Event ---"

#Region "--- Button_MannualMean ---"
    Private Sub Button_MannualMean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_MannualMean.Click
        Dim mean As Integer
        Dim Gray_max As Integer
        Dim str_log As String

        Me.Button_MannualMean.Enabled = False
        Label_ROI_Mean.Text = "ROI Mean�G"
        Label_ROI_Max.Text = "ROI Max�G"
        Try
            Me.get_GrayMean(mean, Gray_max)

            Label_ROI_Mean.Text = "ROI Mean�G" & mean
            Label_ROI_Max.Text = "ROI Max�G" & Gray_max

            str_log = NumericUpDown_ExposureTime.Value & vbTab & mean & vbTab & Gray_max
            Utils.WriteLog(Me.m_MainProcess.TEMP_PATH & "\" & Me.m_MainProcess.ProductName & "_C" & Me.m_MainProcess.GrabNo & "_ExposureMean.txt", str_log)

            Me.Button_MannualMean.Enabled = True
        Catch ex As Exception
            Me.Button_MannualMean.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_CaculateMean]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Button_Save ---"
    Private Sub Button_Save_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_Save.Click
        Dim str As String
        Dim dir As String
        Dim i As Integer
        Dim Parameter_Lists As String = ""

        Try
            '--- �إ߳s�u ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.Button_Save.Enabled = False   '2010/06/10 Rick add 
            Me.GroupBox_Mode.Enabled = False   '2010/06/13 Rick add 

            Me.Setting()   '2010/06/01 Rick add

            '----------------------------------------------------------------------------------------------
            ' Dialog_ADJMean Setting   ==> Request_Command = "DIALOG_ADJMEAN_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_ADJMEAN_SETTING"
                TimeOut = 100000 '100 secs

                Parameter_Lists = "ExposureTime," & Me.NumericUpDown_ExposureTime.Value & ";" & "MeanTarget," & Me.TextBox_MeanTarget.Text & ";" & "ErrorRange," & Me.TextBox_ErrorRange.Text & ";" & "Kp," & Me.TextBox_Kp.Text & ";" & "Max_ExposureTime," & Me.m_Max_ExposureTime

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_ADJMean Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Save.Enabled = True
                    Me.GroupBox_Mode.Enabled = True
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If Me.RadioButton_Func.Checked = True Then   '2010/05/19 Rick add
                i = Me.m_MainProcess.FuncPatternRecipeArrayOrder.IndexOf(Me.m_FuncProcess.CurrentFuncPatternRecipe)
                Me.CompareFunc(Me.m_MainProcess.FuncPatternRecipeArrayTemp.Item(i), Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray.Item(i), Me.m_MainProcess.RecipeDailyLogManager)

                str = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & i + 1 & ".xml"
                ClsFuncPatternRecipe.WriteXML(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i), str)

                '----------------------------------------------------------------------------------------------
                ' Save Current Func Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Func Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Save.Enabled = True
                        Me.GroupBox_Mode.Enabled = True
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            ElseIf Me.RadioButton_Mura.Checked = True Then
                i = Me.m_MainProcess.MuraPatternRecipeArrayOrder.IndexOf(Me.m_MuraProcess.CurrentMuraPatternRecipe)
                Me.CompareMura(Me.m_MainProcess.MuraPatternRecipeArrayTemp.Item(i), Me.m_MuraProcess.MuraPatternRecipeArray.Item(i), Me.m_MainProcess.RecipeDailyLogManager)

                str = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & i + 1 & ".xml"
                ClsMuraPatternRecipe.WriteXML(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i), str)

                '----------------------------------------------------------------------------------------------
                ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                    TimeOut = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_Save]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Save.Enabled = True
                        Me.GroupBox_Mode.Enabled = True
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            If Me.RadioButton_Func.Checked Then
                'Func Recipe Monitor ---
                dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
                If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
                Me.m_FuncProcess.SaveToFuncRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)
            Else
                'Mura Recipe Monitor ---
                dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
                If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
                Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)
            End If

            Me.GroupBox_Mode.Enabled = True

            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.Button_Save.Enabled = True
        Catch ex As Exception
            Me.Button_Save.Enabled = True
            Me.GroupBox_Mode.Enabled = True

            Me.Button_Continue.Enabled = True
            Me.Button_Load.Enabled = True
            Me.SetButton_Grab(False)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Save]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- Button_AutoExposure ---"

#Region "--- Button_AutoExposure_Click ---"
    Private Sub Button_AutoExposure_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button_AutoExposure.Click
        If Me.m_IPBootConfig.Digitizer_Type.Value = DigitizerType.Color And Me.ComboBox_ColorBand.Text = "" Then
            MsgBox("�Х���� Color Band !", MsgBoxStyle.Critical, "[AreaGrabber]")
            Exit Sub
        End If

        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Try
            If Me.TextBox_MeanTarget.Text <> "" Then

                ''--- ����s����� ---
                'Me.WaitGrabReady()

                '--- �إ߳s�u ---
                If Not Me.ConnectToIP Then
                    Exit Sub
                End If

                Me.Button_AutoExposure.Enabled = False

                If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
                    image = Me.m_MainProcess.Img_16U_Grab_1

                    If image <> M_NULL Then
                        imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                        SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                        Type = MbufInquire(image, M_TYPE, M_NULL)

                        If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                            MbufFree(imageBuffer)
                            imageBuffer = M_NULL
                            imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                        End If
                        MbufCopy(image, imageBuffer)

                        MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                        MbufControl(image, M_MODIFIED, M_DEFAULT)
                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                        Me.m_Form.ResetScrollBar()
                    End If
                Else
                    Me.m_Form.CurrentIndex0 = 0
                    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    Me.m_Form.ComboBox_Select.SelectedIndex = 0
                End If
                Me.m_Form.ImageZoomAll()

                Me.Button_AutoExposure.Enabled = False
                Me.Label_AutoExposure_Time.Text = ""

                '----------------------------------------------------------------------------------------------
                ' Adjust Exposure Time Dynamically  ==> Request_Command = "CALCULATE_DYNAMICEXPOSURE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DYNAMICEXPOSURE"
                    TimeOut = 20000 ' 20 secs
                    If Me.CheckBox_LongCalculateTime.Checked Then
                        TimeOut = 60000 ' 60 secs
                    End If

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, TextBox_Kp.Text, TextBox_MeanTarget.Text, TextBox_ErrorRange.Text, ComboBox_ColorBand.Text, , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True

                        '[Result]
                        Me.Label_AutoExposure.Text = SubSystemResult.Responses(0).Param2
                        Me.Label_ROI_Mean.Text = "ROI Mean�G" & SubSystemResult.Responses(0).Param3
                        Me.Label_AutoExposure_Time.Text = CStr(SubSystemResult.Responses(0).Param4) & " ms"
                        Me.Label_ExecuteCount.Text = CStr(SubSystemResult.Responses(0).Param5) & " ��"

                        If Me.m_Form.GetPatternIndexInfo < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then   '2009/06/16 Rick modify (�ѭק��Mura�n���ɶ�)
                            Me.m_MuraProcess.CurrentMuraPatternRecipe.ExposureTime.Value = SubSystemResult.Responses(0).Param2
                        Else
                            Me.m_FuncProcess.CurrentFuncPatternRecipe.ExposureTime.Value = SubSystemResult.Responses(0).Param2
                        End If

                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Adjust Exposure Time Dynamically Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_AutoExposure]" & SubSystemResult.ErrMessage & ", �Y�վ�ɶ�Time out,�Э��s�]�w kp �� !", "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_AutoExposure.Enabled = True
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Else
                MessageBox.Show("�п�J�۰��n�������Ƕ���", "[AreaGrabber]")
            End If

            Me.AutoExp_Apply()

            Me.Button_AutoExposure.Enabled = True
        Catch ex As Exception
            Me.Button_AutoExposure.Enabled = True
            Throw New Exception("[Dialog_ADJMean.Button_AutoExposure_Click] Auto Exposure Error !(" & ex.Message & ")")
        End Try
    End Sub
#End Region

#Region "--- get_GrayMean ---"
    Private Sub get_GrayMean(ByRef mean As Integer, ByRef Max_GrayMean As Integer)
        Dim buffer As MIL_ID = Nothing
        Dim image As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim strs() As String
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        ''--- ����s����� ---
        'Me.WaitGrabReady()

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' IP LOAD GRAB IMAGE  ==> Request_Command = "LOAD_GRABIMAGE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "LOAD_GRABIMAGE"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Grab Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Response_OK Then
                '[1] Update Processed Image ---
                If Me.RadioButton_Func.Checked Then
                    image = Me.m_FuncProcess.Img_Original_NonPage   'Func
                    If Me.m_ManualLoad Then
                        strPath = Me.m_ManualPath
                    Else

                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                            Me.RepairPath_2(strPath)
                        End If
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_Mapping_NonPage)

                    End If
                End If

                'If System.IO.File.Exists(strPath) = True Then
                '    System.IO.File.Delete(strPath)
                'End If
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_GrayMean]Func Load Grab Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

        If Me.RadioButton_Mura.Checked Then
            '----------------------------------------------------------------------------------------------
            ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "RESIZE_ORIGINAL"
                TimeOut = 1000000 '1000 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error ! (" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image --- Resize �᪺�v���Y���Y�p�᪺Mura��l�v��
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                    Else
                        image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                    End If

                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        'MbufCopy(image, Me.m_MainProcess.Img_Mapping_NonPage)

                        'If System.IO.File.Exists(strPath) = True Then
                        '    System.IO.File.Delete(strPath)
                        'End If
                    End If
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_GrayMean]Mura Resize Image Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try

        End If

        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        Else
            Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        End If

        '----------------------------------------------------------------------------------------------
        ' Get Gray Mean  ==> Request_Command = "GET_GRAYMEAN" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "GET_GRAYMEAN"
            TimeOut = 500000 '500 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                strs = SubSystemResult.Responses(0).Param2.Split(",")
                mean = strs(1)
                Max_GrayMean = SubSystemResult.Responses(0).Param3
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Gray Mean Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_GrayMean]Get Gray Mean Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

    End Sub
#End Region

#End Region

#Region "--- Buttom_SaveExp---"
    Private Sub Button_SaveExp_Click(sender As System.Object, e As System.EventArgs) Handles Button_SaveExp.Click
        Me.m_Form.MainProcess.Save_All_ExposureTime_2()
    End Sub
#End Region

#Region "--- Button_Correct_Distortion ---"
    Private Sub Button_Correct_Distortion_Click(sender As System.Object, e As System.EventArgs) Handles Button_Correct_Distortion.Click
        Dim Image As MIL_ID = M_NULL
        Dim Image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim SaveImage As Boolean

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Button Control ---   

        Image = MdispInquire(Me.m_Form.AxMDisplay, M_SELECTED, M_NULL)
        If Image = M_NULL Then
            MsgBox("�и��J�v��")
        Else
            '----------------------------------------------------------------------------------------------------------------------
            'Calculate Correct Image Distortion  ==> Request_Command = "CALCULATE_CORRECT_IMAGE_DISTORTION" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_CORRECT_IMAGE_DISTORTION"
                TimeOut = 100000 '100 secs


                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then

                    If SubSystemResult.Responses(0).Param1 <> "" Then
                        Me.m_Form.OutputInfo(SubSystemResult.Responses(0).Param1)
                        MessageBox.Show("[Dialog_Align.Button_Correct_Distortion_Click]" & SubSystemResult.Responses(0).Param1, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Else
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")

                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_Func_Calibrated_NonPage.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_Func_Calibrated_NonPage.tif"
                            RepairPath_2(strPath)
                        End If

                        '--- ALL For Display---
                        Image = Me.m_MainProcess.Img_16U_Grab_1
                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Image <> M_NULL Then
                                If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image)
                                    Image = M_NULL
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Image)
                            MbufCopy(Image, Me.m_FuncProcess.Img_Original_NonPage)

                            Me.m_Form.ImageUpdate()

                            '--- Display ---
                            If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
                                If Image <> M_NULL Then
                                    imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                    SizeX = MbufInquire(Image, M_SIZE_X, M_NULL)
                                    SizeY = MbufInquire(Image, M_SIZE_Y, M_NULL)
                                    Type = MbufInquire(Image, M_TYPE, M_NULL)

                                    If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                        MbufFree(imageBuffer)
                                        imageBuffer = M_NULL
                                        imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                    End If
                                    MbufCopy(Image, imageBuffer)

                                    MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                                    MbufControl(Image, M_MODIFIED, M_DEFAULT)
                                    MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                    Me.m_Form.ResetScrollBar()
                                End If
                            End If
                        End If

                        If Me.RadioButton_Mura.Checked Then
                            Try
                                '--- Prepare Command ---
                                Request_Command = "Transfer_Mura_Boundary"
                                TimeOut = 10000 '10 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    Exit Sub
                                End If
                            Catch ex As Exception
                                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                            End Try

                            Image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                            '[AreaGrabber] Load image2 --- (For Display)
                            '[1] image2 ---
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Image2 <> M_NULL Then
                                If MbufInquire(Image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image2, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Image2)
                                    Image2 = M_NULL
                                    Image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                            MbufLoad(strPath, Image2)
                        End If

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        If Me.RadioButton_Mura.Checked Then

                            '----------------------------------------------------------------------------------------------
                            ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "RESIZE_ORIGINAL"
                                TimeOut = 500000 '500 secs
                                SaveImage = True

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    'MessageBox.Show("[Dialog_ADJMean.Button_Grab_Click]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Me.Button_Continue.Enabled = True
                                    Me.Button_Load.Enabled = True
                                    Me.SetButton_Grab(False)
                                    Exit Sub
                                End If

                                If SaveImage AndAlso Response_OK Then
                                    '[1] Update Processed Image --- Resize �᪺�v���Y���Y�p�᪺Mura��l�v��
                                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                        Image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                                    Else
                                        Image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                                    End If

                                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                        strPath = strPath.Replace("\\", "\")
                                    Else
                                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                        Me.RepairPath_2(strPath)
                                    End If

                                    If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                        MbufDiskInquire(strPath, M_TYPE, Type)
                                        If Image <> M_NULL Then
                                            If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                                MbufFree(Image)
                                                Image = M_NULL
                                                Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                            End If
                                        Else
                                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If

                                        '--- Load Remote Image ---
                                        MbufLoad(strPath, Image)
                                        If System.IO.File.Exists(strPath) = True Then
                                            System.IO.File.Delete(strPath)
                                        End If
                                    End If
                                End If

                            Catch ex As Exception
                                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                            End Try
                        End If

                        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                            Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                        Else
                            Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
                        End If

                    End If

                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Correct Image Distortion Fail !(" & SubSystemResult.Responses(0).Param2 & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Button_Correct_Distortion_Click]" & SubSystemResult.Responses(0).Param2, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

        End If
    End Sub
#End Region

#Region "--- Button_Save_ColorRawImage ---"
    Private Sub Button_Save_ColorRawImage_Click(sender As System.Object, e As System.EventArgs) Handles Button_Save_ColorRawImage.Click
        Try
            '--- Save Image ---
            Me.SetButton_Save_ColorRawImage(False)

            Me.SaveFileDialog.ShowDialog()
            If Me.SaveFileDialog.FileName <> "" Then
                MbufSave(Me.SaveFileDialog.FileName, Me.m_MainProcess.Img_16U_GrabColor_1)
            End If

            Me.SetButton_Save_ColorRawImage(True)

        Catch ex As Exception
            Me.SetButton_Save_ColorRawImage(True)
            Me.m_Form.OutputInfo("[Dialog_ADJmean.Save_ColorRawImage]Save Color Raw Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_ADJmean.Save_ColorRawImage]Save Color Raw Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#End Region



#End Region

#Region "--- ComboBox Event ---"

#Region "--- ComboBox_PatnList_SelectedIndexChanged ---"
    Private Sub ComboBox_PatnList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_PatnList.SelectedIndexChanged
        Dim PatternName As String
        Dim PatternIndex As Integer

        ''--- ����s����� ---
        'Me.WaitGrabReady()

        '--- �إ߳s�u ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.GetPatternNameInfo

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


        '[AreaGrabber]
        If Me.RadioButton_Mura.Checked = True Then
            PatternIndex = Me.ComboBox_PatnList.SelectedIndex
            Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '�q[1]�}�l
            If Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).ExposureTime.Value >= Me.TrackBar_ExposureTime.Maximum Then
                Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).ExposureTime.Value = Me.TrackBar_ExposureTime.Maximum - 1
            End If
            Me.TrackBar_ExposureTime.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).ExposureTime.Value
            Me.TextBox_Kp.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).AutoExposure_Kp.Value)
            Me.TextBox_MeanTarget.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).AutoExposure_TargetMean.Value)
            Me.TextBox_ErrorRange.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).AutoExposure_SmallErrorRange.Value)

        ElseIf Me.RadioButton_Func.Checked = True Then
            PatternIndex = Me.ComboBox_PatnList.SelectedIndex
            Me.m_Form.SetPatternIndexInfo(PatternIndex + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value + 1)  '�q[1]�}�l
            If Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).ExposureTime.Value >= Me.TrackBar_ExposureTime.Maximum Then
                Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).ExposureTime.Value = Me.TrackBar_ExposureTime.Maximum - 1
            End If
            Me.TrackBar_ExposureTime.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).ExposureTime.Value
            Me.TextBox_Kp.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).AutoExposure_Kp.Value)
            Me.TextBox_MeanTarget.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).AutoExposure_TargetMean.Value)
            Me.TextBox_ErrorRange.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).AutoExposure_SmallErrorRange.Value)
        End If

        '--- ��s�n���ɶ� ---
        '--- �������̤p�n���ɶ� 16000 --- 
        'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
        Me.NumericUpDown_ExposureTime.Value = Me.TrackBar_ExposureTime.Value

        If Me.m_Have_MDigitizer Then

            '----------------------------------------------------------------------------------------------
            ' Update Current Exposure Time  ==> Request_Command = "UPDATE_EXPOSURETIME" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "UPDATE_EXPOSURETIME"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NumericUpDown_ExposureTime.Value, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Response_OK = False
                    Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If
            Catch ex As Exception
                Response_OK = False
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Update Current Exposure Time Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

        '[AreaGrabber]
        Me.Button_Continue.Enabled = True
        Me.Button_Load.Enabled = True
        Me.SetButton_Grab(False)
        Me.TrackBar_ExposureTime.Enabled = False
        Me.NumericUpDown_ExposureTime.Enabled = False

    End Sub
#End Region

#Region "--- ComboBox_PitchCheck_SelectedIndexChanged ---"
    Private Sub ComboBox_PitchCheck_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If CheckBox_ShowBoundary.Checked Then
            PitchCheck_Boundary()
        End If

    End Sub
#End Region

#Region "--- ComboBox_ColorBand_SelectedIndexChanged ---"
    Private Sub ComboBox_ColorBand_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox_ColorBand.SelectedIndexChanged
        Select Case Me.ComboBox_ColorBand.Text
            Case "R"
                Me.ComboBox_ColorBand.ForeColor = Color.Red
            Case "G"
                Me.ComboBox_ColorBand.ForeColor = Color.Green
            Case "B"
                Me.ComboBox_ColorBand.ForeColor = Color.Blue
            Case "L"
                Me.ComboBox_ColorBand.ForeColor = Color.Black
        End Select
    End Sub
#End Region

#End Region

#Region "--- NumericUpDown Event ---"

#Region "--- NumericUpDown_ExposureTime_ValueChanged ---"
    Private Sub NumericUpDown_ExposureTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown_ExposureTime.ValueChanged
        If Me.m_MainProcess Is Nothing Then Exit Sub
        If Me.m_Initial_Finished = False Then Exit Sub
        If Not Me.m_Ever_ContinueGrab Then Exit Sub

        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        'Dim PatternName As String
        'Dim PatternIndex As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim ColorBand As String = Me.GetColorBandInfo  'Image Band (R\G\B\L --> Color�۾� �G�ť� --> Mono�۾�)

        '--- Initial --- 
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        'Stop Grab First ---
        Me.WaitGrabReady()

        '[AreaGrabber]    
        'If Me.RadioButton_Mura.Checked = True Then
        '    PatternIndex = Me.ComboBox_PatnList.SelectedIndex
        '    Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '�q[1]�}�l
        'ElseIf Me.RadioButton_Func.Checked = True Then
        '    PatternIndex = Me.ComboBox_PatnList.SelectedIndex
        '    Me.m_Form.SetPatternIndexInfo(PatternIndex + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value + 1)   '�q[1]�}�l
        'End If

        If Me.RadioButton_Mura.Checked Or RadioButton_Func.Checked Then
            Me.TrackBar_ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
        Else
            Exit Sub
        End If

        '--- Button Disable ---
        Me.Button_Save.Enabled = False
        Me.GroupBox_Mode.Enabled = False
        If Me.m_Have_MDigitizer Then Me.Button_Continue.Enabled = False
        Me.Button_Load.Enabled = False
        Me.TrackBar_ExposureTime.Enabled = False

        ''----------------------------------------------------------------------------------------------
        '' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        ''----------------------------------------------------------------------------------------------
        'Try
        '    '--- Prepare Command ---
        '    Request_Command = "SET_PATTERNINDEX"
        '    TimeOut = 100000 '100 secs

        '    '--- PatternName ---
        '    PatternName = Me.GetPatternNameInfo

        '    Response_OK = False
        '    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
        '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

        '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
        '        Response_OK = True
        '    Else
        '        Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '        MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        Exit Sub
        '    End If
        'Catch ex As Exception
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Set Pattern Index Error ! (" & ex.Message & ")")
        '    MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        If Not Me.m_MainProcess Is Nothing Then

            Try
                If Not Me.m_Form Is Nothing AndAlso (Me.m_IPBootConfig.CardSystem.Value <> "" Or Me.m_IPBootConfig.CCD_Link_Type.Value = CCD_LinkType.GigE) Then

                    If Me.m_Have_MDigitizer Then
                        '----------------------------------------------------------------------------------------------
                        ' Update Current Exposure Time  ==> Request_Command = "UPDATE_EXPOSURETIME" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "UPDATE_EXPOSURETIME"
                            TimeOut = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.NumericUpDown_ExposureTime.Value, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Response_OK = False
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If
                        Catch ex As Exception
                            Response_OK = False
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Update Current Exposure Time Error ! (" & ex.Message & ")")
                            'MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If

                    If Response_OK Then
                        '----------------------------------------------------------------------------------------------
                        ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "GRAB_ONESHOT"
                            TimeOut = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ColorBand, , , , , , , , TimeOut)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                Response_OK = True
                            Else
                                Response_OK = False
                                Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                            If Response_OK Then
                                '--- Update Processed Image ---
                                Image = Me.m_MainProcess.Img_16U_Grab_1

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If Image <> M_NULL Then
                                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(Image)
                                            Image = M_NULL
                                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, Image)
                                    MbufCopy(Image, Me.m_MainProcess.Img_Mapping_NonPage)

                                    Me.m_Form.ImageUpdate()
                                    Me.Button_Save.Enabled = True
                                End If
                            End If
                        Catch ex As Exception
                            Response_OK = False
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try
                    End If

                    '--- Stop Grab First ---
                    Me.SetButton_Grab(False)
                    If Me.m_Have_MDigitizer Then Me.Button_Continue.Enabled = True
                    Me.Button_Load.Enabled = True
                End If

            Catch ex As Exception
                If Me.m_Have_MDigitizer Then Me.Button_Continue.Enabled = True
                Me.Button_Load.Enabled = True
                Me.SetButton_Grab(False)
                Me.Button_Save.Enabled = True
                Me.GroupBox_Mode.Enabled = True
                Me.TrackBar_ExposureTime.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message)
            End Try
        End If

        System.Threading.Thread.Sleep(200)
        Me.Button_Save.Enabled = True
        Me.TrackBar_ExposureTime.Enabled = True
        Me.GroupBox_Mode.Enabled = True

    End Sub
#End Region

#End Region

#Region "--- TrackBar Event ---"

#Region "--- TrackBar_ExposureTime_MouseUp ---"
    Private Sub TrackBar_ExposureTime_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TrackBar_ExposureTime.MouseUp
        If Me.m_Initial_Finished = False Then Exit Sub
        If Not Me.m_Ever_ContinueGrab Then Exit Sub

        '--- ��s�n���ɶ� ---
        '--- �������̤p�n���ɶ� 16000 --- 
        'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
        Me.NumericUpDown_ExposureTime.Value = Me.TrackBar_ExposureTime.Value
    End Sub
#End Region

#End Region

#Region "--- CheckBox Event ---"

#Region "--- CheckBox_ShowBoundary_CheckedChanged ---"
    Private Sub CheckBox_ShowBoundary_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_ShowBoundary.CheckedChanged
        If CheckBox_ShowBoundary.Checked Then
            PitchCheck_Boundary()
        End If
        Me.ReDraw(pb)
    End Sub
#End Region

#Region "--- CheckBox_MannualFocus_CheckedChanged ---"
    Private Sub CheckBox_MannualFocus_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles CheckBox_MannualFocus.CheckedChanged
        SetCalculateFocusValueEnableInfo(Me.CheckBox_MannualFocus.Checked)
    End Sub
#End Region

#End Region

#Region "--- AxMDisplay Event ---"

#Region "--- m_AxMDisplay_PaintEvent ---"
    Private Sub m_AxMDisplay_PaintEvent(sender As Object, e As System.Windows.Forms.PaintEventArgs) Handles m_Panel_AxMDisplay.Paint
        If Not Me.m_Form.PaintStop Then
            If Me.m_Form.ComboBox_Type.SelectedIndex = 0 Then
                Me.ReDraw(pb)
            End If

        End If
    End Sub
#End Region

#End Region

#Region "--- ��s�ثe�����A ---"

#Region "--- Button Event ---"
    Private Delegate Function SetButton_ContinueCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Continue(ByVal En As Boolean) As Boolean
        If Me.Button_Continue.InvokeRequired Then
            Me.Invoke(New SetButton_ContinueCallback(AddressOf SetButton_Continue), New Object() {En})
        Else
            Me.Button_Continue.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_LoadCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Load(ByVal En As Boolean) As Boolean
        If Me.Button_Load.InvokeRequired Then
            Me.Invoke(New SetButton_LoadCallback(AddressOf SetButton_Load), New Object() {En})
        Else
            Me.Button_Load.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_GrabCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Grab(ByVal En As Boolean) As Boolean
        If Me.Button_Grab.InvokeRequired Then
            Me.Invoke(New SetButton_GrabCallback(AddressOf SetButton_Grab), New Object() {En})
        Else
            Me.Button_Grab.Enabled = En
            Me.Update()
        End If
        Return True
    End Function

    Private Delegate Function SetButton_Save_ColorRawImageCallback(ByVal En As Boolean) As Boolean
    Private Function SetButton_Save_ColorRawImage(ByVal En As Boolean) As Boolean
        If Me.Button_Save_ColorRawImage.InvokeRequired Then
            Me.Invoke(New SetButton_Save_ColorRawImageCallback(AddressOf SetButton_Save_ColorRawImage), New Object() {En})
        Else
            Me.Button_Save_ColorRawImage.Enabled = En
            Me.Update()
        End If
        Return True
    End Function
#End Region

#Region "--- GetExposureTimeInfo ---"
    Delegate Function GetExposureTimeInfoCallback() As Double
    Public Function GetExposureTimeInfo() As Double
        Dim i As Double
        If Me.NumericUpDown_ExposureTime.InvokeRequired Then
            Return Me.Invoke(New GetExposureTimeInfoCallback(AddressOf GetExposureTimeInfo), New Object() {})
        Else
            i = Me.NumericUpDown_ExposureTime.Value
            Me.Update()
            Return i
        End If
    End Function
#End Region

#Region "--- GetButtonGranEnableInfo ---"
    Delegate Function GetButtonGranEnableInfoCallback() As Boolean
    Public Function GetButtonGranEnableInfo() As Boolean
        If Me.Button_Grab.InvokeRequired Then
            Return Me.Invoke(New GetButtonGranEnableInfoCallback(AddressOf GetButtonGranEnableInfo), New Object() {})
        Else
            Me.Update()
            Return Me.Button_Grab.Enabled
        End If
    End Function
#End Region

#Region "--- GetCalculateFocusValueEnableInfo ---"
    Delegate Function GetCalculateFocusValueEnableInfoCallback() As Boolean
    Public Function GetCalculateFocusValueEnableInfo() As Boolean
        Dim En As Boolean
        If Me.CheckBox_MannualFocus.InvokeRequired Then
            Return Me.Invoke(New GetCalculateFocusValueEnableInfoCallback(AddressOf GetCalculateFocusValueEnableInfo), New Object() {})
        Else
            En = Me.CheckBox_MannualFocus.Checked
            Me.Update()
            Return En
        End If
    End Function
#End Region

#Region "--- SetCalculateFocusValueEnableInfo ---"
    Delegate Sub SetCalculateFocusValueEnableInfoCallback(ByVal En As Boolean)
    Public Sub SetCalculateFocusValueEnableInfo(ByVal En As Boolean)
        If Me.CheckBox_MannualFocus.InvokeRequired Then
            Me.Invoke(New SetCalculateFocusValueEnableInfoCallback(AddressOf SetCalculateFocusValueEnableInfo), New Object() {En})
        Else
            Me.CheckBox_MannualFocus.Checked = En
            Me.Update()
        End If
    End Sub
#End Region

#Region "--- SetLabel_FocusValueinfo ---"
    Delegate Sub SetLabel_FocusValueInfoCallback(ByVal Text As String)
    Public Sub SetLabel_FocusValueInfo(ByVal Text As String)
        If Me.Label_FocusValue.InvokeRequired Then
            Me.Invoke(New SetLabel_FocusValueInfoCallback(AddressOf SetLabel_FocusValueInfo), New Object() {Text})
        Else
            Me.Label_FocusValue.Text = Text
            Me.Update()
        End If
    End Sub
#End Region

#Region "--- SetComboBox_PatnList_EnableInfo ---"
    Delegate Sub SetComboBox_PatnList_EnableInfoCallback(ByVal En As Boolean)
    Public Sub SetComboBox_PatnList_EnableInfo(ByVal En As Boolean)
        If Me.ComboBox_PatnList.InvokeRequired Then
            Me.Invoke(New SetComboBox_PatnList_EnableInfoCallback(AddressOf SetComboBox_PatnList_EnableInfo), New Object() {En})
        Else
            Me.ComboBox_PatnList.Enabled = En
            Me.Update()
        End If
    End Sub
#End Region

#Region "--- SetRadioButton_Mura_EnableInfo ---"
    Delegate Sub SetRadioButton_Mura_EnableInfoCallback(ByVal En As Boolean)
    Public Sub SetRadioButton_Mura_EnableInfo(ByVal En As Boolean)
        If Me.RadioButton_Mura.InvokeRequired Then
            Me.Invoke(New SetRadioButton_Mura_EnableInfoCallback(AddressOf SetRadioButton_Mura_EnableInfo), New Object() {En})
        Else
            Me.RadioButton_Mura.Enabled = En
            Me.Update()
        End If
    End Sub
#End Region

#Region "--- SetRadioButton_Func_EnableInfo ---"
    Delegate Sub SetRadioButton_Func_EnableInfoCallback(ByVal En As Boolean)
    Public Sub SetRadioButton_Func_EnableInfo(ByVal En As Boolean)
        If Me.RadioButton_Func.InvokeRequired Then
            Me.Invoke(New SetRadioButton_Func_EnableInfoCallback(AddressOf SetRadioButton_Func_EnableInfo), New Object() {En})
        Else
            Me.RadioButton_Func.Enabled = En
            Me.Update()
        End If
    End Sub
#End Region

#Region "--- GetPatternNameInfoCallback ---"
    Delegate Function GetPatternNameInfoCallback() As String
    Private Function GetPatternNameInfo() As String
        Dim PatternName As String
        If Me.ComboBox_PatnList.InvokeRequired Then
            Return Me.Invoke(New GetPatternNameInfoCallback(AddressOf GetPatternNameInfo), New Object() {})
        Else
            PatternName = Me.ComboBox_PatnList.Text
            Me.Update()
            Return PatternName
        End If
    End Function
#End Region

#Region "--- GetColorBandInfoCallback ---"
    Delegate Function GetColorBandInfoCallback() As String
    Private Function GetColorBandInfo() As String
        Dim ColorBand As String
        If Me.ComboBox_ColorBand.InvokeRequired Then
            Return Me.Invoke(New GetColorBandInfoCallback(AddressOf GetColorBandInfo), New Object() {})
        Else
            ColorBand = Me.ComboBox_ColorBand.Text
            Me.Update()
            Return ColorBand
        End If
    End Function
#End Region

#End Region



    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button_CalculateHValue.Click
        Request_Command = "CALCULATE_HVVALUE"
        TimeOut = 100000 '100 secs
        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
            Me.NumericUpDown_GaussianHValue.Value = SubSystemResult.Responses(0).Param1
            Me.NumericUpDown_GaussianVValue.Value = SubSystemResult.Responses(0).Param2
            Me.NumericUpDown_LSQHValue.Value = SubSystemResult.Responses(0).Param3
            Me.NumericUpDown_LSQVValue.Value = SubSystemResult.Responses(0).Param4
        Else
            Response_OK = False
            Me.m_MainProcess.LogDailyManager("[G >>C1]�����R�O =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "CALCULATE_HVALUE Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
            MessageBox.Show("[Dialog_ADJMean.CALCULATE_HVALUE]" & SubSystemResult.ErrMessage, "���~", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If


    End Sub

#Region "--- Change Language ---"

    Private Sub changeLanguage(ByVal language As String)
        Select Case language
            Case "zh-CN"
                Me.Text = res.GetString("$this.Text")
                Button_AutoExposure.Text = res.GetString("Button_AutoExposure.Text")
                Button_MannualMean.Text = res.GetString("Button_MannualMean.Text")
                CheckBox_LongCalculateTime.Text = res.GetString("CheckBox_LongCalculateTime.Text")
                CheckBox_MannualFocus.Text = res.GetString("CheckBox_MannualFocus.Text")
                CheckBox_ShowBoundary.Text = res.GetString("CheckBox_ShowBoundary.Text")
                GroupBox_ExposureTime.Text = res.GetString("GroupBox_ExposureTime.Text")
                GroupBox_Grab.Text = res.GetString("GroupBox_Grab.Text")
                GroupBox_ImageSource.Text = res.GetString("GroupBox_ImageSource.Text")
                GroupBox_Mode.Text = res.GetString("GroupBox_Mode.Text")
                Label_ExposureTime.Text = res.GetString("Label_ExposureTime.Text")
                Label_ROI_Max.Text = res.GetString("Label_ROI_Max.Text")
                Label_ROI_Mean.Text = res.GetString("Label_ROI_Mean.Text")
                Label1.Text = res.GetString("Label1.Text")
                Label6.Text = res.GetString("Label6.Text")
                Label7.Text = res.GetString("Label7.Text")
                Label8.Text = res.GetString("Label8.Text")
                RadioButton_Auto.Text = res.GetString("RadioButton_Auto.Text")
                RadioButton_Manual.Text = res.GetString("RadioButton_Manual.Text")
                '
                Label10.Visible = False
                Label11.Visible = False
                NumericUpDown_GaussianHValue.Visible = False
                NumericUpDown_GaussianVValue.Visible = False
                NumericUpDown_LSQHValue.Visible = False
                NumericUpDown_LSQVValue.Visible = False
                Button_Save_ColorRawImage.Visible = False
                Button_CalculateHValue.Visible =False
        End Select
    End Sub
#End Region

    Private Sub Label_FocusValue_Click(sender As System.Object, e As System.EventArgs) Handles Label_FocusValue.Click

    End Sub
End Class


Public Class Utils

#Region "--- ��k�禡 ---"

    ''' <summary>
    ''' �glog��
    ''' </summary>
    ''' <param name="str_log">log����r</param>
    ''' <param name="LOG_FILE_PRENAME">���ɦW</param>
    ''' <param name="bNeedHeader">�e�Y�O�_�n���[�ɶ�</param>
    ''' <remarks></remarks>
    ''' 
#Region "--- WriteLog ---"
    Public Shared Sub WriteLog(ByVal sLogPath As String, ByVal str_log As String, Optional ByVal LOG_FILE_PRENAME As String = "", Optional ByVal sModelName As String = "", Optional ByVal bNeedHeader As Boolean = True)
        Try
            If Not sModelName.Equals("") Then sLogPath &= sModelName & "\"

            Dim tempfilestream As System.IO.FileStream



            If bNeedHeader Then str_log = str_log.Replace(vbCrLf, vbTab)
            If bNeedHeader Then str_log = Now & vbTab & str_log & vbCrLf

            '--- �P�@�Ѫ��ާ@�u�����@��log�ɮ� ---
            If bNeedHeader Then CheckForInitLog(sLogPath)

            tempfilestream = IO.File.Open(sLogPath, IO.FileMode.Append)
            Dim teststreamwrite As New System.IO.StreamWriter(tempfilestream, System.Text.Encoding.Default)

            Dim buffer() As Byte

            ReDim buffer(str_log.Length - 1)
            teststreamwrite.Write(str_log)
            teststreamwrite.Close()
        Catch ex As Exception
            Throw New Exception("[ClsFuncFalseFilter]WriteLog Error !(" & ex.Message & ")" & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region

#Region "--- CheckForInitLog ---"
    Public Shared Sub CheckForInitLog(ByVal sLogPath As String)
        Try
            If Not IO.File.Exists(sLogPath) Then
                Dim Str As String = ""

                Dim tempfilestream As System.IO.FileStream

                tempfilestream = IO.File.Open(sLogPath, IO.FileMode.Create)
                Dim teststreamwrite As New System.IO.StreamWriter(tempfilestream, System.Text.Encoding.Default)

                Dim buffer() As Byte

                ReDim buffer(Str.Length - 1)
                teststreamwrite.Write(Str)
                teststreamwrite.Close()
            End If
        Catch ex As Exception
            Throw New Exception("[ClsFuncFalseFilter]CheckForInitLog Error!(" & ex.Message & ")" & "(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region

#End Region


End Class