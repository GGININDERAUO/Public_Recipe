﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Dialog_ADJMean
    Inherits System.Windows.Forms.Form

    'Form 覆寫 Dispose 以清除元件清單。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    '為 Windows Form 設計工具的必要項
    Private components As System.ComponentModel.IContainer

    '注意: 以下為 Windows Form 設計工具所需的程序
    '可以使用 Windows Form 設計工具進行修改。
    '請不要使用程式碼編輯器進行修改。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Dialog_ADJMean))
        Me.GroupBox_Mode = New System.Windows.Forms.GroupBox()
        Me.CheckBox_LongCalculateTime = New System.Windows.Forms.CheckBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.NumericUpDown_GaussianVValue = New System.Windows.Forms.NumericUpDown()
        Me.Button_SaveExp = New System.Windows.Forms.Button()
        Me.NumericUpDown_GaussianHValue = New System.Windows.Forms.NumericUpDown()
        Me.CheckBox_MannualFocus = New System.Windows.Forms.CheckBox()
        Me.Button_CalculateHValue = New System.Windows.Forms.Button()
        Me.Label_FocusValue = New System.Windows.Forms.Label()
        Me.Label_ExecuteCount = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label_AutoExposure_Time = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox_Kp = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox_ErrorRange = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label_AutoExposure = New System.Windows.Forms.Label()
        Me.Label_ROI_Max = New System.Windows.Forms.Label()
        Me.Button_AutoExposure = New System.Windows.Forms.Button()
        Me.TextBox_MeanTarget = New System.Windows.Forms.TextBox()
        Me.Button_MannualMean = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RadioButton_Manual = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Auto = New System.Windows.Forms.RadioButton()
        Me.Label_ROI_Mean = New System.Windows.Forms.Label()
        Me.CheckBox_ShowBoundary = New System.Windows.Forms.CheckBox()
        Me.GroupBox_ExposureTime = New System.Windows.Forms.GroupBox()
        Me.Button_Save = New System.Windows.Forms.Button()
        Me.Label_ExposureTime = New System.Windows.Forms.Label()
        Me.NumericUpDown_ExposureTime = New System.Windows.Forms.NumericUpDown()
        Me.TrackBar_ExposureTime = New System.Windows.Forms.TrackBar()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox_PatnList = New System.Windows.Forms.ComboBox()
        Me.GroupBox_ImageSource = New System.Windows.Forms.GroupBox()
        Me.Button_Correct_Distortion = New System.Windows.Forms.Button()
        Me.GroupBox_Grab = New System.Windows.Forms.GroupBox()
        Me.ComboBox_ColorBand = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button_Grab = New System.Windows.Forms.Button()
        Me.Button_Continue = New System.Windows.Forms.Button()
        Me.Button_Load = New System.Windows.Forms.Button()
        Me.RadioButton_Func = New System.Windows.Forms.RadioButton()
        Me.RadioButton_Mura = New System.Windows.Forms.RadioButton()
        Me.Button_Save_ColorRawImage = New System.Windows.Forms.Button()
        Me.SaveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.NumericUpDown_LSQHValue = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown_LSQVValue = New System.Windows.Forms.NumericUpDown()
        Me.GroupBox_Mode.SuspendLayout()
        CType(Me.NumericUpDown_GaussianVValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_GaussianHValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ExposureTime.SuspendLayout()
        CType(Me.NumericUpDown_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TrackBar_ExposureTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox_ImageSource.SuspendLayout()
        Me.GroupBox_Grab.SuspendLayout()
        CType(Me.NumericUpDown_LSQHValue, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown_LSQVValue, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox_Mode
        '
        resources.ApplyResources(Me.GroupBox_Mode, "GroupBox_Mode")
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_LongCalculateTime)
        Me.GroupBox_Mode.Controls.Add(Me.Label11)
        Me.GroupBox_Mode.Controls.Add(Me.Label10)
        Me.GroupBox_Mode.Controls.Add(Me.NumericUpDown_GaussianVValue)
        Me.GroupBox_Mode.Controls.Add(Me.Button_SaveExp)
        Me.GroupBox_Mode.Controls.Add(Me.NumericUpDown_GaussianHValue)
        Me.GroupBox_Mode.Controls.Add(Me.CheckBox_MannualFocus)
        Me.GroupBox_Mode.Controls.Add(Me.Button_CalculateHValue)
        Me.GroupBox_Mode.Controls.Add(Me.Label_FocusValue)
        Me.GroupBox_Mode.Controls.Add(Me.Label_ExecuteCount)
        Me.GroupBox_Mode.Controls.Add(Me.Label8)
        Me.GroupBox_Mode.Controls.Add(Me.Label_AutoExposure_Time)
        Me.GroupBox_Mode.Controls.Add(Me.Label7)
        Me.GroupBox_Mode.Controls.Add(Me.Label6)
        Me.GroupBox_Mode.Controls.Add(Me.TextBox_Kp)
        Me.GroupBox_Mode.Controls.Add(Me.Label5)
        Me.GroupBox_Mode.Controls.Add(Me.Label4)
        Me.GroupBox_Mode.Controls.Add(Me.TextBox_ErrorRange)
        Me.GroupBox_Mode.Controls.Add(Me.Label3)
        Me.GroupBox_Mode.Controls.Add(Me.Label_AutoExposure)
        Me.GroupBox_Mode.Controls.Add(Me.Label_ROI_Max)
        Me.GroupBox_Mode.Controls.Add(Me.Button_AutoExposure)
        Me.GroupBox_Mode.Controls.Add(Me.TextBox_MeanTarget)
        Me.GroupBox_Mode.Controls.Add(Me.Button_MannualMean)
        Me.GroupBox_Mode.Controls.Add(Me.Label1)
        Me.GroupBox_Mode.Controls.Add(Me.RadioButton_Manual)
        Me.GroupBox_Mode.Controls.Add(Me.RadioButton_Auto)
        Me.GroupBox_Mode.Controls.Add(Me.Label_ROI_Mean)
        Me.GroupBox_Mode.Name = "GroupBox_Mode"
        Me.GroupBox_Mode.TabStop = False
        '
        'CheckBox_LongCalculateTime
        '
        resources.ApplyResources(Me.CheckBox_LongCalculateTime, "CheckBox_LongCalculateTime")
        Me.CheckBox_LongCalculateTime.Name = "CheckBox_LongCalculateTime"
        Me.CheckBox_LongCalculateTime.UseVisualStyleBackColor = True
        '
        'Label11
        '
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'Label10
        '
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'NumericUpDown_GaussianVValue
        '
        resources.ApplyResources(Me.NumericUpDown_GaussianVValue, "NumericUpDown_GaussianVValue")
        Me.NumericUpDown_GaussianVValue.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_GaussianVValue.Maximum = New Decimal(New Integer() {7000000, 0, 0, 0})
        Me.NumericUpDown_GaussianVValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_GaussianVValue.Name = "NumericUpDown_GaussianVValue"
        Me.NumericUpDown_GaussianVValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Button_SaveExp
        '
        resources.ApplyResources(Me.Button_SaveExp, "Button_SaveExp")
        Me.Button_SaveExp.Name = "Button_SaveExp"
        Me.Button_SaveExp.UseVisualStyleBackColor = True
        '
        'NumericUpDown_GaussianHValue
        '
        resources.ApplyResources(Me.NumericUpDown_GaussianHValue, "NumericUpDown_GaussianHValue")
        Me.NumericUpDown_GaussianHValue.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_GaussianHValue.Maximum = New Decimal(New Integer() {7000000, 0, 0, 0})
        Me.NumericUpDown_GaussianHValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_GaussianHValue.Name = "NumericUpDown_GaussianHValue"
        Me.NumericUpDown_GaussianHValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'CheckBox_MannualFocus
        '
        resources.ApplyResources(Me.CheckBox_MannualFocus, "CheckBox_MannualFocus")
        Me.CheckBox_MannualFocus.Name = "CheckBox_MannualFocus"
        Me.CheckBox_MannualFocus.UseVisualStyleBackColor = True
        '
        'Button_CalculateHValue
        '
        resources.ApplyResources(Me.Button_CalculateHValue, "Button_CalculateHValue")
        Me.Button_CalculateHValue.Name = "Button_CalculateHValue"
        '
        'Label_FocusValue
        '
        resources.ApplyResources(Me.Label_FocusValue, "Label_FocusValue")
        Me.Label_FocusValue.Name = "Label_FocusValue"
        '
        'Label_ExecuteCount
        '
        resources.ApplyResources(Me.Label_ExecuteCount, "Label_ExecuteCount")
        Me.Label_ExecuteCount.Name = "Label_ExecuteCount"
        '
        'Label8
        '
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'Label_AutoExposure_Time
        '
        resources.ApplyResources(Me.Label_AutoExposure_Time, "Label_AutoExposure_Time")
        Me.Label_AutoExposure_Time.Name = "Label_AutoExposure_Time"
        '
        'Label7
        '
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'Label6
        '
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'TextBox_Kp
        '
        resources.ApplyResources(Me.TextBox_Kp, "TextBox_Kp")
        Me.TextBox_Kp.Name = "TextBox_Kp"
        '
        'Label5
        '
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Label4
        '
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'TextBox_ErrorRange
        '
        resources.ApplyResources(Me.TextBox_ErrorRange, "TextBox_ErrorRange")
        Me.TextBox_ErrorRange.Name = "TextBox_ErrorRange"
        '
        'Label3
        '
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'Label_AutoExposure
        '
        resources.ApplyResources(Me.Label_AutoExposure, "Label_AutoExposure")
        Me.Label_AutoExposure.Name = "Label_AutoExposure"
        '
        'Label_ROI_Max
        '
        resources.ApplyResources(Me.Label_ROI_Max, "Label_ROI_Max")
        Me.Label_ROI_Max.Name = "Label_ROI_Max"
        '
        'Button_AutoExposure
        '
        resources.ApplyResources(Me.Button_AutoExposure, "Button_AutoExposure")
        Me.Button_AutoExposure.Name = "Button_AutoExposure"
        Me.Button_AutoExposure.UseVisualStyleBackColor = True
        '
        'TextBox_MeanTarget
        '
        resources.ApplyResources(Me.TextBox_MeanTarget, "TextBox_MeanTarget")
        Me.TextBox_MeanTarget.Name = "TextBox_MeanTarget"
        '
        'Button_MannualMean
        '
        resources.ApplyResources(Me.Button_MannualMean, "Button_MannualMean")
        Me.Button_MannualMean.Name = "Button_MannualMean"
        Me.Button_MannualMean.UseVisualStyleBackColor = True
        '
        'Label1
        '
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'RadioButton_Manual
        '
        resources.ApplyResources(Me.RadioButton_Manual, "RadioButton_Manual")
        Me.RadioButton_Manual.Name = "RadioButton_Manual"
        '
        'RadioButton_Auto
        '
        resources.ApplyResources(Me.RadioButton_Auto, "RadioButton_Auto")
        Me.RadioButton_Auto.Name = "RadioButton_Auto"
        '
        'Label_ROI_Mean
        '
        resources.ApplyResources(Me.Label_ROI_Mean, "Label_ROI_Mean")
        Me.Label_ROI_Mean.Name = "Label_ROI_Mean"
        '
        'CheckBox_ShowBoundary
        '
        resources.ApplyResources(Me.CheckBox_ShowBoundary, "CheckBox_ShowBoundary")
        Me.CheckBox_ShowBoundary.Name = "CheckBox_ShowBoundary"
        '
        'GroupBox_ExposureTime
        '
        resources.ApplyResources(Me.GroupBox_ExposureTime, "GroupBox_ExposureTime")
        Me.GroupBox_ExposureTime.Controls.Add(Me.Button_Save)
        Me.GroupBox_ExposureTime.Controls.Add(Me.Label_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.NumericUpDown_ExposureTime)
        Me.GroupBox_ExposureTime.Controls.Add(Me.TrackBar_ExposureTime)
        Me.GroupBox_ExposureTime.Name = "GroupBox_ExposureTime"
        Me.GroupBox_ExposureTime.TabStop = False
        '
        'Button_Save
        '
        resources.ApplyResources(Me.Button_Save, "Button_Save")
        Me.Button_Save.Name = "Button_Save"
        Me.Button_Save.UseVisualStyleBackColor = True
        '
        'Label_ExposureTime
        '
        resources.ApplyResources(Me.Label_ExposureTime, "Label_ExposureTime")
        Me.Label_ExposureTime.Name = "Label_ExposureTime"
        '
        'NumericUpDown_ExposureTime
        '
        resources.ApplyResources(Me.NumericUpDown_ExposureTime, "NumericUpDown_ExposureTime")
        Me.NumericUpDown_ExposureTime.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Maximum = New Decimal(New Integer() {7000000, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_ExposureTime.Name = "NumericUpDown_ExposureTime"
        Me.NumericUpDown_ExposureTime.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'TrackBar_ExposureTime
        '
        resources.ApplyResources(Me.TrackBar_ExposureTime, "TrackBar_ExposureTime")
        Me.TrackBar_ExposureTime.LargeChange = 10000
        Me.TrackBar_ExposureTime.Maximum = 7000000
        Me.TrackBar_ExposureTime.Minimum = 1
        Me.TrackBar_ExposureTime.Name = "TrackBar_ExposureTime"
        Me.TrackBar_ExposureTime.TickStyle = System.Windows.Forms.TickStyle.None
        Me.TrackBar_ExposureTime.Value = 1
        '
        'Label2
        '
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'ComboBox_PatnList
        '
        resources.ApplyResources(Me.ComboBox_PatnList, "ComboBox_PatnList")
        Me.ComboBox_PatnList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_PatnList.FormattingEnabled = True
        Me.ComboBox_PatnList.Name = "ComboBox_PatnList"
        '
        'GroupBox_ImageSource
        '
        resources.ApplyResources(Me.GroupBox_ImageSource, "GroupBox_ImageSource")
        Me.GroupBox_ImageSource.Controls.Add(Me.Button_Correct_Distortion)
        Me.GroupBox_ImageSource.Controls.Add(Me.CheckBox_ShowBoundary)
        Me.GroupBox_ImageSource.Controls.Add(Me.GroupBox_Grab)
        Me.GroupBox_ImageSource.Controls.Add(Me.Button_Load)
        Me.GroupBox_ImageSource.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GroupBox_ImageSource.Name = "GroupBox_ImageSource"
        Me.GroupBox_ImageSource.TabStop = False
        '
        'Button_Correct_Distortion
        '
        resources.ApplyResources(Me.Button_Correct_Distortion, "Button_Correct_Distortion")
        Me.Button_Correct_Distortion.Name = "Button_Correct_Distortion"
        Me.Button_Correct_Distortion.UseVisualStyleBackColor = True
        '
        'GroupBox_Grab
        '
        resources.ApplyResources(Me.GroupBox_Grab, "GroupBox_Grab")
        Me.GroupBox_Grab.Controls.Add(Me.ComboBox_ColorBand)
        Me.GroupBox_Grab.Controls.Add(Me.Label9)
        Me.GroupBox_Grab.Controls.Add(Me.Button_Grab)
        Me.GroupBox_Grab.Controls.Add(Me.Button_Continue)
        Me.GroupBox_Grab.Name = "GroupBox_Grab"
        Me.GroupBox_Grab.TabStop = False
        '
        'ComboBox_ColorBand
        '
        resources.ApplyResources(Me.ComboBox_ColorBand, "ComboBox_ColorBand")
        Me.ComboBox_ColorBand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_ColorBand.ForeColor = System.Drawing.Color.Red
        Me.ComboBox_ColorBand.FormattingEnabled = True
        Me.ComboBox_ColorBand.Items.AddRange(New Object() {resources.GetString("ComboBox_ColorBand.Items"), resources.GetString("ComboBox_ColorBand.Items1"), resources.GetString("ComboBox_ColorBand.Items2"), resources.GetString("ComboBox_ColorBand.Items3"), resources.GetString("ComboBox_ColorBand.Items4")})
        Me.ComboBox_ColorBand.Name = "ComboBox_ColorBand"
        '
        'Label9
        '
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'Button_Grab
        '
        resources.ApplyResources(Me.Button_Grab, "Button_Grab")
        Me.Button_Grab.Name = "Button_Grab"
        '
        'Button_Continue
        '
        resources.ApplyResources(Me.Button_Continue, "Button_Continue")
        Me.Button_Continue.Name = "Button_Continue"
        '
        'Button_Load
        '
        resources.ApplyResources(Me.Button_Load, "Button_Load")
        Me.Button_Load.Name = "Button_Load"
        '
        'RadioButton_Func
        '
        resources.ApplyResources(Me.RadioButton_Func, "RadioButton_Func")
        Me.RadioButton_Func.Name = "RadioButton_Func"
        Me.RadioButton_Func.UseVisualStyleBackColor = True
        '
        'RadioButton_Mura
        '
        resources.ApplyResources(Me.RadioButton_Mura, "RadioButton_Mura")
        Me.RadioButton_Mura.Name = "RadioButton_Mura"
        Me.RadioButton_Mura.UseVisualStyleBackColor = True
        '
        'Button_Save_ColorRawImage
        '
        resources.ApplyResources(Me.Button_Save_ColorRawImage, "Button_Save_ColorRawImage")
        Me.Button_Save_ColorRawImage.Name = "Button_Save_ColorRawImage"
        Me.Button_Save_ColorRawImage.UseVisualStyleBackColor = True
        '
        'SaveFileDialog
        '
        resources.ApplyResources(Me.SaveFileDialog, "SaveFileDialog")
        '
        'NumericUpDown_LSQHValue
        '
        resources.ApplyResources(Me.NumericUpDown_LSQHValue, "NumericUpDown_LSQHValue")
        Me.NumericUpDown_LSQHValue.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_LSQHValue.Maximum = New Decimal(New Integer() {7000000, 0, 0, 0})
        Me.NumericUpDown_LSQHValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LSQHValue.Name = "NumericUpDown_LSQHValue"
        Me.NumericUpDown_LSQHValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'NumericUpDown_LSQVValue
        '
        resources.ApplyResources(Me.NumericUpDown_LSQVValue, "NumericUpDown_LSQVValue")
        Me.NumericUpDown_LSQVValue.Increment = New Decimal(New Integer() {100, 0, 0, 0})
        Me.NumericUpDown_LSQVValue.Maximum = New Decimal(New Integer() {7000000, 0, 0, 0})
        Me.NumericUpDown_LSQVValue.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown_LSQVValue.Name = "NumericUpDown_LSQVValue"
        Me.NumericUpDown_LSQVValue.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Dialog_ADJMean
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.NumericUpDown_LSQVValue)
        Me.Controls.Add(Me.NumericUpDown_LSQHValue)
        Me.Controls.Add(Me.Button_Save_ColorRawImage)
        Me.Controls.Add(Me.RadioButton_Mura)
        Me.Controls.Add(Me.RadioButton_Func)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox_ExposureTime)
        Me.Controls.Add(Me.ComboBox_PatnList)
        Me.Controls.Add(Me.GroupBox_ImageSource)
        Me.Controls.Add(Me.GroupBox_Mode)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Dialog_ADJMean"
        Me.ShowInTaskbar = False
        Me.GroupBox_Mode.ResumeLayout(False)
        Me.GroupBox_Mode.PerformLayout()
        CType(Me.NumericUpDown_GaussianVValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_GaussianHValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_ExposureTime.ResumeLayout(False)
        Me.GroupBox_ExposureTime.PerformLayout()
        CType(Me.NumericUpDown_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TrackBar_ExposureTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox_ImageSource.ResumeLayout(False)
        Me.GroupBox_Grab.ResumeLayout(False)
        Me.GroupBox_Grab.PerformLayout()
        CType(Me.NumericUpDown_LSQHValue, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown_LSQVValue, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox_Mode As System.Windows.Forms.GroupBox
    Friend WithEvents Button_MannualMean As System.Windows.Forms.Button
    Friend WithEvents Label_ROI_Mean As System.Windows.Forms.Label
    Friend WithEvents GroupBox_ExposureTime As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ComboBox_PatnList As System.Windows.Forms.ComboBox
    Friend WithEvents Button_Save As System.Windows.Forms.Button
    Friend WithEvents Label_ExposureTime As System.Windows.Forms.Label
    Friend WithEvents TrackBar_ExposureTime As System.Windows.Forms.TrackBar
    Friend WithEvents GroupBox_ImageSource As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox_Grab As System.Windows.Forms.GroupBox
    Friend WithEvents Button_Grab As System.Windows.Forms.Button
    Friend WithEvents Button_Continue As System.Windows.Forms.Button
    Friend WithEvents Button_Load As System.Windows.Forms.Button
    Friend WithEvents RadioButton_Manual As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Auto As System.Windows.Forms.RadioButton
    Friend WithEvents TextBox_MeanTarget As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button_AutoExposure As System.Windows.Forms.Button
    Friend WithEvents RadioButton_Func As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton_Mura As System.Windows.Forms.RadioButton
    Friend WithEvents Label_ROI_Max As System.Windows.Forms.Label
    Friend WithEvents Label_AutoExposure As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox_ErrorRange As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label_AutoExposure_Time As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label_ExecuteCount As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents CheckBox_ShowBoundary As System.Windows.Forms.CheckBox
    Friend WithEvents Label_FocusValue As System.Windows.Forms.Label
    Friend WithEvents CheckBox_MannualFocus As System.Windows.Forms.CheckBox
    Friend WithEvents Button_SaveExp As System.Windows.Forms.Button
    Friend WithEvents ComboBox_ColorBand As System.Windows.Forms.ComboBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Button_Correct_Distortion As System.Windows.Forms.Button
    Friend WithEvents Button_Save_ColorRawImage As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog As System.Windows.Forms.SaveFileDialog
    Friend WithEvents TextBox_Kp As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_ExposureTime As System.Windows.Forms.NumericUpDown
    Friend WithEvents Button_CalculateHValue As System.Windows.Forms.Button
    Friend WithEvents NumericUpDown_GaussianHValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_GaussianVValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown_LSQHValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents NumericUpDown_LSQVValue As System.Windows.Forms.NumericUpDown
    Friend WithEvents CheckBox_LongCalculateTime As System.Windows.Forms.CheckBox
End Class
