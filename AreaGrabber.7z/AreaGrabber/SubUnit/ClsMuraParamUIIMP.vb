﻿Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.Threading
Imports System.IO
Imports AUO.SubSystemControl
Imports ClassLibrary

Public Class ClsMuraParamUIIMP

#Region "---Variable---"
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_DialogBoundaryType As DialogBoundaryTypeDefine
    'Private m_IPBootConfig As ClsIPBootConfig
    'Private m_Ever_ContinueGrab As Boolean
    'Private m_Grab_OK As Boolean
    'Private m_ContinueGrab As Boolean
    'Private m_IsCalcFocusValue As Boolean
    'Private m_Thread1_RunCommand As Threading.Thread = Nothing  '「執行命令」執行緒 1
    'Private m_ReadWriteLock As New System.Threading.ReaderWriterLock()
    'Private m_Max_ExposureTime As Integer

    '--- 繪圖 ---
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    'Private m_Pen As Pen
    'Private m_Size As Integer
    ''--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

#End Region

#Region "---Contructor---"
    Public Sub New(ByVal MainFrm As Main_Form)
        Me.m_Form = MainFrm
        Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.ORIGINAL
    End Sub
#End Region

#Region "---Public Method---"
    Public Sub Init()
        Me.m_MainProcess = Me.m_Form.MainProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess

        RemoveHandler Me.m_Form.Button_MuraPrePrcoessPage.Click, AddressOf Button_MuraPrePrcoessPage_Click
        AddHandler Me.m_Form.Button_MuraPrePrcoessPage.Click, AddressOf Button_MuraPrePrcoessPage_Click
        RemoveHandler Me.m_Form.Button_MuraCenterPage.Click, AddressOf Button_MuraCenterPage_Click
        AddHandler Me.m_Form.Button_MuraCenterPage.Click, AddressOf Button_MuraCenterPage_Click
        RemoveHandler Me.m_Form.Button_MuraAroundPage.Click, AddressOf Button_MuraAroundPage_Click
        AddHandler Me.m_Form.Button_MuraAroundPage.Click, AddressOf Button_MuraAroundPage_Click
        RemoveHandler Me.m_Form.Button_MuraBandPage.Click, AddressOf Button_MuraBandPage_Click
        AddHandler Me.m_Form.Button_MuraBandPage.Click, AddressOf Button_MuraBandPage_Click

        RemoveHandler Me.m_Form.Button_MuraPreprocess.Click, AddressOf Button_MuraPreprocess_Click
        AddHandler Me.m_Form.Button_MuraPreprocess.Click, AddressOf Button_MuraPreprocess_Click
        RemoveHandler Me.m_Form.Button_MuraParamSave.Click, AddressOf Button_MuraParamSave_Click
        AddHandler Me.m_Form.Button_MuraParamSave.Click, AddressOf Button_MuraParamSave_Click

        RemoveHandler Me.m_Form.Button_AnalysisMuraBlob.Click, AddressOf Button_AnalysisMuraBlob_Click
        AddHandler Me.m_Form.Button_AnalysisMuraBlob.Click, AddressOf Button_AnalysisMuraBlob_Click

        RemoveHandler Me.m_Form.Button_AnalysisMuraAround.Click, AddressOf Button_AnalysisMuraAround_Click
        AddHandler Me.m_Form.Button_AnalysisMuraAround.Click, AddressOf Button_AnalysisMuraAround_Click

        RemoveHandler Me.m_Form.Button_AnalysisMuraBand.Click, AddressOf Button_AnalysisMuraBand_Click
        AddHandler Me.m_Form.Button_AnalysisMuraBand.Click, AddressOf Button_AnalysisMuraBand_Click

        RemoveHandler Me.m_Form.TreeView_MuraParamPattern.AfterSelect, AddressOf TreeView_MuraParamPattern_AfterSelect
        AddHandler Me.m_Form.TreeView_MuraParamPattern.AfterSelect, AddressOf TreeView_MuraParamPattern_AfterSelect

        RemoveHandler Me.m_Form.Num_ResizeCount_Max.ValueChanged, AddressOf Num_ResizeCount_Max_ValueChanged
        AddHandler Me.m_Form.Num_ResizeCount_Max.ValueChanged, AddressOf Num_ResizeCount_Max_ValueChanged
        RemoveHandler Me.m_Form.Num_ResizeCount_Mid.ValueChanged, AddressOf Num_ResizeCount_Mid_ValueChanged
        AddHandler Me.m_Form.Num_ResizeCount_Mid.ValueChanged, AddressOf Num_ResizeCount_Mid_ValueChanged
        RemoveHandler Me.m_Form.Num_ResizeCount_Mid2.ValueChanged, AddressOf Num_ResizeCount_Mid2_ValueChanged
        AddHandler Me.m_Form.Num_ResizeCount_Mid2.ValueChanged, AddressOf Num_ResizeCount_Mid2_ValueChanged
        RemoveHandler Me.m_Form.Num_ResizeCount_Min.ValueChanged, AddressOf Num_ResizeCount_Min_ValueChanged
        AddHandler Me.m_Form.Num_ResizeCount_Min.ValueChanged, AddressOf Num_ResizeCount_Min_ValueChanged
        '
        RemoveHandler Me.m_Form.CheckBox_AnalysisCenterMuraEnable.CheckedChanged, AddressOf CheckBox_AnalysisCenterMuraEnable_CheckedChanged
        AddHandler Me.m_Form.CheckBox_AnalysisCenterMuraEnable.CheckedChanged, AddressOf CheckBox_AnalysisCenterMuraEnable_CheckedChanged
        RemoveHandler Me.m_Form.CheckBox_AnalysisAroundMuraEnable.CheckedChanged, AddressOf CheckBox_AnalysisAroundMuraEnable_CheckedChanged
        AddHandler Me.m_Form.CheckBox_AnalysisAroundMuraEnable.CheckedChanged, AddressOf CheckBox_AnalysisAroundMuraEnable_CheckedChanged
        RemoveHandler Me.m_Form.CheckBox_AnalysisBandMuraEnable.CheckedChanged, AddressOf CheckBox_AnalysisBandMuraEnable_CheckedChanged
        AddHandler Me.m_Form.CheckBox_AnalysisBandMuraEnable.CheckedChanged, AddressOf CheckBox_AnalysisBandMuraEnable_CheckedChanged
        '
        RemoveHandler Me.m_Form.CheckBox_MuraBandResult.CheckedChanged, AddressOf CheckBox_MuraBandResult_CheckedChanged
        AddHandler Me.m_Form.CheckBox_MuraBandResult.CheckedChanged, AddressOf CheckBox_MuraBandResult_CheckedChanged

        'UI
        Me.ResetUI()

        '
        Me.m_Form.TreeView_MuraParamPattern.TabIndex = 0
        Me.m_Form.ImageUpdate()
        Me.m_Form.ImageZoomAll()

    End Sub

    Public Sub Close()
        Me.m_Form.PaintStop = True
        Me.m_Panel_AxMDisplay.Refresh()
        Me.Finalize()
    End Sub

#End Region

#Region "---Private Method---"

#Region "---ResetUI---"
    Private Sub ResetUI()
        Try
            Dim image As MIL_ID = M_NULL
            Dim mpr As ClsMuraPatternRecipe = Me.m_MuraProcess.CurrentMuraPatternRecipe
            Dim boundary As ClsParameterBoundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound
            Dim GrayLevel_Maximum As Double = 2 ^ Me.m_MainProcess.IPBootConfig.Digitizer_Datadepth.Value - 1
            Dim RoundExpandWidth As Integer = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

            Me.m_Form.TreeView_MuraParamPattern.Nodes.Clear()

            For i As Integer = 0 To Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1
                Dim rootNode As TreeNode = New TreeNode()
                rootNode.Name = "Node_" & Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value
                rootNode.Text = Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value
                Me.m_Form.TreeView_MuraParamPattern.Nodes.Add(rootNode)
            Next

            'If Me.m_Form.GetPatternIndexInfo <> -1 Then
            '    If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex >= Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            '        Me.ComboBox_PatnList.SelectedIndex = 0
            '    Else
            '        Me.ComboBox_PatnList.SelectedIndex = Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex
            '    End If
            'Else
            '    Me.ComboBox_PatnList.SelectedIndex = 0
            '    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
            '    Me.m_MainProcess.SetRecipe(Me.ComboBox_PatnList.Text, Me.m_MainProcess.ErrorCode)
            'End If

            Me.m_AxMDisplay = Me.m_Form.AxMDisplay
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Form.Panel_AxMDisplay.Width, Me.m_Form.Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)

            Select Case Me.m_DialogBoundaryType
                Case DialogBoundaryTypeDefine.FFC
                    'image = Me.m_MuraProcess.Img_CurrentSample_NonPage

                    'If image <> M_NULL Then
                    '    Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("分析影像")
                    '    image = Me.m_MuraProcess.Img_ChildSample
                    '    If image <> M_NULL Then
                    '        Me.ComboBox_Select.Items.Add("亮校正可視區影像")
                    '    End If
                    'Else
                    '    Me.m_Form.ComboBox_Type.SelectedIndex = -1
                    '    Me.DisableOp()
                    'End If

                    'image = Me.m_MuraProcess.Img_CurrentSample_NonPage
                    'If image <> M_NULL Then
                    '    Me.m_Form.CurrentIndex0 = 1
                    '    Me.m_Form.ComboBox_Type.SelectedIndex = 0
                    '    Me.m_Form.ComboBox_Select.SelectedIndex = 1
                    'End If
                Case DialogBoundaryTypeDefine.ORIGINAL
                    image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                    If image <> M_NULL Then
                        image = Me.m_MuraProcess.Img_ChildOriginal
                        'Me.ComboBox_Select.SelectedIndex = Me.ComboBox_Select.Items.Add("分析影像")
                        'If image <> M_NULL Then
                        '    Me.ComboBox_Select.Items.Add("可視區影像")
                        'End If

                        Me.m_Form.CurrentIndex0 = 2
                        Me.m_Form.ComboBox_Type.SelectedIndex = 0
                        Me.m_Form.ComboBox_Select.SelectedIndex = 2

                    Else
                        Me.m_Form.ComboBox_Type.SelectedIndex = -1
                        'Me.DisableOp()
                    End If
            End Select

            'boundary = Me.m_MuraProcess.MuraModelRecipe.Boundary
            'Me.NumericUpDown_BoundaryTop.Maximum = boundary.BottomY - 1
            'Me.NumericUpDown_BoundaryBottom.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 1
            'Me.NumericUpDown_BoundaryBottom.Minimum = boundary.TopY + 1
            'Me.NumericUpDown_BoundaryLeft.Maximum = boundary.RightX - 1
            'Me.NumericUpDown_BoundaryRight.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 1
            'Me.NumericUpDown_BoundaryRight.Minimum = boundary.LeftX + 1

            'If boundary.TopY > Me.NumericUpDown_BoundaryTop.Maximum Then boundary.TopY = Me.NumericUpDown_BoundaryTop.Maximum - 1
            'If boundary.BottomY >= Me.NumericUpDown_BoundaryBottom.Maximum Then boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Maximum - 1
            'If boundary.LeftX > Me.NumericUpDown_BoundaryLeft.Maximum Then boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Maximum - 1
            'If boundary.RightX >= Me.NumericUpDown_BoundaryRight.Maximum Then boundary.RightX = Me.NumericUpDown_BoundaryRight.Maximum - 1

            'If boundary.TopY <= Me.NumericUpDown_BoundaryTop.Minimum Then boundary.TopY = Me.NumericUpDown_BoundaryTop.Minimum
            'If boundary.BottomY <= Me.NumericUpDown_BoundaryBottom.Minimum Then boundary.BottomY = Me.NumericUpDown_BoundaryBottom.Minimum
            'If boundary.LeftX <= Me.NumericUpDown_BoundaryLeft.Minimum Then boundary.LeftX = Me.NumericUpDown_BoundaryLeft.Minimum
            'If boundary.RightX <= Me.NumericUpDown_BoundaryRight.Minimum Then boundary.RightX = Me.NumericUpDown_BoundaryRight.Minimum


            'Me.NumericUpDown_BoundaryTop.Value = boundary.TopY
            'Me.NumericUpDown_BoundaryBottom.Value = boundary.BottomY
            'Me.NumericUpDown_BoundaryLeft.Value = boundary.LeftX
            'Me.NumericUpDown_BoundaryRight.Value = boundary.RightX

            'Me.NumericUpDown_ResultTop.Maximum = boundary.BottomY - 1
            'Me.NumericUpDown_ResultBottom.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeY.Value - 1
            'Me.NumericUpDown_ResultBottom.Minimum = boundary.TopY + 1
            'Me.NumericUpDown_ResultLeft.Maximum = boundary.RightX - 1
            'Me.NumericUpDown_ResultRight.Maximum = Me.m_MainProcess.IPBootConfig.ImageSizeX.Value - 1
            'Me.NumericUpDown_ResultRight.Minimum = boundary.LeftX + 1

            'Me.NumericUpDown_ResultTop.Value = boundary.TopY
            'Me.NumericUpDown_ResultBottom.Value = boundary.BottomY
            'Me.NumericUpDown_ResultLeft.Value = boundary.LeftX
            'Me.NumericUpDown_ResultRight.Value = boundary.RightX

            'Me.m_Form.NumericUpDown_DefocusCount.Value = mpr.DefocusCount.Value
            'Me.m_Form.NumericUpDown_BlobMura_GlobleSmooth.Value = mpr.BlobMura_GlobleSmooth.Value
            'Me.m_Form.NumericUpDown_MacroMura_GlobleSmooth.Value = mpr.MacroMura_GlobleSmooth.Value
            ''Me.m_Form.NumericUpDown_Circle_ByPassRadius.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value

            'Me.m_Form.Num_ResizeCount_Min.Value = mpr.ResizeCount_min.Value
            'Me.m_Form.Num_ResizeCount_Mid.Value = mpr.ResizeCount_mid.Value
            'Me.m_Form.Num_ResizeCount_Mid2.Value = mpr.ResizeCount_mid.Value
            'Me.m_Form.Num_ResizeCount_Max.Value = mpr.ResizeCount_max.Value

            'Me.m_Form.CheckBox_UseBaseLine.Checked = mpr.UseBaseLine.Value
            'Me.m_Form.NumericUpDown_MacroPowerX.Value = mpr.MacroPowerX.Value
            'Me.m_Form.NumericUpDown_MacroPowerY.Value = mpr.MacroPowerY.Value

            'Me.m_Form.CheckBox_RemoveHVBand.Checked = mpr.RemoveHVBand.Value

            'Me.m_Form.NumericUpDown_Circle_ByPassRadius.Value = mpr.Circle_ByPassRadius.Value
            'Me.m_Form.CheckBox_UseFFT.Checked = mpr.UseFFT.Value

            'If Not mpr.UseFFT.Value Then
            '    Me.m_Form.Button_CalculateFFT.Enabled = False
            '    Me.m_Form.NumericUpDown_FFTFilterRadius.Enabled = False
            'End If

            'Me.m_Form.NumericUpDown_FFTFilterRadius.Value = mpr.FFTFilterRadius.Value

            'Me.m_Form.CheckBox_UseFFT.Checked = mpr.UseFFT.Value

            'If Not mpr.UseFFT.Value Then
            '    Me.m_Form.Button_CalculateFFT.Enabled = False
            '    Me.m_Form.NumericUpDown_FFTFilterRadius.Enabled = False
            'End If

            'Me.m_Form.NumericUpDown_FFTFilterRadius.Value = mpr.FFTFilterRadius.Value

            'center blob
            'Me.m_Form.CheckBox_AnalysisCenterMuraEnable.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseCenter.Value
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Minimum = 0
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Minimum = 0
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Minimum = 0
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Minimum = 0

            Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Maximum = RoundExpandWidth
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Maximum = RoundExpandWidth
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Maximum = RoundExpandWidth
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Maximum = RoundExpandWidth


            If Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Maximum < boundary.TopY Then
                boundary.TopY = RoundExpandWidth - 1
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Value = RoundExpandWidth - 1
            Else
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Value = boundary.TopY
            End If
            If Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Maximum < boundary.BottomY Then
                boundary.BottomY = RoundExpandWidth - 1
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Value = RoundExpandWidth - 1
            Else
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Value = boundary.BottomY
            End If
            If Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Maximum < boundary.LeftX Then
                boundary.LeftX = RoundExpandWidth - 1
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Value = RoundExpandWidth - 1
            Else
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Value = boundary.LeftX
            End If
            If Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Maximum < boundary.RightX Then
                boundary.RightX = RoundExpandWidth - 1
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Value = RoundExpandWidth - 1
            Else
                Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Value = boundary.RightX
            End If

            Me.m_Form.NUD_WhiteBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
            Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
            Me.m_Form.NUD_BlackBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
            Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
            Me.m_Form.NUD_WhiteMacroMura_Threshold.Maximum = GrayLevel_Maximum
            Me.m_Form.NUD_BlackMacroMura_Threshold.Maximum = GrayLevel_Maximum

            Me.m_Form.NUD_WhiteBlobMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value
            If (Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value >= Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value) Then
                Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value - 1
            Else
                Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value
            End If
            Me.m_Form.NUD_WhiteMacroMura_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_Threshold.Value

            Me.m_Form.NUD_BlackBlobMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value
            If (Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value >= Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value) Then
                Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value - 1
            Else
                Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value
            End If

            Me.m_Form.NUD_BlackMacroMura_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_Threshold.Value

            Me.m_Form.CheckBox_UseReconstructBW.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseReconstructBW.Value
            '
            Me.m_Form.Button_MuraAroundPage.Enabled = False
            Me.m_Form.Button_MuraCenterPage.Enabled = False
            Me.m_Form.Button_MuraBandPage.Enabled = False

            Me.m_Form.CheckBox_MuraBandResult.Checked = True
            Me.m_Form.ComboBox_SelectMuraBlock.SelectedIndex = 0
            Me.m_Form.ComboBox_MuraBandResult.SelectedIndex = 0
            Me.m_Form.ComboBox_ShowMuraBand.SelectedIndex = 1

        Catch ex As Exception
            Throw New Exception("[Dialog_BlobMuraLocal.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region
#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()
        Dim IsIPConnected As Boolean = False
        Dim IPConnectMsg As String = ""

        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        Dim ip As ClsIPInfo = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPConnectMsg)
        If IsIPConnected = False Or IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region
#Region "---RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region

#Region "--- CalcMuraBoundary ---"
    Private Sub CalcMuraBoundary()
        Dim modelBoundary As ClsParameterBoundary = Me.m_MuraProcess.MuraModelRecipe.Boundary
        Dim boundary As ClsParameterBoundary = Nothing
        Dim boundary2 As ClsParameterBoundary = Nothing
        Dim ResizeRatio As Single
        Dim Parameter_Lists As String = ""
        Dim OutputString As String = ""
        Dim strs1() As String
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        Try
            '--- Button Control ---   
            'Button_Enable(False)

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraBoundary Setting   ==> Request_Command = "DIALOG_MURABOUNDARY_SETTING"  (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURABOUNDARY_SETTING"
                TimeOut = 200000 '200 secs

                Parameter_Lists = "BoundaryTop," & modelBoundary.TopY & ";" & "BoundaryBottom," & modelBoundary.BottomY & ";" & "BoundaryLeft," & modelBoundary.LeftX & ";" & _
                                  "BoundaryRight," & modelBoundary.RightX & ";" & "DefocusCount," & Me.m_Form.NumericUpDown_DefocusCount.Value

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraBoundary Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'If Me.m_FFCOperation Then
                    '    Button_Enable_2(True)
                    'Else
                    '    Button_Enable(True)
                    'End If
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Mura Original Boundary  ==> Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_ORIGINALBOUNDARY"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original Boundary Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'If Me.m_FFCOperation Then
                    '    Button_Enable_2(True)
                    'Else
                    '    Button_Enable(True)
                    'End If
                    'Exit Sub
                End If

                '--- Get ROI Boundary ---
                boundary = Me.m_MuraProcess.BoundaryOriginal
                If Response_OK Then
                    OutputString = SubSystemResult.Responses(0).Param2
                    strs1 = OutputString.Split(";")

                    Select Case Me.m_DialogBoundaryType
                        Case DialogBoundaryTypeDefine.FFC
                            boundary = Me.m_MuraProcess.BoundarySample
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)

                            boundary2 = Me.m_MuraProcess.BoundaryOriginal
                            boundary2.TopY = strs1(0)
                            boundary2.BottomY = strs1(1)
                            boundary2.LeftX = strs1(2)
                            boundary2.RightX = strs1(3)
                        Case DialogBoundaryTypeDefine.ORIGINAL
                            boundary = Me.m_MuraProcess.BoundaryOriginal
                            boundary.TopY = strs1(0)
                            boundary.BottomY = strs1(1)
                            boundary.LeftX = strs1(2)
                            boundary.RightX = strs1(3)
                    End Select

                    '--- Update MuraModelRecipe.Boundary ---
                    boundary2 = Me.m_MuraProcess.MuraModelRecipe.Boundary
                    boundary2.TopY = strs1(0)
                    boundary2.BottomY = strs1(1)
                    boundary2.LeftX = strs1(2)
                    boundary2.RightX = strs1(3)
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '--- Check Boundary ---
            ResizeRatio = 2 ^ Me.m_MuraProcess.MuraModelRecipe.ResizeCount.Value
            If boundary.RightX >= Me.m_MainProcess.IPBootConfig.ImageSizeX.Value / ResizeRatio Then
                boundary.RightX = (Me.m_MainProcess.IPBootConfig.ImageSizeX.Value / ResizeRatio) - 1
            End If
            If boundary.BottomY >= Me.m_MainProcess.IPBootConfig.ImageSizeY.Value / ResizeRatio Then
                boundary.BottomY = (Me.m_MainProcess.IPBootConfig.ImageSizeY.Value / ResizeRatio) - 1
            End If

            If Not Response_OK Then
                MsgBox("邊界分析有誤", MsgBoxStyle.Critical, "[AreaGrabber]")
            Else
                'Me.NumericUpDown_ResultTop.Value = boundary.TopY
                'Me.NumericUpDown_ResultBottom.Value = boundary.BottomY
                'Me.NumericUpDown_ResultLeft.Value = boundary.LeftX
                'Me.NumericUpDown_ResultRight.Value = boundary.RightX
                'Me.CheckBox_ShowResult.Checked = True

                Me.m_Form.OutputInfo("[CalculateMuraBoundary] Complete.")
            End If

            ''--- Button Control ---   
            'If Me.m_FFCOperation Then
            '    Button_Enable_2(True)
            'Else
            '    Button_Enable(True)
            'End If
        Catch ex As Exception
            'If Me.m_FFCOperation Then
            '    Button_Enable_2(True)
            'Else
            '    Button_Enable(True)
            'End If
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Calculate]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Calculate]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

#End Region

#Region "--- CalcMuraSmooth ---"
    Private Sub CalcMuraROI()
        'Dim image As MIL_ID = M_NULL
        Dim muraROI As ClsParameterBoundary = Me.m_MuraProcess.BoundaryOriginal
        Dim InputImage_Type As String = ""
        Dim SaveImage As Boolean = False
        Dim Image_Range As String = ""
        Dim IP_Address As String = ""
        Dim OffsetX, OffsetY As Integer
        Dim SizeX, SizeY, Type As Integer
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        Try
            '--- Initial --- 
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            ''--- Button Control ---   
            'Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value = Me.m_Form.NumericUpDown_DefocusCount.Value

            '----------------------------------------------------------------------------------------------
            ' Calculate Mura Original ROI Image  ==> Request_Command = "CALCULATE_MURA_ORIGINALROI" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_ORIGINALROI"
                TimeOut = 300000 '300 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Mura Original ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'If Me.m_FFCOperation Then
                    '    Button_Enable_2(True)
                    'Else
                    '    Button_Enable(True)
                    'End If

                    Exit Sub
                End If

                If Response_OK Then
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        '[1] Me.m_MuraProcess.Img_ChildSample
                        If Me.m_MuraProcess.Img_ChildSample <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_ChildSample)
                            Me.m_MuraProcess.Img_ChildSample = M_NULL
                        End If

                        OffsetX = muraROI.LeftX
                        OffsetY = muraROI.TopY
                        SizeX = muraROI.RightX - muraROI.LeftX
                        SizeY = muraROI.BottomY - muraROI.TopY
                        Me.m_MuraProcess.Img_ChildSample = MbufChild2d(Me.m_MuraProcess.Img_CurrentSample_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)
                    Else
                        '[1] Me.m_MuraProcess.Img_ChildOriginal
                        If Me.m_MuraProcess.Img_ChildOriginal <> M_NULL Then
                            MbufFree(Me.m_MuraProcess.Img_ChildOriginal)
                            Me.m_MuraProcess.Img_ChildOriginal = M_NULL
                        End If

                        OffsetX = muraROI.LeftX
                        OffsetY = muraROI.TopY
                        SizeX = muraROI.RightX - muraROI.LeftX
                        SizeY = muraROI.BottomY - muraROI.TopY
                        Me.m_MuraProcess.Img_ChildOriginal = MbufChild2d(Me.m_MuraProcess.Img_CurrentOriginal_NonPage, OffsetX, OffsetY, SizeX, SizeY, M_NULL)
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.m_MuraProcess.Mura_CreateImage(Me.m_MainProcess.IPBootConfig, Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MuraProcess.MuraModelRecipe, Me.m_MainProcess.ErrorCode)   '09/22 Rick add
            'If Me.ComboBox_Select.Items.Count = 1 Then
            '    Me.ComboBox_Select.Items.Add("可視區影像")
            'End If

            '----------------------------------------------------------------------------------------------
            ' Create Mura Image  ==> Request_Command = "CALCULATE_MURA_CREATEIMAGE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_MURA_CREATEIMAGE"
                TimeOut = 200000 '200 secs
                Image_Range = "PART"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Image_Range, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Create Mura Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'If Me.m_FFCOperation Then
                    '    Button_Enable_2(True)
                    'Else
                    '    Button_Enable(True)
                    'End If
                    'Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            '2009/03/28 Rick modify ---
            If Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.ORIGINAL Then

                '----------------------------------------------------------------------------------------------
                ' Calculate ROI Expand Image  ==> Request_Command = "CALCULATE_ROIEXPAND" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_ROIEXPAND"
                    TimeOut = 200000 '200 secs
                    InputImage_Type = "CHILD_ORIGINAL"

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate ROI Expand Image  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        'If Me.m_FFCOperation Then
                        '    Button_Enable_2(True)
                        'Else
                        '    Button_Enable(True)
                        'End If
                        Exit Sub
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 200000 '200 secs
                    InputImage_Type = "CHILD_ORIGINAL"
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        'If Me.m_FFCOperation Then
                        '    Button_Enable_2(True)
                        'Else
                        '    Button_Enable(True)
                        'End If
                        Exit Sub
                    End If

                    If SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image 
                        Dim strPath as String = String.Empty
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            ElseIf Me.m_DialogBoundaryType = DialogBoundaryTypeDefine.FFC Then

                '----------------------------------------------------------------------------------------------
                ' Calculate Defocus Image  ==> Request_Command = "CALCULATE_DEFOCUS" (Dispatcher 2)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "CALCULATE_DEFOCUS"
                    TimeOut = 100000 '100 secs
                    InputImage_Type = "NONE"
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, InputImage_Type, SaveImage, , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Defocus Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        'If Me.m_FFCOperation Then
                        '    Button_Enable_2(True)
                        'Else
                        '    Button_Enable(True)
                        'End If
                        Exit Sub
                    End If

                    If SaveImage AndAlso Response_OK Then
                        '--- Update Processed Image ---
                        Dim strPath As String = String.Empty
                        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                            strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_ChildDefocus.tif"
                            strPath = strPath.Replace("\\", "\")
                        Else
                            strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_ChildDefocus.tif"
                            Me.RepairPath_2(strPath)
                        End If

                        If System.IO.File.Exists(strPath) Then
                            MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                            MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                            MbufDiskInquire(strPath, M_TYPE, Type)
                            If Me.m_MuraProcess.Img_16U_Defocus_NonPage <> M_NULL Then
                                If MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                    MbufFree(Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = M_NULL
                                    Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If
                            Else
                                Me.m_MuraProcess.Img_16U_Defocus_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If

                            '--- Load Remote Image ---
                            MbufLoad(strPath, Me.m_MuraProcess.Img_16U_Defocus_NonPage)
                            'MbufCopy(image, Me.m_MuraProcess.Img_16U_Defocus_NonPage)

                            If System.IO.File.Exists(strPath) = True Then
                                System.IO.File.Delete(strPath)
                            End If
                        End If
                    End If

                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            End If

            If Response_OK Then
                'Me.m_Form.CurrentIndex1 = 19
                'Me.m_Form.ComboBox_Type.SelectedIndex = 1
                'Me.m_Form.ComboBox_Select.SelectedIndex = 19
                'Me.m_Form.ImageUpdate()
                'Me.m_Form.ImageZoomAll()
            End If

            ''--- Button Control ---   
            'If Me.m_FFCOperation Then
            '    Button_Enable_2(True)
            'Else
            '    Button_Enable(True)
            'End If

            Me.m_Form.OutputInfo("[CalculateMuraROI] Complete.")
        Catch ex As Exception
            'If Me.m_FFCOperation Then
            '    Button_Enable_2(True)
            'Else
            '    Button_Enable(True)
            'End If
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Split]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Split]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'Me.Update() 'MuraBoundary Form-> Update
    End Sub
#End Region

#Region "--- AnalysisMuraAround ---"
    Private Sub AnalysisCenterMuraBlob()
        Dim mpr As ClsMuraPatternRecipe
        Dim RefX As Integer
        Dim RefY As Integer
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim RoundExpandWidth As Integer
        Dim strPath As String = ""
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            '--- Disable Button ---  
            'Button_Save.Enabled = False
            'Button_Cancel.Enabled = False

            '--- Setting ---
            Me.Setting()
            '---Set local Value---
            mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe

            '----------------------------------------------------------------------------------------------
            ' Dialog_BlobMuraLocal Setting   ==> Request_Command = "DIALOG_BLOBMURALOCAL_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_BLOBMURALOCAL_SETTING"
                TimeOut = 100000 '100 secs
                Parameter_Lists = "AreaTop," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Value & ";" & "AreaBottom," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Value & ";" & "AreaLeft," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Value & ";" & "AreaRight," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Value & ";" & _
                                  "WhiteBlobMura_ReconstructHeight," & mpr.WhiteBlobMura_BinarizeHeight.Value & ";" & "WhiteBlobMura_ReconstructLow," & mpr.WhiteBlobMura_BinarizeLow.Value & ";" & "WhiteMacroMura_Threshold," & mpr.WhiteMacroMura_Threshold.Value & ";" & _
                                  "BlackBlobMura_ReconstructHeight," & mpr.BlackBlobMura_BinarizeHeight.Value & ";" & "BlackBlobMura_ReconstructLow," & mpr.BlackBlobMura_BinarizeLow.Value & ";" & "BlackMacroMura_Threshold," & mpr.BlackMacroMura_Threshold.Value & ";" & _
                                  "UseReconstructBW," & mpr.UseReconstructBW.Value & ";"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraLocal Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '---------------------------------------------------------------------------------------------------------------------------------
            '--- 取得Golden影像 ---
            '----------------------------------------------------------------------------------------------
            ' Calculate Area Golden Sample Image  ==> Request_Command = "CALCULATE_AREA_GOLDENSAMPLE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_AREA_GOLDENSAMPLE"
                TimeOut = 200000 '200 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Area Golden Sample Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then

                    RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

                    'Blob Mura ---
                    '[1] Update Processed Image (Img_16U_BlobMura_ResizeH_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeH_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_BlobMura_ResizeHChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild)
                            Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeHChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 2
                        'Me.UpdateSelectdImage()

                    End If

                    '[3] Update Processed Image (Img_16U_BlobMura_ResizeL_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_ResizeL_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[4] Update Processed Image (Img_BlobMura_ResizeLChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild)
                            Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_BlobMura_ResizeLChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 3
                        'Me.UpdateSelectdImage()
                    End If

                    'Macro Mura ---
                    '[1] Update Processed Image (Img_16U_MacroMura_ResizeH_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeH_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_MacroMura_ResizeHChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeHChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeH_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)


                        'Me.ComboBox_Select.SelectedIndex = 4
                        'Me.UpdateSelectdImage()
                    End If

                    '[3] Update Processed Image (Img_16U_MacroMura_ResizeL_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_ResizeL_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[4] Update Processed Image (Img_MacroMura_ResizeLChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild = M_NULL
                        End If
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        Me.m_MainProcess.MuraProcess.Img_MacroMura_ResizeLChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_ResizeL_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)


                        'Me.ComboBox_Select.SelectedIndex = 5
                        'Me.UpdateSelectdImage()
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '---------------------------------------------------------------------------------------------------------------------------------

            '--- 取得相減影像 ---
            '----------------------------------------------------------------------------------------------
            ' Calculate White Area Image  ==> Request_Command = "CALCULATE_WHITE_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_WHITE_AREA"
                TimeOut = 200000 '200 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

                If Response_OK Then
                    '[1] Update Processed Image (Img_16U_BlobMura_White_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If

                    '[2] Update Processed Image (Img_BlobMuraArea_WhiteChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild)
                        Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                    'Me.ComboBox_Select.SelectedIndex = 6
                    'Me.UpdateSelectdImage()
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Black Area Image  ==> Request_Command = "CALCULATE_BLACK_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_BLACK_AREA"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

                If Response_OK Then
                    '[1] Update Processed Image (Img_16U_BlobMura_Black_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_BlobMuraArea_BlackChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild)
                            Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = M_NULL
                        End If

                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If

                        Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 7
                        'Me.UpdateSelectdImage()

                    End If

                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate White Macro Image  ==> Request_Command = "CALCULATE_WHITE_MACRO" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_WHITE_MACRO"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_16U_MacroMura_White_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_White_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_MacroMura_WhiteChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild = M_NULL
                        End If

                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If

                        Me.m_MainProcess.MuraProcess.Img_MacroMura_WhiteChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                    End If

                    'Me.ComboBox_Select.SelectedIndex = 8
                    'Me.UpdateSelectdImage()
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Black Macro Image  ==> Request_Command = "CALCULATE_BLACK_MACRO" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_BLACK_MACRO"
                TimeOut = 100000 '100 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Macro Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_16U_MacroMura_Black_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Black_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage)

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                        '[2] Update Processed Image (Img_MacroMura_BlackChild) ---
                        If Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild <> M_NULL Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild)
                            Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild = M_NULL
                        End If

                        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                        Else
                            SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                            SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                        End If

                        Me.m_MainProcess.MuraProcess.Img_MacroMura_BlackChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_MacroMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                        'Me.ComboBox_Select.SelectedIndex = 9
                        'Me.UpdateSelectdImage()
                    End If

                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            'Me.GroupBox_Modify.Enabled = True
            'Me.GroupBox_Parameter.Enabled = True
            'Me.CheckBox_Show.Checked = True

            '---------------------------------------------------------------------------------------------------------------------------------
            '--- 找可視區Blob Mura ---
            '----------------------------------------------------------------------------------------------
            ' Calculate Black Blob Mura (Area-中心區)  ==> Request_Command = "CALCULATE_BLACKBLOB_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_BLACKBLOB_AREA"
                TimeOut = 500000 '500 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_1U_BlackReconstructArea_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructArea_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructArea_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 10
                        'Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                    End If

                    '[2] Update Processed Image (Img_1U_BlackThreshold_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackThreshold_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_BlackThreshold_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 11
                        'Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If

                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate White Blob Mura (Area-中心區)  ==> Request_Command = "CALCULATE_WHITEBLOB_AREA" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "CALCULATE_WHITEBLOB_AREA"
                TimeOut = 500000 '500 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Blob Mura  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image (Img_1U_WhiteReconstructArea_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructArea_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructArea_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 12
                        'Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If

                    '[2] Update Processed Image (Img_1U_WhiteThreshold_NonPage) ---
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteThreshold_NonPage.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage <> M_NULL Then
                            If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage)
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage = M_NULL
                                Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_WhiteThreshold_NonPage)

                        'Me.ComboBox_Select.SelectedIndex = 13
                        'Me.UpdateSelectdImage()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Calculate Position shift in Mura_Local  ==> Request_Command = "POSITIONSHIFT_MURALOCAL" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "POSITIONSHIFT_MURALOCAL"
                TimeOut = 100000 '100 secs

                RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
                RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RefX, RefY, , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Position shift in Mura_Local  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            Me.m_MuraProcess.HavePositionShift_Round = True
            '----------------------------------------------------------------------------------------------------------------------------------

            'If CheckBox_Show.Checked Then Me.ReDraw()

            '--- Button Control ---   
            'Button_Enable(True)
        Catch ex As Exception
            'Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraSetting.Button_CalculateBlob]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraLocal.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "--- AnalysisMuraAround ---"
    Private Sub AnalysisMuraAround()
        Dim mp As ClsMuraProcess
        Dim mpr As ClsMuraPatternRecipe
        Dim RefX As Integer
        Dim RefY As Integer
        Dim errMsg As String = ""
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim strPath As String = ""
        Dim RoundExpandWidth As Integer = 0
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Setting ---
        Me.Setting()
        '---Set local Value---
        mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
        mp = Me.m_MuraProcess

        RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdLow.Value = Me.m_Form.NumericUpDown_BlackMura_ReconstructLow.Value

        '--- Button Control ---   
        'Button_Enable(False)

        '----------------------------------------------------------------------------------------------
        ' Dialog_BlobMuraRound Setting   ==> Request_Command = "DIALOG_BLOBMURAROUND_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BLOBMURAROUND_SETTING"
            TimeOut = 100000 '100 secs
            Parameter_Lists = "RimTop," & Me.m_Form.NumericUpDown_RimTop.Value & ";" & "RimBottom," & Me.m_Form.NumericUpDown_RimBottom.Value & ";" & "RimLeft," & Me.m_Form.NumericUpDown_RimLeft.Value & ";" & "RimRight," & Me.m_Form.NumericUpDown_RimRight.Value & ";" & _
                              "WhiteMura_ReconstructHeight," & mpr.WhiteMura_ThresholdHeight.Value & ";" & "WhiteMura_ReconstructLow," & mpr.WhiteMura_ThresholdLow.Value & ";" & _
                              "BlackMura_ReconstructHeight," & mpr.BlackMura_ThresholdHeight.Value & ";" & "BlackMura_ReconstructLow," & mpr.BlackMura_ThresholdLow.Value & ";"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraRound Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Dialog_BlobMuraRound Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Area Golden Sample Image  ==> Request_Command = "CALCULATE_AREA_GOLDENSAMPLE" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_AREA_GOLDENSAMPLE"
            TimeOut = 100000 '100 secs
            SaveImage = False

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Area Golden Sample Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Area Golden Sample Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate White Area Image  ==> Request_Command = "CALCULATE_WHITE_AREA" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_WHITE_AREA"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, Me.m_Form.CheckBox_WhiteRimBlobValue.Checked, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

            If Response_OK Then
                '[1] Update Processed Image (Img_16U_BlobMura_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = M_NULL
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_BlobMuraArea_WhiteChild) ---
                If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild <> M_NULL Then
                    MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild)
                    Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = M_NULL
                End If

                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                Else
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                End If

                Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_WhiteChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_White_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

            End If

        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate White Area Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Black Area Image  ==> Request_Command = "CALCULATE_BLACK_AREA" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLACK_AREA"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, Me.m_Form.CheckBox_BlackRimBlobValue.Checked, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Area Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

            If Response_OK Then
                '[1] Update Processed Image (Img_16U_BlobMura_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = M_NULL
                            Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    '[2] Update Processed Image (Img_BlobMuraArea_BlackChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild)
                        Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_BlobMuraArea_BlackChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_16U_BlobMura_Black_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)
                End If

            End If

        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Black Area Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


        '-----------影像處理 -----------------
        '計算Reconstuct White \Black 影像 for Round ---
        '----------------------------------------------------------------------------------------------
        ' Calculate Reconstruct Rim Image  ==> Request_Command = "CALCULATE_RECONSTRUCT_RIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_RECONSTRUCT_RIM"
            TimeOut = 500000 '500 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Reconstruct Rim Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '--- White Reconstruct Rim ---

                '[1] Update Processed Image (Img_1U_WhiteReconstructRim_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_WhiteReconstructRim_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)
                            Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_WhiteReconstructRim_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    '[2] Update Processed Image (Img_WhiteReconstructRImChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild)
                        Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_WhiteReconstructRImChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_1U_WhiteReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                End If

                'Black Reconstruct Rim ---

                '[1] Update Processed Image (Img_1U_BlackReconstructRim_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_BlackReconstructRim_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage)
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage = M_NULL
                            Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    '[2] Update Processed Image (Img_BlackReconstructRimChild) ---
                    If Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild <> M_NULL Then
                        MbufFree(Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild)
                        Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild = M_NULL
                    End If

                    If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                    Else
                        SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                        SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                    End If

                    Me.m_MainProcess.MuraProcess.Img_BlackReconstructRimChild = MbufChild2d(Me.m_MainProcess.MuraProcess.Img_1U_BlackReconstructRim_NonPage, RoundExpandWidth, RoundExpandWidth, SizeX, SizeY, M_NULL)

                End If

            End If
        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Reconstruct Rim Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '-------------------------------------------------------------------------------------------------------------------------------
        '影像資料處理 ---

        RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
        RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

        ''計算邊緣Blob Mura --- 
        '----------------------------------------------------------------------------------------------
        ' Calculate Black Rim Mura  ==> Request_Command = "CALCULATE_BLACKBLOB_RIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLACKBLOB_RIM"
            TimeOut = 500000 '500 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Black Rim Mura Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate White Rim Mura  ==> Request_Command = "CALCULATE_WHITEBLOB_RIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_WHITEBLOB_RIM"
            TimeOut = 500000 '500 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Rim Mura Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate White Rim Mura Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Position shift in Mura_Rim  ==> Request_Command = "POSITIONSHIFT_MURARIM" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "POSITIONSHIFT_MURARIM"
            TimeOut = 200000 '200 secs

            RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
            RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RefX, RefY, , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Position shift in Mura_Rim  Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_CalculateBlob]Calculate Position shift in Mura_Rim  Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_CalculateBlob]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------------------------------------------

        'Me.CheckBox_Show.Checked = True
        'Me.m_Blob = True
        'Me.Button_Enable(True)

        'Me.ComboBox_Select.SelectedIndex = Me.m_CurrentMuraIndex
        'Me.UpdateSelectdImage()
        'Me.m_Form.ImageZoomAll()
        'Me.UpdateUserLevel()
        'If CheckBox_Show.Checked Then Me.ReDraw()

        '----------------------------------------------------------------------------------------------------------------------------------
    End Sub
#End Region

#Region "--- AnalysisMuraBand ---"
    Private Sub AnalysisMuraBand()
        Dim mpr As ClsMuraPatternRecipe
        Dim image As MIL_ID = M_NULL
        Dim RefX As Integer
        Dim RefY As Integer
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim RoundExpandWidth As Integer
        Dim strPath_HBand_White As String = ""
        Dim strPath_HBand_Black As String = ""
        Dim strPath_VBand_White As String = ""
        Dim strPath_VBand_Black As String = ""
        Dim V_MulRatio As Double
        Dim H_MulRatio As Double
        Dim MulMin As Double
        Dim strPath As String = ""

        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
        '--- Setting ---
        Me.Setting()
        'Set local Value
        mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe

        '--- Disable Button ---
        'Me.Button_Enable(False)

        RefX = Me.m_MuraProcess.MuraModelRecipe.Boundary.LeftX
        RefY = Me.m_MuraProcess.MuraModelRecipe.Boundary.TopY

        '---Delete Result Image---
        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
            strPath_HBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            strPath_HBand_White = strPath_HBand_White.Replace("\\", "\")
            strPath_HBand_Black = strPath_HBand_Black.Replace("\\", "\")
            strPath_VBand_White = strPath_VBand_White.Replace("\\", "\")
            strPath_VBand_Black = strPath_VBand_Black.Replace("\\", "\")
        Else
            strPath_HBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.bmp"
            strPath_HBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            strPath_VBand_White = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.bmp"
            strPath_VBand_Black = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.RepairPath_2(strPath_HBand_White)
            Me.RepairPath_2(strPath_HBand_Black)
            Me.RepairPath_2(strPath_VBand_White)
            Me.RepairPath_2(strPath_VBand_Black)
        End If

        If System.IO.File.Exists(strPath_HBand_White) Then
            System.IO.File.Delete(strPath_HBand_White)
        End If
        If System.IO.File.Exists(strPath_HBand_Black) Then
            System.IO.File.Delete(strPath_HBand_Black)
        End If
        If System.IO.File.Exists(strPath_VBand_White) Then
            System.IO.File.Delete(strPath_VBand_White)
        End If
        If System.IO.File.Exists(strPath_VBand_Black) Then
            System.IO.File.Delete(strPath_VBand_Black)
        End If
        '----------------------------------------------------------------------------------------------
        ' Dialog_BandMura Setting   ==> Request_Command = "DIALOG_BANDMURA_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BANDMURA_SETTING"
            TimeOut = 100000 '100 secs

            Parameter_Lists = "HTop," & Me.m_Form.NumericUpDown_HTop.Value & ";" & "HBottom," & Me.m_Form.NumericUpDown_HBottom.Value & ";" & "HLeft," & Me.m_Form.NumericUpDown_HLeft.Value & ";" & "HRight," & Me.m_Form.NumericUpDown_HRight.Value & ";" & _
                              "VTop," & Me.m_Form.NumericUpDown_VTop.Value & ";" & "VBottom," & Me.m_Form.NumericUpDown_VBottom.Value & ";" & "VLeft," & Me.m_Form.NumericUpDown_VLeft.Value & ";" & "VRight," & Me.m_Form.NumericUpDown_VRight.Value & ";" & _
                              "BandMura_ResizeCount," & mpr.BandMura_ResizeCount.Value & ";" & "BandMura_SmoothCount," & mpr.BandMura_SmoothCount.Value & ";" & _
                              "WhiteHBand_Threshold," & mpr.WhiteHBand_Threshold.Value & ";" & "BlackHBand_Threshold," & mpr.BlackHBand_Threshold.Value & ";" & _
                              "WhiteVBand_Threshold," & mpr.WhiteVBand_Threshold.Value & ";" & "BlackVBand_Threshold," & mpr.BlackVBand_Threshold.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BandMura Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Dialog_BandMura Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
            Exit Sub
        End Try

        '------割取影像-----------------------------------------------------------------------------------------------------

        '----------------------------------------------------------------------------------------------
        ' Calculate H-Band Mura ROI Image  ==> Request_Command = "CALCULATE_HROI" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_HROI"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_BandMura_ChildOriginalH.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_BandMura_ChildOriginalH.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_BandMura_ChildOriginalH <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalH, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalH, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalH)
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalH = M_NULL
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_BandMura_ChildOriginalH)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

            'If Response_OK Then
            '    '[1] Update Processed Image (Img_BandMura_ChildOriginalH) ---
            '    RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
            '    If Me.m_MuraProcess.Img_BandMura_ChildOriginalH <> M_NULL Then
            '        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalH)
            '        Me.m_MuraProcess.Img_BandMura_ChildOriginalH = M_NULL
            '    End If
            '    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.BottomY - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.TopY - 2 * RoundExpandWidth
            '    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX - Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.RightX - 2 * RoundExpandWidth

            '    'While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
            '    '    SizeX = SizeX - 1
            '    'End While

            '    'While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)
            '    '    SizeY = SizeY - 1
            '    'End While

            '    Me.m_MuraProcess.Img_BandMura_ChildOriginalH = MbufChild2d(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand.TopY, SizeX, SizeY, M_NULL)
            'End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate H-Band Mura ROI Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
            Exit Sub
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate V-Band Mura ROI Image  ==> Request_Command = "CALCULATE_VROI" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_VROI"
            TimeOut = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura ROI Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_BandMura_ChildOriginalV.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_BandMura_ChildOriginalV.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_BandMura_ChildOriginalV <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalV, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_BandMura_ChildOriginalV, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalV)
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalV = M_NULL
                            Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_BandMura_ChildOriginalV)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

            'If Response_OK Then
            '    '[1] Update Processed Image (Img_BandMura_ChildOriginalV) ---
            '    RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
            '    If Me.m_MuraProcess.Img_BandMura_ChildOriginalV <> M_NULL Then
            '        MbufFree(Me.m_MuraProcess.Img_BandMura_ChildOriginalV)
            '        Me.m_MuraProcess.Img_BandMura_ChildOriginalV = M_NULL
            '    End If

            '    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.BottomY - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.TopY - 2 * RoundExpandWidth
            '    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL) - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX - Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.RightX - 2 * RoundExpandWidth

            '    'While (SizeX Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
            '    '    SizeX = SizeX - 1
            '    'End While

            '    'While (SizeY Mod 2 ^ Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value <> 0)  '2015/03/23 Rick modify
            '    '    SizeY = SizeY - 1
            '    'End While

            '    Me.m_MuraProcess.Img_BandMura_ChildOriginalV = MbufChild2d(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX, RoundExpandWidth + Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand.TopY, SizeX, SizeY, M_NULL)
            'End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate V-Band Mura ROI Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
            Exit Sub
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate H-Band Mura Projection Image  ==> Request_Command = "CALCULATE_HBAND_PROJECT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_HBAND_PROJECT"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HProject_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HProject_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HProject_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HProject_NonPage)
                            Me.m_MuraProcess.Img_16U_HProject_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HProject_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate H-Band Mura Projection Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
            Exit Sub
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate V-Band Mura Projection Image  ==> Request_Command = "CALCULATE_VBAND_PROJECT" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_VBAND_PROJECT"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Mura Projection Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_VProject_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VProject_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VProject_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VProject_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VProject_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VProject_NonPage)
                            Me.m_MuraProcess.Img_16U_VProject_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VProject_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VProject_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate V-Band Mura Projection Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
            Exit Sub
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Golden H-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_H" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_GOLDEN_H"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden H-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HGolden_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HGolden_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HGolden_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HGolden_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HGolden_NonPage)
                            Me.m_MuraProcess.Img_16U_HGolden_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HGolden_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate Golden H-Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
            Exit Sub
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Golden V-Band Image  ==> Request_Command = "CALCULATE_GOLDEN_V" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_GOLDEN_V"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Golden V-Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_VGolden_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VGolden_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VGolden_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VGolden_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VGolden_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VGolden_NonPage)
                            Me.m_MuraProcess.Img_16U_VGolden_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VGolden_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VGolden_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate Golden V-Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
            Exit Sub
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate White Band Image  ==> Request_Command = "CALCULATE_WHITE_BAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_WHITE_BAND"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate White Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HBand_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HBand_White_NonPage)
                            Me.m_MuraProcess.Img_16U_HBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_16U_VBand_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VBand_White_NonPage)
                            Me.m_MuraProcess.Img_16U_VBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate White Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Black Band Image  ==> Request_Command = "CALCULATE_BLACK_BAND" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_BLACK_BAND"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Black Band Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_16U_HBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_HBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_HBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_HBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)
                            Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_HBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_16U_VBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_VBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_VBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_VBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)
                            Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_VBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate Black Band Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate V-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_V_BAND" (Dispatcher 2)
        ' 此函數功能包括計算出 Band Mura結果，但目前沒有從IP傳回結果，視需要傳回。
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_V_BAND"
            TimeOut = 500000 '500 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate V-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_1U_VBand_White_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_VBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_VBand_White_NonPage)
                            Me.m_MuraProcess.Img_1U_VBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_VBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_1U_VBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_VBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)
                            Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_VBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_VBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                'Update VValue
                'Me.m_Form.NumericUpDown_VValue.Value = SubSystemResult.Responses(0).Param2
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate V-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate H-Band Threshold (White\Black) Image  ==> Request_Command = "CALCULATE_H_BAND" (Dispatcher 2)
        ' 此函數功能包括計算出 Band Mura結果，但目前沒有從IP傳回結果，視需要傳回。
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_H_BAND"
            TimeOut = 500000 '500 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate H-Band Threshold (White\Black) Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Band]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] Update Processed Image (Img_1U_HBand_White_NonPage) ---
                image = Me.m_MuraProcess.Img_1U_HBand_White_NonPage
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_HBand_White_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_White_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_HBand_White_NonPage)
                            Me.m_MuraProcess.Img_1U_HBand_White_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_HBand_White_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_White_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] Update Processed Image (Img_1U_HBand_Black_NonPage) ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_1U_HBand_Black_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)
                            Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = M_NULL
                            Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_1U_HBand_Black_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_1U_HBand_Black_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                'Me.NumericUpDown_HValue.Value = SubSystemResult.Responses(0).Param2

            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Band]Calculate H-Band Threshold (White\Black) Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Band]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Me.Button_Enable(True)
        End Try

        'Me.Button_Enable(True)
        'Me.m_MuraProcess.PositionShift_MuraBand(RefX, RefY)   '當有從IP傳回結果，此行需打開

        'If Me.ComboBox_Select.Items.Count = 7 Then
        '    Me.ComboBox_Select.Items.Add("水平White Band影像")
        '    Me.ComboBox_Select.Items.Add("水平Black Band影像")
        '    Me.ComboBox_Select.Items.Add("垂直White Band影像")
        '    Me.ComboBox_Select.Items.Add("垂直Black Band影像")
        '    Me.ComboBox_Select.Items.Add("水平Band影像處理(亮-Threshold)")
        '    Me.ComboBox_Select.Items.Add("水平Band影像處理(暗-Threshold)")
        '    Me.ComboBox_Select.Items.Add("垂直Band影像處理(亮-Threshold)")
        '    Me.ComboBox_Select.Items.Add("垂直Band影像處理(暗-Threshold)")
        '    If Me.ComboBox_Select.Items.Count >= 14 Then Me.ComboBox_Select.SelectedIndex = 14
        'End If

        '---Modify Picturebox Location & Size
        'SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL)
        'SizeX = SizeX - (2 * RoundExpandWidth)
        'V_MulRatio = Me.m_Form.Panel_AxMDisplay.Width / SizeX
        'SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL)
        'SizeY = SizeY - (2 * RoundExpandWidth)
        'H_MulRatio = Me.m_Form.Panel_AxMDisplay.Height / SizeY
        'MulMin = Math.Min(V_MulRatio, H_MulRatio)
        'SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL)
        'SizeX = SizeX - (2 * RoundExpandWidth)
        'SizeX = (SizeX - Me.NumericUpDown_VLeft.Value - Me.NumericUpDown_VRight.Value) * MulMin
        'SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL)
        'SizeY = SizeY - (2 * RoundExpandWidth)
        'SizeY = (SizeY - Me.NumericUpDown_HTop.Value - Me.NumericUpDown_HBottom.Value) * MulMin
        'Me.m_Form.PictureBox_VBand_White.Left = Me.m_Form.Panel_AxMDisplay.Left + Me.NumericUpDown_VLeft.Value * MulMin
        'Me.m_Form.PictureBox_VBand_White.Size = New Size(SizeX, 48)
        'Me.m_Form.PictureBox_VBand_Black.Left = Me.m_Form.Panel_AxMDisplay.Left + Me.NumericUpDown_VLeft.Value * MulMin
        'Me.m_Form.PictureBox_VBand_Black.Size = New Size(SizeX, 48)
        'Me.m_Form.PictureBox_HBand_White.Top = Me.m_Form.Panel_AxMDisplay.Top + Me.NumericUpDown_HTop.Value * MulMin
        'Me.m_Form.PictureBox_HBand_White.Size = New Size(55, SizeY)
        'Me.m_Form.PictureBox_HBand_Black.Top = Me.m_Form.Panel_AxMDisplay.Top + Me.NumericUpDown_HTop.Value * MulMin
        'Me.m_Form.PictureBox_HBand_Black.Size = New Size(55, SizeY)

        '---Update Result Image---
        If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
            Me.m_Form.PictureBox_HBand_Black.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_HBand_White.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_HBand_White_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_Black.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_White.ImageLocation = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_1U_VBand_White_NonPage.bmp"
        Else
            Me.m_Form.PictureBox_HBand_Black.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_HBand_White.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_HBand_White_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_Black.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_Black_NonPage.bmp"
            Me.m_Form.PictureBox_VBand_White.ImageLocation = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_1U_VBand_White_NonPage.bmp"
        End If

        Me.m_Form.CheckBox_MurabandResult.Checked = True
        'Me.UpdateSelectdImage()
        'If Me.m_Form.CheckBox_ShowMuraBandByPass.Checked Then Me.ReDraw()

        'Me.ComboBox_Select.SelectedIndex = 1
        'Me.ComboBox_Select.SelectedIndex = 0

        '--- Disable Button ---   
        'Button_Ok.Enabled = True
        'Button_Cancel.Enabled = True
    End Sub
#End Region

#Region "---SaveMuraBoundaryParam---"
    Private Sub SaveMuraBoundaryParam()
        Dim modelBoundary As ClsParameterBoundary = Me.m_MuraProcess.MuraModelRecipe.Boundary
        Dim str As String
        Dim dirPath As String
        Dim Parameter_Lists As String = ""
        Dim PatternName As String
        Dim PatternIndex As Integer
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        Try
            '--- Button Control ---   
            'Button_Enable(False)

            Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value = Me.m_Form.NumericUpDown_DefocusCount.Value

            dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dirPath) Then
                Directory.CreateDirectory(dirPath)
            End If
            str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)
            Me.m_MuraProcess.SaveMuraModelRecipe(dirPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

            '[AreaGrabber]
            PatternIndex = Me.m_Form.TreeView_MuraParamPattern.SelectedNode.Index
            Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '從[1]開始

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.m_Form.TreeView_MuraParamPattern.SelectedNode.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.Button_Ok]Set Pattern Index Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Dialog_MuraBoundary Setting   ==> Request_Command = "DIALOG_MURABOUNDARY_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_MURABOUNDARY_SETTING"
                TimeOut = 100000 '100 secs

                Parameter_Lists = "BoundaryTop," & modelBoundary.TopY & ";" & "BoundaryBottom," & modelBoundary.BottomY & ";" & "BoundaryLeft," & modelBoundary.LeftX & ";" & _
                                  "BoundaryRight," & modelBoundary.RightX & ";" & "DefocusCount," & Me.m_Form.NumericUpDown_DefocusCount.Value

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraBoundary Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Mura Model Recipe  ==> Request_Command = "SAVE_MURA_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_MURA_MODEL_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Button Control ---   
            'Button_Enable(True)
        Catch ex As Exception
            'Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_MuraBoundary.Button_Ok]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_MuraBoundary.Button_Ok]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region

#Region "---SaveMuraSmoothParam---"
    Private Sub SaveMuraSmoothParam()
        Dim mpr As ClsMuraPatternRecipe
        Dim str As String
        Dim dirPath As String
        Dim Parameter_Lists As String = ""
        Dim dir As String = ""
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        '--- Disable Button ---
        'Me.Button_Enable(False)

        '---AreaGrab Save Setting---
        Me.Setting()
        'Set local Value
        mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraSmooth Setting   ==> Request_Command = "DIALOG_MURASMOOTH_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURASMOOTH_SETTING"
            Timeout = 10000 '10 secs
            Parameter_Lists = "BlobMura_GlobleSmooth," & Me.m_Form.NumericUpDown_BlobMura_GlobleSmooth.Value & ";" & "MacroMura_GlobleSmooth," & Me.m_Form.NumericUpDown_MacroMura_GlobleSmooth.Value & ";" & "Circle_ByPassRadius," & 0 & ";" & _
                              "ResizeCount_min," & Me.m_Form.Num_ResizeCount_Min.Value & ";" & "ResizeCount_mid," & Me.m_Form.Num_ResizeCount_Mid.Value & ";" & "ResizeCount_max," & Me.m_Form.Num_ResizeCount_Max.Value & ";" & "RemoveHVBand," & Me.m_Form.CheckBox_RemoveHVBand.Checked & ";" & _
                              "UseBaseLine," & Me.m_Form.CheckBox_UseBaseLine.Checked & ";" & "MacroPowerX," & Me.m_Form.NumericUpDown_MacroPowerX.Value & ";" & "MacroPowerY," & Me.m_Form.NumericUpDown_MacroPowerY.Value & ";" & _
                              "UseFFT," & False & ";" & "FFTFilterRadius," & 50 & ";"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , Timeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(Timeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSmooth Setting Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            'Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Save]Dialog_MuraSmooth Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        If Not Directory.Exists(dirPath) Then
            Directory.CreateDirectory(dirPath)
        End If
        str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"

        Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

        '-------------------------------------------------------------------------------------------------------

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            Timeout = 10000 '10 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , Timeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(Timeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & "), " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            'Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

        'Me.Button_Enable(True)
    End Sub
#End Region

#Region "--- SaveMuraBlobParam ---"
    Private Sub SaveMuraBlobParam()
        Dim str As String
        Dim dir As String
        Dim boundary As ClsParameterBoundary
        Dim mpr As ClsMuraPatternRecipe
        Dim Parameter_Lists As String = ""
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            'Me.Button_Save.Enabled = False   '2010/07/12 Rick add
            Me.m_MuraProcess.CurrentMuraPatternRecipe.UseCenter.Value = Me.m_Form.CheckBox_AnalysisCenterMuraEnable.Checked

            '----------------------------------------------------------------------------------------------
            ' Dialog_BlobMuraLocal Setting   ==> Request_Command = "DIALOG_BLOBMURALOCAL_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_BLOBMURALOCAL_SETTING"
                TimeOut = 100000 '100 secs

                Parameter_Lists = "UseCenter," & Me.m_Form.CheckBox_AnalysisCenterMuraEnable.Checked & ";" & _
                                  "AreaTop," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Value & ";" & "AreaBottom," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Value & ";" & "AreaLeft," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Value & ";" & "AreaRight," & Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Value & ";" & _
                                  "WhiteBlobMura_ReconstructHeight," & Me.m_Form.NUD_WhiteBlobMura_ReconstructHeight.Value & ";" & "WhiteBlobMura_ReconstructLow," & Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Value & ";" & "WhiteMacroMura_Threshold," & Me.m_Form.NUD_WhiteMacroMura_Threshold.Value & ";" & _
                                  "BlackBlobMura_ReconstructHeight," & Me.m_Form.NUD_BlackBlobMura_ReconstructHeight.Value & ";" & "BlackBlobMura_ReconstructLow," & Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Value & ";" & "BlackMacroMura_Threshold," & Me.m_Form.NUD_BlackMacroMura_Threshold.Value & ";" & _
                                  "UseReconstructBW," & Me.m_Form.CheckBox_UseReconstructBW.Checked & ";"

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraLocal Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Me.Button_Save.Enabled = True
                    Exit Sub
                End If
            Catch ex As Exception
                'Me.Button_Save.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraLocal.Button_Save]Dialog_BlobMuraLocal Setting Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '-------------------------------------------------------------------------------------------------------

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MainProcess.MuraPatternRecipeArrayTemp.Count Then
                mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
            Else
                mpr = Me.m_MuraProcess.MuraPatternRecipeArray.Item(0)
            End If

            boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound
            boundary.TopY = Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Value
            boundary.BottomY = Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Value
            boundary.LeftX = Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Value
            boundary.RightX = Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value = Me.m_Form.NUD_WhiteBlobMura_ReconstructHeight.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value = Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_Threshold.Value = Me.m_Form.NUD_WhiteMacroMura_Threshold.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value = Me.m_Form.NUD_BlackBlobMura_ReconstructHeight.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value = Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Value
            Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_Threshold.Value = Me.m_Form.NUD_BlackMacroMura_Threshold.Value

            Me.m_MuraProcess.CurrentMuraPatternRecipe.UseReconstructBW.Value = Me.m_Form.CheckBox_UseReconstructBW.Checked

            dir = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
            If Not Directory.Exists(dir) Then
                Directory.CreateDirectory(dir)
            End If

            str = dir & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
            Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)
            Me.m_MuraProcess.SaveAllMuraRecipe(Me.m_MainProcess.RECIPE_PATH, Me.m_Form.TextBox_Product.Text, Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

            '----------------------------------------------------------------------------------------------
            ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                TimeOut = 10000 '10 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Me.Button_Save.Enabled = True
                    Exit Sub
                End If

            Catch ex As Exception
                'Me.Button_Save.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraLocal.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save All Mura Recipe  ==> Request_Command = "SAVE_ALL_MURA_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_ALL_MURA_RECIPE"
                TimeOut = 10000 '10 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save All Mura Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Me.Button_Save.Enabled = True
                    Exit Sub
                End If

            Catch ex As Exception
                'Me.Button_Save.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraLocal.Button_Ok]Save All Mura Recipe Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '--- Mura Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

            '--- Button Control ---   
            'Me.Button_Save.Enabled = True
        Catch ex As Exception
            'Me.Button_Save.Enabled = True
            Me.m_Form.OutputInfo("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_BlobMuraLocal.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#End Region

#Region "--- SaveMuraRoundParam ---"
    Private Sub SaveMuraRoundParam()
        Dim str As String
        Dim dir As String = ""
        Dim dirPath As String
        Dim Parameter_Lists As String = ""
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Button Control ---   
        'Button_Enable(False)   '2010/07/12 Rick add

        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseRound.Value = Me.m_Form.CheckBox_AnalysisAroundMuraEnable.Checked
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdHeight.Value = Me.m_Form.NumericUpDown_WhiteMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdLow.Value = Me.m_Form.NumericUpDown_WhiteMura_ReconstructLow.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdHeight.Value = Me.m_Form.NumericUpDown_BlackMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdLow.Value = Me.m_Form.NumericUpDown_BlackMura_ReconstructLow.Value
        '----------------------------------------------------------------------------------------------
        ' Dialog_BlobMuraRound Setting   ==> Request_Command = "DIALOG_BLOBMURAROUND_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BLOBMURAROUND_SETTING"
            Timeout = 10000 '10 secs
            Parameter_Lists = "UseRound," & Me.m_Form.CheckBox_AnalysisAroundMuraEnable.Checked & ";" & _
                              "RimTop," & Me.m_Form.NumericUpDown_RimTop.Value & ";" & "RimBottom," & Me.m_Form.NumericUpDown_RimBottom.Value & ";" & "RimLeft," & Me.m_Form.NumericUpDown_RimLeft.Value & ";" & "RimRight," & Me.m_Form.NumericUpDown_RimRight.Value & ";" & _
                              "WhiteMura_ReconstructHeight," & Me.m_Form.NumericUpDown_WhiteMura_ReconstructHeight.Value & ";" & "WhiteMura_ReconstructLow," & Me.m_Form.NumericUpDown_WhiteMura_ReconstructLow.Value & ";" & _
                              "BlackMura_ReconstructHeight," & Me.m_Form.NumericUpDown_BlackMura_ReconstructHeight.Value & ";" & "BlackMura_ReconstructLow," & Me.m_Form.NumericUpDown_BlackMura_ReconstructLow.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , Timeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(Timeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BlobMuraRound Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_Save]Dialog_BlobMuraRound Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'Save Current Mura Pattern Recipe ---

        dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        If Not Directory.Exists(dirPath) Then
            Directory.CreateDirectory(dirPath)
        End If
        str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
        Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            Timeout = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , Timeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(Timeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            'Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BlobMuraRound.Button_Save]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BlobMuraRound.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

        'Button_Enable(True)

    End Sub
#End Region

#Region "--- SaveMuraBandParam ---"
    Private Sub SaveMuraBandParam()
        Dim str As String
        Dim dir As String = ""
        Dim dirPath As String = ""
        Dim Parameter_Lists As String = ""
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Disable Button ---
        'Me.Button_Enable(False)

        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseBand.Value = Me.m_Form.CheckBox_AnalysisBandMuraEnable.Checked  '2015/03/23 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandUseRemoveHV.Value = Me.m_Form.CheckBox_BandUseRemoveHV.Checked  '2015/03/23 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value = Me.m_Form.NumericUpDown_BandMura_ResizeCount.Value   '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_SmoothCount.Value = Me.m_Form.NumericUpDown_BandMura_SmoothCount.Value   '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteHBand_Threshold.Value = Me.m_Form.NumericUpDown_WhiteHBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackHBand_Threshold.Value = Me.m_Form.NumericUpDown_BlackHBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteVBand_Threshold.Value = Me.m_Form.NumericUpDown_WhiteVBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackVBand_Threshold.Value = Me.m_Form.NumericUpDown_BlackVBand_Threshold.Value    '2009/04/16 Rick add
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.TopY = Me.m_Form.NumericUpDown_HTop.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.BottomY = Me.m_Form.NumericUpDown_HBottom.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.LeftX = Me.m_Form.NumericUpDown_HLeft.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.HBand.RightX = Me.m_Form.NumericUpDown_HRight.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.TopY = Me.m_Form.NumericUpDown_VTop.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.BottomY = Me.m_Form.NumericUpDown_VBottom.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.LeftX = Me.m_Form.NumericUpDown_VLeft.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.VBand.RightX = Me.m_Form.NumericUpDown_VRight.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.EnableBandLeakPoint.Value = Me.m_Form.CheckBox_EnableBandLeakPoint.Checked
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.BandLeakPointFilterRadius.Value = Me.m_Form.NumericUpDown_BandLeakPointFilterRadius.Value
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.EnableBandVOpen.Value = Me.m_Form.CheckBox_EnableBandVOpen.Checked
        Me.m_Form.MuraProcess.CurrentMuraPatternRecipe.BandVOpenEdgeStrength.Value = Me.m_Form.NumericUpDown_BandVOpenEdgeStrength.Value

        '----------------------------------------------------------------------------------------------
        ' Dialog_BandMura Setting   ==> Request_Command = "DIALOG_BANDMURA_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_BANDMURA_SETTING"
            Timeout = 100000 '100 secs

            Parameter_Lists = "UseBand," & Me.m_Form.CheckBox_AnalysisBandMuraEnable.Checked & ";" & "BandUseRemoveHV," & Me.m_Form.CheckBox_BandUseRemoveHV.Checked & ";" & _
                              "HTop," & Me.m_Form.NumericUpDown_HTop.Value & ";" & "HBottom," & Me.m_Form.NumericUpDown_HBottom.Value & ";" & "HLeft," & Me.m_Form.NumericUpDown_HLeft.Value & ";" & "HRight," & Me.m_Form.NumericUpDown_HRight.Value & ";" & _
                              "VTop," & Me.m_Form.NumericUpDown_VTop.Value & ";" & "VBottom," & Me.m_Form.NumericUpDown_VBottom.Value & ";" & "VLeft," & Me.m_Form.NumericUpDown_VLeft.Value & ";" & "VRight," & Me.m_Form.NumericUpDown_VRight.Value & ";" & _
                              "BandMura_ResizeCount," & Me.m_Form.NumericUpDown_BandMura_ResizeCount.Value & ";" & "BandMura_SmoothCount," & Me.m_Form.NumericUpDown_BandMura_SmoothCount.Value & ";" & _
                              "WhiteHBand_Threshold," & Me.m_Form.NumericUpDown_WhiteHBand_Threshold.Value & ";" & "BlackHBand_Threshold," & Me.m_Form.NumericUpDown_BlackHBand_Threshold.Value & ";" & "WhiteVBand_Threshold," & Me.m_Form.NumericUpDown_WhiteVBand_Threshold.Value & ";" & "BlackVBand_Threshold," & Me.m_Form.NumericUpDown_BlackVBand_Threshold.Value & ";" & _
                              "EnableBandLeakPoint," & Me.m_Form.CheckBox_EnableBandLeakPoint.Checked & ";" & "BandLeakPointFilterRadius," & Me.m_Form.NumericUpDown_BandLeakPointFilterRadius.Value & ";" & "EnableBandVOpen," & Me.m_Form.CheckBox_EnableBandVOpen.Checked & ";" & "BandVOpenEdgeStrength," & Me.m_Form.NumericUpDown_BandVOpenEdgeStrength.Value

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , Timeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(Timeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_BandMura Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            'Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Ok]Dialog_BandMura Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Ok]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Setting Recipe ---

        dirPath = Me.m_MainProcess.IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura"
        If Not Directory.Exists(dirPath) Then
            Directory.CreateDirectory(dirPath)
        End If
        str = dirPath & "\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_MuraProcess.Pattern & ".xml"
        Me.m_MuraProcess.SaveCurrentMuraPatternRecipe(str, Me.m_MainProcess.ErrorCode)
        Me.m_MuraProcess.SaveMuraModelRecipe(dirPath, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)

        '----------------------------------------------------------------------------------------------
        ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
            Timeout = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , Timeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(Timeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If

        Catch ex As Exception
            'Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Ok]Save Current Mura Pattern Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Ok]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Save Mura Model Recipe  ==> Request_Command = "SAVE_MURA_MODEL_RECIPE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SAVE_MURA_MODEL_RECIPE"
            Timeout = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , Timeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(Timeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Mura Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_BandMura.Button_Ok]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            ' Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_BandMura.Button_Ok]Save Mura Model Recipe Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_BandMura.Button_Ok]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '--- Mura Recipe Monitor ---
        dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
        If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
        Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

        'Me.Button_Enable(True)
    End Sub
#End Region

#Region "---Setting---"
    Private Sub Setting()
        'PreProcess
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value = Me.m_Form.NumericUpDown_BlobMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value = Me.m_Form.NumericUpDown_MacroMura_GlobleSmooth.Value
        'Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value = Me.m_Form.NumericUpDown_Circle_ByPassRadius.Value
        'Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFT.Value = Me.m_Form.CheckBox_UseFFT.Checked
        'Me.m_MuraProcess.CurrentMuraPatternRecipe.FFTFilterRadius.Value = Me.m_Form.NumericUpDown_FFTFilterRadius.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseBaseLine.Value = Me.m_Form.CheckBox_UseBaseLine.Checked
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroPowerX.Value = Me.m_Form.NumericUpDown_MacroPowerX.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroPowerY.Value = Me.m_Form.NumericUpDown_MacroPowerY.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.RemoveHVBand.Value = Me.m_Form.CheckBox_RemoveHVBand.Checked
        'Blob Center
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value = Me.m_Form.NUD_WhiteBlobMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value = Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_Threshold.Value = Me.m_Form.NUD_WhiteMacroMura_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value = Me.m_Form.NUD_BlackBlobMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value = Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_Threshold.Value = Me.m_Form.NUD_BlackMacroMura_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.UseReconstructBW.Value = Me.m_Form.CheckBox_UseReconstructBW.Checked
        'Blob Around
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdHeight.Value = Me.m_Form.NumericUpDown_WhiteMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdLow.Value = Me.m_Form.NumericUpDown_WhiteMura_ReconstructLow.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdHeight.Value = Me.m_Form.NumericUpDown_BlackMura_ReconstructHeight.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdLow.Value = Me.m_Form.NumericUpDown_BlackMura_ReconstructLow.Value
        'Band
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value = Me.m_Form.NumericUpDown_BandMura_ResizeCount.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_SmoothCount.Value = Me.m_Form.NumericUpDown_BandMura_SmoothCount.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteHBand_Threshold.Value = Me.m_Form.NumericUpDown_WhiteHBand_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackHBand_Threshold.Value = Me.m_Form.NumericUpDown_BlackHBand_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteVBand_Threshold.Value = Me.m_Form.NumericUpDown_WhiteVBand_Threshold.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackVBand_Threshold.Value = Me.m_Form.NumericUpDown_BlackVBand_Threshold.Value
        '---  Mura 比例參數 ---
        Me.m_MuraProcess.CurrentMuraPatternRecipe.ResizeCount_min.Value = Me.m_Form.Num_ResizeCount_Min.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.ResizeCount_mid.Value = Me.m_Form.Num_ResizeCount_Mid.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.ResizeCount_max.Value = Me.m_Form.Num_ResizeCount_Max.Value

    End Sub

#End Region

#Region "---IP Smooth---"
    Private Sub ImageSmooth()
        Dim boundary As ClsParameterBoundary = Nothing
        Dim Parameter_Lists As String = ""
        Dim SaveImage As Boolean = False
        Dim Image_Range As String = ""
        Dim InputImage_Type As String = ""
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As MIL_INT
        Dim shift As Integer
        Dim strPath As String = String.Empty

        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        '--- Disable Button ---
        'Me.Button_Enable(False)

        Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value = Me.m_Form.NumericUpDown_BlobMura_GlobleSmooth.Value
        Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value = Me.m_Form.NumericUpDown_MacroMura_GlobleSmooth.Value
        'Me.m_MuraProcess.CurrentMuraPatternRecipe.Circle_ByPassRadius.Value = Me.m_Form.NumericUpDown_Circle_ByPassRadius.Value

        '----------------------------------------------------------------------------------------------
        ' Dialog_MuraSmooth Setting   ==> Request_Command = "DIALOG_MURASMOOTH_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_MURASMOOTH_SETTING"
            TimeOut = 100000 '100 secs
            Parameter_Lists = "BlobMura_GlobleSmooth," & Me.m_Form.NumericUpDown_BlobMura_GlobleSmooth.Value & ";" & "MacroMura_GlobleSmooth," & Me.m_Form.NumericUpDown_MacroMura_GlobleSmooth.Value & ";" & "Circle_ByPassRadius," & 50 & ";"

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_MuraSmooth Setting Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If
        Catch ex As Exception
            'Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Smooth]Dialog_MuraSmooth Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Calculate Smooth Image  ==> Request_Command = "CALCULATE_SMOOTH" (Dispatcher 2)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "CALCULATE_SMOOTH"
            TimeOut = 200000 '200 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.Button_Enable(True)
                Exit Sub
            End If


            If Me.m_Form.CheckBox_RemoveHVBand.Checked Then
                '--- Prepare Command ---
                Request_Command = "REMOVE_HVBAND"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Calculate Smooth Image Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    'Me.Button_Enable(True)
                    Exit Sub
                End If
            End If

            If SaveImage AndAlso Response_OK Then
                '[1] --- Update Blob Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BlobMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)

                    If Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage)
                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[2] --- Update Macro Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_MacroMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[3] --- Update Band Mura Smooth Image ---
                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_BandMura_Smooth_NonPage.tif"
                    strPath = strPath.Replace("\\", "\")
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_BandMura_Smooth_NonPage.tif"
                    Me.RepairPath_2(strPath)
                End If

                If System.IO.File.Exists(strPath) Then
                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                    MbufDiskInquire(strPath, M_TYPE, Type)
                    If Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage <> M_NULL Then
                        If MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, M_SIZE_Y, M_NULL) <> SizeY Then
                            MbufFree(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage)
                            Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = M_NULL
                            Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                    Else
                        Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                    End If

                    '--- Load Remote Image ---
                    MbufLoad(strPath, Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage)

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If
                End If

                '[4] --- Update Defocus Image ---
                If (Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value) Then
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_FFCResult_NonPage, M_SIZE_Y, M_NULL)
                Else
                    SizeX = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_X, M_NULL)
                    SizeY = MbufInquire(Me.m_MuraProcess.Img_16U_Defocus_NonPage, M_SIZE_Y, M_NULL)
                End If

                shift = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value

                '[5] --- Update Blob Smooth Child Image ---
                If Me.m_MuraProcess.Img_BlobMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_BlobMura_SmoothChild)
                    Me.m_MuraProcess.Img_BlobMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_BlobMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BlobMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                '[6] --- Update Macro Smooth Child Image ---
                If Me.m_MuraProcess.Img_MacroMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_MacroMura_SmoothChild)
                    Me.m_MuraProcess.Img_MacroMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_MacroMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_MacroMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)

                '[7] --- Update Band Smooth Child Image ---
                If Me.m_MuraProcess.Img_BandMura_SmoothChild <> M_NULL Then
                    MbufFree(Me.m_MuraProcess.Img_BandMura_SmoothChild)
                    Me.m_MuraProcess.Img_BandMura_SmoothChild = M_NULL
                End If
                Me.m_MuraProcess.Img_BandMura_SmoothChild = MbufChild2d(Me.m_MuraProcess.Img_16U_BandMura_Smooth_NonPage, shift, shift, SizeX, SizeY, M_NULL)
                'MbufSave("D:\Test.tif", Me.m_MuraProcess.Img_BandMura_SmoothChild)
            End If
        Catch ex As Exception
            'Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSmooth.Button_Smooth]Calculate Smooth Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraSmooth.Button_Smooth]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        'If Me.m_BlobSmoothIndex = -2 Then
        '    Me.m_BlobSmoothIndex = Me.ComboBox_Select.Items.Add("Blob 平滑處理影像")
        'End If
        'If Me.m_MacroSmoothIndex = -2 Then
        '    Me.m_MacroSmoothIndex = Me.ComboBox_Select.Items.Add("Macro 平滑處理影像")
        'End If

        'Main Form- Show Blob Smooth image
        'Me.m_Form.ComboBox_Type.SelectedIndex = 1
        'Me.m_Form.ComboBox_Select.SelectedIndex = 2
        'Me.m_Form.ImageUpdate()
        ''Main Form- Show Marco Smooth image
        'Me.m_Form.ComboBox_Type.SelectedIndex = 1
        'Me.m_Form.ComboBox_Select.SelectedIndex = 3
        'Me.m_Form.ImageUpdate()

        'Me.Button_Enable(True)

    End Sub
#End Region

#Region "--- UpdateData ---"
    Private Sub UpdateData()
        Dim mpr As ClsMuraPatternRecipe = Me.m_MuraProcess.CurrentMuraPatternRecipe
        Dim boundary As ClsParameterBoundary
        Dim GrayLevel_Maximum As Double
        Dim RoundExpandWidth As Integer
        Dim HBoundary As ClsParameterBoundary
        Dim VBoundary As ClsParameterBoundary

        'Smooth
        Me.m_Form.NumericUpDown_BlobMura_GlobleSmooth.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlobMura_GlobleSmooth.Value
        Me.m_Form.NumericUpDown_MacroMura_GlobleSmooth.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.MacroMura_GlobleSmooth.Value
        Me.m_Form.Num_ResizeCount_Min.Value = mpr.ResizeCount_min.Value
        Me.m_Form.Num_ResizeCount_Mid.Value = mpr.ResizeCount_mid.Value
        Me.m_Form.Num_ResizeCount_Mid2.Value = mpr.ResizeCount_mid.Value
        Me.m_Form.Num_ResizeCount_Max.Value = mpr.ResizeCount_max.Value
        Me.m_Form.CheckBox_UseBaseLine.Checked = mpr.UseBaseLine.Value
        Me.m_Form.NumericUpDown_MacroPowerX.Value = mpr.MacroPowerX.Value
        Me.m_Form.NumericUpDown_MacroPowerY.Value = mpr.MacroPowerY.Value
        Me.m_Form.CheckBox_RemoveHVBand.Checked = mpr.RemoveHVBand.Value

        'Blob
        GrayLevel_Maximum = 2 ^ Me.m_MainProcess.IPBootConfig.Digitizer_Datadepth.Value - 1
        boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound
        RoundExpandWidth = Me.m_MuraProcess.MuraModelRecipe.RoundExpandWidth.Value
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Minimum = 0
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Minimum = 0
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Minimum = 0
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Minimum = 0
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Maximum = RoundExpandWidth
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Maximum = RoundExpandWidth
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Maximum = RoundExpandWidth
        Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Maximum = RoundExpandWidth

        Me.m_Form.CheckBox_AnalysisCenterMuraEnable.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseCenter.Value

        If Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Maximum < boundary.TopY Then
            boundary.TopY = RoundExpandWidth - 1
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Value = RoundExpandWidth - 1
        Else
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassTop.Value = boundary.TopY
        End If
        If Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Maximum < boundary.BottomY Then
            boundary.BottomY = RoundExpandWidth - 1
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Value = RoundExpandWidth - 1
        Else
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassBotton.Value = boundary.BottomY
        End If
        If Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Maximum < boundary.LeftX Then
            boundary.LeftX = RoundExpandWidth - 1
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Value = RoundExpandWidth - 1
        Else
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassLeft.Value = boundary.LeftX
        End If
        If Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Maximum < boundary.RightX Then
            boundary.RightX = RoundExpandWidth - 1
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Value = RoundExpandWidth - 1
        Else
            Me.m_Form.NumericUpDown_MuraCenterBlobByPassRight.Value = boundary.RightX
        End If

        Me.m_Form.NUD_WhiteBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
        Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
        Me.m_Form.NUD_BlackBlobMura_ReconstructHeight.Maximum = GrayLevel_Maximum
        Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Maximum = GrayLevel_Maximum
        Me.m_Form.NUD_WhiteMacroMura_Threshold.Maximum = GrayLevel_Maximum
        Me.m_Form.NUD_BlackMacroMura_Threshold.Maximum = GrayLevel_Maximum

        Me.m_Form.NUD_WhiteBlobMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value
        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value >= Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value) Then
            Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeHeight.Value - 1
        Else
            Me.m_Form.NUD_WhiteBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteBlobMura_BinarizeLow.Value
        End If
        Me.m_Form.NUD_WhiteMacroMura_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMacroMura_Threshold.Value

        Me.m_Form.NUD_BlackBlobMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value
        If (Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value >= Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value) Then
            Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeHeight.Value - 1
        Else
            Me.m_Form.NUD_BlackBlobMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackBlobMura_BinarizeLow.Value
        End If

        Me.m_Form.NUD_BlackMacroMura_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMacroMura_Threshold.Value

        Me.m_Form.CheckBox_UseReconstructBW.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseReconstructBW.Value

        'Round
        Me.m_Form.NumericUpDown_RimTop.Minimum = 0 ' original value = 1
        Me.m_Form.NumericUpDown_RimBottom.Minimum = 0 ' original value = 1
        Me.m_Form.NumericUpDown_RimLeft.Minimum = 0 ' original value = 1
        Me.m_Form.NumericUpDown_RimRight.Minimum = 0 ' original value = 1

        boundary = Me.m_MuraProcess.MuraModelRecipe.BoundaryRound
        If boundary.TopY > 1 Then Me.m_Form.NumericUpDown_RimTop.Maximum = boundary.TopY - 1
        If boundary.BottomY > 1 Then Me.m_Form.NumericUpDown_RimBottom.Maximum = boundary.BottomY - 1
        If boundary.LeftX > 1 Then Me.m_Form.NumericUpDown_RimLeft.Maximum = boundary.LeftX - 1
        If boundary.RightX > 1 Then Me.m_Form.NumericUpDown_RimRight.Maximum = boundary.RightX - 1

        Me.m_Form.CheckBox_AnalysisAroundMuraEnable.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseRound.Value
        If boundary.TopY <= Me.m_Form.NumericUpDown_RimTop.Minimum Then boundary.TopY = Me.m_Form.NumericUpDown_RimTop.Minimum
        If boundary.BottomY <= Me.m_Form.NumericUpDown_RimBottom.Minimum Then boundary.BottomY = Me.m_Form.NumericUpDown_RimBottom.Minimum
        If boundary.LeftX <= Me.m_Form.NumericUpDown_RimLeft.Maximum Then boundary.LeftX = Me.m_Form.NumericUpDown_RimLeft.Minimum
        If boundary.RightX <= Me.m_Form.NumericUpDown_RimRight.Minimum Then boundary.RightX = Me.m_Form.NumericUpDown_RimRight.Minimum

        Me.m_Form.NumericUpDown_WhiteMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdHeight.Value
        Me.m_Form.NumericUpDown_WhiteMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteMura_ThresholdLow.Value

        Me.m_Form.NumericUpDown_BlackMura_ReconstructHeight.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdHeight.Value
        Me.m_Form.NumericUpDown_BlackMura_ReconstructLow.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackMura_ThresholdLow.Value

        'Me.SetBoundary(Me.m_MuraProcess.CurrentMuraPatternRecipe.Rim)

        'Band
        HBoundary = Me.m_MuraProcess.CurrentMuraPatternRecipe.HBand
        VBoundary = Me.m_MuraProcess.CurrentMuraPatternRecipe.VBand
        Me.m_Form.NumericUpDown_HTop.Value = HBoundary.TopY
        Me.m_Form.NumericUpDown_HBottom.Value = HBoundary.BottomY
        Me.m_Form.NumericUpDown_HLeft.Value = HBoundary.LeftX
        Me.m_Form.NumericUpDown_HRight.Value = HBoundary.RightX
        Me.m_Form.NumericUpDown_VTop.Value = VBoundary.TopY
        Me.m_Form.NumericUpDown_VBottom.Value = VBoundary.BottomY
        Me.m_Form.NumericUpDown_VLeft.Value = VBoundary.LeftX
        Me.m_Form.NumericUpDown_VRight.Value = VBoundary.RightX
        Me.m_Form.CheckBox_AnalysisBandMuraEnable.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.UseBand.Value
        Me.m_Form.CheckBox_BandUseRemoveHV.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandUseRemoveHV.Value
        Me.m_Form.NumericUpDown_BandMura_ResizeCount.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_ResizeCount.Value
        Me.m_Form.NumericUpDown_BandMura_SmoothCount.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandMura_SmoothCount.Value
        Me.m_Form.NumericUpDown_WhiteHBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteHBand_Threshold.Value
        Me.m_Form.NumericUpDown_BlackHBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackHBand_Threshold.Value
        Me.m_Form.NumericUpDown_WhiteVBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.WhiteVBand_Threshold.Value
        Me.m_Form.NumericUpDown_BlackVBand_Threshold.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BlackVBand_Threshold.Value
        Me.m_Form.CheckBox_EnableBandLeakPoint.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.EnableBandLeakPoint.Value
        Me.m_Form.NumericUpDown_BandLeakPointFilterRadius.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandLeakPointFilterRadius.Value
        Me.m_Form.CheckBox_EnableBandVOpen.Checked = Me.m_MuraProcess.CurrentMuraPatternRecipe.EnableBandVOpen.Value
        Me.m_Form.NumericUpDown_BandVOpenEdgeStrength.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.BandVOpenEdgeStrength.Value
    End Sub
#End Region

#End Region

#Region "---Event ---"
    Private Sub Button_MuraPrePrcoessPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.m_Form.TabControl_MuraParam.SelectedIndex = 0
    End Sub
    Private Sub Button_MuraCenterPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.m_Form.TabControl_MuraParam.SelectedIndex = 1
    End Sub
    Private Sub Button_MuraAroundPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.m_Form.TabControl_MuraParam.SelectedIndex = 2
    End Sub
    Private Sub Button_MuraBandPage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.m_Form.TabControl_MuraParam.SelectedIndex = 3
    End Sub
    Private Sub Button_MuraPreprocess_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim OnOff As Boolean = False
        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If
        Try
            'STEP 1 Set Mura boundary
            Me.CalcMuraBoundary()
            'STEP 2 Calculate Mura ROI
            Me.CalcMuraROI()
            'STEP 3 Preprocess - image smooth
            Me.ImageSmooth()
            OnOff = True

        Catch ex As Exception
            OnOff = False
        Finally
            'Main Form - Show Mura-ROI Image
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 0

            Me.m_Form.Button_MuraCenterPage.Enabled = OnOff
            Me.m_Form.Button_MuraAroundPage.Enabled = OnOff
            Me.m_Form.Button_MuraBandPage.Enabled = OnOff
        End Try
    End Sub
    Private Sub Button_MuraParamSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'STEP 1
        Me.SaveMuraBoundaryParam()
        'STEP 2 
        Me.SaveMuraSmoothParam()
        'STEP 3
        Me.SaveMuraBlobParam()
        'STEP 4
        Me.SaveMuraRoundParam()
        'STEP 5
        Me.SaveMuraBandParam()

        MessageBox.Show("Save parameter complete.", "INFO", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub Button_AnalysisMuraBlob_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        'STEP 1
        Me.AnalysisCenterMuraBlob()

        Me.m_Form.ComboBox_Type.SelectedIndex = 1
        Me.m_Form.ComboBox_Select.SelectedIndex = 13
    End Sub
    Private Sub Button_AnalysisMuraAround_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If
        'STEP 1
        Me.AnalysisMuraAround()

        Me.m_Form.ComboBox_Type.SelectedIndex = 1
        Me.m_Form.ComboBox_Select.SelectedIndex = 17
    End Sub

    Private Sub Button_AnalysisMuraBand_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If
        'STEP 1
        Me.AnalysisMuraBand()

        Me.m_Form.ComboBox_Type.SelectedIndex = 2
        Me.m_Form.ComboBox_Select.SelectedIndex = 6
    End Sub
    Private Sub TreeView_MuraParamPattern_AfterSelect(sender As System.Object, e As System.Windows.Forms.TreeViewEventArgs)
        Dim PatternName As String
        Dim PatternIndex As Integer
        '--- 連線參數 ---
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim TimeOut As Integer
        '----------------------------------------------------------------------------------------------
        ' ConnectToIP ==> Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            ''Disable ComboBox ---
            'Me.ComboBox_PatnList.Enabled = False

            PatternIndex = Me.m_Form.TreeView_MuraParamPattern.SelectedNode.Index
            Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '從[1]開始
            Me.m_Form.NumericUpDown_DefocusCount.Value = Me.m_MuraProcess.CurrentMuraPatternRecipe.DefocusCount.Value
            Me.UpdateData()

            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.m_Form.TreeView_MuraParamPattern.SelectedNode.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                'Me.ComboBox_PatnList.Enabled = True
                Exit Sub
            End If

            System.Threading.Thread.Sleep(1000)
            'Me.ComboBox_PatnList.Enabled = True
        Catch ex As Exception
            'Me.ComboBox_PatnList.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraBoundary.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
#Region "---Numeric Event---"

    Private Sub Num_ResizeCount_Max_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.Num_ResizeCount_Max.Value <= Me.m_Form.Num_ResizeCount_Mid.Value Then
            Me.m_Form.Num_ResizeCount_Mid.Value = Me.m_Form.Num_ResizeCount_Max.Value - 1
            Me.m_Form.Num_ResizeCount_Mid2.Value = Me.m_Form.Num_ResizeCount_Mid.Value
            If Me.m_Form.Num_ResizeCount_Mid2.Value <= Me.m_Form.Num_ResizeCount_Min.Value Then
                Me.m_Form.Num_ResizeCount_Min.Value = Me.m_Form.Num_ResizeCount_Mid2.Value - 1
            End If
        End If
    End Sub

    Private Sub Num_ResizeCount_Mid_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.m_Form.Num_ResizeCount_Mid2.Value = Me.m_Form.Num_ResizeCount_Mid.Value
        If Me.m_Form.Num_ResizeCount_Mid.Value >= Me.m_Form.Num_ResizeCount_Max.Value Then
            Me.m_Form.Num_ResizeCount_Max.Value = Me.m_Form.Num_ResizeCount_Mid.Value + 1
        End If
        If Me.m_Form.Num_ResizeCount_Mid.Value <= Me.m_Form.Num_ResizeCount_Min.Value Then
            Me.m_Form.Num_ResizeCount_Min.Value = Me.m_Form.Num_ResizeCount_Mid.Value - 1
        End If
    End Sub

    Private Sub Num_ResizeCount_Mid2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.m_Form.Num_ResizeCount_Mid.Value = Me.m_Form.Num_ResizeCount_Mid2.Value
        If Me.m_Form.Num_ResizeCount_Mid2.Value >= Me.m_Form.Num_ResizeCount_Max.Value Then
            Me.m_Form.Num_ResizeCount_Max.Value = Me.m_Form.Num_ResizeCount_Mid2.Value + 1
        End If
        If Me.m_Form.Num_ResizeCount_Mid2.Value <= Me.m_Form.Num_ResizeCount_Min.Value Then
            Me.m_Form.Num_ResizeCount_Min.Value = Me.m_Form.Num_ResizeCount_Mid2.Value - 1
        End If
    End Sub

    Private Sub Num_ResizeCount_Min_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.Num_ResizeCount_Mid2.Value <= Me.m_Form.Num_ResizeCount_Min.Value Then
            Me.m_Form.Num_ResizeCount_Mid2.Value = Me.m_Form.Num_ResizeCount_Min.Value + 1
            Me.m_Form.Num_ResizeCount_Mid.Value = Me.m_Form.Num_ResizeCount_Mid2.Value
            If Me.m_Form.Num_ResizeCount_Mid.Value >= Me.m_Form.Num_ResizeCount_Max.Value Then
                Me.m_Form.Num_ResizeCount_Max.Value = Me.m_Form.Num_ResizeCount_Mid.Value + 1
            End If
        End If
    End Sub

#End Region

#Region "--- CheckBox ---"
    Private Sub CheckBox_AnalysisCenterMuraEnable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not Me.m_Form.CheckBox_AnalysisCenterMuraEnable.Checked Then
            Me.m_Form.Button_AnalysisMuraBlob.Enabled = False
            Me.m_Form.CheckBox_UseReconstructBW.Enabled = False
            Me.m_Form.GroupBox_Modify.Enabled = False
            Me.m_Form.GroupBox_MuraCenterBlobThreshold.Enabled = False
        Else
            Me.m_Form.Button_AnalysisMuraBlob.Enabled = True
            Me.m_Form.CheckBox_UseReconstructBW.Enabled = True
            Me.m_Form.GroupBox_Modify.Enabled = True
            Me.m_Form.GroupBox_MuraCenterBlobThreshold.Enabled = True
        End If
    End Sub

    Private Sub CheckBox_AnalysisAroundMuraEnable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not Me.m_Form.CheckBox_AnalysisAroundMuraEnable.Checked Then
            Me.m_Form.Button_AnalysisMuraAround.Enabled = False
            Me.m_Form.GroupBox_MuraAroundThreshold.Enabled = False
            Me.m_Form.GroupBox_MuraAroundByPass.Enabled = False
        Else
            Me.m_Form.Button_AnalysisMuraAround.Enabled = True
            Me.m_Form.GroupBox_MuraAroundThreshold.Enabled = True
            Me.m_Form.GroupBox_MuraAroundByPass.Enabled = True
        End If
    End Sub

    Private Sub CheckBox_AnalysisBandMuraEnable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not Me.m_Form.CheckBox_AnalysisBandMuraEnable.Checked Then
            Me.m_Form.Button_AnalysisMuraBand.Enabled = False
            Me.m_Form.CheckBox_MuraBandResult.Enabled = False
            Me.m_Form.ComboBox_MuraBandResult.Enabled = False
            Me.m_Form.CheckBox_BandUseRemoveHV.Enabled = False
            Me.m_Form.GroupBox_BandVOpenSearch.Enabled = False
            Me.m_Form.GroupBox_BandLeakPoint.Enabled = False
            Me.m_Form.GroupBox_BandBlockV.Enabled = False
            Me.m_Form.GroupBox_BandBlockH.Enabled = False
            Me.m_Form.GroupBox_BandBlockSetting.Enabled = False
            Me.m_Form.GroupBox_BandResizeThreshold.Enabled = False
            Me.m_Form.GroupBox_BandByPass.Enabled = False
        Else
            Me.m_Form.Button_AnalysisMuraBand.Enabled = True
            Me.m_Form.CheckBox_MuraBandResult.Enabled = True
            Me.m_Form.ComboBox_MuraBandResult.Enabled = True
            Me.m_Form.CheckBox_BandUseRemoveHV.Enabled = True

            Me.m_Form.GroupBox_BandVOpenSearch.Enabled = True
            Me.m_Form.GroupBox_BandLeakPoint.Enabled = True
            Me.m_Form.GroupBox_BandBlockV.Enabled = True
            Me.m_Form.GroupBox_BandBlockH.Enabled = True
            Me.m_Form.GroupBox_BandBlockSetting.Enabled = True
            Me.m_Form.GroupBox_BandResizeThreshold.Enabled = True
            Me.m_Form.GroupBox_BandByPass.Enabled = True
        End If
    End Sub

    Private Sub CheckBox_MuraBandResult_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        If Me.m_Form.CheckBox_MuraBandResult.Checked Then
            If Me.m_Form.CheckBox_MuraBandResult.Text = "Black" Then
                Me.m_Form.PictureBox_HBand_Black.Visible = True
                Me.m_Form.PictureBox_HBand_White.Visible = False
                Me.m_Form.PictureBox_VBand_Black.Visible = True
                Me.m_Form.PictureBox_VBand_White.Visible = False
            ElseIf Me.m_Form.CheckBox_MuraBandResult.Text = "White" Then
                Me.m_Form.PictureBox_HBand_Black.Visible = False
                Me.m_Form.PictureBox_HBand_White.Visible = True
                Me.m_Form.PictureBox_VBand_Black.Visible = False
                Me.m_Form.PictureBox_VBand_White.Visible = True
            End If
        Else
            Me.m_Form.PictureBox_HBand_Black.Visible = False
            Me.m_Form.PictureBox_HBand_White.Visible = False
            Me.m_Form.PictureBox_VBand_Black.Visible = False
            Me.m_Form.PictureBox_VBand_White.Visible = False
        End If
        Me.m_Form.PictureBox_HBand_Black.SizeMode = 1
        Me.m_Form.PictureBox_HBand_White.SizeMode = 1
        Me.m_Form.PictureBox_VBand_Black.SizeMode = 1
        Me.m_Form.PictureBox_VBand_White.SizeMode = 1
    End Sub

#End Region

#End Region

End Class
