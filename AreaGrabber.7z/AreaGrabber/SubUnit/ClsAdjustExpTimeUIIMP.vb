﻿Imports MILOperationLib
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports System.Threading
Imports System.IO
Imports AUO.SubSystemControl
Imports ClassLibrary

<CLSCompliant(False)>
Public Class ClsAdjustExpTimeUIIMP

#Region "---Variable---"
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_Ever_ContinueGrab As Boolean
    Private m_Grab_OK As Boolean
    Private m_ContinueGrab As Boolean
    Private m_IsCalcFocusValue As Boolean
    Private m_Thread1_RunCommand As Threading.Thread = Nothing  '「執行命令」執行緒 1
    Private m_ReadWriteLock As New System.Threading.ReaderWriterLock()
    Private m_Max_ExposureTime As Integer

    '-----------------ShowBoundary------------------
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel
    Private pb As New ClsParameterBoundary

#End Region

#Region "---Properties---"
    Public Property Button_Continue As Button
    Public Property Button_StopGrab As Button
    Public Property Button_SaveExpTime As Button

    Public ReadOnly Property IsGrabStatus As Boolean
        Get
            Return Me.m_ContinueGrab
        End Get
    End Property

#End Region

#Region "---Contructor---"
    Public Sub New(ByVal MainFrm As Main_Form)
        Me.m_Form = Main_Form

    End Sub
#End Region

#Region "---Public Method---"
    Public Sub Init()
        Me.Button_Continue = Me.m_Form.Button_Continue
        Me.Button_StopGrab = Me.m_Form.Button_StopGrab
        Me.Button_SaveExpTime = Me.m_Form.Button_SaveExpTime

        Me.m_MainProcess = Me.m_Form.MainProcess
        Me.m_FuncProcess = Me.m_MainProcess.FuncProcess
        Me.m_MuraProcess = Me.m_MainProcess.MuraProcess
        Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig

        Me.m_Max_ExposureTime = Me.m_MainProcess.IPBootConfig.Max_ExposureTime.Value   '2012/11/09 Rick add
        Me.m_Form.NumericUpDown_ExposureTime.Maximum = Me.m_Max_ExposureTime  '2013/01/24 Rick add
        Me.m_Form.TrackBar_ExposureTime.Maximum = Me.m_Max_ExposureTime  '2013/01/24 Rick add

        RemoveHandler Button_Continue.Click, AddressOf Button_Continue_Click
        AddHandler Button_Continue.Click, AddressOf Button_Continue_Click
        RemoveHandler Button_StopGrab.Click, AddressOf Button_StopGrab_Click
        AddHandler Button_StopGrab.Click, AddressOf Button_StopGrab_Click
        RemoveHandler Button_SaveExpTime.Click, AddressOf Button_SaveExpTime_Click
        AddHandler Button_SaveExpTime.Click, AddressOf Button_SaveExpTime_Click
        RemoveHandler Me.m_Form.Button_MannualMean.Click, AddressOf Button_MannualMean_Click
        AddHandler Me.m_Form.Button_MannualMean.Click, AddressOf Button_MannualMean_Click

        RemoveHandler Me.m_Form.RadioButton_Func.CheckedChanged, AddressOf RadioButton_Func_CheckedChanged
        AddHandler Me.m_Form.RadioButton_Func.CheckedChanged, AddressOf RadioButton_Func_CheckedChanged
        RemoveHandler Me.m_Form.RadioButton_Mura.CheckedChanged, AddressOf RadioButton_Mura_CheckedChanged
        AddHandler Me.m_Form.RadioButton_Mura.CheckedChanged, AddressOf RadioButton_Mura_CheckedChanged
        RemoveHandler Me.m_Form.CheckBox_ExpShowBoundary.CheckedChanged, AddressOf CheckBox_ShowBoundary_CheckedChanged
        AddHandler Me.m_Form.CheckBox_ExpShowBoundary.CheckedChanged, AddressOf CheckBox_ShowBoundary_CheckedChanged
        RemoveHandler Me.m_Form.TrackBar_ExposureTime.MouseUp, AddressOf TrackBar_ExposureTime_MouseUp
        AddHandler Me.m_Form.TrackBar_ExposureTime.MouseUp, AddressOf TrackBar_ExposureTime_MouseUp

        RemoveHandler Me.m_Form.NumericUpDown_ExposureTime.ValueChanged, AddressOf NumericUpDown_ExposureTime_ValueChanged
        AddHandler Me.m_Form.NumericUpDown_ExposureTime.ValueChanged, AddressOf NumericUpDown_ExposureTime_ValueChanged


        RemoveHandler Me.m_Form.ComboBox_PatnList.SelectedIndexChanged, AddressOf ComboBox_PatnList_SelectedIndexChanged
        AddHandler Me.m_Form.ComboBox_PatnList.SelectedIndexChanged, AddressOf ComboBox_PatnList_SelectedIndexChanged

        'Reset 
        Me.ResetUIParam()
        'Get ALL Exp Time
        Me.GetAllExpTime()

    End Sub
#End Region

#Region "---Private Method---"
#Region "--- ContinueGrabImage ---"
    Private Sub ContinueGrabImage()
        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        Dim Grab_Success As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim FocusValue As Integer
        Dim strs() As String
        Dim strPath As String
        Dim strPath_Exists As Boolean
        Dim ColorBand As String = Me.GetColorBandParam() 'Image Band (R\G\B\L --> Color相機 ：空白 --> Mono相機)
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer

        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                strPath = Me.m_MainProcess.RAMDISK_PATH
                strPath = strPath.Replace("\\", "\")
                'Me.RepairPath_2(strPath)
                If System.IO.File.Exists(strPath) Then
                    Directory.CreateDirectory(strPath)
                End If
            Else
                strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\"
                Me.RepairPath_2(strPath)
                If System.IO.File.Exists(strPath) Then
                    Directory.CreateDirectory(strPath)
                End If
            End If

            '--- Disable ScrollBar ---
            'Me.ScrollBar_Enable(False)

            '--- 建立連線 ---
            If Me.ConnectToIP = False Then
                Exit Sub
            End If

            Me.m_ReadWriteLock.AcquireWriterLock(Me.m_Grab_OK)

            Me.m_Grab_OK = False

            If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                If ColorBand = "raw" Then
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.raw"
                Else
                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                End If
                strPath = strPath.Replace("\\", "\")
            Else
                If ColorBand = "raw" Then
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.raw"
                Else
                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                End If
                Me.RepairPath_2(strPath)
            End If

            Do
                '----------------------------------------------------------------------------------------------
                ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------

                System.Threading.Thread.Sleep(100)

                Try
                    SyncLock Me.m_MainProcess.IP_Dispatcher1
                        '--- Prepare Command ---
                        Request_Command = "GRAB_ONESHOT"
                        iTimeout = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ColorBand, , , , , , , , iTimeout)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)
                    End SyncLock

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        Response_OK = True
                    Else
                        Response_OK = False
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.UpdateGrabImage]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                    If Response_OK Then
                        '--- Update Processed Image ---
                        Grab_Success = Grab_Success + 1
                        If ColorBand = "raw" Then
                            Image = Me.m_MainProcess.Img_16U_GrabColor_1
                        Else
                            Image = Me.m_MainProcess.Img_16U_Grab_1
                        End If

                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        strPath_Exists = System.IO.File.Exists(strPath)

                        If strPath_Exists Then
                            If ColorBand = "raw" Then
                                '--- Color Image ---
                                If Me.m_MainProcess.Img_16U_GrabColor_1 <> M_NULL Then
                                    If MbufInquire(Me.m_MainProcess.Img_16U_GrabColor_1, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Me.m_MainProcess.Img_16U_GrabColor_1, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Me.m_MainProcess.Img_16U_GrabColor_1)
                                        Me.m_MainProcess.Img_16U_GrabColor_1 = M_NULL
                                        Me.m_MainProcess.Img_16U_GrabColor_1 = MbufAllocColor(Me.m_MainProcess.System_Host, 3, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Me.m_MainProcess.Img_16U_GrabColor_1 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Me.m_MainProcess.Img_16U_GrabColor_1)

                                '--- Show Image ---
                                If Me.m_MainProcess.Img_16U_GrabColor_1 = M_NULL Then
                                    MdispSelect(Me.m_Form.AxMDisplay, M_NULL)
                                Else
                                    If Me.m_MainProcess.Img_16U_GrabColor_1 <> M_NULL Then
                                        MdispSelectWindow(Me.m_Form.AxMDisplay, Me.m_MainProcess.Img_16U_GrabColor_1, Me.m_Form.GetAxMDisplay_HandleInfo())  '2013/01/24 Rick modify
                                        MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)
                                    Else
                                        MdispSelect(Me.m_Form.AxMDisplay, M_NULL)
                                    End If
                                End If
                                MdispPan(Me.m_Form.AxMDisplay, 0, 0)
                                MdispPan(Me.m_Form.AxMDisplay, Me.m_Form.HScrollBar.Value, Me.m_Form.VScrollBar.Value)
                            Else
                                '--- Gray Image ---
                                If Image <> M_NULL Then
                                    If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                        MbufFree(Image)
                                        Image = M_NULL
                                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If
                                Else
                                    Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                End If

                                '--- Load Remote Image ---
                                MbufLoad(strPath, Image)
                                Me.m_Form.ImageUpdate()
                            End If

                            Me.SetButtonStopGrabEnable(True)
                        End If
                    End If

                    If Me.m_IsCalcFocusValue Then
                        '----------------------------------------------------------------------------------------------
                        ' Get Gray Mean  ==> Request_Command = "GET_FOCUSVALUE" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            SyncLock Me.m_MainProcess.IP_Dispatcher1
                                '--- Prepare Command ---
                                Request_Command = "GET_FOCUSVALUE"
                                iTimeout = 500000 '500 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , iTimeout)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)
                            End SyncLock

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                'If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                                If SubSystemResult.Responses(0).Param2 <> "" Then

                                    strs = SubSystemResult.Responses(0).Param2.Split(",")
                                    FocusValue = strs(1)
                                    SetLabel_FocusValueInfo("Focus Value：" & FocusValue)
                                End If
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Focus Value Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_ADJMean.get_FocusValue]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_FocusValue]Get Focus Value Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_ADJMean.get_FocusValue]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End Try

                    End If

                    'Me.m_Grab_OK = True
                Catch ex As Exception
                    Response_OK = False
                    Me.m_ContinueGrab = False
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            Loop While (Me.m_ContinueGrab And Me.Button_Continue.Enabled = False)

            Me.m_Grab_OK = True
            Me.ScrollBar_Enable(True)
            Me.ZoomEnable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
        Catch ex As Exception
            Me.ScrollBar_Enable(True)
            Me.SetButtonStopGrabEnable(True)
            Me.m_ReadWriteLock.ReleaseWriterLock()
            Me.m_Form.OutputInfo("[Dialog_ADJmean.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            Throw New Exception("[Dialog_ADJmean.UpdateGrabImage]Grab One Image Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try

    End Sub
#End Region
#Region "--- WaitGrabReady ---"
    Private Sub WaitGrabReady()
        Dim i As Integer

        i = (Me.GetExposureTimeInfo() / 100000) + 1  '2013/01/25 Rick add
        If i < 10 Then i = 10

        If Not Me.m_ContinueGrab Then
            While (Not Me.m_Grab_OK And i >= 0)
                System.Threading.Thread.Sleep(200)
                Application.DoEvents()
                i = i - 1
            End While

            Me.m_Grab_OK = True
        End If
    End Sub
#End Region
#Region "--- UpdateExposureTime ---"
    Private Sub UpdateExposureTime()
        Dim ExposureTime As Long

        'If Me.m_Have_MDigitizer Then '---暫時comment out

        '[AreaGrabber]
        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value Then
            ExposureTime = Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex).ExposureTime.Value
        Else
            ExposureTime = Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex - Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value).ExposureTime.Value
        End If

        '--- 曝光時間最小需求 16000 ---
        'If ExposureTime < 16000 Then ExposureTime = 16000

        Me.m_Form.TrackBar_ExposureTime.Value = ExposureTime
        Me.m_Form.NumericUpDown_ExposureTime.Value = ExposureTime

        'End If
    End Sub
#End Region
#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region
#Region "--- ConnectToIP ---"
    Private Function ConnectToIP()
        Dim ip As ClsIPInfo
        Dim IsIPConnected As Boolean = False
        Dim IPConnectMsg As String = ""

        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_MainProcess.IPInfo.Add(ip)
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPConnectMsg)
        If IsIPConnected = False Or IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region
#Region "--- ScrollBar_Enable ---"
    Private Sub ScrollBar_Enable(ByVal En As Boolean)
        Me.m_Form.HScrollBar_Enable(En)
        Me.m_Form.VScrollBar_Enable(En)
    End Sub
#End Region
#Region "--- ZommEnable ---"
    Private Sub ZoomEnable(ByVal En As Boolean)
        Me.m_Form.SetButton_ZoomIn(En)
        Me.m_Form.SetButton_ZoomOut(En)
        Me.m_Form.SetButton_ZoomO(En)
        Me.m_Form.SetButton_ZoomAll(En)
    End Sub
#End Region
#Region "--- PatternSelect_Enable ---"
    Private Sub PatternSelect_Enable(ByVal En As Boolean)
        Me.SetComboBox_PatnList_EnableInfo(En)
        Me.SetRadioButton_Mura_EnableInfo(En)
        Me.SetRadioButton_Func_EnableInfo(En)
    End Sub
#End Region

#Region "---GetAllExpTime---"
    Private Sub GetAllExpTime()
        Dim strs() As String
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer
        Dim count1 As Integer
        Dim count2 As Integer

        '-------------------------------------------------------------------------------------
        ' Get All Exposure Time   ==> Request_Command = "GET_ALL_EXPOSURE_TIME" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "GET_ALL_EXPOSURE_TIME"
            iTimeout = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , iTimeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True

                strs = SubSystemResult.Responses(0).Param1.Split(",")

                count1 = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
                count2 = Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value

                For i = 0 To strs.Length - 1 Step 2
                    If (strs(i) <> "") Then
                        '[Mura]
                        For j = 0 To count1 - 1
                            If Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(j).PatternName.Value = strs(i) Then
                                If Val(strs(j + 1)) >= Me.m_Max_ExposureTime Then
                                    strs(j + 1) = Me.m_Max_ExposureTime
                                End If
                                Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(j).ExposureTime.Value = Val(strs(i + 1))
                            End If
                        Next

                        '[Func]
                        For k = 0 To count2 - 1
                            If Me.m_FuncProcess.FuncPatternRecipeArray.Item(k).PatternName.Value = strs(i) Then
                                If Val(strs(k + 1)) >= Me.m_Max_ExposureTime Then
                                    strs(k + 1) = Me.m_Max_ExposureTime
                                End If
                                Me.m_FuncProcess.FuncPatternRecipeArray.Item(k).ExposureTime.Value = Val(strs(i + 1))
                            End If
                        Next
                    End If
                Next
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get All Exposure Time  Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraAutoManual.SetMainForm]Get All Exposure Time  Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_MuraAutoManual.SetMainForm]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region
#Region "--- Setting ---"
    Private Sub Setting()
        Dim i As Integer

        If Me.m_Form.RadioButton_Mura.Checked = True Then
            i = Me.m_MainProcess.MuraPatternRecipeArrayOrder.IndexOf(Me.m_MuraProcess.CurrentMuraPatternRecipe)
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).ExposureTime.Value = Me.m_Form.NumericUpDown_ExposureTime.Value
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).AutoExposure_Kp.Value = 30 'CInt(Me.TextBox_Kp.Text)
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).AutoExposure_TargetMean.Value = 1500 'CInt(Me.TextBox_MeanTarget.Text)
            Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).AutoExposure_SmallErrorRange.Value = 5 'CInt(Me.TextBox_ErrorRange.Text)

        ElseIf Me.m_Form.RadioButton_Func.Checked = True Then
            i = Me.m_MainProcess.FuncPatternRecipeArrayOrder.IndexOf(Me.m_FuncProcess.CurrentFuncPatternRecipe)
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).ExposureTime.Value = Me.m_Form.NumericUpDown_ExposureTime.Value
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).AutoExposure_Kp.Value = 30 'CInt(Me.TextBox_Kp.Text)
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).AutoExposure_TargetMean.Value = 1500 'CInt(Me.TextBox_MeanTarget.Text)
            Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).AutoExposure_SmallErrorRange.Value = 5 'CInt(Me.TextBox_ErrorRange.Text)

        End If

    End Sub
#End Region
#Region "--- CompareFunc ---"
    Private Sub CompareFunc(ByVal fprOld As ClsFuncPatternRecipe, ByVal fprNew As ClsFuncPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[Exposure Time Change]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        If fprOld.ExposureTime.Value <> fprNew.ExposureTime.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< ExposureTime >: " & fprOld.ExposureTime.Value & " --> " & fprNew.ExposureTime.Value)
            fprOld.ExposureTime = fprNew.ExposureTime
        End If
        If fprOld.AutoExposure_Kp.Value <> fprNew.AutoExposure_Kp.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< AutoExposure_Kp >: " & fprOld.AutoExposure_Kp.Value & " --> " & fprNew.AutoExposure_Kp.Value)
            fprOld.AutoExposure_Kp.Value = fprNew.AutoExposure_Kp.Value
        End If
        If fprOld.AutoExposure_SmallErrorRange.Value <> fprNew.AutoExposure_SmallErrorRange.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< AutoExposure_SmallErrorRange >: " & fprOld.AutoExposure_SmallErrorRange.Value & " --> " & fprNew.AutoExposure_SmallErrorRange.Value)
            fprOld.AutoExposure_SmallErrorRange = fprNew.AutoExposure_SmallErrorRange
        End If
        If fprOld.AutoExposure_TargetMean.Value <> fprNew.AutoExposure_TargetMean.Value Then
            dlm.WriteLog("< Pattern > : " & fprNew.PatternName.Value & " ; " & "< AutoExposure_TargetMean >: " & fprOld.AutoExposure_TargetMean.Value & " --> " & fprNew.AutoExposure_TargetMean.Value)
            fprOld.AutoExposure_TargetMean = fprNew.AutoExposure_TargetMean
        End If
    End Sub
#End Region
#Region "--- CompareMura ---"
    Private Sub CompareMura(ByVal mprOld As ClsMuraPatternRecipe, ByVal mprNew As ClsMuraPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[Exposure Time Change]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        If mprOld.ExposureTime.Value <> mprNew.ExposureTime.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< ExposureTime >: " & mprOld.ExposureTime.Value & " --> " & mprNew.ExposureTime.Value)
            mprOld.ExposureTime = mprNew.ExposureTime
        End If
        If mprOld.AutoExposure_Kp.Value <> mprNew.AutoExposure_Kp.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< AutoExposure_Kp >: " & mprOld.AutoExposure_Kp.Value & " --> " & mprNew.AutoExposure_Kp.Value)
            mprOld.AutoExposure_Kp = mprNew.AutoExposure_Kp
        End If
        If mprOld.AutoExposure_SmallErrorRange.Value <> mprNew.AutoExposure_SmallErrorRange.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< AutoExposure_SmallErrorRange >: " & mprOld.AutoExposure_SmallErrorRange.Value & " --> " & mprNew.AutoExposure_SmallErrorRange.Value)
            mprOld.AutoExposure_SmallErrorRange.Value = mprNew.AutoExposure_SmallErrorRange.Value
        End If
        If mprOld.AutoExposure_TargetMean.Value <> mprNew.AutoExposure_TargetMean.Value Then
            dlm.WriteLog("< Pattern > : " & mprNew.PatternName.Value & " ; " & "< AutoExposure_SmallErrorRange >: " & mprOld.AutoExposure_TargetMean.Value & " --> " & mprNew.AutoExposure_TargetMean.Value)
            mprOld.AutoExposure_TargetMean.Value = mprNew.AutoExposure_TargetMean.Value
        End If
    End Sub
#End Region
#Region "--- PitchCheck_Boundary ---"
    Private Sub PitchCheck_Boundary()
        '--------------2010/10/12 grant  add for BoundaryAuto------------------------
        Dim StartX As Integer = 0
        Dim StartY As Integer = 0
        Dim EndX As Integer = 0
        Dim EndY As Integer = 0

        StartX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
        EndX = Me.m_FuncProcess.FuncModelRecipe.Boundary.RightX
        StartY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY
        EndY = Me.m_FuncProcess.FuncModelRecipe.Boundary.BottomY

        '2010/12/1 Lena Modify
        Try

            pb.LeftX = StartX
            pb.RightX = EndX
            pb.TopY = StartY
            pb.BottomY = EndY

            ReDraw(pb)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
#End Region
#Region "--- ReDraw ---"
    Private Sub ReDraw(ByVal Boundary As ClsParameterBoundary)
        'OLED
        Try

            Dim image As MIL_ID
            image = MIL.MdispInquire(Me.m_Form.AxMDisplay, MIL.M_SELECTED, MIL.M_NULL)
            If image <> MIL.M_NULL Then
                Me.ReDrawPage0(image, Boundary)
            End If
        Catch ex As Exception
            Throw New Exception(ex.Message)
        End Try

    End Sub
#End Region
#Region "--- ReDrawPage0 ---"
    Private Sub ReDrawPage0(ByVal image As MIL_ID, ByVal Boundary As ClsParameterBoundary)
        Dim rect As Rectangle
        Dim s As Integer
        Dim v As Integer
        Dim h As Integer
        Dim SizeX, SizeY As Integer

        Try
            Dim Factor As Double
            MIL.MdispInquire(Me.m_Form.AxMDisplay, MIL.M_ZOOM_FACTOR_Y, Factor)

            rect = New Rectangle
            Me.m_Form.PaintStop = True
            Me.m_Form.Panel_AxMDisplay.Refresh()
            Me.m_GraphicsImage.Clear(Color.Transparent)
            If Me.m_Form.CheckBox_ExpShowBoundary.Checked Then
                'image = MIL.MdispInquire(Me.m_Form.AxMDisplay, MIL.M_SELECTED, MIL.M_NULL)
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                s = Math.Ceiling(Factor)
                If Me.m_Form.CheckBox_ExpShowBoundary.Checked Then
                    Me.m_SolidBrush.Color = Color.Red
                    v = (Boundary.LeftX - Me.m_Form.HScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Width Then
                        h = SizeY * Factor  ' Me.m_Form.ZoomY
                        If h >= Me.m_BitMap.Height Then
                            h = Me.m_BitMap.Height - 1
                        End If
                        rect.X = v
                        rect.Y = 1
                        rect.Width = s
                        rect.Height = h
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                    v = (Boundary.RightX - Me.m_Form.HScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Width Then
                        h = SizeY * Factor
                        If h >= Me.m_BitMap.Height Then
                            h = Me.m_BitMap.Height - 1
                        End If
                        rect.X = v
                        rect.Y = 1
                        rect.Width = s
                        rect.Height = h
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                    v = (Boundary.TopY - Me.m_Form.VScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Height Then
                        h = SizeX * Factor
                        If h >= Me.m_BitMap.Width Then
                            h = Me.m_BitMap.Width - 1
                        End If
                        rect.X = 1
                        rect.Y = v
                        rect.Width = h
                        rect.Height = s
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                    v = (Boundary.BottomY - Me.m_Form.VScrollBar.Value) * Factor
                    If v >= 0 And v < Me.m_BitMap.Height Then
                        h = SizeX * Factor
                        If h >= Me.m_BitMap.Width Then
                            h = Me.m_BitMap.Width - 1
                        End If
                        rect.X = 1
                        rect.Y = v
                        rect.Width = h
                        rect.Height = s
                        Me.m_GraphicsImage.FillRectangle(Me.m_SolidBrush, rect)
                    End If
                End If
            End If

            'Me.m_BitMap.Save("D:\\Temp.bmp")

            Me.m_GraphicsDisplay.DrawImage(Me.m_BitMap, New PointF(0, 0))
            Me.m_Form.PaintStop = False
        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_Boundary.ReDrawPage0]" & ex.Message)
        End Try
    End Sub
#End Region
#Region "Reset UI Param"
    Private Sub ResetUIParam()

        Dim image As MIL_ID = M_NULL
        Try
            '--- 光學邊界調整繪圖 ---
            Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
            Me.m_BitMap = New Bitmap(Me.m_Form.Panel_AxMDisplay.Width, Me.m_Form.Panel_AxMDisplay.Height)
            Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
            Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
            Me.m_SolidBrush = New SolidBrush(Color.White)
            Me.m_Pen = New Pen(Color.White)
            Me.m_Form.PaintStop = True

            If Me.m_IPBootConfig.MuraUI.Value AndAlso Me.m_IPBootConfig.FuncUI.Value Then
                If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                    Image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
                Else
                    Image = Me.m_FuncProcess.Img_Original_NonPage
                End If
            ElseIf Me.m_IPBootConfig.FuncUI.Value And Not Me.m_IPBootConfig.MuraUI.Value Then
                Image = Me.m_FuncProcess.Img_Original_NonPage
            ElseIf Me.m_IPBootConfig.MuraUI.Value And Not Me.m_IPBootConfig.FuncUI.Value Then
                Image = Me.m_MuraProcess.Img_CurrentOriginal_NonPage
            End If

            If Image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            Else
                'Me.GroupBox_Mode.Enabled = False
            End If

            Me.m_Form.ImageZoomAll()
            'Me.UpdateUserLevel()

            If Not Me.m_IPBootConfig.MuraUI.Value Then Me.m_Form.RadioButton_Mura.Enabled = False
            'If Me.m_Have_MDigitizer Then
            '    Me.GroupBox_Grab.Enabled = True
            'Else
            '    Me.GroupBox_Grab.Enabled = False
            'End If

            '--- Color Band List ---
            Me.m_Form.ComboBox_ColorBand.Items.Clear()
            If Me.m_IPBootConfig.Digitizer_Type.Value = DigitizerType.Color Then
                Me.m_Form.ComboBox_ColorBand.Items.Add("L")
                Me.m_Form.ComboBox_ColorBand.Items.Add("R")
                Me.m_Form.ComboBox_ColorBand.Items.Add("G")
                Me.m_Form.ComboBox_ColorBand.Items.Add("B")
                Me.m_Form.ComboBox_ColorBand.Items.Add("raw")
                'Me.m_Form.ComboBox_ColorBand.ForeColor = Color.Red
            Else
                Me.m_Form.ComboBox_ColorBand.Items.Add("")
                Me.m_Form.ComboBox_ColorBand.Items.Add("NONE")
            End If

            Me.m_Form.RadioButton_Func.Checked = True
            Me.m_ContinueGrab = False
            Me.m_Grab_OK = False
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region
#Region "--- get_GrayMean ---"
    Private Sub get_GrayMean(ByRef mean As Integer, ByRef Max_GrayMean As Integer)
        Dim buffer As MIL_ID = Nothing
        Dim image As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim strs() As String
        Dim strPath As String
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        ''--- 停止連續取像 ---
        'Me.WaitGrabReady()

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' IP LOAD GRAB IMAGE  ==> Request_Command = "LOAD_GRABIMAGE" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "LOAD_GRABIMAGE"
            iTimeout = 100000 '100 secs
            SaveImage = True

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , iTimeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Grab Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            If Response_OK Then
                '[1] Update Processed Image ---
                If Me.m_Form.RadioButton_Func.Checked Then
                    image = Me.m_FuncProcess.Img_Original_NonPage   'Func
                    'If Me.m_ManualLoad Then
                    '    strPath = Me.m_ManualPath
                    'Else

                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                        Me.RepairPath_2(strPath)
                    End If
                    'End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_Mapping_NonPage)

                    End If
                End If

                'If System.IO.File.Exists(strPath) = True Then
                '    System.IO.File.Delete(strPath)
                'End If
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_GrayMean]Func Load Grab Image Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

        If Me.m_Form.RadioButton_Mura.Checked Then
            '----------------------------------------------------------------------------------------------
            ' Resize Original Image  ==> Request_Command = "RESIZE_ORIGINAL" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "RESIZE_ORIGINAL"
                iTimeout = 1000000 '1000 secs
                SaveImage = True

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , iTimeout)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(iTimeout)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error ! (" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                If SaveImage AndAlso Response_OK Then
                    '[1] Update Processed Image --- Resize 後的影像即為縮小後的Mura原始影像
                    If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                        image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                    Else
                        image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                    End If

                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                        Me.RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        'MbufCopy(image, Me.m_MainProcess.Img_Mapping_NonPage)

                        'If System.IO.File.Exists(strPath) = True Then
                        '    System.IO.File.Delete(strPath)
                        'End If
                    End If
                End If
            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_GrayMean]Mura Resize Image Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try

        End If

        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        Else
            Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        End If

        '----------------------------------------------------------------------------------------------
        ' Get Gray Mean  ==> Request_Command = "GET_GRAYMEAN" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "GET_GRAYMEAN"
            iTimeout = 500000 '500 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , iTimeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
                strs = SubSystemResult.Responses(0).Param2.Split(",")
                mean = strs(1)
                Max_GrayMean = SubSystemResult.Responses(0).Param3
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Get Gray Mean Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.get_GrayMean]Get Gray Mean Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.get_GrayMean]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End Try

    End Sub
#End Region

#End Region

#Region "---Event---"
#Region "---Button Continue---"
    Private Sub Button_Continue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_IPBootConfig.Digitizer_Type.Value = DigitizerType.Color And Me.m_Form.ComboBox_ColorBand.Text = "" Then
            MsgBox("請先選擇 Color Band !", MsgBoxStyle.Critical, "[AreaGrabber]")
            Exit Sub
        End If

        Dim image As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer

        Me.m_Ever_ContinueGrab = True
        Me.Button_Continue.Enabled = False
        Me.m_IsCalcFocusValue = Me.m_Form.CheckBox_MannualFocus.Checked
        'Me.Button_Load.Enabled = False
        Me.PatternSelect_Enable(False)

        ''--- Stop Grab First ---
        'Me.WaitGrabReady()

        ''---Initial---
        'Me.m_ManualLoad = False

        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
            image = Me.m_MainProcess.Img_16U_Grab_1
            If image <> M_NULL Then
                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                Type = MbufInquire(image, M_TYPE, M_NULL)

                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                    MbufFree(imageBuffer)
                    imageBuffer = M_NULL
                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                End If
                MbufCopy(image, imageBuffer)

                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                MbufControl(image, M_MODIFIED, M_DEFAULT)
                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                Me.m_Form.ResetScrollBar()
            End If
        Else
            Me.m_Form.CurrentIndex0 = 0
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 0
        End If

        Me.m_Form.ImageZoomAll()
        'Me.ZoomEnable(False)
        Me.UpdateExposureTime()

        If Me.m_Form.ComboBox_PatnList.Text = "" Then
            Me.Button_Continue.Enabled = True
            Me.m_Form.TrackBar_ExposureTime.Enabled = True
            Me.m_Form.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_SaveExpTime.Enabled = True
            MsgBox("請選擇Pattern")
        Else
            'Me.GroupBox_Mode.Enabled = False
            Me.m_Form.GroupBox_ExposureTime.Enabled = True
            Me.m_Form.TrackBar_ExposureTime.Enabled = False
            Me.m_Form.NumericUpDown_ExposureTime.Enabled = False
            Me.Button_SaveExpTime.Enabled = False
        End If


        'Thread --- Update Grab Image
        '---啟動 Run Command Thread ---

        Me.m_ContinueGrab = True
        Try
            If Not Me.m_Thread1_RunCommand Is Nothing Then
                Me.m_Thread1_RunCommand = Nothing
            End If

            If Not (Not Me.m_Thread1_RunCommand Is Nothing) Then
                Try
                    'If Not Me.m_MasterSlaveMode_Enable Then ' 封~~印~~~~~~~~~~
                    If True Then
                        Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.ContinueGrabImage)
                        Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        Me.m_Thread1_RunCommand.Start()
                    Else
                        ''--- MasterSlave Mode ---
                        'Me.m_Thread1_RunCommand = New System.Threading.Thread(AddressOf Me.MS_UpdateGrabImage)
                        'Me.m_Thread1_RunCommand.Name = "Thread1_RunCommand"
                        'Me.m_Thread1_RunCommand.SetApartmentState(Threading.ApartmentState.STA)
                        'Me.m_Thread1_RunCommand.Priority = Threading.ThreadPriority.Highest
                        'Me.m_Thread1_RunCommand.Start()
                    End If

                Catch ex As Exception
                    Throw New Exception(ex.Message)
                End Try
            End If
        Catch ex As Exception
            Me.ZoomEnable(True)
            Me.SetButtonStopGrabEnable(False)
            Me.m_Form.Button_Continue.Enabled = True
            Me.m_Form.Button_LoadImage.Enabled = True
            Me.m_Form.TrackBar_ExposureTime.Enabled = True
            Me.m_Form.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_SaveExpTime.Enabled = True
            Me.m_ContinueGrab = False
            Me.PatternSelect_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Continue](" & ex.Message & ")(" & ex.StackTrace & ")")
        End Try
    End Sub
    Private Sub Button_StopGrab_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        System.Threading.Thread.Sleep(GetExposureTimeInfo() / 1000)

        Dim image As MIL_ID = M_NULL
        Dim image2 As MIL_ID = M_NULL
        Dim imageBuffer As MIL_ID = M_NULL
        Dim SaveImage As Boolean = False
        Dim IP_Address As String = ""
        Dim SizeX, SizeY, Type As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer
        Dim strPath As String

        If Me.m_IPBootConfig.IsPixelShiftCCD.Value Then
            If Me.m_IPBootConfig.PixelShiftStage.Value = "1" Then
                Dim DelayTime As Integer = (GetExposureTimeInfo() * 4) / 1000 + 400
                System.Threading.Thread.Sleep(DelayTime)
            ElseIf Me.m_IPBootConfig.PixelShiftStage.Value = "2" Then
                Dim DelayTime As Integer = (GetExposureTimeInfo() * 9) / 1000 + 900
                System.Threading.Thread.Sleep(DelayTime)
            End If
        End If


        Try
            '--- Initial ---  
            IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

            Me.m_ContinueGrab = False  '2013/01/25 Rick add
            Me.SetButtonStopGrabEnable(False)
            Me.Button_SaveExpTime.Enabled = False
            'Me.m_Form.Button_AutoExposure.Enabled = False
            '--- 停止連續取像 ---
            Me.WaitGrabReady()

            '--- Finish Grab Image Thread ---  '2013/01/25 Rick add
            If (Me.m_Thread1_RunCommand Is Nothing) = False Then
                Me.m_Thread1_RunCommand = Nothing
            End If

            If Me.m_Form.ComboBox_ColorBand.Text = "raw" Then Exit Sub

            '--- 建立連線 ---
            'If Not Me.m_MasterSlaveMode_Enable Then ' 封~~印~~~~~~~~~~
            If True Then
                If Not Me.ConnectToIP Then
                    Me.Button_Continue.Enabled = True
                    Me.m_Form.Button_LoadImage.Enabled = True
                    Me.SetButtonStopGrabEnable(False)
                    Exit Sub
                End If
            Else '--- M\S Mode ---
                'If Not Me.MS_ConnectToIP Then
                '    Me.Button_Continue.Enabled = True
                '    Me.Button_Load.Enabled = True
                '    Me.SetButton_Grab(False)
                '    Exit Sub
                'End If
            End If

            Try
                'If Not Me.m_MasterSlaveMode_Enable Then ' 封~~印~~~~~~~~~~
                If True Then
                    '----------------------------------------------------------------------------------------------
                    ' IP LOAD GRAB IMAGE  ==> Request_Command = "LOAD_GRABIMAGE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    '--- Prepare Command ---
                    Request_Command = "LOAD_GRABIMAGE"
                    iTimeout = 10000 '100 secs
                    SaveImage = True

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , iTimeout)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Grab Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        'MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_Continue.Enabled = True
                        Me.m_Form.Button_LoadImage.Enabled = True
                        Me.SetButtonStopGrabEnable(False)
                        'Me.GroupBox_Mode.Enabled = True
                        Exit Sub
                    End If

                Else  '--- M\S Mode ---
                    '----------------------------------------------------------------------------------------------
                    ' IP LOAD IMAGE  ==> Request_Command = "LOAD_IMAGE" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    'Try
                    '    '--- Prepare Command ---
                    '    Request_Command = "LOAD_IMAGE"
                    '    iTimeout = 200000 '200 secs

                    '    '--- Initial ---  
                    '    IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress
                    '    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                    '        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                    '        strPath = strPath.Replace("\\", "\")
                    '    Else
                    '        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                    '        Me.RepairPath_2(strPath)
                    '    End If

                    '    Me.m_ManualPath = Me.m_Form.OpenFileDialog.FileName
                    '    Response_OK = False
                    '    Me.m_MainProcess.IP_Dispatcher1.PrepareRequest(m_Slave_ID, Request_Command, "", "", strPath, , , , , , iTimeout)
                    '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                    '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    '        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    '        Response_OK = True
                    '    Else
                    '        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Load Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    '        MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    '        Me.Button_Load.Enabled = True
                    '        If Me.m_Have_MDigitizer Then
                    '            Me.GroupBox_ExposureTime.Enabled = True
                    '            Me.GroupBox_Mode.Enabled = True
                    '        End If
                    '        Exit Sub
                    '    End If
                    'Catch ex As Exception
                    '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Grab]Load Image Error ! (" & ex.Message & ")")
                    '    MessageBox.Show("[Dialog_ADJMean.Button_Grab]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    '    Throw New Exception(ex.Message)
                    'End Try
                End If


                If Response_OK Then
                    '[1] Update Img_16U_Grab_1
                    image = Me.m_MainProcess.Img_16U_Grab_1

                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                        Me.RepairPath_2(strPath)
                    End If



                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_FuncProcess.Img_Original_NonPage)
                        Me.m_Form.ImageUpdate()

                        '--- Display ---
                        If Me.m_Form.ComboBox_Type.SelectedIndex = 0 And Me.m_Form.ComboBox_Select.SelectedIndex = 0 Then
                            If image <> M_NULL Then
                                imageBuffer = Me.m_MainProcess.Img_Mapping_NonPage
                                SizeX = MbufInquire(image, M_SIZE_X, M_NULL)
                                SizeY = MbufInquire(image, M_SIZE_Y, M_NULL)
                                Type = MbufInquire(image, M_TYPE, M_NULL)

                                If MbufInquire(imageBuffer, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(imageBuffer, M_SIZE_Y, M_NULL) <> SizeY Or MbufInquire(imageBuffer, M_TYPE, M_NULL) <> Type Then
                                    MbufFree(imageBuffer)
                                    imageBuffer = M_NULL
                                    imageBuffer = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)
                                End If
                                MbufCopy(image, imageBuffer)

                                MdispSelectWindow(Me.m_Form.AxMDisplay, imageBuffer, Me.m_Form.GetAxMDisplay_HandleInfo())
                                MbufControl(image, M_MODIFIED, M_DEFAULT)
                                MdispControl(Me.m_Form.AxMDisplay, MIL.M_VIEW_MODE, MIL.M_AUTO_SCALE)

                                Me.m_Form.ResetScrollBar()
                            End If
                        End If
                    End If


                    If Me.m_Form.RadioButton_Mura.Checked Then
                        Try
                            '--- Prepare Command ---
                            Request_Command = "Transfer_Mura_Boundary"
                            iTimeout = 10000 '10 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , iTimeout)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(iTimeout)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                Exit Sub
                            End If
                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try

                        image2 = Me.m_MuraProcess.Img_CurrentOriginal_NonPage

                        '[AreaGrabber] Load image2 --- (For Display)
                        '[1] image2 ---
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image2 <> M_NULL Then
                            If MbufInquire(image2, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image2, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image2)
                                image2 = M_NULL
                                image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image2 = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If
                        MbufLoad(strPath, image2)
                    End If

                    If System.IO.File.Exists(strPath) = True Then
                        System.IO.File.Delete(strPath)
                    End If

                    If Me.m_Form.RadioButton_Mura.Checked Then
                        Try
                            '--- Prepare Command ---
                            Request_Command = "RESIZE_ORIGINAL"
                            iTimeout = 500000 '500 secs
                            SaveImage = True

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, SaveImage, , , , , , , , iTimeout)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(iTimeout)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Resize Original Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                'MessageBox.Show("[Dialog_ADJMean.Button_Grab_Click]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.Button_Continue.Enabled = True
                                Me.m_Form.Button_LoadImage.Enabled = True
                                Me.SetButtonStopGrabEnable(False)
                                Exit Sub
                            End If

                            If SaveImage AndAlso Response_OK Then
                                '[1] Update Processed Image --- Resize 後的影像即為縮小後的Mura原始影像
                                If Me.m_MuraProcess.CurrentMuraPatternRecipe.UseFFC.Value Then
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentSample_NonPage
                                Else
                                    image = Me.m_MainProcess.MuraProcess.Img_CurrentOriginal_NonPage
                                End If

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "ResizeOriginal.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "ResizeOriginal.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) And FileLen(strPath) > 0 Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If image <> M_NULL Then
                                        If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(image)
                                            image = M_NULL
                                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, image)
                                    'MbufCopy(image, Me.m_MainProcess.Img_Mapping_NonPage)

                                    If System.IO.File.Exists(strPath) = True Then
                                        System.IO.File.Delete(strPath)
                                    End If
                                End If
                            End If

                        Catch ex As Exception
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try
                    End If
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_MuraProcess.CalculateOriginalROI(Me.m_MuraProcess.MuraModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            Else
                Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
            End If

            'Me.m_Form.ImageZoomAll()

            'Me.GroupBox_Mode.Enabled = True
            Me.m_Form.GroupBox_ExposureTime.Enabled = True
            Me.m_Form.TrackBar_ExposureTime.Enabled = True
            Me.m_Form.NumericUpDown_ExposureTime.Enabled = True
            Me.Button_SaveExpTime.Enabled = True
            'If Me.RadioButton_Auto.Checked Then
            '    Me.Button_AutoExposure.Enabled = True
            'End If

            Me.m_Form.Button_Continue.Enabled = True
            Me.m_Form.Button_LoadImage.Enabled = True
            Me.SetButtonStopGrabEnable(False)
            Me.PatternSelect_Enable(True)

        Catch ex As Exception
            Me.m_Form.Button_Continue.Enabled = True
            Me.m_Form.Button_LoadImage.Enabled = True
            Me.SetButtonStopGrabEnable(False)
            'Me.GroupBox_Mode.Enabled = False
            Me.m_Form.TrackBar_ExposureTime.Enabled = False
            Me.m_Form.NumericUpDown_ExposureTime.Enabled = False
            Me.m_ContinueGrab = False
            Me.PatternSelect_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_AutoManual.Button_Grab]Grab Image Error!(" & ex.Message & ")")
        End Try
    End Sub
#End Region
#Region "--- Button SaveExpTime ---"
    Private Sub Button_SaveExpTime_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim str As String
        Dim dir As String
        Dim i As Integer
        Dim Parameter_Lists As String = ""
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            Me.Button_SaveExpTime.Enabled = False   '2010/06/10 Rick add 
            'Me.GroupBox_Mode.Enabled = False   '2010/06/13 Rick add 

            Me.Setting()   '2010/06/01 Rick add

            '----------------------------------------------------------------------------------------------
            ' Dialog_ADJMean Setting   ==> Request_Command = "DIALOG_ADJMEAN_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_ADJMEAN_SETTING"
                iTimeout = 100000 '100 secs

                Parameter_Lists = "ExposureTime," & Me.m_Form.NumericUpDown_ExposureTime.Value & ";" & "MeanTarget," & 1500 & ";" & "ErrorRange," & 5 & ";" & "Kp," & 30 & ";" & "Max_ExposureTime," & Me.m_Max_ExposureTime

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , iTimeout)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_ADJMean Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_ADJMean.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_SaveExpTime.Enabled = True
                    'Me.GroupBox_Mode.Enabled = True
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try


            If Me.m_Form.RadioButton_Func.Checked = True Then   '2010/05/19 Rick add
                i = Me.m_MainProcess.FuncPatternRecipeArrayOrder.IndexOf(Me.m_FuncProcess.CurrentFuncPatternRecipe)
                Me.CompareFunc(Me.m_MainProcess.FuncPatternRecipeArrayTemp.Item(i), Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray.Item(i), Me.m_MainProcess.RecipeDailyLogManager)

                str = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & i + 1 & ".xml"
                ClsFuncPatternRecipe.WriteXML(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i), str)

                '----------------------------------------------------------------------------------------------
                ' Save Current Func Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE"
                    iTimeout = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , iTimeout)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Func Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_SaveExpTime.Enabled = True
                        'Me.GroupBox_Mode.Enabled = True
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try
            ElseIf Me.m_Form.RadioButton_Mura.Checked = True Then
                i = Me.m_MainProcess.MuraPatternRecipeArrayOrder.IndexOf(Me.m_MuraProcess.CurrentMuraPatternRecipe)
                Me.CompareMura(Me.m_MainProcess.MuraPatternRecipeArrayTemp.Item(i), Me.m_MuraProcess.MuraPatternRecipeArray.Item(i), Me.m_MainProcess.RecipeDailyLogManager)

                str = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & i + 1 & ".xml"
                ClsMuraPatternRecipe.WriteXML(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i), str)

                '----------------------------------------------------------------------------------------------
                ' Save Current Mura Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_CURRENT_MURAPATTERN_RECIPE"
                    iTimeout = 200000 '200 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , iTimeout)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Mura Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                        MessageBox.Show("[Dialog_ADJMean.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Me.Button_SaveExpTime.Enabled = True
                        'Me.GroupBox_Mode.Enabled = True
                        Exit Sub
                    End If
                Catch ex As Exception
                    Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                End Try

            End If

            If Me.m_Form.RadioButton_Func.Checked Then
                'Func Recipe Monitor ---
                dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
                If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
                Me.m_FuncProcess.SaveToFuncRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)
            Else
                'Mura Recipe Monitor ---
                dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
                If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
                Me.m_MuraProcess.SaveToMuraRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)
            End If

            'Me.GroupBox_Mode.Enabled = True

            Me.Button_Continue.Enabled = True
            Me.m_Form.Button_LoadImage.Enabled = True
            Me.SetButtonStopGrabEnable(False)
            Me.Button_SaveExpTime.Enabled = True
        Catch ex As Exception
            Me.Button_SaveExpTime.Enabled = True
            'Me.GroupBox_Mode.Enabled = True

            Me.Button_Continue.Enabled = True
            Me.m_Form.Button_LoadImage.Enabled = True
            Me.SetButtonStopGrabEnable(False)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_Save]" & ex.Message)
        End Try
    End Sub
#End Region
#Region "--- Button_MannualMean ---"
    Private Sub Button_MannualMean_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim mean As Integer
        Dim Gray_max As Integer
        Dim str_log As String

        Me.m_Form.Button_MannualMean.Enabled = False
        Me.m_Form.Label_ROI_Mean.Text = "ROI Mean："
        'Me.m_Form.Label_ROI_Max.Text = "ROI Max："
        Try
            Me.get_GrayMean(mean, Gray_max)

            Me.m_Form.Label_ROI_Mean.Text = "ROI Mean：" & mean
            'Me.m_Form.Label_ROI_Max.Text = "ROI Max：" & Gray_max

            str_log = Me.m_Form.NumericUpDown_ExposureTime.Value & vbTab & mean & vbTab & Gray_max
            Utils.WriteLog(Me.m_MainProcess.TEMP_PATH & "\" & Me.m_MainProcess.ProductName & "_C" & Me.m_MainProcess.GrabNo & "_ExposureMean.txt", str_log)

            Me.m_Form.Button_MannualMean.Enabled = True
        Catch ex As Exception
            Me.m_Form.Button_MannualMean.Enabled = True
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.Button_CaculateMean]" & ex.Message)
        End Try
    End Sub
#End Region

#Region "--- RadioButton_Func_CheckedChanged ---"
    Private Sub RadioButton_Func_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim i As Integer
        Dim ExposureTime As Integer
        Dim PatternName As String
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer

        ''--- 停止連續取像 ---
        'Me.WaitGrabReady()

        If Me.m_Form.RadioButton_Func.Checked = True Then

            '[AreaGrabber]
            Me.m_Form.ComboBox_PatnList.Items.Clear()
            For i = 0 To Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value - 1
                Me.m_Form.ComboBox_PatnList.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next

            '[AreaGrabber] Set Recipe ---  
            Me.m_MainProcess.SetRecipe(Me.m_FuncProcess.FuncPatternRecipeArray.Item(0).PatternName.Value, Me.m_MainProcess.ErrorCode)
            Me.m_Form.ComboBox_PatnList.SelectedIndex = 0

            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                iTimeout = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.m_Form.ComboBox_PatnList.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , iTimeout)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    'MessageBox.Show("[Dialog_ADJMean.RadioButton_Func_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.RadioButton_Func_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
                ''MessageBox.Show("[Dialog_ADJMean.RadioButton_Func_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            If Me.m_Form.RadioButton_Func.Checked = True Then
                ExposureTime = Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_PatnList.SelectedIndex).ExposureTime.Value
                'Me.m_Form.TextBox_Kp.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_PatnList.SelectedIndex).AutoExposure_Kp.Value)
                'Me.m_Form.TextBox_MeanTarget.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_PatnList.SelectedIndex).AutoExposure_TargetMean.Value)
                'Me.m_Form.TextBox_ErrorRange.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_PatnList.SelectedIndex).AutoExposure_SmallErrorRange.Value)

                '--- 更新曝光時間 ---
                '--- 須滿足最小曝光時間 16000 --- 
                'If ExposureTime < 16000 Then
                'ExposureTime = 16000
                Me.m_FuncProcess.FuncPatternRecipeArray.Item(Me.m_Form.ComboBox_PatnList.SelectedIndex).ExposureTime.Value = ExposureTime
                'End If

                'If Me.m_Have_MDigitizer Then
                Me.m_Form.TrackBar_ExposureTime.Value = ExposureTime
                Me.m_Form.NumericUpDown_ExposureTime.Value = ExposureTime
                'End If
            End If

        End If
    End Sub
#End Region
#Region "--- RadioButton_Mura_CheckedChanged ---"
    Private Sub RadioButton_Mura_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim i As Integer
        Dim PatternName As String
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer

        If Me.m_Form.RadioButton_Mura.Checked = True Then

            ''--- 停止連續取像 ---
            'Me.WaitGrabReady()

            '[AreaGrabber]
            Me.m_Form.ComboBox_PatnList.Items.Clear()
            For i = 0 To Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1
                Me.m_Form.ComboBox_PatnList.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next

            '[AreaGrabber] Set Recipe ---   
            Me.m_MainProcess.SetRecipe(Me.m_MuraProcess.MuraPatternRecipeArray.Item(0).PatternName.Value, Me.m_MainProcess.ErrorCode)
            Me.m_Form.ComboBox_PatnList.SelectedIndex = 0

            '--- 建立連線 ---
            If Me.ConnectToIP = False Then
                Exit Sub
            End If

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                iTimeout = 100000 '100 secs

                '--- PatternName ---
                PatternName = Me.m_Form.ComboBox_PatnList.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , iTimeout)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    'MessageBox.Show("[Dialog_ADJMean.RadioButton_Mura_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.RadioButton_Mura_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
                'MessageBox.Show("[Dialog_ADJMean.RadioButton_Mura_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '這是在哈囉?!
            If Me.m_Form.RadioButton_Func.Checked = True Then
                'ExposureTime = Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).ExposureTime.Value
                'Me.TextBox_Kp.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_Kp.Value)
                'Me.TextBox_MeanTarget.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_TargetMean.Value)
                'Me.TextBox_ErrorRange.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).AutoExposure_SmallErrorRange.Value)


                ''--- 更新曝光時間 ---
                ''--- 須滿足最小曝光時間 16000 --- 
                ''If ExposureTime < 16000 Then
                ''ExposureTime = 16000
                'Me.m_MuraProcess.MuraPatternRecipeArray.Item(Me.ComboBox_PatnList.SelectedIndex).ExposureTime.Value = ExposureTime
                ''End If
                'If Me.m_Have_MDigitizer Then
                '    Me.TrackBar_ExposureTime.Value = ExposureTime
                '    Me.NumericUpDown_ExposureTime.Value = ExposureTime
                'End If
            End If

        End If
    End Sub
#End Region
#Region "---TrackBar_ExposureTime ---"
    Private Sub TrackBar_ExposureTime_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        'If Me.m_Initial_Finished = False Then Exit Sub
        If Me.m_Ever_ContinueGrab = False Then Exit Sub
        Dim trkBar As TrackBar = Convert.ChangeType(sender, GetType(TrackBar))

        '--- 更新曝光時間 ---
        '--- 須滿足最小曝光時間 16000 --- 
        'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
        Me.m_Form.NumericUpDown_ExposureTime.Value = trkBar.Value

    End Sub


#End Region
#Region "--- CheckBox_ShowBoundary_CheckedChanged ---"
    Private Sub CheckBox_ShowBoundary_CheckedChanged(sender As System.Object, e As System.EventArgs)
        If Me.m_Form.CheckBox_ExpShowBoundary.Checked Then
            PitchCheck_Boundary()
        End If
        Me.ReDraw(pb)
    End Sub
#End Region
#Region "--- ComboBox_PatnList_SelectedIndexChanged ---"
    Private Sub ComboBox_PatnList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim PatternName As String
        Dim PatternIndex As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer

        ''--- 停止連續取像 ---
        'Me.WaitGrabReady()

        '--- 建立連線 ---
        If Me.ConnectToIP = False Then
            Exit Sub
        End If

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            iTimeout = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.GetPatternNameInfo()

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , iTimeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.ComboBox_PatnList_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try


        '[AreaGrabber]
        If Me.m_Form.RadioButton_Mura.Checked = True Then
            PatternIndex = Me.m_Form.ComboBox_PatnList.SelectedIndex
            Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '從[1]開始
            If Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).ExposureTime.Value >= Me.m_Form.TrackBar_ExposureTime.Maximum Then
                Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).ExposureTime.Value = Me.m_Form.TrackBar_ExposureTime.Maximum - 1
            End If
            Me.m_Form.TrackBar_ExposureTime.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).ExposureTime.Value
            'Me.m_Form.TextBox_Kp.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).AutoExposure_Kp.Value)
            'Me.m_Form.TextBox_MeanTarget.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).AutoExposure_TargetMean.Value)
            'Me.m_Form.TextBox_ErrorRange.Text = CStr(Me.m_MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).AutoExposure_SmallErrorRange.Value)

        ElseIf Me.m_Form.RadioButton_Func.Checked = True Then
            PatternIndex = Me.m_Form.ComboBox_PatnList.SelectedIndex
            Me.m_Form.SetPatternIndexInfo(PatternIndex + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value + 1)  '從[1]開始
            If Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).ExposureTime.Value >= Me.m_Form.TrackBar_ExposureTime.Maximum Then
                Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).ExposureTime.Value = Me.m_Form.TrackBar_ExposureTime.Maximum - 1
            End If
            Me.m_Form.TrackBar_ExposureTime.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).ExposureTime.Value
            'Me.m_Form.TextBox_Kp.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).AutoExposure_Kp.Value)
            'Me.m_Form.TextBox_MeanTarget.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).AutoExposure_TargetMean.Value)
            'Me.m_Form.TextBox_ErrorRange.Text = CStr(Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).AutoExposure_SmallErrorRange.Value)
        End If

        '--- 更新曝光時間 ---
        '--- 須滿足最小曝光時間 16000 --- 
        'If Me.TrackBar_ExposureTime.Value < 16000 Then Me.TrackBar_ExposureTime.Value = 16000
        Me.m_Form.NumericUpDown_ExposureTime.Value = Me.m_Form.TrackBar_ExposureTime.Value

        'If Me.m_Have_MDigitizer Then

        '----------------------------------------------------------------------------------------------
        ' Update Current Exposure Time  ==> Request_Command = "UPDATE_EXPOSURETIME" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "UPDATE_EXPOSURETIME"
            iTimeout = 100000 '100 secs

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_Form.NumericUpDown_ExposureTime.Value, , , , , , , , iTimeout)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Response_OK = False
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Response_OK = False
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Update Current Exposure Time Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        'End If

        '[AreaGrabber]
        Me.Button_Continue.Enabled = True
        'Me.Button_Load.Enabled = True
        Me.SetButtonStopGrabEnable(False)
        Me.m_Form.TrackBar_ExposureTime.Enabled = False
        Me.m_Form.NumericUpDown_ExposureTime.Enabled = False

    End Sub
#End Region

#Region "--- NumericUpDown_ExposureTime_ValueChanged ---"
    Private Sub NumericUpDown_ExposureTime_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_MainProcess Is Nothing Then Exit Sub
        If Not Me.m_Ever_ContinueGrab Then Exit Sub

        Dim Image As MIL_ID = Nothing
        Dim IP_Address As String = ""
        'Dim PatternName As String
        'Dim PatternIndex As Integer
        Dim SizeX, SizeY, Type As Integer
        Dim ColorBand As String = Me.GetColorBandParam() 'Image Band (R\G\B\L --> Color相機 ：空白 --> Mono相機)
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = String.Empty
        Dim iTimeout As Integer
        Dim strPath As String


        '--- Initial --- 
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        'Stop Grab First ---
        Me.WaitGrabReady()

        '[AreaGrabber]    
        'If Me.RadioButton_Mura.Checked = True Then
        '    PatternIndex = Me.ComboBox_PatnList.SelectedIndex
        '    Me.m_Form.SetPatternIndexInfo(PatternIndex + 1)  '從[1]開始
        'ElseIf Me.RadioButton_Func.Checked = True Then
        '    PatternIndex = Me.ComboBox_PatnList.SelectedIndex
        '    Me.m_Form.SetPatternIndexInfo(PatternIndex + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value + 1)   '從[1]開始
        'End If

        'If Me.m_Form.RadioButton_Mura.Checked Or Me.m_Form.RadioButton_Func.Checked Then
        '    Me.TrackBar_ExposureTime.Value = Me.NumericUpDown_ExposureTime.Value
        'Else
        '    Exit Sub
        'End If

        '--- Button Disable ---
        Me.Button_SaveExpTime.Enabled = False
        'Me.GroupBox_Mode.Enabled = False
        'If Me.m_Have_MDigitizer Then Me.Button_Continue.Enabled = False
        'Me.Button_Load.Enabled = False
        Me.m_Form.TrackBar_ExposureTime.Enabled = False

        ''----------------------------------------------------------------------------------------------
        '' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        ''----------------------------------------------------------------------------------------------
        'Try
        '    '--- Prepare Command ---
        '    Request_Command = "SET_PATTERNINDEX"
        '    TimeOut = 100000 '100 secs

        '    '--- PatternName ---
        '    PatternName = Me.GetPatternNameInfo

        '    Response_OK = False
        '    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
        '    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

        '    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
        '        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
        '        Response_OK = True
        '    Else
        '        Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error ! " & "(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
        '        MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        '        Exit Sub
        '    End If
        'Catch ex As Exception
        '    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Set Pattern Index Error ! (" & ex.Message & ")")
        '    MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        'End Try

        If Not Me.m_MainProcess Is Nothing Then

            Try
                If Not Me.m_Form Is Nothing AndAlso (Me.m_IPBootConfig.CardSystem.Value <> "" Or Me.m_IPBootConfig.CCD_Link_Type.Value = CCD_LinkType.GigE) Then

                    'If Me.m_Have_MDigitizer Then
                    '----------------------------------------------------------------------------------------------
                    ' Update Current Exposure Time  ==> Request_Command = "UPDATE_EXPOSURETIME" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "UPDATE_EXPOSURETIME"
                        iTimeout = 100000 '100 secs

                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Me.m_Form.NumericUpDown_ExposureTime.Value, , , , , , , , iTimeout)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Response_OK = False
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Update Current Exposure Time Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If
                    Catch ex As Exception
                        Response_OK = False
                        Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]Update Current Exposure Time Error ! (" & ex.Message & ")")
                        'MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End Try
                    'End If

                    If Response_OK Then
                        '----------------------------------------------------------------------------------------------
                        ' Grab One Image  ==> Request_Command = "GRAB_ONESHOT" (Dispatcher 1)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "GRAB_ONESHOT"
                            iTimeout = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, ColorBand, , , , , , , , iTimeout)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeout)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                Response_OK = True
                            Else
                                Response_OK = False
                                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Grab One Image Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_ADJMean.ExposureTime_ValueChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                            If Response_OK Then
                                '--- Update Processed Image ---
                                Image = Me.m_MainProcess.Img_16U_Grab_1

                                If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                                    strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_16U_Grab_1.tif"
                                    strPath = strPath.Replace("\\", "\")
                                Else
                                    strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_16U_Grab_1.tif"
                                    Me.RepairPath_2(strPath)
                                End If

                                If System.IO.File.Exists(strPath) Then
                                    MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                                    MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                                    MbufDiskInquire(strPath, M_TYPE, Type)
                                    If Image <> M_NULL Then
                                        If MbufInquire(Image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(Image, M_SIZE_Y, M_NULL) <> SizeY Then
                                            MbufFree(Image)
                                            Image = M_NULL
                                            Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                        End If
                                    Else
                                        Image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                                    End If

                                    '--- Load Remote Image ---
                                    MbufLoad(strPath, Image)
                                    MbufCopy(Image, Me.m_MainProcess.Img_Mapping_NonPage)

                                    Me.m_Form.ImageUpdate()
                                    Me.Button_SaveExpTime.Enabled = True
                                End If
                            End If
                        Catch ex As Exception
                            Response_OK = False
                            Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                        End Try
                    End If

                    '--- Stop Grab First ---
                    Me.SetButtonStopGrabEnable(False)
                    'If Me.m_Have_MDigitizer Then Me.Button_Continue.Enabled = True
                    Me.Button_SaveExpTime.Enabled = True
                End If

            Catch ex As Exception
                'If Me.m_Have_MDigitizer Then Me.Button_Continue.Enabled = True
                'Me.Button_Load.Enabled = True
                Me.SetButtonStopGrabEnable(False)
                Me.Button_SaveExpTime.Enabled = True
                'Me.GroupBox_Mode.Enabled = True
                Me.m_Form.TrackBar_ExposureTime.Enabled = True
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_ADJMean.ExposureTime_ValueChanged]" & ex.Message)
            End Try
        End If

        System.Threading.Thread.Sleep(200)
        Me.Button_SaveExpTime.Enabled = True
        Me.m_Form.TrackBar_ExposureTime.Enabled = True
        'Me.GroupBox_Mode.Enabled = True

    End Sub
#End Region

#End Region

#Region "---UI Invoke---"
#Region "---Button Continue---"
    Private Delegate Function SetButton_StopGrabEnableHandler(ByVal En As Boolean) As Boolean
    Private Function SetButtonStopGrabEnable(ByVal En As Boolean) As Boolean
        If Me.m_Form.Button_StopGrab.InvokeRequired Then
            Me.m_Form.Button_StopGrab.Invoke(New SetButton_StopGrabEnableHandler(AddressOf SetButtonStopGrabEnable), New Object() {En})
        Else
            Me.m_Form.Button_StopGrab.Enabled = En
            Me.m_Form.RefreshUI()
        End If
        Return True
    End Function
#End Region
#Region "---Label FocusValue"
    Delegate Sub SetLabel_FocusValueInfoCallback(ByVal Text As String)
    Public Sub SetLabel_FocusValueInfo(ByVal Text As String)
        If Me.m_Form.Label_FocusValue.InvokeRequired Then
            Me.m_Form.Label_FocusValue.Invoke(New SetLabel_FocusValueInfoCallback(AddressOf SetLabel_FocusValueInfo), New Object() {Text})
        Else
            Me.m_Form.Label_FocusValue.Text = Text
            Me.m_Form.RefreshUI()
        End If
    End Sub
#End Region
#Region "---ComboBox PatnList ---"
    Delegate Sub SetComboBox_PatnList_EnableInfoCallback(ByVal En As Boolean)
    Public Sub SetComboBox_PatnList_EnableInfo(ByVal En As Boolean)
        If Me.m_Form.ComboBox_PatnList.InvokeRequired Then
            Me.m_Form.ComboBox_PatnList.Invoke(New SetComboBox_PatnList_EnableInfoCallback(AddressOf SetComboBox_PatnList_EnableInfo), New Object() {En})
        Else
            Me.m_Form.ComboBox_PatnList.Enabled = En
            Me.m_Form.RefreshUI()
        End If
    End Sub
#End Region

#Region "--- RadioButton_Mura ---"
    Delegate Sub SetRadioButton_Mura_EnableInfoCallback(ByVal En As Boolean)
    Public Sub SetRadioButton_Mura_EnableInfo(ByVal En As Boolean)
        If Me.m_Form.RadioButton_Mura.InvokeRequired Then
            Me.m_Form.RadioButton_Mura.Invoke(New SetRadioButton_Mura_EnableInfoCallback(AddressOf SetRadioButton_Mura_EnableInfo), New Object() {En})
        Else
            Me.m_Form.RadioButton_Mura.Enabled = En
            Me.m_Form.RefreshUI()
        End If
    End Sub
#End Region

#Region "--- RadioButton_Func ---"
    Delegate Sub SetRadioButton_Func_EnableInfoCallback(ByVal En As Boolean)
    Public Sub SetRadioButton_Func_EnableInfo(ByVal En As Boolean)
        If Me.m_Form.RadioButton_Func.InvokeRequired Then
            Me.m_Form.RadioButton_Func.Invoke(New SetRadioButton_Func_EnableInfoCallback(AddressOf SetRadioButton_Func_EnableInfo), New Object() {En})
        Else
            Me.m_Form.RadioButton_Func.Enabled = En
            Me.m_Form.RefreshUI()
        End If
    End Sub
#End Region

#Region "--- GetExposureTimeInfo ---"
    Delegate Function GetExposureTimeInfoCallback() As Double
    Public Function GetExposureTimeInfo() As Double
        Dim i As Double
        If Me.m_Form.NumericUpDown_ExposureTime.InvokeRequired Then
            Me.m_Form.NumericUpDown_ExposureTime.Invoke(New GetExposureTimeInfoCallback(AddressOf GetExposureTimeInfo), New Object() {})
        Else
            i = Me.m_Form.NumericUpDown_ExposureTime.Value
            Me.m_Form.RefreshUI()
            Return i
        End If
    End Function
#End Region

#Region "--- GetPatternNameInfoCallback ---"
    Delegate Function GetPatternNameInfoCallback() As String
    Private Function GetPatternNameInfo() As String
        Dim PatternName As String
        If Me.m_Form.ComboBox_PatnList.InvokeRequired Then
            Return Me.m_Form.ComboBox_PatnList.Invoke(New GetPatternNameInfoCallback(AddressOf GetPatternNameInfo), New Object() {})
        Else
            PatternName = Me.m_Form.ComboBox_PatnList.Text
            Me.m_Form.RefreshUI()
            Return PatternName
        End If
    End Function
#End Region
#Region "--- GetColorBand ---"
    Delegate Function GetColorBandParamHandler() As String
    Private Function GetColorBandParam() As String
        Dim rtn As String
        If Me.m_Form.ComboBox_ColorBand.InvokeRequired Then
            Return Me.m_Form.ComboBox_ColorBand.Invoke(New GetColorBandParamHandler(AddressOf GetColorBandParam), New Object() {})
        Else
            rtn = Me.m_Form.ComboBox_ColorBand.Text
            Me.m_Form.RefreshUI()
            Return rtn
        End If
    End Function
#End Region

#End Region

End Class
