﻿Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL
Imports MILOperationLib
Imports ClassLibrary
Imports AUO.SubSystemControl
Imports System.IO


Public Class ClsFuncParamUIIMP

#Region "--- Variable ---"
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    Private m_IPBootConfig As ClsIPBootConfig

    ''--- PL Mark ---
    'Private m_CurrentPLMark As New ClsPLMark
    'Private m_CurrentPLMarkIndex As Integer = 0   '目前所選擇的 Mark
    'Private m_AxMDisplay_PLMark As MIL_ID         '顯示 PLMark

    '--- Temp ---
    Private m_offX As Integer
    Private m_offY As Integer

    '--- 繪圖 ---
    Private m_AxMDisplay As MIL_ID
    Private m_BitMap As Bitmap
    Private m_GraphicsImage As Graphics
    Private m_GraphicsDisplay As Graphics
    Private m_SolidBrush As SolidBrush
    Private m_Pen As Pen
    Private m_Size As Integer
    '--- Display ---
    Private WithEvents m_Panel_AxMDisplay As System.Windows.Forms.Panel

#End Region

#Region "--- Properties ---"

#End Region

#Region "--- Constructor ---"
    Public Sub New(ByVal mainFrm As Main_Form)
        Me.m_Form = mainFrm
    End Sub
#End Region

#Region "--- Public Method ---"
    Public Sub Init()
        Try
            Me.m_MainProcess = Me.m_Form.MainProcess
            Me.m_FuncProcess = Me.m_MainProcess.FuncProcess
            Me.m_MuraProcess = Me.m_MainProcess.MuraProcess
            Me.m_IPBootConfig = Me.m_MainProcess.IPBootConfig

            Me.m_offX = Me.m_FuncProcess.FuncModelRecipe.Boundary.LeftX
            Me.m_offY = Me.m_FuncProcess.FuncModelRecipe.Boundary.TopY

            'Me.m_UpdatePLMark = False
            'Me.m_UpdatePLTH = False
            RemoveHandler Me.m_Form.Button_SaveFuncParam.Click, AddressOf Button_SaveFuncParam_Click
            AddHandler Me.m_Form.Button_SaveFuncParam.Click, AddressOf Button_SaveFuncParam_Click

            RemoveHandler Me.m_Form.RadioButton_BP.CheckedChanged, AddressOf RadioButton_BP_CheckedChanged
            AddHandler Me.m_Form.RadioButton_BP.CheckedChanged, AddressOf RadioButton_BP_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_BPDP.CheckedChanged, AddressOf RadioButton_BPDP_CheckedChanged
            AddHandler Me.m_Form.RadioButton_BPDP.CheckedChanged, AddressOf RadioButton_BPDP_CheckedChanged

            RemoveHandler Me.m_Form.RadioButton_BP_Threshold.Click, AddressOf RadioButton_BP_Threshold_CheckedChanged
            AddHandler Me.m_Form.RadioButton_BP_Threshold.Click, AddressOf RadioButton_BP_Threshold_CheckedChanged

            RemoveHandler Me.m_Form.RadioButton_BP_Threshold_Low.CheckedChanged, AddressOf RadioButton_BP_Threshold_Low_CheckedChanged
            AddHandler Me.m_Form.RadioButton_BP_Threshold_Low.CheckedChanged, AddressOf RadioButton_BP_Threshold_Low_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_BP_RimThreshold.CheckedChanged, AddressOf RadioButton_BP_RimThreshold_CheckedChanged
            AddHandler Me.m_Form.RadioButton_BP_RimThreshold.CheckedChanged, AddressOf RadioButton_BP_RimThreshold_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_BP_RimThreshold_Low.CheckedChanged, AddressOf RadioButton_BP_RimThreshold_Low_CheckedChanged
            AddHandler Me.m_Form.RadioButton_BP_RimThreshold_Low.CheckedChanged, AddressOf RadioButton_BP_RimThreshold_Low_CheckedChanged

            RemoveHandler Me.m_Form.RadioButton_DP_Threshold.Click, AddressOf RadioButton_DP_Threshold_CheckedChanged
            AddHandler Me.m_Form.RadioButton_DP_Threshold.Click, AddressOf RadioButton_DP_Threshold_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_DP_Threshold_Low.Click, AddressOf RadioButton_DP_Threshold_Low_CheckedChanged
            AddHandler Me.m_Form.RadioButton_DP_Threshold_Low.Click, AddressOf RadioButton_DP_Threshold_Low_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_DP_RimThreshold.Click, AddressOf RadioButton_DP_RimThreshold_CheckedChanged
            AddHandler Me.m_Form.RadioButton_DP_RimThreshold.Click, AddressOf RadioButton_DP_RimThreshold_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_DP_RimThreshold_Low.Click, AddressOf RadioButton_DP_RimThreshold_Low_CheckedChanged
            AddHandler Me.m_Form.RadioButton_DP_RimThreshold_Low.Click, AddressOf RadioButton_DP_RimThreshold_Low_CheckedChanged

            RemoveHandler Me.m_Form.NumericUpDown_BP_Threshold.ValueChanged, AddressOf NumericUpDown_BP_Threshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_BP_Threshold.ValueChanged, AddressOf NumericUpDown_BP_Threshold_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_BP_Threshold_Low.ValueChanged, AddressOf NumericUpDown_BP_Threshold_Low_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_BP_Threshold_Low.ValueChanged, AddressOf NumericUpDown_BP_Threshold_Low_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_BP_RimThreshold.ValueChanged, AddressOf NumericUpDown_BP_RimThreshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_BP_RimThreshold.ValueChanged, AddressOf NumericUpDown_BP_RimThreshold_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_BP_RimThreshold_Low.ValueChanged, AddressOf NumericUpDown_BP_RimThreshold_Low_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_BP_RimThreshold_Low.ValueChanged, AddressOf NumericUpDown_BP_RimThreshold_Low_ValueChanged

            RemoveHandler Me.m_Form.NumericUpDown_DP_Threshold.ValueChanged, AddressOf NumericUpDown_DP_Threshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_DP_Threshold.ValueChanged, AddressOf NumericUpDown_DP_Threshold_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_DP_Threshold_Low.ValueChanged, AddressOf NumericUpDown_DP_Threshold_Low_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_DP_Threshold_Low.ValueChanged, AddressOf NumericUpDown_DP_Threshold_Low_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_DP_RimThreshold.ValueChanged, AddressOf NumericUpDown_DP_RimThreshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_DP_RimThreshold.ValueChanged, AddressOf NumericUpDown_DP_RimThreshold_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_DP_RimThreshold_Low.ValueChanged, AddressOf NumericUpDown_DP_RimThreshold_Low_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_DP_RimThreshold_Low.ValueChanged, AddressOf NumericUpDown_DP_RimThreshold_Low_ValueChanged

            RemoveHandler Me.m_Form.NumericUpDown_BL_Threshold.ValueChanged, AddressOf NumericUpDown_BL_Threshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_BL_Threshold.ValueChanged, AddressOf NumericUpDown_BL_Threshold_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_BL_RimThreshold.ValueChanged, AddressOf NumericUpDown_BL_RimThreshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_BL_RimThreshold.ValueChanged, AddressOf NumericUpDown_BL_RimThreshold_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_DL_Threshold.ValueChanged, AddressOf NumericUpDown_DL_Threshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_DL_Threshold.ValueChanged, AddressOf NumericUpDown_DL_Threshold_ValueChanged
            RemoveHandler Me.m_Form.NumericUpDown_DL_RimThreshold.ValueChanged, AddressOf NumericUpDown_DL_RimThreshold_ValueChanged
            AddHandler Me.m_Form.NumericUpDown_DL_RimThreshold.ValueChanged, AddressOf NumericUpDown_DL_RimThreshold_ValueChanged

            RemoveHandler Me.m_Form.CheckBox_Point_Enable.CheckedChanged, AddressOf CheckBox_Point_Enable_CheckedChanged
            AddHandler Me.m_Form.CheckBox_Point_Enable.CheckedChanged, AddressOf CheckBox_Point_Enable_CheckedChanged
            RemoveHandler Me.m_Form.CheckBox_Line_Enable.CheckedChanged, AddressOf CheckBox_Line_Enable_CheckedChanged
            AddHandler Me.m_Form.CheckBox_Line_Enable.CheckedChanged, AddressOf CheckBox_Line_Enable_CheckedChanged
            RemoveHandler Me.m_Form.CheckBox_GrayAbnormal_Enable.CheckedChanged, AddressOf CheckBox_GrayAbnormal_Enable_CheckedChanged
            AddHandler Me.m_Form.CheckBox_GrayAbnormal_Enable.CheckedChanged, AddressOf CheckBox_GrayAbnormal_Enable_CheckedChanged

            RemoveHandler Me.m_Form.CheckBox_BLine_Enable.CheckedChanged, AddressOf CheckBox_BLine_Enable_CheckedChanged
            AddHandler Me.m_Form.CheckBox_BLine_Enable.CheckedChanged, AddressOf CheckBox_BLine_Enable_CheckedChanged
            RemoveHandler Me.m_Form.CheckBox_DLine_Enable.CheckedChanged, AddressOf CheckBox_DLine_Enable_CheckedChanged
            AddHandler Me.m_Form.CheckBox_DLine_Enable.CheckedChanged, AddressOf CheckBox_DLine_Enable_CheckedChanged
            '
            RemoveHandler Me.m_Form.RadioButton_BL_Threshold.Click, AddressOf RadioButton_BL_Threshold_Click
            AddHandler Me.m_Form.RadioButton_BL_Threshold.Click, AddressOf RadioButton_BL_Threshold_Click
            RemoveHandler Me.m_Form.RadioButton_BL_Threshold.CheckedChanged, AddressOf RadioButton_BL_Threshold_CheckedChanged
            AddHandler Me.m_Form.RadioButton_BL_Threshold.CheckedChanged, AddressOf RadioButton_BL_Threshold_CheckedChanged

            RemoveHandler Me.m_Form.RadioButton_DL_Threshold.Click, AddressOf RadioButton_DL_Threshold_Click
            AddHandler Me.m_Form.RadioButton_DL_Threshold.Click, AddressOf RadioButton_DL_Threshold_Click
            RemoveHandler Me.m_Form.RadioButton_DL_Threshold.CheckedChanged, AddressOf RadioButton_DL_Threshold_CheckedChanged
            AddHandler Me.m_Form.RadioButton_DL_Threshold.CheckedChanged, AddressOf RadioButton_DL_Threshold_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_ByPassUpH.CheckedChanged, AddressOf RadioButton_Line_ByPassUpH_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_ByPassUpH.CheckedChanged, AddressOf RadioButton_Line_ByPassUpH_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_ByPassDownH.CheckedChanged, AddressOf RadioButton_Line_ByPassDownH_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_ByPassDownH.CheckedChanged, AddressOf RadioButton_Line_ByPassDownH_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_ByPassLeftV.CheckedChanged, AddressOf RadioButton_Line_ByPassLeftV_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_ByPassLeftV.CheckedChanged, AddressOf RadioButton_Line_ByPassLeftV_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_ByPassRightV.CheckedChanged, AddressOf RadioButton_Line_ByPassrRightV_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_ByPassRightV.CheckedChanged, AddressOf RadioButton_Line_ByPassrRightV_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_Cut.CheckedChanged, AddressOf RadioButton_Line_Cut_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_Cut.CheckedChanged, AddressOf RadioButton_Line_Cut_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_ShortCut.CheckedChanged, AddressOf RadioButton_Line_ShortCut_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_ShortCut.CheckedChanged, AddressOf RadioButton_Line_ShortCut_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_Cut_H.CheckedChanged, AddressOf RadioButton_Line_Cut_H_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_Cut_H.CheckedChanged, AddressOf RadioButton_Line_Cut_H_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_ShortCut_H.CheckedChanged, AddressOf RadioButton_Line_ShortCut_H_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_ShortCut_H.CheckedChanged, AddressOf RadioButton_Line_ShortCut_H_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Line_OverNum.CheckedChanged, AddressOf RadioButton_Line_OverNum_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Line_OverNum.CheckedChanged, AddressOf RadioButton_Line_OverNum_CheckedChanged
            RemoveHandler Me.m_Form.RadioButton_Block_OverNum.CheckedChanged, AddressOf RadioButton_Block_OverNum_CheckedChanged
            AddHandler Me.m_Form.RadioButton_Block_OverNum.CheckedChanged, AddressOf RadioButton_Block_OverNum_CheckedChanged
            '
            RemoveHandler Me.m_Form.TreeView_FuncParamPattern.AfterSelect, AddressOf TreeView_Pattern_AfterSelect
            AddHandler Me.m_Form.TreeView_FuncParamPattern.AfterSelect, AddressOf TreeView_Pattern_AfterSelect

            '--- 建立連線 ---
            If Me.ConnectToIP = False Then
                Exit Sub
            End If

            'UI
            Me.ResetUI()
            '--- 權限控管 ---
            'Me.UpdateUserLevel()


        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.SetMainForm]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try


    End Sub
#End Region

#Region "--- Private Method ---"
#Region "--- ResetUI ---"
    Private Sub ResetUI()

        Dim Image As MIL_ID = M_NULL
        Dim SizeX, SizeY, Type As Integer
        '
        Me.m_Form.Panel_FuncParam.AutoScroll = True
        '--- Set Pattern (已含 UpdateData()) ---
        Me.m_Form.TreeView_FuncParamPattern.Nodes.Clear()

        For i As Integer = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
            Dim rootNode As TreeNode = New TreeNode()
            rootNode.Name = "Node_" & Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value
            rootNode.Text = Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value
            Me.m_Form.TreeView_FuncParamPattern.Nodes.Add(rootNode)
        Next

        'If Me.m_Form.ComboBox_Pattern.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
        '    Me.ComboBox_Pattern.SelectedIndex = 0
        'Else
        '    Me.ComboBox_Pattern.SelectedIndex = Me.m_Form.GetPatternIndexInfo() - Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
        'End If

        If Me.m_FuncProcess.Img_Original_NonPage <> M_NULL Then
            Me.m_FuncProcess.CalculateOriginalROI(Me.m_FuncProcess.FuncModelRecipe.Boundary, Me.m_MainProcess.ErrorCode)
        End If

        '--- 繪圖 ---
        '---[1] 繪製搜尋到的Mark ---
        Me.m_AxMDisplay = Me.m_Form.AxMDisplay
        Me.m_Panel_AxMDisplay = Me.m_Form.Panel_AxMDisplay
        Me.m_BitMap = New Bitmap(Me.m_Panel_AxMDisplay.Width, Me.m_Panel_AxMDisplay.Height)
        Me.m_GraphicsImage = Graphics.FromImage(Me.m_BitMap)
        Me.m_GraphicsDisplay = Me.m_Panel_AxMDisplay.CreateGraphics
        Me.m_Pen = New Pen(Color.White)
        Me.m_SolidBrush = New SolidBrush(Color.White)
        Me.m_Size = 15
        Me.m_Form.PaintStop = True

        ''---[2] 建立顯示 PLMark 元件 ---
        'If Me.m_AxMDisplay_PLMark <> M_NULL Then
        '    MdispFree(Me.m_AxMDisplay_PLMark)
        '    Me.m_AxMDisplay_PLMark = M_NULL
        'End If
        'MdispAlloc(Me.m_MainProcess.System_Host, M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay_PLMark)

        ''---[3] 建立顯示 TPMark 元件 ---
        'If Me.m_AxMDisplay_TPMark <> M_NULL Then
        '    MdispFree(Me.m_AxMDisplay_TPMark)
        '    Me.m_AxMDisplay_TPMark = M_NULL
        'End If
        'MdispAlloc(Me.m_MainProcess.System_Host, M_DEFAULT, "M_DEFAULT", MIL.M_WINDOWED, Me.m_AxMDisplay_TPMark)

        '--- Img_FixRecipe_NonPage ---
        SizeX = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_X, M_NULL)
        SizeY = MbufInquire(Me.m_FuncProcess.Img_Original_NonPage, M_SIZE_Y, M_NULL)
        Type = MbufInquire(Me.m_MainProcess.Img_FixRecipe_NonPage, M_TYPE, M_NULL)

        If Me.m_MainProcess.Img_FixRecipe_NonPage <> M_NULL Then
            MbufFree(Me.m_MainProcess.Img_FixRecipe_NonPage)
            Me.m_MainProcess.Img_FixRecipe_NonPage = M_NULL
        End If

        Me.m_MainProcess.Img_FixRecipe_NonPage = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_DISP + M_NON_PAGED, M_NULL)

        Image = Me.m_FuncProcess.Img_Original_NonPage
        If Image <> M_NULL Then
            Me.m_Form.CurrentIndex0 = 2
            Me.m_Form.ComboBox_Type.SelectedIndex = 0
            Me.m_Form.ComboBox_Select.SelectedIndex = 2
        End If

        'Main UI
        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        Try
            Me.m_Form.ImageUpdate()
            Me.m_Form.ComboBox_Pattern_MainFrm.Enabled = False
            'Me.Update()
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.Dialog_FuncSetting_Load]" & ex.Message & "(" & ex.StackTrace & ")")
        End Try
    End Sub
#End Region
#Region "--- ConnectToIP ---"
    Private Function ConnectToIP()
        Dim ip As ClsIPInfo
        Dim IsIPConnected As Boolean
        Dim IPConnectMsg As String
        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPConnectMsg)
        If IsIPConnected = False Or IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region
#Region "--- CheckPattern ---"
    Private Sub CheckPattern()
        Try
            '--- Pattern 檢查 ----
            If Me.m_Form.GetPatternNameInfo() <> Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Index + Me.m_MuraProcess.MuraPatternRecipeArray.Count()
            End If
        Catch ex As Exception
            Throw New Exception("[Dialog_FuncSetting.CheckPattern]Check Pattern Error ! (" & ex.Message & ")")
        End Try
    End Sub

#End Region
#Region "--- UpdateNumberUpDown ---"
    Private Sub UpdateUIEnable()

        Me.CheckPattern()
        '--- GroupBox ---
        '--- Point ---
        Me.m_Form.GroupBox_PointPitchSetting.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked
        Me.m_Form.GroupBox_PointCommonSetting.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked
        Me.m_Form.GroupBox_PointMode.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked

        If Me.m_Form.RadioButton_BPDP.Checked Then
            Me.m_Form.GroupBox_BPoint.Enabled = True
            Me.m_Form.GroupBox_DPoint.Enabled = True

            If (Me.m_Form.RadioButton_BP_Threshold.Checked And Me.m_Form.RadioButton_DP_Threshold.Checked) Or (Me.m_Form.RadioButton_BP_Threshold.Checked And Me.m_Form.RadioButton_DP_Threshold_Low.Checked) Then
                Me.m_Form.RadioButton_BP_Threshold.Checked = False
                Me.m_Form.RadioButton_DP_Threshold.Checked = False
                Me.m_Form.RadioButton_DP_Threshold_Low.Checked = False
            End If

            If (Me.m_Form.RadioButton_BP_RimThreshold.Checked And Me.m_Form.RadioButton_DP_RimThreshold.Checked) Or (Me.m_Form.RadioButton_BP_RimThreshold.Checked And Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked) Then
                Me.m_Form.RadioButton_BP_RimThreshold.Checked = False
                Me.m_Form.RadioButton_DP_RimThreshold.Checked = False
                Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked = False
            End If

            If (Me.m_Form.RadioButton_BP_Threshold_Low.Checked And Me.m_Form.RadioButton_DP_Threshold.Checked) Or (Me.m_Form.RadioButton_BP_Threshold_Low.Checked And Me.m_Form.RadioButton_DP_Threshold_Low.Checked) Then
                Me.m_Form.RadioButton_BP_Threshold_Low.Checked = False
                Me.m_Form.RadioButton_DP_Threshold.Checked = False
                Me.m_Form.RadioButton_DP_Threshold_Low.Checked = False
            End If

            If (Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked And Me.m_Form.RadioButton_DP_RimThreshold.Checked) Or (Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked And Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked) Then
                Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked = False
                Me.m_Form.RadioButton_DP_RimThreshold.Checked = False
                Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked = False
            End If
        Else
            Me.m_Form.GroupBox_BPoint.Enabled = Me.m_Form.RadioButton_BP.Checked
            Me.m_Form.GroupBox_BP_Characteristics.Enabled = Me.m_Form.RadioButton_BP.Checked
            Me.m_Form.GroupBox_DPoint.Enabled = Me.m_Form.RadioButton_DP.Checked
            Me.m_Form.GroupBox_DP_Characteristics.Enabled = Me.m_Form.RadioButton_DP.Checked
        End If

        '--- GSBP ---
        'Me.m_Form.GroupBox_GSBP.Enabled = Me.m_Form.CheckBox_GSBP_Enable.Checked
        'Me.m_Form.GroupBox_GSBPCommonSetting.Enabled = Me.m_Form.CheckBox_GSBP_Enable.Checked

        '--- BLDP ---
        'Me.m_Form.GroupBox_BLDP.Enabled = Me.m_Form.CheckBox_BLDP_Enable.Checked
        'Me.m_Form.GroupBox_BLDPCommonSetting.Enabled = Me.m_Form.CheckBox_BLDP_Enable.Checked

        '--- Abnormal ---
        Me.m_Form.GroupBox_GrayAbnormal.Enabled = Me.m_Form.CheckBox_GrayAbnormal_Enable.Checked

        '--- DPoint ----
        If Me.m_Form.GroupBox_DPoint.Enabled Then
            Me.m_Form.NumericUpDown_DP_Threshold.Enabled = Me.m_Form.RadioButton_DP_Threshold.Checked
            Me.m_Form.NumericUpDown_DP_Threshold_Low.Enabled = Me.m_Form.RadioButton_DP_Threshold_Low.Checked
            Me.m_Form.NumericUpDown_DP_RimThreshold.Enabled = Me.m_Form.RadioButton_DP_RimThreshold.Checked
            Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Enabled = Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked
        End If
        '--- BPoint ---
        If Me.m_Form.GroupBox_BPoint.Enabled Then
            Me.m_Form.NumericUpDown_BP_Threshold.Enabled = Me.m_Form.RadioButton_BP_Threshold.Checked
            Me.m_Form.NumericUpDown_BP_Threshold_Low.Enabled = Me.m_Form.RadioButton_BP_Threshold_Low.Checked
            Me.m_Form.NumericUpDown_BP_RimThreshold.Enabled = Me.m_Form.RadioButton_BP_RimThreshold.Checked
            Me.m_Form.NumericUpDown_BP_RimThreshold_Low.Enabled = Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked
        End If

        ''--- GSBP ---
        'If Me.m_Form.GroupBox_GSBP.Enabled Then
        '    Me.m_Form.NumericUpDown_GSBP_Threshold.Enabled = Me.m_Form.RadioButton_GSBP_Threshold.Checked
        '    Me.m_Form.NumericUpDown_GSBP_ThresholdRim.Enabled = Me.m_Form.RadioButton_GSBP_RimThreshold.Checked
        'End If

        ''--- BLDP ---
        'If Me.m_Form.GroupBox_BLDP.Enabled Then
        '    Me.m_Form.NumericUpDown_BLDP_Threshold.Enabled = Me.m_Form.RadioButton_BLDP_Threshold.Checked
        '    Me.m_Form.NumericUpDown_BLDP_ThresholdRim.Enabled = Me.m_Form.RadioButton_BLDP_RimThreshold.Checked
        '    Me.m_Form.NumericUpDown_BLDP_EnhanceCount.Enabled = Me.m_Form.RadioButton_BLDP_EnhanceCount.Checked
        'End If

        '--- Point Common Setting ----
        'Me.m_Form.NumericUpDown_BP_AreaMax.Enabled = Me.m_Form.RadioButton_BP_AreaMax.Checked
        'Me.m_Form.NumericUpDown_BP_AreaMin.Enabled = Me.m_Form.RadioButton_BP_AreaMin.Checked
        'Me.m_Form.NumericUpDown_DP_AreaMax.Enabled = Me.m_Form.RadioButton_DP_AreaMax.Checked
        'Me.m_Form.NumericUpDown_DP_AreaMin.Enabled = Me.m_Form.RadioButton_DP_AreaMin.Checked
        'Me.m_Form.NumericUpDown_Point_ByPassX.Enabled = Me.m_Form.RadioButton_Point_ByPassX.Checked
        'Me.m_Form.NumericUpDown_Point_ByPassY.Enabled = Me.m_Form.RadioButton_Point_ByPassY.Checked
        'Me.m_Form.NumericUpDown_Point_OverNum.Enabled = Me.m_Form.RadioButton_Point_OverNum.Checked

        ''--- GSBP Common Setting ----
        'Me.m_Form.NumericUpDown_GSBP_AreaMax.Enabled = Me.m_Form.RadioButton_GSBP_AreaMax.Checked
        'Me.m_Form.NumericUpDown_GSBP_AreaMin.Enabled = Me.m_Form.RadioButton_GSBP_AreaMin.Checked
        'Me.m_Form.NumericUpDown_GSBP_Count_Min.Enabled = Me.m_Form.RadioButton_GSBP_Count_Min.Checked
        'Me.m_Form.NumericUpDown_GSBP_RangeX.Enabled = Me.m_Form.RadioButton_GSBP_RangeX.Checked
        'Me.m_Form.NumericUpDown_GSBP_RangeY.Enabled = Me.m_Form.RadioButton_GSBP_RangeY.Checked
        'Me.m_Form.NumericUpDown_GSBP_Scratch_Length.Enabled = Me.m_Form.RadioButton_GSBP_Scratch_Length.Checked
        'Me.m_Form.NumericUpDown_GSBP_OverNum.Enabled = Me.m_Form.RadioButton_GSBP_OverNum.Checked
        'Me.m_Form.NumericUpDown_GSBP_NumOfHoles.Enabled = Me.m_Form.RadioButton_GSBP_NumOfHoles.Checked
        'Me.m_Form.NumericUpDown_GSBP_GrayMax_High.Enabled = Me.m_Form.RadioButton_GSBP_GrayMax_High.Checked
        'Me.m_Form.NumericUpDown_GSBP_GrayMax_Low.Enabled = Me.m_Form.RadioButton_GSBP_GrayMax_Low.Checked

        ''--- BLDP Common Setting ----
        'Me.m_Form.NumericUpDown_BLDP_AreaMax.Enabled = Me.m_Form.RadioButton_BLDP_AreaMax.Checked
        'Me.m_Form.NumericUpDown_BLDP_AreaMin.Enabled = Me.m_Form.RadioButton_BLDP_AreaMin.Checked
        'Me.m_Form.NumericUpDown_BLDP_Count_Min.Enabled = Me.m_Form.RadioButton_BLDP_Count_Min.Checked
        'Me.m_Form.NumericUpDown_BLDP_RangeX.Enabled = Me.m_Form.RadioButton_BLDP_RangeX.Checked
        'Me.m_Form.NumericUpDown_BLDP_RangeY.Enabled = Me.m_Form.RadioButton_BLDP_RangeY.Checked
        'Me.m_Form.NumericUpDown_BLDP_Scratch_Length.Enabled = Me.m_Form.RadioButton_BLDP_Scratch_Length.Checked
        'Me.m_Form.NumericUpDown_BLDP_OverNum.Enabled = Me.m_Form.RadioButton_BLDP_OverNum.Checked
        'Me.m_Form.NumericUpDown_BLDP_Fatness_Min.Enabled = Me.m_Form.RadioButton_BLDP_Fatness_Min.Checked
        'Me.m_Form.NumericUpDown_BLDP_Elongation_Min.Enabled = Me.m_Form.RadioButton_BLDP_Elongation_Min.Checked
        'Me.m_Form.NumericUpDown_BLDP_Elongation_Max.Enabled = Me.m_Form.RadioButton_BLDP_Elongation_Max.Checked

        ''--- BP Characteristics ---
        'Me.m_Form.NumericUpDown_BP_Elongation_Min.Enabled = Me.m_Form.RadioButton_BP_Elongation_Min.Checked
        'Me.m_Form.NumericUpDown_BP_Elongation_Max.Enabled = Me.m_Form.RadioButton_BP_Elongation_Max.Checked
        'Me.m_Form.NumericUpDown_BP_Fullness_Min.Enabled = Me.m_Form.RadioButton_BP_Fullness_Min.Checked
        'Me.m_Form.NumericUpDown_BP_Fullness_Max.Enabled = Me.m_Form.RadioButton_BP_Fullness_Max.Checked
        'Me.m_Form.NumericUpDown_BP_MaxGray_Fullness_Min.Enabled = Me.m_Form.RadioButton_BP_MaxGray_Fullness_Min.Checked
        'Me.m_Form.NumericUpDown_BP_GrayMean_Min.Enabled = Me.m_Form.RadioButton_BP_GrayMean_Min.Checked
        'Me.m_Form.NumericUpDown_BP_MaxGray_Min.Enabled = Me.m_Form.RadioButton_BP_MaxGray_Min.Checked
        'Me.m_Form.NumericUpDown_BP_StdDev_Max.Enabled = Me.m_Form.RadioButton_BP_StdDev_Max.Checked
        'Me.m_Form.NumericUpDown_BP_Compactness_Max.Enabled = Me.m_Form.RadioButton_BP_Compactness_Max.Checked

        ''--- DP Characteristics ---
        'Me.m_Form.NumericUpDown_DP_Elongation_Min.Enabled = Me.m_Form.RadioButton_DP_Elongation_Min.Checked
        'Me.m_Form.NumericUpDown_DP_Elongation_Max.Enabled = Me.m_Form.RadioButton_DP_Elongation_Max.Checked
        'Me.m_Form.NumericUpDown_DP_Fullness_Min.Enabled = Me.m_Form.RadioButton_DP_Fullness_Min.Checked
        'Me.m_Form.NumericUpDown_DP_Fullness_Max.Enabled = Me.m_Form.RadioButton_DP_Fullness_Max.Checked
        'Me.m_Form.NumericUpDown_DP_MaxGray_Fullness_Min.Enabled = Me.m_Form.RadioButton_DP_MaxGray_Fullness_Min.Checked
        'Me.m_Form.NumericUpDown_DP_GrayMean_Max.Enabled = Me.m_Form.RadioButton_DP_GrayMean_Max.Checked
        'Me.m_Form.NumericUpDown_DP_MinGray_Max.Enabled = Me.m_Form.RadioButton_DP_MinGray_Max.Checked
        'Me.m_Form.NumericUpDown_DP_StdDev_Max.Enabled = Me.m_Form.RadioButton_DP_StdDev_Max.Checked
        'Me.m_Form.NumericUpDown_DP_Compactness_Max.Enabled = Me.m_Form.RadioButton_DP_Compactness_Max.Checked

            '--- Line ---
            Me.m_Form.GroupBox_LinePitchSetting.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked

            Me.m_Form.GroupBox_LineCommonSetting.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
            Me.m_Form.CheckBox_BLine_Enable.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
            Me.m_Form.CheckBox_DLine_Enable.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
            Me.m_Form.GroupBox_BLine.Enabled = Me.m_Form.CheckBox_BLine_Enable.Checked
            Me.m_Form.GroupBox_DLine.Enabled = Me.m_Form.CheckBox_DLine_Enable.Checked
            'Me.m_Form.GroupBox_MeanDiff.Enabled = Me.m_Form.CheckBox_HalfScreen_Enable.Checked

            If Me.m_Form.CheckBox_DLine_Enable.Enabled Then
                Me.m_Form.NumericUpDown_DL_Threshold.Enabled = Me.m_Form.RadioButton_DL_Threshold.Checked
                Me.m_Form.NumericUpDown_DL_RimThreshold.Enabled = Me.m_Form.RadioButton_DL_Threshold.Checked
            End If
            If Me.m_Form.CheckBox_BLine_Enable.Enabled Then
                Me.m_Form.NumericUpDown_BL_Threshold.Enabled = Me.m_Form.RadioButton_BL_Threshold.Checked
                Me.m_Form.NumericUpDown_BL_RimThreshold.Enabled = Me.m_Form.RadioButton_BL_Threshold.Checked
            End If

            If Me.m_Form.GroupBox_LineCommonSetting.Enabled Then
                Me.m_Form.NumericUpDown_Line_ByPassUpH.Enabled = Me.m_Form.RadioButton_Line_ByPassUpH.Checked
                Me.m_Form.NumericUpDown_Line_ByPassDownH.Enabled = Me.m_Form.RadioButton_Line_ByPassDownH.Checked
                Me.m_Form.NumericUpDown_Line_ByPassLeftV.Enabled = Me.m_Form.RadioButton_Line_ByPassLeftV.Checked
                Me.m_Form.NumericUpDown_Line_ByPassRightV.Enabled = Me.m_Form.RadioButton_Line_ByPassRightV.Checked
                Me.m_Form.NumericUpDown_Line_Cut.Enabled = Me.m_Form.RadioButton_Line_Cut.Checked
                Me.m_Form.NumericUpDown_Line_Short_Cut.Enabled = Me.m_Form.RadioButton_Line_ShortCut.Checked
                Me.m_Form.NumericUpDown_Line_Cut_H.Enabled = Me.m_Form.RadioButton_Line_Cut_H.Checked
                Me.m_Form.NumericUpDown_Line_Short_Cut_H.Enabled = Me.m_Form.RadioButton_Line_ShortCut_H.Checked
                Me.m_Form.NumericUpDown_Line_OverNumber.Enabled = Me.m_Form.RadioButton_Line_OverNum.Checked
                Me.m_Form.NumericUpDown_Block_OverNumber.Enabled = Me.m_Form.RadioButton_Block_OverNum.Checked
            End If

            '--- Boundary Setting ---
            If Me.m_Form.CheckBox_Line_Enable.Checked OrElse Me.m_Form.CheckBox_Point_Enable.Checked Then
                Me.m_Form.GroupBox_ImgProcBoundary.Enabled = True
                Me.m_Form.GroupBox_LineAverageFilter.Enabled = True
            Else
                Me.m_Form.GroupBox_ImgProcBoundary.Enabled = False
                Me.m_Form.GroupBox_LineAverageFilter.Enabled = False
            End If


            '--- TPMark ---
            'Me.m_Form.CheckBox_TPMark_Enable.Enabled = Me.m_IPBootConfig.TPMarkUI.Value

    End Sub
#End Region
#Region "--- Me.RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region
#Region "--- UpdateData ---"
    Public Sub UpdateData()
        Dim fpr As ClsFuncPatternRecipe
        Dim fmr As ClsFuncModelRecipe
        Dim PL_mmr As ClsPLMarkModelRecipe
        Dim TP_mmr As ClsTPMarkModelRecipe
        Dim GrayLevel_Maximum As Double
        Dim FuncUpdateDataLog As String

        Try
            FuncUpdateDataLog = ""

            fmr = Me.m_FuncProcess.FuncModelRecipe
            fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
            PL_mmr = Me.m_FuncProcess.PLMarkModelRecipe
            TP_mmr = Me.m_FuncProcess.TPMarkModelRecipe

            If fmr.PointAlgorithm.Value = 2 Then
                GrayLevel_Maximum = 20000  '原1000 ,改20000 For Test , 2012/11/26 Rick modify
            Else
                GrayLevel_Maximum = (2 ^ Me.m_IPBootConfig.Digitizer_Datadepth.Value - 1) * 10
            End If

            If Not fpr Is Nothing Then
                'Me.Text = "[Func]影像处理参数调整 [ Pattern：" & Me.m_Form.ComboBox_Pattern_MainFrm.Text & " ]"

                '--- BDPoint Setting (第一頁) ---------------------
                If (fpr.AnalysisBP.Value = True And fpr.AnalysisDP.Value = False) Then
                    Me.m_Form.RadioButton_BP.Checked = True
                    Me.m_Form.RadioButton_DP.Checked = False
                    Me.m_Form.GroupBox_DPoint.Enabled = False
                ElseIf (fpr.AnalysisDP.Value = True And fpr.AnalysisBP.Value = False) Then
                    Me.m_Form.RadioButton_DP.Checked = True
                    Me.m_Form.RadioButton_BP.Checked = False
                    Me.m_Form.GroupBox_BPoint.Enabled = False
                ElseIf (fpr.AnalysisBP.Value = True And fpr.AnalysisDP.Value = True) Then
                    Me.m_Form.RadioButton_BPDP.Checked = True
                Else
                    Me.m_Form.RadioButton_BP.Checked = False
                    Me.m_Form.RadioButton_DP.Checked = False
                End If

                '--- Tool ---
                ''[1] Inverse Point Type & Fix Area ---
                'Me.m_Form.CheckBox_Inverse_Point_DefectType.Checked = fpr.BDPointRecipe.Inverse_PointDefectType.Value
                'Me.m_Form.CheckBox_Inverse_Point_EnableFixArea.Checked = fpr.BDPointRecipe.Inverse_Point_EnableFixArea.Value
                'Me.m_Form.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value = fpr.BDPointRecipe.Inverse_PointFixArea.Value
                'Me.m_Form.NumericUpDown_CheckBox_Inverse_Point_FixArea.Enabled = Me.m_Form.CheckBox_Inverse_Point_EnableFixArea.Checked

                '--- DP Recipe ---
                If Me.m_Form.NumericUpDown_DP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_DP.Value Then Me.m_Form.NumericUpDown_DP_Threshold.Value = fpr.BDPointRecipe.Threshold_DP.Value Else FuncUpdateDataLog &= "[Point] DPoint Threshold High 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_Threshold_Low.Maximum >= fpr.BDPointRecipe.Threshold_DP_Low.Value Then Me.m_Form.NumericUpDown_DP_Threshold_Low.Value = fpr.BDPointRecipe.Threshold_DP_Low.Value Else FuncUpdateDataLog &= "[Point] DPoint Threshold Low 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_RimThreshold.Maximum >= fpr.BDPointRecipe.ThresholdRim_DP.Value Then Me.m_Form.NumericUpDown_DP_RimThreshold.Value = fpr.BDPointRecipe.ThresholdRim_DP.Value Else FuncUpdateDataLog &= "[Point] DPoint Boundary Threshold High 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Maximum >= fpr.BDPointRecipe.ThresholdRim_DP_Low.Value Then Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Value = fpr.BDPointRecipe.ThresholdRim_DP_Low.Value Else FuncUpdateDataLog &= "[Point] DPoint Boundary Threshold Low 設定超出範圍" & vbCrLf

                Me.m_Form.NumericUpDown_DP_Threshold.Maximum = GrayLevel_Maximum
                Me.m_Form.NumericUpDown_DP_Threshold_Low.Maximum = GrayLevel_Maximum
                Me.m_Form.NumericUpDown_DP_RimThreshold.Maximum = GrayLevel_Maximum
                Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Maximum = GrayLevel_Maximum

                ''--- Waku Recipe ---
                'Me.m_Form.NumericUpDown_WakuSplitNum.Value = fpr.WakuSplitNum.Value
                'Me.m_Form.NumericUpDown_WakuEdgeWidth.Value = fpr.WakuEdgeWidth.Value
                'Me.m_Form.NumericUpDown_WakuEdgeOffset.Value = fpr.WakuEdgeOffset.Value

                '--- BP Recipe ---
                If Me.m_Form.NumericUpDown_BP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_BP.Value Then Me.m_Form.NumericUpDown_BP_Threshold.Value = fpr.BDPointRecipe.Threshold_BP.Value Else FuncUpdateDataLog &= "[Point] BPoint Threshold 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_Threshold_Low.Maximum >= fpr.BDPointRecipe.Threshold_BP_Low.Value Then Me.m_Form.NumericUpDown_BP_Threshold_Low.Value = fpr.BDPointRecipe.Threshold_BP_Low.Value Else FuncUpdateDataLog &= "[Point] BPoint Threshold Low 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_RimThreshold.Maximum >= fpr.BDPointRecipe.ThresholdRim_BP.Value Then Me.m_Form.NumericUpDown_BP_RimThreshold.Value = fpr.BDPointRecipe.ThresholdRim_BP.Value Else FuncUpdateDataLog &= "[Point] BPoint Boundary Threshold 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_RimThreshold_Low.Maximum >= fpr.BDPointRecipe.ThresholdRim_BP_Low.Value Then Me.m_Form.NumericUpDown_BP_RimThreshold_Low.Value = fpr.BDPointRecipe.ThresholdRim_BP_Low.Value Else FuncUpdateDataLog &= "[Point] BPoint Boundary Threshold Low 設定超出範圍" & vbCrLf

                Me.m_Form.NumericUpDown_BP_Threshold.Maximum = GrayLevel_Maximum
                Me.m_Form.NumericUpDown_BP_RimThreshold.Maximum = GrayLevel_Maximum

                ''---Separate BP---
                'Me.m_Form.CheckBox_SeparateBPEnable.Checked = fpr.SeparateBPEnable.Value
                'Me.m_Form.NumericUpDown_SeparateBPArea.Value = fpr.SeparateBPArea.Value
                'Me.m_Form.NumericUpDown_SeparateBPBlob.Value = fpr.SeparateBPBlob.Value

                '--- BDPoint - Common setting ---
                If Me.m_Form.NumericUpDown_BP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_BP.Value Then Me.m_Form.NumericUpDown_BP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_BP.Value Else FuncUpdateDataLog &= "[Common] BP AreaMax 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_BP.Value Then Me.m_Form.NumericUpDown_BP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_BP.Value Else FuncUpdateDataLog &= "[Common] BP AreaMin 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_DP.Value Then Me.m_Form.NumericUpDown_DP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_DP.Value Else FuncUpdateDataLog &= "[Common] DP AreaMax 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_DP.Value Then Me.m_Form.NumericUpDown_DP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_DP.Value Else FuncUpdateDataLog &= "[Common] DP AreaMin 設定超出範圍" & vbCrLf

                If Me.m_Form.NumericUpDown_Point_ByPassX.Maximum >= fpr.BDPointRecipe.BypassX.Value Then Me.m_Form.NumericUpDown_Point_ByPassX.Value = fpr.BDPointRecipe.BypassX.Value Else FuncUpdateDataLog &= "[Common] BypassX設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Point_ByPassY.Maximum >= fpr.BDPointRecipe.BypassY.Value Then Me.m_Form.NumericUpDown_Point_ByPassY.Value = fpr.BDPointRecipe.BypassY.Value Else FuncUpdateDataLog &= "[Common] BypassY設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Point_OverNum.Maximum >= fpr.BDPointRecipe.OverNum.Value Then Me.m_Form.NumericUpDown_Point_OverNum.Value = fpr.BDPointRecipe.OverNum.Value Else FuncUpdateDataLog &= "[Common] OverNum設定超出範圍" & vbCrLf

                'Me.m_Form.CheckBox_EnableLeakPoint.Checked = fpr.BDPointRecipe.EnableLeakPoint.Value

                '--- Point Characteristics (第二頁) -------------------------
                '--- BP ---
                If Me.m_Form.NumericUpDown_BP_Elongation_Min.Maximum >= fpr.BDPointRecipe.Elongation_Min.Value Then Me.m_Form.NumericUpDown_BP_Elongation_Min.Value = fpr.BDPointRecipe.Elongation_Min.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Elongation Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_Elongation_Max.Maximum >= fpr.BDPointRecipe.Elongation_Max.Value Then Me.m_Form.NumericUpDown_BP_Elongation_Max.Value = fpr.BDPointRecipe.Elongation_Max.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Elongation Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_Fullness_Min.Maximum >= fpr.BDPointRecipe.Fullness_Min.Value Then Me.m_Form.NumericUpDown_BP_Fullness_Min.Value = fpr.BDPointRecipe.Fullness_Min.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Fullness Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_Fullness_Max.Maximum >= fpr.BDPointRecipe.Fullness_Max.Value Then Me.m_Form.NumericUpDown_BP_Fullness_Max.Value = fpr.BDPointRecipe.Fullness_Max.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Fullness Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_MaxGray_Fullness_Min.Maximum >= fpr.BDPointRecipe.MaxGray_Fullness_Min.Value Then Me.m_Form.NumericUpDown_BP_MaxGray_Fullness_Min.Value = fpr.BDPointRecipe.MaxGray_Fullness_Min.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP MaxGray_Fullness Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_GrayMean_Min.Maximum >= fpr.BDPointRecipe.GrayMean_Min_BP.Value Then Me.m_Form.NumericUpDown_BP_GrayMean_Min.Value = fpr.BDPointRecipe.GrayMean_Min_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP GrayMean Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_MaxGray_Min.Maximum >= fpr.BDPointRecipe.MaxGray_Min_BP.Value Then Me.m_Form.NumericUpDown_BP_MaxGray_Min.Value = fpr.BDPointRecipe.MaxGray_Min_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP MaxGray Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_MaxGray_Max.Maximum >= fpr.BDPointRecipe.MaxGray_Max_BP.Value Then Me.m_Form.NumericUpDown_BP_MaxGray_Max.Value = fpr.BDPointRecipe.MaxGray_Max_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP MaxGray Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_Compactness_Max.Maximum >= fpr.BDPointRecipe.Compactness_Max_BP.Value Then Me.m_Form.NumericUpDown_BP_Compactness_Max.Value = fpr.BDPointRecipe.Compactness_Max_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP Compactness Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BP_StdDev_Max.Maximum >= fpr.BDPointRecipe.StdDev_Max_BP.Value Then Me.m_Form.NumericUpDown_BP_StdDev_Max.Value = fpr.BDPointRecipe.StdDev_Max_BP.Value Else FuncUpdateDataLog &= "[Point Characteristics] BP StdDev Max 設定超出範圍" & vbCrLf

                '--- DP ---
                If Me.m_Form.NumericUpDown_DP_Elongation_Min.Maximum >= fpr.BDPointRecipe.Elongation_Min_DP.Value Then Me.m_Form.NumericUpDown_DP_Elongation_Min.Value = fpr.BDPointRecipe.Elongation_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Elongation Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_Elongation_Max.Maximum >= fpr.BDPointRecipe.Elongation_Max_DP.Value Then Me.m_Form.NumericUpDown_DP_Elongation_Max.Value = fpr.BDPointRecipe.Elongation_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Elongation Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_Fullness_Min.Maximum >= fpr.BDPointRecipe.Fullness_Min_DP.Value Then Me.m_Form.NumericUpDown_DP_Fullness_Min.Value = fpr.BDPointRecipe.Fullness_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Fullness Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_Fullness_Max.Maximum >= fpr.BDPointRecipe.Fullness_Max_DP.Value Then Me.m_Form.NumericUpDown_DP_Fullness_Max.Value = fpr.BDPointRecipe.Fullness_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Fullness Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_MaxGray_Fullness_Min.Maximum >= fpr.BDPointRecipe.MaxGray_Fullness_Min_DP.Value Then Me.m_Form.NumericUpDown_DP_MaxGray_Fullness_Min.Value = fpr.BDPointRecipe.MaxGray_Fullness_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP MaxGray_Fullness Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_GrayMean_Max.Maximum >= fpr.BDPointRecipe.GrayMean_Max_DP.Value Then Me.m_Form.NumericUpDown_DP_GrayMean_Max.Value = fpr.BDPointRecipe.GrayMean_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP GrayMean Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_MinGray_Min.Maximum >= fpr.BDPointRecipe.MinGray_Min_DP.Value Then Me.m_Form.NumericUpDown_DP_MinGray_Min.Value = fpr.BDPointRecipe.MinGray_Min_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP MinGray Min 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_MinGray_Max.Maximum >= fpr.BDPointRecipe.MinGray_Max_DP.Value Then Me.m_Form.NumericUpDown_DP_MinGray_Max.Value = fpr.BDPointRecipe.MinGray_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP MinGray Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_Compactness_Max.Maximum >= fpr.BDPointRecipe.Compactness_Max_DP.Value Then Me.m_Form.NumericUpDown_DP_Compactness_Max.Value = fpr.BDPointRecipe.Compactness_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP Compactness Max 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DP_StdDev_Max.Maximum >= fpr.BDPointRecipe.StdDev_Max_DP.Value Then Me.m_Form.NumericUpDown_DP_StdDev_Max.Value = fpr.BDPointRecipe.StdDev_Max_DP.Value Else FuncUpdateDataLog &= "[Point Characteristics] DP StdDev Max 設定超出範圍" & vbCrLf

                ''--- GSBDP Recipe (第三頁) -------------------------
                ''--- GSBP ---
                'If Me.m_Form.NumericUpDown_GSBP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_GSBP.Value Then Me.m_Form.NumericUpDown_GSBP_Threshold.Value = fpr.BDPointRecipe.Threshold_GSBP.Value Else FuncUpdateDataLog &= "[GSBP] GSBP Threshold 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_ThresholdRim.Maximum >= fpr.BDPointRecipe.ThresholdRim_GSBP.Value Then Me.m_Form.NumericUpDown_GSBP_ThresholdRim.Value = fpr.BDPointRecipe.ThresholdRim_GSBP.Value Else FuncUpdateDataLog &= "[GSBP] GSBP Threshold Rim 設定超出範圍" & vbCrLf

                'Me.m_Form.NumericUpDown_GSBP_Threshold.Maximum = GrayLevel_Maximum
                'Me.m_Form.NumericUpDown_GSBP_ThresholdRim.Maximum = GrayLevel_Maximum

                ''--- GSBP - Common setting ---
                'If Me.m_Form.NumericUpDown_GSBP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_GSBP.Value Then Me.m_Form.NumericUpDown_GSBP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_GSBP.Value Else FuncUpdateDataLog &= "[Common] GSBP AreaMax 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_GSBP.Value Then Me.m_Form.NumericUpDown_GSBP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_GSBP.Value Else FuncUpdateDataLog &= "[Common] GSBP AreaMin 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_Count_Min.Maximum >= fpr.BDPointRecipe.GSBP_Count_Min.Value Then Me.m_Form.NumericUpDown_GSBP_Count_Min.Value = fpr.BDPointRecipe.GSBP_Count_Min.Value Else FuncUpdateDataLog &= "[Common] GSBP_Count_Min 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_RangeX.Maximum >= fpr.BDPointRecipe.GSBP_RangeX.Value Then Me.m_Form.NumericUpDown_GSBP_RangeX.Value = fpr.BDPointRecipe.GSBP_RangeX.Value Else FuncUpdateDataLog &= "[Common] GSBP_RangeX 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_RangeY.Maximum >= fpr.BDPointRecipe.GSBP_RangeY.Value Then Me.m_Form.NumericUpDown_GSBP_RangeY.Value = fpr.BDPointRecipe.GSBP_RangeY.Value Else FuncUpdateDataLog &= "[Common] GSBP_RangeY 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_Scratch_Length.Maximum >= fpr.BDPointRecipe.GSBP_Scratch_Length.Value Then Me.m_Form.NumericUpDown_GSBP_Scratch_Length.Value = fpr.BDPointRecipe.GSBP_Scratch_Length.Value Else FuncUpdateDataLog &= "[Common] GSBP_Scratch_Length 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_OverNum.Maximum >= fpr.BDPointRecipe.GSBP_OverNum.Value Then Me.m_Form.NumericUpDown_GSBP_OverNum.Value = fpr.BDPointRecipe.GSBP_OverNum.Value Else FuncUpdateDataLog &= "[Common] GSBP_OverNum 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_NumOfHoles.Maximum >= fpr.BDPointRecipe.GSBP_NumOfHoles.Value Then Me.m_Form.NumericUpDown_GSBP_NumOfHoles.Value = fpr.BDPointRecipe.GSBP_NumOfHoles.Value Else FuncUpdateDataLog &= "[Common] GSBP_NumOfHoles 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_GrayMax_High.Maximum >= fpr.BDPointRecipe.GSBP_GrayMax_High.Value Then Me.m_Form.NumericUpDown_GSBP_GrayMax_High.Value = fpr.BDPointRecipe.GSBP_GrayMax_High.Value Else FuncUpdateDataLog &= "[Common] GSBP_GrayMax_High 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_GSBP_GrayMax_Low.Maximum >= fpr.BDPointRecipe.GSBP_GrayMax_Low.Value Then Me.m_Form.NumericUpDown_GSBP_GrayMax_Low.Value = fpr.BDPointRecipe.GSBP_GrayMax_Low.Value Else FuncUpdateDataLog &= "[Common] GSBP_GrayMax_Low 設定超出範圍" & vbCrLf

                ''--- BLDP ---
                'If Me.m_Form.NumericUpDown_BLDP_Threshold.Maximum >= fpr.BDPointRecipe.Threshold_BLDP.Value Then Me.m_Form.NumericUpDown_BLDP_Threshold.Value = fpr.BDPointRecipe.Threshold_BLDP.Value Else FuncUpdateDataLog &= "[BLDP] BLDP Threshold 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_ThresholdRim.Maximum >= fpr.BDPointRecipe.ThresholdRim_BLDP.Value Then Me.m_Form.NumericUpDown_BLDP_ThresholdRim.Value = fpr.BDPointRecipe.ThresholdRim_BLDP.Value Else FuncUpdateDataLog &= "[BLDP] BLDP Threshold Rim 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_EnhanceCount.Maximum >= fpr.BDPointRecipe.EnhanceCount_BLDP.Value Then Me.m_Form.NumericUpDown_BLDP_EnhanceCount.Value = fpr.BDPointRecipe.EnhanceCount_BLDP.Value Else FuncUpdateDataLog &= "[BLDP] BLDP Enhance Count 設定超出範圍" & vbCrLf

                'Me.m_Form.NumericUpDown_BLDP_Threshold.Maximum = GrayLevel_Maximum
                'Me.m_Form.NumericUpDown_BLDP_ThresholdRim.Maximum = GrayLevel_Maximum

                ''--- BLDP - Common setting ---
                'If Me.m_Form.NumericUpDown_BLDP_AreaMax.Maximum >= fpr.BDPointRecipe.AreaMax_BLDP.Value Then Me.m_Form.NumericUpDown_BLDP_AreaMax.Value = fpr.BDPointRecipe.AreaMax_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP AreaMax 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_AreaMin.Maximum >= fpr.BDPointRecipe.AreaMin_BLDP.Value Then Me.m_Form.NumericUpDown_BLDP_AreaMin.Value = fpr.BDPointRecipe.AreaMin_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP AreaMin 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_Count_Min.Maximum >= fpr.BDPointRecipe.BLDP_Count_Min.Value Then Me.m_Form.NumericUpDown_BLDP_Count_Min.Value = fpr.BDPointRecipe.BLDP_Count_Min.Value Else FuncUpdateDataLog &= "[Common] BLDP_Count_Min 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_RangeX.Maximum >= fpr.BDPointRecipe.BLDP_RangeX.Value Then Me.m_Form.NumericUpDown_BLDP_RangeX.Value = fpr.BDPointRecipe.BLDP_RangeX.Value Else FuncUpdateDataLog &= "[Common] BLDP_RangeX 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_RangeY.Maximum >= fpr.BDPointRecipe.BLDP_RangeY.Value Then Me.m_Form.NumericUpDown_BLDP_RangeY.Value = fpr.BDPointRecipe.BLDP_RangeY.Value Else FuncUpdateDataLog &= "[Common] BLDP_RangeY 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_Scratch_Length.Maximum >= fpr.BDPointRecipe.BLDP_Scratch_Length.Value Then Me.m_Form.NumericUpDown_BLDP_Scratch_Length.Value = fpr.BDPointRecipe.BLDP_Scratch_Length.Value Else FuncUpdateDataLog &= "[Common] BLDP_Scratch_Length 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_OverNum.Maximum >= fpr.BDPointRecipe.BLDP_OverNum.Value Then Me.m_Form.NumericUpDown_BLDP_OverNum.Value = fpr.BDPointRecipe.BLDP_OverNum.Value Else FuncUpdateDataLog &= "[Common] BLDP_OverNum 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_Fatness_Min.Maximum >= fpr.BDPointRecipe.BLDP_Fatness_Min.Value Then Me.m_Form.NumericUpDown_BLDP_Fatness_Min.Value = fpr.BDPointRecipe.BLDP_Fatness_Min.Value Else FuncUpdateDataLog &= "[Common] BLDP_Fatness_Min 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_Elongation_Min.Maximum >= fpr.BDPointRecipe.Elongation_Min_BLDP.Value Then Me.m_Form.NumericUpDown_BLDP_Elongation_Min.Value = fpr.BDPointRecipe.Elongation_Min_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP_Elongation_Min 設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_BLDP_Elongation_Max.Maximum >= fpr.BDPointRecipe.Elongation_Max_BLDP.Value Then Me.m_Form.NumericUpDown_BLDP_Elongation_Max.Value = fpr.BDPointRecipe.Elongation_Max_BLDP.Value Else FuncUpdateDataLog &= "[Common] BLDP_Elongation_Max 設定超出範圍" & vbCrLf

                '--- Line Recipe (第四頁) -------------------------
                Me.m_Form.CheckBox_BLine_Enable.Checked = fpr.LineFinderRecipe.AnalysisBL.Value
                Me.m_Form.CheckBox_DLine_Enable.Checked = fpr.LineFinderRecipe.AnalysisDL.Value
                If Me.m_Form.NumericUpDown_BL_Threshold.Maximum >= fpr.LineFinderRecipe.Threshold_BL.Value Then Me.m_Form.NumericUpDown_BL_Threshold.Value = fpr.LineFinderRecipe.Threshold_BL.Value Else FuncUpdateDataLog &= "[Line] Bright Line Threshold 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_BL_RimThreshold.Maximum >= fpr.LineFinderRecipe.ThresholdRim_BL.Value Then Me.m_Form.NumericUpDown_BL_RimThreshold.Value = fpr.LineFinderRecipe.ThresholdRim_BL.Value Else FuncUpdateDataLog &= "[Line] Bright Line Rim Threshold 設定超出範圍" & vbCrLf

                If Me.m_Form.NumericUpDown_DL_Threshold.Maximum >= fpr.LineFinderRecipe.Threshold_DL.Value Then Me.m_Form.NumericUpDown_DL_Threshold.Value = fpr.LineFinderRecipe.Threshold_DL.Value Else FuncUpdateDataLog &= "[Line] Dark Line Threshold 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_DL_RimThreshold.Maximum >= fpr.LineFinderRecipe.ThresholdRim_DL.Value Then Me.m_Form.NumericUpDown_DL_RimThreshold.Value = fpr.LineFinderRecipe.ThresholdRim_DL.Value Else FuncUpdateDataLog &= "[Line] Dark Line Rim Threshold 設定超出範圍" & vbCrLf

                Me.m_Form.NumericUpDown_DL_Threshold.Maximum = GrayLevel_Maximum
                Me.m_Form.NumericUpDown_BL_Threshold.Maximum = GrayLevel_Maximum
                Me.m_Form.NumericUpDown_DL_RimThreshold.Maximum = GrayLevel_Maximum
                Me.m_Form.NumericUpDown_BL_RimThreshold.Maximum = GrayLevel_Maximum

                If Me.m_Form.NumericUpDown_Line_ByPassUpH.Maximum >= fpr.LineFinderRecipe.ByPassUpH.Value Then Me.m_Form.NumericUpDown_Line_ByPassUpH.Value = fpr.LineFinderRecipe.ByPassUpH.Value Else FuncUpdateDataLog &= "[Line] Line ByPassUpH設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Line_ByPassDownH.Maximum >= fpr.LineFinderRecipe.ByPassDownH.Value Then Me.m_Form.NumericUpDown_Line_ByPassDownH.Value = fpr.LineFinderRecipe.ByPassDownH.Value Else FuncUpdateDataLog &= "[Line] Line ByPassDownH設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Line_ByPassLeftV.Maximum >= fpr.LineFinderRecipe.ByPassLeftV.Value Then Me.m_Form.NumericUpDown_Line_ByPassLeftV.Value = fpr.LineFinderRecipe.ByPassLeftV.Value Else FuncUpdateDataLog &= "[Line] Line ByPassLeftV設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Line_ByPassRightV.Maximum >= fpr.LineFinderRecipe.ByPassRightV.Value Then Me.m_Form.NumericUpDown_Line_ByPassRightV.Value = fpr.LineFinderRecipe.ByPassRightV.Value Else FuncUpdateDataLog &= "[Line] Line ByPassRightV設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Line_Cut.Maximum >= fpr.LineFinderRecipe.Line_Cut.Value Then Me.m_Form.NumericUpDown_Line_Cut.Value = fpr.LineFinderRecipe.Line_Cut.Value Else FuncUpdateDataLog &= "[Line] Line Cut 設定超出範圍" & vbCrLf
                If fpr.LineFinderRecipe.Line_Cut_H.Value = 1 Then
                    fpr.LineFinderRecipe.Line_Cut_H.Value = fpr.LineFinderRecipe.Line_Cut.Value
                    Me.m_Form.NumericUpDown_Line_Cut_H.Value = fpr.LineFinderRecipe.Line_Cut.Value
                Else
                    Me.m_Form.NumericUpDown_Line_Cut_H.Value = fpr.LineFinderRecipe.Line_Cut_H.Value
                End If
                If fpr.LineFinderRecipe.Line_Short_Cut_H.Value = 0 Then
                    fpr.LineFinderRecipe.Line_Short_Cut_H.Value = fpr.LineFinderRecipe.Line_Short_Cut_H.Value
                    Me.m_Form.NumericUpDown_Line_Short_Cut_H.Value = fpr.LineFinderRecipe.Line_Short_Cut_H.Value
                Else
                    Me.m_Form.NumericUpDown_Line_Short_Cut_H.Value = fpr.LineFinderRecipe.Line_Short_Cut_H.Value
                End If
                If Me.m_Form.NumericUpDown_Line_Short_Cut.Maximum >= fpr.LineFinderRecipe.Line_Short_Cut.Value Then Me.m_Form.NumericUpDown_Line_Short_Cut.Value = fpr.LineFinderRecipe.Line_Short_Cut.Value Else FuncUpdateDataLog &= "[Line] Line Short Cut設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Line_OverNumber.Maximum >= fpr.LineFinderRecipe.LineOverNum.Value Then Me.m_Form.NumericUpDown_Line_OverNumber.Value = fpr.LineFinderRecipe.LineOverNum.Value Else FuncUpdateDataLog &= "[Line] Line Over Number設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Block_OverNumber.Maximum >= fpr.LineFinderRecipe.BlockOverNum.Value Then Me.m_Form.NumericUpDown_Block_OverNumber.Value = fpr.LineFinderRecipe.BlockOverNum.Value Else FuncUpdateDataLog &= "[Line] Block Over Number設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_MeanDifference.Maximum >= fpr.LineFinderRecipe.Mean_Difference.Value Then Me.m_Form.NumericUpDown_MeanDifference.Value = fpr.LineFinderRecipe.Mean_Difference.Value Else FuncUpdateDataLog &= "[Line] Line Mean_Difference設定超出範圍" & vbCrLf
                'If Me.m_Form.NumericUpDown_Line_Elongation_Min.Maximum >= fpr.LineFinderRecipe.Elongation_Min.Value Then Me.m_Form.NumericUpDown_Line_Elongation_Min.Value = fpr.LineFinderRecipe.Mean_Difference.Value Else FuncUpdateDataLog &= "[Line] Line Mean_Difference設定超出範圍" & vbCrLf

                'Me.m_Form.NumericUpDown_LeakPointRadius.Value = fpr.LineFinderRecipe.LeakPointRadius.Value

                '--- Gray Abnormal (第五頁) -----------------------
                Me.m_Form.NumericUpDown_GrayAbnormal_PosLimit.Value = fpr.DisplayMeanOffsetRecipe.PosLimit.Value
                Me.m_Form.NumericUpDown_GrayAbnormal_NegLimit.Value = fpr.DisplayMeanOffsetRecipe.NegLimit.Value
                Me.m_Form.NumericUpDown_GrayAbnormalStandardGray.Value = fpr.DisplayMeanOffsetRecipe.StandardGray.Value
                'Me.m_Form.NumericUpDown_GrayAbnormal_NoDisplay.Value = fpr.DisplayMeanOffsetRecipe.NoDisplay.Value
                Me.m_Form.Lbl_GrayAbnormal_PosLimit.Text = CStr(Format(Me.m_Form.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 + Me.m_Form.NumericUpDown_GrayAbnormal_PosLimit.Value) / 100), "#"))
                Me.m_Form.Lbl_GrayAbnormal_NegLimit.Text = CStr(Format(Me.m_Form.NumericUpDown_GrayAbnormalStandardGray.Value * ((100 - Me.m_Form.NumericUpDown_GrayAbnormal_NegLimit.Value) / 100), "#"))

                ''--- Auto (第六頁) --------------------------------
                'Me.m_Form.NumericUpDown_AutoExposure_TargetMean.Maximum = GrayLevel_Maximum
                'If Me.m_Form.NumericUpDown_AutoExposure_Kp.Maximum >= fpr.AutoExposure_Kp.Value Then Me.m_Form.NumericUpDown_AutoExposure_Kp.Value = fpr.AutoExposure_Kp.Value Else FuncUpdateDataLog &= "[Auto] Kp設定超出範圍： " & Me.m_Form.NumericUpDown_AutoExposure_Kp.Maximum & vbCrLf
                'If Me.m_Form.NumericUpDown_AutoExposure_TargetMean.Maximum >= fpr.AutoExposure_TargetMean.Value Then Me.m_Form.NumericUpDown_AutoExposure_TargetMean.Value = fpr.AutoExposure_TargetMean.Value Else FuncUpdateDataLog &= "[Auto] TargetMean設定超出範圍： " & Me.m_Form.NumericUpDown_AutoExposure_TargetMean.Maximum & vbCrLf
                'If Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum >= fpr.AutoExposure_LargeErrorRange_UL.Value Then Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value = fpr.AutoExposure_LargeErrorRange_UL.Value Else FuncUpdateDataLog &= "[Auto] LargeErrorRange_UL設定超出範圍： " & Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_UL.Maximum & vbCrLf
                'If Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum >= fpr.AutoExposure_LargeErrorRange_DL.Value Then Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value = fpr.AutoExposure_LargeErrorRange_DL.Value Else FuncUpdateDataLog &= "[Auto] LargeErrorRange_DL設定超出範圍： " & Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_DL.Maximum & vbCrLf
                'If Me.m_Form.NumericUpDown_AutoExposure_SmallErrorRange.Maximum >= fpr.AutoExposure_SmallErrorRange.Value Then Me.m_Form.NumericUpDown_AutoExposure_SmallErrorRange.Value = fpr.AutoExposure_SmallErrorRange.Value Else FuncUpdateDataLog &= "[Auto] SmallErrorRange設定超出範圍： " & Me.m_Form.NumericUpDown_AutoExposure_SmallErrorRange.Maximum & vbCrLf
                'If Me.m_Form.NumericUpDown_AutoExposure_GrabDelayTime.Maximum >= fpr.AutoExposure_GrabDelayTime.Value Then Me.m_Form.NumericUpDown_AutoExposure_GrabDelayTime.Value = fpr.AutoExposure_GrabDelayTime.Value Else FuncUpdateDataLog &= "[Auto] GrabDelayTime設定超出範圍： " & Me.m_Form.NumericUpDown_AutoExposure_GrabDelayTime.Maximum & vbCrLf

                '-- Other (第七頁) --------------------------------
                '--- Point Pitch Setting ---
                If Me.m_Form.NumericUpDown_Point_PitchX.Maximum >= fpr.Point_PitchX.Value Then Me.m_Form.NumericUpDown_Point_PitchX.Value = fpr.Point_PitchX.Value Else FuncUpdateDataLog &= "Point PitchX 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Point_PitchY.Maximum >= fpr.Point_PitchY.Value Then Me.m_Form.NumericUpDown_Point_PitchY.Value = fpr.Point_PitchY.Value Else FuncUpdateDataLog &= "Point PitchY 設定超出範圍" & vbCrLf
                '--- Line Pitch Setting ---
                If Me.m_Form.NumericUpDown_Line_PitchX.Maximum >= fpr.Line_PitchX.Value Then Me.m_Form.NumericUpDown_Line_PitchX.Value = fpr.Line_PitchX.Value Else FuncUpdateDataLog &= "Line PitchX 設定超出範圍" & vbCrLf
                If Me.m_Form.NumericUpDown_Line_PitchY.Maximum >= fpr.Line_PitchY.Value Then Me.m_Form.NumericUpDown_Line_PitchY.Value = fpr.Line_PitchY.Value Else FuncUpdateDataLog &= "Line PitchY 設定超出範圍" & vbCrLf

                '--- Point\Line Average FIlter ---
                If Me.m_Form.NumericUpDown_AverageFilter.Maximum >= fpr.Average_Filter.Value Then Me.m_Form.NumericUpDown_AverageFilter.Value = fpr.Average_Filter.Value Else FuncUpdateDataLog &= "Average Pitch 設定超出範圍" & vbCrLf

                '--- Point Algorithm ---
                'Point Algorithm ---
                'If fpr.PointAlgorithm.Value = 0 Then
                '    Me.m_Form.RadioButton_PointAlgorithm_0.Checked = True
                'ElseIf fpr.PointAlgorithm.Value = 1 Then
                '    Me.m_Form.RadioButton_PointAlgorithm_1.Checked = True
                'ElseIf fpr.PointAlgorithm.Value = 2 Then
                Me.m_Form.RadioButton_PointAlgorithm_3.Checked = True
                'ElseIf fpr.PointAlgorithm.Value = 3 Then
                '    Me.m_Form.RadioButton_PointAlgorithm_3.Checked = True
                'ElseIf fpr.PointAlgorithm.Value = 4 Then  'Circle ROI Image
                '    Me.m_Form.RadioButton_PointAlgorithm_4.Checked = True
                'ElseIf fpr.PointAlgorithm.Value = 5 Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
                '    Me.m_Form.RadioButton_PointAlgorithm_5.Checked = True
                'ElseIf fpr.PointAlgorithm.Value = 6 Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
                '    Me.m_Form.RadioButton_PointAlgorithm_6.Checked = True
                'End If

                If fmr.AlignType.Value = AlignType.Rectangle Then
                    'Me.m_Form.RadioButton_PointAlgorithm_0.Enabled = True
                    'Me.m_Form.RadioButton_PointAlgorithm_1.Enabled = True
                    Me.m_Form.RadioButton_PointAlgorithm_3.Enabled = True
                    'Me.m_Form.m_Form.RadioButton_PointAlgorithm_3.Enabled = True
                    'Me.m_Form.RadioButton_PointAlgorithm_4.Enabled = False
                    'Me.m_Form.RadioButton_PointAlgorithm_5.Enabled = True
                    'Me.m_Form.RadioButton_PointAlgorithm_6.Enabled = False
                ElseIf fmr.AlignType.Value = AlignType.Circle Then
                    'Me.m_Form.RadioButton_PointAlgorithm_0.Enabled = False
                    'Me.m_Form.RadioButton_PointAlgorithm_1.Enabled = False
                    Me.m_Form.RadioButton_PointAlgorithm_3.Enabled = False
                    'Me.m_Form.RadioButton_PointAlgorithm_3.Enabled = False
                    'Me.m_Form.RadioButton_PointAlgorithm_4.Enabled = True   'Circle Image
                    'Me.m_Form.RadioButton_PointAlgorithm_5.Enabled = False
                    'Me.m_Form.RadioButton_PointAlgorithm_6.Enabled = True   'Circle Image
                End If

                '--- Func Raw Data Filter Mura Setting ---
                'Me.m_Form.CheckBox_FuncRawDataFilterMura_Enable.Checked = fmr.FuncRawDataFilterMura_Enable.Value

                '--- Boundary Width ---
                Me.m_Form.NumericUpDown_Boundary_MulWidth_LX.Value = fpr.Boundary_MulWidth_LX.Value
                Me.m_Form.NumericUpDown_Boundary_MulWidth_RX.Value = fpr.Boundary_MulWidth_RX.Value
                Me.m_Form.NumericUpDown_Boundary_MulWidth_TY.Value = fpr.Boundary_MulWidth_TY.Value
                Me.m_Form.NumericUpDown_Boundary_MulWidth_BY.Value = fpr.Boundary_MulWidth_BY.Value

                ''--- AI Setting ---
                'Me.m_Form.NumericUpDown_AiResizeX.Value = fmr.AiResizeX.Value
                'Me.m_Form.NumericUpDown_AiResizeY.Value = fmr.AiResizeY.Value
                'Me.m_Form.ComboBox_IsAISaveROI.Text = fmr.IsAISaveROI.Value

                ''--- 第八頁(PL Mark) ---
                'If Me.m_IPBootConfig.PLMarkUI.Value Then
                '    If Not PL_mmr Is Nothing Then
                '        Me.m_Form.CheckBox_FillOfHole.Checked = PL_mmr.FillofHole
                '        Me.m_Form.NumericUpDown_SearchRange_PLMark_Multiple.Value = PL_mmr.SearchRange_PLMark_Multiple
                '        Me.m_Form.NumericUpDown_BlobArea.Value = PL_mmr.BlobArea
                '        Me.m_Form.NumericUpDown_SearchMarkCount.Value = PL_mmr.SearchMarkCount
                '        Me.m_CurrentPLMarkIndex = 0
                '        '--- Load Current Pattern ---
                '        Me.Update_PLMark_Pattern(Me.m_CurrentPLMarkIndex, Me.m_FuncProcess.PLMarkModelRecipe)
                '    Else
                '        Me.m_FuncProcess.PLMarkModelRecipe = New ClsPLMarkModelRecipe
                '    End If
                'End If

                ''--- 第九頁(HotPixel) ---
                'Me.m_Form.GroupBox_HotPixel.Enabled = False
                'Me.m_Form.CheckBox_HotPixelEnable.Checked = fpr.HotPixelEnable.Value
                'Me.m_Form.NumericUpDown_HotPixelRecipe.Value = fpr.HotPixelRecipe.Value
                'Me.m_Form.NumericUpDown_HotPixelFilterDistance.Value = fpr.HotPixelFilterDistance.Value
                'Me.m_Form.NumericUpDown_HotPixelMaxMean.Value = fpr.HotPixelMaxMean.Value
                'Me.m_Form.TrackBar_HotPixel_Threshold.Value = Me.m_Form.NumericUpDown_HotPixelRecipe.Value
                'Me.m_Form.CheckBox_Filter_HotPixel_With_Characteristics.Checked = fpr.Filter_HotPixel_With_Characteristics_Enable.Value

                ''--- 第十頁(TP Mark) ---
                'If Me.m_IPBootConfig.TPMarkUI.Value Then
                '    If Not TP_mmr Is Nothing Then
                '        Me.m_CurrentTPMarkIndex = 0
                '        '--- Load Current Pattern ---
                '        Me.Update_TPMark_Pattern(Me.m_CurrentTPMarkIndex, Me.m_FuncProcess.TPMarkModelRecipe)
                '    Else
                '        Me.m_FuncProcess.TPMarkModelRecipe = New ClsTPMarkModelRecipe
                '    End If
                'End If

                '--- Enable Setting ---
                'Me.m_Form.CheckBox_Report_Multi_Pixel.Checked = fpr.Report_Multi_Pixel.Value   '2013/06/18 Rick add
                Me.m_Form.CheckBox_Align_Enable.Checked = fpr.AlignEnable.Value
                Me.m_Form.CheckBox_Point_Enable.Checked = fpr.PointEnable.Value
                'Me.m_Form.CheckBox_GSBP_Enable.Checked = fpr.AnalysisGSBP.Value
                'Me.m_Form.CheckBox_BLDP_Enable.Checked = fpr.AnalysisBLDP.Value
                Me.m_Form.CheckBox_Line_Enable.Checked = fpr.LineEnable.Value
                Me.m_Form.CheckBox_HLine_NotAddToOutput.Checked = fpr.HLine_NotAddToOutput.Value
                Me.m_Form.CheckBox_VLine_NotAddToOutput.Checked = fpr.VLine_NotAddToOutput.Value
                'Me.m_Form.CheckBox_Filter_VH_Scratch.Checked = fpr.Filter_VH_Scratch.Value
                'Me.m_Form.CheckBox_HalfScreen_Enable.Checked = fpr.HalfScreenEnable.Value
                Me.m_Form.CheckBox_GrayAbnormal_Enable.Checked = fpr.GrayAbnormalEnable.Value
                'Me.m_Form.CheckBox_PLMark_Enable.Checked = fpr.PLMarkEnable.Value
                'Me.m_Form.CheckBox_CurrentPLMark_Enable.Enabled = Me.m_Form.CheckBox_PLMark_Enable.Checked
                'Me.m_Form.CheckBox_TPMark_Enable.Checked = fpr.TPMarkEnable.Value
                'Me.m_Form.CheckBox_CPD_Enable.Checked = fpr.CPDEnable.Value
                'Me.m_Form.CheckBox_TPMark_Enable.Checked = fpr.TPMarkEnable.Value
                'Me.m_Form.CheckBox_Waku_Inspect_Enable.Checked = fpr.WakuInspectEnable.Value

                'If fpr.WakuInspectEnable.Value Then
                '    Me.m_Form.ComboBox_WakuEdge.SelectedIndex = 1
                'End If

                Me.UpdateUIEnable()

                If FuncUpdateDataLog.Length > 0 Then Throw New Exception(FuncUpdateDataLog)
            End If
        Catch ex As Exception
            MsgBox("[Dialog_FuncSetting] 參數載入Form出錯：" & vbCrLf & ex.Message & "，請確認。", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try

    End Sub
#End Region
#Region "--- Button_Enable ---"
    Private Sub Button_Enable(ByVal En As Boolean)
        'Me.Button_LoadImage.Enabled = En
        Me.m_Form.Button_SaveFuncParam.Enabled = En
        Me.m_Form.TreeView_FuncParamPattern.Enabled = En
    End Sub
#End Region

#Region "--- Button_PLMark_Enable ---"
    'Private Sub Button_PLMark_Enable(ByVal En As Boolean)
    '    Button_Enable(En)
    '    Me.Button_PLMark_PatTest.Enabled = En
    '    Me.Button_Save_PLMark.Enabled = En
    'End Sub
#End Region

#Region "--- Setting ---"
    Private Sub Setting()
        Dim fpr As ClsFuncPatternRecipe
        Dim fmr As ClsFuncModelRecipe
        Dim pmmr As ClsPLMarkModelRecipe

        Try
            Me.CheckPattern()

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraPatternRecipeArray.Count Then
                fpr = Me.m_FuncProcess.FuncPatternRecipeArray.Item(0)
            Else
                fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
            End If
            fmr = Me.m_FuncProcess.FuncModelRecipe
            pmmr = Me.m_FuncProcess.PLMarkModelRecipe

            '--- 第一頁 ---
            '--- BP ---
            fpr.BDPointRecipe.Threshold_BP.Value = Me.m_Form.NumericUpDown_BP_Threshold.Value
            fpr.BDPointRecipe.Threshold_BP_Low.Value = Me.m_Form.NumericUpDown_BP_Threshold_Low.Value
            fpr.BDPointRecipe.ThresholdRim_BP.Value = Me.m_Form.NumericUpDown_BP_RimThreshold.Value
            fpr.BDPointRecipe.ThresholdRim_BP_Low.Value = Me.m_Form.NumericUpDown_BP_RimThreshold_Low.Value
            '--- DP ---
            fpr.BDPointRecipe.Threshold_DP.Value = Me.m_Form.NumericUpDown_DP_Threshold.Value
            fpr.BDPointRecipe.Threshold_DP_Low.Value = Me.m_Form.NumericUpDown_DP_Threshold_Low.Value
            fpr.BDPointRecipe.ThresholdRim_DP.Value = Me.m_Form.NumericUpDown_DP_RimThreshold.Value
            fpr.BDPointRecipe.ThresholdRim_DP_Low.Value = Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Value

            fpr.AnalysisBP.Value = Me.m_Form.RadioButton_BP.Checked
            fpr.AnalysisDP.Value = Me.m_Form.RadioButton_DP.Checked
            If Me.m_Form.RadioButton_BPDP.Checked Then
                fpr.AnalysisBP.Value = True
                fpr.AnalysisDP.Value = True
            End If

            '--- Tool ---
            '[1] Inverse Point Type & Fix Area ---
            fpr.BDPointRecipe.Inverse_PointDefectType.Value = False 'Me.m_Form.CheckBox_Inverse_Point_DefectType.Checked
            fpr.BDPointRecipe.Inverse_Point_EnableFixArea.Value = False 'Me.m_Form.CheckBox_Inverse_Point_EnableFixArea.Checked
            fpr.BDPointRecipe.Inverse_PointFixArea.Value = 10   'Me.m_Form.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value

            fpr.BDPointRecipe.AreaMax_BP.Value = Me.m_Form.NumericUpDown_BP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_BP.Value = Me.m_Form.NumericUpDown_BP_AreaMin.Value
            fpr.BDPointRecipe.AreaMax_DP.Value = Me.m_Form.NumericUpDown_DP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_DP.Value = Me.m_Form.NumericUpDown_DP_AreaMin.Value
            fpr.BDPointRecipe.BypassX.Value = Me.m_Form.NumericUpDown_Point_ByPassX.Value
            fpr.BDPointRecipe.BypassY.Value = Me.m_Form.NumericUpDown_Point_ByPassY.Value
            fpr.BDPointRecipe.OverNum.Value = Me.m_Form.NumericUpDown_Point_OverNum.Value
            '
            fpr.Report_Multi_Pixel.Value = False 'Me.m_Form.CheckBox_Report_Multi_Pixel.Checked   '2013/06/18 Rick add
            fpr.AlignEnable.Value = Me.m_Form.CheckBox_Align_Enable.Checked
            fpr.PointEnable.Value = Me.m_Form.CheckBox_Point_Enable.Checked
            fpr.AnalysisGSBP.Value = False  'Me.m_Form.CheckBox_GSBP_Enable.Checked
            fpr.AnalysisBLDP.Value = False  'Me.m_Form.CheckBox_BLDP_Enable.Checked
            fpr.CPDEnable.Value = False 'Me.m_Form.CheckBox_CPD_Enable.Checked
            fpr.WakuInspectEnable.Value = False 'Me.m_Form.CheckBox_Waku_Inspect_Enable.Checked

            '---SeparateBP---
            fpr.SeparateBPEnable.Value = False  'Me.m_Form.CheckBox_SeparateBPEnable.Checked
            fpr.SeparateBPArea.Value = 0    'Me.m_Form.NumericUpDown_SeparateBPArea.Value
            fpr.SeparateBPBlob.Value = 0    'Me.m_Form.NumericUpDown_SeparateBPBlob.Value

            fpr.BDPointRecipe.EnableLeakPoint.Value = False 'Me.m_Form.CheckBox_EnableLeakPoint.Checked

            '--- 第二頁 ---
            '--- BP Characteristics ---
            fpr.BDPointRecipe.Elongation_Min.Value = Me.m_Form.NumericUpDown_BP_Elongation_Min.Value
            fpr.BDPointRecipe.Elongation_Max.Value = Me.m_Form.NumericUpDown_BP_Elongation_Max.Value
            fpr.BDPointRecipe.Fullness_Min.Value = Me.m_Form.NumericUpDown_BP_Fullness_Min.Value
            fpr.BDPointRecipe.Fullness_Max.Value = Me.m_Form.NumericUpDown_BP_Fullness_Max.Value
            fpr.BDPointRecipe.MaxGray_Fullness_Min.Value = Me.m_Form.NumericUpDown_BP_MaxGray_Fullness_Min.Value
            fpr.BDPointRecipe.GrayMean_Min_BP.Value = Me.m_Form.NumericUpDown_BP_GrayMean_Min.Value
            fpr.BDPointRecipe.MaxGray_Min_BP.Value = Me.m_Form.NumericUpDown_BP_MaxGray_Min.Value
            fpr.BDPointRecipe.MaxGray_Max_BP.Value = Me.m_Form.NumericUpDown_BP_MaxGray_Max.Value
            fpr.BDPointRecipe.Compactness_Max_BP.Value = Me.m_Form.NumericUpDown_BP_Compactness_Max.Value
            fpr.BDPointRecipe.StdDev_Max_BP.Value = Me.m_Form.NumericUpDown_BP_StdDev_Max.Value

            '--- DP Characteristics ---
            fpr.BDPointRecipe.Elongation_Min_DP.Value = Me.m_Form.NumericUpDown_DP_Elongation_Min.Value
            fpr.BDPointRecipe.Elongation_Max_DP.Value = Me.m_Form.NumericUpDown_DP_Elongation_Max.Value
            fpr.BDPointRecipe.Fullness_Min_DP.Value = Me.m_Form.NumericUpDown_DP_Fullness_Min.Value
            fpr.BDPointRecipe.Fullness_Max_DP.Value = Me.m_Form.NumericUpDown_DP_Fullness_Max.Value
            fpr.BDPointRecipe.MaxGray_Fullness_Min_DP.Value = Me.m_Form.NumericUpDown_DP_MaxGray_Fullness_Min.Value
            fpr.BDPointRecipe.GrayMean_Max_DP.Value = Me.m_Form.NumericUpDown_DP_GrayMean_Max.Value
            fpr.BDPointRecipe.MinGray_Min_DP.Value = Me.m_Form.NumericUpDown_DP_MinGray_Min.Value
            fpr.BDPointRecipe.MinGray_Max_DP.Value = Me.m_Form.NumericUpDown_DP_MinGray_Max.Value
            fpr.BDPointRecipe.Compactness_Max_DP.Value = Me.m_Form.NumericUpDown_DP_Compactness_Max.Value
            fpr.BDPointRecipe.StdDev_Max_DP.Value = Me.m_Form.NumericUpDown_DP_StdDev_Max.Value

            '--- 第三頁 ---
            '--- GSBP ---
            fpr.BDPointRecipe.Threshold_GSBP.Value = 0  'Me.m_Form.NumericUpDown_GSBP_Threshold.Value
            fpr.BDPointRecipe.ThresholdRim_GSBP.Value = 0   'Me.m_Form.NumericUpDown_GSBP_ThresholdRim.Value

            '--- GSBP - Common setting ---
            fpr.BDPointRecipe.AreaMax_GSBP.Value = 250  'Me.m_Form.NumericUpDown_GSBP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_GSBP.Value = 0    'Me.m_Form.NumericUpDown_GSBP_AreaMin.Value
            fpr.BDPointRecipe.GSBP_Count_Min.Value = 20 'Me.m_Form.NumericUpDown_GSBP_Count_Min.Value
            fpr.BDPointRecipe.GSBP_RangeX.Value = 200   'Me.m_Form.NumericUpDown_GSBP_RangeX.Value
            fpr.BDPointRecipe.GSBP_RangeY.Value = 200   'Me.m_Form.NumericUpDown_GSBP_RangeY.Value
            fpr.BDPointRecipe.GSBP_Scratch_Length.Value = 100   'Me.m_Form.NumericUpDown_GSBP_Scratch_Length.Value
            fpr.BDPointRecipe.GSBP_OverNum.Value = 100  'Me.m_Form.NumericUpDown_GSBP_OverNum.Value
            fpr.BDPointRecipe.GSBP_NumOfHoles.Value = 0 'Me.m_Form.NumericUpDown_GSBP_NumOfHoles.Value
            fpr.BDPointRecipe.GSBP_GrayMax_High.Value = 0   'Me.m_Form.NumericUpDown_GSBP_GrayMax_High.Value
            fpr.BDPointRecipe.GSBP_GrayMax_Low.Value = 0    'Me.m_Form.NumericUpDown_GSBP_GrayMax_Low.Value

            fpr.AnalysisGSBP.Value = False  'Me.m_Form.CheckBox_GSBP_Enable.Checked

            '--- BLDP ---
            fpr.BDPointRecipe.Threshold_BLDP.Value = 0 'Me.m_Form.NumericUpDown_BLDP_Threshold.Value
            fpr.BDPointRecipe.ThresholdRim_BLDP.Value = 0   'Me.m_Form.NumericUpDown_BLDP_ThresholdRim.Value
            fpr.BDPointRecipe.EnhanceCount_BLDP.Value = 0   'Me.m_Form.NumericUpDown_BLDP_EnhanceCount.Value

            '--- BLDP - Common setting ---
            fpr.BDPointRecipe.AreaMax_BLDP.Value = 250  'Me.m_Form.NumericUpDown_BLDP_AreaMax.Value
            fpr.BDPointRecipe.AreaMin_BLDP.Value = 0    'Me.m_Form.NumericUpDown_BLDP_AreaMin.Value
            fpr.BDPointRecipe.BLDP_Count_Min.Value = 20 'Me.m_Form.NumericUpDown_BLDP_Count_Min.Value
            fpr.BDPointRecipe.BLDP_RangeX.Value = 200   'Me.m_Form.NumericUpDown_BLDP_RangeX.Value
            fpr.BDPointRecipe.BLDP_RangeY.Value = 200   'Me.m_Form.NumericUpDown_BLDP_RangeY.Value
            fpr.BDPointRecipe.BLDP_Scratch_Length.Value = 100   'Me.m_Form.NumericUpDown_BLDP_Scratch_Length.Value
            fpr.BDPointRecipe.BLDP_OverNum.Value = 100  'Me.m_Form.NumericUpDown_BLDP_OverNum.Value
            fpr.BDPointRecipe.BLDP_Fatness_Min.Value = 2.1  'Me.m_Form.NumericUpDown_BLDP_Fatness_Min.Value
            fpr.BDPointRecipe.Elongation_Min_BLDP.Value = 0.03  'Me.m_Form.NumericUpDown_BLDP_Elongation_Min.Value
            fpr.BDPointRecipe.Elongation_Max_BLDP.Value = 100   'Me.m_Form.NumericUpDown_BLDP_Elongation_Max.Value

            fpr.AnalysisBLDP.Value = False  'Me.m_Form.CheckBox_BLDP_Enable.Checked

            '--- 第四頁 ---
            fpr.LineFinderRecipe.AnalysisBL.Value = Me.m_Form.CheckBox_BLine_Enable.Checked
            fpr.LineFinderRecipe.AnalysisDL.Value = Me.m_Form.CheckBox_DLine_Enable.Checked
            fpr.LineFinderRecipe.Threshold_DL.Value = Me.m_Form.NumericUpDown_DL_Threshold.Value
            fpr.LineFinderRecipe.Threshold_BL.Value = Me.m_Form.NumericUpDown_BL_Threshold.Value
            fpr.LineFinderRecipe.ThresholdRim_DL.Value = Me.m_Form.NumericUpDown_DL_RimThreshold.Value
            fpr.LineFinderRecipe.ThresholdRim_BL.Value = Me.m_Form.NumericUpDown_BL_RimThreshold.Value
            fpr.LineFinderRecipe.ByPassUpH.Value = Me.m_Form.NumericUpDown_Line_ByPassUpH.Value
            fpr.LineFinderRecipe.ByPassDownH.Value = Me.m_Form.NumericUpDown_Line_ByPassDownH.Value
            fpr.LineFinderRecipe.ByPassLeftV.Value = Me.m_Form.NumericUpDown_Line_ByPassLeftV.Value
            fpr.LineFinderRecipe.ByPassRightV.Value = Me.m_Form.NumericUpDown_Line_ByPassRightV.Value
            fpr.LineFinderRecipe.Line_Cut.Value = Me.m_Form.NumericUpDown_Line_Cut.Value
            fpr.LineFinderRecipe.Line_Short_Cut.Value = Me.m_Form.NumericUpDown_Line_Short_Cut.Value
            fpr.LineFinderRecipe.Line_Cut_H.Value = Me.m_Form.NumericUpDown_Line_Cut_H.Value
            fpr.LineFinderRecipe.Line_Short_Cut_H.Value = Me.m_Form.NumericUpDown_Line_Short_Cut_H.Value
            fpr.LineFinderRecipe.LineOverNum.Value = Me.m_Form.NumericUpDown_Line_OverNumber.Value
            fpr.LineFinderRecipe.BlockOverNum.Value = Me.m_Form.NumericUpDown_Block_OverNumber.Value
            fpr.LineFinderRecipe.Elongation_Min.Value = 0   'Me.m_Form.NumericUpDown_Line_Elongation_Min.Value
            fpr.LineFinderRecipe.Mean_Difference.Value = 0  'Me.m_Form.NumericUpDown_MeanDifference.Value
            fpr.LineEnable.Value = Me.m_Form.CheckBox_Line_Enable.Checked
            fpr.HLine_NotAddToOutput.Value = Me.m_Form.CheckBox_HLine_NotAddToOutput.Checked
            fpr.VLine_NotAddToOutput.Value = Me.m_Form.CheckBox_VLine_NotAddToOutput.Checked
            fpr.Filter_VH_Scratch.Value = False 'Me.m_Form.CheckBox_Filter_VH_Scratch.Checked
            fpr.HalfScreenEnable.Value = False  'Me.m_Form.CheckBox_HalfScreen_Enable.Checked

            fpr.LineFinderRecipe.LeakPointRadius.Value = 0  'Me.m_Form.NumericUpDown_LeakPointRadius.Value
            '--- 第五頁 ---
            fpr.DisplayMeanOffsetRecipe.PosLimit.Value = Me.m_Form.NumericUpDown_GrayAbnormal_PosLimit.Value
            fpr.DisplayMeanOffsetRecipe.NegLimit.Value = Me.m_Form.NumericUpDown_GrayAbnormal_NegLimit.Value
            fpr.DisplayMeanOffsetRecipe.StandardGray.Value = Me.m_Form.NumericUpDown_GrayAbnormalStandardGray.Value
            fpr.DisplayMeanOffsetRecipe.NoDisplay.Value = 0 'Me.m_Form.NumericUpDown_GrayAbnormal_NoDisplay.Value
            fpr.GrayAbnormalEnable.Value = Me.m_Form.CheckBox_GrayAbnormal_Enable.Checked

            '--- 第六頁 ---
            fpr.AutoExposure_Kp.Value = 0   'Me.m_Form.NumericUpDown_AutoExposure_Kp.Value
            fpr.AutoExposure_TargetMean.Value = 0   'Me.m_Form.NumericUpDown_AutoExposure_TargetMean.Value
            fpr.AutoExposure_LargeErrorRange_UL.Value = 0   'Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_UL.Value
            fpr.AutoExposure_LargeErrorRange_DL.Value = 0   'Me.m_Form.NumericUpDown_AutoExposure_LargeErrorRange_DL.Value
            fpr.AutoExposure_SmallErrorRange.Value = 0  'Me.m_Form.NumericUpDown_AutoExposure_SmallErrorRange.Value
            fpr.AutoExposure_GrabDelayTime.Value = 0    'Me.m_Form.NumericUpDown_AutoExposure_GrabDelayTime.Value

            '--- 第七頁 ---
            fpr.Point_PitchX.Value = Me.m_Form.NumericUpDown_Point_PitchX.Value
            fpr.Point_PitchY.Value = Me.m_Form.NumericUpDown_Point_PitchY.Value
            fpr.Line_PitchX.Value = Me.m_Form.NumericUpDown_Line_PitchX.Value
            fpr.Line_PitchY.Value = Me.m_Form.NumericUpDown_Line_PitchY.Value

            '--- Point\Line Average FIlter ---
            fpr.Average_Filter.Value = Me.m_Form.NumericUpDown_AverageFilter.Value

            '--- Point Algorithm ---
            'If Me.m_Form.RadioButton_PointAlgorithm_0.Checked Then
            '    fpr.PointAlgorithm.Value = 0
            'ElseIf Me.m_Form.RadioButton_PointAlgorithm_1.Checked Then
            '    fpr.PointAlgorithm.Value = 1
            'ElseIf Me.m_Form.RadioButton_PointAlgorithm_2.Checked Then
            fpr.PointAlgorithm.Value = 2
            'ElseIf Me.m_Form.RadioButton_PointAlgorithm_3.Checked Then
            '    fpr.PointAlgorithm.Value = 3
            'ElseIf Me.m_Form.RadioButton_PointAlgorithm_4.Checked Then  'Circle ROI Image
            '    fpr.PointAlgorithm.Value = 4
            'ElseIf Me.m_Form.RadioButton_PointAlgorithm_5.Checked Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
            '    fpr.PointAlgorithm.Value = 5
            'ElseIf Me.m_Form.RadioButton_PointAlgorithm_6.Checked Then  'R\G\B Image (Inspect DP in Bright Region, Inspect BP in Dark Region)
            '    fpr.PointAlgorithm.Value = 6
            'End If

            '--- Func Raw Data Filter Mura Setting ---
            fmr.FuncRawDataFilterMura_Enable.Value = False  'Me.m_Form.CheckBox_FuncRawDataFilterMura_Enable.Checked

            '--- Boundary Width ---
            fpr.Boundary_MulWidth_LX.Value = Me.m_Form.NumericUpDown_Boundary_MulWidth_LX.Value
            fpr.Boundary_MulWidth_RX.Value = Me.m_Form.NumericUpDown_Boundary_MulWidth_RX.Value
            fpr.Boundary_MulWidth_TY.Value = Me.m_Form.NumericUpDown_Boundary_MulWidth_TY.Value
            fpr.Boundary_MulWidth_BY.Value = Me.m_Form.NumericUpDown_Boundary_MulWidth_BY.Value

            '--- AI Setting ---
            fmr.AiResizeX.Value = 0 'Me.m_Form.NumericUpDown_AiResizeX.Value
            fmr.AiResizeY.Value = 0 'Me.m_Form.NumericUpDown_AiResizeY.Value
            fmr.IsAISaveROI.Value = "false" 'Me.m_Form.ComboBox_IsAISaveROI.Text.ToLower()

            '--- 第八頁(PL Mark) ---
            If Me.m_IPBootConfig.PLMarkUI.Value Then
                pmmr.FillofHole = False 'Me.m_Form.CheckBox_FillOfHole.Checked
                pmmr.SearchRange_PLMark_Multiple = 1    'Me.m_Form.NumericUpDown_SearchRange_PLMark_Multiple.Value
                fpr.PLMarkEnable.Value = False  'Me.m_Form.CheckBox_PLMark_Enable.Checked
                pmmr.BlobArea = 0   'Me.m_Form.NumericUpDown_BlobArea.Value
                pmmr.SearchMarkCount = 0    'Me.m_Form.NumericUpDown_SearchMarkCount.Value
            End If

            '--- 第九頁(Hot Pixel) ---
            fpr.HotPixelEnable.Value = False    'Me.m_Form.CheckBox_HotPixelEnable.Checked
            fpr.HotPixelRecipe.Value = 0    'Me.m_Form.NumericUpDown_HotPixelRecipe.Value
            fpr.HotPixelFilterDistance.Value = 0    'Me.m_Form.NumericUpDown_HotPixelFilterDistance.Value
            fpr.HotPixelMaxMean.Value = 1   'Me.m_Form.NumericUpDown_HotPixelMaxMean.Value
            fpr.Filter_HotPixel_With_Characteristics_Enable.Value = False   'Me.m_Form.CheckBox_Filter_HotPixel_With_Characteristics.Checked

            '---第十頁(TP Mark) ---
            If Me.m_IPBootConfig.TPMarkUI.Value Then
                fpr.TPMarkEnable.Value = False  'Me.m_Form.CheckBox_TPMark_Enable.Checked
            End If
        Catch ex As Exception
            MsgBox("[Dialog_FuncSetting.Setting] Setting 參數出錯：" & vbCrLf & ex.Message & "，請確認。", MsgBoxStyle.Information, "[AreaGrabber]")
        End Try
    End Sub
#End Region
#Region "--- Compare ---"
    Private Sub Compare(ByVal fprOld As ClsFuncPatternRecipe, ByVal fprNew As ClsFuncPatternRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[FuncPatternRecipe]**********************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        '--- 第一頁 ---
        If fprOld.BDPointRecipe.Threshold_BP.Value <> fprNew.BDPointRecipe.Threshold_BP.Value Then
            dlm.WriteLog("< Threshold_BP >: " & fprOld.BDPointRecipe.Threshold_BP.Value & " --> " & fprNew.BDPointRecipe.Threshold_BP.Value)
            fprOld.BDPointRecipe.Threshold_BP.Value = fprNew.BDPointRecipe.Threshold_BP.Value
        End If
        If fprOld.BDPointRecipe.Threshold_DP.Value <> fprNew.BDPointRecipe.Threshold_DP.Value Then
            dlm.WriteLog("< Threshold_DP >: " & fprOld.BDPointRecipe.Threshold_DP.Value & " --> " & fprNew.BDPointRecipe.Threshold_DP.Value)
            fprOld.BDPointRecipe.Threshold_DP.Value = fprNew.BDPointRecipe.Threshold_DP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_BP.Value <> fprNew.BDPointRecipe.ThresholdRim_BP.Value Then
            dlm.WriteLog("< ThresholdRim_BP >: " & fprOld.BDPointRecipe.ThresholdRim_BP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_BP.Value)
            fprOld.BDPointRecipe.ThresholdRim_BP.Value = fprNew.BDPointRecipe.ThresholdRim_BP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_DP.Value <> fprNew.BDPointRecipe.ThresholdRim_DP.Value Then
            dlm.WriteLog("< ThresholRimd_DP >: " & fprOld.BDPointRecipe.ThresholdRim_DP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_DP.Value)
            fprOld.BDPointRecipe.ThresholdRim_DP.Value = fprNew.BDPointRecipe.ThresholdRim_DP.Value
        End If
        If fprOld.AnalysisBP.Value <> fprNew.AnalysisBP.Value Then
            dlm.WriteLog("< AnalysisBP >: " & fprOld.AnalysisBP.Value & " --> " & fprNew.AnalysisBP.Value)
            fprOld.AnalysisBP.Value = fprNew.AnalysisBP.Value
        End If
        If fprOld.AnalysisDP.Value <> fprNew.AnalysisDP.Value Then
            dlm.WriteLog("< AnalysisDP >: " & fprOld.AnalysisDP.Value & " --> " & fprNew.AnalysisDP.Value)
            fprOld.AnalysisDP.Value = fprNew.AnalysisDP.Value
        End If

        If fprOld.BDPointRecipe.AreaMax_BP.Value <> fprNew.BDPointRecipe.AreaMax_BP.Value Then
            dlm.WriteLog("< AreaMax_BP >: " & fprOld.BDPointRecipe.AreaMax_BP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_BP.Value)
            fprOld.BDPointRecipe.AreaMax_BP.Value = fprNew.BDPointRecipe.AreaMax_BP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_BP.Value <> fprNew.BDPointRecipe.AreaMin_BP.Value Then
            dlm.WriteLog("< AreaMin_BP >: " & fprOld.BDPointRecipe.AreaMin_BP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_BP.Value)
            fprOld.BDPointRecipe.AreaMin_BP.Value = fprNew.BDPointRecipe.AreaMin_BP.Value
        End If

        If fprOld.BDPointRecipe.AreaMax_DP.Value <> fprNew.BDPointRecipe.AreaMax_DP.Value Then
            dlm.WriteLog("< AreaMax_DP >: " & fprOld.BDPointRecipe.AreaMax_DP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_DP.Value)
            fprOld.BDPointRecipe.AreaMax_DP.Value = fprNew.BDPointRecipe.AreaMax_DP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_DP.Value <> fprNew.BDPointRecipe.AreaMin_DP.Value Then
            dlm.WriteLog("< AreaMin_DP >: " & fprOld.BDPointRecipe.AreaMin_DP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_DP.Value)
            fprOld.BDPointRecipe.AreaMin_DP.Value = fprNew.BDPointRecipe.AreaMin_DP.Value
        End If

        If fprOld.BDPointRecipe.BypassX.Value <> fprNew.BDPointRecipe.BypassX.Value Then
            dlm.WriteLog("< BypassX >: " & fprOld.BDPointRecipe.BypassX.Value & " --> " & fprNew.BDPointRecipe.BypassX.Value)
            fprOld.BDPointRecipe.BypassX.Value = fprNew.BDPointRecipe.BypassX.Value
        End If
        If fprOld.BDPointRecipe.BypassY.Value <> fprNew.BDPointRecipe.BypassY.Value Then
            dlm.WriteLog("< BypassY >: " & fprOld.BDPointRecipe.BypassY.Value & " --> " & fprNew.BDPointRecipe.BypassY.Value)
            fprOld.BDPointRecipe.BypassY.Value = fprNew.BDPointRecipe.BypassY.Value
        End If
        If fprOld.BDPointRecipe.OverNum.Value <> fprNew.BDPointRecipe.OverNum.Value Then
            dlm.WriteLog("< OverNum >: " & fprOld.BDPointRecipe.OverNum.Value & " --> " & fprNew.BDPointRecipe.OverNum.Value)
            fprOld.BDPointRecipe.OverNum.Value = fprNew.BDPointRecipe.OverNum.Value
        End If
        If fprOld.PointEnable.Value <> fprNew.PointEnable.Value Then
            dlm.WriteLog("< PointEnable >: " & fprOld.PointEnable.Value & " --> " & fprNew.PointEnable.Value)
            fprOld.PointEnable.Value = fprNew.PointEnable.Value
        End If
        If fprOld.CPDEnable.Value <> fprNew.CPDEnable.Value Then
            dlm.WriteLog("< CPDEnable >: " & fprOld.CPDEnable.Value & " --> " & fprNew.CPDEnable.Value)
            fprOld.CPDEnable.Value = fprNew.CPDEnable.Value
        End If

        '--- 第二頁 ---
        If fprOld.LineFinderRecipe.ByPassUpH.Value <> fprNew.LineFinderRecipe.ByPassUpH.Value Then
            dlm.WriteLog("< ByPassUpH >: " & fprOld.LineFinderRecipe.ByPassUpH.Value & " --> " & fprNew.LineFinderRecipe.ByPassUpH.Value)
            fprOld.LineFinderRecipe.ByPassUpH.Value = fprNew.LineFinderRecipe.ByPassUpH.Value
        End If
        If fprOld.LineFinderRecipe.ByPassDownH.Value <> fprNew.LineFinderRecipe.ByPassDownH.Value Then
            dlm.WriteLog("< ByPassDownH >: " & fprOld.LineFinderRecipe.ByPassDownH.Value & " --> " & fprNew.LineFinderRecipe.ByPassDownH.Value)
            fprOld.LineFinderRecipe.ByPassDownH.Value = fprNew.LineFinderRecipe.ByPassDownH.Value
        End If
        If fprOld.LineFinderRecipe.ByPassLeftV.Value <> fprNew.LineFinderRecipe.ByPassLeftV.Value Then
            dlm.WriteLog("< ByPassLeftV >: " & fprOld.LineFinderRecipe.ByPassLeftV.Value & " --> " & fprNew.LineFinderRecipe.ByPassLeftV.Value)
            fprOld.LineFinderRecipe.ByPassLeftV.Value = fprNew.LineFinderRecipe.ByPassLeftV.Value
        End If
        If fprOld.LineFinderRecipe.ByPassRightV.Value <> fprNew.LineFinderRecipe.ByPassRightV.Value Then
            dlm.WriteLog("< ByPassRightV >: " & fprOld.LineFinderRecipe.ByPassRightV.Value & " --> " & fprNew.LineFinderRecipe.ByPassRightV.Value)
            fprOld.LineFinderRecipe.ByPassRightV.Value = fprNew.LineFinderRecipe.ByPassRightV.Value
        End If
        If fprOld.LineFinderRecipe.Line_Cut.Value <> fprNew.LineFinderRecipe.Line_Cut.Value Then
            dlm.WriteLog("< Line_Cut >: " & fprOld.LineFinderRecipe.Line_Cut.Value & " --> " & fprNew.LineFinderRecipe.Line_Cut.Value)
            fprOld.LineFinderRecipe.Line_Cut.Value = fprNew.LineFinderRecipe.Line_Cut.Value
        End If
        If fprOld.LineFinderRecipe.Line_Short_Cut.Value <> fprNew.LineFinderRecipe.Line_Short_Cut.Value Then
            dlm.WriteLog("< Line_Short_Cut >: " & fprOld.LineFinderRecipe.Line_Short_Cut.Value & " --> " & fprNew.LineFinderRecipe.Line_Short_Cut.Value)
            fprOld.LineFinderRecipe.Line_Short_Cut.Value = fprNew.LineFinderRecipe.Line_Short_Cut.Value
        End If
        If fprOld.LineFinderRecipe.LineOverNum.Value <> fprNew.LineFinderRecipe.LineOverNum.Value Then
            dlm.WriteLog("< LineOverNum >: " & fprOld.LineFinderRecipe.LineOverNum.Value & " --> " & fprNew.LineFinderRecipe.LineOverNum.Value)
            fprOld.LineFinderRecipe.LineOverNum.Value = fprNew.LineFinderRecipe.LineOverNum.Value
        End If
        If fprOld.LineFinderRecipe.BlockOverNum.Value <> fprNew.LineFinderRecipe.BlockOverNum.Value Then
            dlm.WriteLog("< BlockOverNum >: " & fprOld.LineFinderRecipe.BlockOverNum.Value & " --> " & fprNew.LineFinderRecipe.BlockOverNum.Value)
            fprOld.LineFinderRecipe.BlockOverNum.Value = fprNew.LineFinderRecipe.BlockOverNum.Value
        End If
        If fprOld.LineFinderRecipe.Mean_Difference.Value <> fprNew.LineFinderRecipe.Mean_Difference.Value Then
            dlm.WriteLog("< Mean_Difference >: " & fprOld.LineFinderRecipe.Mean_Difference.Value & " --> " & fprNew.LineFinderRecipe.Mean_Difference.Value)
            fprOld.LineFinderRecipe.Mean_Difference.Value = fprNew.LineFinderRecipe.Mean_Difference.Value
        End If
        If fprOld.LineEnable.Value <> fprNew.LineEnable.Value Then
            dlm.WriteLog("< LineEnable >: " & fprOld.LineEnable.Value & " --> " & fprNew.LineEnable.Value)
            fprOld.LineEnable.Value = fprNew.LineEnable.Value
        End If
        If fprOld.HLine_NotAddToOutput.Value <> fprNew.HLine_NotAddToOutput.Value Then
            dlm.WriteLog("< HLine_NotAddToOutput >: " & fprOld.HLine_NotAddToOutput.Value & " --> " & fprNew.HLine_NotAddToOutput.Value)
            fprOld.HLine_NotAddToOutput.Value = fprNew.HLine_NotAddToOutput.Value
        End If
        If fprOld.VLine_NotAddToOutput.Value <> fprNew.VLine_NotAddToOutput.Value Then
            dlm.WriteLog("< VLine_NotAddToOutput >: " & fprOld.VLine_NotAddToOutput.Value & " --> " & fprNew.VLine_NotAddToOutput.Value)
            fprOld.VLine_NotAddToOutput.Value = fprNew.VLine_NotAddToOutput.Value
        End If
        If fprOld.HalfScreenEnable.Value <> fprNew.HalfScreenEnable.Value Then
            dlm.WriteLog("< HalfScreenEnable >: " & fprOld.HalfScreenEnable.Value & " --> " & fprNew.HalfScreenEnable.Value)
            fprOld.HalfScreenEnable.Value = fprNew.HalfScreenEnable.Value
        End If

        '--- 第三頁(GSBDP) ---
        '--- GSBP ---
        If fprOld.BDPointRecipe.Threshold_GSBP.Value <> fprNew.BDPointRecipe.Threshold_GSBP.Value Then
            dlm.WriteLog("< Threshold_GSBP >: " & fprOld.BDPointRecipe.Threshold_GSBP.Value & " --> " & fprNew.BDPointRecipe.Threshold_GSBP.Value)
            fprOld.BDPointRecipe.Threshold_GSBP.Value = fprNew.BDPointRecipe.Threshold_GSBP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_GSBP.Value <> fprNew.BDPointRecipe.ThresholdRim_GSBP.Value Then
            dlm.WriteLog("< ThresholdRim_GSBP >: " & fprOld.BDPointRecipe.ThresholdRim_GSBP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_GSBP.Value)
            fprOld.BDPointRecipe.ThresholdRim_GSBP.Value = fprNew.BDPointRecipe.ThresholdRim_GSBP.Value
        End If

        If fprOld.AnalysisGSBP.Value <> fprNew.AnalysisGSBP.Value Then
            dlm.WriteLog("< AnalysisGSBP >: " & fprOld.AnalysisGSBP.Value & " --> " & fprNew.AnalysisGSBP.Value)
            fprOld.AnalysisGSBP.Value = fprNew.AnalysisGSBP.Value
        End If
        If fprOld.BDPointRecipe.AreaMax_GSBP.Value <> fprNew.BDPointRecipe.AreaMax_GSBP.Value Then
            dlm.WriteLog("< AreaMax_GSBP >: " & fprOld.BDPointRecipe.AreaMax_GSBP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_GSBP.Value)
            fprOld.BDPointRecipe.AreaMax_GSBP.Value = fprNew.BDPointRecipe.AreaMax_GSBP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_GSBP.Value <> fprNew.BDPointRecipe.AreaMin_GSBP.Value Then
            dlm.WriteLog("< AreaMin_GSBP >: " & fprOld.BDPointRecipe.AreaMin_GSBP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_GSBP.Value)
            fprOld.BDPointRecipe.AreaMin_GSBP.Value = fprNew.BDPointRecipe.AreaMin_GSBP.Value
        End If
        If fprOld.BDPointRecipe.GSBP_Count_Min.Value <> fprNew.BDPointRecipe.GSBP_Count_Min.Value Then
            dlm.WriteLog("< GSBP_Count_Min >: " & fprOld.BDPointRecipe.GSBP_Count_Min.Value & " --> " & fprNew.BDPointRecipe.GSBP_Count_Min.Value)
            fprOld.BDPointRecipe.GSBP_Count_Min.Value = fprNew.BDPointRecipe.GSBP_Count_Min.Value
        End If
        If fprOld.BDPointRecipe.GSBP_RangeX.Value <> fprNew.BDPointRecipe.GSBP_RangeX.Value Then
            dlm.WriteLog("< GSBP_RangeX >: " & fprOld.BDPointRecipe.GSBP_RangeX.Value & " --> " & fprNew.BDPointRecipe.GSBP_RangeX.Value)
            fprOld.BDPointRecipe.GSBP_RangeX.Value = fprNew.BDPointRecipe.GSBP_RangeX.Value
        End If
        If fprOld.BDPointRecipe.GSBP_RangeY.Value <> fprNew.BDPointRecipe.GSBP_RangeY.Value Then
            dlm.WriteLog("< GSBP_RangeY >: " & fprOld.BDPointRecipe.GSBP_RangeY.Value & " --> " & fprNew.BDPointRecipe.GSBP_RangeY.Value)
            fprOld.BDPointRecipe.GSBP_RangeY.Value = fprNew.BDPointRecipe.GSBP_RangeY.Value
        End If
        If fprOld.BDPointRecipe.GSBP_Scratch_Length.Value <> fprNew.BDPointRecipe.GSBP_Scratch_Length.Value Then
            dlm.WriteLog("< GSBP_Scratch_Length >: " & fprOld.BDPointRecipe.GSBP_Scratch_Length.Value & " --> " & fprNew.BDPointRecipe.GSBP_Scratch_Length.Value)
            fprOld.BDPointRecipe.GSBP_Scratch_Length.Value = fprNew.BDPointRecipe.GSBP_Scratch_Length.Value
        End If

        '--- BLDP ---
        If fprOld.BDPointRecipe.Threshold_BLDP.Value <> fprNew.BDPointRecipe.Threshold_BLDP.Value Then
            dlm.WriteLog("< Threshold_BLDP >: " & fprOld.BDPointRecipe.Threshold_BLDP.Value & " --> " & fprNew.BDPointRecipe.Threshold_BLDP.Value)
            fprOld.BDPointRecipe.Threshold_BLDP.Value = fprNew.BDPointRecipe.Threshold_BLDP.Value
        End If
        If fprOld.BDPointRecipe.ThresholdRim_BLDP.Value <> fprNew.BDPointRecipe.ThresholdRim_BLDP.Value Then
            dlm.WriteLog("< ThresholdRim_BLDP >: " & fprOld.BDPointRecipe.ThresholdRim_BLDP.Value & " --> " & fprNew.BDPointRecipe.ThresholdRim_BLDP.Value)
            fprOld.BDPointRecipe.ThresholdRim_BLDP.Value = fprNew.BDPointRecipe.ThresholdRim_BLDP.Value
        End If

        If fprOld.AnalysisBLDP.Value <> fprNew.AnalysisBLDP.Value Then
            dlm.WriteLog("< AnalysisBLDP >: " & fprOld.AnalysisBLDP.Value & " --> " & fprNew.AnalysisBLDP.Value)
            fprOld.AnalysisBLDP.Value = fprNew.AnalysisBLDP.Value
        End If
        If fprOld.BDPointRecipe.AreaMax_BLDP.Value <> fprNew.BDPointRecipe.AreaMax_BLDP.Value Then
            dlm.WriteLog("< AreaMax_BLDP >: " & fprOld.BDPointRecipe.AreaMax_BLDP.Value & " --> " & fprNew.BDPointRecipe.AreaMax_BLDP.Value)
            fprOld.BDPointRecipe.AreaMax_BLDP.Value = fprNew.BDPointRecipe.AreaMax_BLDP.Value
        End If
        If fprOld.BDPointRecipe.AreaMin_BLDP.Value <> fprNew.BDPointRecipe.AreaMin_BLDP.Value Then
            dlm.WriteLog("< AreaMin_BLDP >: " & fprOld.BDPointRecipe.AreaMin_BLDP.Value & " --> " & fprNew.BDPointRecipe.AreaMin_BLDP.Value)
            fprOld.BDPointRecipe.AreaMin_BLDP.Value = fprNew.BDPointRecipe.AreaMin_BLDP.Value
        End If
        If fprOld.BDPointRecipe.BLDP_Count_Min.Value <> fprNew.BDPointRecipe.BLDP_Count_Min.Value Then
            dlm.WriteLog("< BLDP_Count_Min >: " & fprOld.BDPointRecipe.BLDP_Count_Min.Value & " --> " & fprNew.BDPointRecipe.BLDP_Count_Min.Value)
            fprOld.BDPointRecipe.BLDP_Count_Min.Value = fprNew.BDPointRecipe.BLDP_Count_Min.Value
        End If
        If fprOld.BDPointRecipe.BLDP_RangeX.Value <> fprNew.BDPointRecipe.BLDP_RangeX.Value Then
            dlm.WriteLog("< BLDP_RangeX >: " & fprOld.BDPointRecipe.BLDP_RangeX.Value & " --> " & fprNew.BDPointRecipe.BLDP_RangeX.Value)
            fprOld.BDPointRecipe.BLDP_RangeX.Value = fprNew.BDPointRecipe.BLDP_RangeX.Value
        End If
        If fprOld.BDPointRecipe.BLDP_RangeY.Value <> fprNew.BDPointRecipe.BLDP_RangeY.Value Then
            dlm.WriteLog("< BLDP_RangeY >: " & fprOld.BDPointRecipe.BLDP_RangeY.Value & " --> " & fprNew.BDPointRecipe.BLDP_RangeY.Value)
            fprOld.BDPointRecipe.BLDP_RangeY.Value = fprNew.BDPointRecipe.BLDP_RangeY.Value
        End If
        If fprOld.BDPointRecipe.BLDP_Scratch_Length.Value <> fprNew.BDPointRecipe.BLDP_Scratch_Length.Value Then
            dlm.WriteLog("< BLDP_Scratch_Length >: " & fprOld.BDPointRecipe.BLDP_Scratch_Length.Value & " --> " & fprNew.BDPointRecipe.BLDP_Scratch_Length.Value)
            fprOld.BDPointRecipe.BLDP_Scratch_Length.Value = fprNew.BDPointRecipe.BLDP_Scratch_Length.Value
        End If
        If fprOld.BDPointRecipe.BLDP_Fatness_Min.Value <> fprNew.BDPointRecipe.BLDP_Fatness_Min.Value Then
            dlm.WriteLog("< BLDP_Fatness_Min >: " & fprOld.BDPointRecipe.BLDP_Fatness_Min.Value & " --> " & fprNew.BDPointRecipe.BLDP_Fatness_Min.Value)
            fprOld.BDPointRecipe.BLDP_Fatness_Min.Value = fprNew.BDPointRecipe.BLDP_Fatness_Min.Value
        End If

        '--- 第四頁 ---
        If fprOld.GrayAbnormalEnable.Value <> fprNew.GrayAbnormalEnable.Value Then
            dlm.WriteLog("< GrayAbnormalEnable >: " & fprOld.GrayAbnormalEnable.Value & " --> " & fprNew.GrayAbnormalEnable.Value)
            fprOld.GrayAbnormalEnable.Value = fprNew.GrayAbnormalEnable.Value
        End If
        If fprOld.DisplayMeanOffsetRecipe.PosLimit.Value <> fprNew.DisplayMeanOffsetRecipe.PosLimit.Value Then
            dlm.WriteLog("< GrayAbnormal PosLimit >: " & fprOld.DisplayMeanOffsetRecipe.PosLimit.Value & " --> " & fprNew.DisplayMeanOffsetRecipe.PosLimit.Value)
            fprOld.DisplayMeanOffsetRecipe.PosLimit = fprNew.DisplayMeanOffsetRecipe.PosLimit
        End If
        If fprOld.DisplayMeanOffsetRecipe.NegLimit.Value <> fprNew.DisplayMeanOffsetRecipe.NegLimit.Value Then   '2009/09/21 Rick add
            dlm.WriteLog("< GrayAbnormal NegLimit >: " & fprOld.DisplayMeanOffsetRecipe.NegLimit.Value & " --> " & fprNew.DisplayMeanOffsetRecipe.NegLimit.Value)
            fprOld.DisplayMeanOffsetRecipe.NegLimit = fprNew.DisplayMeanOffsetRecipe.NegLimit
        End If
        If fprOld.DisplayMeanOffsetRecipe.StandardGray.Value <> fprNew.DisplayMeanOffsetRecipe.StandardGray.Value Then
            dlm.WriteLog("< GrayAbnormal StandardGray >: " & fprOld.DisplayMeanOffsetRecipe.StandardGray.Value & " --> " & fprNew.DisplayMeanOffsetRecipe.StandardGray.Value)
            fprOld.DisplayMeanOffsetRecipe.StandardGray = fprNew.DisplayMeanOffsetRecipe.StandardGray
        End If

        '--- 第五頁 ---
        If fprOld.AutoExposure_Kp.Value <> fprNew.AutoExposure_Kp.Value Then
            dlm.WriteLog("< AutoExposure_Kp >: " & fprOld.AutoExposure_Kp.Value & " --> " & fprNew.AutoExposure_Kp.Value)
            fprOld.AutoExposure_Kp.Value = fprNew.AutoExposure_Kp.Value
        End If
        If fprOld.AutoExposure_LargeErrorRange_UL.Value <> fprNew.AutoExposure_LargeErrorRange_UL.Value Then
            dlm.WriteLog("< AutoExposure_LargeErrorRange_UL >: " & fprOld.AutoExposure_LargeErrorRange_UL.Value & " --> " & fprNew.AutoExposure_LargeErrorRange_UL.Value)
            fprOld.AutoExposure_LargeErrorRange_UL.Value = fprNew.AutoExposure_LargeErrorRange_UL.Value
        End If
        If fprOld.AutoExposure_LargeErrorRange_DL.Value <> fprNew.AutoExposure_LargeErrorRange_DL.Value Then
            dlm.WriteLog("< AutoExposure_LargeErrorRange_DL >: " & fprOld.AutoExposure_LargeErrorRange_DL.Value & " --> " & fprNew.AutoExposure_LargeErrorRange_DL.Value)
            fprOld.AutoExposure_LargeErrorRange_DL.Value = fprNew.AutoExposure_LargeErrorRange_DL.Value
        End If
        If fprOld.AutoExposure_SmallErrorRange.Value <> fprNew.AutoExposure_SmallErrorRange.Value Then
            dlm.WriteLog("< AutoExposure_SmallErrorRange >: " & fprOld.AutoExposure_SmallErrorRange.Value & " --> " & fprNew.AutoExposure_SmallErrorRange.Value)
            fprOld.AutoExposure_SmallErrorRange.Value = fprNew.AutoExposure_SmallErrorRange.Value
        End If
        If fprOld.AutoExposure_TargetMean.Value <> fprNew.AutoExposure_TargetMean.Value Then
            dlm.WriteLog("< AutoExposure_TargetMean >: " & fprOld.AutoExposure_TargetMean.Value & " --> " & fprNew.AutoExposure_TargetMean.Value)
            fprOld.AutoExposure_TargetMean.Value = fprNew.AutoExposure_TargetMean.Value
        End If

        '--- 第六頁 ---
        If fprOld.PointAlgorithm.Value <> fprOld.PointAlgorithm.Value Then
            dlm.WriteLog("< Point Algorithm >: " & fprOld.PointAlgorithm.Value & " --> " & fprOld.PointAlgorithm.Value)
            fprOld.PointAlgorithm.Value = fprOld.PointAlgorithm.Value
        End If

    End Sub

    Private Sub Compare(ByVal fmrOld As ClsFuncModelRecipe, ByVal fmrNew As ClsFuncModelRecipe, ByVal dlm As AUO.LogRecorder.CLogRecorder)
        dlm.WriteLog("********************[FuncModelRecipe]************************")
        dlm.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

        '--- 第五頁 ---
        If fmrOld.Point_PitchX.Value <> fmrNew.Point_PitchX.Value Then
            dlm.WriteLog("< Point Pitch X >: " & fmrOld.Point_PitchX.Value & " --> " & fmrNew.Point_PitchX.Value)
            fmrOld.Point_PitchX.Value = fmrNew.Point_PitchX.Value
        End If
        If fmrOld.Point_PitchY.Value <> fmrNew.Point_PitchY.Value Then
            dlm.WriteLog("< Point Pitch Y >: " & fmrOld.Point_PitchY.Value & " --> " & fmrNew.Point_PitchY.Value)
            fmrOld.Point_PitchY.Value = fmrNew.Point_PitchY.Value
        End If
        If fmrOld.Line_PitchX.Value <> fmrNew.Line_PitchX.Value Then
            dlm.WriteLog("< Line Pitch X >: " & fmrOld.Line_PitchX.Value & " --> " & fmrNew.Line_PitchX.Value)
            fmrOld.Line_PitchX.Value = fmrNew.Line_PitchX.Value
        End If
        If fmrOld.Line_PitchY.Value <> fmrNew.Line_PitchY.Value Then
            dlm.WriteLog("< Line Pitch Y >: " & fmrOld.Line_PitchY.Value & " --> " & fmrNew.Line_PitchY.Value)
            fmrOld.Line_PitchY.Value = fmrNew.Line_PitchY.Value
        End If
        If fmrOld.Average_Filter.Value <> fmrNew.Average_Filter.Value Then
            dlm.WriteLog("< Average_Filter >: " & fmrOld.Average_Filter.Value & " --> " & fmrNew.Average_Filter.Value)
            fmrOld.Average_Filter.Value = fmrNew.Average_Filter.Value
        End If

        If fmrOld.FuncRawDataFilterMura_Enable.Value <> fmrNew.FuncRawDataFilterMura_Enable.Value Then
            dlm.WriteLog("< FuncRawDataFilterMura_Enable >: " & fmrOld.FuncRawDataFilterMura_Enable.Value & " --> " & fmrNew.FuncRawDataFilterMura_Enable.Value)
            fmrOld.FuncRawDataFilterMura_Enable.Value = fmrNew.FuncRawDataFilterMura_Enable.Value
        End If
    End Sub

#End Region

#End Region

#Region "--- Event ---"
    Private Sub CheckBox_Point_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim fpr As ClsFuncPatternRecipe

        Me.CheckPattern()
        fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
        fpr.PointEnable.Value = Me.m_Form.CheckBox_Point_Enable.Checked

        Me.m_Form.GroupBox_PointMode.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked
        Me.m_Form.CheckBox_Align_Enable.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked
        'Me.m_Form.GroupBox_SeparateBP.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked
        'Me.m_Form.CheckBox_Report_Multi_Pixel.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked
        'Me.m_Form.CheckBox_Waku_Inspect_Enable.Enabled = Me.m_Form.CheckBox_Point_Enable.Checked

        If Me.m_Form.CheckBox_Point_Enable.Checked Then
            Me.m_Form.GroupBox_PointCommonSetting.Enabled = True
            If Me.m_Form.RadioButton_BP.Checked Then
                Me.m_Form.GroupBox_BPoint.Enabled = True
                Me.m_Form.GroupBox_DPoint.Enabled = False
                fpr.AnalysisBP.Value = True
                fpr.AnalysisDP.Value = False
            End If
            If Me.m_Form.RadioButton_DP.Checked Then
                Me.m_Form.GroupBox_BPoint.Enabled = False
                Me.m_Form.GroupBox_DPoint.Enabled = True
                fpr.AnalysisDP.Value = True
                fpr.AnalysisBP.Value = False
            End If
            If Me.m_Form.RadioButton_BPDP.Checked = True Then
                Me.m_Form.GroupBox_BPoint.Enabled = True
                Me.m_Form.GroupBox_DPoint.Enabled = True
                fpr.AnalysisBP.Value = True
                fpr.AnalysisDP.Value = True
            End If
            Me.m_Form.GroupBox_PointPitchSetting.Enabled = True
        Else
            Me.m_Form.GroupBox_PointCommonSetting.Enabled = False
            Me.m_Form.GroupBox_BPoint.Enabled = False
            Me.m_Form.GroupBox_DPoint.Enabled = False
            Me.m_Form.GroupBox_PointPitchSetting.Enabled = False
        End If

        If Me.m_Form.CheckBox_Line_Enable.Checked OrElse Me.m_Form.CheckBox_Point_Enable.Checked Then
            Me.m_Form.GroupBox_ImgProcBoundary.Enabled = True
            Me.m_Form.GroupBox_LineAverageFilter.Enabled = True
        Else
            Me.m_Form.GroupBox_ImgProcBoundary.Enabled = False
            Me.m_Form.GroupBox_LineAverageFilter.Enabled = False
        End If

    End Sub
    Private Sub CheckBox_BLine_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs)
        If Me.m_Form.CheckBox_Line_Enable.Checked Then
            Me.m_Form.GroupBox_BLine.Enabled = Me.m_Form.CheckBox_BLine_Enable.Checked
        Else
            Me.m_Form.GroupBox_BLine.Enabled = False
        End If
    End Sub
    Private Sub CheckBox_DLine_Enable_CheckedChanged(sender As System.Object, e As System.EventArgs)
        If Me.m_Form.CheckBox_Line_Enable.Checked Then
            Me.m_Form.GroupBox_DLine.Enabled = Me.m_Form.CheckBox_DLine_Enable.Checked
        Else
            Me.m_Form.GroupBox_DLine.Enabled = False
        End If
    End Sub
    Private Sub CheckBox_Line_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Me.CheckPattern()
        Me.m_Form.GroupBox_LinePitchSetting.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
        Me.m_FuncProcess.CurrentFuncPatternRecipe.LineEnable.Value = Me.m_Form.CheckBox_Line_Enable.Checked

        Me.m_Form.CheckBox_BLine_Enable.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
        Me.m_Form.CheckBox_DLine_Enable.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
        Me.m_Form.GroupBox_LineCommonSetting.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
        'Me.m_Form.CheckBox_HalfScreen_Enable.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked

        Me.m_Form.CheckBox_HLine_NotAddToOutput.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
        Me.m_Form.CheckBox_VLine_NotAddToOutput.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
        'Me.m_Form.CheckBox_Filter_VH_Scratch.Enabled = Me.m_Form.CheckBox_Line_Enable.Checked
        'If Me.m_Form.CheckBox_Line_Enable.Checked = False Then Me.m_Form.Me.CheckBox_HLine_NotAddToOutput.Checked = False

        'UI-Param Setting
        If Me.m_Form.CheckBox_Line_Enable.Checked Then
            Me.m_Form.GroupBox_BLine.Enabled = Me.m_Form.CheckBox_BLine_Enable.Checked
            Me.m_Form.GroupBox_DLine.Enabled = Me.m_Form.CheckBox_DLine_Enable.Checked
        Else
            Me.m_Form.GroupBox_BLine.Enabled = False
            Me.m_Form.GroupBox_DLine.Enabled = False
        End If

        If Me.m_Form.CheckBox_Line_Enable.Checked OrElse Me.m_Form.CheckBox_Point_Enable.Checked Then
            Me.m_Form.GroupBox_ImgProcBoundary.Enabled = True
            Me.m_Form.GroupBox_LineAverageFilter.Enabled = True
        Else
            Me.m_Form.GroupBox_ImgProcBoundary.Enabled = False
            Me.m_Form.GroupBox_LineAverageFilter.Enabled = False
        End If

    End Sub
    Private Sub CheckBox_GrayAbnormal_Enable_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.CheckPattern()
        Me.m_FuncProcess.CurrentFuncPatternRecipe.GrayAbnormalEnable.Value = Me.m_Form.CheckBox_GrayAbnormal_Enable.Checked
        Me.m_Form.GroupBox_GrayAbnormal.Enabled = Me.m_Form.CheckBox_GrayAbnormal_Enable.Checked
    End Sub


    Private Sub TreeView_Pattern_AfterSelect(sender As System.Object, e As System.Windows.Forms.TreeViewEventArgs)
        Dim PatternName As String
        Dim Parameter_Lists As String = ""
        Dim Request_Command As String
        Dim TimeOut As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult

        Try
            '--- Button Control ---   
            Button_Enable(False)

            '--- 建立連線 ---
            If Me.ConnectToIP = False Then
                '--- Button Control ---   
                Button_Enable(True)
                Exit Sub
            End If

            Try
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Index + Me.m_MuraProcess.MuraPatternRecipeArray.Count
                Me.UpdateData()
                'Me.UpdateUserLevel()
            Catch ex As Exception
                Button_Enable(True)
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message)
                MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                TimeOut = 300000 '300 secs

                '--- PatternName ---
                PatternName = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Button_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

                Button_Enable(True)
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_FUNCSETTING_SETTING"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------

                '--- Other ---
                If Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text <> "" Then
                    Parameter_Lists = Parameter_Lists & "PatternName," & Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text & ";"
                End If

                '--- 第一頁 ---
                Parameter_Lists = "BPDP," & Me.m_Form.RadioButton_BPDP.Checked & ";" & "BP," & Me.m_Form.RadioButton_BP.Checked & ";" & "DP," & Me.m_Form.RadioButton_DP.Checked & ";"

                'If Me.m_Form.RadioButton_PointAlgorithm_0.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_0," & Me.m_Form.RadioButton_PointAlgorithm_0.Checked & ";"
                'ElseIf Me.m_Form.RadioButton_PointAlgorithm_1.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_1," & Me.m_Form.RadioButton_PointAlgorithm_1.Checked & ";"
                'ElseIf Me.m_Form.RadioButton_PointAlgorithm_2.Checked Then 'v2012.09.05
                'Parameter_Lists = Parameter_Lists & "PointAlgorithm_2," & Me.m_Form.RadioButton_PointAlgorithm_2.Checked & ";"
                'ElseIf Me.m_Form.RadioButton_PointAlgorithm_3.Checked Then
                Parameter_Lists = Parameter_Lists & "PointAlgorithm_3," & Me.m_Form.RadioButton_PointAlgorithm_3.Checked & ";"
                'ElseIf Me.m_Form.RadioButton_PointAlgorithm_4.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_4," & Me.m_Form.RadioButton_PointAlgorithm_4.Checked & ";"
                'ElseIf Me.m_Form.RadioButton_PointAlgorithm_5.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_5," & Me.m_Form.RadioButton_PointAlgorithm_5.Checked & ";"
                'ElseIf Me.m_Form.RadioButton_PointAlgorithm_6.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_6," & Me.m_Form.RadioButton_PointAlgorithm_6.Checked & ";"
                'End If

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '--- Button Control ---   
            Button_Enable(True)
        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & ex.Message)
            MessageBox.Show("[Dialog_FuncSetting.ComboBox_Pattern_SelectedIndexChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            Me.m_Form.Panel_FuncParam.Focus()
        End Try
    End Sub
    Private Sub Button_SaveFuncParam_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.ComboBox_CCD.SelectedIndex = -1 Then
            MessageBox.Show("[Dialog_FuncSetting.Button_Save]請先選擇 IP No , 才能進行儲存", "警告", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        Me.m_Form.PaintStop = True

        If MsgBox("是否儲存Recipe參數？", MsgBoxStyle.OkCancel, "[ IP" & Me.m_MainProcess.CCDNo & " ]") = MsgBoxResult.Cancel Then
            Exit Sub
        End If

        Dim i As Integer
        Dim dir As String
        Dim strs() As String = {""}
        Dim str As String
        Dim Parameter_Lists As String = ""

        Dim Request_Command As String
        Dim TimeOut As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        'Dim strPath As String

        Try
            '--- 建立連線 ---
            If Not Me.ConnectToIP Then
                Exit Sub
            End If

            '--- Button Control ---   
            Button_Enable(False)

            Me.Setting()
            '----------------------------------------------------------------------------------------------
            ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "DIALOG_FUNCSETTING_SETTING"
                TimeOut = 100000 '100 secs

                'UI Recipe Setting -----------------------------------
                '--- Func Pattern Recipe --- 20191126
                Dim fpr As ClsFuncPatternRecipe = Me.m_FuncProcess.CurrentFuncPatternRecipe
                Dim fmr As ClsFuncModelRecipe = Me.m_FuncProcess.FuncModelRecipe
                Dim pmmr As ClsPLMarkModelRecipe = Me.m_FuncProcess.PLMarkModelRecipe

                'Other ---
                If Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text <> "" Then
                    Parameter_Lists = Parameter_Lists & "PatternName," & Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text & ";"
                End If

                '--- 第一頁(Point) ---
                Parameter_Lists = "BP_Threshold," & Me.m_Form.NumericUpDown_BP_Threshold.Value & ";" & "BP_Threshold_Low," & Me.m_Form.NumericUpDown_BP_Threshold_Low.Value & ";" & "BP_RimThreshold," & Me.m_Form.NumericUpDown_BP_RimThreshold.Value & ";" & "BP_RimThreshold_Low," & Me.m_Form.NumericUpDown_BP_RimThreshold_Low.Value & ";" & _
                                  "DP_Threshold," & Me.m_Form.NumericUpDown_DP_Threshold.Value & ";" & "DP_Threshold_Low," & Me.m_Form.NumericUpDown_DP_Threshold_Low.Value & ";" & "DP_RimThreshold," & Me.m_Form.NumericUpDown_DP_RimThreshold.Value & ";" & "DP_RimThreshold_Low," & Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Value & ";" & _
                                  "BPDP," & Me.m_Form.RadioButton_BPDP.Checked & ";" & "BP," & Me.m_Form.RadioButton_BP.Checked & ";" & "DP," & Me.m_Form.RadioButton_DP.Checked & ";" & _
                                  "BP_AreaMax," & Me.m_Form.NumericUpDown_BP_AreaMax.Value & ";" & "BP_AreaMin," & Me.m_Form.NumericUpDown_BP_AreaMin.Value & ";" & "DP_AreaMax," & Me.m_Form.NumericUpDown_DP_AreaMax.Value & ";" & "DP_AreaMin," & Me.m_Form.NumericUpDown_DP_AreaMin.Value & ";" & _
                                  "Point_ByPassX," & Me.m_Form.NumericUpDown_Point_ByPassX.Value & ";" & "Point_ByPassY," & Me.m_Form.NumericUpDown_Point_ByPassY.Value & ";" & "Point_OverNum," & Me.m_Form.NumericUpDown_Point_OverNum.Value & ";" & "Report_Multi_Pixel," & fpr.Report_Multi_Pixel.Value & ";" & "Align_Enable," & Me.m_Form.CheckBox_Align_Enable.Checked & ";" & _
                                  "Point_Enable," & Me.m_Form.CheckBox_Point_Enable.Checked & ";" & "Inverse_Point_DefectType," & fpr.BDPointRecipe.Inverse_PointDefectType.Value & ";" & "Inverse_Point_EnableFixArea," & fpr.BDPointRecipe.Inverse_Point_EnableFixArea.Value & ";" & _
                                  "Inverse_Point_FixArea," & fpr.BDPointRecipe.Inverse_PointFixArea.Value & ";" & "CPDEnable," & fpr.CPDEnable.Value & ";" & _
                                  "SeparateBPEnable," & fpr.SeparateBPEnable.Value & ";" & "SeparateBPArea," & fpr.SeparateBPArea.Value & ";" & "SeparateBPBlob," & fpr.SeparateBPBlob.Value & ";" & _
                                  "EnableLeakPoint," & fpr.BDPointRecipe.EnableLeakPoint.Value & ";" & "Waku_Inspect_Enable," & fpr.WakuInspectEnable.Value & ";" & "WakuSplitNum," & fpr.WakuSplitNum.Value & ";" & "WakuEdgeWidth," & fpr.WakuEdgeWidth.Value & ";" & "WakuEdgeOffset," & fpr.WakuEdgeOffset.Value & ";" & _
                                  "Top_Waku_Value_Min," & fpr.TopWakuValueMin.Value & ";" & "Top_Waku_Value_Max," & fpr.TopWakuValueMax.Value & ";" & "Bottom_Waku_Value_Min," & fpr.BottomWakuValueMin.Value & ";" & "Bottom_Waku_Value_Max," & fpr.BottomWakuValueMax.Value & ";" & _
                                  "Left_Waku_Value_Min," & fpr.LeftWakuValueMin.Value & ";" & "Left_Waku_Value_Max," & fpr.LeftWakuValueMax.Value & ";" & "Right_Waku_Value_Min," & fpr.RightWakuValueMin.Value & ";" & "Right_Waku_Value_Max," & fpr.RightWakuValueMax.Value & ";"

                '--- 第二頁(Point Char.) ---
                Parameter_Lists = Parameter_Lists & "BP_Elongation_Min," & fpr.BDPointRecipe.Elongation_Min.Value & ";" & "BP_Elongation_Max," & fpr.BDPointRecipe.Elongation_Max.Value & ";" & "BP_Fullness_Min," & fpr.BDPointRecipe.Fullness_Min.Value & ";" & "BP_Fullness_Max," & fpr.BDPointRecipe.Fullness_Max.Value & ";" & "BP_MaxGray_Fullness_Min," & fpr.BDPointRecipe.MaxGray_Fullness_Min.Value & ";" & _
                                                    "DP_Elongation_Min," & fpr.BDPointRecipe.Elongation_Min_DP.Value & ";" & "DP_Elongation_Max," & fpr.BDPointRecipe.Elongation_Max_DP.Value & ";" & "DP_Fullness_Min," & fpr.BDPointRecipe.Fullness_Min_DP.Value & ";" & "DP_Fullness_Max," & fpr.BDPointRecipe.Fullness_Max_DP.Value & ";" & "DP_MaxGray_Fullness_Min," & fpr.BDPointRecipe.MaxGray_Fullness_Min_DP.Value & ";" & _
                                                    "DP_GrayMean_Max," & fpr.BDPointRecipe.GrayMean_Max_DP.Value & ";" & "DP_MinGray_Min," & fpr.BDPointRecipe.MinGray_Min_DP.Value & ";" & "DP_MinGray_Max," & fpr.BDPointRecipe.MinGray_Max_DP.Value & ";" & "DP_StdDev_Max," & fpr.BDPointRecipe.StdDev_Max_DP.Value & ";" & _
                                                    "BP_GrayMean_Min," & fpr.BDPointRecipe.GrayMean_Min_BP.Value & ";" & "BP_MaxGray_Min," & fpr.BDPointRecipe.MaxGray_Min_BP.Value & ";" & "BP_MaxGray_Max," & fpr.BDPointRecipe.MaxGray_Max_BP.Value & ";" & "BP_StdDev_Max," & fpr.BDPointRecipe.StdDev_Max_BP.Value & ";" & "BP_Compactness_Max," & fpr.BDPointRecipe.Compactness_Max_BP.Value & ";" & "DP_Compactness_Max," & fpr.BDPointRecipe.Compactness_Max_DP.Value & ";"

                '--- 第三頁(GSBDP) ---
                Parameter_Lists = Parameter_Lists & "GSBP_Enable," & fpr.AnalysisGSBP.Value & ";" & "GSBP_Threshold," & fpr.BDPointRecipe.Threshold_GSBP.Value & ";" & "GSBP_ThresholdRim," & fpr.BDPointRecipe.ThresholdRim_GSBP.Value & ";" & _
                                                    "GSBP_AreaMax," & fpr.BDPointRecipe.AreaMax_GSBP.Value & ";" & "GSBP_AreaMin," & fpr.BDPointRecipe.AreaMin_GSBP.Value & ";" & "GSBP_Count_Min," & fpr.BDPointRecipe.GSBP_Count_Min.Value & ";" & _
                                                    "GSBP_RangeX," & fpr.BDPointRecipe.GSBP_RangeX.Value & ";" & "GSBP_RangeY," & fpr.BDPointRecipe.GSBP_RangeY.Value & ";" & "GSBP_Scratch_Length," & fpr.BDPointRecipe.GSBP_Scratch_Length.Value & ";" & "GSBP_OverNum," & fpr.BDPointRecipe.GSBP_OverNum.Value & ";" & "GSBP_NumOfHoles," & fpr.BDPointRecipe.GSBP_NumOfHoles.Value & ";" & "GSBP_GrayMax_High," & fpr.BDPointRecipe.GSBP_GrayMax_High.Value & ";" & "GSBP_GrayMax_Low," & fpr.BDPointRecipe.GSBP_GrayMax_Low.Value & ";"

                Parameter_Lists = Parameter_Lists & "BLDP_Enable," & fpr.AnalysisBLDP.Value & ";" & "BLDP_Threshold," & fpr.BDPointRecipe.Threshold_BLDP.Value & ";" & "BLDP_ThresholdRim," & fpr.BDPointRecipe.ThresholdRim_BLDP.Value & ";" & "BLDP_EnhanceCount," & fpr.BDPointRecipe.EnhanceCount_BLDP.Value & ";" & _
                                                    "BLDP_AreaMax," & fpr.BDPointRecipe.AreaMax_BLDP.Value & ";" & "BLDP_AreaMin," & fpr.BDPointRecipe.AreaMin_BLDP.Value & ";" & "BLDP_Count_Min," & fpr.BDPointRecipe.BLDP_Count_Min.Value & ";" & _
                                                    "BLDP_RangeX," & fpr.BDPointRecipe.BLDP_RangeX.Value & ";" & "BLDP_RangeY," & fpr.BDPointRecipe.BLDP_RangeY.Value & ";" & "BLDP_Scratch_Length," & fpr.BDPointRecipe.BLDP_Scratch_Length.Value & ";" & "BLDP_OverNum," & fpr.BDPointRecipe.BLDP_OverNum.Value & ";" & "BLDP_Fatness_Min," & fpr.BDPointRecipe.BLDP_Fatness_Min.Value & ";" & _
                                                    "BLDP_Elongation_Min," & fpr.BDPointRecipe.Elongation_Min_BLDP.Value & ";" & "BLDP_Elongation_Max," & fpr.BDPointRecipe.Elongation_Max_BLDP.Value & ";"

                '--- 第三頁(Line) ---
                Parameter_Lists = Parameter_Lists & "DL_Threshold," & fpr.LineFinderRecipe.Threshold_DL.Value & ";" & "BL_Threshold," & fpr.LineFinderRecipe.Threshold_BL.Value & ";" & "DL_RimThreshold," & fpr.LineFinderRecipe.ThresholdRim_DL.Value & ";" & "BL_RimThreshold," & fpr.LineFinderRecipe.ThresholdRim_BL.Value & ";" & _
                                                    "Line_ByPassUpH," & fpr.LineFinderRecipe.ByPassUpH.Value & ";" & "Line_ByPassDownH," & fpr.LineFinderRecipe.ByPassDownH.Value & ";" & "Line_ByPassLeftV," & fpr.LineFinderRecipe.ByPassLeftV.Value & ";" & "Line_ByPassRightV," & fpr.LineFinderRecipe.ByPassRightV.Value & ";" & _
                                                    "Line_Cut," & fpr.LineFinderRecipe.Line_Cut.Value & ";" & "Line_Short_Cut," & fpr.LineFinderRecipe.Line_Short_Cut.Value & ";" & "Line_Cut_H," & fpr.LineFinderRecipe.Line_Cut_H.Value & ";" & "Line_Short_Cut_H," & fpr.LineFinderRecipe.Line_Short_Cut_H.Value & ";" & _
                                                    "Line_OverNumber," & fpr.LineFinderRecipe.LineOverNum.Value & ";" & "Block_OverNumber," & fpr.LineFinderRecipe.BlockOverNum.Value & ";" & _
                                                    "MeanDifference," & fpr.LineFinderRecipe.Mean_Difference.Value & ";" & "Line_Enable," & fpr.LineEnable.Value & ";" & _
                                                    "HLine_NotAddToOutput," & fpr.HLine_NotAddToOutput.Value & ";" & "VLine_NotAddToOutput," & fpr.VLine_NotAddToOutput.Value & ";" & "Filter_VH_Scratch," & fpr.Filter_VH_Scratch.Value & ";" & _
                                                    "HalfScreen_Enable," & fpr.HalfScreenEnable.Value & ";" & "LeakPointRadius," & fpr.LineFinderRecipe.LeakPointRadius.Value & ";"
                Parameter_Lists = Parameter_Lists & "BL," & fpr.LineFinderRecipe.AnalysisBL.Value & ";" & "DL," & fpr.LineFinderRecipe.AnalysisDL.Value & ";"

                '--- 第四頁(Abnormal) ---
                Parameter_Lists = Parameter_Lists & "GrayAbnormal_PosLimit," & fpr.DisplayMeanOffsetRecipe.PosLimit.Value & ";" & "GrayAbnormal_NegLimit," & fpr.DisplayMeanOffsetRecipe.NegLimit.Value & ";" & _
                                                    "GrayAbnormalStandardGray," & fpr.DisplayMeanOffsetRecipe.StandardGray.Value & ";" & "GrayAbnormal_NoDisplay," & fpr.DisplayMeanOffsetRecipe.NoDisplay.Value & ";" & _
                                                    "GrayAbnormal_Enable," & fpr.GrayAbnormalEnable.Value & ";"

                '--- 第五頁(Auto) ---
                Parameter_Lists = Parameter_Lists & "AutoExposure_Kp," & fpr.AutoExposure_Kp.Value & ";" & "AutoExposure_TargetMean," & fpr.AutoExposure_TargetMean.Value & ";" & _
                                                    "AutoExposure_LargeErrorRange_UL," & fpr.AutoExposure_LargeErrorRange_UL.Value & ";" & "AutoExposure_LargeErrorRange_DL," & fpr.AutoExposure_LargeErrorRange_DL.Value & ";" & _
                                                    "AutoExposure_SmallErrorRange," & fpr.AutoExposure_SmallErrorRange.Value & ";" & _
                                                    "AutoExposure_GrabDelayTime," & fpr.AutoExposure_GrabDelayTime.Value & ";"

                '--- 第六頁 ---
                Parameter_Lists = Parameter_Lists & "Point_PitchX," & fpr.Point_PitchX.Value & ";" & "Point_PitchY," & fpr.Point_PitchY.Value & ";" & _
                                                    "FuncRawDataFilterMura_Enable," & fmr.FuncRawDataFilterMura_Enable.Value & ";" & _
                                                    "Line_PitchX," & fpr.Line_PitchX.Value & ";" & "Line_PitchY," & fpr.Line_PitchY.Value & ";" & "AverageFilter," & fpr.Average_Filter.Value & ";" & _
                                                    "Boundary_MulWidth_LX," & fpr.Boundary_MulWidth_LX.Value & ";" & "Boundary_MulWidth_TY," & fpr.Boundary_MulWidth_TY.Value & ";" & _
                                                    "Boundary_MulWidth_RX," & fpr.Boundary_MulWidth_RX.Value & ";" & "Boundary_MulWidth_BY," & fpr.Boundary_MulWidth_BY.Value & ";" & _
                                                    "AiResizeX," & fmr.AiResizeX.Value & ";" & "AiResizeY," & fmr.AiResizeY.Value & ";" & "IsAISaveROI," & fmr.IsAISaveROI.Value & ";"

                '--- 第七頁 ---
                If Me.m_IPBootConfig.PLMarkUI.Value Then
                    Parameter_Lists = Parameter_Lists & "FillOfHole," & pmmr.FillofHole & ";" & _
                                                        "PLMark_Enable," & fpr.PLMarkEnable.Value & ";" & "SearchRange_PLMark_Multiple," & pmmr.SearchRange_PLMark_Multiple & ";" & _
                                                        "SearchMarkCount," & pmmr.SearchMarkCount & ";" & _
                                                        "PLMark_Blacking," & ";" & "PLMark_Variation," & ";"
                End If

                '--- 第八頁 ---
                Parameter_Lists = Parameter_Lists & "HotPixelEnable," & fpr.HotPixelEnable.Value & ";" & "HotPixelRecipe," & fpr.HotPixelRecipe.Value & ";" & _
                                                    "HotPixelFilterDistance," & fpr.HotPixelFilterDistance.Value & ";" & "HotPixelMaxMean," & fpr.HotPixelMaxMean.Value & ";" & _
                                                    "Filter_HotPixel_With_Characteristics," & fpr.Filter_HotPixel_With_Characteristics_Enable.Value & ";"

                '--- 第九頁 ---
                If Me.m_IPBootConfig.TPMarkUI.Value Then
                    Parameter_Lists = Parameter_Lists & "TPMark_Enable," & fpr.TPMarkEnable.Value & ";"
                End If

                'If Me.RadioButton_PointAlgorithm_0.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_0," & Me.RadioButton_PointAlgorithm_0.Checked & ";"
                'ElseIf Me.RadioButton_PointAlgorithm_1.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_1," & Me.RadioButton_PointAlgorithm_1.Checked & ";"
                'ElseIf Me.RadioButton_PointAlgorithm_2.Checked Then 'v2012.09.05
                'Parameter_Lists = Parameter_Lists & "PointAlgorithm_2," & Me.m_Form.RadioButton_PointAlgorithm_2.Checked & ";"
                'ElseIf Me.RadioButton_PointAlgorithm_3.Checked Then
                Parameter_Lists = Parameter_Lists & "PointAlgorithm_3," & Me.m_Form.RadioButton_PointAlgorithm_3.Checked & ";"
                'ElseIf Me.RadioButton_PointAlgorithm_4.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_4," & Me.RadioButton_PointAlgorithm_4.Checked & ";"
                'ElseIf Me.RadioButton_PointAlgorithm_5.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_5," & Me.RadioButton_PointAlgorithm_5.Checked & ";"
                'ElseIf Me.RadioButton_PointAlgorithm_6.Checked Then
                '    Parameter_Lists = Parameter_Lists & "PointAlgorithm_6," & Me.RadioButton_PointAlgorithm_6.Checked & ";"
                'End If

                'End UI Recipe Setting -----------------------------------

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            dir = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
            If Directory.Exists(dir) = False Then
                Directory.CreateDirectory(dir)
            End If
            str = dir & "\FuncPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & Me.m_FuncProcess.Pattern & ".xml"

            If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                i = Me.m_MainProcess.FuncPatternRecipeArrayOrder.IndexOf(Me.m_FuncProcess.CurrentFuncPatternRecipe)
                If i >= 0 Then
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("**************************[FuncSave]******************************")
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[ClsFuncPatternRecipe] 目前 Model：" & Me.m_Form.GetProductNameInfo & " ; 目前 Pattern: " & Me.m_Form.ComboBox_Pattern_MainFrm.Text)
                    Me.Compare(Me.m_MainProcess.FuncPatternRecipeArrayTemp.Item(i), Me.m_FuncProcess.CurrentFuncPatternRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                    Me.m_FuncProcess.SaveCurrentFuncPatternRecipe(str, Me.m_MainProcess.ErrorCode)
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern 存檔]: " & str)
                Else
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("PatternAdd: " & Me.m_FuncProcess.Pattern)
                End If
                Me.Compare(Me.m_MainProcess.FuncModelRecipeTemp, Me.m_FuncProcess.FuncModelRecipe, Me.m_MainProcess.RecipeDailyLogManager)
                Me.m_FuncProcess.SaveFuncModelRecipe(dir, Me.m_MainProcess.GrabNo, Me.m_MainProcess.ErrorCode)
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Model 存檔]: " & dir & "\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml")
            End If

            '----------------------------------------------------------------------------------------------
            ' Save Current Func Pattern Recipe  ==> Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_CURRENT_FUNCPATTERN_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, str, , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Current Func Pattern Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.m_Form.Button_SaveFuncParam.Enabled = True
                    Button_Enable(True)
                    Exit Sub
                End If

            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save Func Model Recipe  ==> Request_Command = "SAVE_FUNC_MODEL_RECIPE" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_FUNC_MODEL_RECIPE"
                TimeOut = 100000 '100 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save Func Model Recipe Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            '----------------------------------------------------------------------------------------------
            ' Save MappingTable Recipe  ==> Request_Command = "SAVE_MAPPINGTABLE_RECIPE" (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SAVE_MAPPINGTABLE_RECIPE"
                TimeOut = 200000 '200 secs

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save MappingTable Recipe Error !, " & CStr(Me.m_MainProcess.ErrorCode))
                    MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Me.Button_Enable(True)
                    Exit Sub
                End If
            Catch ex As Exception
                Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try

            If (Me.m_IPBootConfig.PLMarkUI.Value) Then
                '----------------------------------------------------------------------------------------------
                ' Save PL Mark Model Recipe ==> Request_Command = "SAVE_PLMARK_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    'Prepare Command ---
                    Request_Command = "SAVE_PLMARK_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        'Enable Button ---   
                        'Me.Button_PLMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save PL Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    'Enable Button ---  
                    'Me.Button_PLMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.PLMark_Setting]Save PL Mark Model Recipe Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.PLMark_Setting][SAVE_PLMARK_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If

            If (Me.m_IPBootConfig.TPMarkUI.Value) Then
                '----------------------------------------------------------------------------------------------
                ' Save TP Mark Model Recipe ==> Request_Command = "SAVE_TPMARK_MODEL_RECIPE" (Dispatcher 1)
                '----------------------------------------------------------------------------------------------
                Try
                    '--- Prepare Command ---
                    Request_Command = "SAVE_TPMARK_MODEL_RECIPE"
                    TimeOut = 100000 '100 secs

                    Response_OK = False
                    Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, , , , , , , , , TimeOut)
                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                        If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                        Response_OK = True
                    Else
                        '--- Enable Button ---   
                        'Me.Button_TPMark_Enable(True)
                        Me.m_MainProcess.LogDailyManager("[G1 >>IP]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Save TP Mark Model Recipe Error !(" & SubSystemResult.ErrMessage & ")")
                        MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMark_MODEL_RECIPE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                Catch ex As Exception
                    '--- Enable Button ---  
                    'Me.Button_TPMark_Enable(True)
                    Me.m_MainProcess.LogDailyManager("[Dialog_FuncSetting.TPMark_Setting]Save TP Mark Model Recipe Error ! (" & ex.Message & ")")
                    MessageBox.Show("[Dialog_FuncSetting.TPMark_Setting][SAVE_TPMark_MODEL_RECIPE]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
            End If

            '--- Func Recipe Monitor ---
            dir = Me.m_MainProcess.LOG_PATH & "\APC\AreaGrabber\" & Now.ToString("yyyyMMdd") & "\"
            If Not Directory.Exists(dir) Then Directory.CreateDirectory(dir)
            Me.m_FuncProcess.SaveToFuncRecipeMonitorFile(dir, Me.m_Form.GetProductNameInfo, Me.m_MainProcess.CCDNo, Me.m_MainProcess.ErrorCode)

            '--- Button Control ---   
            Button_Enable(True)
            'Me.Update()

        Catch ex As Exception
            Button_Enable(True)
            Me.m_Form.OutputInfo("[Dialog_FuncSetting.Button_Save]" & ex.Message)
            MessageBox.Show("[Dialog_FuncSetting.Button_Save]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub


#Region "--- BPoint ---"
    Private Sub RadioButton_BP_CheckedChanged(sender As System.Object, e As System.EventArgs)
        If Me.m_Form.CheckBox_Point_Enable.Checked Then

            Me.m_Form.GroupBox_BPoint.Enabled = Me.m_Form.RadioButton_BP.Checked
            Me.m_Form.GroupBox_DPoint.Enabled = Me.m_Form.RadioButton_DP.Checked
            Me.m_Form.GroupBox_BP_Characteristics.Enabled = Me.m_Form.RadioButton_BP.Checked
            Me.m_Form.GroupBox_DP_Characteristics.Enabled = Me.m_Form.RadioButton_DP.Checked

            If Me.m_Form.RadioButton_BP.Checked = False And Me.m_Form.RadioButton_DP.Checked = False And Me.m_Form.RadioButton_BPDP.Checked = False Then
                Me.m_Form.GroupBox_BPoint.Enabled = False
                Me.m_Form.GroupBox_DPoint.Enabled = False
                Me.m_Form.GroupBox_BP_Characteristics.Enabled = False
                Me.m_Form.GroupBox_DP_Characteristics.Enabled = False
            End If

        End If
    End Sub
    Private Sub RadioButton_BPDP_CheckedChanged(sender As System.Object, e As System.EventArgs)
        If Me.m_Form.CheckBox_Point_Enable.Checked Then
            Me.m_Form.GroupBox_BPoint.Enabled = Me.m_Form.RadioButton_BPDP.Checked
            Me.m_Form.GroupBox_DPoint.Enabled = Me.m_Form.RadioButton_BPDP.Checked
            Me.m_Form.GroupBox_BP_Characteristics.Enabled = Me.m_Form.RadioButton_BPDP.Checked
            Me.m_Form.GroupBox_DP_Characteristics.Enabled = Me.m_Form.RadioButton_BPDP.Checked

            If Me.m_Form.RadioButton_BP.Checked = False And Me.m_Form.RadioButton_DP.Checked = False And Me.m_Form.RadioButton_BPDP.Checked = False Then
                Me.m_Form.GroupBox_BPoint.Enabled = False
                Me.m_Form.GroupBox_DPoint.Enabled = False
                Me.m_Form.GroupBox_BP_Characteristics.Enabled = False
                Me.m_Form.GroupBox_DP_Characteristics.Enabled = False
            End If
        End If
    End Sub

    Private Sub RadioButton_BP_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_Threshold.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BP_Threshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_Threshold_Low.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_Threshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_Threshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BP_RimThreshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_RimThreshold.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_RimThreshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BP_RimThreshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked Then Call BP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_BP_RimThreshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BP_Threshold_CheckedChanged()
        End If
    End Sub

#Region "--- BP_Threshold_CheckedChanged ---"
    Private Sub BP_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        '--- 連線參數 ---
        Dim TimeOut As Integer
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim strPath As String = ""
        Dim m_IsIPConnected As Boolean = False
        Dim m_IPConnectMsg As String = ""

        If Me.m_Form.RadioButton_DP_Threshold.Checked Then Me.m_Form.RadioButton_DP_Threshold.Checked = False
        If Me.m_Form.RadioButton_DP_Threshold_Low.Checked Then Me.m_Form.RadioButton_DP_Threshold_Low.Checked = False
        If Me.m_Form.RadioButton_DP_RimThreshold.Checked Then Me.m_Form.RadioButton_DP_RimThreshold.Checked = False
        If Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked Then Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked = False

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Index + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateUIEnable()


        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BP_Threshold_CheckedChange]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChange]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第一頁 ---
            Parameter_Lists = "BP_Threshold," & Me.m_Form.NumericUpDown_BP_Threshold.Value & ";" & "BP_Threshold_Low," & Me.m_Form.NumericUpDown_BP_Threshold_Low.Value & ";" & "BP_RimThreshold," & Me.m_Form.NumericUpDown_BP_RimThreshold.Value & ";" & "BP_RimThreshold_Low," & Me.m_Form.NumericUpDown_BP_RimThreshold_Low.Value & ";" & _
                              "DP_Threshold," & Me.m_Form.NumericUpDown_DP_Threshold.Value & ";" & "DP_Threshold_Low," & Me.m_Form.NumericUpDown_DP_Threshold_Low.Value & ";" & "DP_RimThreshold," & Me.m_Form.NumericUpDown_DP_RimThreshold.Value & ";" & "DP_RimThreshold_Low," & Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Value & ";" & _
                              "BP_AreaMax," & Me.m_Form.NumericUpDown_BP_AreaMax.Value & ";" & "BP_AreaMin," & Me.m_Form.NumericUpDown_BP_AreaMin.Value & ";" & "DP_AreaMax," & Me.m_Form.NumericUpDown_DP_AreaMax.Value & ";" & "DP_AreaMin," & Me.m_Form.NumericUpDown_DP_AreaMin.Value & ";" & _
                              "Point_ByPassX," & Me.m_Form.NumericUpDown_Point_ByPassX.Value & ";" & "Point_ByPassY," & Me.m_Form.NumericUpDown_Point_ByPassY.Value & ";" & "Point_OverNum," & Me.m_Form.NumericUpDown_Point_OverNum.Value & ";" & "Align_Enable," & Me.m_Form.CheckBox_Align_Enable.Checked & ";" & _
                              "Point_Enable," & Me.m_Form.CheckBox_Point_Enable.Checked & ";" & "Inverse_Point_DefectType," & False & ";" & "Inverse_Point_EnableFixArea," & False & ";" & "Inverse_Point_FixArea," & 10 & ";" & "Waku_Inspect_Enable," & False & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.m_Form.RadioButton_BP_Threshold.Checked Or Me.m_Form.RadioButton_BP_Threshold_Low.Checked Or Me.m_Form.RadioButton_BP_RimThreshold.Checked Or Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "WHITE"
                Inspect_Defect_Type = "POINT"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.BP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
#End Region

#End Region
#Region "--- DPoint ---"

    'Private Sub RadioButton_DP_CheckedChanged(sender As System.Object, e As System.EventArgs)
    '    If Me.m_Form.CheckBox_Point_Enable.Checked Then
    '        Me.m_Form.GroupBox_BPoint.Enabled = Me.m_Form.RadioButton_BP.Checked
    '        Me.m_Form.GroupBox_DPoint.Enabled = Me.m_Form.RadioButton_DP.Checked
    '        Me.m_Form.GroupBox_BP_Characteristics.Enabled = Me.m_Form.RadioButton_BP.Checked
    '        Me.m_Form.GroupBox_DP_Characteristics.Enabled = Me.m_Form.RadioButton_DP.Checked

    '        If Me.m_Form.RadioButton_BP.Checked = False And Me.m_Form.RadioButton_DP.Checked = False And Me.m_Form.RadioButton_BPDP.Checked = False Then
    '            Me.m_Form.GroupBox_BPoint.Enabled = False
    '            Me.m_Form.GroupBox_DPoint.Enabled = False
    '            Me.m_Form.GroupBox_BP_Characteristics.Enabled = False
    '            Me.m_Form.GroupBox_DP_Characteristics.Enabled = False
    '        End If
    '    End If
    'End Sub

    Private Sub RadioButton_DP_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_Threshold.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub RadioButton_DP_Threshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_Threshold_Low.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_DP_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_DP_Threshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_Threshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_DP_RimThreshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_RimThreshold.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub RadioButton_DP_RimThreshold_Low_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked Then Call DP_Threshold_CheckedChanged()

        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.CurrentIndex1 = 18
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub NumericUpDown_DP_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_RimThreshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_DP_RimThreshold_Low_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DP_Threshold_CheckedChanged()
        End If
    End Sub

#Region "--- DP_Threshold_CheckedChanged ---"
    Private Sub DP_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        '--- 連線參數 ---
        Dim TimeOut As Integer
        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim strPath As String

        If Me.m_Form.RadioButton_BP_Threshold.Checked Then Me.m_Form.RadioButton_BP_Threshold.Checked = False
        If Me.m_Form.RadioButton_BP_Threshold_Low.Checked Then Me.m_Form.RadioButton_BP_Threshold_Low.Checked = False
        If Me.m_Form.RadioButton_BP_RimThreshold.Checked Then Me.m_Form.RadioButton_BP_RimThreshold.Checked = False
        If Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked Then Me.m_Form.RadioButton_BP_RimThreshold_Low.Checked = False

        '--- 建立連線 ---
        If Me.ConnectToIP = False Then
            Exit Sub
        End If

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Index + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateUIEnable()


        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DP_Threshold_CheckedChange]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChange]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 100000 '100 secs

            'UI Recipe Setting -----------------------------------

            '--- 第一頁 ---
            Parameter_Lists = "BP_Threshold," & Me.m_Form.NumericUpDown_BP_Threshold.Value & ";" & "BP_Threshold_Low," & Me.m_Form.NumericUpDown_BP_Threshold_Low.Value & ";" & "BP_RimThreshold," & Me.m_Form.NumericUpDown_BP_RimThreshold.Value & ";" & "BP_RimThreshold_Low," & Me.m_Form.NumericUpDown_BP_RimThreshold_Low.Value & ";" & _
                              "DP_Threshold," & Me.m_Form.NumericUpDown_DP_Threshold.Value & ";" & "DP_Threshold_Low," & Me.m_Form.NumericUpDown_DP_Threshold_Low.Value & ";" & "DP_RimThreshold," & Me.m_Form.NumericUpDown_DP_RimThreshold.Value & ";" & "DP_RimThreshold_Low," & Me.m_Form.NumericUpDown_DP_RimThreshold_Low.Value & ";" & _
                              "BP_AreaMax," & Me.m_Form.NumericUpDown_BP_AreaMax.Value & ";" & "BP_AreaMin," & Me.m_Form.NumericUpDown_BP_AreaMin.Value & ";" & "DP_AreaMax," & Me.m_Form.NumericUpDown_DP_AreaMax.Value & ";" & "DP_AreaMin," & Me.m_Form.NumericUpDown_DP_AreaMin.Value & ";" & _
                              "Point_ByPassX," & Me.m_Form.NumericUpDown_Point_ByPassX.Value & ";" & "Point_ByPassY," & Me.m_Form.NumericUpDown_Point_ByPassY.Value & ";" & "Point_OverNum," & Me.m_Form.NumericUpDown_Point_OverNum.Value & ";" & "Align_Enable," & Me.m_Form.CheckBox_Align_Enable.Checked & ";" & _
                              "Point_Enable," & Me.m_Form.CheckBox_Point_Enable.Checked & ";" & "Inverse_Point_DefectType," & False & ";" & "Inverse_Point_EnableFixArea," & False & ";" & "Inverse_Point_FixArea," & 10 & ";" & "Waku_Inspect_Enable," & False & ";"

            'Parameter_Lists = "BP_Threshold," & Me.NumericUpDown_BP_Threshold.Value & ";" & "BP_Threshold_Low," & Me.NumericUpDown_BP_Threshold_Low.Value & ";" & "BP_RimThreshold," & Me.NumericUpDown_BP_RimThreshold.Value & ";" & "BP_RimThreshold_Low," & Me.NumericUpDown_BP_RimThreshold_Low.Value & ";" & _
            '                  "DP_Threshold," & Me.NumericUpDown_DP_Threshold.Value & ";" & "DP_Threshold_Low," & Me.NumericUpDown_DP_Threshold_Low.Value & ";" & "DP_RimThreshold," & Me.NumericUpDown_DP_RimThreshold.Value & ";" & "DP_RimThreshold_Low," & Me.NumericUpDown_DP_RimThreshold_Low.Value & ";" & _
            '                  "BP_AreaMax," & Me.NumericUpDown_BP_AreaMax.Value & ";" & "BP_AreaMin," & Me.NumericUpDown_BP_AreaMin.Value & ";" & "DP_AreaMax," & Me.NumericUpDown_DP_AreaMax.Value & ";" & "DP_AreaMin," & Me.NumericUpDown_DP_AreaMin.Value & ";" & _
            '                  "Point_ByPassX," & Me.NumericUpDown_Point_ByPassX.Value & ";" & "Point_ByPassY," & Me.NumericUpDown_Point_ByPassY.Value & ";" & "Point_OverNum," & Me.NumericUpDown_Point_OverNum.Value & ";" & "Align_Enable," & Me.CheckBox_Align_Enable.Checked & ";" & _
            '                  "Point_Enable," & Me.CheckBox_Point_Enable.Checked & ";" & "Inverse_Point_DefectType," & Me.CheckBox_Inverse_Point_DefectType.Checked & ";" & "Inverse_Point_EnableFixArea," & Me.CheckBox_Inverse_Point_EnableFixArea.Checked & ";" & _
            '                  "Inverse_Point_FixArea," & Me.NumericUpDown_CheckBox_Inverse_Point_FixArea.Value & ";" & "Waku_Inspect_Enable," & Me.CheckBox_Waku_Inspect_Enable.Checked & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.m_Form.RadioButton_DP_Threshold.Checked Or Me.m_Form.RadioButton_DP_Threshold_Low.Checked Or Me.m_Form.RadioButton_DP_RimThreshold.Checked Or Me.m_Form.RadioButton_DP_RimThreshold_Low.Checked Then
            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "BLACK"
                Inspect_Defect_Type = "POINT"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.DP_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
            End Try
        End If
    End Sub
#End Region

#End Region
#Region "--- Bright-Line ---"
    Private Sub RadioButton_BL_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BLine_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_BL_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call BLine_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub RadioButton_BL_Threshold_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub BLine_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String
        Dim SizeX, SizeY, Type As Integer

        Dim Request_Command As String
        Dim TimeOut As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim strPath As String

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---   
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Index + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateUIEnable()

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 10000 '10 secs

            'UI Recipe Setting -----------------------------------

            '--- 第二頁 ---
            Parameter_Lists = Parameter_Lists & "DL_Threshold," & Me.m_Form.NumericUpDown_DL_Threshold.Value & ";" & "BL_Threshold," & Me.m_Form.NumericUpDown_BL_Threshold.Value & ";" & "DL_RimThreshold," & Me.m_Form.NumericUpDown_DL_RimThreshold.Value & ";" & "BL_RimThreshold," & Me.m_Form.NumericUpDown_BL_RimThreshold.Value & ";" & _
                                                "Line_H_Threshold," & Me.m_Form.NumericUpDown_Line_ByPassUpH.Value & ";" & "LINE_BYPASSV," & Me.m_Form.NumericUpDown_Line_ByPassDownH.Value & ";" & _
                                                "LINE_BYPASSH," & Me.m_Form.NumericUpDown_Line_ByPassUpH.Value & ";" & "LINE_BYPASSV," & Me.m_Form.NumericUpDown_Line_ByPassDownH.Value & ";" & _
                                                "Line_Cut," & Me.m_Form.NumericUpDown_Line_Cut.Value & ";" & "Line_Short_Cut," & Me.m_Form.NumericUpDown_Line_Short_Cut.Value & ";" & _
                                                "Line_OverNumber," & Me.m_Form.NumericUpDown_Line_OverNumber.Value & ";" & "Block_OverNumber," & Me.m_Form.NumericUpDown_Block_OverNumber.Value & ";" & _
                                                "MeanDifference," & 0 & ";" & "Line_Enable," & Me.m_Form.CheckBox_Line_Enable.Checked & ";" & _
                                                "HLine_NotAddToOutput," & Me.m_Form.CheckBox_HLine_NotAddToOutput.Checked & ";" & "VLine_NotAddToOutput," & Me.m_Form.CheckBox_VLine_NotAddToOutput.Checked & ";" & "Filter_VH_Scratch," & False & ";" & "Line_Elongation_Min," & 0 & ";" & _
                                                "HalfScreen_Enable," & False & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
        End Try


        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.m_Form.RadioButton_BL_Threshold.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "WHITE"
                Inspect_Defect_Type = "LINE"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.BLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        End If

    End Sub
#End Region
#Region "--- Dark-Line ---"
    Private Sub RadioButton_DL_Threshold_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DLine_Threshold_CheckedChanged()
        End If
    End Sub

    Private Sub NumericUpDown_DL_Threshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DL_Threshold.Checked Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
            Call DLine_Threshold_CheckedChanged()
        End If
    End Sub


    Private Sub RadioButton_DL_Threshold_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        If Me.m_Form.ComboBox_Type.SelectedIndex >= 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex >= 0 Then
            Me.m_Form.ComboBox_Type.SelectedIndex = 1
            Me.m_Form.ComboBox_Select.SelectedIndex = 18
        End If
    End Sub

    Private Sub DLine_Threshold_CheckedChanged()
        Dim image As MIL_ID = M_NULL
        Dim Parameter_Lists As String = ""
        Dim ImageType As String
        Dim Inspect_Defect_Type As String
        Dim IP_Address As String = ""
        Dim PatternName As String = ""
        Dim SizeX, SizeY, Type As Integer

        Dim Request_Command As String
        Dim TimeOut As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim strPath As String

        '--- 建立連線 ---
        If Not Me.ConnectToIP Then
            Exit Sub
        End If

        '--- Initial ---  
        IP_Address = Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(Me.m_MainProcess.CCDNo - 1).IP_IPAddress

        Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Index + Me.m_MuraProcess.MuraPatternRecipeArray.Count

        If Me.m_MainProcess.ChipId Is Nothing Or Me.m_MainProcess.ChipId = "" Then Me.m_MainProcess.ChipId = "AAAAAAAA"
        Me.UpdateUIEnable()

        '----------------------------------------------------------------------------------------------
        ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "SET_PATTERNINDEX"
            TimeOut = 100000 '100 secs

            '--- PatternName ---
            PatternName = Me.m_Form.TreeView_FuncParamPattern.SelectedNode.Text

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]Set Pattern Index Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        '----------------------------------------------------------------------------------------------
        ' Dialog_FuncSetting Setting   ==> Request_Command = "DIALOG_FUNCSETTING_SETTING" (Dispatcher 1)
        '----------------------------------------------------------------------------------------------
        Try
            '--- Prepare Command ---
            Request_Command = "DIALOG_FUNCSETTING_SETTING"
            TimeOut = 10000 '10 secs

            'UI Recipe Setting -----------------------------------

            '--- 第二頁 ---
            Parameter_Lists = Parameter_Lists & "DL_Threshold," & Me.m_Form.NumericUpDown_DL_Threshold.Value & ";" & "BL_Threshold," & Me.m_Form.NumericUpDown_BL_Threshold.Value & ";" & "DL_RimThreshold," & Me.m_Form.NumericUpDown_DL_RimThreshold.Value & ";" & "BL_RimThreshold," & Me.m_Form.NumericUpDown_BL_RimThreshold.Value & ";" & _
                                                "Line_ByPassH," & Me.m_Form.NumericUpDown_Line_ByPassUpH.Value & ";" & "Line_ByPassV," & Me.m_Form.NumericUpDown_Line_ByPassDownH.Value & ";" & _
                                                "Line_Cut," & Me.m_Form.NumericUpDown_Line_Cut.Value & ";" & "Line_Short_Cut," & Me.m_Form.NumericUpDown_Line_Short_Cut.Value & ";" & _
                                                "Line_OverNumber," & Me.m_Form.NumericUpDown_Line_OverNumber.Value & ";" & "Block_OverNumber," & Me.m_Form.NumericUpDown_Block_OverNumber.Value & ";" & _
                                                "MeanDifference," & 0 & ";" & "Line_Enable," & Me.m_Form.CheckBox_Line_Enable.Checked & ";" & _
                                                "HLine_NotAddToOutput," & Me.m_Form.CheckBox_HLine_NotAddToOutput.Checked & ";" & "VLine_NotAddToOutput," & Me.m_Form.CheckBox_VLine_NotAddToOutput.Checked & ";" & "Filter_VH_Scratch," & False & ";" & "Line_Elongation_Min," & 0 & ";" & _
                                                "HalfScreen_Enable," & False & ";"

            'End UI Recipe Setting -----------------------------------

            Response_OK = False
            Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, Parameter_Lists, , , , , , , , TimeOut)
            SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(TimeOut)

            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                Response_OK = True
            Else
                Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Dialog_FuncSetting Setting Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
        Catch ex As Exception
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]Dialog_FuncSetting Setting Error ! (" & ex.Message & ")")
            MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        If Me.m_Form.ComboBox_Type.SelectedIndex < 0 AndAlso Me.m_Form.ComboBox_Select.SelectedIndex < 0 Then
            Exit Sub
        End If

        If Me.m_Form.RadioButton_DL_Threshold.Checked Then

            '----------------------------------------------------------------------------------------------
            ' Calculate Func PreProcess  ==> Request_Command = "FUNC_PREPROCESS"  (Dispatcher 2)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "FUNC_PREPROCESS"
                TimeOut = 300000 '300 secs

                ImageType = "BLACK"
                Inspect_Defect_Type = "LINE"
                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, Me.m_FuncProcess.CurrentFuncPatternRecipe.PatternName.Value, ImageType, Inspect_Defect_Type, , , , , , TimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(TimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "IP Image Preprocess Fail !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    Exit Sub
                End If

                If Response_OK Then
                    '--- Update Processed Image ---
                    image = Me.m_MainProcess.Img_FixRecipe_NonPage
                    If Me.m_MainProcess.IPBootConfig.LocalGrab.Value Then
                        strPath = Me.m_MainProcess.RAMDISK_PATH & "\" & "Img_FixRecipe_NonPage.tif"
                        strPath = strPath.Replace("\\", "\")
                    Else
                        strPath = "\\" & IP_Address & "\" & Me.m_MainProcess.RAMDISK_PATH.Substring(4) & "\" & "Img_FixRecipe_NonPage.tif"
                        RepairPath_2(strPath)
                    End If

                    If System.IO.File.Exists(strPath) Then
                        MbufDiskInquire(strPath, M_SIZE_X, SizeX)
                        MbufDiskInquire(strPath, M_SIZE_Y, SizeY)
                        MbufDiskInquire(strPath, M_TYPE, Type)
                        If image <> M_NULL Then
                            If MbufInquire(image, M_SIZE_X, M_NULL) <> SizeX Or MbufInquire(image, M_SIZE_Y, M_NULL) <> SizeY Then
                                MbufFree(image)
                                image = M_NULL
                                image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                            End If
                        Else
                            image = MbufAlloc2d(Me.m_MainProcess.System_Host, SizeX, SizeY, Type, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        End If

                        '--- Load Remote Image ---
                        MbufLoad(strPath, image)
                        MbufCopy(image, Me.m_MainProcess.Img_FixRecipe_NonPage)

                        Me.m_Form.ImageUpdate()
                        'Me.m_Form.ImageZoomAll()

                        If System.IO.File.Exists(strPath) = True Then
                            System.IO.File.Delete(strPath)
                        End If
                    End If
                End If

            Catch ex As Exception
                Me.m_Form.OutputInfo("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message & "(" & ex.StackTrace & ")")
                MessageBox.Show("[Dialog_FuncSetting.DLine_Threshold_CheckedChanged]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

        End If
    End Sub
#End Region
#Region "--- Boundary Line Thread ---"
    Private Sub NumericUpDown_DL_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_DL_Threshold.Checked Then
            Call DLine_Threshold_CheckedChanged()
        End If
    End Sub
    Private Sub NumericUpDown_BL_RimThreshold_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Me.m_Form.RadioButton_BL_Threshold.Checked Then
            Call BLine_Threshold_CheckedChanged()
        End If
    End Sub

#End Region
#Region "--- Line Common Setting ---"
    Private Sub RadioButton_Line_ByPassUpH_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_ByPassDownH_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_ByPassLeftV_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_ByPassrRightV_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_Cut_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_ShortCut_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_Cut_H_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_ShortCut_H_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Line_OverNum_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
    Private Sub RadioButton_Block_OverNum_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        UpdateUIEnable()
    End Sub
#End Region



#End Region

#Region "--- UI ---"

#End Region


End Class
