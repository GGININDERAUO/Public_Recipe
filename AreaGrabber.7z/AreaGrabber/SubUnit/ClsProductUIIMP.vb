﻿Imports MILOperationLib
Imports ClassLibrary
Imports AUO.SubSystemControl
Imports System.IO
Imports Matrox.MatroxImagingLibrary
Imports Matrox.MatroxImagingLibrary.MIL

<CLSCompliant(False)>
Public Class ClsProductUIIMP

#Region "---Variable---"
    Private m_Form As Main_Form
    Private m_MainProcess As ClsMainProcess
    Private m_IPBootConfig As ClsIPBootConfig
    Private m_FuncProcess As ClsFuncProcess
    Private m_MuraProcess As ClsMuraProcess
    '--- 多連線參數 ---
    Private m_ConnectedIP As ArrayList
#End Region


#Region "---Properties---"
    Public Property ContextMenuStrip_Model As ContextMenuStrip
    Public Property ContextMenuStrip_FuncPattern As ContextMenuStrip
    Public Property ContextMenuStrip_MuraPattern As ContextMenuStrip
    Public Property ListView_Model As ListView
    Public Property ListView_FuncPattern As ListView
    Public Property ListView_MuraPattern As ListView

#End Region

#Region "--- Contructor---"
    Public Sub New(ByVal Mainfrm As Main_Form)
        Me.m_Form = Mainfrm
    End Sub
#End Region


#Region "---Public Method---"
    Public Sub Init()
        'Set Variable
        Me.m_MainProcess = Me.m_Form.MainProcess
        Me.m_FuncProcess = Me.m_Form.MainProcess.FuncProcess
        Me.m_MuraProcess = Me.m_Form.MainProcess.MuraProcess
        Me.m_IPBootConfig = Me.m_Form.MainProcess.IPBootConfig
        'Set UI Component Variable
        Me.ContextMenuStrip_Model = Me.m_Form.ContextMenuStrip_Model
        Me.ContextMenuStrip_FuncPattern = Me.m_Form.ContextMenuStrip_FuncPattern
        Me.ContextMenuStrip_MuraPattern = Me.m_Form.ContextMenuStrip_MuraPattern
        Me.ListView_Model = Me.m_Form.ListView_Model
        Me.ListView_FuncPattern = Me.m_Form.ListView_FuncPattern
        Me.ListView_MuraPattern = Me.m_Form.ListView_MuraPattern

        If Me.ContextMenuStrip_Model IsNot Nothing Then
            RemoveHandler ContextMenuStrip_Model.ItemClicked, AddressOf ContextMenuStrip_Model_ItemClicked
            AddHandler ContextMenuStrip_Model.ItemClicked, AddressOf ContextMenuStrip_Model_ItemClicked
        End If
        If Me.ContextMenuStrip_FuncPattern IsNot Nothing Then
            RemoveHandler ContextMenuStrip_FuncPattern.ItemClicked, AddressOf ContextMenuStrip_FuncPattern_ItemClicked
            AddHandler ContextMenuStrip_FuncPattern.ItemClicked, AddressOf ContextMenuStrip_FuncPattern_ItemClicked
        End If
        If Me.ContextMenuStrip_MuraPattern IsNot Nothing Then
            RemoveHandler ContextMenuStrip_MuraPattern.ItemClicked, AddressOf ContextMenuStrip_MuraPattern_ItemClicked
            AddHandler ContextMenuStrip_MuraPattern.ItemClicked, AddressOf ContextMenuStrip_MuraPattern_ItemClicked
        End If

        If Me.ListView_Model IsNot Nothing Then
            RemoveHandler ListView_Model.MouseDown, AddressOf ListView_Model_MouseDown
            AddHandler ListView_Model.MouseDown, AddressOf ListView_Model_MouseDown
            RemoveHandler ListView_Model.AfterLabelEdit, AddressOf ListView_Model_AfterLabelEdit
            AddHandler ListView_Model.AfterLabelEdit, AddressOf ListView_Model_AfterLabelEdit
            RemoveHandler ListView_Model.MouseEnter, AddressOf ListView_Model_MouseEnter
            AddHandler ListView_Model.MouseEnter, AddressOf ListView_Model_MouseEnter
            RemoveHandler ListView_Model.MouseLeave, AddressOf ListView_Model_MouseLeave
            AddHandler ListView_Model.MouseLeave, AddressOf ListView_Model_MouseLeave
        End If

        If Me.ListView_FuncPattern IsNot Nothing Then
            RemoveHandler ListView_FuncPattern.MouseDown, AddressOf ListView_FuncPattern_MouseDown
            AddHandler ListView_FuncPattern.MouseDown, AddressOf ListView_FuncPattern_MouseDown
            RemoveHandler ListView_FuncPattern.AfterLabelEdit, AddressOf ListView_FuncPattern_AfterLabelEdit
            AddHandler ListView_FuncPattern.AfterLabelEdit, AddressOf ListView_FuncPattern_AfterLabelEdit
            RemoveHandler ListView_FuncPattern.MouseEnter, AddressOf ListView_FuncPattern_MouseEnter
            AddHandler ListView_FuncPattern.MouseEnter, AddressOf ListView_FuncPattern_MouseEnter
            RemoveHandler ListView_FuncPattern.MouseLeave, AddressOf ListView_FuncPattern_MouseLeave
            AddHandler ListView_FuncPattern.MouseLeave, AddressOf ListView_FuncPattern_MouseLeave
        End If

        If Me.ListView_MuraPattern IsNot Nothing Then
            RemoveHandler ListView_MuraPattern.MouseDown, AddressOf ListView_MuraPattern_MouseDown
            AddHandler ListView_MuraPattern.MouseDown, AddressOf ListView_MuraPattern_MouseDown
            RemoveHandler ListView_MuraPattern.AfterLabelEdit, AddressOf ListView_MuraPattern_AfterLabelEdit
            AddHandler ListView_MuraPattern.AfterLabelEdit, AddressOf ListView_MuraPattern_AfterLabelEdit
            RemoveHandler ListView_MuraPattern.MouseEnter, AddressOf ListView_MuraPattern_MouseEnter
            AddHandler ListView_MuraPattern.MouseEnter, AddressOf ListView_MuraPattern_MouseEnter
            RemoveHandler ListView_MuraPattern.MouseLeave, AddressOf ListView_MuraPattern_MouseLeave
            AddHandler ListView_MuraPattern.MouseLeave, AddressOf ListView_MuraPattern_MouseLeave
        End If

        '--- 建立連線 ---
        If Me.ConnectToIP = False Then
            Exit Sub
        End If
        'ResetUIParam
        Me.ResetUIParam()
        'Set Pattern List
        Me.UpdateModelInfo()
        'Me.UpdateUserLevel()
    End Sub
#End Region

#Region "---Private Method---"
#Region "--- Repair_PatternName ---"
    Private Sub Repair_PatternName(ByRef strPatternName As String)
        Dim strFirst As String
        Dim strSecond As String
        strFirst = Mid(strPatternName, 1, 1)
        strSecond = Mid(strPatternName, 2, 1)

        If strFirst <> "F" And strSecond <> "_" Then
            If strFirst <> "_" Then strPatternName = "_" & strPatternName
            If Mid(strPatternName, 1, 1) <> "M" Then strPatternName = "M" & strPatternName
            Exit Sub
        ElseIf strFirst <> "M" And strSecond <> "_" Then
            If strFirst <> "_" Then strPatternName = "_" & strPatternName
            If Mid(strPatternName, 1, 1) <> "M" Then strPatternName = "M" & strPatternName
            Exit Sub
        Else
            Exit Sub
        End If

    End Sub
#End Region
#Region "--- ConnectToMultiIP ---"
    Public Function ConnectToMultiIP() As Boolean
        Dim ipnwc As ClsIPNetWorkConfig
        Dim i As Integer
        Dim ErrMsg = ""
        Dim ip As ClsIPInfo
        Dim IsIPConnected As Boolean
        Dim IPMsg As String

        Me.m_ConnectedIP = New ArrayList
        ipnwc = Me.m_MainProcess.IPNetworkConfig

        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()

        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then
                ip = New ClsIPInfo
                ip.CCDNo = i
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)
                System.Threading.Thread.Sleep(200)

                If IsIPConnected = False Or IPMsg <> "" Then
                    ErrMsg = ErrMsg + "IP - " & i & " 連線失敗 !( " & IPMsg & " )" & " ; "
                    Me.m_MainProcess.IsIPConnected = False
                Else
                    Me.m_ConnectedIP.Add(ip.CCDNo)
                End If

            End If

        Next

        If ErrMsg <> "" Then
            MsgBox(ErrMsg, MsgBoxStyle.Critical, "[AreaGrabber]")
            Return False
        Else
            Me.m_MainProcess.IsIPConnected = True
            Return True
        End If

    End Function
#End Region
#Region "--- RepairPath_2 ---"
    Private Function RepairPath_2(ByRef strPath As String)
        Do While (strPath.Contains("\\"))
            strPath = Replace(strPath, "\\", "\")
        Loop

        If (Not strPath.Contains(":")) Then
            strPath = "\" + strPath
        End If
        Return strPath
    End Function
#End Region
#Region "--- Button Enable ---"
    Private Sub Button_Enable(ByVal flag As Boolean)
        Me.m_Form.SplitContainer1.Panel1.Enabled = flag

    End Sub
#End Region
#Region "--- UpdateData ---"
    Private Sub UpdateModelInfo()
        Dim i As Integer

        Try
            '--- Product Name ---
            Me.ListView_Model.Items.Clear()
            For i = 0 To Me.m_IPBootConfig.ProductList.Count - 1
                Me.ListView_Model.Items.Add(Me.m_IPBootConfig.ProductList.Item(i).Value)
            Next

            '--- Func Pattern Name ---
            Me.ListView_FuncPattern.Items.Clear()
            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                Me.ListView_FuncPattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
            Next

            '--- Mura Pattern Name ---
            Me.ListView_MuraPattern.Items.Clear()
            For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                Me.ListView_MuraPattern.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
            Next

        Catch ex As Exception
            Me.m_Form.OutputErrorInfo("[Dialog_FuncSettingBase.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.UpdateData]" & ex.Message & "(" & ex.StackTrace & ")", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
#End Region
#Region "--- RecipeUpdate ---"
    Private Sub RecipeUpdate(ByVal CCDNo As Integer, ByVal GrabNo As String)
        Dim i As Integer
        Dim strOld_Path As String = ""
        Dim strModelPath As String = ""
        Dim strPatternPath As String = ""
        Dim fmr As ClsFuncModelRecipe

        strOld_Path = Me.m_MainProcess.RECIPE_PATH & "\IP" & CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func"
        strModelPath = strOld_Path & "\FuncModelRecipe_C" & GrabNo & ".xml"
        RepairPath_2(strModelPath)
        If System.IO.File.Exists(strModelPath) Then
            fmr = ClsFuncModelRecipe.ReadXML(strModelPath)
            fmr.PatternCount.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Count()
            MILOperationLib.ClsFuncModelRecipe.WriteXML(fmr, strModelPath)

            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count() - 1
                strPatternPath = strOld_Path & "\FuncPatternRecipe_C" & GrabNo & "_P" & i + 1 & ".xml"
                RepairPath_2(strPatternPath)
                ClsFuncPatternRecipe.WriteXML(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i), strPatternPath)
            Next
        End If

    End Sub
#End Region
#Region "---UpdateModelInfo---"
    Private Sub ResetUIParam()
        Dim image As MIL_ID = M_NULL
        Try
            'Me.m_ModelChanged = False
            'Me.m_PatternChanged = False

            If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            Else
                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value
            End If

            image = Me.m_FuncProcess.Img_Original_NonPage
            If image <> M_NULL Then
                Me.m_Form.CurrentIndex0 = 2
                Me.m_Form.ComboBox_Type.SelectedIndex = 0
                Me.m_Form.ComboBox_Select.SelectedIndex = 2
            End If

        Catch ex As Exception
            Me.m_Form.OutputInfo("[Dialog_FuncSettingBase.SetMainForm]" & ex.Message)
        End Try
    End Sub
#End Region
#Region "--- ConnectToIP ---"
    Public Function ConnectToIP()

        Dim ip As ClsIPInfo
        Dim IsIPConnected As Boolean = False
        Dim IPConnectMsg As String = ""

        '--- 斷線清除 ---
        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

        '--- 建立 IP 連線 ---
        If Me.m_MainProcess.IPInfo.Count > 0 Then Me.m_MainProcess.IPInfo.Clear()
        ip = New ClsIPInfo
        ip.CCDNo = Me.m_MainProcess.CCDNo
        ip.GrabNo = Me.m_MainProcess.GrabNo
        Me.m_Form.Change_GrabNo(Me.m_MainProcess.CCDNo, Me.m_MainProcess.GrabNo)
        Me.m_MainProcess.IPInfo.Add(ip)
        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPConnectMsg)
        If IsIPConnected = False Or IPConnectMsg <> "" Then
            MsgBox("IP連線失敗 !( " & IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
            Me.m_MainProcess.IsIPConnected = False
            Return False
        End If

        Me.m_MainProcess.IsIPConnected = True
        Return True

    End Function
#End Region
#Region "---SetCurrentModelName---"
    Private Sub SetCurrentModelName()
        Dim PatternName As String = ""
        Dim Path As String = ""

        Dim Response_OK As Boolean = False
        Dim SubSystemResult As CResponseResult
        Dim Request_Command As String = ""
        Dim iTimeOut As Integer

        If Not Me.m_MainProcess.IsIPConnected Then
            Exit Sub
        End If

        '--- 建立連線 ---
        If Me.ConnectToIP = False Then
            Exit Sub
        End If

        Me.m_Form.Text = "Model參數調整 [ " & Me.m_Form.GetProductNameInfo & " ]"

        Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncModelRecipe_C" & Me.m_MainProcess.GrabNo & ".xml"
        RepairPath_2(Path)
        Me.m_FuncProcess.FuncModelRecipe = MILOperationLib.ClsFuncModelRecipe.ReadXML(Path)

        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex < Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
            Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value

            '----------------------------------------------------------------------------------------------
            ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
            '----------------------------------------------------------------------------------------------
            Try
                '--- Prepare Command ---
                Request_Command = "SET_PATTERNINDEX"
                iTimeOut = 200000 '200 secs

                '--- PatternName ---
                PatternName = Me.m_Form.ComboBox_Pattern_MainFrm.Text

                Response_OK = False
                Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , iTimeOut)
                SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(iTimeOut)

                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                    If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                    Response_OK = True
                Else
                    Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                    MessageBox.Show("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Exit Sub
                End If

            Catch ex As Exception
                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]Set Pattern Index Error ! (" & ex.Message & ")")
                MessageBox.Show("[Dialog_FuncSettingBase.Dialog_FuncSettingBase_Load]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

        Me.m_Form.ImageUpdate()
        Me.m_Form.RefreshUI()
    End Sub
#End Region

#End Region

#Region "---Event---"
#Region "---ListView_Model---"
    Private Sub ListView_Model_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs)
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim bool As Boolean
        Dim str As String
        Dim CurrentCCD As Integer
        Dim Is_Same_PC As Boolean = True
        Dim ip As ClsIPInfo
        Dim IPMsg As String = ""
        Dim IsIPConnected As Boolean = False
        Dim Request_Command As String = ""
        Dim timeout As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult

        Try
            If Not e.Label Is Nothing Then

                '--- Disable Button ---    
                Me.Button_Enable(False)

                If Not Me.ConnectToMultiIP Then
                    '--- Enable Button ---    
                    Me.Button_Enable(True)
                    Exit Sub
                End If

                If e.Label = "" Then
                    e.CancelEdit = True
                    MsgBox("Model 名稱不可空白", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Exit Sub
                Else
                    '--- Edit Model Name ---
                    'Me.m_ModelChanged = True
                    CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex


                    '--- 取得 Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then

                        MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Exit Sub
                    End If

                    '--- Change CCDNo ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = 0
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("********************[ModelRecipe]**********************")
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

                    bool = True
                    str = e.Label.ToUpper
                    For i = 0 To Me.m_MainProcess.IPBootConfig.ProductList.Count - 1
                        If e.Item <> i Then
                            If str = Me.m_MainProcess.IPBootConfig.ProductList.Item(i).Value.ToUpper Then
                                e.CancelEdit = True
                                bool = False
                                MsgBox("Model 名稱不可重複", MsgBoxStyle.Critical, "[AreaGrabber]")
                            ElseIf e.Item = i Then
                                If str = Me.m_MainProcess.IPBootConfig.ProductList.Item(i).Value.ToUpper Then
                                    e.CancelEdit = True
                                    bool = False
                                    MsgBox("Model 名稱不可重複，沒有大小寫之分", MsgBoxStyle.Critical, "[AreaGrabber]")
                                End If
                            End If
                        End If
                    Next

                    Me.m_MainProcess.IPBootConfig.ProductList.Item(Me.ListView_Model.SelectedIndices(0)).Value = str

                    'Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Model Name Change]" & "Model名稱：" & str & " ---> " & e.Label)
                    'Me.m_MainProcess.SaveBoot()


                    '[MODEL_EDIT]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '--- 斷線清除 ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                            If IsIPConnected = False Or IPMsg <> "" Then
                                MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Edit One Model  ==> Request_Command = "MODEL_EDIT" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "MODEL_EDIT"
                                timeout = 300000 '300 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, e.Item, e.Label.ToUpper, , , , , , , timeout)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---  
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Edit One Model Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---   
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Edit One Model Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next

                    '--- Change CCDNo to CurrentCCD ---   
                    Me.m_Form.ComboBox_CCD.SelectedIndex = 0
                End If

                '--- Enable Button ---    
                Me.Button_Enable(True)
            End If

            Me.ListView_Model.LabelEdit = False

        Catch ex As Exception
            '--- Enable Button ---   
            Me.Button_Enable(True)
            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Edit Func Model Error ! (" & ex.Message & ")(" & ex.StackTrace & ")")
            MessageBox.Show("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit][MODEL_EDIT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub ListView_Model_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim lvi As ListViewItem
        Dim flag As Boolean
        If e.Button = Windows.Forms.MouseButtons.Right Then
            lvi = Me.ListView_Model.GetItemAt(e.X, e.Y)
            If lvi Is Nothing Then
                flag = False
                'Me.ToolStripMenuItem_RemoveModel.Enabled = False
                'Me.ToolStripMenuItem_SetCurrentModel.Enabled = False
            Else
                flag = True
                'Me.ToolStripMenuItem_RemoveModel.Enabled = True
                'Me.ToolStripMenuItem_SetCurrentModel.Enabled = True
            End If

            For i As Integer = 0 To Me.ContextMenuStrip_Model.Items.Count - 1
                If Convert.ToString(Me.ContextMenuStrip_Model.Items(i).Tag).ToUpper() = "REMOVE" Then
                    Me.ContextMenuStrip_Model.Items(i).Enabled = flag
                End If
                If Convert.ToString(Me.ContextMenuStrip_Model.Items(i).Tag).ToUpper() = "SET_CURRENT" Then
                    Me.ContextMenuStrip_Model.Items(i).Enabled = flag
                End If
            Next
        End If
    End Sub
    Private Sub ListView_Model_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.ListView_Model.ContextMenuStrip = Me.ContextMenuStrip_Model
    End Sub
    Private Sub ListView_Model_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.ListView_Model.ContextMenuStrip = Nothing
    End Sub
#End Region
#Region "---ListView_FuncPattern---"
    Private Sub ListView_FuncPattern_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs)
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim bool_Index As Boolean
        Dim str As String
        Dim strOld As String
        Dim PatternName As String
        Dim Path As String
        Dim Is_Same_PC As Boolean = True
        Dim ip As ClsIPInfo
        Dim IPMsg As String = ""
        Dim IsIPConnected As Boolean = False
        Dim Request_Command As String = ""
        Dim timeout As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult

        '--- Disable Button ---   
        Me.Button_Enable(False)

        If Not e.Label Is Nothing Then
            If e.Label = "" Then
                e.CancelEdit = True
                MsgBox("Pattern 名稱不可空白", MsgBoxStyle.Critical, "[AreaGrabber]")
                '--- Enable Button ---  
                Me.Button_Enable(True)
                Exit Sub
            Else

                '--- 建立連線 ---
                If Not Me.ConnectToMultiIP Then
                    '--- Enable Button ---   
                    Me.Button_Enable(True)
                    Exit Sub
                End If
                'Me.m_PatternChanged = True

                bool_Index = True
                str = e.Label.ToUpper
                For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                    If e.Item <> i Then
                        If str = Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value.ToUpper Then
                            e.CancelEdit = True
                            bool_Index = False
                            MsgBox("Pattern 名稱不可重複", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If
                    End If
                Next

                PatternName = e.Label
                Repair_PatternName(PatternName)

                If bool_Index Then

                    For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                        '--- 取得 Grab No ---
                        If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                            MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If

                        '--- Change CCDNo ---
                        Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                        Me.m_FuncProcess.FuncPatternRecipeArray.Item(e.Item).PatternName.Value = PatternName
                        Path = Me.m_IPBootConfig.RecipePath.Value & "\IP" & CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncPatternRecipe_C" & GrabNo & "_P" & e.Item + 1 & ".xml"
                        RepairPath_2(Path)
                        ClsFuncPatternRecipe.WriteXML(Me.m_FuncProcess.FuncPatternRecipeArray.Item(e.Item), Path)
                    Next

                    '--- Check Same PC ---
                    For j = 0 To Me.m_MainProcess.IPNetworkConfig.Total_IP - 2
                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(j).IP_IPAddress <> Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(j + 1).IP_IPAddress Then
                            Is_Same_PC = False
                        End If
                    Next

                    '--- Re New Label --- 
                    Me.ListView_FuncPattern.Items.Clear()
                    For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                        Me.ListView_FuncPattern.Items.Add(Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value)
                    Next
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Item(e.Item + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value) = PatternName
                    Me.m_Form.RefreshUI()

                    strOld = Me.m_FuncProcess.FuncPatternRecipeArray.Item(e.Item).PatternName.Value
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern Name Change]" & "Pattern名稱：" & strOld & " ----> " & PatternName)

                    If Not Is_Same_PC Then
                        '[FUNC_PATTERN_EDIT]
                        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                                '--- 斷線清除 ---
                                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                                ip = New ClsIPInfo
                                ip.CCDNo = i
                                ip.GrabNo = ""
                                Me.m_MainProcess.IPInfo.Add(ip)

                                IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                                If IsIPConnected = False Or IPMsg <> "" Then
                                    MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                    Me.m_MainProcess.IsIPConnected = False
                                End If

                                '----------------------------------------------------------------------------------------------
                                ' Edit Func Pattern  ==> Request_Command = "FUNC_PATTERN_EDIT" (Dispatcher 2)
                                '----------------------------------------------------------------------------------------------
                                Try
                                    '--- Prepare Command ---
                                    Request_Command = "FUNC_PATTERN_EDIT"
                                    timeout = 300000 '300 secs

                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, e.Item, PatternName, , , , , , , timeout)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                        Response_OK = True
                                    Else
                                        '--- Enable Button ---    
                                        Me.Button_Enable(True)
                                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Edit Func Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                        MessageBox.Show("[Dialog_FuncSettingBase.ListView_Pattern_AfterLabelEdit]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        Exit Sub
                                    End If

                                Catch ex As Exception
                                    '--- Enable Button ---    
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ListView_Pattern_AfterLabelEdit]Edit Func Pattern Error ! (" & ex.Message & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ListView_Pattern_AfterLabelEdit]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            End If
                        Next

                    End If

                    '--- Change CCDNo to 1 ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = 0
                End If
            End If
        End If

        '--- Enable Button ---   
        Me.Button_Enable(True)

        Me.ListView_FuncPattern.LabelEdit = False
    End Sub
    Private Sub ListView_FuncPattern_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim lvi As ListViewItem
        Dim flag As Boolean
        If e.Button = Windows.Forms.MouseButtons.Right Then
            lvi = Me.ListView_FuncPattern.GetItemAt(e.X, e.Y)
            If lvi Is Nothing Then
                flag = False
                'Me.ToolStripMenuItem_RemoveModel.Enabled = False
            Else
                flag = True
                'Me.ToolStripMenuItem_RemoveModel.Enabled = True
            End If

            For i As Integer = 0 To Me.ContextMenuStrip_FuncPattern.Items.Count - 1
                If Convert.ToString(Me.ContextMenuStrip_FuncPattern.Items(i).Tag).ToUpper() = "REMOVE" Then
                    Me.ContextMenuStrip_FuncPattern.Items(i).Enabled = flag
                End If
            Next
        End If
    End Sub
    Private Sub ListView_FuncPattern_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.ListView_FuncPattern.ContextMenuStrip = Me.ContextMenuStrip_FuncPattern
    End Sub
    Private Sub ListView_FuncPattern_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.ListView_FuncPattern.ContextMenuStrip = Nothing
    End Sub
#End Region
#Region "---ListView_MuraPattern---"
    Private Sub ListView_MuraPattern_AfterLabelEdit(ByVal sender As Object, ByVal e As System.Windows.Forms.LabelEditEventArgs)
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim bool_Index As Boolean
        Dim str As String
        Dim strOld As String
        Dim PatternName As String
        Dim ip As ClsIPInfo
        Dim IPMsg As String = ""
        Dim IsIPConnected As Boolean = False
        Dim Request_Command As String = ""
        Dim timeout As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult

        '--- Disable Button ---   
        Me.Button_Enable(False)

        If Not e.Label Is Nothing Then
            If e.Label = "" Then
                e.CancelEdit = True
                MsgBox("Pattern 名稱不可空白", MsgBoxStyle.Critical, "[AreaGrabber]")
                Me.Button_Enable(True)
                Exit Sub
            Else

                '--- 建立連線 ---
                If Not Me.ConnectToMultiIP Then
                    '--- Enable Button ---    
                    Me.Button_Enable(True)
                    Exit Sub
                End If
                'Me.m_PatternChanged = True

                bool_Index = True
                str = e.Label.ToUpper
                For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                    If e.Item <> i Then
                        If str = Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value.ToUpper Then
                            e.CancelEdit = True
                            bool_Index = False
                            MsgBox("Pattern 名稱不可重複", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If
                    End If
                Next

                PatternName = e.Label
                Repair_PatternName(PatternName)

                If bool_Index Then

                    For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                        '--- 取得 Grab No ---
                        If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                            MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If

                        '--- Change CCDNo ---  
                        Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                        Me.m_MuraProcess.MuraPatternRecipeArray.Item(e.Item).PatternName.Value = PatternName
                        ClsMuraPatternRecipe.WriteXML(Me.m_MuraProcess.MuraPatternRecipeArray.Item(e.Item), Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Mura\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & e.Item + 1 & ".xml")
                    Next

                    '--- Re New Label ---  
                    Me.ListView_MuraPattern.Items.Clear()
                    For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                        Me.ListView_MuraPattern.Items.Add(Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value)
                    Next
                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Item(e.Item + Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value) = PatternName
                    Me.m_Form.RefreshUI()

                    strOld = Me.m_MuraProcess.MuraPatternRecipeArray.Item(e.Item).PatternName.Value
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern Name Change]" & "Pattern名稱：" & strOld & " ----> " & PatternName)

                    '[MURA_PATTERN_EDIT]
                    For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                        If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                            '--- 斷線清除 ---
                            If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                            If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                            ip = New ClsIPInfo
                            ip.CCDNo = i
                            ip.GrabNo = ""
                            Me.m_MainProcess.IPInfo.Add(ip)

                            IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                            If IsIPConnected = False Or IPMsg <> "" Then
                                MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_MainProcess.IsIPConnected = False
                            End If

                            '----------------------------------------------------------------------------------------------
                            ' Edit Mura Pattern  ==> Request_Command = "MURA_PATTERN_EDIT" (Dispatcher 2)
                            '----------------------------------------------------------------------------------------------
                            Try
                                '--- Prepare Command ---
                                Request_Command = "MURA_PATTERN_EDIT"
                                timeout = 300000 '300 secs

                                Response_OK = False
                                Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, e.Item, PatternName, , , , , , , timeout)
                                SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                                If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                    If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                    Response_OK = True
                                Else
                                    '--- Enable Button ---  
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Edit Mura Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.ListView_Pattern_AfterLabelEdit]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Exit Sub
                                End If

                            Catch ex As Exception
                                '--- Enable Button ---   
                                Me.Button_Enable(True)
                                Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.ListView_Pattern_AfterLabelEdit]Edit Mura Pattern Error ! (" & ex.Message & ")")
                                MessageBox.Show("[Dialog_MuraSettingBase.ListView_Pattern_AfterLabelEdit]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            End Try
                        End If
                    Next

                End If
            End If
        End If

        '---  Button ---   
        Me.Button_Enable(True)

        Me.ListView_MuraPattern.LabelEdit = False
    End Sub
    Private Sub ListView_MuraPattern_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs)
        Dim lvi As ListViewItem
        Dim flag As Boolean

        If e.Button = Windows.Forms.MouseButtons.Right Then
            lvi = Me.ListView_MuraPattern.GetItemAt(e.X, e.Y)
            If lvi Is Nothing Then
                flag = False
                'Me.ToolStripMenuItem_RemoveModel.Enabled = False
            Else
                flag = True
                'Me.ToolStripMenuItem_RemoveModel.Enabled = True
            End If

            For i As Integer = 0 To Me.ContextMenuStrip_MuraPattern.Items.Count - 1
                If Convert.ToString(Me.ContextMenuStrip_MuraPattern.Items(i).Tag).ToUpper() = "REMOVE" Then
                    Me.ContextMenuStrip_MuraPattern.Items(i).Enabled = flag
                End If
            Next
        End If
    End Sub
    Private Sub ListView_MuraPattern_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.ListView_MuraPattern.ContextMenuStrip = Me.ContextMenuStrip_MuraPattern
    End Sub
    Private Sub ListView_MuraPattern_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.ListView_MuraPattern.ContextMenuStrip = Nothing
    End Sub
#End Region
#Region "---ContextMenuStrip---"
#Region "--- ContextMenuStrip_Model_ItemClicked ---"
    Private Sub ContextMenuStrip_Model_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)
        Dim i As Integer
        Dim IPNo As Integer
        Dim GrabNo As String = ""
        Dim RemoveIndex As Integer
        Dim CurrentModelIndex As Integer
        Dim CurrentModelName As String
        Dim str As String
        Dim str_Remove As String
        Dim mmr As ClsMuraModelRecipe
        Dim fmr As ClsFuncModelRecipe
        Dim mpra As ClsMuraPatternRecipeArray
        Dim fpra As ClsFuncPatternRecipeArray
        Dim mpr As ClsMuraPatternRecipe
        Dim fpr As ClsFuncPatternRecipe
        Dim BootRecipeFilename As String
        Dim ProductName As ClsString = Nothing
        Dim ip As ClsIPInfo
        Dim IPMsg As String = ""
        Dim IsIPConnected As Boolean = False
        Dim Request_Command As String = ""
        Dim timeout As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim CurrentCCD As Integer

        '--- Disable Button ---   
        Me.Button_Enable(False)

        '--- 建立連線 ---
        If Not Me.ConnectToMultiIP Then
            'Enable Button ---    
            Me.Button_Enable(True)
            Exit Sub
        End If

        '[Add New Model] ---
        Select Case Convert.ToString(e.ClickedItem.Tag).ToUpper
            Case "ADD"
                CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

                i = Me.ListView_Model.Items.Count + 1
                str = InputBox("請輸入Model Name", "Model Name")
                For i = 0 To Me.ListView_Model.Items.Count - 1
                    If str = Me.ListView_Model.Items(i).Text Then
                        MsgBox("Model:" & str & "已經存在,請將其重新命名", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Exit Sub
                    End If
                Next
                Me.ListView_Model.Items.Add(str)

                '--- 取得 Grab No ---
                If Not (Me.m_Form.Change_GrabNo(IPNo, GrabNo) And GrabNo <> "") Then
                    MsgBox("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                    'Me.Button_Enable(True)
                    Exit Sub
                End If

                '--- Change CCDNo --- 
                Me.m_Form.ComboBox_CCD.SelectedIndex = 0

                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("********************[ModelRecipe]**********************")
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[User ID] : " & Me.m_MainProcess.UserID)

                ProductName = New ClsString("ProductName", str, 1000)
                Me.m_MainProcess.IPBootConfig.ProductList.Add(ProductName)
                If Me.m_IPBootConfig.ProductList.Count <> Me.m_MainProcess.IPBootConfig.ProductList.Count Then
                    Me.m_IPBootConfig.ProductList.Add(ProductName)
                End If

                '--- [MODEL_ADD] ---
                For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                        ''--- Change IP --- 
                        'Me.m_Form.ComboBox_CCD.SelectedIndex = i - 1

                        '--- 斷線清除 ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = i
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                        If IsIPConnected = False Or IPMsg <> "" Then
                            MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If

                        '----------------------------------------------------------------------------------------------
                        ' Add One Model  ==> Request_Command = "MODEL_ADD" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            'Prepare Command ---
                            Request_Command = "MODEL_ADD"
                            timeout = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , timeout)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                'Enable Button ---   '2010/12/18 Rick add
                                Me.Button_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add One Model Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_ADD]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            'Enable Button ---   '2010/12/18 Rick add
                            Me.Button_Enable(True)
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Model]Add One Model Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_ADD]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                Next

                'Change CCDNo to Current CCD ---   
                Me.m_Form.ComboBox_CCD.SelectedIndex = CurrentCCD
            Case "REMOVE"

                '[Remove One Model] ---
                RemoveIndex = Me.ListView_Model.SelectedIndices(0)

                If Not Me.ConnectToMultiIP Then
                    Me.Button_Enable(True)
                    Exit Sub
                End If
                'Me.m_ModelChanged = True
                CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

                If Me.ListView_Model.Items.Count = 1 Then
                    MsgBox("至少保留一個Model", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Exit Sub
                ElseIf Me.ListView_Model.Items(RemoveIndex).Text = Me.m_MainProcess.ProductName Then
                    MsgBox("欲刪除之Model為Current Model,請先將其他Model設定為Current Model", MsgBoxStyle.Critical, "[AreaGrabber]")
                    'Me.Button_Enable(True)
                    Exit Sub
                Else
                    If MsgBox("是否刪除 Model: " & Me.m_MainProcess.IPBootConfig.ProductList.Item(RemoveIndex).Value & " ?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                        'CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

                        i = Me.ListView_Model.SelectedIndices(0)
                        str_Remove = Me.m_MainProcess.IPBootConfig.ProductList.Item(RemoveIndex).Value

                        '--- 取得 Grab No ---
                        IPNo = 1   'Load CCD 1's all Recipe ---
                        If Not (Me.m_Form.Change_GrabNo(IPNo, GrabNo) And GrabNo <> "") Then
                            MsgBox("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.Button_Enable(True)
                            Exit Sub
                        End If

                        Me.ListView_Model.Items.RemoveAt(RemoveIndex)
                        Me.m_MainProcess.IPBootConfig.ProductList.RemoveAt(RemoveIndex)
                        If Me.m_MainProcess.IPBootConfig.ProductList.Count <> Me.m_IPBootConfig.ProductList.Count Then
                            Me.m_IPBootConfig.ProductList.RemoveAt(RemoveIndex)
                        End If

                        If Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value > RemoveIndex Then
                            Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value -= 1
                        End If

                        'Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Model Delete]" & "刪除一組Model，名稱：" & str_Remove)
                        'Me.m_MainProcess.SaveBoot()

                        '[MODEL_DELETE]
                        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                                '斷線清除 ---
                                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                                ip = New ClsIPInfo
                                ip.CCDNo = i
                                ip.GrabNo = ""
                                Me.m_MainProcess.IPInfo.Add(ip)

                                IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                                If IsIPConnected = False Or IPMsg <> "" Then
                                    MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                    Me.m_MainProcess.IsIPConnected = False
                                End If

                                '----------------------------------------------------------------------------------------------
                                ' Delete One Model  ==> Request_Command = "MODEL_DELETE" (Dispatcher 2)
                                '----------------------------------------------------------------------------------------------
                                Try
                                    'Prepare Command ---
                                    Request_Command = "MODEL_DELETE"
                                    timeout = 300000 '300 secs

                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str_Remove, , , , , , , , timeout)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                        Response_OK = True
                                    Else
                                        'Enable Button ---   '2010/12/18 Rick add
                                        'Me.Button_Enable(True)
                                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete One Model Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                        MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_DELETE]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        Exit Sub
                                    End If

                                Catch ex As Exception
                                    'Enable Button ---   '2010/12/18 Rick add
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Model]Delete One Model Error ! (" & ex.Message & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            End If
                        Next

                    End If

                    'Change CCDNo to Current CCD --- 
                    Me.m_Form.ComboBox_CCD.SelectedIndex = CurrentCCD
                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = 0
                    Me.UpdateModelInfo()
                End If
            Case "SET_CURRENT"

                If Not Me.ConnectToMultiIP Then
                    'Enable Button ---  
                    'Me.Button_Enable(True)
                    Exit Sub
                End If

                'Me.m_ModelChanged = True
                CurrentCCD = Me.m_Form.ComboBox_CCD.SelectedIndex

                '[Set Current Model] --- 
                CurrentModelIndex = Me.ListView_Model.SelectedIndices(0)

                '[MODEL_SETCURRENT]
                For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                        '斷線清除 ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = i
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                        If IsIPConnected = False Or IPMsg <> "" Then
                            MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If

                        '----------------------------------------------------------------------------------------------
                        ' Set Current Model  ==> Request_Command = "MODEL_SETCURRENT" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            'Prepare Command ---
                            Request_Command = "MODEL_SETCURRENT"
                            timeout = 300000 '300 secs

                            Response_OK = False
                            CurrentModelName = Me.m_MainProcess.IPBootConfig.ProductList.Item(CurrentModelIndex).Value
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, CurrentModelName, , , , , , , , timeout)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                'Enable Button ---   
                                Me.Button_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Current Model Error !(" & SubSystemResult.ErrMessage & ")(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_SETCURRENT]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            'Enable Button ---   
                            Me.Button_Enable(True)
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Model]Set Current Model Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Model][MODEL_SETCURRENT]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                Next


                CurrentModelName = Me.m_MainProcess.IPBootConfig.ProductList.Item(CurrentModelIndex).Value
                If Not Me.m_MainProcess.RecipeDailyLogManager Is Nothing Then
                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("變換產品: " & Me.m_Form.TextBox_Product.Text & " --> " & CurrentModelName)
                End If
                Me.m_Form.OutputInfo("變換產品: " & Me.m_Form.TextBox_Product.Text & " --> " & CurrentModelName)
                Me.m_Form.TextBox_Product.Text = CurrentModelName

                IPNo = 1

                '取得 Grab No ---
                If Not (Me.m_Form.Change_GrabNo(IPNo, GrabNo) And GrabNo <> "") Then
                    MsgBox("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Exit Sub
                End If

                'Change CCDNo ---   '2010/11/11 Rick add
                Me.m_Form.ComboBox_CCD.SelectedIndex = IPNo - 1

                If Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value <> CurrentModelIndex Then
                    CurrentModelName = Me.m_MainProcess.IPBootConfig.ProductList.Item(CurrentModelIndex).Value
                    '讀取IPBootConfig ---  '2012/01/30 Rick add
                    BootRecipeFilename = Me.m_MainProcess.BootRecipePath & "\IPBootConfig_IP" & IPNo & "_C" & GrabNo & ".xml"
                    If System.IO.File.Exists(BootRecipeFilename) Then     ' 檢查Recipe的路徑是否存在
                        Me.m_MainProcess.IPBootConfig = MILOperationLib.ClsIPBootConfig.ReadXML(BootRecipeFilename)
                    Else
                        Throw New Exception("[Read IPBootConfig] IPBootConfig Recipe 路徑不存在！(" & BootRecipeFilename & ")")
                    End If

                    Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value = CurrentModelIndex
                    Me.m_MainProcess.CurrentProductIndex = CurrentModelIndex


                    Me.m_MainProcess.GrabNo = GrabNo
                    Me.m_MainProcess.CCDNo = IPNo
                    Me.m_MainProcess.CurrentProductIndex = CurrentModelIndex
                    Me.m_MainProcess.ProductName = Me.m_IPBootConfig.ProductList.Item(CurrentModelIndex).Value
                    Me.m_MainProcess.UpdateIPBootSetting()

                    '儲存IPBootConfig ---  '2012/01/30 Rick add
                    MILOperationLib.ClsIPBootConfig.WriteXML(Me.m_MainProcess.IPBootConfig, BootRecipeFilename)

                    'Mura ---
                    'If Me.m_MainProcess.IPBootConfig.MuraUI.Value Then    '2010/10/12 Rick cancel,不限是否有啟動MURA
                    Me.m_MuraProcess.LoadAllRecipeAndFFCImages(Me.m_MainProcess.RECIPE_PATH, CurrentModelName, IPNo, GrabNo, Me.m_MainProcess.ErrorCode)
                    mmr = Me.m_MuraProcess.MuraModelRecipe
                    mpra = Me.m_MuraProcess.MuraPatternRecipeArray
                    Me.m_MainProcess.MuraModelRecipeTemp.Copy(mmr)

                    Me.m_Form.ComboBox_Pattern_MainFrm.Items.Clear()
                    Me.m_MainProcess.MuraPatternRecipeArrayTemp.Clear()
                    Me.m_MainProcess.MuraPatternRecipeArrayOrder.Clear()
                    For i = 0 To mmr.PatternCount.Value - 1
                        mpr = mpra.Item(i)
                        Me.m_Form.ComboBox_Pattern_MainFrm.Items.Add(mpr.PatternName.Value)
                        Me.m_MainProcess.MuraPatternRecipeArrayTemp.Add(New ClsMuraPatternRecipe(mpr))
                        Me.m_MainProcess.MuraPatternRecipeArrayOrder.Add(mpr)
                    Next

                    '更新 Mura 演算法內的Pitch --------------------------- 
                    '更新Mura Pitch ---
                    'Me.m_MuraProcess.IniFilters(mmr.PitchX.Value, mmr.PitchY.Value, Me.m_MainProcess.ErrorCode)   '09/18 Rick modify
                    'End If

                    'Func --- 
                    'If Me.m_MainProcess.IPBootConfig.FuncUI.Value Then    '2010/10/12 Rick cancel,不限是否有啟動MURA
                    Me.m_MainProcess.FuncProcess.LoadFuncImageProcessRecipe(Me.m_IPBootConfig, CurrentModelName, IPNo, GrabNo, Me.m_MainProcess.ErrorCode)
                    fmr = Me.m_MainProcess.FuncProcess.FuncModelRecipe
                    fpra = Me.m_MainProcess.FuncProcess.FuncPatternRecipeArray
                    Me.m_MainProcess.FuncModelRecipeTemp.Copy(fmr)

                    Me.m_MainProcess.FuncPatternRecipeArrayTemp.Clear()
                    Me.m_MainProcess.FuncPatternRecipeArrayOrder.Clear()
                    For i = 0 To fmr.PatternCount.Value - 1
                        fpr = fpra.Item(i)
                        Me.m_Form.ComboBox_Pattern_MainFrm.Items.Add(fpr.PatternName.Value)
                        Me.m_MainProcess.FuncPatternRecipeArrayTemp.Add(New ClsFuncPatternRecipe(fpr))
                        Me.m_MainProcess.FuncPatternRecipeArrayOrder.Add(fpr)
                    Next

                    'End If

                    'Measurement ---
                    Me.m_MainProcess.MeasProcess.LoadAllMeasRecipe(Me.m_MainProcess.BootRecipePath, Me.m_MainProcess.RECIPE_PATH, CurrentModelName, IPNo, GrabNo, Me.m_MainProcess.ErrorCode)

                    'MappingTable & MappingTableRecipe --- ---
                    'If Me.m_MainProcess.IPBootConfig.Panel_TransferMode.Value = "MAPPINGTABLE" Then
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & IPNo & "\" & CurrentModelName & "\Func\MappingTable_C" & GrabNo & ".txt"
                    RepairPath_2(str)
                    If System.IO.File.Exists(str) Then
                        Try
                            Me.m_MainProcess.TableProcess.MappingTable.LoadTable(str)
                        Catch ex As Exception
                            Throw New Exception("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]MappingTable Load Error! (" & ex.Message & ")")
                        End Try
                        If Not Me.m_MainProcess.TableProcess.MappingTable.HaveData Then
                            Try
                                str = Me.m_MainProcess.RECIPE_PATH & "\" & CurrentModelName & "\Func\Backup\MappingTable_C" & GrabNo & ".txt"
                                RepairPath_2(str)
                                Me.m_MainProcess.TableProcess.MappingTable.LoadTable(str)
                            Catch ex As Exception
                                Throw New Exception("[Dialog_FuncSettingBase]MappingTable Load Error! (" & ex.Message & ")")
                            End Try
                            If Not Me.m_MainProcess.TableProcess.MappingTable.HaveData Then
                                MsgBox("還沒做MappingTable檔案，請確認：" & str, MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.m_Form.OutputInfo("還沒做MappingTable檔案，請確認 !")
                            Else '回存
                                str = Me.m_MainProcess.RECIPE_PATH & "\" & CurrentModelName & "\Func\MappingTable_C" & GrabNo & ".txt"
                                RepairPath_2(str)
                                Me.m_MainProcess.TableProcess.MappingTable.Save(str)
                            End If
                        End If
                    Else
                        'MsgBox("MappingTable檔案不存在，請確認：" & str, MsgBoxStyle.Critical, "[AreaGrabber]")
                        'Me.m_Form.OutputInfo("MappingTable檔案不存在，請確認 !")
                    End If

                    'MappingTableRecipe ---   '2010/11/11 Rick add
                    str = Me.m_MainProcess.RECIPE_PATH & "\IP" & IPNo & "\" & CurrentModelName & "\Func\MappingTableRecipe_C" & GrabNo & ".txt"
                    RepairPath_2(str)
                    If System.IO.File.Exists(str) Then
                        Try
                            ClsMappingTableRecipe.ReadXML(str)
                        Catch ex As Exception
                            Throw New Exception("[Dialog_FuncSettingBase.ContextMenuStrip_Model_ItemClicked]MappingTable Load Error! (" & ex.Message & ")")
                        End Try
                    Else
                        'MsgBox("MappingTableRecipe 檔案不存在，請確認：" & str, MsgBoxStyle.Critical, "[AreaGrabber]")
                        'Me.m_Form.OutputInfo("MappingTableRecipe 檔案不存在，請確認 !")
                    End If

                    Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Current Model Set]" & "設定目前Model，名稱：" & Me.m_Form.TextBox_Product.Text)
                    Me.m_MainProcess.SaveBoot()
                End If

                'Change CCDNo to Current CCD ---    
                Me.m_Form.ComboBox_CCD.SelectedIndex = -1
                Me.m_Form.ComboBox_CCD.SelectedIndex = 0
                Me.m_Form.SetPatternIndex(1)
                Me.UpdateModelInfo()
        End Select
        'Enable Button ---  
        Me.Button_Enable(True)
    End Sub
#End Region
#Region "--- ContextMenuStrip_FuncPattern_ItemClicked ---"
    Private Sub ContextMenuStrip_FuncPattern_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)
        Dim i As Integer
        Dim j As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim PatternIndex As Integer
        Dim MuraPatternCount As Integer
        Dim str As String
        Dim RemovePattern As String = ""
        Dim fpr As ClsFuncPatternRecipe
        Dim PatternName As String = ""
        Dim SelectPattern As Integer
        Dim PatternStrs As String()
        Dim ip As ClsIPInfo
        Dim IPMsg As String = ""
        Dim IsIPConnected As Boolean = False
        Dim Request_Command As String = ""
        Dim timeout As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult
        Dim CurrentCCD As Integer

        '--- Disable Button ---    
        Me.Button_Enable(False)

        '--- 建立連線 ---
        If Not Me.ConnectToMultiIP Then
            '--- Enable Button ---    
            Me.Button_Enable(True)
            Exit Sub
        End If

        Select Case Convert.ToString(e.ClickedItem).ToUpper()
            Case "ADD"
                'Me.m_PatternChanged = True

                i = Me.ListView_FuncPattern.Items.Count + 1
                str = InputBox("請輸入PatternName", "PatternName")
                If str = "" Then Exit Sub
                Me.ListView_FuncPattern.Items.Add(str)


                For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                    '--- 取得 Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                        MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.Button_Enable(True)
                        Me.ListView_FuncPattern.Items.RemoveAt(Me.ListView_FuncPattern.Items.Count)
                        Exit Sub
                    End If

                    '--- 斷線清除 ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = CCDNo
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                    If IsIPConnected = False Or IPMsg <> "" Then
                        MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    '----------------------------------------------------------------------------------------------
                    'Check Pattern Count & Pattern Name  ==> Request_Command = "GET_ALL_FUNC_PATTERN" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "GET_ALL_FUNC_PATTERN"
                        timeout = 300000 '300 secs
                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , timeout)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(timeout)
                        PatternStrs = SubSystemResult.Responses(0).Param2.Split(";")
                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If CInt(SubSystemResult.Responses(0).Param1) <> Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value Then
                                MessageBox.Show("[GET_ALL_FUNC_PATTERN] Please Check CCD" & CCDNo & " , FuncModelRecipe_C" & GrabNo & ".xml PatternCount  Value Error", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.ListView_FuncPattern.Items.RemoveAt(Me.ListView_FuncPattern.Items.Count - 1)
                                'Kill IP ---    
                                Me.m_Form.Button_KillIP.PerformClick()
                                Exit Sub
                            End If
                            For i = 0 To Me.m_FuncProcess.FuncPatternRecipeArray.Count - 1
                                If PatternStrs(i) <> Me.m_FuncProcess.FuncPatternRecipeArray.Item(i).PatternName.Value Then
                                    MessageBox.Show("[GET_ALL_FUNC_PATTERN] Please Check CCD" & CCDNo & " , FuncPatternRecipe_C" & GrabNo & "_P." & i + 1 & ".xml PatternName Value Error", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Me.ListView_FuncPattern.Items.RemoveAt(Me.ListView_FuncPattern.Items.Count - 1)
                                    'Kill IP ---    
                                    Me.m_Form.Button_KillIP.PerformClick()
                                    Exit Sub
                                End If
                            Next
                        Else
                            Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "GET_ALL_FUNC_PATTERN Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSeting.GET_ALL_FUNC_PATTERN]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.ListView_FuncPattern.Items.RemoveAt(Me.ListView_FuncPattern.Items.Count - 1)
                            'Kill IP ---    
                            Me.m_Form.Button_KillIP.PerformClick()
                            Exit Sub
                        End If

                    Catch ex As Exception
                        Exit Sub
                    End Try
                Next

                '--- PatternName ---
                If Me.ListView_FuncPattern.SelectedItems.Count = 1 Then
                    PatternName = Me.ListView_FuncPattern.SelectedItems(0).Text
                    For j = 0 To Me.ListView_FuncPattern.Items.Count - 1
                        If Me.ListView_FuncPattern.SelectedItems(0).Text = Me.ListView_FuncPattern.Items(j).Text Then
                            SelectPattern = j
                            Exit For
                        End If
                    Next
                Else
                    PatternName = Me.ListView_FuncPattern.Items(0).Text
                    SelectPattern = 0
                End If

                For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    '--- 取得 Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                        MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.Button_Enable(True)
                        Me.ListView_FuncPattern.Items.RemoveAt(Me.ListView_FuncPattern.Items.Count)
                        Exit Sub
                    End If

                    'Change CCDNo ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1
                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = SelectPattern + Me.m_MuraProcess.MuraPatternRecipeArray.Count

                    '----------------------------------------------------------------------------------------------
                    ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SET_PATTERNINDEX"
                        timeout = 300000 '300 secs


                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , timeout)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(timeout)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.ListView_FuncPattern.Items.RemoveAt(Me.ListView_FuncPattern.Items.Count)
                            Exit Sub
                        End If

                        Button_Enable(True)
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try

                    Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value += 1
                    fpr = Me.m_FuncProcess.CurrentFuncPatternRecipe
                    fpr = New ClsFuncPatternRecipe(fpr)
                    fpr.PatternName.Value = str
                    Me.m_FuncProcess.FuncPatternRecipeArray.Add(fpr)
                    Me.m_MainProcess.FuncPatternRecipeArrayTemp.Add(fpr)
                    Me.m_MainProcess.FuncPatternRecipeArrayOrder.Add(fpr)
                    Me.m_MainProcess.FuncProcess.FuncModelRecipe.PatternCount.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Count()
                    Me.RecipeUpdate(CCDNo, GrabNo)
                Next
                Me.m_Form.ComboBox_Pattern_MainFrm.Items.Add(str)
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern Add]" & "增加一組Pattern，Pattern名稱：" & str)

                '[FUNC_PATTERN_ADD]
                For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                        '--- 斷線清除 ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = i
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                        If IsIPConnected = False Or IPMsg <> "" Then
                            MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If

                        '----------------------------------------------------------------------------------------------
                        ' Add Func Pattern  ==> Request_Command = "FUNC_PATTERN_ADD" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "FUNC_PATTERN_ADD"
                            timeout = 300000 '300 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , timeout)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                '--- Enable Button ---    
                                Me.Button_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add Func Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            '--- Enable Button ---    
                            Me.Button_Enable(True)
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]Add Func Pattern Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                Next

                '--- 斷線清除 ---
                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                ip = New ClsIPInfo
                ip.CCDNo = 1
                ip.GrabNo = ""
                Me.m_MainProcess.IPInfo.Add(ip)

                IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                If IsIPConnected = False Or IPMsg <> "" Then
                    MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.m_MainProcess.IsIPConnected = False
                End If

                'Change CCDNo ---    
                Me.m_Form.ComboBox_CCD.SelectedIndex = 0
            Case "REMOVE"

                If Me.ListView_FuncPattern.Items.Count = 1 Then
                    MsgBox("至少保留一個Pattern", MsgBoxStyle.Critical, "[AreaGrabber]")
                Else
                    If MsgBox("是否刪除", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                        'Me.m_PatternChanged = True

                        i = Me.ListView_FuncPattern.SelectedIndices(0)
                        PatternIndex = i
                        MuraPatternCount = Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value

                        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + MuraPatternCount Then
                            If i = 0 Then
                                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + MuraPatternCount
                            Else
                                If Me.m_Form.ComboBox_Pattern_MainFrm.Items.Count - 1 = i + MuraPatternCount Then
                                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = (i - 1) + MuraPatternCount
                                Else
                                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = (i + 1) + MuraPatternCount
                                End If
                            End If
                        End If

                        Me.ListView_FuncPattern.Items.RemoveAt(i)
                        Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i + MuraPatternCount)

                        RemovePattern = Me.m_FuncProcess.FuncPatternRecipeArray.Item(PatternIndex).PatternName.Value
                        Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Func Pattern Delete]" & "刪除一組Pattern，名稱：" & RemovePattern)

                        For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                            '--- 取得 Grab No ---
                            If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                                MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.Button_Enable(True)
                                Exit Sub
                            End If

                            '--- Change CCDNo ---   
                            Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                            Me.m_FuncProcess.FuncModelRecipe.PatternCount.Value -= 1
                            Me.m_FuncProcess.FuncPatternRecipeArray.RemoveAt(PatternIndex)
                            Me.m_MainProcess.FuncPatternRecipeArrayTemp.RemoveAt(PatternIndex)
                            Me.m_MainProcess.FuncPatternRecipeArrayOrder.RemoveAt(PatternIndex)
                            Me.m_MainProcess.FuncProcess.FuncModelRecipe.PatternCount.Value = Me.m_FuncProcess.FuncPatternRecipeArray.Count()

                            '--- 更新路徑 ---
                            File.Delete(Me.m_IPBootConfig.RecipePath.Value & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_Form.GetProductNameInfo & "\Func\FuncPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & PatternIndex + 1 & ".xml")
                            Me.RecipeUpdate(CCDNo, GrabNo)
                        Next

                        '[FUNC_PATTERN_DELETE]
                        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                                '--- 斷線清除 ---
                                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                                ip = New ClsIPInfo
                                ip.CCDNo = i
                                ip.GrabNo = ""
                                Me.m_MainProcess.IPInfo.Add(ip)

                                IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                                If IsIPConnected = False Or IPMsg <> "" Then
                                    MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                    Me.m_MainProcess.IsIPConnected = False
                                End If

                                '----------------------------------------------------------------------------------------------
                                ' Delete Func Pattern  ==> Request_Command = "FUNC_PATTERN_DELETE" (Dispatcher 2)
                                '----------------------------------------------------------------------------------------------
                                Try
                                    '--- Prepare Command ---
                                    Request_Command = "FUNC_PATTERN_DELETE"
                                    timeout = 300000 '300 secs

                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RemovePattern, , , , , , , , timeout)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                        Response_OK = True
                                    Else
                                        '--- Enable Button ---    
                                        Me.Button_Enable(True)
                                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete Func Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                        MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        Exit Sub
                                    End If

                                Catch ex As Exception
                                    '--- Enable Button ---    
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]Delete Func Pattern Error ! (" & ex.Message & ")")
                                    MessageBox.Show("[Dialog_FuncSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            End If
                        Next

                        '--- 斷線清除 ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = 1
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPMsg)

                        If IsIPConnected = False Or IPMsg <> "" Then
                            MsgBox("IP - " & i & " 連線失敗 !( " & IPMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If

                        'Change CCDNo ---    
                        Me.m_Form.ComboBox_CCD.SelectedIndex = 0

                    End If
                End If
        End Select

        '--- Enable Button ---    
        Me.Button_Enable(True)
    End Sub
#End Region
    Private Sub ContextMenuStrip_MuraPattern_ItemClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)
        Dim i As Integer
        Dim CCDNo As Integer
        Dim GrabNo As String = ""
        Dim PatternIndex As Integer
        Dim RemovePattern As String = ""
        Dim str As String
        Dim mpr As ClsMuraPatternRecipe
        Dim image As MIL_ID = M_NULL
        Dim PatternName As String = ""
        Dim SelectPattern As Integer
        Dim PatternStrs As String()
        Dim ip As ClsIPInfo
        Dim IPConnectMsg As String = ""
        Dim IsIPConnected As Boolean = False
        Dim Request_Command As String = ""
        Dim timeout As Integer
        Dim Response_OK As Boolean
        Dim SubSystemResult As CResponseResult

        '--- Disable Button ---   
        Me.Button_Enable(False)

        '--- 建立連線 ---
        If Not Me.ConnectToMultiIP Then
            '--- Enable Button ---   
            Me.Button_Enable(True)
            Exit Sub
        End If

        Select Case Convert.ToString(e.ClickedItem).ToUpper()
            Case "ADD"
                'Me.m_PatternChanged = True

                i = Me.ListView_MuraPattern.Items.Count + 1
                str = InputBox("請輸入PatternName", "PatternName")
                If str = "" Then Exit Sub
                Me.ListView_MuraPattern.Items.Add(str)

                For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP
                    '--- 取得 Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                        MsgBox("[Dialog_FuncSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.Button_Enable(True)
                        Me.ListView_MuraPattern.Items.RemoveAt(Me.ListView_MuraPattern.Items.Count)
                        Exit Sub
                    End If

                    '--- 斷線清除 ---
                    If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                    If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                    ip = New ClsIPInfo
                    ip.CCDNo = CCDNo
                    ip.GrabNo = ""
                    Me.m_MainProcess.IPInfo.Add(ip)

                    IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPConnectMsg)

                    If IsIPConnected = False Or IPConnectMsg <> "" Then
                        MsgBox("IP - " & i & " 連線失敗 !( " & IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.m_MainProcess.IsIPConnected = False
                    End If

                    '----------------------------------------------------------------------------------------------
                    'Check Pattern Count & Pattern Name  ==> Request_Command = "GET_ALL_MURA_PATTERN" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "GET_ALL_MURA_PATTERN"
                        timeout = 300000 '300 secs
                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , timeout)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(timeout)
                        PatternStrs = SubSystemResult.Responses(0).Param2.Split(";")
                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If CInt(SubSystemResult.Responses(0).Param1) <> Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value Then
                                MessageBox.Show("[GET_ALL_MURA_PATTERN] Please Check CCD" & CCDNo & " , MuraModelRecipe_C" & GrabNo & ".xml PatternCount  Value Error", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Me.ListView_MuraPattern.Items.RemoveAt(Me.ListView_MuraPattern.Items.Count - 1)
                                'Kill IP ---    
                                Me.m_Form.Button_KillIP.PerformClick()
                                Exit Sub
                            End If
                            For i = 0 To Me.m_MuraProcess.MuraPatternRecipeArray.Count - 1
                                If PatternStrs(i) <> Me.m_MuraProcess.MuraPatternRecipeArray.Item(i).PatternName.Value Then
                                    MessageBox.Show("[GET_ALL_MURA_PATTERN] Please Check CCD" & CCDNo & " , MuraPatternRecipe_C" & GrabNo & "_P." & i + 1 & ".xml PatternName Value Error", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                    Me.ListView_MuraPattern.Items.RemoveAt(Me.ListView_MuraPattern.Items.Count - 1)
                                    'Kill IP ---    
                                    Me.m_Form.Button_KillIP.PerformClick()
                                    Exit Sub
                                End If
                            Next
                        Else
                            Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "GET_ALL_MURA_PATTERN Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSeting.GET_ALL_MURA_PATTERN]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Me.ListView_MuraPattern.Items.RemoveAt(Me.ListView_MuraPattern.Items.Count - 1)
                            'Kill IP ---    
                            Me.m_Form.Button_KillIP.PerformClick()
                            Exit Sub
                        End If

                    Catch ex As Exception
                        Exit Sub
                    End Try
                Next

                '--- PatternName ---
                If Me.ListView_MuraPattern.SelectedItems.Count = 1 Then
                    PatternName = Me.ListView_MuraPattern.SelectedItems(0).Text
                    For j = 0 To Me.ListView_MuraPattern.Items.Count - 1
                        If Me.ListView_MuraPattern.SelectedItems(0).Text = Me.ListView_MuraPattern.Items(j).Text Then
                            SelectPattern = j
                            Exit For
                        End If
                    Next
                Else
                    PatternName = Me.ListView_MuraPattern.Items(0).Text
                    SelectPattern = 0
                End If

                For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    '--- 取得 Grab No ---
                    If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                        MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                        Me.Button_Enable(True)
                        Exit Sub
                    End If

                    '--- Change CCDNo ---    
                    Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1
                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = SelectPattern

                    '----------------------------------------------------------------------------------------------
                    ' Set Pattern index   ==> Request_Command = "SET_PATTERNINDEX" (Dispatcher 1)
                    '----------------------------------------------------------------------------------------------
                    Try
                        '--- Prepare Command ---
                        Request_Command = "SET_PATTERNINDEX"
                        timeout = 300000 '300 secs


                        Response_OK = False
                        Me.m_MainProcess.IP_Dispatcher1.PrepareAllRequest(Request_Command, PatternName, , , , , , , , timeout)
                        SubSystemResult = Me.m_MainProcess.IP_Dispatcher1.SendRequest(timeout)

                        If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                            If Me.m_MainProcess.WriteToLog_1 Then Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                            Response_OK = True
                        Else
                            Button_Enable(True)
                            Me.m_MainProcess.LogDailyManager("[G >>C1]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Set Pattern Index Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                            MessageBox.Show("[Dialog_FuncSeting.Pattern_SelectedIndexChanged]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Exit Sub
                        End If

                        Button_Enable(True)
                    Catch ex As Exception
                        Throw New Exception("[" & Request_Command & "]" & ex.Message & "(" & ex.StackTrace & ")")
                    End Try


                    Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value += 1
                    mpr = Me.m_MuraProcess.CurrentMuraPatternRecipe
                    mpr = New ClsMuraPatternRecipe(mpr)
                    mpr.UseFFC.Value = False
                    mpr.PatternName.Value = str
                    Me.m_MuraProcess.MuraPatternRecipeArray.Add(mpr)
                    Me.m_MainProcess.MuraPatternRecipeArrayTemp.Add(mpr)
                    Me.m_MainProcess.MuraPatternRecipeArrayOrder.Add(mpr)
                    Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Count()

                    If Me.m_MuraProcess.Img_FFCAlignArray.Count < Me.m_MuraProcess.MuraPatternRecipeArray.Count Then
                        image = MbufAlloc2d(Me.m_MainProcess.System_Host, 1, 1, 16 + M_UNSIGNED, M_IMAGE + M_PROC + M_NON_PAGED, M_NULL)
                        Me.m_MuraProcess.Img_FFCAlignArray.Add(image)
                    End If

                    Me.RecipeUpdate(CCDNo, GrabNo)
                Next
                Me.m_Form.ComboBox_Pattern_MainFrm.Items.Insert(Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value - 1, str)
                Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern Add]" & "增加一組Pattern，Pattern名稱：" & str)

                '[MURA_PATTERN_ADD]
                For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                    If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                        '--- 斷線清除 ---
                        If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                        If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                        ip = New ClsIPInfo
                        ip.CCDNo = i
                        ip.GrabNo = ""
                        Me.m_MainProcess.IPInfo.Add(ip)

                        IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPConnectMsg)

                        If IsIPConnected = False Or IPConnectMsg <> "" Then
                            MsgBox("IP - " & i & " 連線失敗 !( " & IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                            Me.m_MainProcess.IsIPConnected = False
                        End If

                        '----------------------------------------------------------------------------------------------
                        ' Add Mura Pattern  ==> Request_Command = "MURA_PATTERN_ADD" (Dispatcher 2)
                        '----------------------------------------------------------------------------------------------
                        Try
                            '--- Prepare Command ---
                            Request_Command = "MURA_PATTERN_ADD"
                            timeout = 100000 '100 secs

                            Response_OK = False
                            Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, str, , , , , , , , timeout)
                            SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                            If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                Response_OK = True
                            Else
                                '--- Enable Button ---   
                                Me.Button_Enable(True)
                                Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Add Mura Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                Exit Sub
                            End If

                        Catch ex As Exception
                            '--- Enable Button ---   
                            Me.Button_Enable(True)
                            Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]Add Mura Pattern Error ! (" & ex.Message & ")")
                            MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        End Try
                    End If
                Next
            Case "REMOVE"
                If Me.ListView_MuraPattern.Items.Count = 1 Then
                    MsgBox("至少保留一個Pattern", MsgBoxStyle.Critical, "[AreaGrabber]")
                    Me.Button_Enable(True)
                    Exit Sub
                Else
                    If MsgBox("是否刪除", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                        'Me.m_PatternChanged = True

                        i = Me.ListView_MuraPattern.SelectedIndices(0)
                        PatternIndex = i

                        If Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i Then
                            If i = 0 Then
                                Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i
                            Else
                                If Me.m_Form.ComboBox_Pattern_MainFrm.Items.Count - 1 = i Then
                                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i - 1
                                Else
                                    Me.m_Form.ComboBox_Pattern_MainFrm.SelectedIndex = i + 1
                                End If
                            End If
                        End If

                        Me.ListView_MuraPattern.Items.RemoveAt(i)
                        Me.m_Form.ComboBox_Pattern_MainFrm.Items.RemoveAt(i)

                        RemovePattern = Me.m_MainProcess.MuraProcess.MuraPatternRecipeArray.Item(PatternIndex).PatternName.Value
                        Me.m_MainProcess.RecipeDailyLogManager.WriteLog("[Mura Pattern Delete]" & "刪除一組Pattern，名稱：" & RemovePattern)

                        For CCDNo = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                            '--- 取得 Grab No ---
                            If Not (Me.m_Form.Change_GrabNo(CCDNo, GrabNo) And GrabNo <> "") Then
                                MsgBox("[Dialog_MuraSettingBase.ListView_Model_AfterLabelEdit]Change GrabNo Error !", MsgBoxStyle.Critical, "[AreaGrabber]")
                                Me.Button_Enable(True)
                                Exit Sub
                            End If

                            '--- Change CCDNo ---   
                            Me.m_Form.ComboBox_CCD.SelectedIndex = CCDNo - 1

                            image = Me.m_MuraProcess.Img_FFCAlignArray.Item(PatternIndex)
                            If image <> M_NULL Then
                                MbufFree(image)
                                image = M_NULL
                            End If
                            Me.m_MuraProcess.Img_FFCAlignArray.RemoveAt(PatternIndex)
                            Me.m_MuraProcess.Img_FFCAlignArray.Add(image)

                            Me.m_MuraProcess.MuraModelRecipe.PatternCount.Value -= 1
                            Me.m_MuraProcess.MuraPatternRecipeArray.RemoveAt(PatternIndex)
                            Me.m_MainProcess.MuraPatternRecipeArrayTemp.RemoveAt(PatternIndex)
                            Me.m_MainProcess.MuraPatternRecipeArrayOrder.RemoveAt(PatternIndex)
                            Me.m_MainProcess.MuraProcess.MuraModelRecipe.PatternCount.Value = Me.m_MuraProcess.MuraPatternRecipeArray.Count()

                            File.Delete(Me.m_MainProcess.RECIPE_PATH & "\IP" & Me.m_MainProcess.CCDNo & "\" & Me.m_MainProcess.IPBootConfig.ProductList.Item(Me.m_MainProcess.IPBootConfig.CurrentProductIndex.Value).Value & "\Mura\MuraPatternRecipe_C" & Me.m_MainProcess.GrabNo & "_P" & PatternIndex + 1 & ".xml")
                            Me.RecipeUpdate(CCDNo, GrabNo)
                        Next

                        '[MURA_PATTERN_DELETE]
                        For i = 1 To Me.m_MainProcess.IPNetworkConfig.Total_IP

                            If Me.m_MainProcess.IPNetworkConfig.NetWorkList.Item(i - 1).IP_Enable = True Then

                                '--- 斷線清除 ---
                                If Not Me.m_MainProcess.IP_Dispatcher1 Is Nothing Then Me.m_MainProcess.IP_Dispatcher1.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)
                                If Not Me.m_MainProcess.IP_Dispatcher2 Is Nothing Then Me.m_MainProcess.IP_Dispatcher2.Disconnect(Me.m_MainProcess.IPNetworkConfig.Total_IP)

                                ip = New ClsIPInfo
                                ip.CCDNo = i
                                ip.GrabNo = ""
                                Me.m_MainProcess.IPInfo.Add(ip)

                                IsIPConnected = Me.m_MainProcess.CreateIP(ip.CCDNo, IPConnectMsg)

                                If IsIPConnected = False Or IPConnectMsg <> "" Then
                                    MsgBox("IP - " & i & " 連線失敗 !( " & IPConnectMsg & " )", MsgBoxStyle.Critical, "[AreaGrabber]")
                                    Me.m_MainProcess.IsIPConnected = False
                                End If

                                '----------------------------------------------------------------------------------------------
                                ' Delete Mura Pattern  ==> Request_Command = "MURA_PATTERN_DELETE" (Dispatcher 2)
                                '----------------------------------------------------------------------------------------------
                                Try
                                    '--- Prepare Command ---
                                    Request_Command = "MURA_PATTERN_DELETE"
                                    timeout = 100000 '100 secs

                                    Response_OK = False
                                    Me.m_MainProcess.IP_Dispatcher2.PrepareAllRequest(Request_Command, RemovePattern, , , , , , , , timeout)
                                    SubSystemResult = Me.m_MainProcess.IP_Dispatcher2.SendRequest(timeout)

                                    If SubSystemResult.CommResult = AUO.SubSystemControl.eCommResult.OK Then
                                        If Me.m_MainProcess.WriteToLog_2 Then Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.OK")
                                        Response_OK = True
                                    Else
                                        '--- Enable Button ---   
                                        Me.Button_Enable(True)
                                        Me.m_MainProcess.LogDailyManager("[G >>C2]完成命令 =>" & Request_Command & ", " & "eResponseResult.ERR" & ", " & "Delete Mura Pattern Error !(" & SubSystemResult.ErrMessage & ")(ErrorCode = " & CStr(Me.m_MainProcess.ErrorCode) & ")")
                                        MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & SubSystemResult.ErrMessage, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                        Exit Sub
                                    End If

                                Catch ex As Exception
                                    '--- Enable Button ---    
                                    Me.Button_Enable(True)
                                    Me.m_MainProcess.DailyLogManager.WriteLog("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]Delete Mura Pattern Error ! (" & ex.Message & ")")
                                    MessageBox.Show("[Dialog_MuraSettingBase.ContextMenuStrip_Pattern]" & ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                End Try
                            End If
                        Next
                    End If
                End If
        End Select

        'Change CCDNo ---    
        Me.m_Form.ComboBox_CCD.SelectedIndex = 0

        '--- Enable Button ---   
        Me.Button_Enable(True)
    End Sub

#End Region
#End Region

End Class
